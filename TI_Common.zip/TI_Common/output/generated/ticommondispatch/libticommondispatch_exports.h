//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  ticommondispatch

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libticommondispatch

#if !defined(LIBTICOMMONDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBTICOMMONDISPATCH is not defined
#endif

/* Handwritten code should use TICOMMONDISPATCH_API, not TICOMMONDISPATCHEXPORT */

#define TICOMMONDISPATCH_API TICOMMONDISPATCHEXPORT

#if IPLIB==libticommondispatch || defined(LIBTICOMMONDISPATCH)
#   if defined(__lint)
#       define TICOMMONDISPATCHEXPORT       __export(ticommondispatch)
#       define TICOMMONDISPATCHGLOBAL       extern __global(ticommondispatch)
#       define TICOMMONDISPATCHPRIVATE      extern __private(ticommondispatch)
#   elif defined(_WIN32)
#       define TICOMMONDISPATCHEXPORT       __declspec(dllexport)
#       define TICOMMONDISPATCHGLOBAL       extern __declspec(dllexport)
#       define TICOMMONDISPATCHPRIVATE      extern
#   else
#       define TICOMMONDISPATCHEXPORT
#       define TICOMMONDISPATCHGLOBAL       extern
#       define TICOMMONDISPATCHPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define TICOMMONDISPATCHEXPORT       __export(ticommondispatch)
#       define TICOMMONDISPATCHGLOBAL       extern __global(ticommondispatch)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define TICOMMONDISPATCHEXPORT      __declspec(dllimport)
#       define TICOMMONDISPATCHGLOBAL       extern __declspec(dllimport)
#   else
#       define TICOMMONDISPATCHEXPORT
#       define TICOMMONDISPATCHGLOBAL       extern
#   endif
#endif
