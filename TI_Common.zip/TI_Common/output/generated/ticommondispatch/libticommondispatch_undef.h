//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBTICOMMONDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBTICOMMONDISPATCH is not defined
#endif

#undef TICOMMONDISPATCH_API
#undef TICOMMONDISPATCHEXPORT
#undef TICOMMONDISPATCHGLOBAL
#undef TICOMMONDISPATCHPRIVATE
