/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <titcerpintegration1811impl.hxx>

using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server;

TITCERPIntegrationImpl::GetPartTransferResponse TITCERPIntegrationImpl::getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs )
{
    // TODO implement operation
}


TITCERPIntegrationImpl::GetContractedCostResponse TITCERPIntegrationImpl::importContractedCostInfo ( const GetContractedCostInput& getContractedCostInputs )
{
    // TODO implement operation
}


TITCERPIntegrationImpl::GetSellingPriceResponse TITCERPIntegrationImpl::importSellingPriceInfo ( const GetSellingPriceInput& getSellingPriceInputs )
{
    // TODO implement operation
}


TITCERPIntegrationImpl::GetStandardCostResponse TITCERPIntegrationImpl::importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs )
{
    // TODO implement operation
}



