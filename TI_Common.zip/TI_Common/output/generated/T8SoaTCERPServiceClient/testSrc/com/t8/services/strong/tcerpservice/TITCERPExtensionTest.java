/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
@<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

package com.t8.services.strong.tcerpservice;


import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.client.model.ModelManager;
import com.teamcenter.utest.SoaSession;

import junit.framework.TestCase;

public class TITCERPExtensionTest extends TestCase
{
    private Connection        connection;
    private ModelManager      manager;
    private TITCERPExtensionService   service;
    

    public TITCERPExtensionTest( String name )
    {
        super( name );
    }

    protected void setUp( ) throws Exception
    {
        super.setUp( );

        connection  = SoaSession.getConnection();
        manager     = connection.getModelManager();       
        service     = TITCERPExtensionService.getService(connection);

    }
        
    
    public void testGetPartTransferInfo()
    {
        // TODO write test code, then remove fail()
        // service.getPartTransferInfo(  )
        fail("This test has not been implemented yet");
    }

    public void testImportStandardCostInfo()
    {
        // TODO write test code, then remove fail()
        // service.importStandardCostInfo(  )
        fail("This test has not been implemented yet");
    }


}

