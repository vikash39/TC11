/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Tcerpservice._2018_11.Titcerpextension 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class ImportStandardCostInfoInput 
  {

         private T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetStandardCostInput GetStandardCostInputsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("getStandardCostInputs")]
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetStandardCostInput GetStandardCostInputs
     { 
        get { return this.GetStandardCostInputsField;}
        set { this.GetStandardCostInputsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetStandardCostInput getGetStandardCostInputs()
     { 
       return this.GetStandardCostInputsField;
     }
     public void setGetStandardCostInputs(T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetStandardCostInput val)
     { 
       this.GetStandardCostInputsField = val;
     }



    
    


  } // type
} // ns
            





