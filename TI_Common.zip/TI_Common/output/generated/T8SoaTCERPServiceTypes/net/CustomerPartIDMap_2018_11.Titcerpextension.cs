/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Tcerpservice._2018_11.Titcerpextension 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class CustomerPartIDMap 
  {

         private string KeyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="key")]
     public string Key
     { 
        get { return this.KeyField;}
        set { this.KeyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getKey()
     { 
       return this.KeyField;
     }
     public void setKey(string val)
     { 
       this.KeyField = val;
     }


     private string[] ValueField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("value")]
     public string[] Value
     { 
        get { return this.ValueField;}
        set { this.ValueField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getValue()
     { 
         if(this.ValueField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ValueField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setValue(System.Collections.ArrayList val)
     { 
       this.ValueField = new string[val.Count];
       val.CopyTo(this.ValueField);
     }



    
    


  } // type
} // ns
            





