/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;

using Teamcenter.Schemas.Soa._2006_03.Base;


namespace T8.Schemas.Tcerpservice._2018_11.Titcerpextension 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetPartTransferResponse 
  {

         private string ChangeTypeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="changeType")]
     public string ChangeType
     { 
        get { return this.ChangeTypeField;}
        set { this.ChangeTypeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getChangeType()
     { 
       return this.ChangeTypeField;
     }
     public void setChangeType(string val)
     { 
       this.ChangeTypeField = val;
     }


     private string AffectedPlantsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="affectedPlants")]
     public string AffectedPlants
     { 
        get { return this.AffectedPlantsField;}
        set { this.AffectedPlantsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getAffectedPlants()
     { 
       return this.AffectedPlantsField;
     }
     public void setAffectedPlants(string val)
     { 
       this.AffectedPlantsField = val;
     }


     private string OwningSiteField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="owningSite")]
     public string OwningSite
     { 
        get { return this.OwningSiteField;}
        set { this.OwningSiteField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getOwningSite()
     { 
       return this.OwningSiteField;
     }
     public void setOwningSite(string val)
     { 
       this.OwningSiteField = val;
     }


     private string JobUIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="jobUID")]
     public string JobUID
     { 
        get { return this.JobUIDField;}
        set { this.JobUIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getJobUID()
     { 
       return this.JobUIDField;
     }
     public void setJobUID(string val)
     { 
       this.JobUIDField = val;
     }


     private string ChangeItemNumField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="changeItemNum")]
     public string ChangeItemNum
     { 
        get { return this.ChangeItemNumField;}
        set { this.ChangeItemNumField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getChangeItemNum()
     { 
       return this.ChangeItemNumField;
     }
     public void setChangeItemNum(string val)
     { 
       this.ChangeItemNumField = val;
     }


     private bool SuccessField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="success")]
     public bool Success
     { 
        get { return this.SuccessField;}
        set { this.SuccessField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public bool getSuccess()
     { 
       return this.SuccessField;
     }
     public void setSuccess(bool val)
     { 
       this.SuccessField = val;
     }


     private T8.Schemas.Tcerpservice._2018_11.Titcerpextension.ProductRevisionData[] ProductRevisionDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("productRevisionData")]
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.ProductRevisionData[] ProductRevisionData
     { 
        get { return this.ProductRevisionDataField;}
        set { this.ProductRevisionDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getProductRevisionData()
     { 
         if(this.ProductRevisionDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ProductRevisionDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setProductRevisionData(System.Collections.ArrayList val)
     { 
       this.ProductRevisionDataField = new T8.Schemas.Tcerpservice._2018_11.Titcerpextension.ProductRevisionData[val.Count];
       val.CopyTo(this.ProductRevisionDataField);
     }


     private string[] ErrorListField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("errorList")]
     public string[] ErrorList
     { 
        get { return this.ErrorListField;}
        set { this.ErrorListField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getErrorList()
     { 
         if(this.ErrorListField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ErrorListField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setErrorList(System.Collections.ArrayList val)
     { 
       this.ErrorListField = new string[val.Count];
       val.CopyTo(this.ErrorListField);
     }


     private Teamcenter.Schemas.Soa._2006_03.Base.ServiceData ServiceDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute(ElementName="ServiceData", Namespace="http://teamcenter.com/Schemas/Soa/2006-03/Base")]
     public Teamcenter.Schemas.Soa._2006_03.Base.ServiceData ServiceData
     { 
        get { return this.ServiceDataField;}
        set { this.ServiceDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public Teamcenter.Schemas.Soa._2006_03.Base.ServiceData getServiceData()
     { 
       return this.ServiceDataField;
     }
     public void setServiceData(Teamcenter.Schemas.Soa._2006_03.Base.ServiceData val)
     { 
       this.ServiceDataField = val;
     }


     private T8.Schemas.Tcerpservice._2018_11.Titcerpextension.MaterialRevisionData[] MaterialRevisionDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("materialRevisionData")]
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.MaterialRevisionData[] MaterialRevisionData
     { 
        get { return this.MaterialRevisionDataField;}
        set { this.MaterialRevisionDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getMaterialRevisionData()
     { 
         if(this.MaterialRevisionDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.MaterialRevisionDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setMaterialRevisionData(System.Collections.ArrayList val)
     { 
       this.MaterialRevisionDataField = new T8.Schemas.Tcerpservice._2018_11.Titcerpextension.MaterialRevisionData[val.Count];
       val.CopyTo(this.MaterialRevisionDataField);
     }


     private T8.Schemas.Tcerpservice._2018_11.Titcerpextension.PrgVariantRevisionData[] PrgVariantRevisionDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("prgVariantRevisionData")]
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.PrgVariantRevisionData[] PrgVariantRevisionData
     { 
        get { return this.PrgVariantRevisionDataField;}
        set { this.PrgVariantRevisionDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getPrgVariantRevisionData()
     { 
         if(this.PrgVariantRevisionDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.PrgVariantRevisionDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setPrgVariantRevisionData(System.Collections.ArrayList val)
     { 
       this.PrgVariantRevisionDataField = new T8.Schemas.Tcerpservice._2018_11.Titcerpextension.PrgVariantRevisionData[val.Count];
       val.CopyTo(this.PrgVariantRevisionDataField);
     }



    
    


  } // type
} // ns
            





