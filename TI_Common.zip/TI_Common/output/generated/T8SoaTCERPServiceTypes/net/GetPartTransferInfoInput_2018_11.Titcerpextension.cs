/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Tcerpservice._2018_11.Titcerpextension 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetPartTransferInfoInput 
  {

         private T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetPartTransferInput GetPartTransferInputsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("getPartTransferInputs")]
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetPartTransferInput GetPartTransferInputs
     { 
        get { return this.GetPartTransferInputsField;}
        set { this.GetPartTransferInputsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetPartTransferInput getGetPartTransferInputs()
     { 
       return this.GetPartTransferInputsField;
     }
     public void setGetPartTransferInputs(T8.Schemas.Tcerpservice._2018_11.Titcerpextension.GetPartTransferInput val)
     { 
       this.GetPartTransferInputsField = val;
     }



    
    


  } // type
} // ns
            





