/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Tcerpservice._2018_11.Titcerpextension 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class StandardCostRecord 
  {

         private string CostBucketField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="costBucket")]
     public string CostBucket
     { 
        get { return this.CostBucketField;}
        set { this.CostBucketField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCostBucket()
     { 
       return this.CostBucketField;
     }
     public void setCostBucket(string val)
     { 
       this.CostBucketField = val;
     }


     private string CurrencyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="currency")]
     public string Currency
     { 
        get { return this.CurrencyField;}
        set { this.CurrencyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCurrency()
     { 
       return this.CurrencyField;
     }
     public void setCurrency(string val)
     { 
       this.CurrencyField = val;
     }


     private string CostSetField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="costSet")]
     public string CostSet
     { 
        get { return this.CostSetField;}
        set { this.CostSetField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCostSet()
     { 
       return this.CostSetField;
     }
     public void setCostSet(string val)
     { 
       this.CostSetField = val;
     }


     private string FacilityField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="facility")]
     public string Facility
     { 
        get { return this.FacilityField;}
        set { this.FacilityField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getFacility()
     { 
       return this.FacilityField;
     }
     public void setFacility(string val)
     { 
       this.FacilityField = val;
     }


     private string RecordIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="recordID")]
     public string RecordID
     { 
        get { return this.RecordIDField;}
        set { this.RecordIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getRecordID()
     { 
       return this.RecordIDField;
     }
     public void setRecordID(string val)
     { 
       this.RecordIDField = val;
     }


     private string StockingUOMField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="stockingUOM")]
     public string StockingUOM
     { 
        get { return this.StockingUOMField;}
        set { this.StockingUOMField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getStockingUOM()
     { 
       return this.StockingUOMField;
     }
     public void setStockingUOM(string val)
     { 
       this.StockingUOMField = val;
     }


     private string QuantityField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="quantity")]
     public string Quantity
     { 
        get { return this.QuantityField;}
        set { this.QuantityField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getQuantity()
     { 
       return this.QuantityField;
     }
     public void setQuantity(string val)
     { 
       this.QuantityField = val;
     }


     private string CurrentCostField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="currentCost")]
     public string CurrentCost
     { 
        get { return this.CurrentCostField;}
        set { this.CurrentCostField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCurrentCost()
     { 
       return this.CurrentCostField;
     }
     public void setCurrentCost(string val)
     { 
       this.CurrentCostField = val;
     }



    
    


  } // type
} // ns
            





