/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


#include <unidefs.h>
#if defined(SUN)
#    include <unistd.h>
#endif

#include<TITCERPIntegration1811IiopSkeleton.hxx>


#include <teamcenter/soa/internal/common/PolicyMarshaller.hxx>
#include <teamcenter/soa/internal/server/PolicyManager.hxx>
#include <teamcenter/soa/internal/server/PerServicePropertyPolicy.hxx>
#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace std;
using namespace Teamcenter::Soa::Server;
using namespace Teamcenter::Soa::Internal::Server;
using namespace Teamcenter::Soa::Internal::Common;
using namespace Teamcenter::Soa::Common::Exceptions;


namespace T8
{
    namespace Services
    {
    
        namespace TITCERPService
        {
             namespace _2018_11
             {




    TITCERPIntegrationIiopSkeleton::TITCERPIntegrationIiopSkeleton():
        IiopSkeleton()
    {
        m_serviceName = "TITCERPIntegration";
    
       _svcMap[ "getPartTransferInfo" ]   = getPartTransferInfo;
       _svcMap[ "importContractedCostInfo" ]   = importContractedCostInfo;
       _svcMap[ "importSellingPriceInfo" ]   = importSellingPriceInfo;
       _svcMap[ "importStandardCostInfo" ]   = importStandardCostInfo;

    }
    
    TITCERPIntegrationIiopSkeleton::~TITCERPIntegrationIiopSkeleton()
    {
    	// If the implementing class did not implement the ServicePolicy
    	// then delete it, since it was allocated here in the skeleton
	 	Teamcenter::Soa::Server::ServicePolicy* sp = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(sp == NULL)
    	{
    		delete _servicePolicy;
    	}
        delete _service;
    }



     void TITCERPIntegrationIiopSkeleton::initialize()
    {
   	// If the impl class has not implemented the ServicePolicy interface
    	// Create an instance of the default ServicePolicy
	 	_servicePolicy = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(_servicePolicy == NULL)
    	{
    		_servicePolicy = new Teamcenter::Soa::Server::ServicePolicy;
    	}
    }




    static T8::Soa::TITCERPService::_2018_11::TITCERPIntegrationImpl* _service;
	static Teamcenter::Soa::Server::ServicePolicy*  	 _servicePolicy;


    void TITCERPIntegrationIiopSkeleton::getPartTransferInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::getPartTransferInfo" );

        std::string _contentType;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetPartTransferInput  getPartTransferInputs;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetPartTransferResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::getPartTransferInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getPartTransferInputs", getPartTransferInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationImpl::getPartTransferInfo" );
            _out = _service->getPartTransferInfo( getPartTransferInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::getPartTransferInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }

    void TITCERPIntegrationIiopSkeleton::importContractedCostInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importContractedCostInfo" );

        std::string _contentType;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetContractedCostInput  getContractedCostInputs;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetContractedCostResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importContractedCostInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getContractedCostInputs", getContractedCostInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationImpl::importContractedCostInfo" );
            _out = _service->importContractedCostInfo( getContractedCostInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importContractedCostInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }

    void TITCERPIntegrationIiopSkeleton::importSellingPriceInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importSellingPriceInfo" );

        std::string _contentType;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetSellingPriceInput  getSellingPriceInputs;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetSellingPriceResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importSellingPriceInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getSellingPriceInputs", getSellingPriceInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationImpl::importSellingPriceInfo" );
            _out = _service->importSellingPriceInfo( getSellingPriceInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importSellingPriceInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }

    void TITCERPIntegrationIiopSkeleton::importStandardCostInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importStandardCostInfo" );

        std::string _contentType;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput  getStandardCostInputs;
        T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importStandardCostInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getStandardCostInputs", getStandardCostInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationImpl::importStandardCostInfo" );
            _out = _service->importStandardCostInfo( getStandardCostInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::TITCERPIntegrationIiopSkeleton::importStandardCostInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }




T8::Soa::TITCERPService::_2018_11::TITCERPIntegrationImpl* TITCERPIntegrationIiopSkeleton::_service = new T8::Soa::TITCERPService::_2018_11::TITCERPIntegrationImpl;
Teamcenter::Soa::Server::ServicePolicy*  	  TITCERPIntegrationIiopSkeleton::_servicePolicy = NULL;
static Teamcenter::Soa::Internal::Gateway::T2LService* me_TITCERPIntegration = Teamcenter::Soa::Internal::Gateway::TcServiceManager::instance().registerService( "TITCERPService-2018-11-TITCERPIntegration", new TITCERPIntegrationIiopSkeleton );

 //register the service for getServiceList()
 static std::string registeredServiceOnStartup_TITCERPIntegration = Teamcenter::Soa::Internal::Server::ServiceManager::instance().registerService("TITCERPService-2018-11-TITCERPIntegration");

}}}}    // End Namespace

