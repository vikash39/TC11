/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_TITCERPSERVICE_TITCERPINTEGRATION_HXX 
#define TEAMCENTER_SERVICES_TITCERPSERVICE_TITCERPINTEGRATION_HXX


#include <titcerpintegration1811.hxx>


namespace T8
{
    namespace Soa
    {
        namespace TITCERPService
        {
            class TITCERPIntegration;
        }
    }
}


/**
 * Custom Service for TC and ERP Integration.
 * <br>
 * <br>
 * <b>Dependencies:</b>
 * <br>
 * LOV
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libt8soatitcerpservice.dll
 * </li>
 * </ul>
 */

class T8::Soa::TITCERPService::TITCERPIntegration
    : public T8::Soa::TITCERPService::_2018_11::TITCERPIntegration
{};

#endif

