/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#include <string>
#include <map>

#include <titcerpintegration1811.hxx>


#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace T8::Soa::TITCERPService::_2018_11;

const std::string TITCERPIntegration::XSD_NAMESPACE ="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration";




void TITCERPIntegration::ContractedCostInputData::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "costID", costID );
    _sdmParser->parseStructMember( "itemID", itemID );
    _sdmParser->parseStructMember( "itemRevID", itemRevID );
    _sdmParser->parseStructMember( "bpcsItemID", bpcsItemID );
    _sdmParser->parseStructMember( "itemDesc", itemDesc );
    _sdmParser->parseStructMember( "extraDesc", extraDesc );
    _sdmParser->parseStructMember( "contractedCostRecords", contractedCostRecords );
}

void TITCERPIntegration::ContractedCostRecord::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "vendorNumber", vendorNumber );
    _sdmParser->parseStructMember( "vendorType", vendorType );
    _sdmParser->parseStructMember( "currency", currency );
    _sdmParser->parseStructMember( "toolCost", toolCost );
    _sdmParser->parseStructMember( "toolOwnership", toolOwnership );
    _sdmParser->parseStructMember( "customerPaidTooling", customerPaidTooling );
    _sdmParser->parseStructMember( "toolingCapacityCPV", toolingCapacityCPV );
    _sdmParser->parseStructMember( "toolingCapacityLifeTime", toolingCapacityLifeTime );
    _sdmParser->parseStructMember( "minPrototypeOrderQty", minPrototypeOrderQty );
    _sdmParser->parseStructMember( "minProductionOrderQty", minProductionOrderQty );
    _sdmParser->parseStructMember( "facility", facility );
    _sdmParser->parseStructMember( "exWorkCost", exWorkCost );
    _sdmParser->parseStructMember( "dutyPaidCost", dutyPaidCost );
    _sdmParser->parseStructMember( "costStatus", costStatus );
    _sdmParser->parseStructMember( "comment", comment );
    _sdmParser->parseStructMember( "quoteEffectiveDate", quoteEffectiveDate );
    _sdmParser->parseStructMember( "quoteDiscontinueDate", quoteDiscontinueDate );
}

void TITCERPIntegration::ContractedCostResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "costID", costID );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "bpcsItemID", bpcsItemID );
    _sdmStream->writeStructMember( "importStatus", importStatus );
    _sdmStream->writeStructMember( "reasonForFailure", reasonForFailure );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, true );

}

void TITCERPIntegration::CustomerData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "customerCode", customerCode );
    _sdmStream->writeStructMember( "customerName", customerName );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"customerPartID", customerPartID, true, false,  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::GetContractedCostInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "contractedCostInputData", contractedCostInputData );
}

void TITCERPIntegration::GetContractedCostResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"contractedCostResponse", contractedCostResponse );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::GetPartTransferInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "changeItemID", changeItemID );
    _sdmParser->parseStructMember( "changeItemRevID", changeItemRevID );
    _sdmParser->parseStructMember( "owningSite", owningSite );
}

void TITCERPIntegration::GetPartTransferResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "success", (bool)success );
    _sdmStream->writeStructMember( "changeItemNum", changeItemNum );
    _sdmStream->writeStructMember( "owningSite", owningSite );
    _sdmStream->writeStructMember( "changeType", changeType );
    _sdmStream->writeStructMember( "affectedPlants", affectedPlants );
    _sdmStream->writeStructMember( "jobUID", jobUID );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"productRevisionData", productRevisionData );
    _sdmStream->writeStructMember( _prefix+"errorList", errorList );
    _sdmStream->writeStructMember( _prefix+"materialRevisionData", materialRevisionData );
    _sdmStream->writeStructMember( _prefix+"prgVariantRevisionData", prgVariantRevisionData );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::GetSellingPriceInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "sellingPriceInputData", sellingPriceInputData );
}

void TITCERPIntegration::GetSellingPriceResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"sellingPriceResponse", sellingPriceResponse );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::GetStandardCostInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "standardCostInputData", standardCostInputData );
}

void TITCERPIntegration::GetStandardCostResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"standardCostResponse", standardCostResponse );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::MaterialRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeStructMember( "erpItemClass", erpItemClass );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::PrgVariantRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeStructMember( "erpItemClass", erpItemClass );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::ProductRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "drawingNum", drawingNum );
    _sdmStream->writeStructMember( "drawingNumRev", drawingNumRev );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeStructMember( "erpItemClass", erpItemClass );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName  );
}

void TITCERPIntegration::SellingPriceInputData::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "costID", costID );
    _sdmParser->parseStructMember( "itemID", itemID );
    _sdmParser->parseStructMember( "itemRevID", itemRevID );
    _sdmParser->parseStructMember( "bpcsItemID", bpcsItemID );
    _sdmParser->parseStructMember( "itemDesc", itemDesc );
    _sdmParser->parseStructMember( "extraDesc", extraDesc );
    _sdmParser->parseStructMember( "sellingPriceRecords", sellingPriceRecords );
}

void TITCERPIntegration::SellingPriceRecord::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "plant", plant );
    _sdmParser->parseStructMember( "priceCode", priceCode );
    _sdmParser->parseStructMember( "price", price );
    _sdmParser->parseStructMember( "priceBase", priceBase );
    _sdmParser->parseStructMember( "tiEffectiveDate", tiEffectiveDate );
    _sdmParser->parseStructMember( "poEffectiveDate", poEffectiveDate );
    _sdmParser->parseStructMember( "expirationDate", expirationDate );
    _sdmParser->parseStructMember( "containerCode", containerCode );
    _sdmParser->parseStructMember( "purchaseOrder", purchaseOrder );
    _sdmParser->parseStructMember( "customerCode", customerCode );
    _sdmParser->parseStructMember( "comments", comments );
    _sdmParser->parseStructMember( "currency", currency );
}

void TITCERPIntegration::SellingPriceResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "costID", costID );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "bpcsItemID", bpcsItemID );
    _sdmStream->writeStructMember( "importStatus", importStatus );
    _sdmStream->writeStructMember( "reasonForFailure", reasonForFailure );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, true );

}

void TITCERPIntegration::StandardCostInputData::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "costID", costID );
    _sdmParser->parseStructMember( "itemID", itemID );
    _sdmParser->parseStructMember( "itemRevID", itemRevID );
    _sdmParser->parseStructMember( "bpcsItemID", bpcsItemID );
    _sdmParser->parseStructMember( "itemDesc", itemDesc );
    _sdmParser->parseStructMember( "extraDesc", extraDesc );
    _sdmParser->parseStructMember( "standardCostRecords", standardCostRecords );
}

void TITCERPIntegration::StandardCostRecord::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "recordID", recordID );
    _sdmParser->parseStructMember( "facility", facility );
    _sdmParser->parseStructMember( "costSet", costSet );
    _sdmParser->parseStructMember( "costBucket", costBucket );
    _sdmParser->parseStructMember( "currentCost", currentCost );
    _sdmParser->parseStructMember( "quantity", quantity );
    _sdmParser->parseStructMember( "stockingUOM", stockingUOM );
    _sdmParser->parseStructMember( "currency", currency );
}

void TITCERPIntegration::StandardCostResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "costID", costID );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "bpcsItemID", bpcsItemID );
    _sdmStream->writeStructMember( "importStatus", importStatus );
    _sdmStream->writeStructMember( "reasonForFailure", reasonForFailure );
    _sdmStream->writeOpenElementClose(  T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::XSD_NAMESPACE, true );

}




TITCERPIntegration::TITCERPIntegration()
{
}

TITCERPIntegration::~TITCERPIntegration()
{
}

