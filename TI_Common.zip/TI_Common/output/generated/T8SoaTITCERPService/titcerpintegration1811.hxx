/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_TITCERPSERVICE_2018_11_TITCERPINTEGRATION_HXX 
#define TEAMCENTER_SERVICES_TITCERPSERVICE_2018_11_TITCERPINTEGRATION_HXX





#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <TITCERPService_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}
namespace T8 { namespace Services { namespace TITCERPService { namespace _2018_11 { class TITCERPIntegrationIiopSkeleton; }}}}


namespace T8
{
    namespace Soa
    {
        namespace TITCERPService
        {
            namespace _2018_11
            {
                class TITCERPIntegration;
            }
        }
    }
}


class SOATITCERPSERVICE_API T8::Soa::TITCERPService::_2018_11::TITCERPIntegration

{
public:

    static const std::string XSD_NAMESPACE;

    struct ContractedCostInputData;
    struct ContractedCostRecord;
    struct ContractedCostResponse;
    struct CustomerData;
    struct GetContractedCostInput;
    struct GetContractedCostResponse;
    struct GetPartTransferInput;
    struct GetPartTransferResponse;
    struct GetSellingPriceInput;
    struct GetSellingPriceResponse;
    struct GetStandardCostInput;
    struct GetStandardCostResponse;
    struct MaterialRevisionData;
    struct PrgVariantRevisionData;
    struct ProductRevisionData;
    struct SellingPriceInputData;
    struct SellingPriceRecord;
    struct SellingPriceResponse;
    struct StandardCostInputData;
    struct StandardCostRecord;
    struct StandardCostResponse;

    typedef std::map< std::string, std::vector< std::string > > CustomerPartIDMap;

    typedef std::map< std::string, std::vector< std::string > > ERPPartNumbersMap;

    struct  ContractedCostInputData
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * itemDesc
         */
        std::string itemDesc;
        /**
         * extraDesc
         */
        std::string extraDesc;
        /**
         * contractedCostRecords
         */
        std::vector< ContractedCostRecord > contractedCostRecords;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  ContractedCostRecord
    {
        /**
         * vendorNumber
         */
        std::string vendorNumber;
        /**
         * vendorType
         */
        std::string vendorType;
        /**
         * currency
         */
        std::string currency;
        /**
         * toolCost
         */
        std::string toolCost;
        /**
         * toolOwnership
         */
        std::string toolOwnership;
        /**
         * customerPaidTooling
         */
        std::string customerPaidTooling;
        /**
         * toolingCapacityCPV
         */
        std::string toolingCapacityCPV;
        /**
         * toolingCapacityLifeTime
         */
        std::string toolingCapacityLifeTime;
        /**
         * minPrototypeOrderQty
         */
        std::string minPrototypeOrderQty;
        /**
         * minProductionOrderQty
         */
        std::string minProductionOrderQty;
        /**
         * facility
         */
        std::string facility;
        /**
         * exWorkCost
         */
        std::string exWorkCost;
        /**
         * dutyPaidCost
         */
        std::string dutyPaidCost;
        /**
         * costStatus
         */
        std::string costStatus;
        /**
         * comment
         */
        std::string comment;
        /**
         * quoteEffectiveDate
         */
        std::string quoteEffectiveDate;
        /**
         * quoteDiscontinueDate
         */
        std::string quoteDiscontinueDate;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  ContractedCostResponse
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * importStatus
         */
        std::string importStatus;
        /**
         * reasonForFailure
         */
        std::string reasonForFailure;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="ContractedCostResponse" );
    };

    struct  CustomerData
    {
        /**
         * sCustomerCode
         */
        std::string customerCode;
        /**
         * sCustomerName
         */
        std::string customerName;
        /**
         * mCustomerPartID
         */
        CustomerPartIDMap customerPartID;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="CustomerData" );
    };

    struct  GetContractedCostInput
    {
        /**
         * contractedCostInputData
         */
        std::vector< ContractedCostInputData > contractedCostInputData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetContractedCostResponse
    {
        /**
         * contractedCostResponse
         */
        std::vector< ContractedCostResponse > contractedCostResponse;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetContractedCostResponse" );
    };

    struct  GetPartTransferInput
    {
        /**
         * TI Change Item ID
         */
        std::string changeItemID;
        /**
         * TI Change Revision ID
         */
        std::string changeItemRevID;
        /**
         * owningSite
         */
        std::string owningSite;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetPartTransferResponse
    {
        /**
         * vProductRevisionData
         */
        std::vector< ProductRevisionData > productRevisionData;
        /**
         * sErrorList
         */
        std::vector< std::string > errorList;
        /**
         * bIsSuccess
         */
        bool success;
        /**
         * sChangeItemNum
         */
        std::string changeItemNum;
        /**
         * sOwningSite
         */
        std::string owningSite;
        /**
         * sChangeType
         */
        std::string changeType;
        /**
         * sAffectedPlants
         */
        std::string affectedPlants;
        /**
         * sJobUID
         */
        std::string jobUID;
        /**
         * materialRevisionData
         */
        std::vector< MaterialRevisionData > materialRevisionData;
        /**
         * prgVariantRevisionData
         */
        std::vector< PrgVariantRevisionData > prgVariantRevisionData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetPartTransferResponse" );
    };

    struct  GetSellingPriceInput
    {
        /**
         * SellingPriceInputData
         */
        std::vector< SellingPriceInputData > sellingPriceInputData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetSellingPriceResponse
    {
        /**
         * SellingPriceResponse
         */
        std::vector< SellingPriceResponse > sellingPriceResponse;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetSellingPriceResponse" );
    };

    struct  GetStandardCostInput
    {
        /**
         * standardCostInputData
         */
        std::vector< StandardCostInputData > standardCostInputData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetStandardCostResponse
    {
        /**
         * standardCostResponse
         */
        std::vector< StandardCostResponse > standardCostResponse;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetStandardCostResponse" );
    };

    struct  MaterialRevisionData
    {
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * itemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * itemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * bpcsFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * bpcsSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeOrBuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * newBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * erpPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * customerData
         */
        std::vector< CustomerData > customerData;
        /**
         * erpItemClass
         */
        std::string erpItemClass;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="MaterialRevisionData" );
    };

    struct  PrgVariantRevisionData
    {
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * itemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * itemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * bpcsFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * bpcsSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeOrBuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * newBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * erpPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * customerData
         */
        std::vector< CustomerData > customerData;
        /**
         * erpItemClass
         */
        std::string erpItemClass;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="PrgVariantRevisionData" );
    };

    struct  ProductRevisionData
    {
        /**
         * Item ID
         */
        std::string itemID;
        /**
         * Item Rev ID
         */
        std::string itemRevID;
        /**
         * strItemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * ItemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * drawingNumber
         */
        std::string drawingNum;
        /**
         * drawingNumRev
         */
        std::string drawingNumRev;
        /**
         * bPCSFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * BPCSSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeorbuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * isNewBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * mERPPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * vCustomerData
         */
        std::vector< CustomerData > customerData;
        /**
         * erpItemClass
         */
        std::string erpItemClass;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="ProductRevisionData" );
    };

    struct  SellingPriceInputData
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * itemDesc
         */
        std::string itemDesc;
        /**
         * extraDesc
         */
        std::string extraDesc;
        /**
         * SellingPriceRecords
         */
        std::vector< SellingPriceRecord > sellingPriceRecords;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  SellingPriceRecord
    {
        /**
         * plant
         */
        std::string plant;
        /**
         * priceCode
         */
        std::string priceCode;
        /**
         * price
         */
        std::string price;
        /**
         * priceBase
         */
        std::string priceBase;
        /**
         * tiEffectiveDate
         */
        std::string tiEffectiveDate;
        /**
         * poEffectiveDate
         */
        std::string poEffectiveDate;
        /**
         * expirationDate
         */
        std::string expirationDate;
        /**
         * containerCode
         */
        std::string containerCode;
        /**
         * purchaseOrder
         */
        std::string purchaseOrder;
        /**
         * customerCode
         */
        std::string customerCode;
        /**
         * comments
         */
        std::string comments;
        /**
         * currency
         */
        std::string currency;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  SellingPriceResponse
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * importStatus
         */
        std::string importStatus;
        /**
         * reasonForFailure
         */
        std::string reasonForFailure;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="SellingPriceResponse" );
    };

    struct  StandardCostInputData
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * itemDesc
         */
        std::string itemDesc;
        /**
         * extraDesc
         */
        std::string extraDesc;
        /**
         * standardCostRecords
         */
        std::vector< StandardCostRecord > standardCostRecords;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  StandardCostRecord
    {
        /**
         * recordID
         */
        std::string recordID;
        /**
         * facility
         */
        std::string facility;
        /**
         * costSet
         */
        std::string costSet;
        /**
         * costBucket
         */
        std::string costBucket;
        /**
         * currentCost
         */
        std::string currentCost;
        /**
         * quantity
         */
        std::string quantity;
        /**
         * stockingUOM
         */
        std::string stockingUOM;
        /**
         * currency
         */
        std::string currency;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  StandardCostResponse
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * importStatus
         */
        std::string importStatus;
        /**
         * reasonForFailure
         */
        std::string reasonForFailure;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TITCERPService::_2018_11::TITCERPIntegrationIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="StandardCostResponse" );
    };



    TITCERPIntegration();
    virtual ~TITCERPIntegration();
    

    /**
     * .
     *
     * @param getPartTransferInputs
     *        getPartTransferInputs
     *
     * @return
     *
     */
    virtual GetPartTransferResponse getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs ) = 0;

    /**
     * .
     *
     * @param getContractedCostInputs
     *        getContractedCostInputs
     *
     * @return
     *
     */
    virtual GetContractedCostResponse importContractedCostInfo ( const GetContractedCostInput& getContractedCostInputs ) = 0;

    /**
     * .
     *
     * @param getSellingPriceInputs
     *        getSellingPriceInputs
     *
     * @return
     *
     */
    virtual GetSellingPriceResponse importSellingPriceInfo ( const GetSellingPriceInput& getSellingPriceInputs ) = 0;

    /**
     * .
     *
     * @param getStandardCostInputs
     *        getStandardCostInputs
     *
     * @return
     *
     */
    virtual GetStandardCostResponse importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs ) = 0;


};

#include <TITCERPService_undef.h>
#endif

