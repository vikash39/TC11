/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class ContractedCostRecord 
  {

         private string QuoteEffectiveDateField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="quoteEffectiveDate")]
     public string QuoteEffectiveDate
     { 
        get { return this.QuoteEffectiveDateField;}
        set { this.QuoteEffectiveDateField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getQuoteEffectiveDate()
     { 
       return this.QuoteEffectiveDateField;
     }
     public void setQuoteEffectiveDate(string val)
     { 
       this.QuoteEffectiveDateField = val;
     }


     private string ExWorkCostField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="exWorkCost")]
     public string ExWorkCost
     { 
        get { return this.ExWorkCostField;}
        set { this.ExWorkCostField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getExWorkCost()
     { 
       return this.ExWorkCostField;
     }
     public void setExWorkCost(string val)
     { 
       this.ExWorkCostField = val;
     }


     private string DutyPaidCostField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="dutyPaidCost")]
     public string DutyPaidCost
     { 
        get { return this.DutyPaidCostField;}
        set { this.DutyPaidCostField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getDutyPaidCost()
     { 
       return this.DutyPaidCostField;
     }
     public void setDutyPaidCost(string val)
     { 
       this.DutyPaidCostField = val;
     }


     private string CostStatusField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="costStatus")]
     public string CostStatus
     { 
        get { return this.CostStatusField;}
        set { this.CostStatusField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCostStatus()
     { 
       return this.CostStatusField;
     }
     public void setCostStatus(string val)
     { 
       this.CostStatusField = val;
     }


     private string CommentField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="comment")]
     public string Comment
     { 
        get { return this.CommentField;}
        set { this.CommentField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getComment()
     { 
       return this.CommentField;
     }
     public void setComment(string val)
     { 
       this.CommentField = val;
     }


     private string ToolingCapacityCPVField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="toolingCapacityCPV")]
     public string ToolingCapacityCPV
     { 
        get { return this.ToolingCapacityCPVField;}
        set { this.ToolingCapacityCPVField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getToolingCapacityCPV()
     { 
       return this.ToolingCapacityCPVField;
     }
     public void setToolingCapacityCPV(string val)
     { 
       this.ToolingCapacityCPVField = val;
     }


     private string CustomerPaidToolingField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="customerPaidTooling")]
     public string CustomerPaidTooling
     { 
        get { return this.CustomerPaidToolingField;}
        set { this.CustomerPaidToolingField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCustomerPaidTooling()
     { 
       return this.CustomerPaidToolingField;
     }
     public void setCustomerPaidTooling(string val)
     { 
       this.CustomerPaidToolingField = val;
     }


     private string ToolingCapacityLifeTimeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="toolingCapacityLifeTime")]
     public string ToolingCapacityLifeTime
     { 
        get { return this.ToolingCapacityLifeTimeField;}
        set { this.ToolingCapacityLifeTimeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getToolingCapacityLifeTime()
     { 
       return this.ToolingCapacityLifeTimeField;
     }
     public void setToolingCapacityLifeTime(string val)
     { 
       this.ToolingCapacityLifeTimeField = val;
     }


     private string FacilityField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="facility")]
     public string Facility
     { 
        get { return this.FacilityField;}
        set { this.FacilityField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getFacility()
     { 
       return this.FacilityField;
     }
     public void setFacility(string val)
     { 
       this.FacilityField = val;
     }


     private string MinPrototypeOrderQtyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="minPrototypeOrderQty")]
     public string MinPrototypeOrderQty
     { 
        get { return this.MinPrototypeOrderQtyField;}
        set { this.MinPrototypeOrderQtyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getMinPrototypeOrderQty()
     { 
       return this.MinPrototypeOrderQtyField;
     }
     public void setMinPrototypeOrderQty(string val)
     { 
       this.MinPrototypeOrderQtyField = val;
     }


     private string ToolCostField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="toolCost")]
     public string ToolCost
     { 
        get { return this.ToolCostField;}
        set { this.ToolCostField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getToolCost()
     { 
       return this.ToolCostField;
     }
     public void setToolCost(string val)
     { 
       this.ToolCostField = val;
     }


     private string QuoteDiscontinueDateField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="quoteDiscontinueDate")]
     public string QuoteDiscontinueDate
     { 
        get { return this.QuoteDiscontinueDateField;}
        set { this.QuoteDiscontinueDateField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getQuoteDiscontinueDate()
     { 
       return this.QuoteDiscontinueDateField;
     }
     public void setQuoteDiscontinueDate(string val)
     { 
       this.QuoteDiscontinueDateField = val;
     }


     private string CurrencyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="currency")]
     public string Currency
     { 
        get { return this.CurrencyField;}
        set { this.CurrencyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCurrency()
     { 
       return this.CurrencyField;
     }
     public void setCurrency(string val)
     { 
       this.CurrencyField = val;
     }


     private string MinProductionOrderQtyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="minProductionOrderQty")]
     public string MinProductionOrderQty
     { 
        get { return this.MinProductionOrderQtyField;}
        set { this.MinProductionOrderQtyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getMinProductionOrderQty()
     { 
       return this.MinProductionOrderQtyField;
     }
     public void setMinProductionOrderQty(string val)
     { 
       this.MinProductionOrderQtyField = val;
     }


     private string ToolOwnershipField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="toolOwnership")]
     public string ToolOwnership
     { 
        get { return this.ToolOwnershipField;}
        set { this.ToolOwnershipField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getToolOwnership()
     { 
       return this.ToolOwnershipField;
     }
     public void setToolOwnership(string val)
     { 
       this.ToolOwnershipField = val;
     }


     private string VendorNumberField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="vendorNumber")]
     public string VendorNumber
     { 
        get { return this.VendorNumberField;}
        set { this.VendorNumberField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getVendorNumber()
     { 
       return this.VendorNumberField;
     }
     public void setVendorNumber(string val)
     { 
       this.VendorNumberField = val;
     }


     private string VendorTypeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="vendorType")]
     public string VendorType
     { 
        get { return this.VendorTypeField;}
        set { this.VendorTypeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getVendorType()
     { 
       return this.VendorTypeField;
     }
     public void setVendorType(string val)
     { 
       this.VendorTypeField = val;
     }



    
    


  } // type
} // ns
            





