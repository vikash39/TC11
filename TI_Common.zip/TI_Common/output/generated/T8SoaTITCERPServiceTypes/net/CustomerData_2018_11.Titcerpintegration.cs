/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class CustomerData 
  {

         private string CustomerNameField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="customerName")]
     public string CustomerName
     { 
        get { return this.CustomerNameField;}
        set { this.CustomerNameField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCustomerName()
     { 
       return this.CustomerNameField;
     }
     public void setCustomerName(string val)
     { 
       this.CustomerNameField = val;
     }


     private string CustomerCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="customerCode")]
     public string CustomerCode
     { 
        get { return this.CustomerCodeField;}
        set { this.CustomerCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCustomerCode()
     { 
       return this.CustomerCodeField;
     }
     public void setCustomerCode(string val)
     { 
       this.CustomerCodeField = val;
     }


     private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerPartIDMap[] CustomerPartIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("customerPartID")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerPartIDMap[] CustomerPartID
     { 
        get { return this.CustomerPartIDField;}
        set { this.CustomerPartIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getCustomerPartID()
     { 
         if(this.CustomerPartIDField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.CustomerPartIDField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setCustomerPartID(System.Collections.ArrayList val)
     { 
       this.CustomerPartIDField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerPartIDMap[val.Count];
       val.CopyTo(this.CustomerPartIDField);
     }



    
    


  } // type
} // ns
            





