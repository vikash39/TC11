/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetContractedCostInput 
  {

         private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostInputData[] ContractedCostInputDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("contractedCostInputData")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostInputData[] ContractedCostInputData
     { 
        get { return this.ContractedCostInputDataField;}
        set { this.ContractedCostInputDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getContractedCostInputData()
     { 
         if(this.ContractedCostInputDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ContractedCostInputDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setContractedCostInputData(System.Collections.ArrayList val)
     { 
       this.ContractedCostInputDataField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostInputData[val.Count];
       val.CopyTo(this.ContractedCostInputDataField);
     }



    
    


  } // type
} // ns
            





