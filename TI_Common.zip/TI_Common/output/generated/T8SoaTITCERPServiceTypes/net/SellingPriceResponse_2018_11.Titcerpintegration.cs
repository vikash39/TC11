/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class SellingPriceResponse 
  {

         private string BpcsItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="bpcsItemID")]
     public string BpcsItemID
     { 
        get { return this.BpcsItemIDField;}
        set { this.BpcsItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getBpcsItemID()
     { 
       return this.BpcsItemIDField;
     }
     public void setBpcsItemID(string val)
     { 
       this.BpcsItemIDField = val;
     }


     private string ReasonForFailureField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="reasonForFailure")]
     public string ReasonForFailure
     { 
        get { return this.ReasonForFailureField;}
        set { this.ReasonForFailureField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getReasonForFailure()
     { 
       return this.ReasonForFailureField;
     }
     public void setReasonForFailure(string val)
     { 
       this.ReasonForFailureField = val;
     }


     private string CostIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="costID")]
     public string CostID
     { 
        get { return this.CostIDField;}
        set { this.CostIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCostID()
     { 
       return this.CostIDField;
     }
     public void setCostID(string val)
     { 
       this.CostIDField = val;
     }


     private string ImportStatusField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="importStatus")]
     public string ImportStatus
     { 
        get { return this.ImportStatusField;}
        set { this.ImportStatusField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getImportStatus()
     { 
       return this.ImportStatusField;
     }
     public void setImportStatus(string val)
     { 
       this.ImportStatusField = val;
     }


     private string ItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemID")]
     public string ItemID
     { 
        get { return this.ItemIDField;}
        set { this.ItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemID()
     { 
       return this.ItemIDField;
     }
     public void setItemID(string val)
     { 
       this.ItemIDField = val;
     }


     private string ItemRevIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemRevID")]
     public string ItemRevID
     { 
        get { return this.ItemRevIDField;}
        set { this.ItemRevIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemRevID()
     { 
       return this.ItemRevIDField;
     }
     public void setItemRevID(string val)
     { 
       this.ItemRevIDField = val;
     }



    
    


  } // type
} // ns
            





