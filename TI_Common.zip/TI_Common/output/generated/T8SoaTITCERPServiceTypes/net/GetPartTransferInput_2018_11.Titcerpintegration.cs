/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetPartTransferInput 
  {

         private string ChangeItemRevIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="changeItemRevID")]
     public string ChangeItemRevID
     { 
        get { return this.ChangeItemRevIDField;}
        set { this.ChangeItemRevIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getChangeItemRevID()
     { 
       return this.ChangeItemRevIDField;
     }
     public void setChangeItemRevID(string val)
     { 
       this.ChangeItemRevIDField = val;
     }


     private string OwningSiteField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="owningSite")]
     public string OwningSite
     { 
        get { return this.OwningSiteField;}
        set { this.OwningSiteField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getOwningSite()
     { 
       return this.OwningSiteField;
     }
     public void setOwningSite(string val)
     { 
       this.OwningSiteField = val;
     }


     private string ChangeItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="changeItemID")]
     public string ChangeItemID
     { 
        get { return this.ChangeItemIDField;}
        set { this.ChangeItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getChangeItemID()
     { 
       return this.ChangeItemIDField;
     }
     public void setChangeItemID(string val)
     { 
       this.ChangeItemIDField = val;
     }



    
    


  } // type
} // ns
            





