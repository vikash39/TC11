/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetPartTransferInfoInput 
  {

         private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.GetPartTransferInput GetPartTransferInputsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("getPartTransferInputs")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.GetPartTransferInput GetPartTransferInputs
     { 
        get { return this.GetPartTransferInputsField;}
        set { this.GetPartTransferInputsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.GetPartTransferInput getGetPartTransferInputs()
     { 
       return this.GetPartTransferInputsField;
     }
     public void setGetPartTransferInputs(T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.GetPartTransferInput val)
     { 
       this.GetPartTransferInputsField = val;
     }



    
    


  } // type
} // ns
            





