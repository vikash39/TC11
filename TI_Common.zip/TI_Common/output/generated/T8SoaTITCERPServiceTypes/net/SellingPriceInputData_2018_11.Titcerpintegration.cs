/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class SellingPriceInputData 
  {

         private string BpcsItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="bpcsItemID")]
     public string BpcsItemID
     { 
        get { return this.BpcsItemIDField;}
        set { this.BpcsItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getBpcsItemID()
     { 
       return this.BpcsItemIDField;
     }
     public void setBpcsItemID(string val)
     { 
       this.BpcsItemIDField = val;
     }


     private string ItemDescField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemDesc")]
     public string ItemDesc
     { 
        get { return this.ItemDescField;}
        set { this.ItemDescField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemDesc()
     { 
       return this.ItemDescField;
     }
     public void setItemDesc(string val)
     { 
       this.ItemDescField = val;
     }


     private string CostIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="costID")]
     public string CostID
     { 
        get { return this.CostIDField;}
        set { this.CostIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCostID()
     { 
       return this.CostIDField;
     }
     public void setCostID(string val)
     { 
       this.CostIDField = val;
     }


     private string ExtraDescField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="extraDesc")]
     public string ExtraDesc
     { 
        get { return this.ExtraDescField;}
        set { this.ExtraDescField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getExtraDesc()
     { 
       return this.ExtraDescField;
     }
     public void setExtraDesc(string val)
     { 
       this.ExtraDescField = val;
     }


     private string ItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemID")]
     public string ItemID
     { 
        get { return this.ItemIDField;}
        set { this.ItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemID()
     { 
       return this.ItemIDField;
     }
     public void setItemID(string val)
     { 
       this.ItemIDField = val;
     }


     private string ItemRevIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemRevID")]
     public string ItemRevID
     { 
        get { return this.ItemRevIDField;}
        set { this.ItemRevIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemRevID()
     { 
       return this.ItemRevIDField;
     }
     public void setItemRevID(string val)
     { 
       this.ItemRevIDField = val;
     }


     private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.SellingPriceRecord[] SellingPriceRecordsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("sellingPriceRecords")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.SellingPriceRecord[] SellingPriceRecords
     { 
        get { return this.SellingPriceRecordsField;}
        set { this.SellingPriceRecordsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getSellingPriceRecords()
     { 
         if(this.SellingPriceRecordsField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.SellingPriceRecordsField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setSellingPriceRecords(System.Collections.ArrayList val)
     { 
       this.SellingPriceRecordsField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.SellingPriceRecord[val.Count];
       val.CopyTo(this.SellingPriceRecordsField);
     }



    
    


  } // type
} // ns
            





