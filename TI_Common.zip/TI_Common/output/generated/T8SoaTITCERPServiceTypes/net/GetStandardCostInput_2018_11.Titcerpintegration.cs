/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetStandardCostInput 
  {

         private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostInputData[] StandardCostInputDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("standardCostInputData")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostInputData[] StandardCostInputData
     { 
        get { return this.StandardCostInputDataField;}
        set { this.StandardCostInputDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getStandardCostInputData()
     { 
         if(this.StandardCostInputDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.StandardCostInputDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setStandardCostInputData(System.Collections.ArrayList val)
     { 
       this.StandardCostInputDataField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostInputData[val.Count];
       val.CopyTo(this.StandardCostInputDataField);
     }



    
    


  } // type
} // ns
            





