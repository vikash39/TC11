/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class ProductRevisionData 
  {

         private string PartWeightField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="partWeight")]
     public string PartWeight
     { 
        get { return this.PartWeightField;}
        set { this.PartWeightField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPartWeight()
     { 
       return this.PartWeightField;
     }
     public void setPartWeight(string val)
     { 
       this.PartWeightField = val;
     }


     private string DrawingNumRevField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="drawingNumRev")]
     public string DrawingNumRev
     { 
        get { return this.DrawingNumRevField;}
        set { this.DrawingNumRevField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getDrawingNumRev()
     { 
       return this.DrawingNumRevField;
     }
     public void setDrawingNumRev(string val)
     { 
       this.DrawingNumRevField = val;
     }


     private string UomField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="uom")]
     public string Uom
     { 
        get { return this.UomField;}
        set { this.UomField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getUom()
     { 
       return this.UomField;
     }
     public void setUom(string val)
     { 
       this.UomField = val;
     }


     private string ItemIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemID")]
     public string ItemID
     { 
        get { return this.ItemIDField;}
        set { this.ItemIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemID()
     { 
       return this.ItemIDField;
     }
     public void setItemID(string val)
     { 
       this.ItemIDField = val;
     }


     private string NewBPCSItemNeededField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="newBPCSItemNeeded")]
     public string NewBPCSItemNeeded
     { 
        get { return this.NewBPCSItemNeededField;}
        set { this.NewBPCSItemNeededField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getNewBPCSItemNeeded()
     { 
       return this.NewBPCSItemNeededField;
     }
     public void setNewBPCSItemNeeded(string val)
     { 
       this.NewBPCSItemNeededField = val;
     }


     private string ReleaseLevelField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="releaseLevel")]
     public string ReleaseLevel
     { 
        get { return this.ReleaseLevelField;}
        set { this.ReleaseLevelField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getReleaseLevel()
     { 
       return this.ReleaseLevelField;
     }
     public void setReleaseLevel(string val)
     { 
       this.ReleaseLevelField = val;
     }


     private string MakeOrBuyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="makeOrBuy")]
     public string MakeOrBuy
     { 
        get { return this.MakeOrBuyField;}
        set { this.MakeOrBuyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getMakeOrBuy()
     { 
       return this.MakeOrBuyField;
     }
     public void setMakeOrBuy(string val)
     { 
       this.MakeOrBuyField = val;
     }


     private string ItemRevIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemRevID")]
     public string ItemRevID
     { 
        get { return this.ItemRevIDField;}
        set { this.ItemRevIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemRevID()
     { 
       return this.ItemRevIDField;
     }
     public void setItemRevID(string val)
     { 
       this.ItemRevIDField = val;
     }


     private string SpendTypeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="spendType")]
     public string SpendType
     { 
        get { return this.SpendTypeField;}
        set { this.SpendTypeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getSpendType()
     { 
       return this.SpendTypeField;
     }
     public void setSpendType(string val)
     { 
       this.SpendTypeField = val;
     }


     private string BpcsSubFamilyCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="bpcsSubFamilyCode")]
     public string BpcsSubFamilyCode
     { 
        get { return this.BpcsSubFamilyCodeField;}
        set { this.BpcsSubFamilyCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getBpcsSubFamilyCode()
     { 
       return this.BpcsSubFamilyCodeField;
     }
     public void setBpcsSubFamilyCode(string val)
     { 
       this.BpcsSubFamilyCodeField = val;
     }


     private string ErpItemClassField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="erpItemClass")]
     public string ErpItemClass
     { 
        get { return this.ErpItemClassField;}
        set { this.ErpItemClassField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getErpItemClass()
     { 
       return this.ErpItemClassField;
     }
     public void setErpItemClass(string val)
     { 
       this.ErpItemClassField = val;
     }


     private string DesignLevelField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="designLevel")]
     public string DesignLevel
     { 
        get { return this.DesignLevelField;}
        set { this.DesignLevelField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getDesignLevel()
     { 
       return this.DesignLevelField;
     }
     public void setDesignLevel(string val)
     { 
       this.DesignLevelField = val;
     }


     private string ItemRevDescriptionField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemRevDescription")]
     public string ItemRevDescription
     { 
        get { return this.ItemRevDescriptionField;}
        set { this.ItemRevDescriptionField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemRevDescription()
     { 
       return this.ItemRevDescriptionField;
     }
     public void setItemRevDescription(string val)
     { 
       this.ItemRevDescriptionField = val;
     }


     private string ItemRevUIDField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemRevUID")]
     public string ItemRevUID
     { 
        get { return this.ItemRevUIDField;}
        set { this.ItemRevUIDField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemRevUID()
     { 
       return this.ItemRevUIDField;
     }
     public void setItemRevUID(string val)
     { 
       this.ItemRevUIDField = val;
     }


     private string DrawingNumField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="drawingNum")]
     public string DrawingNum
     { 
        get { return this.DrawingNumField;}
        set { this.DrawingNumField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getDrawingNum()
     { 
       return this.DrawingNumField;
     }
     public void setDrawingNum(string val)
     { 
       this.DrawingNumField = val;
     }


     private string BpcsFamilyCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="bpcsFamilyCode")]
     public string BpcsFamilyCode
     { 
        get { return this.BpcsFamilyCodeField;}
        set { this.BpcsFamilyCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getBpcsFamilyCode()
     { 
       return this.BpcsFamilyCodeField;
     }
     public void setBpcsFamilyCode(string val)
     { 
       this.BpcsFamilyCodeField = val;
     }


     private string ItemNameField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="itemName")]
     public string ItemName
     { 
        get { return this.ItemNameField;}
        set { this.ItemNameField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getItemName()
     { 
       return this.ItemNameField;
     }
     public void setItemName(string val)
     { 
       this.ItemNameField = val;
     }


     private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ERPPartNumbersMap[] ErpPartNumbersField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("erpPartNumbers")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ERPPartNumbersMap[] ErpPartNumbers
     { 
        get { return this.ErpPartNumbersField;}
        set { this.ErpPartNumbersField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getErpPartNumbers()
     { 
         if(this.ErpPartNumbersField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ErpPartNumbersField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setErpPartNumbers(System.Collections.ArrayList val)
     { 
       this.ErpPartNumbersField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ERPPartNumbersMap[val.Count];
       val.CopyTo(this.ErpPartNumbersField);
     }


     private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerData[] CustomerDataField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("customerData")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerData[] CustomerData
     { 
        get { return this.CustomerDataField;}
        set { this.CustomerDataField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getCustomerData()
     { 
         if(this.CustomerDataField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.CustomerDataField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setCustomerData(System.Collections.ArrayList val)
     { 
       this.CustomerDataField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.CustomerData[val.Count];
       val.CopyTo(this.CustomerDataField);
     }



    
    


  } // type
} // ns
            





