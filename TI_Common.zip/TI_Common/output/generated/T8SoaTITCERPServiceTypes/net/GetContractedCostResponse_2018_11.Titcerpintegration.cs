/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetContractedCostResponse 
  {

         private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostResponse[] ContractedCostResponseField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("contractedCostResponse")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostResponse[] ContractedCostResponse
     { 
        get { return this.ContractedCostResponseField;}
        set { this.ContractedCostResponseField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getContractedCostResponse()
     { 
         if(this.ContractedCostResponseField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.ContractedCostResponseField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setContractedCostResponse(System.Collections.ArrayList val)
     { 
       this.ContractedCostResponseField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.ContractedCostResponse[val.Count];
       val.CopyTo(this.ContractedCostResponseField);
     }



    
    


  } // type
} // ns
            





