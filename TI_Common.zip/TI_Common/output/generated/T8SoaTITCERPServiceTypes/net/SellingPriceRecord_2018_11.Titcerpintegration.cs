/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class SellingPriceRecord 
  {

         private string PriceBaseField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="priceBase")]
     public string PriceBase
     { 
        get { return this.PriceBaseField;}
        set { this.PriceBaseField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPriceBase()
     { 
       return this.PriceBaseField;
     }
     public void setPriceBase(string val)
     { 
       this.PriceBaseField = val;
     }


     private string PriceCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="priceCode")]
     public string PriceCode
     { 
        get { return this.PriceCodeField;}
        set { this.PriceCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPriceCode()
     { 
       return this.PriceCodeField;
     }
     public void setPriceCode(string val)
     { 
       this.PriceCodeField = val;
     }


     private string ContainerCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="containerCode")]
     public string ContainerCode
     { 
        get { return this.ContainerCodeField;}
        set { this.ContainerCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getContainerCode()
     { 
       return this.ContainerCodeField;
     }
     public void setContainerCode(string val)
     { 
       this.ContainerCodeField = val;
     }


     private string CustomerCodeField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="customerCode")]
     public string CustomerCode
     { 
        get { return this.CustomerCodeField;}
        set { this.CustomerCodeField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCustomerCode()
     { 
       return this.CustomerCodeField;
     }
     public void setCustomerCode(string val)
     { 
       this.CustomerCodeField = val;
     }


     private string PriceField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="price")]
     public string Price
     { 
        get { return this.PriceField;}
        set { this.PriceField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPrice()
     { 
       return this.PriceField;
     }
     public void setPrice(string val)
     { 
       this.PriceField = val;
     }


     private string CommentsField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="comments")]
     public string Comments
     { 
        get { return this.CommentsField;}
        set { this.CommentsField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getComments()
     { 
       return this.CommentsField;
     }
     public void setComments(string val)
     { 
       this.CommentsField = val;
     }


     private string ExpirationDateField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="expirationDate")]
     public string ExpirationDate
     { 
        get { return this.ExpirationDateField;}
        set { this.ExpirationDateField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getExpirationDate()
     { 
       return this.ExpirationDateField;
     }
     public void setExpirationDate(string val)
     { 
       this.ExpirationDateField = val;
     }


     private string CurrencyField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="currency")]
     public string Currency
     { 
        get { return this.CurrencyField;}
        set { this.CurrencyField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getCurrency()
     { 
       return this.CurrencyField;
     }
     public void setCurrency(string val)
     { 
       this.CurrencyField = val;
     }


     private string PoEffectiveDateField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="poEffectiveDate")]
     public string PoEffectiveDate
     { 
        get { return this.PoEffectiveDateField;}
        set { this.PoEffectiveDateField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPoEffectiveDate()
     { 
       return this.PoEffectiveDateField;
     }
     public void setPoEffectiveDate(string val)
     { 
       this.PoEffectiveDateField = val;
     }


     private string TiEffectiveDateField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="tiEffectiveDate")]
     public string TiEffectiveDate
     { 
        get { return this.TiEffectiveDateField;}
        set { this.TiEffectiveDateField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getTiEffectiveDate()
     { 
       return this.TiEffectiveDateField;
     }
     public void setTiEffectiveDate(string val)
     { 
       this.TiEffectiveDateField = val;
     }


     private string PlantField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="plant")]
     public string Plant
     { 
        get { return this.PlantField;}
        set { this.PlantField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPlant()
     { 
       return this.PlantField;
     }
     public void setPlant(string val)
     { 
       this.PlantField = val;
     }


     private string PurchaseOrderField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlAttributeAttribute(AttributeName="purchaseOrder")]
     public string PurchaseOrder
     { 
        get { return this.PurchaseOrderField;}
        set { this.PurchaseOrderField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public string getPurchaseOrder()
     { 
       return this.PurchaseOrderField;
     }
     public void setPurchaseOrder(string val)
     { 
       this.PurchaseOrderField = val;
     }



    
    


  } // type
} // ns
            





