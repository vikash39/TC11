/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace T8.Schemas.Titcerpservice._2018_11.Titcerpintegration 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://t8.com/Schemas/TITCERPService/2018-11/TITCERPIntegration", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetStandardCostResponse 
  {

         private T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostResponse[] StandardCostResponseField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("standardCostResponse")]
     public T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostResponse[] StandardCostResponse
     { 
        get { return this.StandardCostResponseField;}
        set { this.StandardCostResponseField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getStandardCostResponse()
     { 
         if(this.StandardCostResponseField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.StandardCostResponseField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setStandardCostResponse(System.Collections.ArrayList val)
     { 
       this.StandardCostResponseField = new T8.Schemas.Titcerpservice._2018_11.Titcerpintegration.StandardCostResponse[val.Count];
       val.CopyTo(this.StandardCostResponseField);
     }



    
    


  } // type
} // ns
            





