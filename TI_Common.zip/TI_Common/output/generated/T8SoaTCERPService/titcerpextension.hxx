/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_TCERPSERVICE_TITCERPEXTENSION_HXX 
#define TEAMCENTER_SERVICES_TCERPSERVICE_TITCERPEXTENSION_HXX


#include <titcerpextension1811.hxx>


namespace T8
{
    namespace Soa
    {
        namespace TCERPService
        {
            class TITCERPExtension;
        }
    }
}


/**
 * SOA service for PLM and ERP Transfers
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libt8soatcerpservice.dll
 * </li>
 * </ul>
 */

class T8::Soa::TCERPService::TITCERPExtension
    : public T8::Soa::TCERPService::_2018_11::TITCERPExtension
{};

#endif

