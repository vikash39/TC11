/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


#include <unidefs.h>
#if defined(SUN)
#    include <unistd.h>
#endif

#include<TITCERPExtension1811IiopSkeleton.hxx>


#include <teamcenter/soa/internal/common/PolicyMarshaller.hxx>
#include <teamcenter/soa/internal/server/PolicyManager.hxx>
#include <teamcenter/soa/internal/server/PerServicePropertyPolicy.hxx>
#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace std;
using namespace Teamcenter::Soa::Server;
using namespace Teamcenter::Soa::Internal::Server;
using namespace Teamcenter::Soa::Internal::Common;
using namespace Teamcenter::Soa::Common::Exceptions;


namespace T8
{
    namespace Services
    {
    
        namespace TCERPService
        {
             namespace _2018_11
             {




    TITCERPExtensionIiopSkeleton::TITCERPExtensionIiopSkeleton():
        IiopSkeleton()
    {
        m_serviceName = "TITCERPExtension";
    
       _svcMap[ "getPartTransferInfo" ]   = getPartTransferInfo;
       _svcMap[ "importStandardCostInfo" ]   = importStandardCostInfo;

    }
    
    TITCERPExtensionIiopSkeleton::~TITCERPExtensionIiopSkeleton()
    {
    	// If the implementing class did not implement the ServicePolicy
    	// then delete it, since it was allocated here in the skeleton
	 	Teamcenter::Soa::Server::ServicePolicy* sp = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(sp == NULL)
    	{
    		delete _servicePolicy;
    	}
        delete _service;
    }



     void TITCERPExtensionIiopSkeleton::initialize()
    {
   	// If the impl class has not implemented the ServicePolicy interface
    	// Create an instance of the default ServicePolicy
	 	_servicePolicy = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(_servicePolicy == NULL)
    	{
    		_servicePolicy = new Teamcenter::Soa::Server::ServicePolicy;
    	}
    }




    static T8::Soa::TCERPService::_2018_11::TITCERPExtensionImpl* _service;
	static Teamcenter::Soa::Server::ServicePolicy*  	 _servicePolicy;


    void TITCERPExtensionIiopSkeleton::getPartTransferInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::getPartTransferInfo" );

        std::string _contentType;
        T8::Soa::TCERPService::_2018_11::TITCERPExtension::GetPartTransferInput  getPartTransferInputs;
        T8::Soa::TCERPService::_2018_11::TITCERPExtension::GetPartTransferResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::getPartTransferInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getPartTransferInputs", getPartTransferInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionImpl::getPartTransferInfo" );
            _out = _service->getPartTransferInfo( getPartTransferInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::getPartTransferInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }

    void TITCERPExtensionIiopSkeleton::importStandardCostInfo( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::importStandardCostInfo" );

        std::string _contentType;
        T8::Soa::TCERPService::_2018_11::TITCERPExtension::GetStandardCostInput  getStandardCostInputs;
        T8::Soa::TCERPService::_2018_11::TITCERPExtension::GetStandardCostResponse _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::importStandardCostInfo - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "getStandardCostInputs", getStandardCostInputs );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionImpl::importStandardCostInfo" );
            _out = _service->importStandardCostInfo( getStandardCostInputs );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "T8::Soa::TCERPService::_2018_11::TITCERPExtension::TITCERPExtensionIiopSkeleton::importStandardCostInfo - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _out.serialize( &_sdmStream );          
        }
    }




T8::Soa::TCERPService::_2018_11::TITCERPExtensionImpl* TITCERPExtensionIiopSkeleton::_service = new T8::Soa::TCERPService::_2018_11::TITCERPExtensionImpl;
Teamcenter::Soa::Server::ServicePolicy*  	  TITCERPExtensionIiopSkeleton::_servicePolicy = NULL;
static Teamcenter::Soa::Internal::Gateway::T2LService* me_TITCERPExtension = Teamcenter::Soa::Internal::Gateway::TcServiceManager::instance().registerService( "TCERPService-2018-11-TITCERPExtension", new TITCERPExtensionIiopSkeleton );

 //register the service for getServiceList()
 static std::string registeredServiceOnStartup_TITCERPExtension = Teamcenter::Soa::Internal::Server::ServiceManager::instance().registerService("TCERPService-2018-11-TITCERPExtension");

}}}}    // End Namespace

