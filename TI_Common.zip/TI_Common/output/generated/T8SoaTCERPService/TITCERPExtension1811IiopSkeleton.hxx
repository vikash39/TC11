/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

//#ifndef TEAMCENTER_SERVICES_TCERPService__2018_11_TITCERPExtension_HXX 
//#define TEAMCENTER_SERVICES_TCERPService__2018_11_TITCERPExtension_HXX

#include <unidefs.h>
#if defined(SUN)
#    include <unistd.h>
#endif

#include <string>
#include <iostream>
#include <sstream>



#include <teamcenter/soa/server/ServiceData.hxx>
#include <teamcenter/soa/server/ServiceException.hxx>
#include <teamcenter/soa/server/PartialErrors.hxx>
#include <teamcenter/soa/server/Preferences.hxx>
#include <teamcenter/soa/server/ServicePolicy.hxx> 
#include <teamcenter/soa/internal/server/IiopSkeleton.hxx>
#include <teamcenter/soa/internal/server/ServiceManager.hxx>
#include <teamcenter/soa/internal/gateway/TcServiceManager.hxx>
#include <teamcenter/soa/common/xml/SaxToNodeParser.hxx>
#include <teamcenter/soa/common/xml/XmlUtils.hxx>
#include <teamcenter/soa/common/exceptions/ExceptionMapper.hxx>
#include <teamcenter/soa/common/exceptions/DomException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/ServiceException.hxx>

#include <titcerpextension1811impl.hxx>


#include <TCERPService_exports.h>  
namespace T8
{
    namespace Services
    {
    
        namespace TCERPService
        {
             namespace _2018_11
             {


class SOATCERPSERVICE_API TITCERPExtensionIiopSkeleton : public Teamcenter::Soa::Internal::Server::IiopSkeleton
{

public:

     TITCERPExtensionIiopSkeleton();
    ~TITCERPExtensionIiopSkeleton();
    
    virtual void initialize();
   


private:

    static T8::Soa::TCERPService::_2018_11::TITCERPExtensionImpl* _service;
	static Teamcenter::Soa::Server::ServicePolicy*  	 _servicePolicy;


    static void getPartTransferInfo( const std::string& xmlIn,  Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse );
    
    static void importStandardCostInfo( const std::string& xmlIn,  Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse );
    


};    // End Class



}}}}    // End Namespace
#include <TCERPService_undef.h>
//#endif   

