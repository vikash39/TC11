/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#include <string>
#include <map>

#include <titcerpextension1811.hxx>


#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace T8::Soa::TCERPService::_2018_11;

const std::string TITCERPExtension::XSD_NAMESPACE ="http://t8.com/Schemas/TCERPService/2018-11/TITCERPExtension";




void TITCERPExtension::CustomerData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "customerCode", customerCode );
    _sdmStream->writeStructMember( "customerName", customerName );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"customerPartID", customerPartID, true, false,  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );
    _sdmStream->writeCloseElement(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName  );
}

void TITCERPExtension::GetPartTransferInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "changeItemID", changeItemID );
    _sdmParser->parseStructMember( "changeItemRevID", changeItemRevID );
    _sdmParser->parseStructMember( "owningSite", owningSite );
}

void TITCERPExtension::GetPartTransferResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{
    _sdmStream->setServiceData( &serviceData );

    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "success", (bool)success );
    _sdmStream->writeStructMember( "changeItemNum", changeItemNum );
    _sdmStream->writeStructMember( "owningSite", owningSite );
    _sdmStream->writeStructMember( "changeType", changeType );
    _sdmStream->writeStructMember( "affectedPlants", affectedPlants );
    _sdmStream->writeStructMember( "jobUID", jobUID );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"productRevisionData", productRevisionData );
    _sdmStream->writeStructMember( _prefix+"errorList", errorList );
    _sdmStream->writeFrameworkMember( serviceData );
    _sdmStream->writeStructMember( _prefix+"materialRevisionData", materialRevisionData );
    _sdmStream->writeStructMember( _prefix+"prgVariantRevisionData", prgVariantRevisionData );
    _sdmStream->writeCloseElement(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName  );
}

void TITCERPExtension::GetStandardCostInput::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "standardCostInputData", standardCostInputData );
}

void TITCERPExtension::GetStandardCostResponse::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "costID", costID );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "bpcsItemID", bpcsItemID );
    _sdmStream->writeStructMember( "importStatus", importStatus );
    _sdmStream->writeStructMember( "reasonForFailure", reasonForFailure );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, true );

}

void TITCERPExtension::MaterialRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName  );
}

void TITCERPExtension::PrgVariantRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName  );
}

void TITCERPExtension::ProductRevisionData::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName );
    _sdmStream->writeStructMember( "itemID", itemID );
    _sdmStream->writeStructMember( "itemRevID", itemRevID );
    _sdmStream->writeStructMember( "itemRevUID", itemRevUID );
    _sdmStream->writeStructMember( "itemName", itemName );
    _sdmStream->writeStructMember( "itemRevDescription", itemRevDescription );
    _sdmStream->writeStructMember( "uom", uom );
    _sdmStream->writeStructMember( "drawingNum", drawingNum );
    _sdmStream->writeStructMember( "drawingNumRev", drawingNumRev );
    _sdmStream->writeStructMember( "bpcsFamilyCode", bpcsFamilyCode );
    _sdmStream->writeStructMember( "bpcsSubFamilyCode", bpcsSubFamilyCode );
    _sdmStream->writeStructMember( "designLevel", designLevel );
    _sdmStream->writeStructMember( "releaseLevel", releaseLevel );
    _sdmStream->writeStructMember( "makeOrBuy", makeOrBuy );
    _sdmStream->writeStructMember( "spendType", spendType );
    _sdmStream->writeStructMember( "partWeight", partWeight );
    _sdmStream->writeStructMember( "newBPCSItemNeeded", newBPCSItemNeeded );
    _sdmStream->writeOpenElementClose(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"erpPartNumbers", erpPartNumbers, true, false,  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE );
    _sdmStream->writeStructMember( _prefix+"customerData", customerData );
    _sdmStream->writeCloseElement(  T8::Soa::TCERPService::_2018_11::TITCERPExtension::XSD_NAMESPACE, elementName  );
}

void TITCERPExtension::StandardCostInputData::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "costID", costID );
    _sdmParser->parseStructMember( "itemID", itemID );
    _sdmParser->parseStructMember( "itemRevID", itemRevID );
    _sdmParser->parseStructMember( "bpcsItemID", bpcsItemID );
    _sdmParser->parseStructMember( "itemDesc", itemDesc );
    _sdmParser->parseStructMember( "extraDesc", extraDesc );
    _sdmParser->parseStructMember( "standardCostRecords", standardCostRecords );
}

void TITCERPExtension::StandardCostRecord::parse( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser )
{
    _sdmParser->parseStructMember( "recordID", recordID );
    _sdmParser->parseStructMember( "facility", facility );
    _sdmParser->parseStructMember( "costSet", costSet );
    _sdmParser->parseStructMember( "costBucket", costBucket );
    _sdmParser->parseStructMember( "currentCost", currentCost );
    _sdmParser->parseStructMember( "quantity", quantity );
    _sdmParser->parseStructMember( "stockingUOM", stockingUOM );
    _sdmParser->parseStructMember( "currency", currency );
}




TITCERPExtension::TITCERPExtension()
{
}

TITCERPExtension::~TITCERPExtension()
{
}

