/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_TCERPSERVICE_2018_11_TITCERPEXTENSION_HXX 
#define TEAMCENTER_SERVICES_TCERPSERVICE_2018_11_TITCERPEXTENSION_HXX


#include <teamcenter/soa/server/ServiceData.hxx>



#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <TCERPService_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}
namespace T8 { namespace Services { namespace TCERPService { namespace _2018_11 { class TITCERPExtensionIiopSkeleton; }}}}


namespace T8
{
    namespace Soa
    {
        namespace TCERPService
        {
            namespace _2018_11
            {
                class TITCERPExtension;
            }
        }
    }
}


class SOATCERPSERVICE_API T8::Soa::TCERPService::_2018_11::TITCERPExtension

{
public:

    static const std::string XSD_NAMESPACE;

    struct CustomerData;
    struct GetPartTransferInput;
    struct GetPartTransferResponse;
    struct GetStandardCostInput;
    struct GetStandardCostResponse;
    struct MaterialRevisionData;
    struct PrgVariantRevisionData;
    struct ProductRevisionData;
    struct StandardCostInputData;
    struct StandardCostRecord;

    typedef std::map< std::string, std::vector< std::string > > CustomerPartIDMap;

    typedef std::map< std::string, std::vector< std::string > > ERPPartNumbersMap;

    struct  CustomerData
    {
        /**
         * sCustomerCode
         */
        std::string customerCode;
        /**
         * sCustomerName
         */
        std::string customerName;
        /**
         * mCustomerPartID
         */
        CustomerPartIDMap customerPartID;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="CustomerData" );
    };

    struct  GetPartTransferInput
    {
        /**
         * TI Change Item ID
         */
        std::string changeItemID;
        /**
         * TI Change Revision ID
         */
        std::string changeItemRevID;
        /**
         * owningSite
         */
        std::string owningSite;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetPartTransferResponse
    {
        /**
         * vProductRevisionData
         */
        std::vector< ProductRevisionData > productRevisionData;
        /**
         * sErrorList
         */
        std::vector< std::string > errorList;
        /**
         * serviceData
         */
        Teamcenter::Soa::Server::ServiceData serviceData;
        /**
         * bIsSuccess
         */
        bool success;
        /**
         * sChangeItemNum
         */
        std::string changeItemNum;
        /**
         * sOwningSite
         */
        std::string owningSite;
        /**
         * sChangeType
         */
        std::string changeType;
        /**
         * sAffectedPlants
         */
        std::string affectedPlants;
        /**
         * sJobUID
         */
        std::string jobUID;
        /**
         * materialRevisionData
         */
        std::vector< MaterialRevisionData > materialRevisionData;
        /**
         * prgVariantRevisionData
         */
        std::vector< PrgVariantRevisionData > prgVariantRevisionData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetPartTransferResponse" );
    };

    struct  GetStandardCostInput
    {
        /**
         * standardCostInputData
         */
        std::vector< StandardCostInputData > standardCostInputData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  GetStandardCostResponse
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * BPCSItemID
         */
        std::string bpcsItemID;
        /**
         * importStatus
         */
        std::string importStatus;
        /**
         * reasonForFailure
         */
        std::string reasonForFailure;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="GetStandardCostResponse" );
    };

    struct  MaterialRevisionData
    {
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * itemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * itemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * bpcsFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * bpcsSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeOrBuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * newBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * erpPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * customerData
         */
        std::vector< CustomerData > customerData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="MaterialRevisionData" );
    };

    struct  PrgVariantRevisionData
    {
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * itemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * itemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * bpcsFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * bpcsSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeOrBuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * newBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * erpPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * customerData
         */
        std::vector< CustomerData > customerData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="PrgVariantRevisionData" );
    };

    struct  ProductRevisionData
    {
        /**
         * Item ID
         */
        std::string itemID;
        /**
         * Item Rev ID
         */
        std::string itemRevID;
        /**
         * strItemRevUID
         */
        std::string itemRevUID;
        /**
         * itemName
         */
        std::string itemName;
        /**
         * ItemRevDescription
         */
        std::string itemRevDescription;
        /**
         * uom
         */
        std::string uom;
        /**
         * drawingNumber
         */
        std::string drawingNum;
        /**
         * drawingNumRev
         */
        std::string drawingNumRev;
        /**
         * bPCSFamilyCode
         */
        std::string bpcsFamilyCode;
        /**
         * BPCSSubFamilyCode
         */
        std::string bpcsSubFamilyCode;
        /**
         * designLevel
         */
        std::string designLevel;
        /**
         * releaseLevel
         */
        std::string releaseLevel;
        /**
         * makeorbuy
         */
        std::string makeOrBuy;
        /**
         * spendType
         */
        std::string spendType;
        /**
         * partWeight
         */
        std::string partWeight;
        /**
         * isNewBPCSItemNeeded
         */
        std::string newBPCSItemNeeded;
        /**
         * mERPPartNumbers
         */
        ERPPartNumbersMap erpPartNumbers;
        /**
         * vCustomerData
         */
        std::vector< CustomerData > customerData;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="ProductRevisionData" );
    };

    struct  StandardCostInputData
    {
        /**
         * costID
         */
        std::string costID;
        /**
         * itemID
         */
        std::string itemID;
        /**
         * itemRevID
         */
        std::string itemRevID;
        /**
         * bpcsItemID
         */
        std::string bpcsItemID;
        /**
         * itemDesc
         */
        std::string itemDesc;
        /**
         * extraDesc
         */
        std::string extraDesc;
        /**
         * standardCostRecords
         */
        std::vector< StandardCostRecord > standardCostRecords;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };

    struct  StandardCostRecord
    {
        /**
         * recordID
         */
        std::string recordID;
        /**
         * facility
         */
        std::string facility;
        /**
         * costSet
         */
        std::string costSet;
        /**
         * costBucket
         */
        std::string costBucket;
        /**
         * currentCost
         */
        std::string currentCost;
        /**
         * quantity
         */
        std::string quantity;
        /**
         * stockingUOM
         */
        std::string stockingUOM;
        /**
         * currency
         */
        std::string currency;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmParser;
        friend class T8::Services::TCERPService::_2018_11::TITCERPExtensionIiopSkeleton;

        void parse    ( Teamcenter::Soa::Internal::Server::SdmParser* _sdmParser );
    };



    TITCERPExtension();
    virtual ~TITCERPExtension();
    

    /**
     * .
     *
     * @param getPartTransferInputs
     *        getPartTransferInputs
     *
     * @return
     *
     */
    virtual GetPartTransferResponse getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs ) = 0;

    /**
     * .
     *
     * @param getStandardCostInputs
     *        getStandardCostInputs
     *
     * @return
     *
     */
    virtual GetStandardCostResponse importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs ) = 0;


};

#include <TCERPService_undef.h>
#endif

