/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
@<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

package com.t8.services.strong.titcerpservice;


import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.client.model.ModelManager;
import com.teamcenter.utest.SoaSession;

import junit.framework.TestCase;

public class TITCERPIntegrationTest extends TestCase
{
    private Connection        connection;
    private ModelManager      manager;
    private TITCERPIntegrationService   service;
    

    public TITCERPIntegrationTest( String name )
    {
        super( name );
    }

    protected void setUp( ) throws Exception
    {
        super.setUp( );

        connection  = SoaSession.getConnection();
        manager     = connection.getModelManager();       
        service     = TITCERPIntegrationService.getService(connection);

    }
        
    
    public void testGetPartTransferInfo()
    {
        // TODO write test code, then remove fail()
        // service.getPartTransferInfo(  )
        fail("This test has not been implemented yet");
    }

    public void testImportContractedCostInfo()
    {
        // TODO write test code, then remove fail()
        // service.importContractedCostInfo(  )
        fail("This test has not been implemented yet");
    }

    public void testImportSellingPriceInfo()
    {
        // TODO write test code, then remove fail()
        // service.importSellingPriceInfo(  )
        fail("This test has not been implemented yet");
    }

    public void testImportStandardCostInfo()
    {
        // TODO write test code, then remove fail()
        // service.importStandardCostInfo(  )
        fail("This test has not been implemented yet");
    }


}

