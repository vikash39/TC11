//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  T8_TIAutoExt

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libT8_TIAutoExt

#if !defined(LIBT8_TIAUTOEXT) && !defined(IPLIB)
#   error IPLIB or LIBT8_TIAUTOEXT is not defined
#endif

/* Handwritten code should use T8_TIAUTOEXT_API, not T8_TIAUTOEXTEXPORT */

#define T8_TIAUTOEXT_API T8_TIAUTOEXTEXPORT

#if IPLIB==libT8_TIAutoExt || defined(LIBT8_TIAUTOEXT)
#   if defined(__lint)
#       define T8_TIAUTOEXTEXPORT       __export(T8_TIAutoExt)
#       define T8_TIAUTOEXTGLOBAL       extern __global(T8_TIAutoExt)
#       define T8_TIAUTOEXTPRIVATE      extern __private(T8_TIAutoExt)
#   elif defined(_WIN32)
#       define T8_TIAUTOEXTEXPORT       __declspec(dllexport)
#       define T8_TIAUTOEXTGLOBAL       extern __declspec(dllexport)
#       define T8_TIAUTOEXTPRIVATE      extern
#   else
#       define T8_TIAUTOEXTEXPORT
#       define T8_TIAUTOEXTGLOBAL       extern
#       define T8_TIAUTOEXTPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define T8_TIAUTOEXTEXPORT       __export(T8_TIAutoExt)
#       define T8_TIAUTOEXTGLOBAL       extern __global(T8_TIAutoExt)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define T8_TIAUTOEXTEXPORT      __declspec(dllimport)
#       define T8_TIAUTOEXTGLOBAL       extern __declspec(dllimport)
#   else
#       define T8_TIAUTOEXTEXPORT
#       define T8_TIAUTOEXTGLOBAL       extern
#   endif
#endif
