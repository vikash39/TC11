//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBT8_TIAUTOEXT) && !defined(IPLIB)
#   error IPLIB or LIBT8_TIAUTOEXT is not defined
#endif

#undef T8_TIAUTOEXT_API
#undef T8_TIAUTOEXTEXPORT
#undef T8_TIAUTOEXTGLOBAL
#undef T8_TIAUTOEXTPRIVATE
