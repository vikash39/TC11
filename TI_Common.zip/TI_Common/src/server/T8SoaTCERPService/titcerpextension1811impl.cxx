/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <titcerpextension1811impl.hxx>

using namespace T8::Soa::TCERPService::_2018_11;
using namespace Teamcenter::Soa::Server;

TITCERPExtensionImpl::GetPartTransferResponse TITCERPExtensionImpl::getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs )
{
    // TODO implement operation
}


TITCERPExtensionImpl::GetStandardCostResponse TITCERPExtensionImpl::importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs )
{
    // TODO implement operation
}



