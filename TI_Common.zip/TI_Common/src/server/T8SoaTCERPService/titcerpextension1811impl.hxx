/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_TCERPSERVICE_2018_11_TITCERPEXTENSION_IMPL_HXX 
#define TEAMCENTER_SERVICES_TCERPSERVICE_2018_11_TITCERPEXTENSION_IMPL_HXX


#include <titcerpextension1811.hxx>

#include <TCERPService_exports.h>

namespace T8
{
    namespace Soa
    {
        namespace TCERPService
        {
            namespace _2018_11
            {
                class TITCERPExtensionImpl;
            }
        }
    }
}


class SOATCERPSERVICE_API T8::Soa::TCERPService::_2018_11::TITCERPExtensionImpl : public T8::Soa::TCERPService::_2018_11::TITCERPExtension

{
public:

    virtual TITCERPExtensionImpl::GetPartTransferResponse getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs );
    virtual TITCERPExtensionImpl::GetStandardCostResponse importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs );


};

#include <TCERPService_undef.h>
#endif
