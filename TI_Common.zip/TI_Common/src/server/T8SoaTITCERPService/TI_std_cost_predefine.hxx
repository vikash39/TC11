# ifndef TI_STANDARD_COST_DATA_IMPORT_HEADER
# define TI_STANDARD_COST_DATA_IMPORT_HEADER

//#include <titcerpextension1811.hxx> //Add the header file name in BMIDE
#include<titcerpintegration1811.hxx>
#include "TI_std_cost_header.hxx"
#include "TI_std_cost_struct.cxx"
#include "TI_std_cost_error.hxx"


#ifdef _WIN32
#define EXTERN_DLL extern __declspec(dllexport)
#define EXTERNCLASS __declspec(dllexport)
#else
#define EXTERN_DLL extern
#define EXTERNCLASS
#endif


using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server; //Use the namespace from BMIDE code


EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration ::GetStandardCostResponse tiStandardCostTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost);

/*IMAN Relation Definition*/
#define TI_COST_FORMS                                   "TI_CostForms"
#define FORM_HISTORY_RELATION                           "TI_FormHistory"

#define RETAIN_RELEASE_DATE                             "yes"
#define ERP_INTEGRATION_GROUP_NAME                      "Commercial"
#define ERP_INTEGRATION_USER_NAME                       "erpintegration"

/*Property Definition*/
#define TO_COMPANY_TYPE                                  "t8_t1a149tocompanytype"
#define TO_COMPANY                                       "t8_t1a149tocompany"
#define TO_COUNTRY                                       "t8_t1a149tocountry"
#define TO_CITY                                          "t8_t1a149tocity"
#define LABOR_COST                                       "t8_t1a149laborcost"
#define MATERIAL_COST                                    "t8_t1a149materialcost"
#define TOTAL_COST                                       "t8_t1a149totalcost"
#define SCRAP_PERCENTAGE                                 "t8_t1a149scrappercentage"
#define OVERHEAD_COST                                    "t8_t1a149varoverheadcost"
#define FIXEDOVERHEAD_COST                               "t8_t1a149fixedoverheadcost"
#define DUTY_COST                                        "t8_t1a149dutycost"
#define FREIGHT_COST                                     "t8_t1a149freightcost"
#define CURRENCY                                         "t8_t1a149currency"
#define ERP_INTEGRATION                                  "t8_t1a149erpintegration"
#define ERP_INTEGATION_ATTR_STD_PART                     "t8_t1a149erpintegration"
#define STD_COST_FORM_TO_CITY_ATTR                       "t8_t1a149tocity"
#define ALT_ID_ATTR_NAME                                 "Alternate ID"
#define ALT_REV_ATTR_NAME                                "Alternate Revision"
#define OBJECT_NAME                                      "object_name"
#define BPCS8_2                                          "NA - BPCS 8.2 - Auburn Hills"
#define EXCLUSION_PART_VALUE                             "fnd0lov_value"
#define EXCLUSION_PART_CATEGORY                          "ERP Exclusion Parts"
#define ITEM_ID                                          "item_id"

/*Business Object Definition*/
#define ITEM_REVISION_TYPE_COST_FORM_CREATION           "TI_Product Revision,TI_Prg_Variant Revision,TI_Material Revision"
#define STANDARD_COST_FORM                              "StandardCostForm"
#define FORM_CLASS                                      "Form"
#define STANDARD_COST_FORM_TYPE                         "T8_TI_StandardCost"
#define CONTRACTED_COST_FORM_TYPE                       "T8_TI_ContractedCost"
#define SELLING_PRICE_FORM_TYPE                         "T8_TI_SellingCost"
#define EXCLUSION_PART_TYPE                             "Administrative List Of Values"

/*Query Name */
#define EXCLUSION_PART_QUERY_NAME                       "Admin - List of Values"

/*Lov name Definition*/
#define FACILITY_CODE_NAME_MAPPING_LOV                   "T8_t1aERPPLMFacilityCodeMapping"
#define COMPANY_LOV_NAME                                 "t1aTICompanies"
#define T1_CURRENCY                                      "t1aCurrency"
#define T8_ERP_CURRENCY_MAP                              "T8_t1aERPCurrencyMapping"

#define PLM_ADMIN_USER                                   "plmadmin@tiauto.com"

/*Preference name */
#define PREF_SERVER_NAME                                 "Mail_server_name"
#define PREF_PLM_NOTIFIERS                               "PLM_Notifiers"



char*  getCurrentSiteID();
map<string, string>  getAttributeMappingValues(TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
map<string, string>  parseFacilityMappingLOV(string lovName /*,TITCERPIntegration::GetStandardCostResponse &stdCostResponse*/);
int  stdCostRecordCompare(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostRecord r1, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostRecord r2);
map<string, string>  parseCascadingLOV(string sLovName,string sParent, TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
map<string, string>  parsingCascadingLOV(tag_t tLov, string sParent,map<string, string> &facilityInfoMap, TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
int  createNewForm(tag_t tRelationType, tag_t tItemRev,TITCERPIntegration::GetStandardCostResponse &stdCostResponse,vector<TIStandardCostRecord> tempStdCostRecords, int index, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData);
int  costFormRevise(tag_t tSecondaryObjects,TITCERPIntegration::GetStandardCostResponse &stdCostResponse,vector<TIStandardCostRecord> tempStdCostRecords, int index, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData);
logical  costFormReviseCondition(tag_t tSecondaryObjects, vector<TIStandardCostRecord> tempStdCostRecords );
int  TI_add_rev_status_to_secondary(tag_t tItemRev, tag_t tCostForm, char* retainReleaseDate) ;
int standardCostRecords(vector<TIStandardCostDataMain> &vcStdCostDataMain);

int  importData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData, vector<struct TIStandardCostRecord> tempStdCostRecords);
void  sendResponseInfo(int iStatusCode, TITCERPIntegration::GetStandardCostResponse &stdCostResponse, 
		 string sReasonForFailure, string costId, string itemId, string itemRevId, string bpcsItemId );
map<char*, char*> mapTestInput();
tag_t findItemRevLatestReleasedAltId(string sBpcsItem, TITCERPIntegration::GetStandardCostResponse &stdCostResponse /* string sBpcsRevId*/);

int updateCostFomAttr(tag_t tSecondaryObjects, vector<TIStandardCostRecord> tempStdCostRecords, int index);

vector<TIStandardCostRecord>  processStandardCostData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData vcStdCostData);
int changeOwnership(tag_t tSecondaryObjects);
logical checkFacilityCode(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData vcStdCostData);
void eMailNotification(TITCERPIntegration::GetStandardCostResponse stdCostResponse, char* siteName /* string erpSystemName*/);
int sendEMail(string sMailSub, char* sMailBody);
string  getCurrencyValue(string sCurrency);
logical readExclusionPartsList(string sValue);
#endif
