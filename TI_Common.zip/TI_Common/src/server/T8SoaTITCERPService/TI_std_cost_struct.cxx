#include "TI_std_cost_header.hxx"

using namespace std;

struct TIStandardCostRecord {

	string recordID;
	string facility ;
	string costSet;
	string costBucket;
	string currentCost;
	string quantity;
	string stockingUOM;
	string currency ;
	string toCompanyType;
	string toCompany ; 
	string toCountry; 
	string toCity; 
	string totalCost;
	string materialCost;
	string laborCost;
	string variableOverHeadCost;
	string fixedOverHeadCost;
	string scrapPercentage;
	string dutyCost;
	string freightCost;
	string erpIntegration;
};

struct TIStandardCostData {

	string  sCostID;
    string  sItemID;
	string  sItemRevID;
	string  sBPCSItemID;
	string  sItemDesc;
	string  sExtraDesc;
	vector<TIStandardCostRecord>  addVectorStruct;

};

struct TIStandardCostDataMain {
	
	vector<TIStandardCostData>  tiStdCostDataMain;

};



