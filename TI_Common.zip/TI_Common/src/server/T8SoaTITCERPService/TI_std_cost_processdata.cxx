#include "TI_std_cost_header.hxx"
#include "TI_std_cost_predefine.hxx"

TITCERPIntegration::StandardCostResponse localCostResponse;

using namespace std;

/****************************************************************
//
//  Function Name:   getCurrentSiteID
//
//  Description:     Get the current site id.
//                   
//  Parameters:     none

//  Return Value:    iSiteID
//                   
*****************************************************************/

char*  getCurrentSiteID(){

	int iFail = ITK_ok;
	int  iSite    = 0;
	int  iSiteID  = 0;

	tag_t  tSitetag = NULLTAG;

	char    *cSiteName = NULL;

	ERROR_CALL(iFail = POM_site_id(&iSite));

	if(iSite != 0)
		ERROR_CALL(iFail = SA_find_site_by_id(iSite,&tSitetag));

	if(tSitetag!= NULLTAG)
		ERROR_CALL(iFail = SA_ask_site_info2(tSitetag,&cSiteName,&iSiteID));

	if(iSiteID != 0)
		return cSiteName;

	return cSiteName;
}

/****************************************************************
//
//  Function Name:   processStandardCostData()
//
//  Description:     Process the input standard cost data, after process it's giving the tempStdCostRecord.
//                   
//  Parameters:     stdCostResponse -> passing the stdCostResponseInfo structure.
vcStdCostRecords -> input records

//  Return Value:    none
//                   
*****************************************************************/


vector<TIStandardCostRecord> processStandardCostData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData vcStdCostData) {

	string sPartNum ="";
	string sRevId = "";
	string sBpcsItem ="" ;
	string sCostId = "";

	vector<TIStandardCostRecord> tempStdCostRecords;

	try{
		map<string, string> facilityCodeNameMap = parseFacilityMappingLOV(FACILITY_CODE_NAME_MAPPING_LOV/*,stdCostResponse*/);
		map<string, string> facilityLocationMap =  parseCascadingLOV(COMPANY_LOV_NAME,"TI",stdCostResponse);

		tempStdCostRecords.push_back(TIStandardCostRecord());
		tempStdCostRecords.erase(tempStdCostRecords.begin());

		sPartNum =vcStdCostData.itemID;
		sRevId = vcStdCostData.itemRevID;
		sBpcsItem = vcStdCostData.bpcsItemID;
		sCostId = vcStdCostData.costID;

		//vector<StandardCostRecord> vcStdCostRecords = vcStdCostData.standardCostRecords;
		logical bAllFacCodeEql = checkFacilityCode(vcStdCostData);
		if(bAllFacCodeEql == true){

			for(int iCnt=0; iCnt<vcStdCostData.standardCostRecords.size(); iCnt++) {

				TIStandardCostRecord tempStdCostRecord;

				int index = iCnt;

				T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostRecord tempstdCostRecord = vcStdCostData.standardCostRecords.at(index);


				while(true) {
					if(index <vcStdCostData.standardCostRecords.size() && stdCostRecordCompare(tempstdCostRecord , vcStdCostData.standardCostRecords.at(index))==0) {

						if(vcStdCostData.standardCostRecords.at(index).costBucket =="000")
						{
							tempStdCostRecord.totalCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="001")
						{
							tempStdCostRecord.materialCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="002")
						{
							tempStdCostRecord.scrapPercentage = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="003")
						{
							tempStdCostRecord.laborCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="004")
						{
							tempStdCostRecord.variableOverHeadCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="005")
						{
							tempStdCostRecord.fixedOverHeadCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="007")
						{
							tempStdCostRecord.dutyCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						else if(vcStdCostData.standardCostRecords.at(index).costBucket =="008")
						{
							tempStdCostRecord.freightCost = vcStdCostData.standardCostRecords.at(index).currentCost;
						}
						if(vcStdCostData.standardCostRecords.size() > 1 && vcStdCostData.standardCostRecords.at(index).facility == vcStdCostData.standardCostRecords.at(index+1).facility){
							//vcStdCostRecords.erase(vcStdCostRecords.begin()+index+1);
							vcStdCostData.standardCostRecords.erase(vcStdCostData.standardCostRecords.begin());
						}
						else
							index++;
					}
					else
						break;
				}


				try{
					string sCurrency = getCurrencyValue(tempstdCostRecord.currency);
					tempStdCostRecord.currency =sCurrency;
					string facilityName = "";
					string facility   ="";

					if(facilityCodeNameMap.size() != 0)
					{
						facility = tempstdCostRecord.facility;
											//facility = tempStdCostRecord.facility;
										for (auto it = facilityCodeNameMap.begin(); it != facilityCodeNameMap.end(); ++it){
											if(facility==(it->first))
												facilityName = it->second;
										}

										if(facilityName != "")
										{
											string facilityLoc = "";
											if(facilityLocationMap.size() != 0){
												map<string, string>::iterator it ;
													it = facilityLocationMap.find(facilityName);
													if( it != facilityLocationMap.end()){
														facilityLoc = it->second;
													}
											}
											//else
												//sendResponseInfo(1, stdCostResponse,  FACILITY__LOC_MAP_SIZE,sCostId,sPartNum,sRevId,sBpcsItem);

											if(facilityLoc!="")
											{

												string companyType ="";
												string companyName ="";
												string country ="";
												//std::string s = "TI::TI Automotive::Poland";
												std::string delimiter = "::";

												int index = 0;
												size_t pos = 0;
												std::string token;
												while ((pos = facilityLoc.find(delimiter)) != std::string::npos) {
													token = facilityLoc.substr(0, pos);
													if(index ==0){
														companyType=token;
													}

													facilityLoc.erase(0, pos + delimiter.length());
													if(index ==1){
														companyName=token;
													}
													index++;
												}
												if(index >1){
													country = facilityLoc;
												}

												tempStdCostRecord.toCompanyType=companyType;
												tempStdCostRecord.toCompany=companyName;
												tempStdCostRecord.toCountry=country;
												tempStdCostRecord.toCity=facilityName;

												if(companyType !="" && companyName !="" && country !="" && facilityName !="" ){
													tempStdCostRecords.push_back(tempStdCostRecord);
												}
												else{
													string sTempPre = "Any of these values are empty. CompanyType = "+companyType+", Company = "+companyName+", Country = "+country+", City = "+facilityName;
													sendResponseInfo(1, stdCostResponse,  sTempPre,sCostId,sPartNum,sRevId,sBpcsItem);
												}
											}
											else{
												sendResponseInfo(1, stdCostResponse,  FACILITY_LOC_IS_NULL,sCostId,sPartNum,sRevId,sBpcsItem);
											}
										}
										else
										{
											sendResponseInfo(1, stdCostResponse,  FACILITY_NAME_IS_NULL,sCostId,sPartNum,sRevId,sBpcsItem);
										}

					}
					else{
						sendResponseInfo(1, stdCostResponse,  FACILITY_CODE_NAME_MAP,sCostId,sPartNum,sRevId,sBpcsItem);
					}

				}catch (const std::out_of_range& error) {
					TC_write_syslog(error.what());
				}
				catch(...){
					sendResponseInfo(1, stdCostResponse,  EXCP_ERR_TO_GET_FACTY_AND_LOC,sCostId,sPartNum,sRevId,sBpcsItem);
				}
			}
		}else
			sendResponseInfo(1, stdCostResponse,EXCP_ERR,sCostId,sPartNum,sRevId,sBpcsItem);

	}catch(...){
		TC_write_syslog(EXCP_ERR_TO_GET_FACTY_AND_LOC);
	}

	return tempStdCostRecords;
}

//Compare with the two same input facility records
int  stdCostRecordCompare(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostRecord r1, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostRecord r2) {
	if(r1.facility == r2.facility){
		return 0;
	}
	else
		return -1;	
}

/****************************************************************
//
//  Function Name: parseFacilityMappingLOV()
//
//  Description:  Getting the facilityName & facilityCode from tc. based on lov name.
//                   
//  Parameters:  lovName -> T8_t1aERPPLMFacilityCodeMapping
stdCostResponse -> passing the stdCostResponseInfo structure.					

//  Return Value:  facilityCodeNameMap
//                   
*****************************************************************/

map<string, string>  parseFacilityMappingLOV(string lovName /*, TITCERPIntegration::GetStandardCostResponse &stdCostResponse*/){

	//TC_write_syslog("stdCostResponse",stdCostResponse);

	int iFail      = ITK_ok;
	int iNumCunt   = 0;
	int iReturnCnt = 0;

	tag_t* tLov		  = NULLTAG;


	char** cLovValues = NULL;

	map<string, string> facilityCodeNameMap;

	try{
		ERROR_CALL(iFail = LOV_find(lovName.c_str(), &iNumCunt, &tLov));

		for(int i=0; i<iNumCunt; i++) {

			ERROR_CALL(iFail = LOV_ask_values_string(tLov[i], &iReturnCnt, &cLovValues));
		}
/*
		char **values = NULL;

		values = (char **)malloc(sizeof(char *) * 4);

		values[0] = (char *)malloc(sizeof(char) * 100);
		values[1] = (char *)malloc(sizeof(char) * 100);
		values[2] = (char *)malloc(sizeof(char) * 100);
		values[3] = (char *)malloc(sizeof(char) * 100);

		strcpy(values[0],"Gravatai:Gravatai/Aftermarket:BPCS 8.2:42:North America:Pump and Module Systems:ABCD:Prototype");
		//strcpy(values[1],"argentina:Caro/Aftermarket:BPCS 8.2:43:North America:Pump and Module Systems:ABCD:Prototype");
		strcpy(values[2],"Bangalore:Bangalore:BPCS 8.2:47:North America:Tank Systems:IJKL:Production Released,Production Launched");
		//strcpy(values[3],"Greeneville:Greeneville:BPCS 8.2:50:North America:Pump and Module Systems:Toyota - 321A/322A,Toyota - 953A,Toyota - 767L:Prototype,Production Released,Production Launched");
*/
		std::string facilityName ="";
		std::string facilityCode ="";

		if(iReturnCnt != 0){
			for(int i=0; i<iReturnCnt; i++){

				char * pch;
				pch = strtok (cLovValues[i],":");
				int index = 0;
				while (pch != NULL)
				{
					//printf ("%s\n",pch);
					if(index==0) {
						facilityName = pch;
					}
					if(index==3){
						facilityCode = pch;
					}

					pch = strtok (NULL, ":");
					index++;
				}

				facilityCodeNameMap.insert(pair<string, string>(facilityCode,facilityName));
				//free(values[i]);
			}
		}

	}catch(...){
		TC_write_syslog(EXCP_PARSE_FACTY_MAP_LOV);
	}

	return facilityCodeNameMap;
}

/****************************************************************
//
//  Function Name: parseCascadingLOV()
//
//  Description:  Getting the facilityLocationMap values from tc. based on lov name.
//                   
//  Parameters: sLovName -> t1aTICompanies
sParent -> TI 
stdCostResponse -> passing the stdCostResponseInfo structure.

// Return Value: facilityInfoMap
//                   
*****************************************************************/

map<string, string>  parseCascadingLOV(string sLovName,string sParent, TITCERPIntegration::GetStandardCostResponse &stdCostResponse){

	int iFail      = ITK_ok;
	int iNumCunt   = 0;

	tag_t* tLov		   = NULLTAG;

	map<string, string> facilityInfoMap;

	try{
		ERROR_CALL(iFail = LOV_find(sLovName.c_str(), &iNumCunt, &tLov));

		if(iNumCunt !=0) {

			for(int i=0; i<iNumCunt; i++) {
				parsingCascadingLOV(tLov[0], sParent,facilityInfoMap, stdCostResponse);
			}
		}

	}catch(...){
		TC_write_syslog(EXCP_PARSE_CASCADEING_LOV);
	}

	return facilityInfoMap;
}


map<string, string>  parsingCascadingLOV(tag_t tLov, string sParent,map<string, string> &facilityInfoMap, TITCERPIntegration::GetStandardCostResponse &stdCostResponse) {

	int iFail           = ITK_ok;
	int iFilterReCont   = 0;
	int *iFilterArryCnt = 0;
	int iNumValuesCnt   = 0;

	tag_t *tListOFFilterObj = NULLTAG;

	char** listOfValues        = NULL;

	try{
		ERROR_CALL(iFail = LOV_ask_values_string(tLov, &iNumValuesCnt, &listOfValues));
		ERROR_CALL(iFail = LOV_ask_value_filters(tLov,&iFilterReCont, &iFilterArryCnt, &tListOFFilterObj));

		if(iNumValuesCnt !=0){
			for(int i=0; i<iNumValuesCnt; i++) {
				if(iFilterReCont == 0) {

					facilityInfoMap.insert(pair<string, string>(listOfValues[i],sParent ));
				}
				else{
					if(sParent != ""){
						parsingCascadingLOV( tListOFFilterObj[i],  sParent+"::"+listOfValues[i],facilityInfoMap, stdCostResponse);

					}else{
						parsingCascadingLOV( tListOFFilterObj[i], listOfValues[i],facilityInfoMap,stdCostResponse);
					}
				}
			}
		}

	}catch(...){
		TC_write_syslog(EXCP_PARSE_CASCADEING_LOV);
	}
	return facilityInfoMap;
}




/****************************************************************
//
//  Function Name: importData()
//
//  Description: This function, searching the part number & rev id in tc based on the input.
then checking corresponding itemRevId, standardCostForm existing or not.
if it's not existing then create new standardCostForm, else revise standardCostForm.
//                   
//  Parameters: stdCostResponse -> passing the stdCostResponseInfo structure.

//  Return Value:    none
//                   
*****************************************************************/

int  importData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData, vector<struct TIStandardCostRecord> tempStdCostRecords) {

	int iFail             = ITK_ok;
		//itemRevisionCount = 0,
	int	iSecObjCunt       = 0;

	//tag_t tItemRevisionQuery  = NULLTAG,
		tag_t tRelationType        = NULLTAG;
		tag_t *tSecondaryObjects   = NULLTAG;
		//tag_t tItemID              = NULLTAG;
		//tag_t *taltLatestRevId     = NULLTAG;
		tag_t tItemRev             = NULLTAG;

	char* cObjectType   = NULL;

	logical bFormRevising = false;

	/*char itemRevisionName[ITEM_name_size_c + 1] = "";
	char itemRevisionID[ITEM_id_size_c + 1] = "";*/


		std::string sPartNum =stdCostData.itemID;
		std::string sRevId = stdCostData.itemRevID;
		std::string sBpcsItem = stdCostData.bpcsItemID;
		std::string sCostId = stdCostData.costID;

		//vector<TIStandardCostRecord> vcStdCostRecords = stdCostData.addVectorStruct;

	try{
		int indx=0;

		//for (int indx = 0; indx < tempStdCostRecords.size(); indx++) {

			char* partNumber = (char*)sPartNum.c_str();
			char* PartRevId  = (char*)sRevId.c_str();
			char* bpcsItem =(char*)sBpcsItem.c_str();

			//----------------------------------------------------------------------
			/*	char *attributeNames[3] = {"Item ID","Revision","Type"},
			*attributeValues[3] =  {partNumber,partRev,ITEM_REVISION_TYPE_COST_FORM_CREATION}; 

			ERROR_CALL(iFail = QRY_find2("Item Revision...", &tItemRevisionQuery)); */

			//checking part number inside the Teamcenter
			if((partNumber != NULL && (partNumber[0] != '\0')) || (bpcsItem != NULL && (bpcsItem[0] != '\0'))){

				if(((PartRevId != NULL) && (PartRevId[0] != '\0')) && ((partNumber != NULL)&& (partNumber[0] != '\0'))){

					ERROR_CALL(iFail =ITEM_find_rev(partNumber, PartRevId, &tItemRev));
				}
				else
				{
					//checking the part number against alternate id  
					tItemRev = findItemRevLatestReleasedAltId(sBpcsItem, stdCostResponse /* sBpcsRevId*/);	
				}

				/*cout<<"error before executing qry======"<<iFail<<endl;
				TC_write_syslog("error before executing qry ");
				ERROR_CALL(iFail = QRY_execute(tItemRevisionQuery, 1, attributeNames, attributeValues, &itemRevisionCount, &tItemRevList));
				TC_write_syslog("error after executing qry======== ");
				cout<<"error======"<<iFail<<endl;*/
				if(tItemRev !=0 && iFail == 0) {

					/*ERROR_CALL(iFail = AOM_ask_value_string(tItemRevList[0],"owning_site", &cSiteName));

					if(cSiteName != NULL){ */

					ERROR_CALL(iFail = GRM_find_relation_type(TI_COST_FORMS, &tRelationType));

					ERROR_CALL(iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType, &iSecObjCunt,  &tSecondaryObjects ));
					logical bExisting = false;

					if(iSecObjCunt>0){
						//saveAS
						for(int iCnt=0; iCnt<iSecObjCunt; iCnt++) {

							ERROR_CALL(iFail = WSOM_ask_object_type2(tSecondaryObjects[iCnt], &cObjectType));

							if(tc_strcmp(cObjectType,STANDARD_COST_FORM_TYPE)==0) {

								 bExisting = costFormReviseCondition(tSecondaryObjects[iCnt],tempStdCostRecords);
								if(bExisting == true) {
									iFail = costFormRevise(tSecondaryObjects[iCnt], stdCostResponse,tempStdCostRecords,indx, stdCostData);
									bFormRevising = true;
									if(iFail == ITK_ok){
										sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS,sCostId,sPartNum,sRevId,sBpcsItem);
										return iFail;
									}else if(iFail ==1){
										return iFail;
									}else{
										sendResponseInfo(1, stdCostResponse,  EXCP_ERR_REVISE_SCF,sCostId,sPartNum,sRevId,sBpcsItem);
										return iFail;
									}
								}
								/*else {

									iFail = createNewForm(tRelationType, tItemRev,stdCostResponse, tempStdCostRecords, indx,stdCostData);
									if(iFail == ITK_ok){
										sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS,sCostId,sPartNum,sRevId,sBpcsItem);
									}else
										sendResponseInfo(1, stdCostResponse,  EXCP_ERR_CREATE_NEW_SCF,sCostId,sPartNum,sRevId,sBpcsItem);

								}*/
							}
						}

					}
					//else{
					 if(tempStdCostRecords[indx].toCity !="" && !bFormRevising){
						iFail = createNewForm(tRelationType, tItemRev,stdCostResponse, tempStdCostRecords, indx, stdCostData);
						if(iFail == ITK_ok){
							sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS,sCostId,sPartNum,sRevId,sBpcsItem);
							return iFail;
						}else if(iFail ==1){
							return iFail;
						}
						else{
							sendResponseInfo(1, stdCostResponse,  EXCP_ERR_CREATE_NEW_SCF,sCostId,sPartNum,sRevId,sBpcsItem);
							return iFail;
						}
					}

					//}
					//else{
					//TC_write_syslog("Unable to update Cost data for the Part \""/* partNumber*/"\": Remote Object");
					//}
				}
				else{
					sendResponseInfo(1, stdCostResponse,  PART_NUM_NOT_FOUND_IN_TC,sCostId,sPartNum,sRevId,sBpcsItem);
					return iFail;
				}

			} 
			else{
				sendResponseInfo(1, stdCostResponse,  PART_NUM_NOT_PASSED_AS_ARG,sCostId,sPartNum,sRevId,sBpcsItem);
				return iFail;
			}

		//} //For loop


	}
	catch(...){
		TC_write_syslog(IMPORT_DATA_FUN_ERR);
	}

	MEM_free(tSecondaryObjects);
	//MEM_free(tItemRevList);
	return iFail;
}

/****************************************************************
//
//  Function Name: createNewForm()
//
//  Description:  Creating the New StandardCost Form...

//  Parameters:   tRelationType -> TI_CostForms
tItemRev -> three type of itemRev
stdCostResponse -> passing the stdCostResponseInfo structure.				
//                   
*****************************************************************/


int  createNewForm(tag_t tRelationType, tag_t tItemRev,TITCERPIntegration::GetStandardCostResponse &stdCostResponse,vector<TIStandardCostRecord> tempStdCostRecords, int index, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData) {

	int iFail = ITK_ok;

	tag_t   tForm      = NULLTAG,
		tFormInput = NULLTAG,
		tFormObj   = NULLTAG,
		tGrmRelation = NULLTAG;

	try {
		ERROR_CALL_RETURN(iFail = TCTYPE_find_type(STANDARD_COST_FORM_TYPE,FORM_CLASS,&tForm));

		ERROR_CALL_RETURN(iFail = TCTYPE_construct_create_input(tForm, &tFormInput));

		char* toCompanyType = (char*)tempStdCostRecords[index].toCompanyType.c_str();
		char* toCompany = (char*)tempStdCostRecords[index].toCompany.c_str();
		char* toCountry = (char*)tempStdCostRecords[index].toCountry.c_str();
		char* toCity =(char*)tempStdCostRecords[index].toCity.c_str();
		char* currency = (char*)tempStdCostRecords[index].currency.c_str();

		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,TO_COMPANY_TYPE,toCompanyType));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,TO_COMPANY,toCompany));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,TO_COUNTRY,toCountry));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,TO_CITY,toCity));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,ERP_INTEGRATION,BPCS8_2));

		if(currency != NULL)
			ERROR_CALL_RETURN(iFail = AOM_set_value_string(tFormInput,CURRENCY,currency));

		string laborCost = tempStdCostRecords[index].laborCost;
		if(laborCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,LABOR_COST,stod(laborCost)));

		string materialCost = tempStdCostRecords[index].materialCost;
		if(materialCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,MATERIAL_COST,stod(materialCost)));

		string totalCost = tempStdCostRecords[index].totalCost;
		if(totalCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,TOTAL_COST,stod(totalCost)));

		string scrapPercentage = tempStdCostRecords[index].scrapPercentage;
		if(scrapPercentage != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,SCRAP_PERCENTAGE,stod(scrapPercentage)));

		string varoverheadcost = tempStdCostRecords[index].variableOverHeadCost;
		if(varoverheadcost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,OVERHEAD_COST,stod(varoverheadcost)));

		string fixedOverheadCost = tempStdCostRecords[index].fixedOverHeadCost;
		if(fixedOverheadCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,FIXEDOVERHEAD_COST,stod(fixedOverheadCost)));

		string dutyCost = tempStdCostRecords[index].dutyCost;
		if(dutyCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,DUTY_COST,stod(dutyCost)));

		string freightCost = tempStdCostRecords[index].freightCost;
		if(freightCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tFormInput,FREIGHT_COST,stod(freightCost)));

		ERROR_CALL_RETURN(iFail = TCTYPE_create_object(tFormInput, &tFormObj)); 
		iFail = changeOwnership(tFormObj);
		if(iFail !=ITK_ok){
			sendResponseInfo(1, stdCostResponse,  CHANGE_OWNERSHIP,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}
		ERROR_CALL(iFail = AOM_save(tFormObj));
		//ERROR_CALL(iFail = AOM_save_without_extensions(tFormObj));
		if(iFail !=ITK_ok){
			string sErrMsg(LOV_INPUT_ERROR);
			string sLovError = sErrMsg+" CompanyType = "+tempStdCostRecords[index].toCompanyType+", Company = "+tempStdCostRecords[index].toCompany+", Country = "+tempStdCostRecords[index].toCountry+", City = "+tempStdCostRecords[index].toCity;
			sendResponseInfo(1, stdCostResponse,  sLovError,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}
		ERROR_CALL_RETURN(iFail = AOM_refresh(tFormObj,0));

		ERROR_CALL_RETURN(iFail = GRM_create_relation(tItemRev,tFormObj,tRelationType,NULLTAG,&tGrmRelation));
		ERROR_CALL_RETURN(iFail = GRM_save_relation(tGrmRelation));
		ERROR_CALL_RETURN(iFail = AOM_refresh(tGrmRelation,0));

		iFail = TI_add_rev_status_to_secondary(tItemRev,tFormObj,NULL);

		if(iFail != ITK_ok){
			sendResponseInfo(1, stdCostResponse,  ERR_ADD_REVISION_STATUS,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_ERR_CREATE_NEW_SCF,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
		return 1;
	}

	return iFail;
}

/****************************************************************
//
//  Function Name:   costFormRevise()
//
//  Description:      it's revising the existing StandardCost Form...

//  Parameters:      iSecObjCunt -> stdCostForm count
tSecondaryObjects -> stdCostForm
stdCostResponse -> passing the stdCostResponseInfo structure.				

//  Return Value:    none
//                   
*****************************************************************/

int  costFormRevise(tag_t tSecondaryObjects, TITCERPIntegration::GetStandardCostResponse &stdCostResponse,vector<TIStandardCostRecord> tempStdCostRecords, int index, T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData stdCostData) {

	int iFail = ITK_ok,
		iFCount = 0;

	tag_t	tForm			 = NULLTAG,
		tSaveAsInput         = NULLTAG,
		tTargetCopyObj       = NULLTAG,
		tObjectType          = NULLTAG,
		tHistoryRelationType = NULLTAG,
		tHistoryForm         = NULLTAG,
		tClass		         = NULLTAG,
		tObjName	       	 = NULLTAG,
		*tSecFormObject      = NULLTAG;

	//date_t tDateVal          = NULLDATE;

	char *pcClassName	   = NULL,
		*cFormName         = NULL;
		//*retainReleaseDate = NULL;

	logical verdict		= false;

	try{

		ERROR_CALL_RETURN(iFail = TCTYPE_find_type(STANDARD_COST_FORM_TYPE,FORM_CLASS,&tForm));

		ERROR_CALL_RETURN(iFail = TCTYPE_ask_object_type(tForm, &tObjectType));
		ERROR_CALL_RETURN(iFail = TCTYPE_construct_saveasinput(tForm, &tSaveAsInput));
		ERROR_CALL_RETURN(iFail = TCTYPE_saveas_object(tSecondaryObjects,tSaveAsInput,0,NULL, &tTargetCopyObj));
		iFail = changeOwnership(tTargetCopyObj);
		if(iFail !=ITK_ok){
			sendResponseInfo(1, stdCostResponse,  CHANGE_OWNERSHIP,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}
		ERROR_CALL_RETURN(iFail = ITK_set_bypass(true));
		ERROR_CALL_RETURN(iFail = AOM_save(tTargetCopyObj));
		ERROR_CALL_RETURN(iFail = AOM_refresh(tTargetCopyObj,0));
		ERROR_CALL_RETURN(iFail = GRM_find_relation_type(FORM_HISTORY_RELATION, &tHistoryRelationType));
		ERROR_CALL_RETURN(iFail = GRM_list_secondary_objects_only(tSecondaryObjects,tHistoryRelationType, &iFCount,  &tSecFormObject));
		ERROR_CALL_RETURN(iFail = AOM_ask_value_string(tTargetCopyObj,OBJECT_NAME,&cFormName));

		ERROR_CALL_RETURN(iFail = POM_is_loaded(tTargetCopyObj, &verdict));
		if (verdict == TRUE && iFail == ITK_ok)
		{
			ERROR_CALL_RETURN(iFail = POM_unload_instances(1, &tTargetCopyObj));
		}

		ERROR_CALL_RETURN(iFail = POM_load_instances_any_class(1, &tTargetCopyObj, POM_modify_lock));
		ERROR_CALL_RETURN(iFail = POM_class_of_instance (tTargetCopyObj, &tClass));
		ERROR_CALL_RETURN(iFail = POM_name_of_class (tClass, &pcClassName));
		ERROR_CALL_RETURN(iFail = POM_attr_id_of_attr(OBJECT_NAME, pcClassName, &tObjName));

		iFail = TI_add_rev_status_to_secondary(tSecondaryObjects,  tTargetCopyObj, RETAIN_RELEASE_DATE);
		if(iFail != ITK_ok){
			sendResponseInfo(1, stdCostResponse,  ERR_ADD_REVISION_STATUS,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}

		string s = to_string(iFCount);
		char const *pchar = s.c_str();
		char* str = ";";
		char * strTemp = (char *) malloc(1 + strlen(cFormName)+ strlen(str)+strlen(pchar));
		strcpy(strTemp, cFormName);
		strcat(strTemp, str);
		strcat(strTemp, pchar);

		ERROR_CALL_RETURN(iFail = POM_set_attr_string(1, &tTargetCopyObj, tObjName, strTemp ));

		ERROR_CALL_RETURN(iFail = POM_save_instances(1, &tTargetCopyObj, FALSE));
		ERROR_CALL_RETURN(iFail = POM_refresh_instances_any_class(1, &tTargetCopyObj, POM_no_lock));

		ERROR_CALL_RETURN(iFail = GRM_create_relation(tSecondaryObjects,tTargetCopyObj,tHistoryRelationType,NULLTAG,&tHistoryForm));

		ERROR_CALL_RETURN(iFail = GRM_save_relation(tHistoryForm));
		ERROR_CALL_RETURN(iFail = AOM_refresh(tHistoryForm,0));

		/*ERROR_CALL_RETURN(iFail = AOM_ask_value_date(tTargetCopyObj,"date_released", &retainReleaseDate));
		ERROR_CALL_RETURN(iFail = AOM_ask_value_date(tTargetCopyObj,"date_released", &tDateVal));
		ERROR_CALL_RETURN(iFail = ITK_date_to_string(tDateVal, &retainReleaseDate));*/

		//Update cost form attr
		iFail = updateCostFomAttr(tSecondaryObjects, tempStdCostRecords,index);
		if(iFail != ITK_ok){
			sendResponseInfo(1, stdCostResponse,  ERR_UPDATE_COST_FORM_ATTR,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}

		/*if(iFail == ITK_ok){
			//iFail = TI_add_rev_status_to_secondary(tTargetCopyObj,  tHistoryForm, RETAIN_RELEASE_DATE);
			//iFail = TI_add_rev_status_to_secondary(tSecondaryObjects,  tTargetCopyObj, RETAIN_RELEASE_DATE);

			if(iFail != ITK_ok){
				sendResponseInfo(1, stdCostResponse,  ERR_ADD_REVISION_STATUS,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
				return 1;
			}

		}else{
			sendResponseInfo(1, stdCostResponse,  ERR_UPDATE_COST_FORM_ATTR,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
			return 1;
		}*/

		MEM_free(tSecFormObject);

	}catch(...){

		sendResponseInfo(1, stdCostResponse,  EXCP_ERR_REVISE_SCF,stdCostData.costID,stdCostData.itemID,stdCostData.itemRevID,stdCostData.bpcsItemID);
		return 1;
	}

	return iFail;
}

/****************************************************************
//
//  Function Name:   costFormReviseCondition()
//
//  Description:      To checking condation for revising StandardCost Form.

//  Parameters:     tSecondaryObjects -> stdCostForm
vcTempRecordList -> after process data.

//  Return Value:    formExistPro = true or false
//                   
*****************************************************************/


logical  costFormReviseCondition(tag_t tSecondaryObjects, vector<TIStandardCostRecord> tempStdCostRecords ){
	logical formExistPro = false;

	int iFail = ITK_ok;

	char *erpIntegration = NULL;
	char	*toCity      = NULL;

	try{
		ERROR_CALL(iFail = AOM_ask_value_string(tSecondaryObjects, ERP_INTEGRATION, &erpIntegration));
		ERROR_CALL(iFail = AOM_ask_value_string(tSecondaryObjects, STD_COST_FORM_TO_CITY_ATTR, &toCity));
		for(int iCnt = 0; iCnt<tempStdCostRecords.size(); iCnt++)
			if(tc_strcasecmp(toCity,tempStdCostRecords[iCnt].toCity.c_str())==0 /*&& tc_strcasecmp(erpIntegration,BPCS8_2)==0*/){   //Juatuaba  , Gravatai, Kilburn
				return formExistPro = true;
			}
	}catch(...){
	}
	return formExistPro;
}


/****************************************************************
//
//  Function Name:   TI_add_rev_status_to_secondary()
//
//  Description:     setting the release status to new form of the existing form

//  Parameters:     tag_t tItemRev,
tag_t tCostForm,
char* retainReleaseDate 							

//  Return Value:    none
//                   
*****************************************************************/

int  TI_add_rev_status_to_secondary(tag_t tItemRev, tag_t tCostForm, char* retainReleaseDate) {

	int	iNoOfRelStatus		= 0,
		iFail			    = ITK_ok;

	char   *classid_s			= NULL;

	tag_t *ptReleaseStatus	 = NULLTAG,
		object_classID		 = NULLTAG,
		object_reldateID     = NULLTAG,
		object_relStatListID = NULLTAG;

	//logical	lValid_date = true,
	logical	verdict     = false;

	date_t dateVal = NULLDATE;
	time_t rawtime;
	struct tm * timeinfo;
	//SYSTEMTIME str_t;
	//time_t timeObj;


	time ( &rawtime );
	timeinfo = localtime ( &rawtime );

	//create the item based on the input data
	ERROR_CALL_RETURN(iFail = ITK_set_bypass(true));
	ERROR_CALL_RETURN(iFail = AOM_ask_value_tags(tItemRev,"release_status_list",&iNoOfRelStatus,&ptReleaseStatus));

	if(iNoOfRelStatus>=0 && ptReleaseStatus != NULL)
	{

		if(retainReleaseDate== NULL)
		{
			ERROR_CALL_RETURN(iFail = POM_class_of_instance(tCostForm, &object_classID));
			if ( iFail == ITK_ok && object_classID!=NULLTAG)
			{
				ERROR_CALL_RETURN(iFail = POM_name_of_class(object_classID,&classid_s));
			}
			if ( iFail == ITK_ok )
			{
				iFail = AOM_ask_value_date(tItemRev,"date_released", &dateVal);
				//printf(asctime(timeinfo));

				/*dateVal.day = timeinfo->tm_mday;
				dateVal.hour = timeinfo->tm_hour;
				dateVal.minute = timeinfo->tm_min;
				dateVal.month = timeinfo->tm_mon;
				dateVal.second = timeinfo->tm_sec;
				dateVal.year = timeinfo->tm_year+1900;*/

				//printf(" IFail=%d",iFail);
				ERROR_CALL_RETURN(iFail = POM_attr_id_of_attr("date_released",classid_s,&object_reldateID));
				ERROR_CALL_RETURN(iFail = POM_attr_id_of_attr("release_status_list",classid_s,&object_relStatListID));

				if ( iFail == ITK_ok )
				{
					ERROR_CALL_RETURN(iFail = POM_is_loaded(tCostForm, &verdict));
				}
				if (verdict == TRUE && iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail=POM_unload_instances(1, &tCostForm));
				}
				//Modifying the values of the new form
				if (iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				}
				ERROR_CALL_RETURN(iFail = POM_clear_attr	( 1, &tCostForm, object_relStatListID));
				ERROR_CALL_RETURN(iFail = EPM_add_release_status(ptReleaseStatus[0],1,&tCostForm,false));
				ERROR_CALL_RETURN(iFail = POM_unload_instances(1, &tCostForm));
				ERROR_CALL_RETURN(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				ERROR_CALL_RETURN(iFail = POM_set_attr_date(1, &tCostForm, object_reldateID, dateVal));

				if (iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail = POM_save_instances(1, &tCostForm, FALSE));
				}
			}
		}
		else
		{
			ERROR_CALL_RETURN(iFail = AOM_ask_value_date(tItemRev,"date_released", &dateVal));
			ERROR_CALL_RETURN(iFail = POM_class_of_instance(tCostForm, &object_classID));
			if ( iFail == ITK_ok && object_classID!=NULLTAG)
			{
				ERROR_CALL_RETURN(iFail = POM_name_of_class(object_classID,&classid_s));
			}
			if ( iFail == ITK_ok )
			{
				ERROR_CALL_RETURN(iFail = POM_attr_id_of_attr("date_released",classid_s,&object_reldateID));
				ERROR_CALL_RETURN(iFail = POM_attr_id_of_attr("release_status_list",classid_s,&object_relStatListID));
				if ( iFail == ITK_ok )
				{
					ERROR_CALL_RETURN(iFail = POM_is_loaded(tCostForm, &verdict));
				}
				if (verdict == TRUE && iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail=POM_unload_instances(1, &tCostForm));
				}
				//Modifying the values of the new form
				if (iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				}
				ERROR_CALL_RETURN(iFail = POM_clear_attr( 1, &tCostForm, object_relStatListID));
				ERROR_CALL_RETURN(iFail = EPM_add_release_status(ptReleaseStatus[0],1,&tCostForm,false));
				ERROR_CALL_RETURN(iFail = POM_unload_instances(1, &tCostForm));
				ERROR_CALL_RETURN(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				ERROR_CALL_RETURN(iFail = POM_set_attr_date(1, &tCostForm, object_reldateID, dateVal));

				if (iFail == ITK_ok)
				{
					ERROR_CALL_RETURN(iFail = POM_save_instances(1, &tCostForm, FALSE));
				}
			}
		}

	}
	EMH_clear_errors();
	MEM_free(ptReleaseStatus);
	return iFail;
}


/****************************************************************
//
//  Function Name:   sendResponseInfo()
//
//  Description:     it's sending the success & failure responseInfo to the server.

//  Parameters:     iStatusCode -> 0 -> success & 1-> failure
stdCostResponse -> passing the stdCostResponseInfo structure 
sReasonForFailure -> reason for failure(msg).							

//  Return Value:    none
//                   
*****************************************************************/

void  sendResponseInfo(int iStatusCode, TITCERPIntegration::GetStandardCostResponse &stdCostResponse, 
					   string sReasonForFailure, string costId, string itemId, string itemRevId, string bpcsItemId ){

						   if(iStatusCode == 0) {

							   localCostResponse.importStatus = SUCCESS_STATUS;
							   localCostResponse.costID = costId;
							   localCostResponse.itemID = itemId;
							   localCostResponse.itemRevID = itemRevId;
							   localCostResponse.bpcsItemID = bpcsItemId;
							   localCostResponse.reasonForFailure ="";

							   stdCostResponse.standardCostResponse.push_back(localCostResponse);

						   }else{

							   localCostResponse.importStatus = ERR_FAIL_STATUS;
							   localCostResponse.reasonForFailure = sReasonForFailure;
							   localCostResponse.costID = costId;
							   localCostResponse.itemID = itemId;
							   localCostResponse.itemRevID = itemRevId;
							   localCostResponse.bpcsItemID = bpcsItemId;

							   stdCostResponse.standardCostResponse.push_back(localCostResponse);
						   }

}


tag_t findItemRevLatestReleasedAltId(string sBpcsItem, TITCERPIntegration::GetStandardCostResponse &stdCostResponse /* string sBpcsRevId*/) {


	TC_write_syslog("stdCostResponse",stdCostResponse);
	int iFail = ITK_ok,
		itemRevisionCount = 0,
		iAltCnt  = 0;

	tag_t tItemId            = NULLTAG,
		tItemRevisionQuery   = NULLTAG,
		*tItemRevList        = NULLTAG,
		taltLatestRevID      = NULLTAG;

	date_t tDateVal         = NULLDATE;

	char *cItemId        = NULL,
		*cReleaseDate    = NULL,
		**cAltIdList      = NULL;

	try{

		char* bpcsItemId  = (char*)sBpcsItem.c_str();
		//char* bpcsRevId  = (char*)sBpcsRevId.c_str();

		if(bpcsItemId != NULL && (bpcsItemId[0] != '\0')) {

			ERROR_CALL(iFail = QRY_find2("Item Revision...", &tItemRevisionQuery));

			/*	if(bpcsRevId != NULL && (bpcsRevId[0] != '\0')) {

			char *attributeNames[2] = {ALT_ID_ATTR_NAME,ALT_REV_ATTR_NAME};
			char *attributeValues[2] =  {bpcsItemId,bpcsRevId};

			if(tItemRevisionQuery != 0){

			ERROR_CALL(iFail = QRY_execute(tItemRevisionQuery, 1, attributeNames, attributeValues, &itemRevisionCount, &tItemRevList));

			if(itemRevisionCount != 0) {

			return tItemRevList[0];
			}
			}
			}*/

			char *attributeNames[2] = {ALT_ID_ATTR_NAME};
			char *attributeValues[2] =  {bpcsItemId};

			//char *attributeNames[3] = {"Item ID","Revision","Type"};
			//char *attributeValues[3] =  {partNumber,partRev,ITEM_REVISION_TYPE_COST_FORM_CREATION};

			if(tItemRevisionQuery != 0){

				ERROR_CALL(iFail = QRY_execute(tItemRevisionQuery, 1, attributeNames, attributeValues, &itemRevisionCount, &tItemRevList));

				if(itemRevisionCount != 0) {

					for(int iCnt = 0; iCnt<itemRevisionCount; iCnt++) {

						ERROR_CALL(iFail = AOM_ask_value_date(tItemRevList[iCnt],"date_released", &tDateVal));
						ERROR_CALL(iFail = ITK_date_to_string(tDateVal, &cReleaseDate));

						if(cReleaseDate != NULL) {

							ERROR_CALL(iFail = AOM_ask_value_strings(tItemRevList[iCnt], "altid_list", &iAltCnt, &cAltIdList));

							if(iAltCnt != 0) {

								int index = 0;
								int iCnt = 0;
								vector<char*> vcAltId;

								for(int alt=0; alt<iAltCnt; alt++) {
									char * pch;
									pch = strtok (cAltIdList[alt],"@,");
									while (pch != NULL)
									{
										if(iCnt== index){
											index++;
											vcAltId.push_back(pch);
											index++;
										}
										iCnt++;
										pch = strtok (NULL, "@,");
									}
								}
								for(int iCnt = 0; iCnt<vcAltId.size(); iCnt++){
									char* pch;
									pch = strtok (vcAltId[iCnt],"/");

									if(tc_strcmp(pch,bpcsItemId) == 0 ) {
										return tItemRevList[iCnt];
									}
								}
							}
						}
					} 

					ERROR_CALL(iFail = AOM_ask_value_string(tItemRevList[0],ITEM_ID, &cItemId));
					ERROR_CALL(iFail = ITEM_find_item(cItemId, &tItemId));
					ERROR_CALL(iFail = ITEM_ask_latest_rev(tItemId, &taltLatestRevID));
				} 
			}
		}

	}catch(const std::exception & ex){

		TC_write_syslog(ex.what());
	}

	return taltLatestRevID;
}


int updateCostFomAttr(tag_t tSecondaryObjects, vector<TIStandardCostRecord> tempStdCostRecords, int index) {

	int iFail = ITK_ok;

	logical isCheckOut = false;

	ERROR_CALL_RETURN(iFail = ITK_set_bypass(true));
	ERROR_CALL_RETURN(iFail = RES_is_checked_out(tSecondaryObjects, &isCheckOut));
	if(isCheckOut == true)
		ERROR_CALL_RETURN(iFail = RES_checkin(tSecondaryObjects));

	ERROR_CALL_RETURN(iFail = AOM_lock(tSecondaryObjects));
	ERROR_CALL_RETURN(iFail = RES_checkout2(tSecondaryObjects,"update",NULL,"/tmp",RES_EXPORT_FILE));
	ERROR_CALL_RETURN(iFail = RES_is_checked_out(tSecondaryObjects, &isCheckOut));
	ERROR_CALL_RETURN(iFail = AOM_refresh(tSecondaryObjects,true));

	if(isCheckOut) {

		char* toCompanyType = (char*)tempStdCostRecords[index].toCompanyType.c_str();
		char* toCompany = (char*)tempStdCostRecords[index].toCompany.c_str();
		char* toCountry = (char*)tempStdCostRecords[index].toCountry.c_str();
		char* toCity =(char*)tempStdCostRecords[index].toCity.c_str();
		char* currency = (char*)tempStdCostRecords[index].currency.c_str();

		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,TO_COMPANY_TYPE,toCompanyType));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,TO_COMPANY,toCompany));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,TO_COUNTRY,toCountry));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,TO_CITY,toCity));
		ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,ERP_INTEGRATION,BPCS8_2));

		if(currency != NULL)
			ERROR_CALL_RETURN(iFail = AOM_set_value_string(tSecondaryObjects,CURRENCY,currency));

		string laborCost = tempStdCostRecords[index].laborCost;
		if(laborCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,LABOR_COST,stod(laborCost)));

		string materialCost = tempStdCostRecords[index].materialCost;
		if(materialCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,MATERIAL_COST,stod(materialCost)));

		string totalCost = tempStdCostRecords[index].totalCost;
		if(totalCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,TOTAL_COST,stod(totalCost)));

		string scrapPercentage = tempStdCostRecords[index].scrapPercentage;
		if(scrapPercentage != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,SCRAP_PERCENTAGE,stod(scrapPercentage)));

		string varoverheadcost = tempStdCostRecords[index].variableOverHeadCost;
		if(varoverheadcost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,OVERHEAD_COST,stod(varoverheadcost)));

		string fixedOverheadCost = tempStdCostRecords[index].fixedOverHeadCost;
		if(fixedOverheadCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,FIXEDOVERHEAD_COST,stod(fixedOverheadCost)));

		string dutyCost = tempStdCostRecords[index].dutyCost;
		if(dutyCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,DUTY_COST,stod(dutyCost)));

		string freightCost = tempStdCostRecords[index].freightCost;
		if(freightCost != "")
			ERROR_CALL_RETURN(iFail = AOM_set_value_double(tSecondaryObjects,FREIGHT_COST,stod(freightCost)));

		ERROR_CALL_RETURN(iFail = AOM_save(tSecondaryObjects));
		//ERROR_CALL(iFail = AOM_save_without_extensions(tSecondaryObjects));
		ERROR_CALL_RETURN(iFail = RES_checkin(tSecondaryObjects));
		ERROR_CALL_RETURN(iFail = AOM_refresh(tSecondaryObjects,false));
		ERROR_CALL_RETURN(iFail = AOM_unlock(tSecondaryObjects));

	}

	return iFail;
}

int changeOwnership(tag_t tSecondaryObjects) {

	int iFail = ITK_ok;

	tag_t tGroupName   = NULLTAG,
		  tUserName    = NULLTAG;

	ERROR_CALL_RETURN(iFail = SA_find_group(ERP_INTEGRATION_GROUP_NAME, &tGroupName));

	ERROR_CALL_RETURN(iFail = SA_find_user2(ERP_INTEGRATION_USER_NAME, &tUserName));

	ERROR_CALL_RETURN(iFail = AOM_set_ownership(tSecondaryObjects,tUserName,tGroupName));

	return iFail;
}

logical checkFacilityCode(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::StandardCostInputData vcStdCostData){
	logical bFacNotSame = false;
	string sTemp = vcStdCostData.standardCostRecords.at(0).facility;

	for(int iCnt=0; iCnt<vcStdCostData.standardCostRecords.size(); iCnt++){

		if(sTemp.compare(vcStdCostData.standardCostRecords.at(iCnt).facility) ==0){
			bFacNotSame = true;
		}else
			return bFacNotSame = false;
	}
	return bFacNotSame;
}


void eMailNotification(TITCERPIntegration::GetStandardCostResponse stdCostResponse ,char* siteName /* string erpSystemName*/) {

	int iFail = ITK_ok;
	int  iFileOpenErrCode    = 0;

	char *pcMailBodyFileName	= NULL;

	FILE *fMailBodyFile			= NULL;

	logical bExistFailResponse = false;

		string sSiteName(siteName);
		string sMailSub =sSiteName+" - [ERP-PLM]  cost data import failed -";
		if(stdCostResponse.standardCostResponse.size()>0){

			pcMailBodyFileName = USER_new_file_name("cr_mail_body","TEXT","dat",1);
			iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );

			fprintf(fMailBodyFile,"\nDear user\n");
			fprintf(fMailBodyFile,"\nStatus of updating cost data for the following part number(s):\n\n");

			fprintf(fMailBodyFile,"\n--------------------------------------------------------------------------------\n");
			fprintf(fMailBodyFile,"%s\t\t\t\t%s ", "TI Product Number","Reason For Failure\n");

			for( int iCnt = 0; iCnt <stdCostResponse.standardCostResponse.size();iCnt++) {
				string sErrorStr ="";

				string sImportStatus = stdCostResponse.standardCostResponse[iCnt].importStatus;

				if(tc_strcmp(sImportStatus.c_str(),ERR_FAIL_STATUS)==0){

					string sItemId =stdCostResponse.standardCostResponse[iCnt].itemID;
					string sItemRevId =stdCostResponse.standardCostResponse[iCnt].itemRevID;
					string sTempItemRevId= sItemId+"/"+sItemRevId;
					string sReasonForFailure = stdCostResponse.standardCostResponse[iCnt].reasonForFailure;
					sErrorStr =sErrorStr+"\n"+sTempItemRevId +"\t\t\t\t"+sReasonForFailure+"\n";
					if(sErrorStr !="")
						fprintf(fMailBodyFile,"  %s\n",sErrorStr.c_str());

					bExistFailResponse = true;
				}
			}

			fprintf(fMailBodyFile,"\n--------------------------------------------------------------------------------\n");
			fprintf(fMailBodyFile,"\nThanks\n");
			fprintf(fMailBodyFile,"PLM Admin\n");

			if(fMailBodyFile != NULL && bExistFailResponse == true)
			{
				fclose(fMailBodyFile);
				iFail = sendEMail( sMailSub,  pcMailBodyFileName);
				if(iFail != ITK_ok)
					TC_write_syslog(ERR_MAIL_NOTIFICATION);
			}
			else{
				TC_write_syslog("\nAll parts updated successfully\n");
			}
		}

		remove(pcMailBodyFileName );
	}


int sendEMail(string sMailSub, char* sMailBody) {

	int iFail = ITK_ok;

	int     pref_count = 0;
	int notifiers_count = 0;

	char    *tcRoot   = NULL;
	char    *server_name = NULL;
	char    **plm_notifiers = NULL;

	char *plmAdmin ="plmadmin@tiauto.com";
	char *mailaddrs = NULL;

	char    command_mail[BUFSIZ +1];
	command_mail[0] = '\0';

	TC_preference_search_scope_t scope = TC_preference_site;

	// Get TC_ROOT
	tcRoot = (char *)TC_getenv("TC_ROOT");

	if(tcRoot == NULL || strlen( tcRoot ) == 0) {
		TC_write_syslog(ENV_VAR_NOT_FOUND);
	}

	tc_strcpy(command_mail, tcRoot);
	tc_strcat(command_mail, "\\bin\\tc_mail_smtp");

	tc_strcat(command_mail, " -subject=");
	tc_strcat(command_mail, sMailSub.c_str());

	ERROR_CALL_RETURN(iFail = PREF_initialize());
	ERROR_CALL_RETURN(iFail = PREF_ask_search_scope(&scope));
	ERROR_CALL_RETURN(iFail = PREF_set_search_scope(TC_preference_site));
	ERROR_CALL_RETURN(iFail = PREF_ask_value_count(PREF_SERVER_NAME, &pref_count ));
	ERROR_CALL_RETURN(iFail = PREF_ask_char_value(PREF_SERVER_NAME, 0, &server_name ));

	ERROR_CALL_RETURN(iFail = PREF_ask_char_values(PREF_PLM_NOTIFIERS, &notifiers_count, &plm_notifiers ));
	if(notifiers_count !=0){

		for(int iCnt=0; iCnt<notifiers_count; iCnt++){
			mailaddrs = plm_notifiers[iCnt];

			if(mailaddrs != NULL &&  strlen( mailaddrs ) != 0){

				tc_strcat(command_mail, " -to=");
				tc_strcat(command_mail, mailaddrs);
			}
		}

		tc_strcat(command_mail, " -body=");
		tc_strcat(command_mail, sMailBody);

		tc_strcat(command_mail, " -user=");
		tc_strcat(command_mail, plmAdmin);

		tc_strcat(command_mail, " -server=");
		tc_strcat(command_mail, server_name);
		//tc_strcat(command_mail, " -port=25");

		system(command_mail);

	}else
		TC_write_syslog(NOT_FOUND_PLM_NOTIFIERS_MAIL_ID);

	return iFail;
}


string  getCurrencyValue(string sCurrency){

	int iFail      = ITK_ok;
	int iCurrCnt   = 0;
	int iValStrCnt = 0;
	int ierpCntMap = 0;
	int ierpValCnt = 0;

	tag_t* tCurrencyValues = NULLTAG;
	tag_t *tERPCurrMap    = NULLTAG;

	char** cCurrLovValues = NULL;
	char** cERPCurrMapVal = NULL;

	map<string, string> mapCurrencyLOVDataFromTC;

	try{
		ERROR_CALL(iFail = LOV_find(T1_CURRENCY, &iCurrCnt, &tCurrencyValues));

		if(iCurrCnt != 0){

			ERROR_CALL(iFail = LOV_ask_values_string(tCurrencyValues[0], &iValStrCnt, &cCurrLovValues));

			if(iValStrCnt !=0) {

				for(int iCnt=0; iCnt<iValStrCnt; iCnt++) {

					int index = 0;
					int currPos =0;

					string tempCurrencValue(cCurrLovValues[iCnt]);
					index = tempCurrencValue.find("(",currPos);
					string subStr = tempCurrencValue.substr(index+1);
					string sKeyCurrency = subStr.substr(0, subStr.size()-1);
					mapCurrencyLOVDataFromTC.insert(make_pair(sKeyCurrency,tempCurrencValue));
					if (tc_strcmp(sKeyCurrency.c_str(),sCurrency.c_str()) == 0)
					return tempCurrencValue;
				}
			}
		}

		//if not found then verify in the Currency Mapping file
		ERROR_CALL(iFail = LOV_find(T8_ERP_CURRENCY_MAP, &ierpCntMap, &tERPCurrMap));

		if(ierpCntMap !=0) {

			ERROR_CALL(iFail = LOV_ask_values_string(tERPCurrMap[0], &ierpValCnt, &cERPCurrMapVal));

			if(ierpValCnt !=0) {

				for(int iCnt=0; iCnt<ierpValCnt; iCnt++) {

					char * pch;

					pch = strtok (cERPCurrMapVal[iCnt],"::");
					int index = 0;
					string currencyPLMCode ="";
					while (pch != NULL)
					{
						if(index == 0)
							currencyPLMCode =pch;
						if(index == 1){
							if (tc_strcmp(pch,sCurrency.c_str()) == 0){
								if ((mapCurrencyLOVDataFromTC.find(currencyPLMCode) == mapCurrencyLOVDataFromTC.end())==0)
								{
									auto it = mapCurrencyLOVDataFromTC.find(currencyPLMCode);
	                                if( it != mapCurrencyLOVDataFromTC.end())
	                                {
	                                	return it->second;
	                                }
								}
							}
						}
						pch = strtok (NULL, "::");
						index++;
					}
				}
			}
		}

	}catch(...){
		TC_write_syslog(EXCP_TO_GETTING_CURRENCY);
	}

	return "";
}

logical readExclusionPartsList(string sValue) {

	int iFail = ITK_ok;
	int iExcCount = 0;

	tag_t tQryListOfValues = NULLTAG;
	tag_t *tExclusionPartsList = NULLTAG;

	char* cExclusionPart = NULL;
	char* cValue = (char*)sValue.c_str();

	logical bExcPartExist = false;

	char *attributeNames[3] =  {"Value","Category","Type"},
		 *attributeValues[3] = {cValue,EXCLUSION_PART_CATEGORY,EXCLUSION_PART_TYPE};

		 ERROR_CALL(iFail = QRY_find2(EXCLUSION_PART_QUERY_NAME, &tQryListOfValues));
		 ERROR_CALL(iFail = QRY_execute(tQryListOfValues, 1, attributeNames, attributeValues, &iExcCount, &tExclusionPartsList));

		 for(int iCnt=0; iCnt<iExcCount; iCnt++){

			ERROR_CALL(iFail = AOM_ask_value_string(tExclusionPartsList[iCnt],EXCLUSION_PART_VALUE, &cExclusionPart));

			if (tc_strcmp(cExclusionPart,sValue.c_str()) == 0)
				return bExcPartExist = true;
		 }

		return  bExcPartExist;
}












