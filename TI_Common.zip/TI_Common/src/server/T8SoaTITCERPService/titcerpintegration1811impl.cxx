/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif


#include "TI_std_cost_header.hxx"
#include "TI_std_cost_predefine.hxx"

using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server;

//extern T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetPartTransferResponse tiPartTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetPartTransferInput paramGetPart);
//extern T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostResponse tiStandardCostTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost);

TITCERPIntegrationImpl::GetPartTransferResponse TITCERPIntegrationImpl::getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs )
{

	TC_write_syslog("getPartTransferInputs %s",getPartTransferInputs.changeItemID.c_str());
		TITCERPIntegrationImpl::GetPartTransferResponse outputRes;

		//product rev data 1
					TITCERPIntegration::ProductRevisionData prodRevData;
					prodRevData.bpcsFamilyCode = "BX";
					prodRevData.bpcsSubFamilyCode = "ZA";
					prodRevData.designLevel = "AA";
					prodRevData.drawingNum = "DWG-100000";
					prodRevData.drawingNumRev = "AA";
					prodRevData.newBPCSItemNeeded = "1";
					prodRevData.itemID = "100000001";
					prodRevData.itemName = "Fluid Tank";
					prodRevData.itemRevDescription = "Fluid Tank � VW";
					prodRevData.itemRevID = "AA";
					prodRevData.itemRevUID = "aER4535vbD67HJY";
					prodRevData.makeOrBuy = "AX";
					prodRevData.partWeight = "10.5 KG";
					prodRevData.releaseLevel = "F";
					prodRevData.spendType = "0";
					prodRevData.uom = "each";

					//Adding Customer Data:

					std::vector<std::string> partNum;
					partNum.push_back("BUQS0001AAF10");
					partNum.push_back("BUQS0022AAF10");

					TITCERPIntegration::CustomerPartIDMap custPartmap;
					std::pair<std::string,std::vector<std::string>> tempMap = std::pair<std::string,std::vector<std::string>> ("Volkswagen-AG", partNum);
					custPartmap.insert(tempMap);

					TITCERPIntegration::CustomerData custData;
					custData.customerCode = "9567832";
					custData.customerName = "Volkswagen";
					custData.customerPartID = custPartmap;
					prodRevData.customerData.push_back(custData);

					//Adding erppartnumber
					std::vector<std::string> tempVec;
					tempVec.push_back("AQVR0003AAF10");
					tempVec.push_back("AQVR0043AAF10");


					TITCERPIntegration::ERPPartNumbersMap partMap;
					std::pair<std::string,std::vector<std::string>> tempMap1 = std::pair<std::string,std::vector<std::string>> ("BPCS Global", tempVec);
					partMap.insert(tempMap1);

					prodRevData.erpPartNumbers = partMap;

				//product rev data 2
					TITCERPIntegration::ProductRevisionData prodRevData1;
					prodRevData1.bpcsFamilyCode = "YU";
					prodRevData1.bpcsSubFamilyCode = "HJ";
					prodRevData1.designLevel = "AA";
					prodRevData1.drawingNum = "DWG-100200";
					prodRevData1.drawingNumRev = "AA";
					prodRevData1.newBPCSItemNeeded = "1";
					prodRevData1.itemID = "100002201";
					prodRevData1.itemName = "Fluid System";
					prodRevData1.itemRevDescription = "Fluid System - BMW";
					prodRevData1.itemRevID = "AA";
					prodRevData1.itemRevUID = "wQA4535tyU67HJY";
					prodRevData1.makeOrBuy = "AZ";
					prodRevData1.partWeight = "23.5 KG";
					prodRevData1.releaseLevel = "F";
					prodRevData1.spendType = "M";
					prodRevData1.uom = "each";
						//Adding Customer Data:
					std::vector<std::string> partNum1;
					partNum1.push_back("CUTS0001AAF10");
					partNum1.push_back("CUTS0022AAF10");

					TITCERPIntegration::CustomerPartIDMap custPartmap1;
					std::pair<std::string,std::vector<std::string>> tempMap2 = std::pair<std::string,std::vector<std::string>> ("Volkswagen-AG", partNum1);
					custPartmap1.insert(tempMap2);

					TITCERPIntegration::CustomerData custData1;
					custData1.customerCode = "9787836";
					custData1.customerName = "BMW";
					custData1.customerPartID = custPartmap1;
					prodRevData1.customerData.push_back(custData1);

					//Adding erppartnumber
					std::vector<std::string> tempVec1;
					tempVec1.push_back("BQWR0003AAF10");
					tempVec1.push_back("BQWR0043AAF10");


					TITCERPIntegration::ERPPartNumbersMap partMap1;
					std::pair<std::string,std::vector<std::string>> tempMap3 = std::pair<std::string,std::vector<std::string>> ("BPCS Global", tempVec1);
					partMap1.insert(tempMap3);

					prodRevData1.erpPartNumbers = partMap1;

				//prg Variant rev data 1
					TITCERPIntegration::PrgVariantRevisionData prgRevData;
					prgRevData.bpcsFamilyCode = "DF";
					prgRevData.bpcsSubFamilyCode = "SD";
					prgRevData.designLevel = "AA";
					prgRevData.newBPCSItemNeeded = "1";
					prgRevData.itemID = "200004001";
					prgRevData.itemName = "Fluid Tank Program";
					prgRevData.itemRevDescription = "Fluid Tank � PV";
					prgRevData.itemRevID = "AA";
					prgRevData.itemRevUID = "bFG4535jkA67HJY";
					prgRevData.makeOrBuy = "AZ";
					//prgRevData.partWeight = "10.5 KG";
					prgRevData.releaseLevel = "X";
					prgRevData.spendType = "0";
					prgRevData.uom = "each";

					//Adding Customer Data:
					std::vector<std::string> prgpartNum;
					prgpartNum.push_back("DFHJ0001AAF10");
					prgpartNum.push_back("DFHJ0022AAF10");

					TITCERPIntegration::CustomerPartIDMap prgcustPartmap;
					std::pair<std::string,std::vector<std::string>> prgtempMap = std::pair<std::string,std::vector<std::string>> ("Volkswagen-AG", prgpartNum);
					prgcustPartmap.insert(prgtempMap);

					TITCERPIntegration::CustomerData prgcustData;
					prgcustData.customerCode = "8246132";
					prgcustData.customerName = "Volkswagen";
					prgcustData.customerPartID = prgcustPartmap;
					prgRevData.customerData.push_back(prgcustData);
					//Adding erppartnumber
					std::vector<std::string> prgtempVec;
					prgtempVec.push_back("WERT0003AAF10");
					prgtempVec.push_back("WERT0043AAF10");


					TITCERPIntegration::ERPPartNumbersMap prgpartMap;
					std::pair<std::string,std::vector<std::string>> prgtempMap1 = std::pair<std::string,std::vector<std::string>> ("BPCS Global", prgtempVec);
					prgpartMap.insert(prgtempMap1);

					prgRevData.erpPartNumbers = prgpartMap;

				//Material rev data 1
					TITCERPIntegration::MaterialRevisionData matRevData;
					matRevData.bpcsFamilyCode = "RT";
					matRevData.bpcsSubFamilyCode = "FV";
					matRevData.designLevel = "AA";
					matRevData.newBPCSItemNeeded = "1";
					matRevData.itemID = "300002201";
					matRevData.itemName = "Fluid System";
					matRevData.itemRevDescription = "Fluid System - BMW";
					matRevData.itemRevID = "AA";
					matRevData.itemRevUID = "zCV4535tyU67HJY";
					matRevData.makeOrBuy = "AM";
					//prgRevData.partWeight = "10.5 KG";
					matRevData.releaseLevel = "P";
					matRevData.spendType = "M";
					matRevData.uom = "each";

					//Adding Customer Data:
					std::vector<std::string> matpartNum;
					matpartNum.push_back("ERTF0001AAF10");
					matpartNum.push_back("ERTF0022AAF10");

					TITCERPIntegration::CustomerPartIDMap matcustPartmap;
					std::pair<std::string,std::vector<std::string>> mattempMap = std::pair<std::string,std::vector<std::string>> ("BMW-GmbH", matpartNum);
					matcustPartmap.insert(mattempMap);
					TITCERPIntegration::CustomerData matcustData;
					matcustData.customerCode = "7787836";
					matcustData.customerName = "BMW";
					matcustData.customerPartID = matcustPartmap;
					matRevData.customerData.push_back(matcustData);
					//Adding erppartnumber
					std::vector<std::string> mattempVec;
					mattempVec.push_back("AQSD0003AAF10");
					mattempVec.push_back("AQSD0043AAF10");

					TITCERPIntegration::ERPPartNumbersMap matpartMap;
					std::pair<std::string,std::vector<std::string>> mattempMap1 = std::pair<std::string,std::vector<std::string>> ("BPCS Global", mattempVec);

					matpartMap.insert(mattempMap1);
					matRevData.erpPartNumbers = matpartMap;

					//Main Response:
					outputRes.success = true;
					outputRes.affectedPlants = "Germany, Spain";
					outputRes.changeItemNum = "CR-000001";
					outputRes.changeType = "CAP";
					outputRes.productRevisionData.push_back(prodRevData);
					outputRes.productRevisionData.push_back(prodRevData1);
					outputRes.prgVariantRevisionData.push_back(prgRevData);
					outputRes.materialRevisionData.push_back(matRevData);
					outputRes.jobUID = "uMxcE45dFW4324Z";
					outputRes.owningSite = "EU";


					//outputRes = tiPartTransfer(getPartTransferInputs);

		return outputRes;

}


TITCERPIntegrationImpl::GetContractedCostResponse TITCERPIntegrationImpl::importContractedCostInfo ( const GetContractedCostInput& getContractedCostInputs )
{
	TC_write_syslog("getStandardCostInputs ",getContractedCostInputs.contractedCostInputData);
	TITCERPIntegrationImpl::GetContractedCostResponse contractCostRes;
	return contractCostRes;
}


TITCERPIntegrationImpl::GetSellingPriceResponse TITCERPIntegrationImpl::importSellingPriceInfo ( const GetSellingPriceInput& getSellingPriceInputs )
{
	TC_write_syslog("getStandardCostInputs ",getSellingPriceInputs.sellingPriceInputData);
	TITCERPIntegrationImpl::GetSellingPriceResponse sellingPriceRes;
	return sellingPriceRes;
}


TITCERPIntegrationImpl::GetStandardCostResponse TITCERPIntegrationImpl::importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs )
{
	/*TC_write_syslog("getStandardCostInputs ",getStandardCostInputs.standardCostInputData);
	TITCERPIntegrationImpl::GetStandardCostResponse stdCostResponse;

	////TITCERPIntegrationImpl::StandardCostInputData =  getStandardCostInputs.standardCostInputData;

	stdCostResponse = tiStandardCostTransfer(getStandardCostInputs);

	return stdCostResponse;*/


	TITCERPIntegration::GetStandardCostResponse stdCostResponse;
	std::vector<StandardCostInputData>::iterator vcStdCostDataMainIter;

	//Getting StandardCost records from input.
	std::vector<StandardCostInputData> vcStdCostDataMain = getStandardCostInputs.standardCostInputData;

		std::vector<StandardCostInputData>::iterator costDataitr;

	//for( vcStdCostDataMainIter=vcStdCostDataMain.begin();vcStdCostDataMainIter != vcStdCostDataMain.end();vcStdCostDataMainIter++){

		//vector<TIStandardCostData> vcStdCostData = (*vcStdCostDataMainIter).tiStdCostDataMain;
		std::vector<StandardCostInputData> vcStdCostData  = getStandardCostInputs.standardCostInputData;

		for( costDataitr=vcStdCostData.begin();costDataitr != vcStdCostData.end();costDataitr++){
			string sItemID = (*costDataitr).itemID;
			string sBPCSItemID = (*costDataitr).bpcsItemID;
			/*string sItemRevID = (*costDataitr).itemRevID;
			string sCostID = (*costDataitr).costID;
			string sBPCSItemID = (*costDataitr).bpcsItemID;
			string sItemDesc = (*costDataitr).itemDesc;
			string sExtraDesc = (*costDataitr).extraDesc;*/
			logical bExcPartExist = false;
			if(sItemID !=""){
				bExcPartExist = readExclusionPartsList(sItemID);
			}
			else if(sBPCSItemID != ""){
				bExcPartExist = readExclusionPartsList(sBPCSItemID);
			}


			if(bExcPartExist == false){

				vector<StandardCostRecord> vectorTIStandardCostRecord = (*costDataitr).standardCostRecords;

				vector<TIStandardCostRecord> tempStdCostRecords;

				if(vectorTIStandardCostRecord.size() !=0){
					tempStdCostRecords = processStandardCostData(stdCostResponse, *costDataitr);
				}

				//Creating, revising & updating the cost form.
				if(tempStdCostRecords.size() !=0){
					importData(stdCostResponse, (*costDataitr), tempStdCostRecords);
					tempStdCostRecords.clear();
				}
			}else{
				sendResponseInfo(1, stdCostResponse,  PART_EXIST_IN_EXCLUSION_LIST,(*costDataitr).costID,(*costDataitr).itemID,(*costDataitr).itemRevID,(*costDataitr).bpcsItemID);
			}

		}

	//}
		if(stdCostResponse.standardCostResponse.size()!=0){
			char* cSiteName = getCurrentSiteID();
			eMailNotification(stdCostResponse, cSiteName /*  erpSystemName*/);
		}


	return stdCostResponse;
}



