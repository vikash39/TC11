//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAIsDeleteRelationAllowedAdvTech
 *
 */
#include <T8_TIAutoExt/T8_TIAIsDeleteRelationAllowedAdvTech.hxx>

int T8_TIAIsDeleteRelationAllowedAdvTech( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}