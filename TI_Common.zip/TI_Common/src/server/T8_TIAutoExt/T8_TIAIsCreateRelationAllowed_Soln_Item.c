//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAIsCreateRelationAllowed_Soln_Item
 *
 */
#include <T8_TIAutoExt/T8_TIAIsCreateRelationAllowed_Soln_Item.h>

int T8_TIAIsCreateRelationAllowed_Soln_Item( METHOD_message_t *msg, va_list args )
{
 
 return 0;

}