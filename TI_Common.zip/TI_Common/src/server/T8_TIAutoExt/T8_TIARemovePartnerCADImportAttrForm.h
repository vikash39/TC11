//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension T8_TIARemovePartnerCADImportAttrForm
 *
 */
 
#ifndef T8_TIAREMOVEPARTNERCADIMPORTATTRFORM_H
#define T8_TIAREMOVEPARTNERCADIMPORTATTRFORM_H
#include <tccore/method.h>
#include <T8_TIAutoExt/libt8_tiautoext_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern T8_TIAUTOEXT_API int T8_TIARemovePartnerCADImportAttrForm(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif

#include <T8_TIAutoExt/libt8_tiautoext_undef.h>
                
#endif  // T8_TIAREMOVEPARTNERCADIMPORTATTRFORM_H
