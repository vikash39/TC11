//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIARemoveFormAttributeValues
 *
 */
#include <T8_TIAutoExt/T8_TIARemoveFormAttributeValues.h>

int T8_TIARemoveFormAttributeValues( METHOD_message_t *msg, va_list args )
{
 
 return 0;

}