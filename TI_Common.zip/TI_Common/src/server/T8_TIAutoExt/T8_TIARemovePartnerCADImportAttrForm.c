//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIARemovePartnerCADImportAttrForm
 *
 */
#include <T8_TIAutoExt/T8_TIARemovePartnerCADImportAttrForm.h>

int T8_TIARemovePartnerCADImportAttrForm( METHOD_message_t *msg, va_list args )
{
 
 return 0;

}