//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAPartFamilyFormCreation
 *
 */
#include <T8_TIAutoExt/T8_TIAPartFamilyFormCreation.h>

int T8_TIAPartFamilyFormCreation( METHOD_message_t *msg, va_list args )
{
 
 return 0;

}