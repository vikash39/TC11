//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAVerifyPRAAttributeValues
 *
 */
#include <T8_TIAutoExt/T8_TIAVerifyPRAAttributeValues.h>

int T8_TIAVerifyPRAAttributeValues( METHOD_message_t *msg, va_list args )
{
 
 return 0;

}