//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension T8_TIAIsCreateRelationAllowed_Soln_ItemAdvTech
 *
 */
 
#ifndef T8_TIAISCREATERELATIONALLOWED_SOLN_ITEMADVTECH_HXX
#define T8_TIAISCREATERELATIONALLOWED_SOLN_ITEMADVTECH_HXX
#include <tccore/method.h>
#include <T8_TIAutoExt/libt8_tiautoext_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern T8_TIAUTOEXT_API int T8_TIAIsCreateRelationAllowed_Soln_ItemAdvTech(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <T8_TIAutoExt/libt8_tiautoext_undef.h>
                
#endif  // T8_TIAISCREATERELATIONALLOWED_SOLN_ITEMADVTECH_HXX
