//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T8_TICAEAnalysisRevisionMasterImpl
//

#ifndef TI_COMMON__T8_TICAEANALYSISREVISIONMASTERIMPL_HXX
#define TI_COMMON__T8_TICAEANALYSISREVISIONMASTERIMPL_HXX

#include <T8_TIAutoExt/T8_TICAEAnalysisRevisionMasterGenImpl.hxx>

#include <T8_TIAutoExt/libt8_tiautoext_exports.h>


namespace TI_Common
{
    class T8_TICAEAnalysisRevisionMasterImpl; 
    class T8_TICAEAnalysisRevisionMasterDelegate;
}

class  T8_TIAUTOEXT_API TI_Common::T8_TICAEAnalysisRevisionMasterImpl
    : public TI_Common::T8_TICAEAnalysisRevisionMasterGenImpl
{
public:


protected:
    ///
    /// Constructor for a T8_TICAEAnalysisRevisionMaster
    explicit T8_TICAEAnalysisRevisionMasterImpl( T8_TICAEAnalysisRevisionMaster& busObj );

    ///
    /// Destructor
    virtual ~T8_TICAEAnalysisRevisionMasterImpl();

private:
    ///
    /// Default Constructor for the class
    T8_TICAEAnalysisRevisionMasterImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T8_TICAEAnalysisRevisionMasterImpl( const T8_TICAEAnalysisRevisionMasterImpl& );

    ///
    /// Copy constructor
    T8_TICAEAnalysisRevisionMasterImpl& operator=( const T8_TICAEAnalysisRevisionMasterImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TI_Common::T8_TICAEAnalysisRevisionMasterDelegate;

};

#include <T8_TIAutoExt/libt8_tiautoext_undef.h>
#endif // TI_COMMON__T8_TICAEANALYSISREVISIONMASTERIMPL_HXX
