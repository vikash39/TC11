//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAIsCreateRelationAllowedAdvTech
 *
 */
#include <T8_TIAutoExt/T8_TIAIsCreateRelationAllowedAdvTech.hxx>

int T8_TIAIsCreateRelationAllowedAdvTech( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}