//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAPopulateChangeTimingForm
 *
 */
#include <T8_TIAutoExt/T8_TIAPopulateChangeTimingForm.hxx>

int T8_TIAPopulateChangeTimingForm( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}