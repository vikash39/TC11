//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T8_TIAIsDeleteRelationAllowed_Soln_ItemAdvTech
 *
 */
#include <T8_TIAutoExt/T8_TIAIsDeleteRelationAllowed_Soln_ItemAdvTech.hxx>

int T8_TIAIsDeleteRelationAllowed_Soln_ItemAdvTech( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}