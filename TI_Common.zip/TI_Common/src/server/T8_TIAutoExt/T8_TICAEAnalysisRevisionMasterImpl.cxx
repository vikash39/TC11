//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T8_TICAEAnalysisRevisionMasterImpl
//

#include <T8_TIAutoExt/T8_TICAEAnalysisRevisionMasterImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace TI_Common;

//----------------------------------------------------------------------------------
// T8_TICAEAnalysisRevisionMasterImpl::T8_TICAEAnalysisRevisionMasterImpl(T8_TICAEAnalysisRevisionMaster& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T8_TICAEAnalysisRevisionMasterImpl::T8_TICAEAnalysisRevisionMasterImpl( T8_TICAEAnalysisRevisionMaster& busObj )
   : T8_TICAEAnalysisRevisionMasterGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T8_TICAEAnalysisRevisionMasterImpl::~T8_TICAEAnalysisRevisionMasterImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T8_TICAEAnalysisRevisionMasterImpl::~T8_TICAEAnalysisRevisionMasterImpl()
{
}

//----------------------------------------------------------------------------------
// T8_TICAEAnalysisRevisionMasterImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T8_TICAEAnalysisRevisionMasterImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T8_TICAEAnalysisRevisionMasterGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


