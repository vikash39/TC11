
# ifndef TD_BW_GET_REAPIR_COMPONENTS_H
# define TD_BW_GET_REAPIR_COMPONENTS_H

#include <common/teradyne_common.h>
#include <common/teradyne_constants.h>
#include "teradyne_operations_exports.h"
#include <common/TeradyneUtils.hxx>

#ifdef __cplusplus
extern "C" {
#endif
	
	//This function will get runtime property value for amount 
	TERADYNE_OPERATION_EXPORT int td_bw_get_repair_components_execute(tag_t tRepairOrderRev, vector<tag_t> &vRepairComponents, vector<int> &vIsNull);

	//This function will get runtime property value for amount 
	TERADYNE_OPERATION_EXPORT int td_bw_get_repair_orders_execute(tag_t tCustomerRev, vector<tag_t> &vRepairOrders, vector<int> &vIsNull);

	//This function will get runtime property value for amount
	TERADYNE_OPERATION_EXPORT int td_bw_get_solution_configs_execute(tag_t tPartSerialNumRev, vector<tag_t> &vSolutionConfigs, vector<int> &vIsNull);

	//This function will get runtime property value for amount
	TERADYNE_OPERATION_EXPORT int td_bw_get_incoming_configs_execute(tag_t tPartSerialNumRev, vector<tag_t> &vIncomingConfigs, vector<int> &vIsNull);
#ifdef __cplusplus
}
#endif

#endif 

