# ifndef TD_BW_REPAIR_GROUP_CREATION
# define TD_BW_REPAIR_GROUP_CREATION

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

	// complete debug and repair task
	TERADYNE_SERVICE_EXPORT char* repair_group_creation(string repairGroupName, string repairLocation);

#ifdef __cplusplus
}
#endif

#endif 