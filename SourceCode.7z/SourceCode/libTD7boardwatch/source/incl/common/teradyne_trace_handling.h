/*!
* \defgroup Common
* @{
*/
/*!
* \defgroup Tracing
* @{

The following set of environment variables (those in [] are optional) control whether 
tracing is performed at all and if so, to what extend and to where the tracing output is 
written:

\par [TERADYNE_TRACE]  		
\verbatim		        		
Setting up this environment variable will turn on the tracing and level will be set.
If not existing, tracing is not turned on.
Values
0  : No tracing
1  : Traces only functions In/Out
2  : Traces function In/Out and arguments(TERADYNE_TRACE_ARGS() and TERADYNE_TRACE_TC_OBJECT())
3  : Tracing everything including itk calls(TERADYNE_TRACE_CALL())
ON : same as 3		
\endverbatim
Example: set TERADYNE_TRACE=3
\image html trace3.jpg

<BR>

\par [TERADYNE_TRACE_METHOD]
\verbatim
Defines the target for the tracing output.
Valid values:
OUTSTREAM : output goes to the TAO console window
SYSLOG    : output goes to the syslog file
JOURNAL   : output goes to the journal file
Any string other than the above : tracing is turned off
If not existing, SYSLOG is the default
\endverbatim
Example: set TERADYNE_TRACE_METHOD=JOURNAL
\image html traceMethod.jpg

<BR>

\par [TERADYNE_TRACE_PREFIX]
\verbatim		
String which precedes each line of tracing output
If not existing, no prefix will be prepended
\endverbatim
Example: set TERADYNE_TRACE_PREFIX=AP4
\image html tracePrefix.jpg

<BR>

\par [TERADYNE_TRACE_INDENT]
\verbatim
Number >= 0
Used for indention of output lines in order to illustrate function calling hierarchy.
If not convertible or < 0 : tracing is turned off.
If not existing, 2 is the default
\endverbatim
Example:
\image html traceIndentationExample.jpg

<BR>

\par [TERADYNE_TRACE_FILELINE]
\verbatim
This defines the amount of path/filename/linenumber information to be appended to the output of the macros TERADYNE_TRACE_CALL, 
TERADYNE_TRACE_ENTER,P4_TRACE_LEAVE and TERADYNE_TRACE_LEAVE_RVAL. 
Valid values:
NO : no path/filename/linenumber information
SHORT : filename/linenumber information
LONG : path/filename/linenumber information
any string other than the above : tracing is turned off
If not existing, NO is the default.		 
\endverbatim 
Example: set TERADYNE_TRACE_FILELINE=LONG
\image html traceFileline.jpg

<BR>

\par Turning tracing ON/OFF from Portal
\verbatim
In production environment tracing noramlly set to off for performance and memory reasons.
User can turn tracing on during the running session using following dialog.				
\endverbatim
Edit -> Options -> Siemens -> Trace Options
\image html tracingFromPortal.jpg
<BR>
<BR>
<BR>

The following set of macros (in teradyne_trace_handling.h) allow for runtime tracing
using the functions herein.

*/
/**
@}
*/

/*!
* \defgroup ErrorHandling
* @{
* \verbatim
This module contails functions and macros to throw and log errors and warnings.
All functions should return 'int' which is error code.
For all functions the Business logic should be written in try-catch block.
Use macros 'TERADYNE_LOG_ERROR_AND_THROW_STATUS' and 'TERADYNE_LOG_ERROR' properly.
Where it is needed to proceed to next operation in case of error use nested try-catch block.
All macros should be used after function call:
e.g.
TERADYNE_TRACE_CALL( iStatus = POM_refresh_instances_any_class( iNumPSobj, tpPSObjs, POM_modify_lock ) );
TERADYNE_LOG_ERROR;
\endverbatim
*/
/**
@}
*/	

/*!
* \defgroup Common
* @{
*/
/*!
* \defgroup StringUtil
* @{
* \verbatim
String utility functions for String operations.
\endverbatim
*/
/**
@}
*/	
/**
@}
*/	
/**
@}
*/

/**
*\file teradyne_trace_handling.h

*\par Since: 
Release1
*\par ENVIRONMENT :
C, ITK

*\par Owner:
Chetan Kekade

*\par History: 
Date          Name				Description of Change
---------------------------------------------------------------------------------------------------------
12-may-2016   Chetan Kekade		Initial Creation

---------------------------------------------------------------------------------------------------------
*/
#ifndef TERADYNE_TRACE_HANDLING_H_INCLUDED
#define TERADYNE_TRACE_HANDLING_H_INCLUDED 

#include "teradyne_common.h"
#include "teradyne_error_handling.h"
#include "teradyne_constants.h"

#ifdef __cplusplus
extern "C" {
#endif

	enum eTERADYNETraceMethods { 
		/** undefined */          UNKNOWN_TRACE_METHOD ,  
		/** TAO console window */ OUTSTREAM_TRACE_METHOD ,
		/** syslog file */        SYSLOG_TRACE_METHOD ,
		/** journal file */       JOURNAL_TRACE_METHOD } ;



	enum eTERADYNETraceFileLines {
		/** undefined */                                     UNKNOWN_TRACE_FILELINE , 
		/** no */                                            NO_TRACE_FILELINE , 
		/** only file name and line number */                SHORT_TRACE_FILELINE ,
		/** path specification, file name and line number */ LONG_TRACE_FILELINE } ;


	typedef struct teradyne_trace_options {
		/** true or false if tracing is on or off */
		int							bTERADYNETraceIsOn ; 
		/** output target: outstream, syslog or journal */
		enum eTERADYNETraceMethods		eTERADYNETraceMethod ;
		/** string, if any, that prefixes every tracing line */
		char							*pcTERADYNETracePrefix ;
		/** number of characters for line indention in- an decrement */
		int								iTERADYNETraceIndentIncr ;
		/** current number of characters for line indention in- an decrement */
		int								iTERADYNETraceIndention ;
		/** filename/linenumber info appended: none, short(only filename and linenumber) or long (path, filename and linenumber) */
		enum eTERADYNETraceFileLines		eTERADYNETraceFileLine ;
	} teradyne_trace_options_t ;

#include <mld/journal/journal.h>

#define FILELINELENGTH 2028
#define FORMATLENGTH 1024

	TERADYNECOMEXP int teradyne_trace_handling_is_on ( 
		void ) ; 

	TERADYNECOMEXP void teradyne_trace_args ( 
		const char	* pcFmtStr ,
		... ) ;

	TERADYNECOMEXP void teradyne_write_syslog (
		const char	* pcFmtStr	,
		va_list		pArgs ) ;

	TERADYNECOMEXP void teradyne_alter_indent (
		const char	cChange ) ;

	TERADYNECOMEXP void teradyne_make_fileline (
		const char	* pcFile ,
		const int   iLine ,
		char	cFileLine[FILELINELENGTH+1] ) ;

	TERADYNECOMEXP enum eTERADYNETraceMethods teradyne_trace_method (
		void ) ;

	TERADYNECOMEXP void teradyne_trace_get_options ( 
		teradyne_trace_options_t		* ptTERADYNETraceOptions ) ; 

	TERADYNECOMEXP void teradyne_trace_set_options ( 
		const teradyne_trace_options_t	tTERADYNETraceOptions ) ; 

	TERADYNECOMEXP void teradyne_log_local_time(void);

	TERADYNECOMEXP void teradyne_log_current_time(void);


	TERADYNECOMEXP char * teradyne_TRACE_object (
		const tag_t		objectTag ) ;


#define TERADYNE_TRACE_AND_THROW(function) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 3 ) \
	{ \
	char * pc = NULL ; \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	pc=(char*)strchr(#function,'=');if(pc){do pc++;while(*pc==' ');}else pc=#function;\
	teradyne_log_local_time();\
	TC_write_syslog("   [INFO]   ");\
	teradyne_trace_args ( " %s %s" , pc , cFileLine ) ; \
	} \
	( iStatus = function) ; \
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	throw iStatus;\
	}\
	} while(0)

	/**
	*\file teradyne_trace_handling.h
	*\ingroup Tracing
	*\par Description:
	Traces the call to an ITK or custom function when value for TERADYNE_TRACE is set to '3'.
	Each function should be embedded inside this macro.

	*/
	#define TERADYNE_TRACE_AND_LOG(function) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 3 ) \
	{ \
	char * pc = NULL ; \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	pc=(char*)strchr(#function,'=');if(pc){do pc++;while(*pc==' ');}else pc=#function;\
	teradyne_log_local_time();\
	TC_write_syslog("   [INFO]   ");\
	teradyne_trace_args ( " %s %s" , pc , cFileLine ) ; \
	} \
	( iStatus = function) ; \
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	}\
	} while(0)
	
	/**
	*\ingroup Tracing
	*\par Description:
	Traces the call to an ITK or custom function when value for TERADYNE_TRACE is set to '3'.
	Each function that you dont want to be throwing an exception should be embedded inside this macro.
	<BR>
	Example:
	\image html traceCallCode.jpg
	<BR>
	Output in syslog:
	\image html traceCallExample.jpg
	*/
#define TERADYNE_TRACE_CALL(function) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 3 ) \
	{ \
	char * pc = NULL ; \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	pc=(char*)strchr(#function,'=');if(pc){do pc++;while(*pc==' ');}else pc=#function;\
	teradyne_log_local_time();\
	TC_write_syslog("   [INFO]   ");\
	teradyne_trace_args ( " %s %s" , pc , cFileLine ) ; \
	} \
	(function) ; \
	} while(0)

	/**
	*\ingroup Tracing
	*\par Description:
	*\verbatim
	Traces the entry in a function when TERADYNE_TRACE is set to 1/2/3,
	e.g.
	int myFunctionName ( ... )
	{
	TERADYNE_TRACE_ENTER();
	...
	\endverbatim	
	<BR>
	\image html traceEnterCode.jpg
	<BR>
	Output in syslog:
	\image html traceEnterExample.jpg
	\verbatim
	Note that TERADYNE_TRACE_ENTER() requires a character variable named
	__function__ which holds the function's name!
	\endverbatim
	*/
#define TERADYNE_TRACE_ENTER() \
	do { \
	const char * __function__ = __FUNCTION__;\
	if ( teradyne_trace_handling_is_on() >= 1 ) \
	{ \
	if ( teradyne_trace_method () == JOURNAL_TRACE_METHOD ) { \
	JOURNAL_routine_start ( __function__ ) ; \
	JOURNAL_routine_call () ; \
	} \
		else { \
		char cFileLine[FILELINELENGTH+1] = "" ; \
		teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
		teradyne_log_local_time();\
		TC_write_syslog("   [FNIN]   ");\
		teradyne_trace_args ( "> %s() %s" , __function__ , cFileLine ) ; \
		teradyne_alter_indent ( '+' ) ; \
	} \
	} \
	} while(0)


	/**
	*\ingroup Tracing
	*\par Description:
	*\verbatim
	Traces the exit in a function when TERADYNE_TRACE is set to 1/2/3, 
	e.g.
	int myFunctionName ( ... )
	{

	TERADYNE_TRACE_LEAVE();
	return ... ;
	}
	\endverbatim
	\image html traceLeaveCode.jpg
	<BR>
	Output in syslog:
	\image html traceLeaveExample.jpg
	<BR>
	\verbatim
	Note that TERADYNE_TRACE_LEAVE() requires a character variable named
	__function__ which holds the function's name!
	\endverbatim
	*/
#define TERADYNE_TRACE_LEAVE() \
	do { \
	const char * __function__ = __FUNCTION__;\
	if ( teradyne_trace_handling_is_on() >= 1 ) \
	{ \
	if ( teradyne_trace_method () == JOURNAL_TRACE_METHOD ) { \
	int iTERADYNETraceStatus_TBD = 0 ; \
	JOURNAL_return_value ( iTERADYNETraceStatus_TBD ) ; \
	JOURNAL_routine_end () ; \
	} \
		else { \
		char cFileLine[FILELINELENGTH+1] = "" ; \
		teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
		teradyne_alter_indent ( '-' ) ; \
		teradyne_log_local_time();\
		TC_write_syslog("   [FNOUT]  ");\
		teradyne_trace_args ( "< %s() %s" , __function__ , cFileLine ) ; \
	} \
	} \
	} while(0)


	/**
	*\ingroup Tracing
	*\par Description:
	\verbatim
	Traces the exit in a function along with a return value when TERADYNE_TRACE is set to 1/2/3.
	e.g.
	int myFunctionName ( ... )
	{
	int retval = 0 ;
	...
	TERADYNE_TRACE_LEAVE_RVAL("%d",retval);
	return retval ;
	}       
	\endverbatim
	\image html traceLeaveRVALCode.jpg
	<BR>
	Output in syslog:

	\verbatim
	Note that TERADYNE_TRACE_LEAVE_RVAL() requires a character variable named
	__function__ which holds the function's name!
	\endverbatim
	*/
#define TERADYNE_TRACE_LEAVE_RVAL(fmt,rval) \
	do { \
	const char * __function__ = __FUNCTION__;\
	if ( teradyne_trace_handling_is_on() >= 1 ) \
	{ \
	if (teradyne_trace_method () == JOURNAL_TRACE_METHOD ) { \
	int iTERADYNETraceStatus_TBD = 0 ; \
	JOURNAL_return_value ( iTERADYNETraceStatus_TBD ) ; \
	JOURNAL_routine_end () ; \
	} \
		else { \
		char cFormat[FORMATLENGTH+1] = "" ; \
		char cFileLine[FILELINELENGTH+1] = "" ; \
		teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
		teradyne_alter_indent ( '-' ) ; \
		sprintf ( cFormat ,"< %s() returns %s %s" , __function__ , fmt , cFileLine ) ; \
		teradyne_log_local_time();\
		TC_write_syslog("   [FNOUT]  ");\
		teradyne_trace_args ( cFormat , rval ) ; \
	} \
	} \
	} while(0)


	/**
	*\ingroup Tracing
	*\par Description:
	Traces any type of function arguments when value for TERADYNE_TRACE is set to 2 or 3,
	arguments should be separated by '|'. 
	<BR>
	Example:
	\image html traceARGSCode.jpg
	<BR>
	Output in syslog:
	\image html traceARGSEG.jpg
	\verbatim
	Note that because of the macro mechanics the argument(s) to 
	TERADYNE_TRACE_args((arg))must be enclosed in double brackets!
	\endverbatim
	*/
#define TERADYNE_TRACE_ARGS(arg) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 2 ) \
	{ \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	teradyne_trace_args ( "%s" , cFileLine ) ; \
	teradyne_log_local_time();\
	TC_write_syslog("   [ARGS]   ");\
	teradyne_trace_args arg ; \
	} \
	} while(0)


	/**
	*\ingroup Tracing
	*\par Description:
	*\verbatim
	Traces object when value for TERADYNE_TRACE is set to 2 or 3, input should be tag_t.
	\endverbatim
	<BR>
	Example:
	\image html traceObjCode.jpg
	<BR>
	Output in syslog:
	\image html traceObjExample.jpg
	*/
#define TERADYNE_TRACE_TC_OBJECT(arg) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 2 ) \
	{ \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	teradyne_trace_args ( "%s" , cFileLine ) ; \
	teradyne_log_local_time();\
	TC_write_syslog("   [OBJ]    ");\
	char* objectTrace = teradyne_TRACE_object( arg ); \
	teradyne_trace_args (objectTrace) ; \
	} \
	} while(0)


	/**
	*\ingroup Tracing
	*\par Description:
	*\verbatim
	Traces any type of output just like printf when TERADYNE_TRACE is set to 3.
	\endverbatim
	<BR>
	Example:
	\image html traceDgbCode.jpg
	<BR>
	Output in syslog:
	\image html traceDgbExample.jpg
	<BR>
	\verbatim
	Note that because of the macro mechanics the argument(s) to 
	TERADYNE_TRACE_args((arg))must be enclosed in double brackets!

	\endverbatim
	*/
#define TERADYNE_TRACE_DGB(arg) \
	do { \
	if ( teradyne_trace_handling_is_on() >= 3 ) \
	{ \
	char cFileLine[FILELINELENGTH+1] = "" ; \
	teradyne_make_fileline ( (const char*)__FILE__ , __LINE__ , cFileLine ) ; \
	teradyne_trace_args ( "%s" , cFileLine ) ; \
	teradyne_log_local_time();\
	TC_write_syslog("   [INFO]   ");\
	teradyne_trace_args arg ; \
	} \
	} while(0)



#define TERADYNE_TRACE_ERRORS(arg) \
	do { \
	teradyne_log_local_time();\
	TC_write_syslog("   [ERROR]  ");\
	teradyne_trace_args arg ; \
	} while(0)

/**
*\file teradyne_trace_handling.h
*\ingroup Tracing
*\par Description:
Traces the call to an ITK or custom function when return is not 0.
Each function should be embedded inside this macro.
* \verbatim
Date         	Name					Description of Change
--------------------------------------------------------------------------------
08-Aug-2018     Kumar Chetan			Intial creation
--------------------------------------------------------------------------------
\endverbatim
*/
#define TERADYNE_LOG_THROW_ERROR(func){\
	if((iStatus = (func) ) != ITK_ok){\
	char* error_str = NULL;\
	EMH_ask_error_text(iStatus, &error_str);\
	TC_write_syslog ("TERADYNE_ERROR: %d ERROR MSG: %s. Error in line %d, function %s\n",\
	iStatus, error_str, __LINE__, __FUNCTION__);\
	MEM_free(error_str);\
	error_str = NULL;\
	throw iStatus; \
	}\
	}

#ifdef __cplusplus
}
#endif


#endif // #ifndef TERADYNE_TRACE_HANDLING_H_INCLUDED

