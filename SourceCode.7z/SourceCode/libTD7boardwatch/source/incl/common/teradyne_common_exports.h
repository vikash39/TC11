
#ifndef TERADYNE_COMMON_EXPORTS_H
#define TERADYNE_COMMON_EXPORTS_H


#ifdef _WIN32
#ifdef _LOAD_FROM_EXTERNAL
#define TERADYNECOMEXP extern __declspec(dllimport)
#else
#define TERADYNECOMEXP extern __declspec(dllexport)
#endif
#ifdef _LOAD_FROM_EXTERNAL
#define TERADYNECOMEXPCLASS __declspec(dllimport)
#else
#define TERADYNECOMEXPCLASS __declspec(dllexport)
#endif
#else
#define TERADYNECOMEXP extern
#define TERADYNECOMEXPCLASS
#endif

#endif  //TERADYNE_COMMON_EXPORTS_H
