# ifndef TERADYNE_WORKFLOWS_H
# define TERADYNE_WORKFLOWS_H


#include <common/teradyne_common.h>
#include <common/teradyne_common_exports.h>
#include <common/teradyne_constants.h>
#include <common/teradyne_error_handling.h>
#include <common/teradyne_trace_handling.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_workflows_exports.h"
#include <extensions/teradyne_extensions.h>
#include  <fclasses\OSFile.hxx>
//#include <windows.h>

class WVSCompareResult;

#include <iostream>
#include <fstream>
#include <cstdio>
#include <map>
#include <string>
#include <vector>

using namespace std;
using namespace Teamcenter;
using namespace TERADYNE::COMMON;

#ifdef __cplusplus
extern "C" {
#endif

	typedef std::vector<WVSCompareResult> vec_wvsresult_t;
	typedef std::unordered_map<std::string, WVSCompareResult>  map_wvsresult_t;

	//Extension to update TC project on creation of HasParticipant relation.
	TERADYNE_WORKFLOW_EXPORT int libTD7boardwatch_register_callbacks();

	//Extension to update TC project on deletion of HasParticipant relation.
	TERADYNE_WORKFLOW_EXPORT int teradyne_register_handlers(int* decision, va_list args);


	//Action handler to update created by attribute on TD7RepairConfigCSV.
	TERADYNE_WORKFLOW_EXPORT int repair_config_uploader_workflow(EPM_action_message_t msg);

	//Action handler to update created by attribute on TD7RepairConfigCSV.
	TERADYNE_WORKFLOW_EXPORT int td7_assign_tc_projects_team_to_debug_and_repair(EPM_action_message_t msg);

	//Action handler to export LLA part number.
	TERADYNE_WORKFLOW_EXPORT int td7_export_lla_part_number(EPM_action_message_t msg);

	//Action handler to export PLMXML.
	TERADYNE_WORKFLOW_EXPORT int plmxml_export_and_attach_to_target_execute(EPM_action_message_t msg);

	//Action handler to generate multiple checklists revisions.
	TERADYNE_WORKFLOW_EXPORT int td7_generate_checklists_revisions_execute(EPM_action_message_t msg);

	//Action handler to validate logged in user based on location.
	TERADYNE_WORKFLOW_EXPORT int td7_validate_user_location_execute(EPM_action_message_t msg);

	//Action handler to set solution config's as "Repaired".
	TERADYNE_WORKFLOW_EXPORT int td7_set_solutionconfig_to_repaired_execute(EPM_action_message_t msg);

	//Action handler to set solution config's as "Scrapped".
	TERADYNE_WORKFLOW_EXPORT int td_bw_actionhandler_to_set_config_objects_to_scrapped_execute(EPM_action_message_t msg);

	//Action handler to assign custom participants.
	TERADYNE_WORKFLOW_EXPORT int td_bw_actionhandler_to_assign_custom_participants_execute(EPM_action_message_t msg);

	//Action handler to assign custom participants.
	TERADYNE_WORKFLOW_EXPORT int td_bw_actionhandler_to_send_email_after_approve_on_hold_request_execute(EPM_action_message_t msg);

	// helper funtions
	// Helper function for action handler : repair_config_uploader_workflow
	//int split_input_values ( string sStrToSplit,vector<string> &vSplittedValues );

	// Helper function for action handler : repair_config_uploader_workflow
	int read_record_import_repairconfigcsv(string sRepairOrderNumber, vector<string> inputValues);

	// Helper function for action handler : repair_config_uploader_workflow
	//int td7_override_part_serial_relation_create_post(tag_t tLLApartNumber, tag_t tPrimaryObject, tag_t tSecondaryObject);

	// Helper function for action handler : repair_config_uploader_workflow
	//int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev);

	// Helper function for action handler : repair_config_uploader_workflow
	//int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev);

	// Helper function for action handler : repair_config_uploader_workflow
	int traverse_BOM_import_repairconfigcsv(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound);

	// Helper function for action handler : repair_config_uploader_workflow
	//int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj);

	// Helper function for action handler : repair_config_uploader_workflow
	//int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	// Helper function for action handler : repair_config_uploader_workflow
	int is_psn_attched_with_lla_import_repairconfigcsv(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound);

	// Helper function for action handler : repair_config_uploader_workflow
	//int teradyne_create_solution_config(string sItemdId, tag_t tRepairOrderRev, tag_t &tNewlyCreatedObj);

	// Helper function for action handler : repair_config_uploader_workflow
	//int revise_object(tag_t tItem, tag_t& tItemReviseTag);

	// Helper function for action handler : td7_assign_tc_projects_team_to_debug_and_repair
	int assign_project_team_wf(tag_t tRepairOrderRev, tag_t tHLAPartRev);

	// Helper function for action handler : td7_assign_tc_projects_team_to_debug_and_repair
	//int query_item(string sItemId, string sType, int iCount, tag_t& tItemRev);

	// Helper function for action handler : td7_assign_tc_projects_team_to_debug_and_repair
	int assign_project_team_members_into_signoff_wf(tag_t tRepairOrderRev, tag_t tProjectTag);

	// Helper function for action handler : td7_export_lla_part_number
	int export_property_values_into_csv(tag_t tLLAPartRev);

	// Helper function for action handler : td7_export_lla_part_number
	//int teradyne_split(std::string str, char delimiter, std::vector<std::string> &vResult);

	// Helper function for action handler : td7_generate_checklists_revisions
	int validate_engg_evaluation_checklists_revisions(tag_t tRepairOrderRev);

	// Helper function for action handler : td7_generate_checklists_revisions
	int update_sender_value_from_previous_task(tag_t tRepairOrderRev, string comments);

	// Helper function for action handler : td7_generate_checklists_revisions
	int validate_debug_and_repair_checklists_revisions(tag_t tRepairOrderRev);

	// Helper function for action handler : td7_generate_checklists_revisions
	int validate_rework_checklists_revisions(tag_t tRepairOrderRev);

	// Helper function for action handler : td7_generate_checklists_revisions
	int validate_final_inspection_checklists_revisions(tag_t tRepairOrderRev);

	// Helper function for action handler : td7_generate_checklists_revisions
	int generate_checklists_revisions_while_running_workflow(tag_t tRepairOrderRev, int iRepairCount,
		int iRepairVerificationCount, int iPostTestCount);

	// Helper function for action handler : td7_generate_checklists_revisions
	//int create_checklist_form(tag_t tRepairOrderRev, string tFormType, string sObjName, string sFormName);

	// Helper function for action handler : td7_generate_checklists_revisions
	//int set_as_older_versions_for_checklists(tag_t tPrimaryObj, string sRelation, string tFormType);

	// Helper function for action handler : td7_generate_checklists_revisions
	//int teradyne_dataset_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	// Helper function for action handler : td7_generate_checklists_revisions
	void create_batch(std::string pathName, std::string fileName);

	int teradyne_delete_relation(tag_t tPrimary, tag_t tSecondary, const char* strRelTypeName);

	// Helper function for action handler : td_bw_actionhandler_to_send_email_after_approve_on_hold_request
	int send_email_task_is_approved(tag_t tcurrentTask, tag_t tRepairOrderRev);

	// Helper function for action handler : td_bw_actionhandler_to_send_email_after_approve_on_hold_request
	string generate_mail_body(tag_t tRepairOrderRev, tag_t tcurrentTask);

	// Helper function for action handler : td_bw_actionhandler_to_set_config_objects_to_scrapped_execute
	int set_solution_objects_to_scrapped(int tRepairOrderRev, string relationType);

	int set_config_objects_to_repaired(int tRepairOrderRev, string relationType);

	class WVSCompareResult
	{
	private:

		bool bIsNewObject;

	public:

		void setNewObject(bool);
		bool getNewObject();


	};

#ifdef __cplusplus
}
#endif

#endif //TERADYNE_WORKFLOWS_H