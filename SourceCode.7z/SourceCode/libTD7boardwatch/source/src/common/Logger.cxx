
#include <common/Logger.hxx>

using namespace TERADYNE::COMMON;

int Logger::validateLogFilePath(string sInputLogPath, string sFormat)
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		if( sInputLogPath.empty() || sFormat.empty() )
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919238 );	
		}
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int Logger::createLogFile(string sFileNameWithoutExt, string sFileFormat)
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		validateLogFilePath(sFileNameWithoutExt,sFileFormat);

		DateTime now;
		string tmpPath = OSEnvironment::get("TEMP");

		sLogFileName = sFileNameWithoutExt;
		sLogFileFormat = sFileFormat;
		sAbsLogFilePath = tmpPath + "\\" + sLogFileName + '.' + sLogFileFormat;
		TC_write_syslog("\n Logger file path for file %s is : %s\n",sLogFileName.c_str(),sAbsLogFilePath.c_str());
		ofsTransLogFile.open(sAbsLogFilePath, ofstream::out | ofstream::trunc);
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int Logger::getLogAbsoluteFilePath(string &sAbsoluteFilePath)
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		sAbsoluteFilePath = sAbsLogFilePath;
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int Logger:: getLogDataset(tag_t &tinputDataset)
{

	int iStatus = NULLTAG;
	int iRefCount = 0;
	char** cpRefList = NULL;
	char* cpRefName = NULL;
	TERADYNE_TRACE_ENTER();
	try
	{
		// create temp folder for file i/o

		tag_t tdatasettype = NULLTAG ;
		TERADYNE_TRACE_AND_THROW(AE_find_datasettype2( sLogFileFormat.c_str(), &tdatasettype ) );
		TERADYNE_TRACE_AND_THROW(AE_create_dataset_with_id(tdatasettype, sLogFileName.c_str(), NULL, NULL, NULL, &tDataset )); 
		TERADYNE_TRACE_AND_THROW(AE_ask_datasettype_refs (tdatasettype, &iRefCount, &cpRefList) );

		if(iRefCount > 0)
		{
			cpRefName = cpRefList[0];

			TERADYNE_TRACE_AND_THROW(AE_import_named_ref( tDataset, cpRefName,sAbsLogFilePath.c_str(), NULL, SS_TEXT ) ) ;

			TERADYNE_TRACE_AND_THROW(AOM_save( tDataset) );
			TERADYNE_TRACE_AND_THROW(AOM_refresh( tDataset, false) );
			tinputDataset = tDataset;
		}
		else
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919237 );	
		}
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int Logger::closeLog()
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		// Close the filestream
		this->ofsTransLogFile.close();
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

Logger::~Logger()
{
	std::remove(sAbsLogFilePath.c_str());
};