
#include <common/LogManagement.h>
#include <common/teradyne_trace_handling.h>

//extern vector<string> vheader;
//extern LogMangement logObj;

using namespace TERALOG;
LogMangement logObj;

int LogMangement::teradyne_openLogFile(string logFilePath)
{
	int iStatus = ITK_ok;
	logObj.logfile.open(logFilePath, fstream::app);
	if(logObj.logfile.is_open())
	{
		iStatus = ITK_ok;
	}
	else
	{
		iStatus = 0;
	}
		return iStatus;
}

void LogMangement::teradyne_writeToLogFile(string sMsgType,string sMsg, string sItemId, string sAction)
{

	

	string emptyStr="";
	if(sMsgType == "ERROR" ){
		
		string dateandtime= logObj.teradyne_getDateandTime();
		string sLogstring =emptyStr+"[ERROR] : " + sMsg + " " " " + sItemId + " " " " + sAction;
		logObj.logfile<<dateandtime<< sLogstring <<endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
		std::cout << "\n " << sLogstring << endl;
	
	}
	if(sMsgType == "INFO" ){
		
		string dateandtime= logObj.teradyne_getDateandTime();
		string sLogstring =emptyStr+"[INFO] : " + sMsg + " " " " + sItemId + " " " " + sAction;
		logObj.logfile<<dateandtime<< sLogstring <<endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
		std::cout << "\n " << sLogstring << endl;
	}
	if(sMsgType == "FAILED" ){
		
		string sDateandtime= logObj.teradyne_getDateandTime();
		string sLogstring="[FAILED] : "+ sMsg +" " " "+ sItemId + " " " " + sAction;
		logObj.logfile<<sDateandtime<<sLogstring<<endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
		std::cout << "\n " << sLogstring << endl;
	}
	if(sMsgType == "SUCCESS" ){
		
		string sDateandtime= logObj.teradyne_getDateandTime();
		string sLogstring="[SUCCESS] : " + sMsg + " " " " + sItemId + " " " " + sAction;
		logObj.logfile<<sDateandtime<<sLogstring<<endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
		std::cout << "\n " << sLogstring << endl;
	}
	
	if(sMsgType.compare("")==0|| sMsgType.compare(" ")==0){
	
		logObj.logfile<<"---------------------------------------------------------------------------------------------------"<<endl;
	}
}

string LogMangement::teradyne_getDateandTime()
{
	_strdate_s(sdate);
	_strtime_s(stime);
	string dateandtime=" ";
	dateandtime.append(sdate);
	dateandtime.append("_");
	dateandtime.append(stime);
	return dateandtime;
}