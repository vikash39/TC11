
#include <common/Logger.hxx>
#include <common/HTMLLogger.hxx>

// constructor
HTMLLogger::HTMLLogger(string sFileNameWithoutExt)
{    
	Logger::createLogFile(sFileNameWithoutExt, "HTML");
	Logger::ofsTransLogFile << "<html> <head/> <body>";
}

int HTMLLogger::addLogHeader(vector<string> logHeader)
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		// Open Html headers
		char del =':';
		for(int inx = 0;inx < logHeader.size(); inx++)
		{
			vector<string> vLableValue;
			//TERADYNE_TRACE_AND_THROW(TeradyneUtils::teradyne_split( logHeader[inx], del, vLableValue) );
			TERADYNE_TRACE_AND_THROW(teradyne_split(logHeader[inx], del, vLableValue));
			if( vLableValue.size() == 2 )
			{	
				Logger::ofsTransLogFile << "<p><b style='font-weight:bold;'>"<< vLableValue[0]<<"     : </b>" << vLableValue[1] << "</p>" ;
			}
			else
			{
				TERADYNE_TRACE_AND_THROW( ERROR_919239 );
			}
		}
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int HTMLLogger::addRowData(vector<string> rowData)
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		Logger::ofsTransLogFile << "<tr>";
		for(int idnx = 0;idnx < rowData.size(); idnx++)
		{				 		
			Logger::ofsTransLogFile << "<td style='text-align:center;border:1px solid black;border-collapse:collapse;'>" << rowData[idnx] << "</td>";				
		}
		Logger::ofsTransLogFile << "</tr>";

	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int HTMLLogger::addColumnData(vector<string> columnHeaders )
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{
		Logger::ofsTransLogFile<<"<br/><table style='border:1px solid black;border-collapse:collapse;'>";
		Logger::ofsTransLogFile<<"<tr>";
		for(int idx = 0;idx < columnHeaders.size(); idx++)
		{
			Logger::ofsTransLogFile<<"<th style='text-align:center;border:1px solid black;border-collapse:collapse;'>"<< columnHeaders[idx]<<"</th>";
		}
		Logger::ofsTransLogFile<<"</tr>";

	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int HTMLLogger::closeHTMLLog()
{
	int iStatus = ITK_ok;
	TERADYNE_TRACE_ENTER();
	try
	{	
		// Close html tags
		Logger::ofsTransLogFile << "</table></body></html>";
		// Close the filestream
		Logger::closeLog();
	}
	catch(...)
	{ 

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}