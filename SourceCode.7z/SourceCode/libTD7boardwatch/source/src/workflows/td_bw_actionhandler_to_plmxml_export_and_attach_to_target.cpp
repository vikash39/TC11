/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_plmxml_export_and_attach_to_target.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int plmxml_export_and_attach_to_target_execute(EPM_action_message_t msg)
{
	int ifail = ITK_ok,
		attachmentCount = 0,
		iStrCnt = 0,
		Cnt = 0,
		iNewCnt = 0;

	tag_t job = NULLTAG,
		root_task = NULLTAG,
		type_tag = NULLTAG,
		input_tag = NULLTAG,
		dataset = NULLTAG,
		type = NULLTAG,
		relation = NULLTAG;

	tag_t* attachments = NULLTAG;
	int iAttachmentCount = 0;
	tag_t *tpAttachments = NULL;

	char *filename = NULL,
		*object_type = NULL,
		*cObjectString = NULL,
		**cNewList = NULL,
		**cRevList = NULL,
		**cstrList = NULL,
		
		*datasetName = NULL;

	string cProcess = "";
	string sNewProcess = "";

	try {
		char* pathName = "C:\\TEMP\\";
		//size_t requiredSize = 100;
		//// To read the environment variable
		//pathName = (char*)malloc(requiredSize * sizeof(char));

		//if (!pathName)
		//{
		//	printf("Failed to allocate memory!\n");
		//	exit(1);
		//}
		//ITK_set_bypass(TRUE);
		//// Get the value of the TEMP environment variable.
		//getenv_s(&requiredSize, pathName, requiredSize, TEMP);

		FILE *fptr, *wptr;
		char input[10000];
		TERADYNE_TRACE_CALL(ifail = EPM_ask_job(msg.task, &job));
		TERADYNE_TRACE_CALL(ifail = EPM_ask_root_task(job, &root_task));

		TERADYNE_TRACE_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &iAttachmentCount, &tpAttachments));

		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tpAttachments[0]);

		// To store Repair Order tag
		tag_t tRepairOrderRev = tpAttachments[0];

		std::string sItemId("");
	
		bool bIsNull = false;
		TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(ITEM_ID, sItemId, bIsNull));

		TERADYNE_TRACE_CALL(ifail = AOM_ask_value_string(root_task, "job_name", &cObjectString));
		TERADYNE_TRACE_CALL(ifail = EPM__parse_string(cObjectString, "/", &iStrCnt, &cstrList));
		if (iStrCnt != 0)
		{
			
			cProcess = cProcess.append(pathName);
			cProcess = cProcess.append(cstrList[0]);

			/*cProcess = (char*)MEM_alloc(100 * sizeof(char*));
			cNewProcess = (char*)MEM_alloc(100 * sizeof(char*));
			strcpy(cProcess, pathName);
			cout << "\n" << cProcess << endl;
			strcat(cProcess, cstrList[0]);*/

			cout << "\n" << cProcess << endl;
			if (tc_strstr(cObjectString, "/") != 0) {
			cProcess = cProcess.append("_");
			cout << "\n" << cProcess << endl;
			cProcess = cProcess.append(cstrList[1]);
			}
		
			//strcat(cProcess, cstrList[1]);
			cout << "\n" << cProcess << endl;
			
			cout << "\n" << sNewProcess << endl;
			sNewProcess = sNewProcess.append(cProcess);
			//strcpy(cNewProcess, cProcess);
			sNewProcess = sNewProcess.append("_");
			sNewProcess = sNewProcess.append(sItemId);
			cout << "\n" << sNewProcess << endl;
			cProcess = cProcess.append(".plmxml");
			//strcat(cProcess, ".plmxml");
			cout << "\n" << cProcess << endl;

			sNewProcess = sNewProcess.append(".xls");
			//strcat(cNewProcess, ".xls");
			cout << "\n" << sNewProcess << endl;
		}
		TERADYNE_TRACE_CALL(ifail = EPM__parse_string(cObjectString, ";", &Cnt, &cRevList));
		if (Cnt != 0) {
			datasetName = (char*)MEM_alloc(100 * sizeof(char*));
			strcpy(datasetName, cRevList[0]);
		}
		
		// Read the plmxml file
		fopen_s(&fptr, cProcess.c_str(), "r+");

		if (fptr == NULL) {
			perror("Error opening file");
			return ifail;
		}

		// Write xlsx file
		fopen_s(&wptr, sNewProcess.c_str(), "w+");

		
		while (fgets(input, 10000, fptr)) {
			fprintf(wptr, "%s", input);
			cout << "\n" << input << endl;
		}
		fclose(fptr);
		fclose(wptr);
		TERADYNE_TRACE_CALL(ifail = EPM_ask_attachments(root_task, EPM_target_attachment, &attachmentCount, &attachments));
		for (int target_attach = 0; target_attach < attachmentCount; target_attach++)
		{
			TERADYNE_TRACE_CALL(ifail = WSOM_ask_object_type2(attachments[target_attach], &object_type));
			if (tc_strcmp(object_type, "TD7RepairOrderRevision") == 0) {
				TERADYNE_TRACE_CALL(ifail = TCTYPE_ask_type("MSExcel", &type_tag));
				TERADYNE_TRACE_CALL(ifail = TCTYPE_construct_create_input(type_tag, &input_tag));
				TERADYNE_TRACE_CALL(ifail = AOM_set_value_string(input_tag, "object_name", datasetName));
				TERADYNE_TRACE_CALL(ifail = TCTYPE_create_object(input_tag, &dataset));
				TERADYNE_TRACE_CALL(ifail = AOM_save(dataset));
				TERADYNE_TRACE_CALL(ifail = AOM_refresh(dataset, true));
				TERADYNE_TRACE_CALL(cout << ifail << endl);
				TERADYNE_TRACE_CALL(ifail = AE_import_named_ref(dataset, "excel", sNewProcess.c_str(), NULL, SS_TEXT));
				TERADYNE_TRACE_CALL(ifail = AOM_save(dataset));
				TERADYNE_TRACE_CALL(ifail = AOM_refresh(dataset, false));
				
				TERADYNE_TRACE_CALL(ifail = GRM_find_relation_type("IMAN_specification", &type));
				TERADYNE_TRACE_CALL(ifail = GRM_create_relation(attachments[target_attach], dataset, type, NULLTAG, &relation));
				TERADYNE_TRACE_CALL(ifail = GRM_save_relation(relation));

			}
		}
		TERADYNE_MEM_FREE(filename);
		TERADYNE_MEM_FREE(object_type);
		TERADYNE_MEM_FREE(cObjectString);
		TERADYNE_MEM_FREE(cNewList);
		TERADYNE_MEM_FREE(cRevList);
		TERADYNE_MEM_FREE(cstrList);
		TERADYNE_MEM_FREE(datasetName);
		TERADYNE_MEM_FREE(filename);
		TERADYNE_MEM_FREE(filename);	
	}
catch (exception) {}
return ifail;
}