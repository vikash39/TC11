/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_assign_project_teams_to_debug_and_repair.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td7_assign_tc_projects_team_to_debug_and_repair(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t *tpReferencedObject = NULL;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t * tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	TERADYNE_TRACE_ENTER();
	try {

		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors());

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask));

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments));

		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIR_SERIAL_NO_REL, &tRelationType));

		int iSecondaryCnt = 0;

		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpAttachments[0], tRelationType, &iSecondaryCnt, &tpSecondaryObjects));

		if (iSecondaryCnt > 0) {
			for (int i = 0; i < iSecondaryCnt; i++)
			{
				
					tag_t tPartRelationType = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType));

					int iSecondaryPartCnt = 0;

					//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i], tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects));

					if (iSecondaryPartCnt > 0) {
						for (int i = 0; i < iSecondaryPartCnt; i++)
						{
							assign_project_team_wf(tpAttachments[0], tpSecondaryPartObjects[0]);
						}
					}
				}
			}
		
	}

	
	catch (exception exp) {}
	return iStatus;
}

int assign_project_team_wf(tag_t tRepairOrderRev, tag_t tHLAPartRev) {

	int iStatus = ITK_ok;
	bool bIsNull = false;

	TERADYNE_TRACE_ENTER();
	try {

		int iProjectCount = 0;
		tag_t* tProjectList = NULLTAG;

		TERADYNE_TRACE_CALL(AOM_ask_value_tags(tHLAPartRev, TD7_PROJECT_LIST, &iProjectCount, &tProjectList));

		if (iProjectCount > 0) {
			for (int i = 0; i < iProjectCount; i++) {

				BusinessObjectRef<Teamcenter::BusinessObject> tTcProjectBORef(tProjectList[i]);
				std::string sProjectId("");
				TERADYNE_TRACE_CALL(tTcProjectBORef->getString(TD7_PROJECT_ID, sProjectId, bIsNull));

				if (tc_strcmp(sProjectId.c_str(), "UNKNOWN_01") != 0) {
					TERADYNE_TRACE_CALL(assign_project_team_members_into_signoff_wf(tRepairOrderRev, tProjectList[i]));
				}
			}
		}
		// requirement changed, if there is not repair group, workflow will be assigned to Repair Admin.
		/**else {
			tag_t tUnknownProjectTag = NULLTAG;
			TERADYNE_TRACE_CALL(PROJ_find("UNKNOWN_01", &tUnknownProjectTag));
			TERADYNE_TRACE_CALL(assign_project_team_members_into_signoff_ro_creation(tRepairOrderRev, tUnknownProjectTag));
		}*/
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int assign_project_team_members_into_signoff_wf(tag_t tRepairOrderRev, tag_t tProjectTag) {

	int iStatus = ITK_ok;
	int iMembersCount = 0;
	tag_t* tMembersTag = NULLTAG;
	int iAdminCount = 0;
	tag_t* tAdminMembersTag = NULLTAG;
	int iPrvillagedCount = 0;
	tag_t* tPrivillagedTag = NULLTAG;
	const char cSubTaskName = NULL;
	tag_t tSubTask = NULLTAG;
	int iSignOffCount = 0;
	tag_t* tSignOffTag = NULLTAG;

	int iSubTaskCount = 0;
	tag_t* ptSubTasks = NULLTAG;
	bool bIsNull = false;
	std::set<tag_t> tagRespPartySet;

	// To be use for Claim / Un claim
	vector<tag_t> vsAssignee;
	vector<tag_t> vsEEAssignee;
	vector<tag_t> vsFIAssignee;
	try {
		TERADYNE_TRACE_CALL(iStatus = PROJ_ask_team(tProjectTag, &iMembersCount, &tMembersTag, &iAdminCount, &tAdminMembersTag, &iPrvillagedCount, &tPrivillagedTag));

		// Get Repair Location from Repair Order Object
		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderBORef(tRepairOrderRev);

		std::string sRepairLocation("");

		TERADYNE_TRACE_CALL(tRepairOrderBORef->getString(TD7_BAT_REPAIR_LOCATION, sRepairLocation, bIsNull));

		if (iMembersCount > 0) {
			for (int i = 0; i < iMembersCount; i++) {
				tag_t tRoleTag = NULLTAG;
				tag_t tUserTag = NULLTAG;
				tag_t tPersonTag = NULLTAG;
				char * cpRoleName = NULL;
				char * cCountry = NULL;
				char * cpUserId = NULL;
				char * personName = NULL;

				// Validate the user location and Repair Order's location
				TERADYNE_TRACE_CALL(SA_ask_groupmember_user(tMembersTag[i], &tUserTag));
				TERADYNE_TRACE_CALL(SA_ask_user_person(tUserTag, &tPersonTag));
				TERADYNE_TRACE_CALL(SA_ask_person_attr2(tPersonTag, "PA5", &cCountry)); // PA5 --> is the real name for country property in Person object.

				TERADYNE_TRACE_CALL(SA_ask_user_person_name2(tUserTag, &personName));

				TERADYNE_TRACE_CALL(SA_ask_user_identifier2(tMembersTag[i], &cpUserId));
				if (tc_strcmp(cCountry, sRepairLocation.c_str()) == 0) {

					TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tMembersTag[i], &tRoleTag));
					TERADYNE_TRACE_CALL(SA_ask_role_name2(tRoleTag, &cpRoleName));

					if (tc_strcmp(cpRoleName, "Test Technician") == 0) {

						tag_t tParticipant = NULLTAG;
						int iParticipantCount = 0;
						int iParticipant = 0;
						tag_t tParticipantList = NULLTAG;
						tag_t* tParticipantTypeList = NULLTAG;

						// To be use for Claim / Un claim
						vsAssignee.push_back(tMembersTag[i]);

						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebugAndRepairSpecialist", &tParticipant));
						if (tParticipant != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList));

							TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList));
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
						}
					}

					if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {

						tag_t tParticipant = NULLTAG;
						int iParticipantCount = 0;
						int iParticipant = 0;
						tag_t tParticipantList = NULLTAG;
						tag_t* tParticipantTypeList = NULLTAG;

						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebAndRepResSpecialist", &tParticipant));
						if (tParticipant != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList));

							TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList));
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
						}
					}
					if ((tc_strcmp(cpRoleName, "Test Engineer") == 0)) {

						tag_t tParticipant = NULLTAG;
						int iParticipantCount = 0;
						int iParticipant = 0;
						tag_t tParticipantList = NULLTAG;
						tag_t* tParticipantTypeList = NULLTAG;

						// To be use for Claim / Un claim
						vsEEAssignee.push_back(tMembersTag[i]);

						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7EnggEvaluationSpecialist", &tParticipant));
						if (tParticipant != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList));

							TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList));
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
						}
					}
					if ((tc_strcmp(cpRoleName, "Quality Inspector") == 0)) {

						tag_t tParticipant = NULLTAG;
						int iParticipantCount = 0;
						int iParticipant = 0;
						tag_t tParticipantList = NULLTAG;
						tag_t* tParticipantTypeList = NULLTAG;

						// To be use for Claim / Un claim
						vsFIAssignee.push_back(tMembersTag[i]);

						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7FinalInspectSpecialist", &tParticipant));
						if (tParticipant != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList));

							TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList));
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
						}
					}
				}

			}

			BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
			AcquireLock lockOnLLApartNum(boRepairOrderRev);

			TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_DEBUG_AND_REPAIR_ASSIGNEES, vsAssignee, false)));
			TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_ENGG_EVALUATION_ASSIGNEES, vsEEAssignee, false)));
			
			//Requirement Changes - If Repair Location is Cebu, No Need to add Quality Inspectors
			TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_FINAL_INSPECTION_ASSIGNEES, vsFIAssignee, false)));
			
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
	TERADYNE_MEM_FREE(tMembersTag);
	TERADYNE_MEM_FREE(tAdminMembersTag);
	TERADYNE_MEM_FREE(tPrivillagedTag);
	TERADYNE_MEM_FREE(tSignOffTag);
}