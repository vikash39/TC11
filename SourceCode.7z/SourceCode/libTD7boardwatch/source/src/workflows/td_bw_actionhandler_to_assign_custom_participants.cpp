/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_assign_custom_participants.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td_bw_actionhandler_to_assign_custom_participants_execute(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t tParticipant = NULLTAG;
	int iParticipantCount = 0;
	int iParticipant = 0;
	int iAssignee = 0;
	int iReworkAssignee = 0;
	int iFinalInsAssignee = 0;
	tag_t tParticipantList = NULLTAG;
	tag_t* tParticipantTypeList = NULLTAG;
	tag_t* vsAssignee = NULLTAG;
	tag_t* tpReworkAssignee = NULLTAG;
	tag_t* tpFinalInsAssignee = NULLTAG;

	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors());

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask));

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments));

		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tpAttachments[0]);

		// To store Repair Order tag
		tag_t tRepairOrderRev = tpAttachments[0];

		std::string sCurrentTaskName("");
		tag_t pCurrentUser = NULLTAG;
		char* cpUserName = NULL;
		char* cpUserId = NULL;

		TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_CURRENT_TASK_NAME, sCurrentTaskName, bIsNull));

		if (tc_strcmp(sCurrentTaskName.c_str(), "Engg Evaluation") == 0) {

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_ENGG_EVALUATION_ASSIGNEES, &iAssignee, &vsAssignee));
			TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7EnggEvaluationSpecialist", &tParticipant));

			// To visble Claim button.
			BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
			AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

			TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_ENGG_EVALUATION_CLAIMED, TRUE, false)));
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));

			for (int j = 0; j < iAssignee; j++) {

				if (tParticipant != NULLTAG) {

					TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(vsAssignee[j], tParticipant, &tParticipantList));
					TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
					TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev));
				}
			}
		}

		if (tc_strcmp(sCurrentTaskName.c_str(), "Debug and Repair") == 0) {

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iAssignee, &vsAssignee));
			TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebugAndRepairSpecialist", &tParticipant));

			// To visble Claim button.
			BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
			AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

			TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_DEB_AND_REPAIR_CLAIMED, TRUE, false)));
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));

			for (int j = 0; j < iAssignee; j++) {

				if (tParticipant != NULLTAG) {

					TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(vsAssignee[j], tParticipant, &tParticipantList));
					TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
					TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev));
				}
			}
		}

		if (tc_strcmp(sCurrentTaskName.c_str(), "Rework") == 0) {

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_REWORK_ASSIGNEES, &iReworkAssignee, &tpReworkAssignee));
			TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7ReworkSpecialist", &tParticipant));

			// To visble Claim button.
			BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
			AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

			TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_REWORK_CLAIMED, TRUE, false)));
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));


			for (int j = 0; j < iReworkAssignee; j++) {

				if (tParticipant != NULLTAG) {

					TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tpReworkAssignee[j], tParticipant, &tParticipantList));
					TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
					TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev));
				}
			}
		}

		if (tc_strcmp(sCurrentTaskName.c_str(), "Final Inspection") == 0) {

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_FINAL_INSPECTION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee));
			TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7FinalInspectSpecialist", &tParticipant));

			// To visble Claim button.
			BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
			AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

			TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_FINAL_INS_CLAIMED, TRUE, false)));
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));

			for (int j = 0; j < iFinalInsAssignee; j++) {

				if (tParticipant != NULLTAG) {

					TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tpFinalInsAssignee[j], tParticipant, &tParticipantList));
					TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList));
					TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev));
				}
			}
		}

	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}
