/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_cancel_ro.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  03-Mar-2021                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_cancel_ro.h>

int td_bw_cancel_ro(std::string roUID) {
	int iStatus = ITK_ok;
	tag_t tRepairOrderRev = NULLTAG;
	int iReleaseStatusCount = 0;
	tag_t* tReleaseStatusList = NULLTAG;
	tag_t tReleaseStatus = NULLTAG;
	
	bool bisverdict = false;
	TERADYNE_TRACE_ENTER();
	try
	{
		if (true) {

			TERADYNE_TRACE_CALL(ITK__convert_uid_to_tag(roUID.c_str(), &tRepairOrderRev));

			if (tRepairOrderRev != NULLTAG) {


				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict));
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true));
				}
				TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_BAT_MATURITY, "Completed"));
				TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_BAT_CLOSURE, "Closed"));
				TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_BAT_DISPOSITION, "Cancelled"));
				TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_HLA_SERIAL_NUM_STATUS, "Repaired"));
				TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false));
				}

				// set all config objects into 'Repaired'
				TERADYNE_TRACE_CALL(td_set_config_objects_as_repaired(tRepairOrderRev));
			
				// set release status for RO
				TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, RELEASE_STATUS_LIST, &iReleaseStatusCount, &tReleaseStatusList));

				// Add Released status (Locked) for Incoming Objects
				if (iReleaseStatusCount == 0) {
					TERADYNE_TRACE_CALL(RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleaseStatus));
					TERADYNE_TRACE_CALL(RELSTAT_add_release_status(tReleaseStatus, 1, &tRepairOrderRev, true));
					TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev));
				}
			}
		}
	}
	catch (...)
	{
	}
	ITK_set_bypass(false);
	TERADYNE_TRACE_LEAVE();
	return  iStatus;
}

int td_set_config_objects_as_repaired(tag_t tRepairOrderRev)
{
	int iStatus = ITK_ok;

	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(set_config_objects_status(tRepairOrderRev, TD7_REPAIRS_SERIAL_NO_REL));
		TERADYNE_TRACE_CALL(set_config_objects_status(tRepairOrderRev, TD7_INCOMING_CONFIG_REL));
		TERADYNE_TRACE_CALL(set_config_objects_status(tRepairOrderRev, TD7_SOLUTION_CONFIG_REL));
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int set_config_objects_status(int tRepairOrderRev, string relationType) {

	int iStatus = ITK_ok;
	int iSecondaryCnt = 0;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t tRelationType = NULLTAG;
	bool bisverdict = false;
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(relationType.c_str(), &tRelationType));
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects));
		for (int i = 0; i < iSecondaryCnt; i++) {

			POM_AM__set_application_bypass(true);
			TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tpSecondaryObjects[i], &bisverdict));
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], true));
			}
			TERADYNE_TRACE_CALL(AOM_set_value_string(tpSecondaryObjects[i], TD7_SERIAL_NUMBER_STATUS, "Repaired"));
			TERADYNE_TRACE_CALL(AOM_save_without_extensions(tpSecondaryObjects[i]));
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], false));
			}
			POM_AM__set_application_bypass(false);
		
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}