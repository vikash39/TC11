/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_repair_group_creation.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  05-Sep-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_repair_group_creation.h>

char* repair_group_creation(string repairGroupName, string repairLocation) {
	int iStatus = ITK_ok;
	int iLLACount = 0;
	int iROCount = 0;
	tag_t tProject = NULLTAG;
	tag_t tRequestor = NULLTAG;
	tag_t tGroup = NULLTAG;
	tag_t tRole = NULLTAG;
	tag_t tItemTypeTag = NULLTAG;
	tag_t tItemCreateInputTag = NULLTAG;
	tag_t tItemTag = NULLTAG;
	char * repairGroupUid = NULL;

	TERADYNE_TRACE_ENTER();
	try
	{
		if (true) {

			string osObjectName = "";
			osObjectName = osObjectName.append("RG_");
			osObjectName = osObjectName.append(repairGroupName.c_str());

			string sProjID = "";
			sProjID = sProjID.append(osObjectName.c_str());
			sProjID = sProjID.append("_");

			if (tc_strcmp(repairLocation.c_str(), "Cebu") == 0) {
				sProjID = sProjID.append("CU");
			}
			else if (tc_strcmp(repairLocation.c_str(), "Costa Rica") == 0) {
				sProjID = sProjID.append("CR");
			}
			else if (tc_strcmp(repairLocation.c_str(), "China") == 0) {
				sProjID = sProjID.append("CH");
			}
			else if (tc_strcmp(repairLocation.c_str(), "North Reading") == 0) {
				sProjID = sProjID.append("NR");
			}

			TERADYNE_TRACE_CALL(iStatus = PROJ_find(sProjID.c_str(), &tProject));

			if ((tProject == NULLTAG))
			{

				TERADYNE_TRACE_CALL(iStatus = PROJ_create_project(sProjID.c_str(), osObjectName.c_str(), "", &tProject));
			
				if (tProject != NULLTAG) {
					TC_write_syslog("The Repair Group Created Successfully!");
				}
				else {
					TC_write_syslog("The Repair Group Creation Failed!");
				}
			}
			ITK__convert_tag_to_uid(tProject, &repairGroupUid);

		}
	}
	catch (...)
	{

	}
	return  repairGroupUid;
}