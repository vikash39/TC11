/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_change_serial_number.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  19-Jun-2020                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_change_serial_number.h>

int change_serial_number(std::string sNewSerialNumber, std::string sNewSerialNumberName, std::string repairOrderUID) {

	tag_t tRepairOrderRev = NULLTAG;
	tag_t tSerialNumberRev = NULLTAG;
	tag_t *tpLLAPartNumberRev = NULLTAG;
	tag_t tPartSerialRel = NULLTAG;
	bool bIsNull = false;
	GRM_relation_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	int iStatus = ITK_ok;
	int	iLLAPartNumberCount = 0;
	std::string refDesignWarningMsg;
	char* serialNumberStatus = NULL;
	tag_t tPartRev = NULL;
	TERADYNE_TRACE_ENTER();
	try
	{
		if (true) {

			TERADYNE_TRACE_CALL(ITK__convert_uid_to_tag(repairOrderUID.c_str(), &tRepairOrderRev));

			if (tRepairOrderRev == NULLTAG)
			{
				return iStatus;
			}
			tag_t tRelationType = NULLTAG;

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tRelationType));

			int iSecondaryCnt = 0;
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects));

			for (int i = 0; i < iSecondaryCnt; i++)
			{
				// to set status for new serial number
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryObjects[i].secondary, TD7_SERIAL_NUMBER_STATUS, &serialNumberStatus));

				// to get HLA Part Number to attach to new serial number
				tag_t tPartRelationType = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType));
				int iPartCount = 0;
				tag_t* tHLAPart = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i].secondary, tPartRelationType, &iPartCount, &tHLAPart));
				tPartRev = tHLAPart[0];

				BusinessObjectRef< Teamcenter::BusinessObject > boSerialNumRev(tpSecondaryObjects[i].secondary);
				AcquireLock lockOnLLApartNum(boSerialNumRev);
				TERADYNE_TRACE_CALL((boSerialNumRev->setString(TD7_SERIAL_NUMBER_STATUS, "Retired", false)));
				TERADYNE_TRACE_CALL(AOM_save(tpSecondaryObjects[i].secondary));

				//TERADYNE_TRACE_CALL(AOM_set_value_string(tpSecondaryObjects[i].secondary, TD7_SERIAL_NUMBER_STATUS, "Retired"));
				
				// cut part serial number from repair order to add new serial number.
				TERADYNE_TRACE_CALL(GRM_delete_relation(tpSecondaryObjects[i].the_relation));
			}

			// create a new serial number
			TERADYNE_TRACE_CALL(create_new_serial_number(sNewSerialNumber, sNewSerialNumberName, tPartRev, tSerialNumberRev));
			
			// Update HLA SerialNumber Status property for Part Serial Number.
			BusinessObjectRef< Teamcenter::BusinessObject > boSerialNumRev(tSerialNumberRev);
			AcquireLock lockOnLLApartNum(boSerialNumRev);
			TERADYNE_TRACE_CALL((boSerialNumRev->setString(TD7_SERIAL_NUMBER_STATUS, serialNumberStatus, false)));
			TERADYNE_TRACE_CALL(AOM_save(tSerialNumberRev));

			// attach new serial number into repair order
			if (tRepairOrderRev != NULLTAG && tSerialNumberRev != NULLTAG) {
				TERADYNE_TRACE_CALL(attach_with_relation(tRepairOrderRev, tSerialNumberRev, TD7_REPAIR_SERIAL_NO_REL));
			}
		}
	}
		catch (...)
		{
		}
		ITK_set_bypass(false);
		TERADYNE_MEM_FREE(tpLLAPartNumberRev);
		TERADYNE_TRACE_LEAVE();
		return  iStatus;
	}

//create hla serial number
int create_new_serial_number(string sSerialNumberId, string sObjectName, tag_t tPartRev, tag_t& tSerialNumRev)
{
	int iStatus = ITK_ok;

	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;

	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sSerialNumberId.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM, TD7_PART_SERIAL_NUM, &tItemTypeTag));

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput));

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSerialNumberId.c_str()));

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObjectName.c_str()));

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM_REVISION, TD7_PART_SERIAL_NUM_REVISION, &tItemRevTypeTag));
			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput));

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"));

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput));

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem));

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem));

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewItem, false));

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tSerialNumRev));

			if (tSerialNumRev != NULLTAG && tPartRev != NULLTAG) {
				tag_t tRelationType = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationType));

				tag_t tRelation = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_create_relation(tSerialNumRev, tPartRev, tRelationType, NULLTAG, &tRelation));

				TERADYNE_TRACE_CALL(GRM_save_relation(tRelation));

			}

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	int iStatus = 0;
	tag_t tNewRel = NULLTAG;
	tag_t tRelation = NULLTAG;
	TERADYNE_TRACE_ENTER();
	try {
		TERADYNE_TRACE_CALL(GRM_find_relation_type(sAttachRel.c_str(), &tRelation));
		if (tRelation != NULLTAG) {
			TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel));
			TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel));
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}