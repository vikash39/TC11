/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_post_action_on_grm_create_of_td7_checklist_to_set_current_step.cpp
#      Module          :           libTD7_teradyne_extensions.dll
#      Project         :           libTD7_teradyne_extensions
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

int td_bw_post_action_on_grm_create_of_td7_checklist_to_set_current_step_execute(va_list localArgs)
{
	int iStatus = ITK_ok;
	tag_t tPrimaryObj = NULLTAG;
	tag_t tSecondayObj = NULLTAG;
	tag_t tRelationType = NULLTAG;
	logical bIsNull = false;
	string sCurrentStep;

	TERADYNE_TRACE_ENTER();
	try
	{
		tPrimaryObj = va_arg(localArgs, tag_t);
		tSecondayObj = va_arg(localArgs, tag_t);
		tRelationType = va_arg(localArgs, tag_t);

		if (tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG) {

			BusinessObjectRef<Teamcenter::BusinessObject> boPrimaryObj(tPrimaryObj);

			std::string sPrimaryObjectType("");
			TERADYNE_TRACE_CALL(boPrimaryObj->getString(OBJECT_TYPE, sPrimaryObjectType, bIsNull));

			if (sPrimaryObjectType.compare(TD7_REPAIR_ORDER_REVISION) == 0) {

				BusinessObjectRef<Teamcenter::BusinessObject> boSecondayObj(tSecondayObj);

				std::string sSecondaryObjectType("");
				TERADYNE_TRACE_CALL(boSecondayObj->getString(OBJECT_TYPE, sSecondaryObjectType, bIsNull));

				if (sSecondaryObjectType.compare(TD7_PRE_INSPECTION_FORM) == 0) {
					sCurrentStep = PRE_INSPECTION;
				}
				if (sSecondaryObjectType.compare(TD7_PRE_TEST_FORM) == 0) {
					sCurrentStep = PRE_TEST;
				}
				if (sSecondaryObjectType.compare(TD7_REPAIR_FORM) == 0) {
					sCurrentStep = REPAIR;
				}
				if (sSecondaryObjectType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0) {
					sCurrentStep = REPAIR_VERIFICATION;
				}
				if (sSecondaryObjectType.compare(TD7_POST_TEST_FORM) == 0) {
					sCurrentStep = POST_TEST;
				}
				if (sSecondaryObjectType.compare(TD7_REPAIR_REWORK_FORM) == 0) {
					sCurrentStep = REWORK;
				}
				if (sSecondaryObjectType.compare(TD7_QUALITY_INSPECTION_FORM) == 0) {
					sCurrentStep = QUALITY_INSPECTION;
				}

				//BusinessObjectRef< Teamcenter::BusinessObject > boPrimaryObj(tPrimaryObj);
				//AcquireLock lockOnPrimaryObj(tPrimaryObj);

				//TERADYNE_TRACE_AND_THROW( ( boPrimaryObj->setString(TD7_BAT_CHECKLIST, sCurrentStep, false ) ) );

				//TERADYNE_TRACE_CALL(AOM_save(tPrimaryObj));

			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}