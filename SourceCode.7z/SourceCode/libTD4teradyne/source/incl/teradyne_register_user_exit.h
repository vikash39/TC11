/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_register_user_exit.h          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Header file for custom exit and Handlers registration         
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  14-Nov-2014                       Vijayasekhar                       Added declaration of functions teradyne_populatedynamicURL and teradyne_whereusedterpart4ROHS
#  13-Jan-2015			             Kameshwaran D.	                    Added declaration of function teradyne_precondition_on_checkin_msg
#  12-Mar-2015                       Vijayasekhar                       Added declaration for teradyne_StandardECNvalidation,teradyne_assignstatus and teradyne_assignstatusondesigndoc
#  17-Mar-2015						 Kameshwaran D.						Added declaration for teradyne_set_releasestatus_ECN, teradyne_set_effectivedate_on_ECNpart, teradyne_assign_itemstatus_asper_ECNstatus
#  16-Mar-2015                       Selvi                              Added declaration for teradyne_genECNSummaryReport
#   17-Mar-2015						 Haripriya     						Added declaration for teradyne_reviewermatrix.
#  18-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_revstampcalculation and teradyne_ReleaseECNvalidations.
#  18-Mar-2015						 Haripriya     						Added declaration for teradyne_populatetechnicalreviewer,teradyne_populatetechnicalreviewer_Protobom.
#  20-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_protobomecnvalidations, teradyne_protobomecnsetrevstamp,Teradyne-DeviationAcknowledgeTask
#																		and teradyne_isobjectownersameastheprocessinitator.
#  23-Mar-2015						 kameshwaran D.						Added declaration for teradyne_update_vendorpartstatus, teradyne_update_sbm_form_vendor_part, teradyne_discdoc_whereusedterpart4ROHS
#  24-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_createandcopydseforms and teradyne_attachreleasestatustodseforms
#  24-Mar-2015						 Haripriya     						Added declaration for teradyne_effectivityassignment,teradyne_effectivitypropagation.
#  30-Mar-2015                       Vijayasekhar                    	Added declaration for teradyne_setdate
#  13-Apr-2015                       Vijayasekhar                    	Added declaration for teradyne_lockeffectivity, teradyne_unlockeffectivity and teradyne_assignsignoffdynamicparticipant
#  15-Apr-2015                       Haripriya                    	    Added declaration for teradyne_assignreviewermatrixsignoffdynamicparticipant.
#  16-Apr-2015                       Vijayasekhar                    	Added declarations teradyne_gendeviationreport
#  17-Apr-2015						 Kameshwaran D.						Added declarations teradyne_updateenggcontrolflagECN
#  20-Apr-2015						 Kameshwaran D.						Added declarations teradyne_whereusedvendorpart4ROHS
#  24-Apr-2015						 Selvi						        Added declarations teradyne_createExcemptionForm
#  24-Apr-2015						 Kameshwaran D.						Added declarations teradyne_checkeffectivitydatewithtodaydate
#  27-Apr-2015						 Selvi						        Added declarations teradyne_findLatestResult.
#  30-Apr-2015						 Haripriya						    Added declarations for teradyne_vendorpartcompliancecalculation,teradyne_updatingteradynepartswithcomplianceattributes.
#  05-May-2015						 Haripriya						    Added declarations for teradyne_change_all_started_to_suspend_resume
#  07-May-2015						 Vijayasekhar					    Added declarations teradyne_updatesupplierinformation
#  08-May-2015						 Haripriya						    Added declarations for teradyne_adhoc_signoff
#  20-May-2015						 Vijayasekhar					    Added declarations teradyne_releaseECNrevstampcalculation
#  02-Jun-2015						 Vijayasekhar					    Added declarations teradyne_revise_to_solution_item
#  19-Jun-2015						 Vijayasekhar					    Added declarations teradyne_updateROHScmplstatusfromlatestresult
#  05-Aug-2015						 Haripriya						    Added declarations for teradyne_solutionitems_org_check
#  14-Aug-2015						 Haripriya						    Added declarations for teradyne_check_solutionitems
#  17-Dec-2015						 Janani								Added declaration for teradyne_dataset_bom_file_validation
#  17-Aug-2016						 Haripriya							Added declaration for teradyne_update_materialimpact_ECN_Form
#  19-Sep-2016                       Rodji                              Added declaration for libTD4teradyne_register_custom_runtime_properties,teradyne_register_runtime_properties,teradyne_ask_td4ItemStatus
#  07-May-2018						 Marjorie							Added declaration for teradyne_validateOPSTaskReviewer
#  07-Jun-2018						 Marjorie							Added declaration for teradyne_assignMarketingResource
#  23-Jan-2019						 Marjorie							Added declaration for teradyne_update_effectivitydate
#  $HISTORY$                    
#  =================================================================================================*/  

# ifndef TERADYNE_REGISTER_USER_EXIT_H
# define TERADYNE_REGISTER_USER_EXIT_H

#include <common/teradyne_common.h>
#include <base_utils/TcResultStatus.hxx>

#ifdef  __cplusplus
extern "C" {
#endif
#include <libtd4teradyne_exports.h>
extern TD4TERADYNE_API int libTD4teradyne_register_callbacks();
extern TD4TERADYNE_API int libTD4teradyne_register_custom_handlers( int *decision , va_list args);
extern TD4TERADYNE_API int libTD4teradyne_register_custom_methods(int *decision, va_list args);

extern TD4TERADYNE_API int TD4_BOMLine_Properties(METHOD_message_t* m, va_list args);
extern TD4TERADYNE_API int TD4_CommPartReqRevision_Properties(METHOD_message_t* m, va_list args);
extern TD4TERADYNE_API int TD4_CommPartRevision_Properties(METHOD_message_t* m, va_list args);
extern TD4TERADYNE_API int TD4_DivPartRevision_Properties(METHOD_message_t* m, va_list args);
extern TD4TERADYNE_API int TD4_Vendor_Properties(METHOD_message_t* m, va_list args);

extern int teradyne_postaction_on_checkin_msg(METHOD_message_t*  msg, va_list args);
extern int teradyne_precondition_on_checkin_msg(METHOD_message_t*  msg, va_list args);

extern int teradyne_ask_td4ItemStatus(METHOD_message_t *  m, va_list  args );
extern int teradyne_ask_td4SafetyLicense(METHOD_message_t *  m, va_list  args);
extern int teradyne_ask_td4AWCSignOffTsks( METHOD_message_t *  m, va_list  args );
extern int teradyne_ask_td4CommPartRequests( METHOD_message_t *  m, va_list  args );
extern int teradyne_format_change_reason_history(METHOD_message_t *  m, va_list  args);




int teradyne_register_action_handlers();
int teradyne_register_rule_handlers();

int teradyne_populatedynamicURL(EPM_action_message_t msg);
int teradyne_whereusedterpart4ROHS(EPM_action_message_t msg);
int teradyne_assigndynamicparticipant(EPM_action_message_t msg);
int teradyne_standardECNvalidation(EPM_action_message_t msg);
int teradyne_assignstatus(EPM_action_message_t msg);
int teradyne_assignstatusondesigndoc(EPM_action_message_t msg);
int teradyne_set_releasestatus_ECN(EPM_action_message_t msg);
int teradyne_set_effectivedate_on_ECNpart(EPM_action_message_t msg);
int teradyne_assign_itemstatus_asper_ECNstatus(EPM_action_message_t msg);
int teradyne_genECNSummaryReport(EPM_action_message_t msg);
int teradyne_reviewermatrix(EPM_action_message_t msg);
int teradyne_revstampcalculation(EPM_action_message_t msg);
int teradyne_releaseECNvalidation(EPM_action_message_t msg);
int teradyne_populatetechnicalreviewer_releaseecn(EPM_action_message_t msg);
int teradyne_populatetechnicalreviewer_protobomecn(EPM_action_message_t msg);
int teradyne_protobomecnvalidations(EPM_action_message_t msg);
int teradyne_protopartecnvalidations(EPM_action_message_t msg);
int teradyne_protobomecnsetrevstamp(EPM_action_message_t msg);
int teradyne_deviationacknowledgetask(EPM_action_message_t msg);
EPM_decision_t teradyne_isobjectownersameastheprocessinitator(EPM_rule_message_t msg);
int teradyne_update_vendorpartstatus(EPM_action_message_t msg);
int teradyne_update_sbm_form_vendor_part(EPM_action_message_t msg);
int teradyne_updateenggcontrolflagECN(EPM_action_message_t msg);
int teradyne_discdoc_whereusedterpart4ROHS(EPM_action_message_t msg);
int teradyne_createandcopydseforms(EPM_action_message_t msg);
int teradyne_attachreleasestatustodseforms(EPM_action_message_t msg); 
int teradyne_effectivityassignment(EPM_action_message_t msg);
int teradyne_effectivitypropagation(EPM_action_message_t msg); 
int teradyne_setdate(EPM_action_message_t msg);
int teradyne_lockeffectivity(EPM_action_message_t msg);
int teradyne_unlockeffectivity(EPM_action_message_t msg);
int teradyne_assignsignoffdynamicparticipant(EPM_action_message_t msg);
int teradyne_assignrevmatdynamicparticipant(EPM_action_message_t msg);
int teradyne_gendeviationreport(EPM_action_message_t msg);
int teradyne_whereusedvendorpart4ROHS(EPM_action_message_t msg);
int teradyne_createExcemptionForm(EPM_action_message_t msg);
int teradyne_findLatestResult(EPM_action_message_t msg);
int teradyne_checkeffectivitydatewithtodaydate(EPM_action_message_t msg);
int teradyne_vendorpartcompliancecalculation(EPM_action_message_t msg); 
int teradyne_updatingteradynepartswithcomplianceattributes(EPM_action_message_t msg);
int teradyne_change_all_started_to_suspend_resume(EPM_action_message_t msg); 
int teradyne_updatesupplierinformation(EPM_action_message_t msg);
int teradyne_adhoc_signoff(EPM_action_message_t msg);
int teradyne_releaseECNrevstampcalculation(EPM_action_message_t msg);
int teradyne_revise_to_solution_item(EPM_action_message_t msg);
int teradyne_updateROHScmplstatusfromlatestresult(EPM_action_message_t msg);
int teradyne_dataset_bom_file_validation(EPM_action_message_t msg);
int teradyne_bom_import_from_csv(EPM_action_message_t msg);
EPM_decision_t teradyne_solutionitems_org_check(EPM_rule_message_t msg);
EPM_decision_t teradyne_check_solutionitems(EPM_rule_message_t msg);
int teradyne_update_materialimpact_ECN_Form(EPM_action_message_t msg);
int teradyne_reassignNotification(EPM_action_message_t msg);
int teradyne_checkDiscSpecForms(EPM_action_message_t msg);
int teradyne_partmodreq_notification(EPM_action_message_t msg);
int teradyne_rejectNotification(EPM_action_message_t msg);
int teradyne_checkeffectivitydate_reviseeff(EPM_action_message_t msg);
int teradyne_updatevendorpart_materialinfo(EPM_action_message_t msg);
int teradyne_validateOPSTaskreviewer(EPM_action_message_t msg);
int teradyne_validateMarketingResource(EPM_action_message_t msg);
int teradyne_submitCommPartRevToT4O(EPM_action_message_t msg);
int teradyne_commentNotification(EPM_action_message_t msg);
int teradyne_submitPartToESI(EPM_action_message_t msg);
int teradyne_is_controlling_bus_unit_NXT(EPM_action_message_t msg);
int teradyne_createPartModifyReq(EPM_action_message_t msg);
int teradyne_is_item_status_prototype(EPM_action_message_t msg);
int teradyne_checkout_checkin_object(EPM_action_message_t msg);
int teradyne_get_part_type_to_modify(EPM_action_message_t msg);
int teradyne_update_effectivitydate(EPM_action_message_t msg);
int teradyne_abort_ecn_tasks(EPM_action_message_t msg);
int teradyne_has_change_management_access(EPM_action_message_t msg);

int teradyne_genECNSafetyReport(EPM_action_message_t msg);
int teradyne_convert_semicolon_to_csv(EPM_action_message_t msg);
int teradyne_supplierAddRequestValidation(EPM_action_message_t msg);
int teradyne_is_controlling_bus_unit_UR(EPM_action_message_t msg);
int teradyne_check_vendorPartCOO(EPM_action_message_t msg);
int teradyne_check_manufacturer_status(EPM_action_message_t msg);
int teradyne_check_commercial_parts_exists(EPM_action_message_t msg);
EPM_decision_t teradyne_provide_information_to_user(EPM_rule_message_t msg);

EPM_decision_t teradyne_check_PMR_properties(EPM_rule_message_t msg);

extern char* td4PrimaryObjUID;
EPM_decision_t ur_ecn_validation_parttypecheck(EPM_rule_message_t msg);
EPM_decision_t ur_ecn_validation_statuscheck(EPM_rule_message_t msg);
EPM_decision_t ur_ecn_validation_bomcheck(EPM_rule_message_t msg);
EPM_decision_t ur_ecn_validation_bomstatuscheck(EPM_rule_message_t msg);
EPM_decision_t ur_ecn_validation_impacted(EPM_rule_message_t msg);
EPM_decision_t ur_ecn_validation_datasetcheck(EPM_rule_message_t msg);

#include <libtd4teradyne_undef.h>
#ifdef  __cplusplus
}
#endif

#endif
