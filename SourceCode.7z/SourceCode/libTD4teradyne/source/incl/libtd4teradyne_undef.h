//@<COPYRIGHT>@
//==================================================
//Copyright $2014.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBTD4TERADYNE) && !defined(IPLIB)
#   error IPLIB orLIBTD4TERADYNE is not defined
#endif

#undef TD4TERADYNE_API
#undef TD4TERADYNEEXPORT
#undef TD4TERADYNEGLOBAL
#undef TD4TERADYNEPRIVATE
