/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_handlers.h          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Header file for data related to workflow handlers         
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  14-Nov-2014                       Vijayasekhar                       Added declaration for teradyne_get_logical_values and teradyne_change_ownership
#  12-Feb-2015                       Vijayasekhar                   	Added teradyne_get_assignee_name declaration and Removed teradyne_get_logical_values function declaration
#  04-Mar-2015                       Vijayasekhar                    	Added declaration for teradyne_replace_url_spacecharacter.
#  12-Mar-2015                       Vijayasekhar                    	Added function declarations teradyne_get_associated_objects, teradyne_pri_sec_object_propvalue,
#  16-Feb-2015						 Selvi 								Added declaration for functions of ECN Summary Report.
#  17-Mar-2015                       Haripriya                          Added declaration for teradyne_vector_to_chararray and teradyne_insert_vector_value_into_another_vector
#  18-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_get_effective_date_range and teradyne_find_relation..
#  18-Mar-2015                       Haripriya                          Added declaration for teradyne_get_primary_imapacted_project_values,teradyne_get_propname_from_Preference and teradyne_set_techreviewer_value
#  18-Mar-2015                       Haripriya                          Modified declaration for teradyne_convert_vector_to_array and teradyne_merge_vectors
#  20-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_translate_and_set_effective_date.
#  23-Mar-2015						 Kameshwaran D					 	Added declarations teradyne_part_related_to_vendor_part_operation, teradyne_getvendorpart_related_discdoc.
#  24-Mar-2015                       Vijayasekhar                    	Added declarations teradyne_copy_forms_into_relation
#  24-Mar-2015                       Haripriya                          Added declaration for teradyne_get_planner_value_from_primary_project,teradyne_get_release_status_tag,teradyne_set_effectivity,
#  26-Mar-2015						 Kameshwaran D						Added declaration for teradyne_getteradynpart_in_solution_folder
#  10-Apr-2015						 Kameshwaran D						Added declaration for teradyne_get_preferred_status_value funtion
#  13-Apr-2015                       Vijayasekhar                    	Added declaration for teradyne_get_effectivities and teradyne_set_protection
#  15-Apr-2015                       Haripriya                    	    Modified declaration for teradyne_get_prop_value_from_primary_project.
#  16-Apr-2015						 Vijayasekhar						Added declarations handlerteradyne_generate_report and teradyne_convert_xls2xlsx
#  17-Apr-2015						 Selvi						        Modified declarations teradyne_get_ECN_effectivity.
#  17-Apr-2015						 Kameshwaran D						Added declaration teradyne_update_engg_control_flag
#  20-Apr-2015						 Kameshwaran D						Added declaration teradyne_get_and_copy_where_used_parts, teradyne_check_and_create_complaince_regrade_folder, teradyne_get_teradyne_part_related_to_vendor_part.
#  21-Apr-2015						 Selvi						        Removed declarations teradyne_convert_xls2xlsx.
#  05-May-2015					     Vijayasekhar                    	Changed the declaration teradyne_get_bomline_children
#  07-May-2015					     Vijayasekhar                    	Added declaration teradyne_search_SBMForms_using_commodity_level1, teradyne_relate_vndr_part_comm_part_update_status and teradyne_get_object_from_item_id
#  14-May-2015					     Vijayasekhar                    	Modified the function declarations teradyne_relate_vndr_part_comm_part_update_status and teradyne_get_object_from_item_id
#  15-May-2015					     Haripriya                    	    Added teradyne_validate_all_child_lines declaration.
#  18-May-2015						 Haripriya						    Added teradyne_check_given_object_in_folder declaration
#  19-May-2015					     Haripriya                    	    Removed teradyne_validate_all_child_lines declaration.
#  20-May-2015					     Haripriya                    	    Modified teradyne_get_bomline_children declaration
#  10-Jun-2015					     Haripriya                    	    Modified teradyne_set_effectivity declaration
#  07-Jul-2015                       Haripriya                          Removed teradyne_find_prev_revision function declaration.
#  07-Jul-2015                       Vijayasekhar						Modified function teradyne_vndr_part_comm_part_update_status name
#  26-Aug-2015                       Haripriya                          Modified teradyne_set_protection and teradyne_lock_effectivities_divpart function declaration.
#  15-Oct-2015                       Manimaran                          Added argument to the teradyne_set_effectivity function.
#  27-Oct-2015                       Manimaran                          Added teradyne_get_description declaration.
#  12-Nov-2015                       Manimaran                          Removed teradyne_convert_vector_to_array function declaration.
#  17-Dec-2015						 janani								Added teradyne_create_log_file function
#  22-Dec-2015                       Manimaran                          Added teradyne_check_if_new_revision_exists_in_solutionitemsfolder declaration.
#  18-Jan-2016                       Manimaran                          Added argument to the teradyne_check_if_new_revision_exists_in_solutionitemsfolder function.
#  25-Mar-2016                       Haripriya                          Added teradyne_check_designdocument function declaration.Modified the arguments in teradyne_get_bomline_children function.
#  $HISTORY$                    
#  =================================================================================================*/  

# ifndef TERADYNE_HANDLERS_H
# define TERADYNE_HANDLERS_H

#include <teradyne_register_user_exit.h>

#ifdef  __cplusplus
extern "C" {
#endif

int teradyne_change_ownership(tag_t tObject, string toGroup);
int teradyne_get_assignee_name(tag_t tTask, char** pcAssingeeName);
int teradyne_replace_url_spacecharacter(char *pcUrl, string& strUrl);
int teradyne_pri_sec_object_propvalue(tag_t tRefObj, string strRelName, string strObjType, int iIsPriOrSec, string strPropName, char** pcPropVal);
int teradyne_get_bomline_children(tag_t tItemRev, tag_t tBomViewRev, int* iChildCount, tag_t** tChildLine, tag_t* tWindow,string strEcntype);
int teradyne_get_associated_objects(tag_t tObject, string strRelTypeName, int *iObjCount, tag_t **tObjects);
int teradyne_add_release_status_to_objects(int iCount, tag_t *tObjects);
int teradyne_merge_vectors( vector<string> &CommonVectorValues,vector<string> VectorValues);
int teradyne_find_relation(tag_t tPrimary, tag_t tSecondary, string strRelTypeName, tag_t* tRelation);
int teradyne_get_effective_date_range(tag_t tObject, char** pcRangeTxt);
int teradyne_get_primary_imapacted_project_values( tag_t tAttachtag,vector<string> &vimpprojValues);
int teradyne_get_propname_from_Preference( string szvalue,vector<string> &techreviewerValues,string &szPropname,bool &bcheck);
int teradyne_set_techreviewer_value( tag_t tAttachtag, vector<string> impprojValues);
int teradyne_translate_and_set_effective_date(tag_t tAttach);
int teradyne_part_related_to_vendor_part_operation(tag_t tRevTag,int iFlagCheck);
int teradyne_getvendorpart_related_discdoc(tag_t tRevTag,std::vector<tag_t> *tVendorPartTagVec);
int teradyne_copy_forms_into_relation(string strNewFormName, tag_t tPrimary, tag_t* tOldForm, string strRelName );
int teradyne_get_prop_value_from_primary_project( tag_t tObjTag,std::map<string,string> &strPropNameValueMap,string szpropname);
int teradyne_get_release_status_tag( tag_t tObjTag,tag_t *tRelStatusTag);
int teradyne_set_effectivity(tag_t tItemRevtag, tag_t tRelStatusTag,string szEffdaterange,string szEffdate,bool bToBeProtected = true);
int teradyne_ask_effectivity_range( tag_t tRelStatusTag,char **pcRangeTxt);
int teradyne_effectivity_start_end_date( char *pcdaterange,string szvalue,string &szeffdate);
int teradyne_update_htmlcontentPair(char *columname, char *columvalue, char* value, std::list<string> strColAttr, std::list<string> strColwidthAttr, std::vector<string> resValVec);
int teradyne_html_headingblock(char* HeadingValue, int iHeadingType);
int teradyne_html_tabletagopen(char* HeadingValue, bool bAddHeader);
int teradyne_html_tabletagclose(bool bAddHeaderclose);
int teradyne_update_htmlcontentPair_safety(char *columname, char *columvalue, char* value, std::list<string> strColAttr, std::list<string> strColwidthAttr, std::vector<string> resValVec);
int teradyne_html_headingblock_safety(char* HeadingValue, int iHeadingType);
int teradyne_html_tabletagopen_safety(char* HeadingValue, bool bAddHeader);
int teradyne_html_tabletagclose_safety(bool bAddHeaderclose);
int teradyne_list_bvr_diffs_safety(tag_t  tImprevtag, tag_t  tSolrevtag, vector<string> &resDiffVec);
int teradyne_update_solitem_BL_only_safety (tag_t  tSolrevtag, vector<string> &resDiffVec);
int teradyne_get_bomline_attr_value_safety (int iChildrenCount1, int iChildrenCount2, tag_t *ptChildrens1, tag_t *ptChildrens2,  std::list<string> strBomLineAttrList, vector<string> &resDiffVec);
int teradyne_list_bvr_diffs (tag_t  tImprevtag, tag_t  tSolrevtag, vector<string> &resDiffVec);
int teradyne_get_ECNRelationPropertyattrCount(tag_t ptAttaches, char *cECNRelName, int *iImpObjCount, tag_t **tImpObjFoundTag);
int teradyne_get_ECNRelationPropertyattrvalue(tag_t ptAttaches, char *cECNRelName, std::list<string> strECNRelationAttrList, char *pcECNClosureStsValue, int *iImpObjCount, tag_t **tImpObjFoundTag, vector<string> &resPropValVec);
int teradyne_write_excelfile(tag_t tTargetObject, char *pcECNID, std::string strECNReportAttr[], std::vector<string> resPropValVec, 
	                         std::vector<string> resImpValVec, std::vector<string> resSolValVec, std::vector<string> resECNDocValue,std::vector<string> resECNPRocessValue, std::vector<string> resECNEffVec,
							 int iImpObjCount, int iSolObjCount, tag_t *tImpObjFoundTag,tag_t *tSolObjFoundTag, char *pcECNClosureStsValue);
int teradyne_write_excelfile_safety(tag_t tTargetObject, char *pcECNID, int iImpObjCount, int iSolObjCount, tag_t *tImpObjFoundTag, tag_t *tSolObjFoundTag, char *pcECNClosureStsValue);
int teradyne_get_bomline_attr_value (int iChildrenCount1, int iChildrenCount2, tag_t *ptChildrens1, tag_t *ptChildrens2,  std::list<string> strBomLineAttrList, vector<string> &resDiffVec);
int teradyne_get_ECN_processhistory (tag_t tTask, tag_t tObject,vector<string> &resDiffVec);
int teradyne_get_ECN_effectivity (char *pcECNID,tag_t tObject,vector<string> &resECNEffVec);
int teradyne_find_and_create_dataset(char *cFileName, tag_t tTargetObject, char *pcDatasetID);
int teradyne_find_and_replace_namedRef(char  *cFormatName, char  *cDatasetRefName,char  *cReferenceName,AE_reference_type_t ref_type, tag_t tagDataset,tag_t tTargetObject);
int teradyne_update_solitem_BL_only(tag_t  tSolrevtag, vector<string> &resDiffVec);
int teradyne_getteradynpart_in_solution_folder(tag_t tRevTag,std::vector<tag_t>	*tVecTeradyneParts);
int teradyne_get_preferred_status_value(tag_t tVendorTag,string *szPreffered_Status);
int teradyne_get_effectivities(tag_t tObject, int* iEffectivities, tag_t** tEffectivities, tag_t* tRelStat = NULL);
int teradyne_set_protection(tag_t tObject, bool bLock,char *pcObjectType);
int teradyne_generate_report(const char* pcReportId, const char* pcReportName, const char* pcCategory, char* pcStyleSheet, int iContextObjects, tag_t* ptContextObjects, char* pcDataSetType, char** pcDataSetPath);
int teradyne_update_engg_control_flag(tag_t tRevTag);
int teradyne_get_and_copy_where_used_parts(tag_t tRevtag, tag_t tFolder);
int teradyne_check_and_create_complaince_regrade_folder(tag_t *tFolder);
int teradyne_get_teradyne_part_related_to_vendor_part(tag_t tTargetTag, vector<tag_t> *tTeradynePartVec);
int teradyne_search_SBMForms_using_commodity_level1(char* pcCommodityLvl, int* iRows, void**** pvQueryResults);
int teradyne_vndr_part_comm_part_update_status(tag_t tCommPart, tag_t tVendorPart, string strPrefStatus, bool bGetVal = false, char **pcPrefStatus = NULL);
int teradyne_get_object_from_item_id(const char* pcItemId, const char* tReqObjectType, const char* pcRelName, const char* pcRelatedObjType, tag_t tVendorToCompare, tag_t* tFoundObjsVec, tag_t* tFoundItem);
int teradyne_check_given_object_in_folder(tag_t tFolder,tag_t object);
int teradyne_create_relation(const char* pcRelType, tag_t tPrimary, tag_t tSecondary);
int teradyne_get_safety_value( tag_t tAttachtag, bool &bSafety);
int teradyne_find_task_reviewers(tag_t tReviewsubtask);
int teradyne_insert_task_into_folder (std::string sTaskObjectName, tag_t tTask);
int teradyne_delete_task_from_folder (tag_t tReviewsubtask);
int teradyne_lock_effectivities_divpart(tag_t tObject,bool bRefresh);
int teradyne_get_description(tag_t tBOMLineTag, char **pcDescription);
int teradyne_create_log_file(tag_t taskid,std::string strErrMsg);
int teradyne_check_if_new_revision_exists_in_solutionitemsfolder(tag_t tECNTag, tag_t *tSolPartList, int iSolPartCount, char *pcECNType);
int teradyne_bom_redo_log_file(tag_t taskid,std::vector<string> vecErrMsg,std::vector<string> vecRedo);
int teradyne_read_csv_header(string strLine,string *err,map<string,int> *HeaderposMap);
void teradyne_quantityvsreferencedesignator_validation(string strRefDes, int iQuantity, std::vector<string> &strRefDesValues, int &iErrorCount, string &strErrorMsg);
int teradyne_check_designdocument(tag_t tObjectTag,tag_t tEcnTag,bool &bisDesignDocExist,std::map<string,string> &mapDocMissingDataSet);
int teradyne_updateComplianceAttributes(tag_t tRelationTypeTag, tag_t tLatestRev);
#ifdef  __cplusplus
}
#endif

#endif
