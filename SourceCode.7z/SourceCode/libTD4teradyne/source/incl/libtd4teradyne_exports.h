//@<COPYRIGHT>@
//==================================================
//Copyright $2014.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  TD4teradyne

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libTD4teradyne

#if !defined(LIBTD4TERADYNE) && !defined(IPLIB)
#   error IPLIB or LIBTD4TERADYNE is not defined
#endif

/* Handwritten code should use TD4TERADYNE_API, not TD4TERADYNEEXPORT */

#define TD4TERADYNE_API TD4TERADYNEEXPORT

#if IPLIB==libTD4teradyne || defined(LIBTD4TERADYNE)
#   if defined(__lint)
#       define TD4TERADYNEEXPORT       __export(TD4teradyne)
#       define TD4TERADYNEGLOBAL       extern __global(TD4teradyne)
#       define TD4TERADYNEPRIVATE      extern __private(TD4teradyne)
#   elif defined(_WIN32)
#       define TD4TERADYNEEXPORT       __declspec(dllexport)
#       define TD4TERADYNEGLOBAL       extern __declspec(dllexport)
#       define TD4TERADYNEPRIVATE      extern
#   else
#       define TD4TERADYNEEXPORT
#       define TD4TERADYNEGLOBAL       extern
#       define TD4TERADYNEPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define TD4TERADYNEEXPORT       __export(TD4teradyne)
#       define TD4TERADYNEGLOBAL       extern __global(TD4teradyne)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define TD4TERADYNEEXPORT      __declspec(dllimport)
#       define TD4TERADYNEGLOBAL       extern __declspec(dllimport)
#   else
#       define TD4TERADYNEEXPORT
#       define TD4TERADYNEGLOBAL       extern
#   endif
#endif
