//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the declaration for the Extension getTd4COO_CalculatedBase
 *
 */

#ifndef GETTD4COO_CALCULATEDBASE_HXX
#define GETTD4COO_CALCULATEDBASE_HXX
#include <tccore/method.h>

#include <extensions/td4_common.hxx>

#include "common\teradyne_constants.h"
#include "common\teradyne_trace.h"
#include <libtd4teradyne_exports.h>
#ifdef __cplusplus
extern "C" {
#endif

	extern TD4TERADYNE_API int getTd4COO_CalculatedBase(METHOD_message_t* msg, va_list args);

#ifdef __cplusplus
}
#endif

#include <libtd4teradyne_undef.h>

#endif  // GETTD4COO_CALCULATEDBASE_HXX
