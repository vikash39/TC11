#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_supplierAddRequestValidation
 * Description				: This function will validates the Supplier Add Request object
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_supplierAddRequestValidation(EPM_action_message_t msg){

	int iStatus       = ITK_ok,
		iAttachCount  = 0;

	char *parentTaskName=NULL,
		 *taskName      =NULL;
	char *pcTypeName			= NULL,
	     *pcTargetAttachmentType=NULL,
		 *pcCommodityEngineer   =NULL,
		 *pcCommodityManager    =NULL,
		 *pcCommodityGroupManager =NULL,
		 *pcLevelOfAssessment =NULL;

	bool  requestCancelled=false;

	tag_t  *ptAttaches		= NULL;
	tag_t *tCommodityFormList	= NULL,
		  tPrimaryObj			= NULLTAG,
		  tSecondaryObj         = NULLTAG,
		  tCommRel				= NULLTAG,
		  tComodityRelType		= NULLTAG;
	const char * __function__ = "teradyne_supplierAddRequestValidation";
	TERADYNE_TRACE_ENTER();


	try{
	   
		
	   TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
	   for(int i=0;i<iAttachCount;i++){
	        TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTargetAttachmentType), TD_LOG_ERROR_AND_THROW);
			if( pcTargetAttachmentType != NULL && (tc_strcmp(pcTargetAttachmentType,TD_SUPPLIER_ADD_REQ_REV) == 0 )  ){
			   TERADYNE_TRACE_CALL(iStatus = EPM_ask_name2(msg.task, &taskName), TD_LOG_ERROR_AND_THROW);
			   TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(ptAttaches[i],TD_CANCEL_SUPPLIER_ADD_REQUEST,&requestCancelled), TD_LOG_ERROR_AND_THROW);
				   if( tc_strcmp(taskName,TD_TASK_SUPPLIER_ADD_COORDINATOR_WORK) == 0 && !requestCancelled){
					 
					   
					  //Validate if Commodity Group Manager is not empty
					  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i],TD_COMMODITY_GROUP_MANAGER,&pcCommodityGroupManager), TD_LOG_ERROR_AND_THROW);
					  if(pcCommodityGroupManager == NULL || tc_strcmp(pcCommodityGroupManager,"")==0){
						 TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_SUPP_ADD_REQ_MISSING_COMMODITY_GROUP_MANAGER),TD_LOG_ERROR_AND_THROW);
						 iStatus =  TD_SUPP_ADD_REQ_MISSING_COMMODITY_GROUP_MANAGER;
						 throw iStatus;
					  }

					  //Validates if Commodity Level1 Form has assign responsible commodity engineer and responsible commodity manager

					  TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_COMMODITY_LVL1_REL_NAME, &tComodityRelType), TD_LOG_ERROR_AND_THROW);
					  TERADYNE_TRACE_CALL(iStatus =teradyne_getprimaryorsecondary_relation_objecttag(ptAttaches[i], TD_COMMODITY_LVL1_REL_NAME, "", 0, &tSecondaryObj), TD_LOG_ERROR_AND_THROW); 
					  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObj,TD_COMMODITY_ENGINEER,&pcCommodityEngineer), TD_LOG_ERROR_AND_THROW);
					  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObj,TD_COMMODITY_MANAGER,&pcCommodityManager), TD_LOG_ERROR_AND_THROW);

					  if(pcCommodityEngineer == NULL || tc_strcmp(pcCommodityEngineer,"")==0){
						 TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_SUPP_ADD_REQ_MISSING_COMMODITY_ENGINEER),TD_LOG_ERROR_AND_THROW);
						 iStatus =  TD_SUPP_ADD_REQ_MISSING_COMMODITY_ENGINEER;
						 throw iStatus;
					  }

					  if(pcCommodityManager == NULL || tc_strcmp(pcCommodityManager,"")==0){
						 TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_SUPP_ADD_REQ_MISSING_COMMODITY_MANAGER),TD_LOG_ERROR_AND_THROW);
						 iStatus =  TD_SUPP_ADD_REQ_MISSING_COMMODITY_MANAGER;
						 throw iStatus;
					  }

				   }else if(tc_strcmp(taskName,TD_TASK_COMMODITY_ENGINEER_REVIEW) == 0){
					//Validates Level Of Assessment
					 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i],TD_LEVEL_OF_ASSESSMENT,&pcLevelOfAssessment), TD_LOG_ERROR_AND_THROW);
					 if(pcLevelOfAssessment==NULL || tc_strcmp(pcLevelOfAssessment,"")==0){
					   TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_SUPP_ADD_REQ_MISSING_LEVEL_OF_ASSESSMENT),TD_LOG_ERROR_AND_THROW);
						 iStatus =  TD_SUPP_ADD_REQ_MISSING_LEVEL_OF_ASSESSMENT;
						 throw iStatus;
					 }
			   
			   
			   }
			   break;
			}
	   }

	  
	   

	}catch(...){
	   if(iStatus == ITK_ok){
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	 
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}