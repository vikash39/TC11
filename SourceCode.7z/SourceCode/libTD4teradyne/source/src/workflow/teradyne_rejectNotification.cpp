/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_rejectNotification.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-PartModReq-Notification action handler
#      Project         :           libTD4teradyne          
#      Author          :           Karl Reimann          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#
#  $HISTORY$                    
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>
std::string teradyneBuildNotificationSubjectReject(EPM_action_message_t msg, string reviewerName);
std::string teradyneBuildNotificationBodyContentReject(EPM_action_message_t msg, string commentEmail);


typedef map<string,string> MapSignOff;

struct SignOffComparator {
   bool operator()(MapSignOff signOffOne, MapSignOff signOffTwo){
      return (signOffOne.find("lastModifiedDate")->second > signOffTwo.find("lastModifiedDate")->second);
   }
};
/*******************************************************************************
 * Function Name			: teradyne_rejectNotification
 * Description				: This function will send a notification email for every signoff wherein the decision is "Reject".
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-action","-task"  in task and action argument is mandatory.
 *							 2. For the given task ,given action is performed.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_rejectNotification(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iCount              = 0,
		iSignoffAttCount	= 0;

	tag_t *tAttachtag			= {NULLTAG},
		  tPerson				= NULLTAG,
		  tMember				= NULLTAG,
		  tUserTag				= NULLTAG,
		  tSignoffMember		= NULLTAG,
		  tOwner				= NULLTAG,
		  tResponsibleParty		= NULLTAG,
		  *tSignoffAttachments	= NULL,
		  *tAttaches			= NULL;

	string strMailFilePath		= "",
		   subject				= "";
	
	EPM_signoff_decision_t	tDecisionType;
	SIGNOFF_TYPE_t memberType;

	char *pcTypeName					= NULL,
		 *pcObjectType					= NULL, 
		 *pcNotificationReceiverEmail	= NULL,
		 *pcSignoffComments				= NULL,
		 *pcReviewerName				= NULL,
		 *the_sender_email_addr			= NULL;
	
	set<MapSignOff,SignOffComparator> setMapSignOff;	
	
	date_t  	decisionDateSignoff;

	const char * __function__    = "teradyne_rejectNotification";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG && msg.action == EPM_reject_action)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(!setMapSignOff.empty())
			{
				setMapSignOff.clear();
			}

			if(!strMailFilePath.empty())
			{
				strMailFilePath.clear();
			}
             
			if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMPerformSignoffTask") == 0)))
			{ //checks if task is sign off task
				TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(msg.task, EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW); //gets attachments(sign off list) of the task
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(msg.task, &tOwner), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tOwner, &pcNotificationReceiverEmail), TD_LOG_ERROR_AND_THROW);
				string	szCurTimeStamp;
				date_t	curDateTime;
					 
			    TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW); // get current system date
				strMailFilePath.append(TD_TEMP_PATH).append("REJECT_NOTIFICATION").append(szCurTimeStamp).append(".htm");
				for (int i = 0; i < iSignoffAttCount; i++)
				{ //iterate through each member of the sign off list
					date_t  	signOffLastModDate;
					char *pcSignOffLastModDateWithHMS=NULL;
					AOM_ask_value_date	(tSignoffAttachments[i],"last_mod_date",&signOffLastModDate); //get last modified date for signOff attachment
					TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( signOffLastModDate, TD_DATE_YMD_CONSTANT, &pcSignOffLastModDateWithHMS),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_signoff_member(tSignoffAttachments[i], &tMember, &memberType), TD_LOG_ERROR_AND_THROW); //gets the member tag of people in the sign off list
					TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_user(tMember, &tUserTag), TD_LOG_ERROR_AND_THROW); //gets the user id
					if(tUserTag != NULLTAG)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW); //gets the email address
						TERADYNE_TRACE_CALL(iStatus = EPM_ask_decision(msg.task, tUserTag, &tDecisionType, &pcSignoffComments, &decisionDateSignoff), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUserTag, &pcReviewerName), TD_LOG_ERROR_AND_THROW); //gets the user full name
						
						MapSignOff mapSignOff;
						mapSignOff["lastModifiedDate"]=pcSignOffLastModDateWithHMS;
						mapSignOff["emailAddress"]=string(the_sender_email_addr);
						mapSignOff["signoffComment"]=string(pcSignoffComments);
						mapSignOff["reviewer"]=string(pcReviewerName);
						setMapSignOff.insert(mapSignOff);
					}
				    Custom_free(pcSignOffLastModDateWithHMS);
				 }
				 
				 if(!setMapSignOff.empty())
				 {
					 MapSignOff lastModifiedSignOff =*setMapSignOff.begin();
	                 string strSignoffComment = lastModifiedSignOff.find("signoffComment")->second;
	                 string strReviewerName = lastModifiedSignOff.find("reviewer")->second;
					 if (pcNotificationReceiverEmail != NULL)
					 {
						 subject.assign(teradyneBuildNotificationSubjectReject(msg, strReviewerName));
						 string htmlBodyContent=teradyneBuildNotificationBodyContentReject(msg, strSignoffComment);
						 TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW); //required for teradyne_send_os_mail
						 TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject,strMailFilePath,pcNotificationReceiverEmail),TD_LOG_ERROR_AND_THROW); //sends the email
					 }
					 Custom_free(the_sender_email_addr);
					 DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
				 }
			}
			Custom_free(pcTypeName);
			Custom_free(pcObjectType);
			Custom_free(pcReviewerName);
			Custom_free(pcSignoffComments);
			Custom_free(pcNotificationReceiverEmail);
		}
	} catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}


 
/*******************************************************************************
 * Function Name			: teradyneBuildNotificationSubjectReject
 * Description				: Will return the subject for notification email
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  strSubject     - The subject for notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
 std::string teradyneBuildNotificationSubjectReject(EPM_action_message_t msg, string reviewerName){
  int iStatus			    = ITK_ok;

  string bufferSubject		= " ";

  char *jobName				= NULL,
	   *currentTask			= NULL,
	   *parentTaskName		= NULL;

  const char * __function__    = "teradyneBuildNotificationSubjectReject";
  
  try
  {
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"job_name",&jobName),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_string",&currentTask),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"parent_name",&parentTaskName),TD_LOG_ERROR_AND_THROW);
	  bufferSubject.append(jobName).append(" (Rejected by:").append(reviewerName).append(")");
	  Custom_free(jobName);
	  Custom_free(currentTask);
	  Custom_free(parentTaskName);

  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  return bufferSubject;
 }
 
 /*******************************************************************************
 * Function Name			: teradyneBuildNotificationBodyContentReject
 * Description				: Will build the html body content for notification 
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  bufferContent  - the html content for the notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
std::string teradyneBuildNotificationBodyContentReject(EPM_action_message_t msg, string commentEmail){
  int iStatus			    = ITK_ok,
	  iSignoffAttCount		= 0,
	  iCount				= 0;

  string bufferHTMLContent	= "<html><head></head><body>",
		pcComment			= "";

  char *jobName			= NULL,
	   *currentTask		= NULL,
	   *description		= NULL,
	   *pcDueDate		= NULL,
	   *objectname		= NULL;

  date_t due_date;

  tag_t *tAttaches				= NULL,
		*tSignoffAttachments	= NULL,
		tMember					= NULLTAG,
	    job						= NULLTAG,
	    root_task				= NULLTAG;
  
  
  const char * __function__    = "teradyneBuildNotificationBodyContentReject";
  
  try
  {
	 TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(msg.task, EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW);
	 pcComment = commentEmail;
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "job_name", &jobName) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "parent_name", &currentTask) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(msg.task, "due_date", &due_date) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_desc", &description) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = EPM_ask_job(msg.task,&job), TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(job, &root_task), TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(root_task, "object_name", &objectname), TD_LOG_ERROR_AND_THROW);
	 
	 if(due_date.year==0 && due_date.month==0 && due_date.day==0)
	 {
	      pcDueDate = (char *) MEM_alloc(sizeof(char) * 2);
		  strcpy(pcDueDate, "None");  
	 }
	 else
	 {
	     DATE_date_to_string	(due_date,"%d-%b-%Y %H:%M",&pcDueDate); // convert the date to string 
	 }

	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
	 bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 if (tc_strcasecmp(objectname, "TER_PartModifyRequestWF") == 0)
	 {
		 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append("</font>\r\n");
	 }
	 else {
		 if (tc_strcmp(currentTask, "OPS Task") == 0) {
			 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("OPS Task is Rejected").append("</font>\r\n");
		 }
		 else {
			 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("ECN is Rejected").append("</font>\r\n");
		 }
	 }

	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(jobName).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcComment).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("(none)").append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); //end table
	 bufferHTMLContent.append("<br>");
	 
	 // Target Attachments
     TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Target:</b></font>\r\n");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>\r\n");
	 
	 bufferHTMLContent.append("<tr height=\"8\">\r\n");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
	 
     for(int iTarget=0; iTarget < iCount;iTarget++)
	 {
	    char *pcItemId = NULL,*pcObjectType = NULL;
	    TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tAttaches[iTarget], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[iTarget],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
	   
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType);
	  }
     
     bufferHTMLContent.append("</tbody></table>\r\n"); // end target attachment tables
     bufferHTMLContent.append("<br><br>");

     // Target References
     int iRefCount=0;
	 tag_t *tReferenceAttachments;

	 TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iRefCount, &tReferenceAttachments), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Reference:</b></font>");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>");
	 
	 bufferHTMLContent.append("<tr height=\"8\">");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
     
      
     for(int iReference=0; iReference < iRefCount;iReference++)
	 {
        char *pcItemId = NULL,*pcObjectType = NULL;
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tReferenceAttachments[iReference], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tReferenceAttachments[iReference],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
						    
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType);
	 }
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); // end target references
     bufferHTMLContent.append("<br><br>");
     
     bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");
     
     
     Custom_free(tAttaches);
	 Custom_free(tSignoffAttachments);
     Custom_free(tReferenceAttachments);
	 Custom_free(jobName);
	 Custom_free(currentTask);
	 Custom_free(description);
	 Custom_free(objectname);
  
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  bufferHTMLContent.append("</body></html>\r\n");
  
  return bufferHTMLContent;
 }