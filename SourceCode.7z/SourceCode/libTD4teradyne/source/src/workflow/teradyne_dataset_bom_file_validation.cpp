/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_dataset_bom_file_validation.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-Check-BOM-File action handler
#      Project         :           libTD4teradyne          
#      Author          :           Janani          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  26-Nov-2015                       Janani                    	        Initial Creation
#  18-Dec-2015						 Janani								Reading preference  for header
#  28-Dec-2015						 Kameshwaran						Added condition for multiple occurrence of same column name in header
#  04-Jan-2016						 Kameshwaran						Added error throw if data is not available after header in CSV file.
#  08-Jan-2016						 Kameshwaran						Changed Warning level tp Error level for no data after header.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

class BomImportFileValidation
{
private:
	string strLogFileName;
	string strInputFilePath;
	ifstream fcsv;
	bool isFileOpen;
	Logger logger;
public:
	BomImportFileValidation();
	~BomImportFileValidation();

	int initializeLog();
	int uploadLogFile(EPM_action_message_t msg);
	int validateInputFile(EPM_action_message_t msg);
};

/*******************************************************************************
 * Function Name			: teradyne_dataset_bom_file_validation
 * Description				: This function will validate the dataset attached as a target and create a error log file
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_dataset_bom_file_validation(EPM_action_message_t msg)
{
	int iStatus = ITK_ok;

	const char * __function__    = "teradyne_dataset_bom_file_validation" ;
	TERADYNE_TRACE_ENTER();
	
	BomImportFileValidation fileValidationObj;
	fileValidationObj.initializeLog();
	try
	{
		TERADYNE_TRACE_CALL(iStatus = fileValidationObj.validateInputFile(msg), TD_LOG_ERROR_AND_THROW);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	fileValidationObj.uploadLogFile(msg);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  BomImportFileValidation constructor
*   Description			:  Standard constructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
BomImportFileValidation::BomImportFileValidation()
{
	int iStatus = ITK_ok;

	const char * __function__    = "BomImportFileValidation::BomImportFileValidation()" ;
	TERADYNE_TRACE_ENTER();

	strLogFileName = "";
	strInputFilePath = "";
	isFileOpen = false;

	TERADYNE_TRACE_LEAVE(iStatus);
}
/****************************************************************************
*   Function Name		:  BomImportFileValidation destructor
*   Description			:  Standard destructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
BomImportFileValidation::~BomImportFileValidation()
{
	int iStatus = ITK_ok;

	const char * __function__    = "BomImportFileValidation::BomImportFileValidation()" ;
	TERADYNE_TRACE_ENTER();

	if(isFileOpen)
		fcsv.close();

	remove(strInputFilePath.c_str());

	TERADYNE_TRACE_LEAVE(iStatus);
}
/****************************************************************************
*   Function Name		:  initializeLog
*   Description			:  Method to intialize the log file
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportFileValidation::initializeLog()
{
	int iStatus = ITK_ok;
	
	char* value = NULL;

	string strLogFileName = "";

	const char * __function__    = "BomImportFileValidation::initializeLog()" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		PREF_ask_char_value(TD_BOM_IMPORT_LOG_FILE_NAME_FORMAT_PREF,0,&value);
		if(value != NULL)
		{
			strLogFileName.assign(value);
		}
		else
		{
			strLogFileName.assign("BOMImport_LogFile_");
		}

		logger.createLogFile(strLogFileName,".log");
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(value);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  uploadLogFile
*   Description			:  Method to upload the log file and attach as target
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportFileValidation::uploadLogFile(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttachmentType	= EPM_reference_attachment;
		
	string strFilePath        = "",
		   strFileName        = "";

	tag_t  tagDataset       = NULLTAG,
			tRootTask       = NULLTAG;

	tag_t *tdataset			= {NULLTAG};

	AE_reference_type_t iRefType = AE_ASSOCIATION ;

	const char * __function__    = "BomImportFileValidation::uploadLogFile()" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		logger.closeFile();

		strFilePath = logger.getFilePath();
		strFileName = logger.getFileName();

		if(logger.getWasFileWritten() && strFilePath != "" && strFilePath.length() >= 0 && strFileName != "" && strFileName.length() >= 0)
		{
			TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_dataset((char*)strFileName.c_str(),"",TD_TEXT_DTYPE,TD_TEXT_FORMATTYPE,(char*)strFilePath.c_str(),TD_TEXT_DTYPE,iRefType,&tagDataset), TD_LOG_ERROR_AND_THROW);
			tdataset = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
			tdataset[0] = tagDataset;
			TERADYNE_TRACE_CALL(iStatus = EPM_add_attachments(tRootTask, 1,tdataset,&iAttachmentType), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tdataset);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  validateInputFile
*   Description			:  Method to validate the given input file
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportFileValidation::validateInputFile(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iFound              = 0;
		
	string strErrMsg        = "",
           strFilePath      = "",
		   line             = "";
	
	tag_t *tAttachtag       = {NULLTAG},
          *tagReferencedObj	= {NULLTAG};
		   
	char  *pcobjname          = NULL,
		  *extname            = NULL;

	std::map<string,int> mapHeaderPosMap;

	const char * __function__    = "BomImportFileValidation::validateInputFile()" ;
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
	    if ( iAttachCount == 1 )
	    {
			TERADYNE_TRACE_CALL(iStatus = AE_ask_all_dataset_named_refs2(tAttachtag[0], TD_CSV_REFNAME, &iFound, &tagReferencedObj), TD_LOG_ERROR_AND_THROW);
			
			if (iFound <= 0)
			{
				strErrMsg = "Input File is missing.";
				logger.log(strErrMsg,Logger::ERROR_LEVEL);
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		        iStatus = TD_CSVLOG_ERROR;
		        throw iStatus;
			}
			if (iFound > 1)
			{
				strErrMsg = "Multiple Files in the dataset. Please remove and keep only one file.";
				logger.log(strErrMsg,Logger::ERROR_LEVEL);
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		        iStatus = TD_CSVLOG_ERROR;
		        throw iStatus;
			}

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tagReferencedObj[0],TD_FILE_EXT_ATTR,&extname), TD_LOG_ERROR_AND_THROW); 
			if ( tc_strcmp(extname, "csv") == 0) 
			{
				//Export the file to temp
				TERADYNE_TRACE_CALL(iStatus = teradyne_export_file_to_temp(tAttachtag[0], tagReferencedObj[0], TD_CSV_REFNAME, strInputFilePath) , TD_LOG_ERROR_AND_THROW);
				fcsv.open(strInputFilePath.c_str());
				/*Verify that the file was able to open*/
				if(fcsv.is_open())
				{
					isFileOpen = true;

					// Verify the given file is not empty
					if ( fcsv.peek() == ifstream::traits_type::eof() )
					{
						strErrMsg = "The input file does not have any data.";
						logger.log(strErrMsg, Logger::ERROR_LEVEL);
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_CSVLOG_ERROR;
						throw iStatus;
					}
					else
					{
						// Read the first line
						getline(fcsv,line);
						if(line != "" && line.length() > 0 )
						{
							teradyne_read_csv_header(line,&strErrMsg,&mapHeaderPosMap);
							if(strErrMsg != "" && strErrMsg.length() > 0)
							{
								logger.log(strErrMsg, Logger::ERROR_LEVEL);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_CSVLOG_ERROR;
								throw iStatus;
							}
						}
						else
						{
							strErrMsg   = "Input file is not in the correct format. The first line of the file must have headers defined.";
							logger.log(strErrMsg, Logger::ERROR_LEVEL);
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_CSVLOG_ERROR;
							throw iStatus;
						}

						// Read all the lines
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[0],TD_ITEMID_ATTR,&pcobjname), TD_LOG_ERROR_AND_THROW);
						std::vector<string> strLineTokens;
						std::vector<string> strParentItem;
						int parentpos = -1;
						bool bFileHasData = false;
						if(mapHeaderPosMap.find("bl_parent_line") != mapHeaderPosMap.end())
						{
							parentpos = mapHeaderPosMap.find("bl_parent_line")->second;
						}
						while(getline(fcsv,line)) 
						{
							if(line != "" && line.length() >= 0)
							{
								if(!bFileHasData)
									bFileHasData = true;
								strLineTokens.clear();
								strLineTokens = splitString(line,",",true);
								if(parentpos != -1 && strLineTokens.size() >= parentpos)
								{
									strParentItem.push_back(strLineTokens[parentpos]);
								}
							}
						}
						if(!bFileHasData)
						{
							strErrMsg = "The input file does not have any data, only header information is available.";
							logger.log( strErrMsg, Logger::ERROR_LEVEL);
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_CSVLOG_ERROR;
							throw iStatus;
						}
						else if(strParentItem.size() > 0 )
						{
							if ( std::adjacent_find( strParentItem.begin(), strParentItem.end(), std::not_equal_to<string>() ) == strParentItem.end() )
							{
								if(tc_strcmp(strParentItem[0].c_str(),pcobjname) != 0)
								{
									strErrMsg   = "Parent item does not match the given Item.";
									logger.log(strErrMsg,Logger::ERROR_LEVEL);
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
									iStatus = TD_CSVLOG_ERROR;
									throw iStatus;
								}
							}
							else
							{
								strErrMsg   = "There are multiple parents in the input file.";
								logger.log(strErrMsg,Logger::ERROR_LEVEL);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_CSVLOG_ERROR;
								throw iStatus;
							}
						}
					}

				}
				else
				{
					strErrMsg   = "Unable to open the input file";
					logger.log(strErrMsg,Logger::ERROR_LEVEL);
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		            iStatus = TD_CSVLOG_ERROR;
		            throw iStatus;
				}
			}
			else
		    {
				strErrMsg = "No CSV file found";
				logger.log(strErrMsg,Logger::ERROR_LEVEL);
			    TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		        iStatus = TD_CSVLOG_ERROR;
		        throw iStatus;
		    }
		}
		else if(iAttachCount > 1)
		{
			strErrMsg = "There are multiple targets attached. Please remove and keep only one target attachment.";
			logger.log(strErrMsg, Logger::ERROR_LEVEL);
		    TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		    iStatus = TD_CSVLOG_ERROR;
		    throw iStatus;
		}
		else
		{
			strErrMsg = "There are no targets attached. Please verify.";
			logger.log(strErrMsg, Logger::ERROR_LEVEL);
		    TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_CSVLOG_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		    iStatus = TD_CSVLOG_ERROR;
		    throw iStatus;
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(extname);
	Custom_free(pcobjname);
	Custom_free(tagReferencedObj);
	Custom_free(tAttachtag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/***************************************************************************************
*   Function Name       : teradyne_read_csv_header
*   Description         : This function parses the header line from the csv file and validates
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         char delim
*
*   RETURN VALUE        : vector of elements
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
int teradyne_read_csv_header(string strLine,string *err,map<string,int> *HeaderposMap)
{
	int iPrefCount	= 0,
		iStatus	= ITK_ok;

	std::map<string,string> mapHeaderPref;
	std::vector<string> vectorTok;

	char **sPrefValues = NULL;
	char *cFindNoVal    = NULL;
	bool bHedrAvailFlag = false;
	string strUprCase = "";

	mapHeaderPref.clear();
	*err = "";
	
	const char * __function__    = "teradyne_read_csv_header" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get Header Column Pref
		PREF_ask_char_values (TD_BOMCSV_COLUMN_NAME_PREF,&iPrefCount,&sPrefValues);

		for(int incr = 0; incr < iPrefCount; incr++)
		{
			vectorTok.clear();
			vectorTok = splitString(sPrefValues[incr],":",false);

			// userColmnName , HardcodedColumnName
			if(vectorTok.size() == 2){
				strUprCase = vectorTok[0];
				std::transform(strUprCase.begin(), strUprCase.end(),strUprCase.begin(), ::toupper);//Store all as UPPER CASE
				mapHeaderPref.insert(pair<string,string>(strUprCase,vectorTok[1])); 
			}
		}
		strUprCase = "";
		if(mapHeaderPref.size() > 0)
		{
			std::vector<string> strLineHeaderTokens = splitString(strLine,",",false);
			for(int i = 0; i < strLineHeaderTokens.size(); i++)
			{
				if(strLineHeaderTokens[i] == "" || strLineHeaderTokens[i].length() <= 0)
				{
					*err = "The header line in the file has a empty value. Please correct.";
					break;
				}

				strUprCase = strLineHeaderTokens[i];
				std::transform(strUprCase.begin(), strUprCase.end(),strUprCase.begin(), ::toupper);

				if(mapHeaderPref.find(strUprCase.c_str()) != mapHeaderPref.end())
				{
					// Contain Hardcoded Header Name and position
					if(HeaderposMap->find(mapHeaderPref.find(strUprCase.c_str())->second) == HeaderposMap->end())
					{
						HeaderposMap->insert(pair<string,int>(mapHeaderPref.find(strUprCase.c_str())->second,(i)));
					}
					else
					{
						*err = "Column \"" + strLineHeaderTokens[i] + "\" occurs multiple time in the header.";
						break;
					}
				}
				else
				{
					*err = "Input file is not in the correct format. The header " + strLineHeaderTokens[i] + " is not defined in the CSV column name preference.";
					break;
				}
			}

			if(HeaderposMap->size() > 0 )
			{
				if(HeaderposMap->find("bl_parent_line") == HeaderposMap->end())
				{
					*err = "Input file is not in the correct format. The header for parent item is not defined in the CSV file.";
				}
				else if(HeaderposMap->find("bl_child_line") == HeaderposMap->end())
				{
					*err = "Input file is not in the correct format. The header for component is not defined in the CSV file.";
				}
				else
				{
					//Get FindNo pref is set or Not
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value (TD_BOMCSV_FINDNO_PREF,0,&cFindNoVal), TD_LOG_ERROR_AND_THROW);
					if ((tc_strcmp(cFindNoVal,"True") == 0 || tc_strcmp(cFindNoVal,"true") == 0) && HeaderposMap->find("bl_findno") == HeaderposMap->end())
					{
						*err   = "Find Number column is Mandatory in CSV file.";
					}
				}
			}
		}
		else
		{
			*err = "The CSV column names preference is missing.";
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}	
	}
	Custom_free(cFindNoVal);
	Custom_free(sPrefValues);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
