/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_bom_import_validation.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ImportBOMs action handler
#      Project         :           libTD4teradyne          
#      Author          :           kameshwaran          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Dec-2015                       kameshwaran                    	 Initial Creation
#  27-Dec-2015						 kameshwaran						 Added Move redofile dataset to target.  
#  28-Dec-2015						 kameshwaran						 Changed parse_ref_designator func with new function
#  29-Dec-2015						 Kameshwaran 						 Removed Remarks related all checks
#  30-Dec-2015						 Kameshwaran 						 Handled BVR delete error case.
#  12-Jan-2016                       Manimaran                           Modified the code to fix Workflow background processing error when target attachment is empty.
#  =================================================================================================*/ 
#define NOMINMAX
#include <workflow/teradyne_handlers.h>

typedef struct BomLineInfo{
	string str_id;
	string str_ref_desg;
	string str_qty;
	string str_find_no;
	string str_status;
	string str_remarks;
	tag_t tLine;

}lineinfo;

class BomImportCSV
{
private:
	string strParentItem;
	string strInputFilePath;
	ifstream fcsv;
	Logger redoFile;
	bool isFileOpen;
	bool isRedoFile;
	std::vector<BomLineInfo> vecLineInfo;
	std::map<int,vector<string>> csvFileMap;
	std::map<int,string> csvMap;
	std::map<int,vector<string>> csvRedoFileMap;
	std::map<int,vector<string>> csvProcessedMap;
public:
	BomImportCSV();
	~BomImportCSV();

	Logger logger;
	int initializeLog();
	int initializeRedoFile(EPM_action_message_t msg);
	int uploadLogFile(EPM_action_message_t msg);
	int uploadRedoFile(EPM_action_message_t msg,int iBvrErr);
	int importBom(EPM_action_message_t msg);
	int teradyne_csv_attribute_validation(int prtAssPos,int refDesPos,int findno_pos,
									      int qtyPos,int remark_pos,bool bFndNo,int MaxFndNoAlot,bool bZeroQnty, bool bQuanflag);
	int teradyne_get_same_component_from_csv_map(map<int,vector<string>> csvFileMap, string strPrtChild,int prtAssPos,int iQtyPos,map<int, vector<string>> *mapSameCmpnt);
	int teradyne_find_same_seqno_different_component(int prtAssPos,string strPrtChild,int findno_pos,int iFindNo,map<int,vector<string>> csvFileMap,vector<string> *sameCmpntVec);
	int teradyne_validate_and_update_csv_attribute(	int findno_pos,string strFndNo,int prtAssPos,string strPrtChild,bool bOneFindNo,
												int *MaxFndNoAlot,map<int, vector<string>> csvFileMap, map<int, vector<string>> mapSameCmpnt,
												int refDesPos,int qtyPos,bool bZeroQnty,bool bQuanflag,int remark_pos);
	int teradyne_validate_quantity_and_refdesgnator(bool bZeroQntyAllwd,bool bQuanflag,string strQtyValue,string strRefDes,string *strErrLog,bool *bQtRefDesError);
	int teradyne_remarks_validate_same_component(map<int ,vector<string>> &mapSameCmpnt,int remark_pos,bool *bRmrkMisMatchErr);
	int teradyne_bom_import_master(vector<string> vecAllwdPrntPrt,vector<string> vecAllChldPrt,int prtNoPos,int prtAssPos,int refdes_pos,int qty_pos,int remark_pos,int findno_pos);
	int teradyne_get_item_and_latest_rev_tag(string strItemID,vector<string> vecAllwdPart,tag_t *tItemTag, tag_t *tItemRevTag);
	int teradyne_get_bom_line_info(string str_id,int *maxFindNo);
	int teradyne_create_bom_window_map(tag_t tParentLine,int *maxFindNo);
	int teradyne_check_same_seq_diff_comp(string sFindNo,string sPrtNo,string sQty,string *sErrror,logical *bError);
	std::map<int,vector<string>> getcsvFileMap();
	std::map<int,vector<string>> getcsvRedoFileMap();
};

/****************************************************************************
*   Function Name		:  BomImportCSV constructor
*   Description			:  Standard constructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
BomImportCSV::BomImportCSV()
{
	int iStatus = ITK_ok;

	const char * __function__    = "BomImportCSV::BomImportCSV()" ;
	TERADYNE_TRACE_ENTER();

	strInputFilePath = "";
	strParentItem = "";
	isFileOpen = false;

	TERADYNE_TRACE_LEAVE(iStatus);
}
/****************************************************************************
*   Function Name		:  BomImportCSV destructor
*   Description			:  Standard destructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
BomImportCSV::~BomImportCSV()
{
	int iStatus = ITK_ok;

	const char * __function__    = "BomImportCSV::BomImportCSV()" ;
	TERADYNE_TRACE_ENTER();

	if(isFileOpen)
		fcsv.close();

	remove(strInputFilePath.c_str());

	TERADYNE_TRACE_LEAVE(iStatus);
}
/****************************************************************************
*   Function Name		:  Getter Methods
*   Description			:  
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
std::map<int,vector<string>> BomImportCSV::getcsvFileMap()
{
	return csvFileMap;
}

std::map<int,vector<string>> BomImportCSV::getcsvRedoFileMap()
{
	return csvRedoFileMap;
}
/****************************************************************************
*   Function Name		:  initializeLog
*   Description			:  Method to intialize the log file
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::initializeLog()
{
	int iStatus = ITK_ok;
	
	char* value = NULL;

	string strLogFileName = "";

	const char * __function__    = "BomImportCSV::initializeLog()" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		PREF_ask_char_value(TD_BOM_IMPORT_LOG_FILE_NAME_FORMAT_PREF,0,&value);
		if(value != NULL)
		{
			strLogFileName.assign(value);
		}
		else
		{
			strLogFileName.assign("BOMImport_LogFile_");
		}

		logger.createLogFile(strLogFileName,".log");
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(value);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  initializeRedoFile
*   Description			:  Method to intialize the Redo File
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::initializeRedoFile(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttachCount = 0;

	char* value = NULL;
	char* pcItemIdvalue = NULL;
	char* pcItemRevIdvalue = NULL;

	tag_t *tAttachtag       = {NULLTAG};

	string strRedoFileName = "";
	std::vector<string> strTokens;

	const char * __function__    = "BomImportCSV::initializeRedoFile()" ;
	TERADYNE_TRACE_ENTER();

	teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag);
	if ( iAttachCount == 1 )
	{
		PREF_ask_char_value(TD_BOM_IMPORT_REDO_FILE_NAME_FORMAT_PREF,0,&value);
		if(value != NULL)
		{
			strTokens = splitString(value, "_", false);
			if(strTokens.size() == 2)
			{
				strRedoFileName.append(strTokens[0]).append("_");
				strTokens[1].replace(0,1,"");
				strTokens[1].replace(strTokens[1].length() - 1, 1, "" );
				std::vector<string> strpropTokens = splitString(strTokens[1], ":", false );
				bool bWasItemIDFound = false;
				bool bWasRevIDFound = false;
				for(int i = 0; i < strpropTokens.size(); i++)
				{
					if(strpropTokens[i] == "" || strpropTokens[i].length() <= 0 )
						continue;
					if(strpropTokens[i] == "ItemID")
					{
						AOM_ask_value_string(tAttachtag[0],TD_ITEMID_ATTR,&pcItemIdvalue);
						if(pcItemIdvalue != NULL)
						{
							if(bWasRevIDFound == true)
								strRedoFileName.append("-");
							strRedoFileName.append(pcItemIdvalue);
							bWasItemIDFound = true;
						}
					}
					if(strpropTokens[i] == "RevID")
					{
						AOM_ask_value_string(tAttachtag[0],TD_REVID_ATTR,&pcItemRevIdvalue);
						if(pcItemRevIdvalue != NULL)
						{
							if(bWasItemIDFound == true)
								strRedoFileName.append("-");
							strRedoFileName.append(pcItemRevIdvalue);
							bWasRevIDFound = true;
						}
					}
				}

				if(strRedoFileName != "" && strRedoFileName.length() >= 0)
					strRedoFileName.append("_");
			}
		}
	}

	if(strRedoFileName == "" || strRedoFileName.length() <= 0)
		strRedoFileName.assign("BOMImport_RedoFile_");

	redoFile.createLogFile(strRedoFileName,".csv");

	Custom_free(value);
	Custom_free(pcItemIdvalue);
	Custom_free(pcItemRevIdvalue);
	Custom_free(tAttachtag);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  uploadLogFile
*   Description			:  Method to upload the log file and attach as Reference
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::uploadLogFile(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttachmentType	= EPM_reference_attachment;
		
	string strFilePath        = "",
		   strFileName        = "";

	tag_t  tagDataset       = NULLTAG,
			tRootTask       = NULLTAG;

	tag_t *tdataset			= {NULLTAG};

	AE_reference_type_t iRefType = AE_ASSOCIATION ;

	const char * __function__    = "BomImportCSV::uploadLogFile()" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		logger.closeFile();

		strFilePath = logger.getFilePath();
		strFileName = logger.getFileName();

		if(logger.getWasFileWritten() && strFilePath != "" && strFilePath.length() >= 0 && strFileName != "" && strFileName.length() >= 0)
		{
			TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_dataset((char*)strFileName.c_str(),"",TD_TEXT_DTYPE,TD_TEXT_FORMATTYPE,(char*)strFilePath.c_str(),TD_TEXT_DTYPE,iRefType,&tagDataset), TD_LOG_ERROR_AND_THROW);
			tdataset = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
			tdataset[0] = tagDataset;
			TERADYNE_TRACE_CALL(iStatus = EPM_add_attachments(tRootTask, 1,tdataset,&iAttachmentType), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tdataset);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  uploadRedoFile
*   Description			:  Method to upload the Redo file and attach as Reference
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::uploadRedoFile(EPM_action_message_t msg,int iBvrStat)
{
	int iStatus = ITK_ok,
		iRefAttachType	= EPM_reference_attachment,
		iTrgtAttchType	= EPM_target_attachment,
		iAttachCount = 0,
		iNumOfRefs   = 0;
		
	string strFilePath        = "",
		   strFileName        = "";

	tag_t  tagDataset       = NULLTAG,
		   tRootTask       = NULLTAG;

	tag_t *tdataset			= {NULLTAG},
		  *tAttDset			= {NULLTAG},
		  *tAttachtag       = {NULLTAG},
		  *dsRefs           = {NULLTAG};

	char *pcItemIdvalue		= NULL,
		 *pcItemRevIdvalue	= NULL;

	logical bRedoFile = true;

	AE_reference_type_t iRefType = AE_ASSOCIATION ;

	const char * __function__    = "BomImportCSV::uploadRedoFile()" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		redoFile.closeFile();
		if(isFileOpen)
		{
			fcsv.close();
			isFileOpen = false;
		}

		strFilePath = redoFile.getFilePath();
		strFileName = redoFile.getFileName();

		if(redoFile.getWasFileWritten() && strFilePath != "" && strFilePath.length() >= 0 && strFileName != "" && strFileName.length() >= 0 && getcsvRedoFileMap().size() > 1 && (iBvrStat == ITK_ok) )
		{
			TERADYNE_TRACE_CALL( iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
			
			// Move the target dataset to reference
			TERADYNE_TRACE_CALL ( iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);

			tAttDset = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
			tAttDset[0] = tAttachtag[0];

			TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_string(tAttachtag[0],TD_ITEMID_ATTR,&pcItemIdvalue), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_string(tAttachtag[0],TD_REVID_ATTR,&pcItemRevIdvalue), TD_LOG_ERROR_AND_THROW);

			// Create and attach the RedoFile dataset under target attatchment
			TERADYNE_TRACE_CALL( iStatus = teradyne_create_dataset((char*)strFileName.c_str(),"",TD_DATASETTYPE_CSV ,TD_BINARY_FORMATTYPE,(char*)strFilePath.c_str(),TD_CSV_REFNAME,iRefType,&tagDataset), TD_LOG_ERROR_AND_THROW);
			tdataset = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
			tdataset[0] = tagDataset;
			TERADYNE_TRACE_CALL( iStatus = EPM_add_attachments(tRootTask, 1,tdataset,&iTrgtAttchType), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL ( iStatus = EPM_remove_attachments(tRootTask,1,tAttDset), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = EPM_add_attachments(tRootTask,1,tAttDset,&iRefAttachType), TD_LOG_ERROR_AND_THROW);

			//Set Custom ItemId , RevId and RedoFile attribute to true
			TERADYNE_TRACE_CALL( iStatus = AOM_lock(tagDataset), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AOM_set_value_string( tagDataset,TD_ITEMID_ATTR,pcItemIdvalue), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AOM_set_value_string( tagDataset,TD_REVID_ATTR,pcItemRevIdvalue), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AOM_set_value_logical(tagDataset,TD_REFO_FILE_ATTR,bRedoFile), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AE_save_myself(tagDataset), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = AOM_unlock(tagDataset), TD_LOG_ERROR_AND_THROW);

			remove(strFilePath.c_str()); //Remove the RedoFile from temp location
			
		}
		if( iBvrStat != 0) remove(strFilePath.c_str());
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tdataset);
	Custom_free(dsRefs);
	Custom_free(tAttachtag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_bom_import_validation
 * Description				: To validate the bom and import the bom
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: To validate the bom and import the bom
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_bom_import_from_csv(EPM_action_message_t msg)
{
	int iStatus			= ITK_ok,
		iAttachCount	= 0,
		iStatBvr		= 0;

	tag_t * tAttachtag = NULLTAG;
	const char * __function__    = "teradyne_bom_import_from_csv" ;
	TERADYNE_TRACE_ENTER();
	
	BomImportCSV impBom;
	impBom.initializeLog();
	impBom.initializeRedoFile(msg);
	try
	{
		iStatus = impBom.importBom(msg);
		if( (impBom.getcsvRedoFileMap().size() > 1) || iStatus > 0)
		{
			string strErrMsg   = "";

			iStatBvr = iStatus;

			if(iStatus == 0) strErrMsg = "BOM Import partially failed.";
			else strErrMsg = "[" + to_string((long double)iStatus) +"] No. BOM Import Failed";

			impBom.logger.log(strErrMsg,Logger::ERROR_LEVEL);
			TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_IMPORT_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		    iStatus = TD_BOM_IMPORT_ERROR;
		    throw iStatus;
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	iStatus = impBom.uploadRedoFile(msg,iStatBvr);
	iStatus = impBom.uploadLogFile(msg);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  importBom
*   Description			:  Method to import the BOM
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::importBom(EPM_action_message_t msg)
{
	int refdes_pos		 = -1,
		parent_pos		 = -1,
		comp_pos		 = -1,
		qty_pos			 = -1,
		remark_pos		 = -1,
		findno_pos	 	 = -1,
		iStatus			 = 0,
		prtNoPos		 = 0,
		prtAssPos		 = 0,
		iPrefCount		 = 0,
		iAttachCount     = 0,
		iFound           = 0,
		iFounditem       = 0,
		MaxFndNoAlot	 = 0;

	char *sPrefValue2	= NULL,
		 *sPrefValue3	= NULL,
		 *pcobjname     = NULL,
		 *pcObjectType  = NULL,
		 **sPrefValues1 = NULL;

	string strErrMsg		= "",
		   line				= "";

	bool bquan_flag		= false,
		 bzeroQuan		= true,
		 bFndNo			= true;

	map<string,int> HeaderposMap;

	std::vector<string> vectorTok, vecAllwdPrtNo,vecAllwdPrtAss;

	tag_t *tAttachtag       = {NULLTAG},
		  *tagReferencedObj = {NULLTAG},
		  *tFindItemTag     = {NULLTAG};

	const char * __function__    = "BomImportCSV::importBom" ;
	TERADYNE_TRACE_ENTER();

	try
	{
	    TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
		
	    if ( iAttachCount == 1 )
	    {
			TERADYNE_TRACE_CALL (iStatus = AE_ask_dataset_named_refs(tAttachtag[0],&iFound,&tagReferencedObj), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = teradyne_export_file_to_temp(tAttachtag[0], tagReferencedObj[0], TD_CSV_REFNAME, strInputFilePath) , TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttachtag[0], TD_REFO_FILE_ATTR,&isRedoFile) , TD_LOG_ERROR_AND_THROW);

			fcsv.open(strInputFilePath.c_str());
			if(fcsv.is_open())
			{
				// Read the header line
				isFileOpen = true;

				getline(fcsv,line);
				TERADYNE_TRACE_CALL(iStatus = teradyne_read_csv_header(line,&strErrMsg,&HeaderposMap), TD_LOG_ERROR_AND_THROW);
				if(strErrMsg != "" && strErrMsg.length() > 0)
				{
					logger.log(strErrMsg, Logger::ERROR_LEVEL);
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_IMPORT_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_BOM_IMPORT_ERROR;
					throw iStatus;
				}

				/*GET the column positions*/
				if( HeaderposMap.find("bl_parent_line") != HeaderposMap.end())			prtNoPos	= HeaderposMap.find("bl_parent_line")->second;
				if( HeaderposMap.find("bl_child_line") != HeaderposMap.end())			prtAssPos	= HeaderposMap.find("bl_child_line")->second;
				if( HeaderposMap.find("bl_reference_designator") != HeaderposMap.end())	refdes_pos  = HeaderposMap.find("bl_reference_designator")->second;
				if( HeaderposMap.find("bl_quantity") != HeaderposMap.end())				qty_pos		= HeaderposMap.find("bl_quantity")->second;
				if( HeaderposMap.find("bl_remarks") != HeaderposMap.end())				remark_pos  = HeaderposMap.find("bl_remarks")->second;
				if( HeaderposMap.find("bl_findno") != HeaderposMap.end())
				{				
					findno_pos	= HeaderposMap.find("bl_findno")->second;
				} 
				else { findno_pos = (int)HeaderposMap.size(); bFndNo = false;}
			
				vectorTok = splitString(line,",",false);

				csvRedoFileMap.insert(make_pair(1,vectorTok));
				redoFile.log(line);

				/* Read Preferences from Teamcenter */
				//Get qnty-Refdes pref set to More/Equal
				TERADYNE_TRACE_CALL(iStatus =PREF_ask_char_value (TD_BOMCSV_QTYREFDES_PREF,0,&sPrefValue2), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(sPrefValue2,"More") == 0)
				{
					bquan_flag = true;
				}

				//Get qnty pref to allow zero or not
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value (TD_BOMCSV_ZERO_QTY_PREF,0,&sPrefValue3), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(sPrefValue3,"False")== 0)
				{
					bzeroQuan = false;
				}
			 
				//Get Allowed Parts Pref
				TERADYNE_TRACE_CALL(iStatus =PREF_ask_char_values (TD_BOMCSV_ALLOWED_PARTS_PREF,&iPrefCount,&sPrefValues1), TD_LOG_ERROR_AND_THROW);
				for(int incr = 0; incr<iPrefCount; incr++)
				{
					string strValue = "";
					strValue.assign(sPrefValues1[incr]);

					vectorTok.clear();
					vectorTok = teradyne_generate_tokens(strValue,":");

					if(vectorTok.size() == 2)
					{
						vecAllwdPrtNo.push_back(vectorTok[0]);	 // Allowed Parent assembly
						vecAllwdPrtAss.push_back(vectorTok[1]);	 // Allowed Part no
					}
				}

				// Read all lines from the file
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[0],TD_ITEMID_ATTR,&pcobjname), TD_LOG_ERROR_AND_THROW);
				strParentItem.assign(pcobjname);

				//Declarations
				std::vector<string> strLineTokens;
				string componentId	= "";
				bool bPartAllowed	= false;
				tag_t tAllwdPrtTag	= NULLTAG,
					  *tstatusTag	= {NULLTAG},
					  tLatestRev	= NULLTAG;
				int lineNo			= 2,
					iRelCnt			= 0,
					MaxFndNoAlot    = 0,
					iFindNumber     = 0;

				while(getline(fcsv,line)) 
				{
					if(line != "" && line.length() >= 0)
					{
						strLineTokens.clear();
						strLineTokens = splitString(line,",",true);

						if(strLineTokens.size() == HeaderposMap.size())
						{
							strLineTokens[qty_pos].erase(std::remove(strLineTokens[qty_pos].begin(), strLineTokens[qty_pos].end(), ' '), strLineTokens[qty_pos].end());
							if( strLineTokens[qty_pos] != "" && strLineTokens[qty_pos].length() > 0 && strLineTokens[qty_pos] == "0")
							{
								if(!bzeroQuan)
								{
									csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
									redoFile.log(line);
									logger.log("LineNo ["+toString(lineNo)+"] : item <"+ strLineTokens[prtAssPos] +"> has zero quantity specified which is not allowed", Logger::ERROR_LEVEL);
									continue;
								}
							}
							componentId.clear();
							componentId = strLineTokens[prtAssPos];
							if(componentId != "" && componentId.length() > 0)
							{
								if( componentId != strParentItem )
								{
									TERADYNE_TRACE_CALL(iStatus = ITEM_find((char*)componentId.c_str(),&iFounditem,&tFindItemTag),TD_LOG_ERROR_AND_THROW);
									if(iFounditem <= 0 )
									{
										csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
										redoFile.log(line);
										logger.log("LineNo ["+toString(lineNo)+"] : item <"+ strLineTokens[prtAssPos] +"> not exist in Teamcenter.", Logger::ERROR_LEVEL);
									}
									else
									{
										// If there are multiple items found for the ID search the type given in the preference
										bPartAllowed = false;
										tAllwdPrtTag = NULLTAG;
										tLatestRev = NULLTAG;
										iRelCnt = 0;
										iFindNumber = 0;
										for(int i = 0; i < iFounditem; i++)
										{
											TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindItemTag[i], &pcObjectType),TD_LOG_ERROR_AND_THROW);
											if ( std::find(vecAllwdPrtAss.begin(), vecAllwdPrtAss.end(), pcObjectType) != vecAllwdPrtAss.end() )
											{
												tAllwdPrtTag = tFindItemTag[i];
												bPartAllowed = true;
												break;
											}
										}
										if(!bPartAllowed)
										{
											csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
											redoFile.log(line);
											logger.log("LineNo ["+toString(lineNo)+"] : item <"+ strLineTokens[prtAssPos] +"> are different types that are not supported.", Logger::ERROR_LEVEL);
										}
										else
										{
											/* No need to check Component latest release revision check* /
											TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tAllwdPrtTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tLatestRev,&iRelCnt,&tstatusTag),TD_LOG_ERROR_AND_THROW);
											if(iRelCnt > 0)
											{
												csvRedoFileMap.insert(make_pair<int,vector<string>>(lineNo,strLineTokens));
												redoFile.log(line);
												logger.log("LineNo "+toString(lineNo)+" has component which does not have latest working revision", Logger::ERROR_LEVEL);
											}
											else
											{
											/**/
												// The line is valid
												if(bFndNo)
												{
													strLineTokens[findno_pos].erase(std::remove(strLineTokens[findno_pos].begin(), strLineTokens[findno_pos].end(), ' '), strLineTokens[findno_pos].end());
													if(strLineTokens[findno_pos] != "" && strLineTokens[findno_pos].length() > 0)
													{
														iFindNumber = stoi(strLineTokens[findno_pos]);
														if(iFindNumber > MaxFndNoAlot)
															MaxFndNoAlot = iFindNumber;
													}
												}
												else
												{
													strLineTokens.push_back("");
												}
												csvFileMap.insert(make_pair(lineNo,strLineTokens));
												csvMap.insert(make_pair(lineNo,line));
											//}
										}
									}
								}
								else
								{
									csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
									redoFile.log(line);
									logger.log("LineNo ["+toString(lineNo)+"] : item <"+ strLineTokens[prtAssPos] +"> Circular reference found.", Logger::ERROR_LEVEL);
								}
							}
							else
							{
								csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
								redoFile.log(line);
								logger.log("LineNo "+toString(lineNo)+" has no component specified", Logger::ERROR_LEVEL);
							}
						}
						else
						{
							csvRedoFileMap.insert(make_pair(lineNo,strLineTokens));
							redoFile.log(line);
							logger.log("LineNo "+toString(lineNo)+" has incorrect number of columns specified", Logger::ERROR_LEVEL);
						}
					}

					lineNo++;
				}
				if(isRedoFile){//Get the Bom line values and maxFindNo.
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_bom_line_info(strParentItem,&MaxFndNoAlot), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(iStatus = teradyne_csv_attribute_validation(prtAssPos, refdes_pos, findno_pos, qty_pos, remark_pos, bFndNo, MaxFndNoAlot, bzeroQuan, bquan_flag), TD_LOG_ERROR_AND_THROW);
				if(csvProcessedMap.size() > 0 )
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_bom_import_master(vecAllwdPrtNo,vecAllwdPrtAss,prtNoPos,prtAssPos,refdes_pos,qty_pos,remark_pos,findno_pos), TD_LOG_ERROR_AND_THROW);
				}
			}
			else
			{
				strErrMsg   = "Unable to open the input file";
				logger.log(strErrMsg,Logger::ERROR_LEVEL);
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_IMPORT_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
		        iStatus = TD_BOM_IMPORT_ERROR;
		        throw iStatus;
			}									
		}
	}
	catch(...)
	{ 
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}	
	}

	Custom_free(tAttachtag);
	Custom_free(tagReferencedObj);
	Custom_free(pcobjname);
	Custom_free(pcObjectType);
	Custom_free(sPrefValue2);
	Custom_free(sPrefValue3);
	Custom_free(sPrefValues1);
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_csv_attribute_validation
*   Description			:  Method to validate the attributes of the BOMLine
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_csv_attribute_validation(int prtAssPos,int refDesPos,int findno_pos,int qtyPos,int remark_pos,bool bFndNo,int MaxFndNoAlot,bool bZeroQnty, bool bQuanflag)
{
	int iStatus = ITK_ok;

	bool bQtRefDesError		= false,
		 bCntIncr			= true;		

	string strErrLog	= "",
		   strFndNoVal	= "";

	const char * __function__    = "teradyne_csv_attribute_validation" ;
	TERADYNE_TRACE_ENTER();

	map<int, vector<string> >::iterator itr = csvFileMap.begin();
	map<int, vector<string> > mapSameCmpnt;
	csvProcessedMap.clear();
	try{
		for(itr ; itr != csvFileMap.end(); itr++){
			bQtRefDesError = false;
			bCntIncr	   = true;
			if(!bFndNo){//FindNo column is not present
				
				string strPrtChild = itr->second[prtAssPos];
				string strQty	   = itr->second[qtyPos];
				if(csvProcessedMap.find(itr->first) == csvProcessedMap.end() && csvRedoFileMap.find(itr->first) == csvRedoFileMap.end()){
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_same_component_from_csv_map(csvFileMap,strPrtChild,prtAssPos,qtyPos,&mapSameCmpnt), TD_LOG_ERROR_AND_THROW); // Get same component
				}
				else continue; // Already Processed

				map<int,vector<string> >::iterator itrSamCmp = mapSameCmpnt.begin();

				for(itrSamCmp ; itrSamCmp != mapSameCmpnt.end() ; itrSamCmp++){
					strErrLog = "";
					strFndNoVal = "";
					bQtRefDesError = false;
					//RedoFile when findno column not present but already teamcenter have seqno for same component
					if(isRedoFile)
					{
						int iQtyVal = -1;
						strErrLog = "";
						logical bError = false;

						strQty.erase(std::remove(strQty.begin(), strQty.end(), ' '), strQty.end()); // Remove whitespace from string
						if( !strQty.empty() && strQty.length() > 0 ) iQtyVal = stoi(strQty);

						
						for(int i=0; i<vecLineInfo.size(); i++)
						{
							int iTcQtyVal = stoi(vecLineInfo[i].str_qty);
							if( (vecLineInfo[i].str_id.compare(itrSamCmp->second[prtAssPos]) == 0) && ( (iTcQtyVal > 0 && iQtyVal > 0) || (iTcQtyVal == 0 && iQtyVal == 0) ) )
							{
								bCntIncr = false;
								strFndNoVal = vecLineInfo[i].str_find_no;
								break;
							}

						}

						itrSamCmp->second[findno_pos] = strFndNoVal;
					}

					strErrLog = "";
					TERADYNE_TRACE_CALL(iStatus = teradyne_validate_quantity_and_refdesgnator(bZeroQnty,bQuanflag,itrSamCmp->second[qtyPos],itrSamCmp->second[refDesPos],&strErrLog,&bQtRefDesError), TD_LOG_ERROR_AND_THROW);

					if(!bQtRefDesError){ //Case: Quantity and RefDes validation passed
						if(bCntIncr){
							MaxFndNoAlot += 10;// to allocate unique findno
							bCntIncr = false;
						}
						if(strFndNoVal.empty() && strFndNoVal.length() <= 0){
							itrSamCmp->second[findno_pos] = to_string((long) MaxFndNoAlot);
						}
						csvProcessedMap.insert(pair<int,vector<string>>(itrSamCmp->first, itrSamCmp->second)); // Insert Into processed Map
						if( !strErrLog.empty() && strErrLog.length() > 0){//When quantity is more then refdes count warning is logged
							logger.log("LineNo ["+toString(itrSamCmp->first)+"] : item <"+ itrSamCmp->second[prtAssPos] +"> "+strErrLog,Logger::WARN_LEVEL);
						}
					}
					else{//Case : Quantity and RefDes validation failed move to redo file

						csvRedoFileMap.insert(make_pair(itrSamCmp->first,itrSamCmp->second));
						redoFile.log(csvMap.find(itrSamCmp->first)->second);
						logger.log("LineNo ["+toString(itrSamCmp->first)+"] : item <"+ itrSamCmp->second[prtAssPos] +"> "+strErrLog,Logger::ERROR_LEVEL);
					}
				}
				mapSameCmpnt.clear();
			}
			else{//FindNo column is present

					int iFindNo = 0;

					bool bOneFindNo = false;

					string strPrtChild = itr->second[prtAssPos];

					vector<string> sameCmpntVec;

					sameCmpntVec.clear();
					mapSameCmpnt.clear();
					if(csvProcessedMap.find(itr->first) == csvProcessedMap.end() && csvRedoFileMap.find(itr->first) == csvRedoFileMap.end() ){//Find in already processd Map and Redo File Map , If not found then proceed for current element in the map

						string strFndNo(itr->second[findno_pos].c_str());

						strFndNo.erase(std::remove(strFndNo.begin(), strFndNo.end(), ' '), strFndNo.end()); // Remove whitespace from string

						if((!strFndNo.empty()) && (strFndNo.length() > 0) ){// FindNo for the elemen is not empty
							bOneFindNo = true;
							iFindNo  = stoi(strFndNo.c_str());

							sameCmpntVec.push_back(strPrtChild);

							//Check same findno for different component
							TERADYNE_TRACE_CALL(iStatus = teradyne_find_same_seqno_different_component(prtAssPos,strPrtChild,findno_pos,iFindNo,csvFileMap,&sameCmpntVec), TD_LOG_ERROR_AND_THROW);

							/*CASE SAME FINDNO BUT DIFFERENT COMPONENT */
							if(sameCmpntVec.size() > 1){// CASE: Same Findno for different compnent found 
								string strLog = "";
								map<int ,vector<string> >::iterator itr3;
								for(int i=0 ;i< sameCmpntVec.size() ; i++){//Move components all records to Redo File
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_same_component_from_csv_map(csvFileMap,sameCmpntVec[i],prtAssPos,qtyPos,&mapSameCmpnt), TD_LOG_ERROR_AND_THROW);
										itr3 = mapSameCmpnt.begin();
										for(itr3 ; itr3 != mapSameCmpnt.end() ; itr3++){ // Invalid FindNo component moved to Redo file with logging Error
										csvRedoFileMap.insert(make_pair(itr3->first,itr3->second));
										redoFile.log(csvMap.find(itr3->first)->second);
										strLog.append(itr3->second[prtAssPos]);
										strLog = strLog + ",";
										}
									logger.log("LineNo ["+toString(itr3->first)+"] :Item <"+ strLog +"> have same FindNo.",Logger::ERROR_LEVEL);
									mapSameCmpnt.clear(); //Empty the map to reuse it
								}
								continue;// Next iterator
							}

							//Get the same component alltogether into a map
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_same_component_from_csv_map(csvFileMap, strPrtChild, prtAssPos, qtyPos, &mapSameCmpnt), TD_LOG_ERROR_AND_THROW);

							//Validate and update the process and redo file
							TERADYNE_TRACE_CALL(iStatus = teradyne_validate_and_update_csv_attribute(findno_pos, strFndNo, prtAssPos, strPrtChild, bOneFindNo, &MaxFndNoAlot, csvFileMap, mapSameCmpnt, refDesPos, qtyPos, bZeroQnty, bQuanflag, remark_pos ), TD_LOG_ERROR_AND_THROW);

						}
						else{//FindNo is empty
								bOneFindNo = false;
								strFndNo = "";

								//Get the same component alltogether into a map
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_same_component_from_csv_map(csvFileMap, strPrtChild, prtAssPos, qtyPos, &mapSameCmpnt), TD_LOG_ERROR_AND_THROW);

								//Validate and update the process and redo file
								TERADYNE_TRACE_CALL(iStatus = teradyne_validate_and_update_csv_attribute(findno_pos, strFndNo, prtAssPos, strPrtChild, bOneFindNo, &MaxFndNoAlot, csvFileMap, mapSameCmpnt, refDesPos, qtyPos, bZeroQnty, bQuanflag, remark_pos ), TD_LOG_ERROR_AND_THROW);
						}
					}else continue; //Already Processed value
				}
			}
		}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_get_same_component_from_csv_map
*   Description			:  Method to get all same components from BOMLine
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_get_same_component_from_csv_map(map<int,vector<string>> csvFileMap, string strPrtChild,int prtAssPos,int iQtyPos,map<int, vector<string>> *mapSameCmpnt)
{
	int iStatus = ITK_ok;
	int iQtyVal = -1;
	vector<int> vecKey;
	bool bMixFlag		= false,
		 bFrstZeroQty	= false;

	const char * __function__    = "teradyne_get_same_component_from_csv_map" ;
	TERADYNE_TRACE_ENTER();
	map<int ,vector<string> >::iterator itr = csvFileMap.begin();

	try{
		for(itr ; itr != csvFileMap.end() ; itr++){
			if(csvProcessedMap.find(itr->first) == csvProcessedMap.end() && csvRedoFileMap.find(itr->first) == csvRedoFileMap.end())//Not present in processed and redofile
			{
				if(itr->second[prtAssPos].compare(strPrtChild.c_str()) == 0){// same component 

					/* Get Quantity value*/
					string strQtyVal(itr->second[iQtyPos].c_str()); 
					strQtyVal.erase(std::remove(strQtyVal.begin(), strQtyVal.end(), ' '), strQtyVal.end()); // Remove whitespace from string
					if(!strQtyVal.empty() && strQtyVal.length() > 0){ iQtyVal =  stoi(strQtyVal); }
					
					/* Handle When first entry is Zero quantity then take only zero ones*/
					if( bFrstZeroQty && (iQtyVal != 0) ) continue;
					if ( (mapSameCmpnt->empty() ) && (mapSameCmpnt->size() == 0) && (iQtyVal == 0) ) {
						bFrstZeroQty = true;
					}

					/* When First entry is Non zero quantity then remove Zero quantity from map since it can be processed later*/
					if(iQtyVal == 0){ vecKey.push_back(itr->first); }
					else bMixFlag = true;

					mapSameCmpnt->insert(pair<int,vector<string>>(itr->first,itr->second)); // Insert the same child component into Map
				}
			}
		}

		if(bMixFlag && (vecKey.size() > 0) ){// Remove quantity value zero and non zero mixed up then remove it
			for(int i=0; i< vecKey.size() ; i++ ){
				mapSameCmpnt->erase(vecKey[i]);
			}
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_find_same_seqno_different_component
*   Description			:  Method to get all same components from 
*                           BOMLine with same find number
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_find_same_seqno_different_component(int prtAssPos,string strPrtChild,int findno_pos,int iFindNo,map<int,vector<string>> csvFileMap,vector<string> *sameCmpntVec)
{
	int iStatus = ITK_ok,
		iSeqNo	= 0;

	const char * __function__    = "teradyne_find_same_seqno_different_component" ;
	TERADYNE_TRACE_ENTER();

	map<int,vector<string>>::iterator itr = csvFileMap.begin();

	try{
		for(itr ; itr != csvFileMap.end() ; itr++)
		{
			string strFndNo(itr->second[findno_pos].c_str());
			strFndNo.erase(std::remove(strFndNo.begin(), strFndNo.end(), ' '), strFndNo.end()); // Remove whitespace from string

			if(csvProcessedMap.find(itr->first) == csvProcessedMap.end() && csvRedoFileMap.find(itr->first) == csvRedoFileMap.end()) //Not present in processed and redofile
			{

				if(!strFndNo.empty() && strFndNo.length() > 0){// No need to check empty Findno
					iSeqNo = stoi( itr->second[findno_pos] );

					if( (iSeqNo == iFindNo) &&  (itr->second[prtAssPos].compare(strPrtChild.c_str()) != 0) ){ // Same FindNo but different Component case
						if( std::find(sameCmpntVec->begin(), sameCmpntVec->end(), itr->second[prtAssPos] ) == sameCmpntVec->end() )
						{
							sameCmpntVec->push_back(itr->second[prtAssPos]);
						}
					}
				}
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/****************************************************************************
*   Function Name		:  teradyne_validate_and_update_csv_attribute
*   Description			:  Method to validate and update the csv contents
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_validate_and_update_csv_attribute(	int findno_pos,string strFndNo,int prtAssPos,string strPrtChild,bool bOneFindNo,
												int *MaxFndNoAlot,map<int, vector<string>> csvFileMap, map<int, vector<string>> mapSameCmpnt,
												int refDesPos,int qtyPos,bool bZeroQnty,bool bQuanflag,int remark_pos)
{
	int iStatus = ITK_ok,
		iFindNo = -1;

	if(bOneFindNo)	iFindNo = stoi(strFndNo);

	bool bInvaLdFndNo	= false, // Different Findno for same component
		 bZeroFindNo	= false, // Same component with all FindNo is Empty
		 bChkDffntCmpt	= false, // When First Element Findno is Empty case
		 bInsrtPrcess   = true,
		 bQtRefDesError	= false,
		 bCntIncr		= true;  //Insert to PreocssedMap

	vector<string> sameCmpntVec;

	string strErrLog = "";
	map<int, vector<string> > mapGetSameCmpnt;

	const char * __function__    = "teradyne_validate_and_update_csv_attribute" ;
	TERADYNE_TRACE_ENTER();

	try{
			map<int,vector<string> >::iterator itrSamCmp = mapSameCmpnt.begin();
			for(itrSamCmp ; itrSamCmp != mapSameCmpnt.end() ; itrSamCmp++){//Loop is to check FindNo validation

				int iFnNo = -1;

				string strFndNo1(itrSamCmp->second[findno_pos].c_str());
				strFndNo1.erase(std::remove(strFndNo1.begin(), strFndNo1.end(), ' '), strFndNo1.end()); // Remove whitespace from string

				if(!strFndNo1.empty() || strFndNo1.length() > 0 ){ iFnNo = stoi(itrSamCmp->second[findno_pos].c_str()); }

				if(strFndNo1.empty() || strFndNo1.length() <=0){ bZeroFindNo=true;} // Empty findNo
				else if(!bOneFindNo) { strFndNo = to_string((long double) iFnNo); iFindNo = iFnNo; bOneFindNo = true; bChkDffntCmpt = true;} // Case when first elemet is empty
				else if(iFindNo != iFnNo ){ bInvaLdFndNo = true; break; } // error case for same FindNo in same component 							
			}

			if( bInvaLdFndNo )//Different FindNo for Same component
			{
				string strLog = "";
				map<int,vector<string> >::iterator itr=mapSameCmpnt.begin();
				for(itr ; itr != mapSameCmpnt.end() ; itr++){ // Invalid FindNo component moved to Redo file with logging Error
					csvRedoFileMap.insert(make_pair(itr->first,itr->second));
					redoFile.log(csvMap.find(itr->first)->second);
					logger.log("LineNo ["+toString(itr->first)+"] : item <"+ itr->second[prtAssPos] +"> has different FindNo.",Logger::ERROR_LEVEL);
				}
			}
			else if( bOneFindNo ){ // Same component with same FindNo and empty FindNo

				if(bChkDffntCmpt){ // CASE :first element is empty
					sameCmpntVec.push_back(strPrtChild);
					//Check same findno for different component
					TERADYNE_TRACE_CALL(iStatus = teradyne_find_same_seqno_different_component(prtAssPos, strPrtChild, findno_pos, iFindNo, csvFileMap, &sameCmpntVec), TD_LOG_ERROR_AND_THROW);

					/*CASE SAME FINDNO BUT DIFFERENT COMPONENT */
					if(sameCmpntVec.size() > 1){// CASE: Same Findno for different compnent found 
							string strLog = "";
							map<int ,vector<string> >::iterator itr3;
							for(int i=0 ;i< sameCmpntVec.size() ; i++){//Move components all records to Redo File
								strLog = "";
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_same_component_from_csv_map(csvFileMap,sameCmpntVec[i],prtAssPos, qtyPos,&mapGetSameCmpnt), TD_LOG_ERROR_AND_THROW);
								itr3 = mapGetSameCmpnt.begin();
									for(itr3 ; itr3 != mapGetSameCmpnt.end() ; itr3++){ // Invalid FindNo component moved to Redo file with logging Error
									csvRedoFileMap.insert(make_pair(itr3->first,itr3->second));
									redoFile.log(csvMap.find(itr3->first)->second);
									strLog.append(itr3->second[prtAssPos]);
									strLog = strLog + ",";
									}
									logger.log("LineNo ["+toString(itr3->first)+"] : item <"+ strLog +"> items have same FindNo.",Logger::ERROR_LEVEL);
								mapGetSameCmpnt.clear(); // Empty the map to reuse it
							}
							bInsrtPrcess = false; // no need to insert into process it is error and move to redo file
						}
					}

				if(bInsrtPrcess){ 

					map<int,vector<string> >::iterator itr1=mapSameCmpnt.begin();
					for(itr1 ; itr1 != mapSameCmpnt.end() ; itr1++){
						string strChildId = itr1->second[prtAssPos];

						if(!bZeroFindNo)
						{ /* Note: Remove bZeroFindNo this condition when partial FindNo is allowed*/
							bool bSeqErr = false;
							strErrLog = "";
							bQtRefDesError	 = false;

							//CASE: Update BOM line when same seq and remarks match else create new line
							if(isRedoFile){
								strErrLog = "";
								logical bError = false;
								bSeqErr = false;
								TERADYNE_TRACE_CALL(iStatus =  teradyne_check_same_seq_diff_comp(strFndNo,strChildId,itr1->second[qtyPos],&strErrLog,&bSeqErr), TD_LOG_ERROR_AND_THROW);

								if(bSeqErr){// Updat BOM case
									csvRedoFileMap.insert(make_pair(itr1->first,itr1->second));
									redoFile.log(csvMap.find(itr1->first)->second);
									logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> "+strErrLog,Logger::ERROR_LEVEL);
									continue;
								}
							}

							if (bZeroFindNo) itr1->second[findno_pos] = strFndNo; // Update FindNo for empty one.

							TERADYNE_TRACE_CALL(iStatus = teradyne_validate_quantity_and_refdesgnator(bZeroQnty,bQuanflag,itr1->second[qtyPos],itr1->second[refDesPos],&strErrLog,&bQtRefDesError), TD_LOG_ERROR_AND_THROW);
							if(!bQtRefDesError){
								csvProcessedMap.insert(pair<int,vector<string>>(itr1->first, itr1->second)); // Insert Into processed Map
								if( !strErrLog.empty() && strErrLog.length() > 0){//When quantity is more then refdes count warning is logged
									logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> "+strErrLog,Logger::WARN_LEVEL);
								}
							}
							else{//Case : Quantity and RefDes validation failed move to redo file
									csvRedoFileMap.insert(make_pair(itr1->first,itr1->second));
									redoFile.log(csvMap.find(itr1->first)->second);
									logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> "+strErrLog,Logger::ERROR_LEVEL);
							}
						}
						else{
							csvRedoFileMap.insert(make_pair(itr1->first,itr1->second));
							redoFile.log(csvMap.find(itr1->first)->second);
							logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> item has different FindNo. ",Logger::ERROR_LEVEL);
						}
					}
				}
			}
			else if (bZeroFindNo){// All occurence of same component's FindNo is empty
				string strFndNoVal = "";
				string strQty = "";

				map<int,vector<string> >::iterator itr1=mapSameCmpnt.begin();
				for(itr1 ; itr1 != mapSameCmpnt.end() ; itr1++)
				{
					strErrLog = "";
					bQtRefDesError = false;
					strQty = itr1->second[qtyPos];
					strFndNoVal = "";
					//Redo File Update findno if already alloted in master Bom structure
					if(isRedoFile)
					{
						int iQtyVal = -1;
						strErrLog = "";
						logical bError = false;
						
						strQty.erase(std::remove(strQty.begin(), strQty.end(), ' '), strQty.end()); // Remove whitespace from string
						if( !strQty.empty() && strQty.length() > 0 ) iQtyVal = stoi(strQty);


						for(int i=0; i<vecLineInfo.size(); i++)
						{
							int iTcQtyVal = stoi(vecLineInfo[i].str_qty);
							if( (vecLineInfo[i].str_id.compare(itr1->second[prtAssPos]) == 0) && ( (iTcQtyVal > 0 && iQtyVal > 0) || (iTcQtyVal == 0 && iQtyVal == 0) ) )
							{
								strFndNoVal = vecLineInfo[i].str_find_no;
								bCntIncr = false;
								break;
							}

						}

						itr1->second[findno_pos] = strFndNoVal;
					}

					strErrLog = "";
					TERADYNE_TRACE_CALL(iStatus = teradyne_validate_quantity_and_refdesgnator(bZeroQnty,bQuanflag,itr1->second[qtyPos],itr1->second[refDesPos],&strErrLog,&bQtRefDesError), TD_LOG_ERROR_AND_THROW);
					if(!bQtRefDesError)
					{
						if(bCntIncr){ // Increase the FindNo count 
							*MaxFndNoAlot += 10;
							bCntIncr = false;
						}

						if(strFndNoVal.empty() && strFndNoVal.length() <=0 )
						{
							itr1->second[findno_pos] = to_string((long)*MaxFndNoAlot); // Update FindNo for empty one.
						}
						csvProcessedMap.insert(pair<int,vector<string>>(itr1->first, itr1->second)); // Insert Into processed Map

						if( !strErrLog.empty() && strErrLog.length() > 0){//When quantity is more then refdes count warning is logged
							logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> "+strErrLog,Logger::WARN_LEVEL);
						}
					}
					else
					{
						//Case : Quantity and RefDes validation failed move to redo file
						csvRedoFileMap.insert(make_pair(itr1->first,itr1->second));
						redoFile.log(csvMap.find(itr1->first)->second);
						logger.log("LineNo ["+toString(itr1->first)+"] : item <"+ itr1->second[prtAssPos] +"> "+strErrLog,Logger::ERROR_LEVEL);
					}
				}
			}
			mapSameCmpnt.clear();
		}
		catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

		TERADYNE_TRACE_LEAVE(iStatus);
		return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_validate_quantity_and_refdesgnator
*   Description			:  Method to validate and quantity and reference designator
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_validate_quantity_and_refdesgnator(bool bZeroQntyAllwd,bool bQuanflag,string strQtyValue,string strRefDes,string *strErrLog,bool *bQtRefDesError)
{
	int		iStatus		= ITK_ok,
			iRefDesCnt	= 0,
			iQtyVal		= -1;

	string  strErr		= "";
	vector<string> vecRefDesValues;

	int iErrorCount = -1;
	const char * __function__    = "teradyne_validate_quantity_and_refdesgnator" ;
	TERADYNE_TRACE_ENTER();

	try{

		/*Empty Quantity Check*/
		strQtyValue.erase(std::remove(strQtyValue.begin(), strQtyValue.end(), ' '), strQtyValue.end()); // Remove whitespace from string
		if( !strQtyValue.empty() && strQtyValue.length() > 0 ) iQtyVal = stoi(strQtyValue);// Non empty value converted to integer
		else {*bQtRefDesError = true; return iStatus; }

		strRefDes.erase(std::remove(strRefDes.begin(), strRefDes.end(), ' '), strRefDes.end()); // Remove whitespace from string
		if( (strRefDes.empty() ) && (strRefDes.length() <=0) && (bQuanflag) )
		{
			if(iQtyVal > 0)
			{
				*strErrLog  = "Item Quantity is more than Reference Designator values.";
			}
			else *strErrLog  = "";
			
			*bQtRefDesError = false;
		}
		else if( (strRefDes.empty() ) && (strRefDes.length() <=0) && (!bQuanflag) )
		{
			if(iQtyVal > 0)
			{
				*strErrLog = "Reference Designator value is less than quantity";
				*bQtRefDesError = true;
			}
		}
		else
		{
				teradyne_quantityvsreferencedesignator_validation(strRefDes, iQtyVal, vecRefDesValues, iErrorCount, strErr);
				if(iErrorCount > 0){//Note: LOG THE ERROR into logger file
						*strErrLog = strErr;
						*bQtRefDesError = true; 
						return iStatus; 
				}

				if( ( iQtyVal > (vecRefDesValues.size()) ) && (bQuanflag) ){//Warning case : Quanity is more than Reference Designator count
					*strErrLog  = "";
					*strErrLog  = "Item Quantity is more than Reference Designator values.";
					*bQtRefDesError = false; 
					return iStatus;
				}
				else if( ( iQtyVal > (vecRefDesValues.size()) ) && (!(bQuanflag) ) ){// Error case : Quantity is more than Reference Designator count when not allowed
					*strErrLog  = "";
					*strErrLog  = "Item Quantity is more than Reference Designator values not allowed.";
					*bQtRefDesError = true; 
					return iStatus;
				}
				else if( (iQtyVal < (vecRefDesValues.size()) ) ){ //Error case : Quantiy is less than Reference Designator count
					*strErrLog  = "";
					*strErrLog  = "Item Quantity is less than Reference Designator values."; 
					*bQtRefDesError = true; 
					return iStatus;
				}
			}
		}
		catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/****************************************************************************
*   Function Name		:  teradyne_remarks_validate_same_component
*   Description			:  Method to validate remarks
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_remarks_validate_same_component(map<int ,vector<string>> &mapSameCmpnt,int remark_pos,bool *bRmrkMisMatchErr)
{
	int		iStatus		= ITK_ok;
	string  strChkRmrk	= "";

	bool	bflag = true;
	const char * __function__    = "teradyne_remarks_validate_same_component" ;
	TERADYNE_TRACE_ENTER();

	map<int ,vector<string> >::iterator it = mapSameCmpnt.begin();

	try{
		for(it ; it != mapSameCmpnt.end() ; it++)
		{
			if(bflag){
				strChkRmrk = it->second[remark_pos];
				bflag = false;
			}

			if( strChkRmrk.compare(it->second[remark_pos].c_str()) != 0)// Compare the Remarks if not match throw error
			{
				*bRmrkMisMatchErr = true;
				break;
			}
		}
	}
	catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/****************************************************************************
*   Function Name		:  teradyne_bom_import_master
*   Description			:  Import create and import BOM lines
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_bom_import_master(vector<string> vecAllwdPrntPrt,vector<string> vecAllChldPrt,int prtNoPos,int prtAssPos,int refdes_pos,int qty_pos,int remark_pos,int findno_pos)
{
	int		iStatus		= ITK_ok,
			ibv_count	= 0,
			ibvr_count	= 0,
			iOccCount	= 0,
			iBvOccCnt	= 0,
			iRefDesCnt	= 0,
			iQtyVal		= -1,
			iErrorCount	= -1,
			iVecRefSiz	= 0;

	string strQtyVal = "",
			strErr	 = "";	

	std::vector<string> vecRefDesValues;
	const char * __function__    = "teradyne_bom_import_master";
	TERADYNE_TRACE_ENTER();

	char*	pcObjectName		= NULL,
			*pcRefDesErr		= NULL,
			**pcRefDesgValues	= NULL;

	tag_t	tItemPrntTag	= NULLTAG,
			tPrntLatestRev	= NULLTAG,
			*tbvList		= NULLTAG,
			tBvPrntTag		= NULLTAG,
			*tbvrist		= NULLTAG,
			tBvrPrntRvTag	= NULLTAG,
			tItmChildTag	= NULLTAG,
			tItmChildRevTag	= NULLTAG,
			*tBvOccTag		= NULLTAG,
			*tOccsTag		= NULLTAG,
			tRmrkNtTyp		= NULLTAG;

	string	strRefDes = "",
			pcRefDes  = "",
			strRemarks= "";

	string strChildId	= "",
			strFindNo	= "",
			strErrLog	= "";

	bool bSeqErr = false;


	vector<string> vecAttrVal;
	map<int ,vector<string> >::iterator itr = csvProcessedMap.begin();

	try{

		/*Get the ItemTag and Latest rev tag of Parent item id */
		teradyne_get_item_and_latest_rev_tag(itr->second[prtNoPos],vecAllwdPrntPrt,&tItemPrntTag,&tPrntLatestRev);

		// Get BVR for parent item
		TERADYNE_TRACE_CALL(iStatus =  ITEM_rev_list_bom_view_revs( tPrntLatestRev, &ibvr_count, &tbvrist), TD_LOG_ERROR_AND_THROW); // Get BOM View revision for parent item

		//Lock the parent latest rev
		TERADYNE_TRACE_CALL(iStatus = AOM_lock( tPrntLatestRev ), TD_LOG_ERROR_AND_THROW);
		//Delete the BVR is already present
		if (ibvr_count > 0 && !isRedoFile){

			//Check if the BOM View Revision is reference by VisStructureContext, if does remove it

			int iReferencers = 0;
			int *iLevels = 0;
			tag_t *tReferencersTag = NULL;
			char **pcRelations = NULL;

		    TERADYNE_TRACE_CALL(iStatus = WSOM_where_referenced2(tbvrist[0], 1, &iReferencers, &iLevels, &tReferencersTag, &pcRelations), TD_LOG_ERROR_AND_THROW);
			if(iReferencers > 0){
               POM_AM__set_application_bypass(true);
			   for (int j = 0; j < iReferencers; j++) {
					char *pcWObjectTypeName = NULL;
					tag_t *listStructureContext=NULL;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReferencersTag[j], &pcWObjectTypeName), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcWObjectTypeName, TD_VIS_STRUCTURE_CONTEXT) == 0) {  // If the object type is VisStructureContext remove it
						tag_t relationTypeTag = NULLTAG;
						tag_t tRelation=NULLTAG;

						TERADYNE_TRACE_CALL(iStatus =GRM_find_relation_type(pcRelations[j],&relationTypeTag), TD_LOG_ERROR_AND_THROW);
						if(relationTypeTag != NULLTAG) {
							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tReferencersTag[j],tbvrist[0] ,relationTypeTag, &tRelation), TD_LOG_ERROR_AND_THROW);
							if(tRelation != NULLTAG) {
			                    TERADYNE_TRACE_CALL(iStatus = GRM_delete_relation(tRelation), TD_LOG_ERROR_AND_THROW);
							}
		                }

						
						/*
						listStructureContext = (tag_t *) MEM_alloc(1 * sizeof(tag_t));
						listStructureContext[0]= tReferencersTag[j];
						POM_AM__set_application_bypass(true);
					    TERADYNE_TRACE_CALL(iStatus = POM_delete_instances(1,listStructureContext), TD_LOG_ERROR_AND_THROW);
						POM_AM__set_application_bypass(false);
						*/
						
					}

					Custom_free(pcWObjectTypeName);
					Custom_free(listStructureContext);
			   }
			   POM_AM__set_application_bypass(false);
			}

			strErrLog = "while deleting BVR item <"+itr->second[prtNoPos]+">";
			TERADYNE_TRACE_CALL(iStatus = ITEM_rev_delete_bvr(tPrntLatestRev,tbvrist[0]), TD_LOG_ERROR_AND_THROW);
		}
		strErrLog ="";
		//unlock the parent latest rev
		TERADYNE_TRACE_CALL(iStatus = AOM_unlock( tPrntLatestRev ), TD_LOG_ERROR_AND_THROW);

		/*Get the BV for Parent item which is Divisional Part*/
		TERADYNE_TRACE_CALL(iStatus = ITEM_list_bom_views(tItemPrntTag, &ibv_count, &tbvList), TD_LOG_ERROR_AND_THROW);

		if(ibv_count)
		{// BV present
			tBvPrntTag = tbvList[0];
		}
		else
		{//Need to create BV
			TERADYNE_TRACE_CALL(iStatus = PS_create_bom_view( NULLTAG, "", "", tItemPrntTag, &tBvPrntTag), TD_LOG_ERROR_AND_THROW);
			// Save Bom view newly created
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tBvPrntTag ), TD_LOG_ERROR_AND_THROW);
			// Save the parent tag
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tItemPrntTag ), TD_LOG_ERROR_AND_THROW);
			// Unlock the parent tag
			TERADYNE_TRACE_CALL(iStatus = AOM_unlock( tItemPrntTag ), TD_LOG_ERROR_AND_THROW);
		}

		if(ibvr_count <= 0 || !isRedoFile)
		{
			//Create BVR for the parent revision
			TERADYNE_TRACE_CALL(iStatus = PS_create_bvr( tBvPrntTag , "", "", false, tPrntLatestRev, &tBvrPrntRvTag ), TD_LOG_ERROR_AND_THROW);
			//Save the bvr for parent revision
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tBvrPrntRvTag ), TD_LOG_ERROR_AND_THROW);
			//Save the parent latest rev
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tPrntLatestRev ), TD_LOG_ERROR_AND_THROW);
			//unlock the parent latest rev
			TERADYNE_TRACE_CALL(iStatus = AOM_unlock( tPrntLatestRev ), TD_LOG_ERROR_AND_THROW);
		}
		else
		{
			tBvrPrntRvTag = tbvrist[0]; //Already bvr present
		}

		TERADYNE_TRACE_CALL(iStatus = PS_find_note_type("TD4Remarks",&tRmrkNtTyp), TD_LOG_ERROR_AND_THROW);

		/*Read the Processed Map and create bom line*/
		for(itr ; itr != csvProcessedMap.end() ; itr++)
		{
			strChildId		= "";
			strQtyVal		= "";
			iRefDesCnt		= 0;
			iErrorCount		= -1;
			strErr			= "";
			iVecRefSiz		= 0;

			pcRefDesgValues = NULL;
			vecRefDesValues.clear();

			tItmChildTag	= NULLTAG;
			tItmChildRevTag = NULLTAG;

			//Child component value
			strChildId = itr->second[prtAssPos];
			//Qty Value
			strQtyVal = itr->second[qty_pos];
			//SeqNo value
			strFindNo = itr->second[findno_pos];
			//RefDesignator
			strRefDes = (itr->second[refdes_pos]);
			//remarks
			strRemarks = (itr->second[remark_pos]);

			strRefDes.erase(std::remove(strRefDes.begin(), strRefDes.end(), ' '), strRefDes.end()); // Remove whitespace from string
			if( (strRefDes.empty() ) && (strRefDes.length() <=0) ){
				iVecRefSiz = 0;
			}
			else{
				teradyne_quantityvsreferencedesignator_validation(strRefDes, stoi(strQtyVal), vecRefDesValues, iErrorCount, strErr);
				iVecRefSiz = (int)vecRefDesValues.size();
			}
			// Remove whitespace from string
			strQtyVal.erase(std::remove(strQtyVal.begin(), strQtyVal.end(), ' '), strQtyVal.end()); 

			// quantity value cant be empty so assign it to 1
			if(strQtyVal.empty() && strQtyVal.length() <=0) iQtyVal = 1; 
			else iQtyVal = stoi(strQtyVal);

			if(iQtyVal == 0) iOccCount = 1;
			else iOccCount = iQtyVal;

			//Get childItem and its latest rev tag
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_item_and_latest_rev_tag(strChildId,vecAllChldPrt,&tItmChildTag,&tItmChildRevTag), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = PS_create_occurrences( tBvrPrntRvTag, tItmChildTag, NULLTAG , iOccCount ,&tOccsTag ), TD_LOG_ERROR_AND_THROW);

			//Create multiple occurence for the component as per the quanity value
			for(int lp = 0 ; lp < iOccCount ; lp++)
			{  
				double iqty = 1;

				if(iQtyVal == 0 ) iqty = 0; //quantiy is zero create a separate occurence with zero value

				/* When refDes count is less than quantity value*/
				if( iVecRefSiz > lp) pcRefDes = vecRefDesValues[lp];
				else pcRefDes = "";

				//Set quantity value
				TERADYNE_TRACE_CALL(iStatus = PS_set_occurrence_qty	( tBvrPrntRvTag, tOccsTag[lp], iqty ), TD_LOG_ERROR_AND_THROW);
				//Set reference designator value
				TERADYNE_TRACE_CALL(iStatus = PS_set_occurrence_ref_designator( tBvrPrntRvTag, tOccsTag[lp], pcRefDes.c_str() ), TD_LOG_ERROR_AND_THROW);
				//Set Sequence No.
				TERADYNE_TRACE_CALL(iStatus = PS_set_seq_no( tBvrPrntRvTag, tOccsTag[lp], strFindNo.c_str() ), TD_LOG_ERROR_AND_THROW);
				if(strRemarks.length() > 0 && !strRemarks.empty()){
					//set remarks
					TERADYNE_TRACE_CALL(iStatus =PS_set_occurrence_note_text( tBvrPrntRvTag, tOccsTag[lp], tRmrkNtTyp, strRemarks.c_str()), TD_LOG_ERROR_AND_THROW);
				}
				//save the occurence
				TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tOccsTag[lp] ), TD_LOG_ERROR_AND_THROW);
			}
			Custom_free(tOccsTag);
		}
		//Save the bvr for parent revision
		TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tBvrPrntRvTag ), TD_LOG_ERROR_AND_THROW);
		//Save the parent latest rev
		TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions( tBvPrntTag ), TD_LOG_ERROR_AND_THROW);
		Custom_free(tbvrist);
		Custom_free(tBvOccTag);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}

		logger.log(strErrLog,Logger::ERROR_LEVEL);
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_get_item_and_latest_rev_tag
*   Description			:  Get ItemID's Tag and Latest Rev Tag 
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_get_item_and_latest_rev_tag(string strItemID,vector<string> vecAllwdPart,tag_t *tItemTag, tag_t *tItemRevTag)
{
	int	iStatus		= ITK_ok,
		iFounditem	= 0;

	tag_t	*tFindItemTag	= NULLTAG,
		tItemPrntTag	= NULLTAG,
		tPrntLatestRev	= NULLTAG;

	char* pcObjectName = NULL;

	const char * __function__    = "teradyne_get_item_and_latest_rev_tag";
	TERADYNE_TRACE_ENTER();

	try{
		TERADYNE_TRACE_CALL(iStatus = ITEM_find ( (char*)strItemID.c_str(), &iFounditem, &tFindItemTag),TD_LOG_ERROR_AND_THROW); //Find Item exits in TC

		/* Check item is DivPart */
		for(int i=0 ; i < iFounditem; i++){
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindItemTag[i], &pcObjectName),TD_LOG_ERROR_AND_THROW);

			if( find(vecAllwdPart.begin(),vecAllwdPart.end(),pcObjectName) != vecAllwdPart.end() ){
				tItemPrntTag = tFindItemTag[i];
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tItemPrntTag, &tPrntLatestRev), TD_LOG_ERROR_AND_THROW);// Get the Latest Revision
				*tItemTag = tItemPrntTag;
				*tItemRevTag = tPrntLatestRev;
				break;
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/****************************************************************************
*   Function Name		:  teradyne_create_bom_window
*   Description			:  Get ItemID's Tag and Latest Rev Tag 
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_get_bom_line_info(string str_id,int *maxFindNo)
{
	int	iStatus		= ITK_ok;
	const char * __function__    = "teradyne_create_bom_window";
	
	tag_t tItem				=	NULLTAG;
	tag_t tItemRev			=	NULLTAG;
	tag_t tBOMLine			=	NULLTAG;
	tag_t *tBvrs			=	NULLTAG;
	tag_t tBOMWindow		=	NULLTAG;

	int iViewCnt			=	0;

	TERADYNE_TRACE_ENTER();
	try{
			TERADYNE_TRACE_CALL(iStatus = ITEM_find_item(str_id.c_str(),&tItem),TD_LOG_ERROR_AND_THROW);
			if(tItem ==NULLTAG)	return ITK_ok;

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tItem,&tItemRev),TD_LOG_ERROR_AND_THROW);
			if(tItemRev == NULLTAG)	return ITK_ok;

			TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs ( tItemRev, &iViewCnt, &tBvrs),TD_LOG_ERROR_AND_THROW);
			if(iViewCnt == 0){//"No BOM View found.."
				return ITK_ok;
			}

			TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tBOMWindow),TD_LOG_ERROR_AND_THROW);
			//TERADYNE_ITKCALL_F(BOM_set_window_pack_all(tBOMWindow,FALSE));
			TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tBOMWindow,tItem,tItemRev,NULLTAG,&tBOMLine),TD_LOG_ERROR_AND_THROW);
			if(tBOMLine == NULLTAG)
				return ITK_ok;

			TERADYNE_TRACE_CALL(iStatus = teradyne_create_bom_window_map(tBOMLine,maxFindNo),TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = BOM_save_window(tBOMWindow),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tBOMWindow),TD_LOG_ERROR_AND_THROW);
		}
		catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

		TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}
/****************************************************************************
*   Function Name		:  teradyne_create_bom_window_map
*   Description			:  Populate the vector holds bom info 
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_create_bom_window_map(tag_t tParentLine,int *maxFindNo){

	int	iStatus		= ITK_ok;

	tag_t *tChildTag		=	NULLTAG;

	int iChildCnt			=	0;

	const char * __function__    = "teradyne_create_bom_window_map";
	TERADYNE_TRACE_ENTER();
	
	
	try{


		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tParentLine,&iChildCnt,&tChildTag),TD_LOG_ERROR_AND_THROW);

		if(iChildCnt == 0)
			return ITK_ok;

		vecLineInfo.clear();
		for(int i = 0; i< iChildCnt; i++){
			char* str_id		= NULL;
			char* str_qty		= NULL;
			char* str_find_no	= NULL;
			char* str_ref_desg	= NULL;
			char* str_remarks	= NULL;

			BomLineInfo lineinfo; 

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildTag[i],"bl_item_item_id",&str_id),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildTag[i],"bl_quantity",&str_qty),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildTag[i],"bl_sequence_no",&str_find_no),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildTag[i],"bl_ref_designator",&str_ref_desg),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildTag[i],"TD4Remarks",&str_remarks),TD_LOG_ERROR_AND_THROW);
		
				
			lineinfo.str_id			= str_id;
			lineinfo.str_find_no	= str_find_no;
			lineinfo.str_qty		= str_qty;
			lineinfo.str_ref_desg	= str_ref_desg;
			lineinfo.str_remarks	= str_remarks;
			lineinfo.tLine			= tChildTag[i] ;
		
			TRIM_TEXT(lineinfo.str_remarks);

			lineinfo.str_status		=	"";
			if(lineinfo.str_qty.size() == 0)
			lineinfo.str_qty = "1";

			vecLineInfo.push_back(lineinfo);

			//Get the Max Find no from Bom Line
			if(!lineinfo.str_find_no.empty()){
				int iFindNo = stoi(lineinfo.str_find_no);

				if(*maxFindNo < iFindNo){
					*maxFindNo = iFindNo;
				}
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

		TERADYNE_TRACE_LEAVE(iStatus);
		return iStatus;
}

	/****************************************************************************
*   Function Name		:  teradyne_check_same_seq_diff_comp
*   Description			:  Check same sequence no and different component in redo process
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
int BomImportCSV::teradyne_check_same_seq_diff_comp(string sFindNo,string sPrtNo,string sQtyVal,string *sErrror,logical *bError){

	int	iStatus		= ITK_ok;

	const char * __function__    = "teradyne_check_same_seq_diff_comp";
	TERADYNE_TRACE_ENTER();
	try{

		for(int i = 0; i< vecLineInfo.size() ; i++)
		{
				if(vecLineInfo[i].str_find_no.compare(sFindNo) == 0)
				{		// checking find number
					if( vecLineInfo[i].str_id.compare(sPrtNo) == 0 )
					{	
						int iQtyVal = stoi(sQtyVal);
						int iBomQtyVal = stoi(vecLineInfo[i].str_qty);
						if( (iQtyVal > 0 && iBomQtyVal > 0) || (iQtyVal == 0 && iBomQtyVal == 0) )
						{
							*bError	=	false;
							return ITK_ok;
						}
						else
						{
							*sErrror	=	"FindNo. for the component is not correct";
							*bError		=	 true;
							return ITK_ok;
						}
					}
					else//checking redo file givn findno. allocated for some other component in TC
					{
						*sErrror	=	"Items has same FindNo. for different component";
						*bError		=	 true;
						return ITK_ok;
					}
				}
				else if( vecLineInfo[i].str_id.compare(sPrtNo) == 0 )
				{
					int iQtyVal = stoi(sQtyVal);
					int iBomQtyVal = stoi(vecLineInfo[i].str_qty);

					if( (iQtyVal > 0 && iBomQtyVal > 0) || (iQtyVal == 0 && iBomQtyVal == 0) )
					{			
						*sErrror	=	"different FindNo. found for same component";
						*bError		=	 true;
					}
				}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

		TERADYNE_TRACE_LEAVE(iStatus);
		return iStatus;

}

/****************************************************************************
*   Function Name		:  teradyne_quantityvsreferencedesignator_validation
*   Description			:  Checks the quantity and reference designator values
*                          after parsing the range values in reference designator
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
void teradyne_quantityvsreferencedesignator_validation(string strRefDes, int iQuantity, std::vector<string> &strRefDesValues, int &iErrorCount, string &strErrorMsg)
{
	int iStatus = 0;
	std::vector<string> strRefDesTokens;

	iErrorCount = 0;
	strErrorMsg.clear();

	if(strRefDes != "" && strRefDes.length() > 0)
	{
		strRefDes = trim(strRefDes);
		/*Validate the first and last character and remove double quotes*/
		if(strRefDes[0] == '"') {
			strRefDes.erase(0,1);
		}
		if(strRefDes[(strRefDes.length() - 1)] == '"') {
			strRefDes.erase((strRefDes.length() - 1),1);
		}

		/*Split the string*/
		strRefDesTokens = splitString(strRefDes,",",false);
		/*Validate that there are no NULL values in the string*/
		for(int itr = 0; itr < strRefDesTokens.size(); itr++)
		{
			if(strRefDesTokens[itr] == "" || strRefDesTokens[itr].length() <= 0)
			{
				iErrorCount++;
				strErrorMsg.assign("There are empty values in the given ReferenceDesignator value.");
				return;
			}
		}
		/*Validate that there are no Empty Space values in the string*/
		bool bisBlank = true;
		for(int itr = 0; itr < strRefDesTokens.size(); itr++)
		{
			bisBlank = true;
			for(int it = 0; it < strRefDesTokens[itr].length(); it++)
			{
				if(!std::isspace(strRefDesTokens[itr].at(it)))
				{
					bisBlank = false;
					break;
				}
			}
			if(bisBlank)
			{
				iErrorCount++;
				strErrorMsg.assign("There are empty spaces in the given ReferenceDesignator value.");
				return;
			}
		}

		/*Perform the operation*/
		int rCount = 0;
		string str = "", part1 = "", part2 = "";
		vector<string> strRangeValues;
		for(int index = 0; index < strRefDesTokens.size(); index++)
		{
			/*Check if it's a range value*/
			rCount = 0;
			str = trim(strRefDesTokens[index]);
			for(int i = 0; i < str.length(); i++)
			{
				if(str.at(i) == '-')
					rCount++;
			}

			if(rCount > 1)
			{
				iErrorCount++;
				strErrorMsg.assign("The range value "+strRefDesTokens[index]+" has invalid format.");
				return;
			}
			else if(rCount == 1)
			{
				/*Split the range value*/
				strRangeValues.clear();
				part1.clear();
				part2.clear();
				strRangeValues = splitString(str,"-",false);

				part1 = trim(strRangeValues[0]);
				part2 = trim(strRangeValues[1]);
		
				/*Validate that both the parts are valid before expanding*/
				if((part1 != "" && part1.length() > 0) && (part2 == "" || part2.length() <= 0)) {
					iErrorCount++;
					strErrorMsg.assign("The value "+str+" is not valid. Range values must have a format of VALUE1-VALUE2");
					return ;
				} else if((part2 != "" && part2.length() > 0) && (part1 == "" || part1.length() <= 0)) {
					iErrorCount++;
					strErrorMsg.assign("The value "+str+" is not valid. Range values must have a format of VALUE1-VALUE2");
					return ;
				}

				/*Validate strict numeric*/
				if(isDigitWSAllowed(part1))
				{
					if(!isDigitWSAllowed(part2))
					{
						/*iErrorCount++;
						strErrorMsg.assign("The value "+str+" is not valid. It has mixed formats. Range values must be specified as ALPHA-ALPHA or NUMERIC-NUMERIC or ALPHANUMERIC-ALPHANUMERIC");
						return ;*/
						strRefDesValues.push_back(str);
						continue;
					}
				}
				/*Validate strict alpha*/ 
				else if(isAlphaWSAllowed(part1)) 
				{
					if(!isAlphaWSAllowed(part2)) 
					{
						/*iErrorCount++;
						strErrorMsg.assign("The value "+str+" is not valid. It has mixed formats. Range values must be specified as ALPHA-ALPHA or NUMERIC-NUMERIC or ALPHANUMERIC-ALPHANUMERIC");
						return ;*/
						strRefDesValues.push_back(str);
						continue;
					}
				}
				/*Validate strict alphanumeric*/
				else if(isAlphaNumericWSAllowed(part1)) 
				{
					if(!isAlphaNumericStrict(part2)) 
					{
						/*iErrorCount++;
						strErrorMsg.assign("The value "+str+" is not valid. It has mixed formats. Range values must be specified as ALPHA-ALPHA or NUMERIC-NUMERIC or ALPHANUMERIC-ALPHANUMERIC");
						return ;*/
						strRefDesValues.push_back(str);
						continue;
					}
				}
				else
				{
					iErrorCount++;
					strErrorMsg.assign("The value "+str+" is not valid");
					return ;
				}

				int count = 0;
				string incrValue = part1;
				strRefDesValues.push_back(incrValue);
				while((incrValue != part2) && count <= iQuantity) 
				{
					incrValue = incrementedAlpha(incrValue);
					strRefDesValues.push_back(incrValue);
					count++;
					/*Validate Overflow condition.This condition should not be true for a single Range Value*/
					if(count > iQuantity) 
					{
						iErrorCount++;
						strErrorMsg.assign("The value "+str+" is not valid. The ReferenceDesignator value exceeded the Quantity given.");
						return ;
					}
				}
				
			}
			else
			{
				strRefDesValues.push_back(str);
			}
		}

		/*Actual validation for Quantity vs ReferenceDesginator*/
		if(iQuantity < strRefDesValues.size()) {
			iErrorCount++;
			strErrorMsg.assign("Item Quantity is less than Reference Designator values.");
			return ;
		}

		//Finally
		if(iErrorCount > 0) {
			/*An error occurred during processing.Do not attempt to return any values to the caller*/
			strRefDesValues.clear();
		}

	}

	return;
}
