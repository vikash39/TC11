/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_check_manufacturer_status.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-Check-Manufacturer-Status rule handler
#      Project         :           libTD4teradyne
#      Author          :           Lalit
#  =================================================================================================
#  Date                              Name                               Description of Change
#  14-Aug-2015                      Lalit                    		Added function definitions teradyne_check_manufacturer_status.
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


/*******************************************************************************
 * Function Name			: teradyne_check_manufacturer_status
 * Description				: Validate CPR that have a Approved or Preferred supplier
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
int teradyne_check_manufacturer_status(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttaches = 0,
		iSecCount = 0,
		n_references = 0,
		iFlag = 0,
		*levels = NULL;

	char *tSecObjectType = NULL,
		*pcObjectType = NULL,
		*pcItemId = NULL,
		*pcEcnCBU = NULL,
		*pcCBU = NULL,
		*pcRevID = NULL,
		*pcECNId = NULL,
		*psManufacturer1 = NULL,
		*psManufacturer2 = NULL,
		*psManufacturer3 = NULL,
		**relation_type_name = NULL;

	tag_t *tAttaches = { NULLTAG },
		*tSecObjects = { NULLTAG },
		tItemSecObject = NULLTAG,
		*reference_tags = { NULLTAG };

	bool isCPRStatusApprovedOrPreferred = false;

	const char * __function__ = "teradyne_check_manufacturer_status";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting target attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		
		if (iAttaches != 0)
		{
			for (int i = 0; i < iAttaches; i++)
			{
				//Validating Object type and works for StandardECNRevision,ProtoBOMECNRevision,ReleaseECNRevision
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(pcObjectType, TD_COMM_PART_REQ_REV) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_1_ATTR, &psManufacturer1), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_2_ATTR, &psManufacturer2), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_3_ATTR, &psManufacturer3), TD_LOG_ERROR_AND_THROW);

					if (psManufacturer1 != NULL && tc_strcmp(psManufacturer1, "") != 0) 
					{
						if (strstr(psManufacturer1, "APPROVED") != NULL || strstr(psManufacturer1, "PREFERRED") != NULL)
						{
							iFlag = 1;
						}
					}
					if (psManufacturer2 != NULL && tc_strcmp(psManufacturer2, "") != 0)
					{
						if (strstr(psManufacturer2, "APPROVED") != NULL || strstr(psManufacturer2, "PREFERRED") != NULL)
						{
							iFlag = 1;
						}
					}
					if (psManufacturer3 != NULL && tc_strcmp(psManufacturer3, "") != 0)
					{
						if (strstr(psManufacturer3, "APPROVED") != NULL || strstr(psManufacturer3, "PREFERRED") != NULL)
						{
							iFlag = 1;
						}
					}
					if (iFlag == 1)
					{
						TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_True), TD_LOG_ERROR_AND_THROW);
					}
					else
					{
						TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_False), TD_LOG_ERROR_AND_THROW);
					}
				}
				Custom_free(pcObjectType);
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
