/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :          teradyne_checkeffectivitydatewithtodaydate.cpp      
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CheckEffectivityDate action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D.          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Jun-2017                       Karl Reimann                    	Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
std::string teradyneBuildNotificationSubjectRevise(EPM_action_message_t msg, string szECNnumber);
std::string teradyneBuildNotificationBodyContentRevise(EPM_action_message_t msg, char* commentEmail);

/*******************************************************************************
 * Function Name			: teradyne_checkeffectivitydatewithtodaydate_reviseeff
 * Description				: This function will check the Effectivity date with todays date in revise effectivity WF to cancel the WF if the ECN has already been implemented.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_checkeffectivitydate_reviseeff(EPM_action_message_t msg){
	
	int		iStatus			    = ITK_ok,
			iAttachCount		= 0,
			iEffCount			= 0,
			iDateCount			= 0;

	tag_t	*tAttachtag			= {NULLTAG},
			tECNRelStatusTag	= NULLTAG,
			tOwner				= NULLTAG,
			*tEffTagList		= {NULLTAG};

	string  szStartDate			= "",
			strMailFilePath		= "",
			subject				= "";
	

	char	*pcAttachType		= NULL,
		    *pcEffDateTime		= NULL,
			*pcRange            = NULL,
			*pcECNId			= NULL,
			*pcNotificationReceiverEmail = NULL;

	string	szCurTimeStamp,
	        szEffrange;

	date_t	curDateTime,
			*tEffDateTime,
			convertedDateTime;

	bool bisverdict         = true;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	const char * __function__    = "teradyne_checkeffectivitydate_reviseeff" ;
	TERADYNE_TRACE_ENTER();

	try{
			if(msg.task != NULLTAG) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttachCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)) {

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tAttachtag[i],&tECNRelStatusTag), TD_LOG_ERROR_AND_THROW);
						if(tECNRelStatusTag != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tECNRelStatusTag,&iEffCount,&tEffTagList),TD_LOG_ERROR_AND_THROW);
							if(iEffCount > 0) 
							{
								TERADYNE_TRACE_CALL( iStatus = WSOM_eff_ask_dates( tECNRelStatusTag, tEffTagList[iEffCount - 1], &iDateCount, &tEffDateTime, &open_ended_or_stock_out ), TD_LOG_ERROR_AND_THROW );
								//Gets the latest start date in the start-end date range
								int iLatestStartDate = (iDateCount % 2 == 0) ? (iDateCount - 2) : (iDateCount - 1);

								if (tEffDateTime[iLatestStartDate].hour >= 21) {
									TERADYNE_TRACE_CALL(iStatus = POM_convert_date(POM_local_to_gmt, tEffDateTime[iLatestStartDate], &convertedDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%d-%b-%Y %H:%M", &pcRange), TD_LOG_ERROR_AND_THROW);
									szEffrange.append(pcRange).append(" to ").append("UP");
									TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tAttachtag[i], tECNRelStatusTag, szEffrange, "", false), TD_LOG_ERROR_AND_THROW);
								} else {
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( tEffDateTime[iLatestStartDate], "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
								}

								string szEffDate(pcEffDateTime);
								szEffDate = szEffDate.substr(0, 8);

								TC_write_syslog("INFO : The Latest start date of effectivity is %s \n",szEffDate);
								TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW);
								TC_write_syslog("INFO : The Current time stamp is %s \n",szCurTimeStamp);
								unsigned long long lEffDate = stoull(szEffDate.c_str());
								unsigned long long lCurrDate = stoull(szCurTimeStamp.c_str());
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(msg.task, &tOwner), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tOwner, &pcNotificationReceiverEmail), TD_LOG_ERROR_AND_THROW);
								if(lEffDate < lCurrDate)
								{
									//set checkeffdate here
									POM_AM__set_application_bypass(true);
									TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
									if(!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
									}
									TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4CheckEffectivityDate", true), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL ( iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
									if(!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);				
									}		
									POM_AM__set_application_bypass(false);
									
								    if (pcNotificationReceiverEmail != NULL)
								    {
										if(!strMailFilePath.empty())
										{
											strMailFilePath.clear();
										}
										TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW); // get current system date
										strMailFilePath.append(TD_TEMP_PATH).append("REVISE_NOTIFICATION").append(szCurTimeStamp).append(".htm");
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
									    subject.assign(teradyneBuildNotificationSubjectRevise(msg, pcECNId));
									    string htmlBodyContent=teradyneBuildNotificationBodyContentRevise(msg, pcECNId);
									    TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW); //required for teradyne_send_os_mail
									    TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject,strMailFilePath,pcNotificationReceiverEmail),TD_LOG_ERROR_AND_THROW); //sends the email
								    }
									Custom_free(pcNotificationReceiverEmail);
									Custom_free(pcECNId);
								    DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
								}
								else
								{
									//set checkeffdate here
									POM_AM__set_application_bypass(true);
									TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
									if(!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
									}
									TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4CheckEffectivityDate", false), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
									if(!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);		
									}		
									POM_AM__set_application_bypass(false);		
								}
							}
							else 
							{
								POM_AM__set_application_bypass(true);
								TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
								if(!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
								}
								TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4CheckEffectivityDate", false), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
								if(!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);		
								}		
								POM_AM__set_application_bypass(false);		
							}
						}
					}
					Custom_free(pcRange);
					Custom_free(pcEffDateTime);
					Custom_free(tEffTagList);
					Custom_free(tEffDateTime);
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttachtag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}




 
/*******************************************************************************
 * Function Name			: teradyneBuildNotificationSubjectRevise
 * Description				: Will return the subject for notification email
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  strSubject     - The subject for notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
 std::string teradyneBuildNotificationSubjectRevise(EPM_action_message_t msg, string szECNnumber){
  int iStatus			    = ITK_ok;

  string bufferSubject		= " ";

  const char * __function__    = "teradyneBuildNotificationSubjectRevise";
  
  try
  {
	  bufferSubject.append("Revise Effectivity not applicable for ").append(szECNnumber);
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  return bufferSubject;
 }
 
 /*******************************************************************************
 * Function Name			: teradyneBuildNotificationBodyContentRevise
 * Description				: Will build the html body content for notification 
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  bufferContent  - the html content for the notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
std::string teradyneBuildNotificationBodyContentRevise(EPM_action_message_t msg, char* commentEmail){
  int iStatus			    = ITK_ok,
	  iSignoffAttCount		= 0,
	  iCount				= 0;

  string bufferHTMLContent	= "<html><head></head><body>",
		pcComment			= "";

  char *jobName			= NULL,
	   *currentTask		= NULL,
	   *description		= NULL,
	   *pcDueDate		= NULL;

  date_t due_date;

  tag_t *tAttaches				= NULL,
		*tSignoffAttachments	= NULL,
		tMember					= NULLTAG;
  
  
  const char * __function__    = "teradyneBuildNotificationBodyContentRevise";
  
  try
  {
	 TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(msg.task, EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW);
	 pcComment = commentEmail;
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "job_name", &jobName) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_string", &currentTask) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(msg.task, "due_date", &due_date) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_desc", &description) ,TD_LOG_ERROR_AND_THROW);
	 
	 if(due_date.year==0 && due_date.month==0 && due_date.day==0)
	 {
	      pcDueDate = (char *) MEM_alloc(sizeof(char) * 2);
		  strcpy(pcDueDate, "None");  
	 }
	 else
	 {
	     DATE_date_to_string	(due_date,"%d-%b-%Y %H:%M",&pcDueDate); // convert the date to string 
	 }

	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
	 bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(jobName).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("REVISE EFFECTIVITY WORKFLOW cannot be performed because the effectivity date of ").append(pcComment).append(" has already passed").append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("(none)").append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); //end table
	 bufferHTMLContent.append("<br>");
	 
	 // Target Attachments
     TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Target:</b></font>\r\n");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>\r\n");
	 
	 bufferHTMLContent.append("<tr height=\"8\">\r\n");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
	 
     for(int iTarget=0; iTarget < iCount;iTarget++)
	 {
	    char *pcItemId = NULL,*pcObjectType = NULL;
	    TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tAttaches[iTarget], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[iTarget],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
	   
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType);
	  }
     
     bufferHTMLContent.append("</tbody></table>\r\n"); // end target attachment tables
     bufferHTMLContent.append("<br><br>");

     // Target References
     int iRefCount=0;
	 tag_t *tReferenceAttachments;

	 TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iRefCount, &tReferenceAttachments), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Reference:</b></font>");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>");
	 
	 bufferHTMLContent.append("<tr height=\"8\">");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
     
      
     for(int iReference=0; iReference < iRefCount;iReference++)
	 {
        char *pcItemId = NULL,*pcObjectType = NULL;
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tReferenceAttachments[iReference], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tReferenceAttachments[iReference],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
						    
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType);
	 }
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); // end target references
     bufferHTMLContent.append("<br><br>");
     
     bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");
     
     
     Custom_free(tAttaches);
	 Custom_free(tSignoffAttachments);
     Custom_free(tReferenceAttachments);
  
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  bufferHTMLContent.append("</body></html>\r\n");
  
  return bufferHTMLContent;
 }