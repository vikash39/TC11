/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :          teradyne_checkeffectivitydatewithtodaydate.cpp      
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CheckEffectivityDate action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D.          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  02-Jan-2019                       Marjorie D				        	Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_update_effectivitydate
 * Description				: This function will update the Effectivity date with tomorrow's date 
 *								if the Effectivity date during T4O is lesser than today's date.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_update_effectivitydate(EPM_action_message_t msg){
	
	int		iStatus			    = ITK_ok,
			iAttachCount		= 0,
			iEffCount			= 0,
			iDateCount			= 0;

	tag_t	*tAttachtag			= {NULLTAG},
			tECNRelStatusTag	= NULLTAG,
			*tEffTagList		= {NULLTAG};

	string  szStartDate			= "";

	char	*pcAttachType		= NULL,
		    *pcEffDateTime		= NULL,
			*pcEffDate			= NULL,
			*pcRange            = NULL;

	string	szCurTimeStamp,
	        szEffrange;

	date_t	curDateTime,
			*tEffDateTime,
			convertedDateTime;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	const char * __function__    = "teradyne_update_effectivitydate" ;
	TERADYNE_TRACE_ENTER();

	try{
			if(msg.task != NULLTAG) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttachCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)) {

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tAttachtag[i],&tECNRelStatusTag), TD_LOG_ERROR_AND_THROW);
						if(tECNRelStatusTag != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tECNRelStatusTag,&iEffCount,&tEffTagList),TD_LOG_ERROR_AND_THROW);
							if(iEffCount > 0) {

								TERADYNE_TRACE_CALL( iStatus = WSOM_eff_ask_dates( tECNRelStatusTag, tEffTagList[iEffCount - 1], &iDateCount, &tEffDateTime, &open_ended_or_stock_out ), TD_LOG_ERROR_AND_THROW );
								//Gets the latest start date in the start-end date range
								int iLatestStartDate = (iDateCount % 2 == 0) ? (iDateCount - 2) : (iDateCount - 1);

								if (tEffDateTime[iLatestStartDate].hour >= 21) {
									TERADYNE_TRACE_CALL(iStatus = POM_convert_date(POM_local_to_gmt, tEffDateTime[iLatestStartDate], &convertedDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%Y%m%d", &pcEffDate), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%d-%b-%Y %H:%M", &pcRange), TD_LOG_ERROR_AND_THROW);
									szEffrange.append(pcRange).append(" to ").append("UP");
									TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tAttachtag[i], tECNRelStatusTag, szEffrange, "", false), TD_LOG_ERROR_AND_THROW);
								} else {
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( tEffDateTime[iLatestStartDate], "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( tEffDateTime[iLatestStartDate], "%Y%m%d", &pcEffDate), TD_LOG_ERROR_AND_THROW);
								}

								string szEffDate(pcEffDateTime);
								szEffDate = szEffDate.substr(0, 8);

								TC_write_syslog("INFO : The Latest start date of effectivity is %s \n",szEffDate);
								TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW);
								TC_write_syslog("INFO : The Current time stamp is %s \n",szCurTimeStamp);
								unsigned long long lEffDate = stoull(szEffDate.c_str());
								unsigned long long lCurrDate = stoull(szCurTimeStamp.c_str());

								if(lEffDate <= lCurrDate) //if effectivity date is less than current date, set effectivity date to today
								{
									char *currentDateRange = NULL;
									string szCurrentDateTime;

									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( curDateTime, "%d-%b-%Y %H:%M", &currentDateRange), TD_LOG_ERROR_AND_THROW);

									szCurrentDateTime.append(currentDateRange).append(" to ").append("UP");
									TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tAttachtag[i], tECNRelStatusTag, szCurrentDateTime, "", false), TD_LOG_ERROR_AND_THROW);

									TC_write_syslog("INFO : NEW EFFECTIVITY DATE is : %s  \n", szCurrentDateTime);

									Custom_free(currentDateRange);
								} 

								Custom_free(pcRange);
								Custom_free(pcEffDateTime);
								Custom_free(pcEffDate);
							} else {

								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_EFF_DATE_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_EFF_DATE_ERROR;
								throw iStatus;
							}
						}
					}
					Custom_free(tEffTagList);
					Custom_free(tEffDateTime);
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttachtag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
