/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_protobomecnvalidations.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ProtoBOMECNValidations action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_protobomecnvalidations
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  05-May-2015					     Vijayasekhar                    	Changed the validation rules
#  01-Oct-2015                       Manimaran                          Modified the code to allow single parts (w/o BOMs) to be revised within ProtoBOM ECN.
#  15-Oct-2015                       Manimaran                          Modified the code to not to allow single parts (w/o BOMs) to be revised within ProtoBOM ECN.
#  14-Dec-2015						 Kameshwaran D						Added condition to restrict if all impacted items(DivPart) are not revised.
#  23-Dec-2015                       Manimaran                          Modified the code to throw error if no items present under Impacted Items Folder of ECN.
#  18-Jan-2016                       Manimaran                          Modified the code to skip the Impacted Items check for ProtoBOM ECN.
#  25-Mar-2016                       Haripriya                          Modified the code to check childlines object type because Divisional and commercial Part Revisions are allowed and changed teradyne_get_bomline_children arguments.
#  04-May-2016                       Haripriya                          Modified the teradyne_check_if_new_revision_exists_in_solutionitemsfolder function to check same revision is present in impacted and solution item folder
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_protobomecnvalidations
 * Description				: This function will validates the Assembly/Itemstatus on ProtoBOMECN
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the parts attached to the relation Solution Items
 *							  2. Will check the part is an assembly if not stops the tast
 *							  3. Will check the Item status for the part revision is "Prototype if not stops the tast
 * NOTES					: 
 ******************************************************************************/
int teradyne_protobomecnvalidations(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0,
		iPartCount				= 0,
		iBvrCount				= 0,
		iChildCount				= 0,
		iDataset				= 0,
		iDesignDoc				= 0,
		iDocDataset				= 0,
		iItarFrmCnt				= 0;
	tag_t *tAttachList			= NULL,
		  *tPartList			= NULL,
		  *tBvrList				= NULL,
		  *tChildLine			= NULL, 
		  *tDataSet				= NULL,
		  tPrevRev				= NULLTAG;
	char *pcPartType			= NULL,
		 *pcItemStatus			= NULL,
		 *pcObjectType			= NULL,
		 *pcItemId				= NULL,
		*pcECNId				= NULL,
		*pcProjAttr				= NULL,
		*pcCBU					= NULL;

	bool bIsBomError			= false,
		 bisDatasetExist		= false,
		 bisDesignDocExist		= false;

	std::map<string, string> mapDocMissingDataSet;
	int iDocMissingDataSet = 0;

	const char * __function__ = "teradyne_protobomecnvalidations";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &tAttachList), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachList[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE)) 
				{
					//Gets the ECN number for the error messages reference
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i], TD_ITEM_ID_ATTR, &pcECNId), TD_LOG_ERROR_AND_THROW);
					//get CBU of Project Form
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i], TD_PRIMARY_PROJECT, &pcProjAttr), TD_LOG_ERROR_AND_THROW);
					if (tc_strlen(pcProjAttr) > 0)
					{
						tag_t projectTag = NULLTAG;

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_object_tag(pcProjAttr, TD_PROJECT_FORM_TYPE, &projectTag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(projectTag, TD_CONTRL_BUSS_UNIT, &pcCBU), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachList[i], TD_SOLUTION_ITEMS_REL_NAME, &iPartCount, &tPartList), TD_LOG_ERROR_AND_THROW);
					//Validate if new revision exists in solution item folder
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_if_new_revision_exists_in_solutionitemsfolder(tAttachList[i], tPartList, iPartCount, pcObjectType), TD_LOG_ERROR_AND_THROW);

					//create relation if NXT ECN
					if (tc_strcmp(pcCBU, TD_NXT) == 0)
					{
						int iObjCount = 0;
						
						//relation=CMHasSolutionItem, primary_attachment=target, secondary_type=TD4DesignDocRevision, primary_type=TD4ProtoBOMECNRevision, secondary_attachment=target

						tag_t CMHasSolutionItem_type_tag = NULLTAG, tIMANSpecRelTag = NULLTAG, relation_tag = NULLTAG, *tFindObjTag = NULL;
						char *pcTypeName = NULL;
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_SOLUTION_ITEMS_REL_NAME, &CMHasSolutionItem_type_tag), TD_LOG_ERROR_AND_THROW);
						//get all the design documents under the Specifications folder of part
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_IMAN_SPEC_REL_NAME, &tIMANSpecRelTag), TD_LOG_ERROR_AND_THROW);
						
						for (int ctr = 0; ctr < iPartCount; ctr++)//iterate all parts
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPartList[ctr], &pcPartType), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0) 
							{
								//get the secondary objects
								TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPartList[ctr], tIMANSpecRelTag, &iObjCount, &tFindObjTag), TD_LOG_ERROR_AND_THROW); 
								if ((tFindObjTag != NULL) && (iObjCount > 0))
								{
									for (int iCount = 0; iCount < iObjCount; iCount++)//iterate all objects under the Specifications folder
									{
										TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindObjTag[iCount], &pcTypeName), TD_LOG_ERROR_AND_THROW);
										if (!tc_strcmp(pcTypeName, TD_DESIGN_DOC_REV_TYPE) || !tc_strcmp(pcTypeName, TD_GENERAL_DOC_REV_TYPE))
										{
											TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tAttachList[i], tFindObjTag[iCount], CMHasSolutionItem_type_tag, &relation_tag), TD_LOG_ERROR_AND_THROW);
											if (relation_tag == NULLTAG) 
											{
												tag_t tNewRelation = NULLTAG;

												POM_AM__set_application_bypass(true);

												TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttachList[i], true), TD_LOG_ERROR_AND_THROW);

												TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tAttachList[i], tFindObjTag[iCount], CMHasSolutionItem_type_tag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);

												TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tNewRelation), TD_LOG_ERROR_AND_THROW);

												TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttachList[i], false), TD_LOG_ERROR_AND_THROW);

												POM_AM__set_application_bypass(false);
											}
										}
									}
								}
							}
						}
						Custom_free(tFindObjTag);
						Custom_free(pcTypeName);

					}
					
					for(int j = 0; j < iPartCount; j++) {
				
						bIsBomError = false;
						bisDatasetExist = false;
						bisDesignDocExist = false;

						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tPartList[j], &pcItemId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPartList[j], &pcPartType), TD_LOG_ERROR_AND_THROW);
						if(tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0) { //checking for Div part revision since solution items can also have Design Documents also
						
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPartList[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
							if(pcItemStatus == NULL) {
								//Check for the attribute in previous revision
								if(tPrevRev != NULLTAG) tPrevRev = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tPartList[j], &tPrevRev),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
							}
							//Check the item status on part revision is Prototype or not
							if(tc_strcmp(pcItemStatus, TD_PROTO_TYPE_ATTR)) {
						
								char *pcECNId = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_ITEM_STATUS_ERROR_PROTOBOM, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_ITEM_STATUS_ERROR_PROTOBOM;
								Custom_free(pcECNId);
								throw iStatus;
							}
							TERADYNE_TRACE_CALL(iStatus = teradyne_check_designdocument(tPartList[j], tAttachList[i], bisDesignDocExist, mapDocMissingDataSet), TD_LOG_ERROR_AND_THROW);

							iBvrCount = 0;
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tPartList[j], &iBvrCount, &tBvrList), TD_LOG_ERROR_AND_THROW); 
							//Check the part revision has assembly
							if(iBvrCount > 0) { 
								
								for(int k = 0; k < iBvrCount; k++) {
									string strEcnType = "";
									tag_t tWindow = NULLTAG;
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_bomline_children(tPartList[j], tBvrList[k], &iChildCount, &tChildLine, &tWindow,strEcnType), TD_LOG_ERROR_AND_THROW);
									if(iChildCount <= 0) {
									
										bIsBomError = true;
									}
									//Validating child objecttype
									for(int l = 0; l < iChildCount; l++) 
									{
										tag_t tItemRev = NULLTAG;
										char *pcBomType= NULL;
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tChildLine[l], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcBomType), TD_LOG_ERROR_AND_THROW);
									    if((tc_strcmp(pcBomType, TD_DIV_PART_REV)!=0) && (tc_strcmp(pcBomType, TD_COMM_PART_REV)!=0))
										{
											char *pcChildId = NULL;
											TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcChildId), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE_ERROR, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW);
											iStatus = TD_BOM_INVALID_CHILD_TYPE_ERROR;
											Custom_free(pcChildId);
											throw iStatus;
										}
										Custom_free(pcBomType);
									}
									Custom_free(tChildLine);
									if(tWindow != NULLTAG) {
									
										TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);
									}
									
								}
							} else {
							
								bIsBomError = true;
							}
							if(bIsBomError) {
							
								char *pcECNId = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_ASSEMBLY_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_ASSEMBLY_ERROR;
								Custom_free(pcECNId);
								throw iStatus;
							}

							if (tc_strcmp(pcCBU, TD_NXT) == 0)
							{
								if (!bisDesignDocExist) {
									//checks the part has dataset
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tPartList[j], TD_REF_MATERIAL_REL, &iDataset, &tDataSet), TD_LOG_ERROR_AND_THROW);
									if (iDataset > 0) {
										bisDatasetExist = true;
										Custom_free(tDataSet);
									}
								}

								if (!bisDatasetExist && !bisDesignDocExist && iBvrCount == 0) {
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_DESIGNDOC_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
									iStatus = TD_DATASET_DESIGNDOC_ERROR;
									throw iStatus;
								}

								// Docs missing ITAR/Datasets....
								if (!mapDocMissingDataSet.empty()) {
									for (map<string, string>::iterator it = mapDocMissingDataSet.begin(); it != mapDocMissingDataSet.end(); it++) {
										TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC, it->first.c_str(), it->second.c_str()), TD_LOG_ERROR_AND_THROW);
									}
									iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
								}
							}
						}
						
						
						if (tc_strcmp(pcPartType, TD_DESIGN_DOC_REV_TYPE) == 0 )
						{													
							if (tc_strcmp(pcCBU, TD_NXT) == 0)
							{
								tag_t *tItarFrmTag = NULL, *tDocDataset = NULL;
								int iDesignErr = 0, iItarFrmCnt = 0;
								bool bisItarFrmExist = false;

								mapDocMissingDataSet.clear();
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tPartList[j], TD_ITAR_REL, &iItarFrmCnt, &tItarFrmTag), TD_LOG_ERROR_AND_THROW);
								if (iItarFrmCnt > 0)
								{
									for (int iITarCnt = 0; iITarCnt < iItarFrmCnt; iITarCnt++)
									{
										char *pcItarFrm = NULL;
										//Bypassing to read Itar Form Object type
										POM_AM__set_application_bypass(true);
										TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItarFrmTag[iITarCnt], &pcItarFrm), TD_LOG_ERROR_AND_THROW);
										POM_AM__set_application_bypass(false);
										if (tc_strcmp(pcItarFrm, TD_ITAR_FORM_TYPE) == 0)
										{
											iDesignErr++;
											bisItarFrmExist = true;
											break;
										}
										Custom_free(pcItarFrm);
									}
									Custom_free(tItarFrmTag);
								}
								if (!bisItarFrmExist)
								{
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tPartList[j], TD_REF_MATERIAL_REL, &iDocDataset, &tDocDataset), TD_LOG_ERROR_AND_THROW);
									if (iDocDataset > 0)
									{
										iDesignErr++;
										Custom_free(tDocDataset);
									}
								}

								if (!bisItarFrmExist && iDocDataset == 0)
								{
									string pcDocumentMissingDataSet = "";
									char *pcItemId = NULL;
									char *pcRevId = NULL;
									char *pcDocumentType = NULL;
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPartList[j], TD_ITEM_ID_ATTR, &pcItemId), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPartList[j], TD_ITEM_REV_ID_ATTR, &pcRevId), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPartList[j], TD_DOCUMENT_TYPE_ATTR, &pcDocumentType), TD_LOG_ERROR_AND_THROW);

									pcDocumentMissingDataSet.append(pcItemId).append("_").append(pcDocumentType);
									mapDocMissingDataSet.insert(::make_pair((string)pcDocumentMissingDataSet, (string)pcRevId));


									Custom_free(pcItemId);
									Custom_free(pcRevId);
									Custom_free(pcDocumentType);
								}

								// Docs missing ITAR/Datasets....
								if (!mapDocMissingDataSet.empty()) {
									for (map<string, string>::iterator it = mapDocMissingDataSet.begin(); it != mapDocMissingDataSet.end(); it++) {
										TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC, it->first.c_str(), it->second.c_str()), TD_LOG_ERROR_AND_THROW);
									}
									iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
								}
								Custom_free(tItarFrmTag);
								Custom_free(tDocDataset);
							}
							//If there are Design Documents under the Solution Items Folder and ECN is non-NXT Project, throw an error message
							else
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_VALIDATE_ECNS_WITH_DESDOC, pcObjectType, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_VALIDATE_ECNS_WITH_DESDOC;
								throw iStatus;
							}
						}
						Custom_free(pcPartType);
						Custom_free(tBvrList);
						Custom_free(pcItemStatus);
						Custom_free(pcItemId);
					}
					Custom_free(pcProjAttr);
					Custom_free(pcCBU);
				}
				Custom_free(pcObjectType);
				Custom_free(tPartList);
			}
			if (iDocMissingDataSet > 0) 
			{
				iStatus = iDocMissingDataSet;
				throw iDocMissingDataSet;
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttachList);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_check_if_new_revision_exists_in_solutionitemsfolder
 * Description				: Validates if new revision exists in solution item folder
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tECNTag (I) - ECN tag
 *                            tSolPartList (I) - Solution Items tags
 *                            iSolPartCount (I) - Solution Item count
 *                            pcECNType (I) - ECN type
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. If impacted item (DivPart) is not revised then Do not allow workflow to proceed further
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_check_if_new_revision_exists_in_solutionitemsfolder(tag_t tECNTag, tag_t *tSolPartList, int iSolPartCount, char *pcECNType)
{
	int iStatus					= ITK_ok;

	const char * __function__ = "teradyne_check_if_new_revision_exists_in_solutionitemsfolder";
	TERADYNE_TRACE_ENTER();

	try {
		int iImpPartCount = 0;
		int iProtobom     = 0;
		tag_t *tImpPartList = NULL;
		string strErrorItm = "";
		/*Source Code :: If impacted item (DivPart) is not revised then Do not allow workflow to proceed further */
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tECNTag, TD_IMPACTED_ITEM_REL_NAME, &iImpPartCount, &tImpPartList), TD_LOG_ERROR_AND_THROW);

		//Throw error if no items present under Impacted Items Folder of ECN
		if (iImpPartCount == 0 && (tc_strcmp(pcECNType, TD_STD_ECN_REV_TYPE) == 0)) {
			TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NO_ITEMS_UNDER_IMPACTED_ITEMS_FOLDER_ERROR), TD_LOG_ERROR_AND_THROW);
			iStatus = TD_NO_ITEMS_UNDER_IMPACTED_ITEMS_FOLDER_ERROR;
			throw iStatus;
		}

		for(int iImpCount = 0 ; iImpCount < iImpPartCount ; iImpCount++) {
			bool bSolFlag = false;
			char *pcImpItemId = NULL;
			char *pcImpItemRevId = NULL;

			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tImpPartList[iImpCount], &pcImpItemId), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_rev_id2(tImpPartList[iImpCount], &pcImpItemRevId), TD_LOG_ERROR_AND_THROW);

			char *pcImpPartType = NULL;
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tImpPartList[iImpCount], &pcImpPartType), TD_LOG_ERROR_AND_THROW);

			//Checking for Div part revision since solution items can also have Design Documents also
			if(tc_strcmp(pcImpPartType, TD_DIV_PART_REV) == 0) {
				tag_t tLatestDivPartRev = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tImpPartList[iImpCount], &tLatestDivPartRev), TD_LOG_ERROR_AND_THROW);

				//Check Impacted items is revised and present under Solution item
				for(int iSolCount = 0 ; iSolCount < iSolPartCount ; iSolCount++) {
					
					if (tc_strcmp(pcECNType, TD_PROTOBOM_ECN_REV_TYPE) == 0) {
						//If solution item present
						iProtobom++;
						if((tSolPartList[iSolCount] == tLatestDivPartRev) && (tSolPartList[iSolCount] != tImpPartList[iImpCount] )) {
							bSolFlag = true;
							break;
						}
					}
					else {
						if((tSolPartList[iSolCount] == tLatestDivPartRev)) {
							bSolFlag = true;
							break;
						}
					}
				}
			} else {
				bSolFlag = true;
			}
			Custom_free(pcImpPartType);

			//Collect the impacted items which are not revised
			if(!bSolFlag) { 
				strErrorItm = strErrorItm.append(pcImpItemId).append(TD_SLASH_CONSTANT).append(pcImpItemRevId).append(TD_COMMA_CONSTANT).append(TD_SPACE_CONSTANT);
			}
			
			Custom_free(pcImpItemId);
			Custom_free(pcImpItemRevId);
		}
		Custom_free(tImpPartList);

		//Contains Impacted item list which are not revised and throw error with same
		if(strErrorItm.length() > 1) {
			char *pcECNID = NULL;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tECNTag, TD_ITEM_ID_ATTR, &pcECNID), TD_LOG_ERROR_AND_THROW);
			if (iProtobom > 0)
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_IMPCT_SOL_SAME_ITEM_ERROR, pcECNID, strErrorItm.c_str()), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_IMPCT_SOL_SAME_ITEM_ERROR;
			} else
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_IMPCT_ITEM_NOT_REVISED_ERROR, pcECNID, strErrorItm.c_str()), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_IMPCT_ITEM_NOT_REVISED_ERROR;
			}
			Custom_free(pcECNID);
			throw iStatus;
		}

	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
