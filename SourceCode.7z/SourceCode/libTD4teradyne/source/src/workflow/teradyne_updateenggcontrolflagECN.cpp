/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_updateenggcontrolflagECN.cpp
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateEnggControlFlagECN action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Apr-2015						Kameshwaran D						Intital creation
#  29-Apr-2015                      Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_updateenggcontrolflagECN
 * Description				: This function to update Engg control flag 
 *							  if Item status is changed from Prototpe to Pre-Production / Production
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_updateenggcontrolflagECN(EPM_action_message_t msg) {
	int iStatus					= ITK_ok,
		iCount					= 0;

	tag_t *tAttaches			= NULL;
	char *pcObjectType			= NULL;

	const char * __function__	= "teradyne_updateenggcontrolflagECN";
	
	TERADYNE_TRACE_ENTER();

	try {

			if(msg.task != NULLTAG) { 
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);

				for(int i = 0; i < iCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE)) {
					
						//Function will update Engg control flag based on item status
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_engg_control_flag(tAttaches[i]),TD_LOG_ERROR_AND_THROW);
					}
					Custom_free(pcObjectType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/***************************************************************************************************
 * Function Name			: teradyne_update_engg_control_flag
 * Description				: This function to update the Control Flag
 *							  which are under VMRepresent relation.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRevTag (Tag)		-  Revision tag of attachment
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					: 
 ******************************************************************************************************/
int teradyne_update_engg_control_flag(tag_t tRevTag)
{
	int iStatus			= 0,
		iObjCnt			= 0;

	tag_t	tRelationTag	= NULLTAG,
			*tFindObjTag	= {NULLTAG};

	string strTerPart_Attr[] = {TD_ITEM_STATUS_ATTR};

	std::map<string,string> strPropNameValueMap;

	const char * __function__		   = "teradyne_update_engg_control_flag";

	TERADYNE_TRACE_ENTER();

	try{
		
		//Get the CMHasSolutionItem relation type tag
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_SOLUTION_ITEMS_REL_NAME,&tRelationTag),TD_LOG_ERROR_AND_THROW);

		//Get Secondary objects of the attach object
		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevTag,tRelationTag,&iObjCnt,&tFindObjTag),TD_LOG_ERROR_AND_THROW);

		for(int iPos = 0 ; iPos < iObjCnt ; iPos++)
		{
			tag_t tSolItemTag = tFindObjTag[iPos] ; 

			string strItemStatus = "";

			string szSetStatusTo = "True";

			list<string> strAttrList( strTerPart_Attr, strTerPart_Attr + sizeof(strTerPart_Attr) / sizeof(string) );

			//Get the Item Status attribute value from teradyne part from solution folder
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tSolItemTag, strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);

			strItemStatus.assign(strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second);

			if(strItemStatus.compare("Pre-Production") == 0 || strItemStatus.compare("Production") == 0 )
			{
				//Set the Engeneering controlled attribute Flag to true on ECN
				TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tRevTag,TD_ENGG_CONTROL_FLAG_ATTR,szSetStatusTo), TD_LOG_ERROR_AND_THROW);
			}
		}
	}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

	Custom_free(tFindObjTag);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}