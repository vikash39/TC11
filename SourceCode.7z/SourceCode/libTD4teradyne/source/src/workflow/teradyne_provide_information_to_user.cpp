/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_provide_information_to_user.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-Provide-information-to-user rule handler
#      Project         :           libTD4teradyne
#      Author          :           Lalit
#  =================================================================================================
#  Date                              Name                               Description of Change
#  14-Aug-2015                      Lalit                    		Added function definitions teradyne_provide_information_to_user.
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


/*******************************************************************************
 * Function Name			: teradyne_provide_information_to_user
 * Description				: Validate CPR that have a Approved or Preferred supplier
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
EPM_decision_t teradyne_provide_information_to_user(EPM_rule_message_t msg)
{
	int iStatus = ITK_ok;
		
	EPM_decision_t epmDecision = EPM_nogo;
	const char * __function__ = "teradyne_provide_information_to_user";
	TERADYNE_TRACE_ENTER();

	try
	{
		epmDecision = EPM_go;
		EMH_clear_errors();
		TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_information, TD_UNABLE_TO_COMPLETE_COMMPARTREQ_ERROR), TD_LOG_ERROR_AND_THROW);
		throw (EPM_decision_t)TD_UNABLE_TO_COMPLETE_COMMPARTREQ_ERROR;
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);

	return epmDecision;
}

