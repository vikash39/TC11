/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_updatesupplierinformation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CheckDiscSpecForms action handler
#      Project         :           libTD4teradyne          
#      Author          :           Karl Reimann          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  25-October-2016                   Karl								Removed check for Standard and ProtoBOM, only Release will be checked.
#
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_checkDiscSpecForms
 * Description				: This function will check Release ECN - check div part discipline specific forms in solution items
 *							  If discipline specific forms are lacking, stop user from proceeding at author task.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-action","-task"  in task and action argument is mandatory.
 *							 2. For the given task ,given action is performed.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_checkDiscSpecForms(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iCount              = 0,
		iSecCount			= 0;

	tag_t *tAttachtag       = {NULLTAG},
		  *tAttaches		= NULL,
		  *tSecObjects		= NULL;

	char *pcObjectType		= NULL,
		 *pcECNId			= NULL,
		 *pcItemId			= NULL,
		 *pcSecObjType		= NULL,
		 *pcChgAdminDate	= NULL,
		 *pcChgHistDate		= NULL,
		 *pcDFMDate			= NULL,
		 *pcSBMDate			= NULL,
		 *pcSafetyDate		= NULL,
		 *pcTradeComplDate	= NULL;

	const char * __function__    = "teradyne_checkDiscSpecForms";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(msg.task != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				//if ECN is Release, check solution items
				if((tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0 ))
				{
					//Gets the ECN number for the error messages reference
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
					//getting all the parts in 'Solution Items'
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iSecCount; j++)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &pcSecObjType), TD_LOG_ERROR_AND_THROW);
						if(tc_strcmp(pcSecObjType, TD_DIV_PART_REV) == 0)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecObjects[j],TD_ITEM_ID_ATTR,&pcItemId), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcChgAdminDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEHISTORY_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcChgHistDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_DFM_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcDFMDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_SBM_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcSBMDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_SAFETY_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcSafetyDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_TRADE_COMPL_FORM_TYPE, 0, TD_OBJECT_NAME_ATTR, &pcTradeComplDate), TD_LOG_ERROR_AND_THROW);
							if (pcChgAdminDate == NULL || pcChgHistDate == NULL || pcDFMDate == NULL || pcSBMDate == NULL || pcSafetyDate == NULL || pcTradeComplDate == NULL)
							{
								if((tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0 ))
									pcSecObjType = "Release";
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_MISSING_DISC_SPEC_FORM_ERROR, pcItemId, pcSecObjType, pcECNId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_MISSING_DISC_SPEC_FORM_ERROR;
								throw iStatus;
							}
							Custom_free(pcItemId);
							Custom_free(pcChgAdminDate);
							Custom_free(pcChgHistDate);
							Custom_free(pcDFMDate);
							Custom_free(pcSBMDate);
							Custom_free(pcSafetyDate);
							Custom_free(pcTradeComplDate);
						}
						Custom_free(pcSecObjType);
					}
					Custom_free(pcECNId);
				}
				Custom_free(pcObjectType);
			}
		}
	} catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}