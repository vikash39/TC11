#include <workflow/teradyne_handlers.h>
std::string teradyneBuildNotificationSubj(EPM_action_message_t msg);
std::string teradyneBuildNotificationBodyContentComment(EPM_action_message_t msg, string commentEmail);


typedef map<string,string> MapSignOff;
struct SignOffComparator {
   bool operator()(MapSignOff signOffOne, MapSignOff signOffTwo){
      return (signOffOne.find("lastModifiedDate")->second > signOffTwo.find("lastModifiedDate")->second);
   }
};
extern "C"
int teradyne_commentNotification(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok;

	tag_t  tOwner				= NULLTAG,
		  *tSignoffAttachments	= NULL,
		  tMember				= NULLTAG,
		  tUserTag				= NULLTAG;

	string strMailFilePath		= "",
		   subject				= "";

	char *pcTypeName					= NULL,
		 *pcObjectType					= NULL, 
		 *pcNotificationReceiverEmail	= NULL,
		 *pcSignoffComments				= NULL,
		 *pcComment                     = NULL,
		 *the_sender_email_addr			= NULL;
	
	set<MapSignOff,SignOffComparator> setMapSignOff;	

	const char * __function__    = "teradyne_commentNotification";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG && msg.action != EPM_reject_action)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
			
			if(!strMailFilePath.empty())
			{
				strMailFilePath.clear();
			}
	
			if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMConditionTask") == 0)))
			{
				char *pcTaskResult = NULL;
				TERADYNE_TRACE_CALL(iStatus = EPM_get_task_result(msg.task,&pcTaskResult),TD_LOG_ERROR_AND_THROW);
				if(pcTaskResult != NULL && ((tc_strcmp(pcTaskResult, "Need more info?") == 0)))
				{
					
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(msg.task, &tOwner), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tOwner, &pcNotificationReceiverEmail), TD_LOG_ERROR_AND_THROW);
					string	szCurTimeStamp;
					date_t	curDateTime;

					TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW); // get current system date
					strMailFilePath.append(TD_TEMP_PATH).append("NEED_MORE_INFO_NOTIFICATION").append(szCurTimeStamp).append(".htm");

					int iSignoffAttCount = 0;
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_recipients_for_token(msg.task, "$USER", &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW); 

					for (int i = 0; i < iSignoffAttCount; i++)
					{ 
						char *pcUserType = NULL;
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSignoffAttachments[i], &pcUserType), TD_LOG_ERROR_AND_THROW);
						
						if(pcUserType != NULL && ((tc_strcmp(pcUserType, "User") == 0)))
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tSignoffAttachments[i], &the_sender_email_addr), TD_LOG_ERROR_AND_THROW); //gets the email address
							
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"comments",&pcComment),TD_LOG_ERROR_AND_THROW);

							if(pcComment == NULL || strlen(pcComment) == 0)
							{
								throw iStatus = TD_NO_COMMENTS_ERROR;
							}

							MapSignOff mapSignOff;
						
							mapSignOff["emailAddress"]=string(the_sender_email_addr);
							mapSignOff["signoffComment"]=string(pcComment);
						
							setMapSignOff.insert(mapSignOff);
						}
						
					 }
				
					if(!setMapSignOff.empty())
					 {
						 MapSignOff lastModifiedSignOff =*setMapSignOff.begin();
						 string strSignoffComment = lastModifiedSignOff.find("signoffComment")->second;
						 
						 if (pcNotificationReceiverEmail != NULL)
						 {
							 subject.assign(teradyneBuildNotificationSubj(msg));
							 string htmlBodyContent=teradyneBuildNotificationBodyContentComment(msg, strSignoffComment);
							 TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW); //required for teradyne_send_os_mail
							 TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject,strMailFilePath,pcNotificationReceiverEmail),TD_LOG_ERROR_AND_THROW); //sends the email
						 }
						 Custom_free(the_sender_email_addr);
						 DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
					 }



					 TERADYNE_TRACE_CALL(iStatus = teradyne_update_rejection_comments(msg.task,pcComment),TD_LOG_ERROR_AND_THROW); //rejection comments
					
				}
			}
			}
	} 
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}


std::string teradyneBuildNotificationSubj(EPM_action_message_t msg){
  int iStatus			    = ITK_ok;

  string bufferSubject		= " ";

  char *jobName				= NULL,
	   *currentTask			= NULL,
	   *parentTaskName		= NULL;

  const char * __function__    = "teradyneBuildNotificationSubj";
  
  try
  {
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"job_name",&jobName),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_string",&currentTask),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"parent_name",&parentTaskName),TD_LOG_ERROR_AND_THROW);
	  bufferSubject.append(jobName).append(" (CSE Needs More Information!)");
	  Custom_free(jobName);
	  Custom_free(currentTask);
	  Custom_free(parentTaskName);

  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  return bufferSubject;
 }



std::string teradyneBuildNotificationBodyContentComment(EPM_action_message_t msg, string commentEmail){
  int iStatus			    = ITK_ok,
	  iSignoffAttCount		= 0,
	  iCount				= 0;

  string bufferHTMLContent	= "<html><head></head><body>",
		pcComment			= "";

  char *jobName			= NULL,
	   *currentTask		= NULL,
	   *description		= NULL,
	   *pcDueDate		= NULL;

  date_t due_date;

  tag_t 
		tMember					= NULLTAG;
  
  
  const char * __function__    = "teradyneBuildNotificationBodyContentComment";
  
  try
  {
	
	 pcComment = commentEmail;
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "job_name", &jobName) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_string", &currentTask) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(msg.task, "due_date", &due_date) ,TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_desc", &description) ,TD_LOG_ERROR_AND_THROW);
	 
	 if(due_date.year==0 && due_date.month==0 && due_date.day==0)
	 {
	      pcDueDate = (char *) MEM_alloc(sizeof(char) * 2);
		  strcpy(pcDueDate, "None");  
	 }
	 else
	 {
	     DATE_date_to_string	(due_date,"%d-%b-%Y %H:%M",&pcDueDate); // convert the date to string 
	 }

	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
	 bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(jobName).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcComment).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("(none)").append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); //end table
	 bufferHTMLContent.append("<br>");
	 

     bufferHTMLContent.append("<br><br>");

     bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");
     
   
  
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  bufferHTMLContent.append("</body></html>\r\n");
  
  return bufferHTMLContent;
 }




 int teradyne_update_rejection_comments(tag_t task,string comment){

	 int iStatus =ITK_ok,
		 iAttaches=0;
	 tag_t tUser					= NULLTAG;
	 tag_t *tAttaches			= NULL;
	 string strCurTimeStamp		= "",
		    concatenatedString	= "",
		    appendedValue		= "";
	 char *pcUserName			= NULL;
	 date_t curDate;
	 const char * __function__     = "teradyne_update_rejection_comments" ;
	 TERADYNE_TRACE_ENTER();



  try
	{
		if(task != NULLTAG) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);

			for(int i=0;i<iAttaches;i++){
			    char *pcTypeName=NULL;
				char *pcRejectionComments = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);

				if( pcTypeName != NULL && (tc_strcmp(pcTypeName,TD_COMM_PART_REQ_REV) == 0 ) ){
				    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_REJECTION_COMMENTS, &pcRejectionComments), TD_LOG_ERROR_AND_THROW);	
					TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
			    
				    if(strCurTimeStamp != "" && strCurTimeStamp.length() > 0) {
		
				    concatenatedString.append(strCurTimeStamp);
				    concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			        }
		
					if(pcUserName != NULL) {
					 concatenatedString.append(pcUserName);
				     concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			        }

					if(comment.length() > 0) {
	                   concatenatedString.append(comment);
			        }



					if(pcRejectionComments !=NULL){
					    appendedValue=pcRejectionComments;
						appendedValue.append("\n------\n");
					}

					if(concatenatedString != "" && concatenatedString.length() > 0) {
		                 appendedValue.append(concatenatedString);
				     }
							
				
				    AM__set_application_bypass(true);
			        TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tAttaches[i], TD_REJECTION_COMMENTS, appendedValue), TD_LOG_ERROR_AND_THROW);
				    AM__set_application_bypass(false);
				    appendedValue = "";
							
						

				
				
				}
				
			 }
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	
	return iStatus;




 }