/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_whereusedterpart4ROHS.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-WhereUsedTERPart4ROHS action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar        
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Nov-2014                       Vijayasekhar                    	Added function definitions teradyne_whereusedterpart4ROHS and teradyne_change_ownership
#  23-Feb-2015                       Vijayasekhar                    	Added changes to complete the workflow if the target object already present in the 'Compliance Regrade' Folder
#  12-Mar-2015                       Vijayasekhar                    	Changed arguments for teradyne_get_attachments																		
#  18-May-2015                       Haripriya                    	    Modified teradyne_get_and_copy_where_used_parts fn,Added teradyne_check_given_object_in_folder fn  																	
#  04-Jun-2015                       Vijayasekhar                       Added condition to check object type
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_whereusedterpart4ROHS
 * Description				: This function will get where used parts for the action handler 
 *							  Teradyne-WhereUsedTERPart4ROHS                            
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checks whether "Compliance Regrade" folder present in dba group.
 *							  2. If folder not available then creating the folder under dba group
 *							  3. Geting the where used parts of the Item revision and will get copy to the created folder.
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_whereusedterpart4ROHS(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0;
		
	tag_t *ptAttaches			= NULL,
		  tFolder				= NULLTAG;
	char *pcObjectType			= NULL;	 

	const char * __function__ = "teradyne_whereusedterpart4ROHS";
	TERADYNE_TRACE_ENTER();

	try {
			//Checks whether "Compliance Regrade" folder present in dba group ,if not create it under dba group
			TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_create_complaince_regrade_folder(&tFolder), TD_LOG_ERROR_AND_THROW);

			if(msg.task != NULLTAG) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttachCount; i++) {
					
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcObjectType, TD_DIV_PART_REV) || !tc_strcmp(pcObjectType, TD_COMM_PART_REV)) {
					
						//Geting the where used parts of the Item revision and will get copy to the created folder.
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_and_copy_where_used_parts(ptAttaches[i],tFolder), TD_LOG_ERROR_AND_THROW);
					}
					Custom_free(pcObjectType);
				}
			}
		}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	
	
	Custom_free(ptAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_get_and_copy_where_used_parts
 * Description				: Will change the owner ship of object from current group to another group
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject (I) - Object tag
 *							  toGroup (I) - The group to change the object
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Geting the where used parts of the Item revision and will get copy to the created folder.
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_and_copy_where_used_parts(tag_t tRevtag, tag_t tFolder)
{
	int			iStatus					= ITK_ok,
				iNParents				= 0,
				*piLevels				= NULL;

	tag_t		*ptParents				= NULL;

	const char * __function__ = "teradyne_get_and_copy_where_used_parts";
	TERADYNE_TRACE_ENTER();

	try {
			TERADYNE_TRACE_CALL(iStatus = PS_where_used_all(tRevtag, PS_where_used_all_levels, &iNParents, &piLevels, &ptParents), TD_LOG_ERROR_AND_THROW);
			for(int index = 0; index < iNParents; index++)
			{
				if(index == iNParents - 1 || piLevels[index] >= piLevels[index + 1]) {
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_given_object_in_folder(tFolder,ptParents[index]), TD_LOG_ERROR_AND_THROW);
				}
			}
			if(iNParents == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_check_given_object_in_folder(tFolder,tRevtag), TD_LOG_ERROR_AND_THROW);
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(piLevels);
	Custom_free(ptParents);
 
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/*******************************************************************************
 * Function Name			: teradyne_change_ownership
 * Description				: Will change the owner ship of object from current group to another group
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject (I) - Object tag
 *							  toGroup (I) - The group to change the object
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_change_ownership(tag_t tObject, string toGroup) {

	int iStatus					= ITK_ok;
	char *pcUserName			= NULL,
		 *pcGroupNm				= NULL;
	tag_t tUser					= NULLTAG,
		  tGroup				= NULLTAG,
		  tDba					= NULLTAG;
	
	const char * __function__ = "teradyne_change_ownership";
	TERADYNE_TRACE_ENTER();

	try {
	
		TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = POM_ask_group(&pcGroupNm, &tGroup), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = SA_find_group(toGroup.c_str(), &tDba), TD_LOG_ERROR_AND_THROW);
		if(tc_strcmp(pcGroupNm, toGroup.c_str()) != 0) {

			TERADYNE_TRACE_CALL(iStatus = AOM_set_ownership(tObject, tUser, tDba), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }	


	Custom_free(pcUserName);
	Custom_free(pcGroupNm);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_check_and_create_complaince_regrade_folder
 * Description				: Checks whether "Compliance Regrade" folder present in dba group.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject (I) - Object tag
 *							  toGroup (I) - The group to change the object
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checks whether "Compliance Regrade" folder present in dba group.
 *							  2. If folder not available then creating the folder under dba group
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_check_and_create_complaince_regrade_folder(tag_t *tFolder)
{
	int		iStatus					= ITK_ok,
			iObjCount				= 0;

	tag_t	*tObjList				= NULL,
			 tOwningGroup			= NULLTAG,
			 tCreObj				= NULLTAG;

	char	*pcTypeName				= NULL,
			*pcGroupName			= NULL;
			

	bool bCreFolder				= false;

	const char * __function__ = "teradyne_check_and_create_complaince_regrade_folder";
	TERADYNE_TRACE_ENTER();

	try{
		//get the object tag for the object Compliance Regrade
		TERADYNE_TRACE_CALL(iStatus = WSOM_find2(TD_CMPL_REG_FLDR, &iObjCount, &tObjList), TD_LOG_ERROR_AND_THROW); 
		if(iObjCount > 0) { //checking for the folder existence
		
			for(int i = 0; i < iObjCount; i++) {
		
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjList[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				if(pcTypeName != NULL) {
					
					if(tc_strcmp(pcTypeName, TD_FLDR_TYPE) == 0) {
						
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_group(tObjList[i], &tOwningGroup), TD_LOG_ERROR_AND_THROW); //getting owning user name
						if(tOwningGroup != NULLTAG) {
							
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_name(tOwningGroup, &pcGroupName), TD_LOG_ERROR_AND_THROW);
							if(pcGroupName != NULL) {
							
								if(tc_strcmp(pcGroupName, TD_DBA_GROUP) == 0) { 
								
									bCreFolder = false;
									*tFolder = tObjList[i];
									break; //breaking the loop if the folder found in dba group
								} else { 
								
									bCreFolder = true;
								}
							}
						}
					}
				}
			}
		} else {
		
			bCreFolder = true;
		}
		if(bCreFolder) {
			//creating folder in name compliance Regrade
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_object(TD_FLDR_TYPE,TD_CMPL_REG_FLDR, &tCreObj), TD_LOG_ERROR_AND_THROW);
			if(tCreObj != NULLTAG) {
				
				*tFolder = tCreObj;				
				TERADYNE_TRACE_CALL(iStatus = teradyne_change_ownership(*tFolder, TD_DBA_GROUP), TD_LOG_ERROR_AND_THROW);
			}
		}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcGroupName);
	Custom_free(pcTypeName);
	Custom_free(tObjList);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_check_given_object_in_folder
 * Description				: Checks whether given object exist in the given folder,else paste
 *                            the object in the given folder
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tFolder (I) - Folder tag
 *							  object (I)  - object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_check_given_object_in_folder(tag_t tFolder,tag_t object)
{
	int		iStatus					= ITK_ok,
		    iFound                       = 0,
			iRefCount				= 0;

	tag_t *tRefList                 = {NULLTAG};

	const char * __function__ = "teradyne_check_given_object_in_folder";
	TERADYNE_TRACE_ENTER();
	try
	{
		if(tFolder != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = FL_ask_references(tFolder,FL_fsc_as_ordered, &iRefCount, &tRefList), TD_LOG_ERROR_AND_THROW);	
			if(iRefCount > 0 ) {
				for(int i = 0; i < iRefCount; i++) {
						
					if(object == tRefList[i]) {
						iFound++;
					}
				}
				if(iFound == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = FL_insert(tFolder,object, 999), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tFolder), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tFolder, false), TD_LOG_ERROR_AND_THROW);
				}
			}
			else if(iRefCount == 0)	
			{
				TERADYNE_TRACE_CALL(iStatus = FL_insert(tFolder, object, 999), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tFolder), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tFolder, false), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tRefList);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

