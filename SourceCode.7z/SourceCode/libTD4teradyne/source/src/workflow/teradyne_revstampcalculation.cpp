/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_revstampcalculation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-RevStampCalculation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  18-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_revstampcalculation and teradyne_get_effective_date_range.
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_translate_and_set_effective_date.
#  15-Apr-2015                       Haripriya                    	    Modified function to bypass POM .
#  20-Apr-2015                       haripriya                          Modified function for error message
#  29-Apr-2015					     Vijayasekhar                    	Added condition to check the suitable target objects
#  23-Sep-2015                       Manimaran                          Modified the code to fix rev stamp calculation issue in case of more than one HLA or PCBA Parts in solution item folder.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_revstampcalculation
 * Description				: Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ECN and the Change Admin Form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:1. Will get all the parts in SolutionItems folder
 *							 2. Will get the Date range effectivity of release status Part revisions and translate the to Week number format.
 *							 3. For the Part Type of any item in solution items is HLA(instrument) or PCBA then will update Rev Stamp attribute on ECN and Change Admin Form
 * NOTES					: 
 ******************************************************************************/
int teradyne_revstampcalculation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL;
	char *pcAttachType			= NULL;

	const char * __function__ = "teradyne_revstampcalculation";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE)) { 
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_translate_and_set_effective_date(tAttaches[i]), TD_LOG_ERROR_AND_THROW);
				}
			}
			Custom_free(pcAttachType);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_get_effective_date_range
 * Description				: Will get the effectivity date range for the release status of the part
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject  		  (I) - Target object tag
 *							  pcRangeTxt (OF)     - Date range text char**
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the release status of the part revision.
 *							  2. if the relase status is TD4Released then return the effective date range text
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_effective_date_range(tag_t tObject, char** pcRangeTxt) { // need to free pcRangeTxt

	int iStatus					= ITK_ok,
		iRelStatus				= 0,
		iEffectivities			= 0;
	tag_t *tRelStatus			= NULL,
		  *tEffectivities		= NULL;
	char *pcRelStatusType		= NULL;

	const char * __function__ = "teradyne_get_effective_date_range";
	TERADYNE_TRACE_ENTER();

	try {
		//assuming that the item revision has only one release and one date range, logic can be changed for the multiple values
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tObject, &iRelStatus, &tRelStatus), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iRelStatus; i++) {
		
			TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tRelStatus[i], &pcRelStatusType) ,TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcRelStatusType, TD_REL_STATUS_NAME) == 0) {
			
				TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tRelStatus[i], &iEffectivities, &tEffectivities), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_date_range(tRelStatus[i], tEffectivities[0], pcRangeTxt), TD_LOG_ERROR_AND_THROW);
				break;
			}
			Custom_free(pcRelStatusType);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tRelStatus);
	Custom_free(pcRelStatusType);
	Custom_free(tEffectivities);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_translate_and_set_effective_date
 * Description				: Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ECN and the Change Admin Form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tAttach (I) - Attachments tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:1. Will get all the parts in SolutionItems folder
 *							 2. Will get the Date range effectivity of release status Part revisions and translate the to Week number format.
 *							 3. For the Part Type of any item in solution items is HLA(instrument) or PCBA then will update Rev Stamp attribute on ECN and Change Admin Form
 * NOTES					: 
 ******************************************************************************/
int teradyne_translate_and_set_effective_date(tag_t tAttach) {

	int iStatus					= ITK_ok,
		iPartCount				= 0;
	tag_t *tPartList			= NULL,
		  tChgAdmin				= NULLTAG;
	char *pcPartType			= NULL,
		 *pcPartTypeAttr		= NULL,
		 *pcDateRange			= NULL,
		 *pcMinShip				= NULL;
	string strStartDate			= "";

	logical islogicalMinShip = false;

	const char * __function__ = "teradyne_translate_and_set_effective_date";
	TERADYNE_TRACE_ENTER();

	try {
		//getting all the parts in 'Solution Items'
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttach, TD_SOLUTION_ITEMS_REL_NAME, &iPartCount, &tPartList), TD_LOG_ERROR_AND_THROW);
		for(int j = 0; j < iPartCount; j++) {
				
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPartList[j], &pcPartType), TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0) { //checking for Div part revision since solution items can have disign documents also
					
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPartList[j], TD_PART_TYPE_ATTR, &pcPartTypeAttr), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcPartTypeAttr, "HLA(Instrument)") || !tc_strcmp(pcPartTypeAttr, "PCBA")) {
							
					if(pcDateRange != NULL) { pcDateRange = NULL; }
					//Gets the effective date range contains start date and end date
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_effective_date_range(tPartList[j], &pcDateRange), TD_LOG_ERROR_AND_THROW);
					if(pcDateRange == NULL) {
						char *pcitemid =NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttach,TD_ITEM_ID_ATTR,&pcitemid), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_NO_DATE_RANGE,pcitemid), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_NO_DATE_RANGE;
						Custom_free(pcitemid);
						Custom_free(tPartList);
						Custom_free(pcPartType);
						Custom_free(pcPartTypeAttr);
						Custom_free(pcDateRange);
						return iStatus;
					} else {

						string strDateRange(pcDateRange);
						strStartDate = strDateRange.substr(0,strDateRange.find(" ")); // Gets the start date in the date range "dd-Mon-yyyy"
						if(strStartDate.length() == 11) {
							POM_AM__set_application_bypass(true);
							string strYearWeekDate = "";
							//Gets the year week format from the given date
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_week_from_date(strStartDate, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
							//setting the yearweek date format on REV STAMP property on ECN revision
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tAttach, TD_REV_STAMP_ATTR, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
							//setting the yearweek date format on Rev Stamp property on change admin form of the part revision
							TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tPartList[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tChgAdmin), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgAdmin, TD_PART_REV_STAMP, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
							POM_AM__set_application_bypass(false);
							//getting the property "PCB only - Change Minimum Shippable Revision" of ECN Revision
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttach, TD_UPD_MIN_SHIP_REV_ATTR, &islogicalMinShip), TD_LOG_ERROR_AND_THROW);

							if(islogicalMinShip) {
								POM_AM__set_application_bypass(true);
								//setting the yearweek date format on Min ship Rev property on change admin form of the part revision
								TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgAdmin, TD_PART_MIN_SHIPPABLE_REV, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
								POM_AM__set_application_bypass(false);
							}
						}	
					}
				}
			}
			Custom_free(pcPartType);
			Custom_free(pcPartTypeAttr);
			Custom_free(pcDateRange);
			Custom_free(pcMinShip);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tPartList);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
