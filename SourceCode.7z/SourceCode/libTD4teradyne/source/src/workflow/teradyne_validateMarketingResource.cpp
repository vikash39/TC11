/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_validateMarketingResource.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SolutionItems-ORG-Check rule handler
#      Project         :           libTD4teradyne          
#      Author          :           Marjorie          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Jun-2018                     Marjorie                    	Added function definitions teradyne_validateMarketingResource.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_validateMarketingResource
 * Description				: Validate Oracle Form and child ORG Value in Oracle name property
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_validateMarketingResource(EPM_action_message_t msg) {

	int iStatus			    = ITK_ok,
		iAttachCount        = 0;

	tag_t *tAttachtag       = {NULLTAG};
	

	char *pcObjectType			= NULL,
		 *pcPCNClass            = NULL;
	std::map<string,string> strECNPropNameValueMap,strPropNameValueMap;
	string szStdEcn_Attr[]  = {TD_PCN_CLASS_ATTR};
	
	EPM_decision_t epmDecision  = EPM_nogo;
	const char * __function__    = "teradyne_validateMarketingResource";
	TERADYNE_TRACE_ENTER();
	
	try 
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment,&iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE)) 
				{					
					char *pcTypeName  = NULL; //checks task type
					bool bisverdict = true;
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[i],TD_PCN_CLASS_ATTR,&pcPCNClass), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcPCNClass,"Class I") || !tc_strcmp(pcPCNClass,"Class II")) 
					{
						std::map<string,string> strPropNameValueMap;
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(tAttachtag[i],strPropNameValueMap,TD_MARKETING_ATTR),TD_LOG_ERROR_AND_THROW);
						//if Marketing Resource is Empty
						if(!strPropNameValueMap.empty() && strPropNameValueMap.find(TD_MARKETING_ATTR)->second.length() == 0)
						{	
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
							if(pcTypeName != NULL && tc_strcmp(pcTypeName, "EPMDoTask") != 0) //if not a Do Task && is a Condition
							{
								POM_AM__set_application_bypass(true);
								TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
								if(!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
								}
								TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4MarketingReqd", true), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
								if(!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);		
								}		
								POM_AM__set_application_bypass(false);	
							}

							//throw error message on Start
							if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMDoTask") == 0)) &&  (msg.action == EPM_start_action || msg.action == EPM_resume_action)) 
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_warning, TD_NO_MARKETING_RESOURCE_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = 	ITK_ok;
							}

							//throw error message on Complete
							if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMDoTask") == 0)) && msg.action == EPM_complete_action) 
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NO_MARKETING_RESOURCE_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = 	TD_NO_MARKETING_RESOURCE_ERROR;
								throw iStatus;
							}
						}
						else
						{
							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
							if(!bisverdict)
							{
								TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
							}
							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4MarketingReqd", false), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
							if(!bisverdict)
							{
								TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);		
							}		
							POM_AM__set_application_bypass(false);	
						}
					}
					else
					{
							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tAttachtag[i],&bisverdict),TD_LOG_ERROR_AND_THROW);
							if(!bisverdict)
							{
								TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],true),TD_LOG_ERROR_AND_THROW);				
							}
							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tAttachtag[i], "td4MarketingReqd", false), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttachtag[i]), TD_LOG_ERROR_AND_THROW);
							if(!bisverdict)
							{
								TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tAttachtag[i],false),TD_LOG_ERROR_AND_THROW);		
							}		
							POM_AM__set_application_bypass(false);	
					}
				}	
			}
		}
	} catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	
	Custom_free(pcObjectType);
	Custom_free(tAttachtag);
	Custom_free(pcPCNClass);
	return iStatus;
}