/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assignstatusondesigndoc.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignStatusOnDesignDoc action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  12-Mar-2015                       Vijayasekhar                    	Initial Creation
#  29-Apr-2015						 Vijayasekhar                    	Added condition to check the suitable target objects and added release status to the datasets
#  05-May-2015					     Vijayasekhar						Added changes to get the relation from the workflow arguments
#  06-May-2015					     Haripriya 						    Added changes to added release status to dataset
#  21-Dec-2016					     Karl Reimann						Added changes to add release status to Additional Reviewers Form
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assignstatusondesigndoc
 * Description				: This function will release all the Design Documents in the custom relation folder call PCBA Design Document.
							  In addition, this will also release the Additional Reviewer Form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_assignstatusondesigndoc(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0,
		iCount					= 0,
		iDataset				= 0;
	tag_t tReleased				= NULLTAG, 
		  *tObjects				= NULL,
		  *tAttaches			= NULL,
		  *tDataset				= NULL;
	char *pcObjectType			= NULL,
		 *pcRelation			= NULL;

	const char * __function__ = "teradyne_assignstatusondesigndoc";
	TERADYNE_TRACE_ENTER();

	try {
		
		if(msg.task != NULLTAG) {

			//read the handler arguments
			teradyne_get_handler_opts(msg.arguments, "-from_relation", &pcRelation, NULL);
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE))
				{
					if(pcRelation != NULL)
					{
						//Getting the all the design documents from the given relation 
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], pcRelation, &iCount, &tObjects), TD_LOG_ERROR_AND_THROW);
						for(int j = 0; j < iCount; j++) 
						{ 
							//relasing the design documets associated with PCBADesignDocumets relation
							if(tReleased != NULLTAG) tReleased = NULLTAG;
							TERADYNE_TRACE_CALL(iStatus = RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleased), TD_LOG_ERROR_AND_THROW);
							if(tReleased != NULLTAG) 
							{
								TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, 1, &tObjects[j], true), TD_LOG_ERROR_AND_THROW);
								//Add release status to the datasets in Files folder
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tObjects[j], TD_REF_MATERIAL_REL, &iDataset, &tDataset), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, iDataset, tDataset, true), TD_LOG_ERROR_AND_THROW);
							}
							Custom_free(tDataset);
						}
						//Getting the additional reviewer form
						/*TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_ADDITIONAL_REVIEWER_REL_NAME, &iCount, &tObjects), TD_LOG_ERROR_AND_THROW);
						for(int j = 0; j < iCount; j++) 
						{ 
							//relasing the additional reviewer form
							
							if(tReleased != NULLTAG) tReleased = NULLTAG;

							
							TERADYNE_TRACE_CALL(iStatus = RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleased), TD_LOG_ERROR_AND_THROW);
							if(tReleased != NULLTAG) 
							{
								
								TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, 1, &tObjects[j], true), TD_LOG_ERROR_AND_THROW);
								
							}
						}*/
					}
				}
				Custom_free(tObjects);
				Custom_free(pcObjectType);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}