#include <workflow/teradyne_handlers.h>


typedef map<string,string> MapSignOff;

struct SignOffComparator {
   bool operator()(MapSignOff signOffOne, MapSignOff signOffTwo){
      return (signOffOne.find("lastModifiedDate")->second > signOffTwo.find("lastModifiedDate")->second);
   }
};


/*******************************************************************************
 * Function Name			: teradyne_reassignNotification
 * Description				: This function will Assign Change the task state to suspended or resume based on action argument.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-action","-task"  in task and action argument is mandatory.
 *							 2. For the given task ,given action is performed.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_reassignNotification(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iCount              = 0,
		iSignoffAttCount	= 0;

	tag_t *tAttachtag       = {NULLTAG},
		  tMember = NULLTAG,
		  tUserTag=NULLTAG,
		  tResponsibleParty = NULLTAG;

	tag_t* tSignoffAttachments;
	tag_t *tAttaches			= NULL;

	
	string strMailFilePath = "",subject="";
	
	SIGNOFF_TYPE_t memberType;

	char *pcTypeName         = NULL,
		 *pcObjectType		= NULL, 
		*the_sender_email_addr = NULL;
		
	set<MapSignOff,SignOffComparator> setMapSignOff;	
	
	

	const char * __function__    = "teradyne_reassignNotification";
	TERADYNE_TRACE_ENTER();
	
	try {
		
		if(msg.task != NULLTAG && msg.action == EPM_assign_approver_action) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
			subject.assign(teradyneBuildNotificationSubject(msg));
             
              if(!setMapSignOff.empty()){
	              setMapSignOff.clear();
	          } 

			  if(!strMailFilePath.empty()){
				  strMailFilePath.clear();
			  }
             
             if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMPerformSignoffTask") == 0))) { //checks if task is sign off task
				TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(msg.task, EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW); //gets attachments(sign off list) of the task
				
				string	szCurTimeStamp;
				date_t	curDateTime;
					 
			    TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW); // get current system date
				strMailFilePath.append(TD_TEMP_PATH).append("REASSIGN_NOTIFICATION").append(szCurTimeStamp).append(".htm");
				
				for (int i = 0; i < iSignoffAttCount; i++) { //iterate through each member of the sign off list
					 date_t  	signOffLastModDate;
					 char *pcSignOffLastModDateWithHMS=NULL;
					 AOM_ask_value_date	(tSignoffAttachments[i],"last_mod_date",&signOffLastModDate); //get last modified date for signOff attachment
					 TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( signOffLastModDate, TD_DATE_YMD_CONSTANT, &pcSignOffLastModDateWithHMS),TD_LOG_ERROR_AND_THROW);
					 
					 TERADYNE_TRACE_CALL(iStatus = EPM_ask_signoff_member(tSignoffAttachments[i], &tMember, &memberType), TD_LOG_ERROR_AND_THROW); //gets the member tag of people in the sign off list
					 TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_user(tMember, &tUserTag), TD_LOG_ERROR_AND_THROW); //gets the user id
					
					
					  if(tUserTag != NULLTAG) {
						  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW); //gets the email address
						  MapSignOff mapSignOff;
						  mapSignOff["lastModifiedDate"]=pcSignOffLastModDateWithHMS;
						  mapSignOff["emailAddress"]=string(the_sender_email_addr);
						  setMapSignOff.insert(mapSignOff);
					   }
					  
				    
				    Custom_free(pcSignOffLastModDateWithHMS);
				   
				    
				 }
				 
				 if(!setMapSignOff.empty()){
					 MapSignOff lastModifiedSignOff =*setMapSignOff.begin();
	                 string emailToAddress = lastModifiedSignOff.find("emailAddress")->second;
	                    if (!emailToAddress.empty()) {
	                         string htmlBodyContent=teradyneBuildNotificationBodyContent(msg);
							 TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW); //required for teradyne_send_os_mail
							 TERADYNE_TRACE_CALL(iStatus=teradyne_send_os_mail(subject,strMailFilePath,emailToAddress),TD_LOG_ERROR_AND_THROW); //sends the email
					    }
						Custom_free(the_sender_email_addr);
	                    DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
	             } 
				    
			}
		} else if (msg.task != NULLTAG && msg.action == EPM_assign_action) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMDoTask") == 0))) { //checks if task is do task
				string htmlBodyContent=teradyneBuildNotificationBodyContent(msg);
				TERADYNE_TRACE_CALL(iStatus = EPM_ask_responsible_party(msg.task, &tResponsibleParty), TD_LOG_ERROR_AND_THROW); //gets the user id
				TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath,htmlBodyContent), TD_LOG_ERROR_AND_THROW);  //required for teradyne_send_os_mail
				if(tResponsibleParty != NULLTAG) {
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tResponsibleParty, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW); //gets the email address
					if (tc_strlen(the_sender_email_addr) > 0 && the_sender_email_addr != NULL) {
						
						TERADYNE_TRACE_CALL(iStatus=teradyne_send_os_mail(teradyneBuildNotificationSubject(msg),strMailFilePath,the_sender_email_addr),TD_LOG_ERROR_AND_THROW); //sends the email
					}
					Custom_free(the_sender_email_addr);
				}
				DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
			}
		}
	} catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}


 