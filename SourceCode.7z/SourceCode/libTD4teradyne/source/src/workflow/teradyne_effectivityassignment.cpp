/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_effectivityassignment.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-EffectivityAssignment action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  24-Mar-2015                       Haripriya                    	    Initial Creation
#  30-Mar-2015						 Vijayasekhar						Modified the function call teradyne_current_timestamp
#  15-Apr-2015						 Haripriya						    Modified the function to only update the StandardEcnRevision,if the part is Assembly.
#  24-Apr-2015						 Haripriya						    Modified the function teradyne_set_effectivity.
#  27-Apr-2015						 Haripriya						    Removed the extra space while tokenising string.
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  28-May-2015                       Haripriya                    	    Modified the function  to set effectivity for the Divparts
#  10-Jun-2015                       Selvi                    	        Modified teradyne_set_effectivity function  to overcome instance locked error
#  07-Jul-2015                       Haripriya                          Moved teradyne_find_prev_revision function to common.cpp.
#  10-Jul-2015                       Haripriya                    	    Modified teradyne_effectivityassignment in getting planner value
#  10-Aug-2015                       Haripriya                    	    Modified teradyne_set_effectivity function to perform refresh operstion after checking the object is modifiable
#  26-Aug-2015                       Haripriya                    	    Modified teradyne_set_effectivity function to lock and unlock the effectivity
#  15-Oct-2015                       Manimaran                          Added argument to the teradyne_set_effectivity function.
#  02-Sep-2016                       Manimaran                          Commented the BVR check to fix BT1800 warning message issue.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_effectivityassignment
 * Description				: This function will Assign Effectivity for the Components.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Searches the DivpartRevision in Solution Items Folder
 *							  2. If DivpartRevision is Found ,checks whether the part is Assembly or Component.
 *                            3. If the part is Assembly,Sets the td4PrimaryProjectPlanner property in ECNRevision.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_effectivityassignment(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iRefCount           = 0,
		iBomCount           = 0;

	tag_t *tAttachtag       = {NULLTAG},
	      *tRefListTag      = {NULLTAG},
		  *tBomViewRevs     = {NULLTAG};

	char *pcAttachType      = NULL;

	 vector<string> TechreviewerValues;
	std::map<string,string> strPropNameValueMap;

	const char * __function__    = "teradyne_effectivityassignment" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE))
				{
					//Getting Parts from Solution Item Folder
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachtag[i], TD_SOLUTION_ITEMS_REL_NAME, &iRefCount, &tRefListTag), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iRefCount; j++)
					{
						//checking the part is Assembly or Component
						TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tRefListTag[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW); 

						//if(iBomCount > 0)
						//{
							//Getting the project value
							//TERADYNE_TRACE_CALL(iStatus = teradyne_get_planner_value_from_primary_project(tAttachtag[i],TechreviewerValues),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(tAttachtag[i],strPropNameValueMap,TD_PLANNER_ATTR),TD_LOG_ERROR_AND_THROW);
							string szassigneevalue=strPropNameValueMap.find(TD_PLANNER_ATTR)->second;
							TechreviewerValues.push_back(szassigneevalue);
							char **pcTechreviewerarray   = NULL;

							//Converting vector to char** array and Setting Value on ECN Revision
							TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( TechreviewerValues,&pcTechreviewerarray),TD_LOG_ERROR_AND_THROW);

							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_PRIMARY_PROJ_PLANNER_ATTR,(int)TechreviewerValues.size(),pcTechreviewerarray),TD_LOG_ERROR_AND_THROW);
							POM_AM__set_application_bypass(false);
							Custom_free(pcTechreviewerarray);
							break;
						//}
					}
				}
				Custom_free(pcAttachType);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttachtag);
	Custom_free(tRefListTag);
	Custom_free(tBomViewRevs);
	TechreviewerValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_release_status_tag
 * Description				: Gets the Release Status Tag for the given Object Tag
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObjTag   (I)	     - tag_t 
 *							  tRelStatusTag  (O) - tag_t
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_release_status_tag( tag_t tObjTag,tag_t *tRelStatusTag)
{
	int iStatus					= ITK_ok,
		iRelCnt                 = 0;

	char *pcRelStatusType       = NULL;

	tag_t *tstatusTag           = {NULLTAG};

	const char * __function__ = "teradyne_get_release_status_tag";
	TERADYNE_TRACE_ENTER();

	try 
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tObjTag,&iRelCnt,&tstatusTag),TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iRelCnt; i++) 
		{
			TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tstatusTag[i], &pcRelStatusType) ,TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcRelStatusType, TD_REL_STATUS_NAME) == 0) 
			{
				*tRelStatusTag = tstatusTag[i];
			}
		}		
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(pcRelStatusType);
	Custom_free(tstatusTag);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_set_effectivity
 * Description				: Sets the Effectivity for the given status tag.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRelStatusTag   (I) - tag_t
 *							  szEffdaterange  (I) - string
 *                            szEffdate (I)       - string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_set_effectivity( tag_t tItemRevtag, tag_t tRelStatusTag,string szEffdaterange,string szEffdate, bool bToBeProtected)
{
	int iStatus					= ITK_ok,
		ieffectivities			= 0;

	tag_t tEffectivity          = NULLTAG,
		  tItemtag              = NULLTAG,
		  *tEffectivitiestag	= NULL, 
		  tRelStatus			= NULLTAG;

	string szCurTimeStamp      = "",
		   szEffrange          = "";

	bool bitemMod              = true,
		 bitemRevMod           = true,
		 bRelMod               = true,
		 bIsProtected		   = false;
	date_t curDate;

	const char * __function__ = "teradyne_set_effectivity";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if((szEffdaterange.length() > 0) && (szEffdate.length() > 0))
		{	
			
			szEffrange.append(szEffdaterange).append(" to ").append(szEffdate);
		}
		else if((szEffdaterange.length() > 0) && (szEffdate.length() == 0))
		{
			szEffrange.append(szEffdaterange);
		}
		else if ((szEffdaterange.length() == 0)  && (szEffdate.length() == 0))
		{	
			TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%d-%b-%Y %H:%M", szCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
			szEffrange.append(szCurTimeStamp).append(" to ").append("UP");
		}
		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tItemRevtag,&tItemtag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tItemtag,&bitemMod),TD_LOG_ERROR_AND_THROW);
		if(!bitemMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tItemtag ,true) ,TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tItemRevtag,&bitemRevMod),TD_LOG_ERROR_AND_THROW);
		if(!bitemRevMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tItemRevtag ,true) ,TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tRelStatusTag,&bRelMod),TD_LOG_ERROR_AND_THROW);
		if(!bRelMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRelStatusTag,true), TD_LOG_ERROR_AND_THROW);
		}
		//Unlocks the effectivity
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_effectivities(tItemRevtag, &ieffectivities, &tEffectivitiestag, &tRelStatus), TD_LOG_ERROR_AND_THROW);
		for (int i=0;i<ieffectivities;i++)
		{
			bool bIsprevProtected = false;
			TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_is_protected(tRelStatus,tEffectivitiestag[i], &bIsprevProtected), TD_LOG_ERROR_AND_THROW);
			if(bIsprevProtected)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_eff_set_protection(tRelStatus,tEffectivitiestag[i], false), TD_LOG_ERROR_AND_THROW);
			}
		}
		TERADYNE_TRACE_CALL(iStatus = WSOM_status_clear_effectivities(tRelStatusTag) ,TD_LOG_ERROR_AND_THROW);	
		TERADYNE_TRACE_CALL(iStatus = WSOM_effectivity_create(tRelStatusTag,NULLTAG, &tEffectivity) ,TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = WSOM_eff_set_date_range(tRelStatusTag,tEffectivity,szEffrange.c_str(),FALSE), TD_LOG_ERROR_AND_THROW);
		//Locks the effectivity

		if (bToBeProtected) {
			TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_is_protected(tRelStatusTag,tEffectivity, &bIsProtected), TD_LOG_ERROR_AND_THROW);
			if(!bIsProtected)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_eff_set_protection(tRelStatusTag,tEffectivity, true), TD_LOG_ERROR_AND_THROW);
			}
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tRelStatusTag), TD_LOG_ERROR_AND_THROW);
		if(!bitemMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tItemtag,false), TD_LOG_ERROR_AND_THROW);
		}
		if(!bitemRevMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tItemRevtag,false), TD_LOG_ERROR_AND_THROW);
		}
		if(!bRelMod)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRelStatusTag,false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);
			
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
