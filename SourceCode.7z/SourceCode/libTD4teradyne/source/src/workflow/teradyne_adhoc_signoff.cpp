/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_adhoc_signoff.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AdhocSignoff handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  08-May-2015                       Haripriya                    	    Initial Creation
#  05-June-2015                      Haripriya                    	    Added type check
#  26-June-2015                      Haripriya                    	    Removed Duplicate Reviewers found Error
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_adhoc_signoff
 * Description				: This function will Assign Unique Signoff members to Review Task.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-assignee"  and  argument is mandatory.
 *							 2. For the given task ,users are assigned from the given participants.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_adhoc_signoff(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iMemcnt             = 0,
        iSignoffcnt         = 0,
		iResCnt             = 0,
		iusercnt            = 0;

	tag_t *tAttachtag       = {NULLTAG},
		  *tMemtag          = {NULLTAG},
		  *tRestag          = {NULLTAG},
		  *tsignofftag      = {NULLTAG},
		  *tusertag         = {NULLTAG};

   char *pcassignee         = NULL;
	 
   bool bSingleparticipant  = false;

   	 vector<string> ParticipantValues;
	std::map<int,int> strUserMemberValueMap;

	const char * __function__    = "teradyne_adhoc_signoff" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		//read the handler arguments
		teradyne_get_handler_opts(msg.arguments,
		"-assignee", &pcassignee,
		NULL);

		if(pcassignee != NULL) 
		{	
		
			char *pch = strtok (pcassignee,",");
			while (pch != NULL)
			{
				ParticipantValues.push_back(pch);
				pch = strtok (NULL, ",");
			}
			//Getting target attachments
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				char *pcTypeName = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				if( (tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_DEVIATION_NOTICE_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName,TD_PROTOPART_ECN_REV_TYPE)==0) || (tc_strcmp(pcTypeName, TD_SUPPLIER_ADD_REQ_REV) == 0))
				{
					for(int j = 0; j < ParticipantValues.size(); j++) 
					{
						//For the given participants member tag is obtained
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participants(ParticipantValues.at(j).c_str(),msg.task,&iMemcnt,&tMemtag,&iResCnt,&tRestag,bSingleparticipant), TD_LOG_ERROR_AND_THROW);
						for(int k= 0; k < iMemcnt; k++) 
						{
							tag_t   tusertag         = NULLTAG;
							//Getting user tag from the member tag
							TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_user (tMemtag[k],&tusertag), TD_LOG_ERROR_AND_THROW);
							strUserMemberValueMap.insert(::make_pair(tusertag,tMemtag[k]));
						}
						Custom_free(tMemtag);
						Custom_free(tRestag);
					}

						TERADYNE_TRACE_CALL(iStatus = EPM_ask_reviewers (msg.task,&iusercnt,&tusertag), TD_LOG_ERROR_AND_THROW);
						for(int l= 0; l < iusercnt; l++) 
						{
							tag_t tusertags          = NULLTAG;
							//Getting user tag from the member tag
							TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_user (tusertag[l],&tusertags), TD_LOG_ERROR_AND_THROW);
							std::map<int,int>::iterator it;
							it=strUserMemberValueMap.find(tusertags);
							if(it != strUserMemberValueMap.end())
							{
								 strUserMemberValueMap.erase(it);
							}
						}
					std::map<int,int>::iterator it;
					for(it=strUserMemberValueMap.begin();it!=strUserMemberValueMap.end();it++)
					{
						//Assigning Signoffs for the given task
						TERADYNE_TRACE_CALL(iStatus = EPM_create_adhoc_signoff(msg.task,it->second,&iSignoffcnt,&tsignofftag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_set_adhoc_signoff_selection_done(msg.task,"true"), TD_LOG_ERROR_AND_THROW);
						Custom_free(tsignofftag);
					}
				}
				Custom_free(pcTypeName);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttachtag);
	ParticipantValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}