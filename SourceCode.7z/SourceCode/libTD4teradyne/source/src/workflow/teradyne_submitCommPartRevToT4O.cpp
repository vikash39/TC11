/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_set_releasestatus_ECN.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SubmitCommPartRevToT4O action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_submitToT4O
 * Description				: 
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_submitCommPartRevToT4O(EPM_action_message_t msg) 
{

	int iStatus					= ITK_ok,
		iReferences             = 0,
		iCount					= 0;

	tag_t tNewProcess           = NULLTAG;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tObjects				= NULL;
	
	char *pcAttachType			= NULL;
	char *pcProcessTemplateName = NULL;
	bool bIsConceptPart			= false;  

	const char * __function__ = "teradyne_submitCommPartRevToT4O";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{ 
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_COMM_PART_REQ_REV)) 
				{
				    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_IS_CONCEPT_PART, &bIsConceptPart), TD_LOG_ERROR_AND_THROW);  
					Custom_free(pcAttachType);
                    break;
				}
                 Custom_free(tObjects);
			}

				  
				  
			   TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iReferences, &tReferences), TD_LOG_ERROR_AND_THROW);
		    
			   for(int i=0;i < iReferences;i++)
			   {

			      TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReferences[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				  if(!tc_strcmp(pcAttachType, TD_COMM_PART) || !tc_strcmp(pcAttachType, TD_COMM_PART_REV) ) 
				  {

				    //Getting Preference Value to get Workflow template name
					tag_t 	tItemRevTag = NULLTAG;
                   
					if(!tc_strcmp(pcAttachType, TD_COMM_PART_REV)){
					    tItemRevTag = tReferences[i];
					}else{
                    TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev (tReferences[i],&tItemRevTag),TD_LOG_ERROR_AND_THROW); 
				    }
				    
					AM__set_application_bypass(true);
                    TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tItemRevTag,TD_ITEM_STATUS_ATTR,TD_PRODUCTION_TYPE_ATTR),TD_LOG_ERROR_AND_THROW);  
			        AM__set_application_bypass(false);
					
					if(bIsConceptPart){
					    TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_UPDATED_EVENT,tItemRevTag,false),TD_LOG_ERROR_AND_THROW);
					
					}else{
						TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_UPDATED_EVENT,tItemRevTag,true),TD_LOG_ERROR_AND_THROW); 
					}


					Custom_free(pcAttachType);
                    break;
				}
			   
			   }
			


		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}