/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_set_releasestatus_ECN.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-SubmitCommPartRevToT4O action handler
#      Project         :           libTD4teradyne
#      Author          :
#  =================================================================================================
#  Date                              Name                               Description of Change
#
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


static size_t WriteCallback(char *contents, size_t size, size_t nmemb, void *userp)
{
	((std::string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}

std::string utf8_from_iso8859_1(std::string str)
{
	std::string res;
	for (std::string::iterator i = str.begin(); i < str.end(); i++) {
		if (0 <= *i && *i < 0x80)
			res += *i;
		else {
			res += 0xC0 | ((*i >> 6) & 0x03);
			res += 0x80 | (*i & 0x3F);
		}
	}
	return res;
}

int postEvent(const char *eventType, const char *es_url, string eventMetadataString, string eventDataString)
{
	GUID uuid;
	::ZeroMemory(&uuid, sizeof(UUID));

	int iStatus = ITK_ok;

	RPC_STATUS ret_val = ::UuidCreate(&uuid);
	if (ret_val == RPC_S_OK)
	{
		curl_global_init(CURL_GLOBAL_ALL);

		CURL *curl = curl_easy_init();
		if (curl)
		{
			curl_easy_setopt(curl, CURLOPT_URL, es_url);

			struct curl_slist *headers = NULL;
			headers = curl_slist_append(headers, "Content-Type: application/vnd.eventstore.events+json; charset=UTF-8");

			CURLcode curlRes = curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

			//curl_easy_setopt(curl, CURLOPT_USERPWD, "admin:changeit");

			string eventString = "[{";

			std::string eventIdString = "\"eventId\": ";
			char *uuidString;
			UuidToStringA(&uuid, (RPC_CSTR*)&uuidString);
			eventIdString.append("\"").append(uuidString).append("\"").append(",");
			RpcStringFreeA((RPC_CSTR*)&uuidString);

			std::string eventTypeString = "\"eventType\": ";
			eventTypeString.append("\"").append(eventType).append("\"").append(",");

			eventString.append(eventIdString);
			eventString.append(eventTypeString);
			eventString.append(eventMetadataString);
			eventString.append(",");
			eventString.append(eventDataString);
			eventString.append("}]");

			string encodedstring = utf8_from_iso8859_1(eventString);

			curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE_LARGE, (long)strlen(encodedstring.c_str()));
			curl_easy_setopt(curl, CURLOPT_POSTFIELDS, encodedstring.c_str());
			//curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

			std::string httpResponse;
			curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
			curl_easy_setopt(curl, CURLOPT_WRITEDATA, &httpResponse);

			curlRes = curl_easy_perform(curl);

			if (curlRes != CURLE_OK)
			{
				fprintf(stderr, "curl_easy_perform() sfailed: %s\n",
					curl_easy_strerror(curlRes));
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}

			curl_easy_cleanup(curl);
		}
		else
		{
			printf("CURL error, something went wrong and curl cannot be used.");
			iStatus = 1;
		}
		curl_global_cleanup();
	}
	else {
		printf("CURL error, something went wrong and curl cannot be used.");
		iStatus = 1;
	}
	return iStatus;
}

std::string escape_json(const std::string &s) {
	std::ostringstream o;
	for (auto c = s.cbegin(); c != s.cend(); c++) {
		switch (*c) {
		case '"': o << "\\\""; break;
		case '\\': o << "\\\\"; break;
		case '\b': o << "\\b"; break;
		case '\f': o << "\\f"; break;
		case '\n': o << "\\n"; break;
		case '\r': o << "\\r"; break;
		case '\t': o << "\\t"; break;
		default:
			if ('\x00' <= *c && *c <= '\x1f') {
				o << "\\u"
					<< std::hex << std::setw(4) << std::setfill('0') << (int)*c;
			}
			else {
				o << *c;
			}
		}
	}
	return o.str();
}

int teradyne_part_avl(tag_t tPartRev, string* avls)
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_part_avl";
	TERADYNE_TRACE_ENTER();
	try
	{

		int		iVendorParts = 0;
		tag_t  *tVendorParts = NULL,
			tRelationTypeTag = NULLTAG,
			tRelationTag = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME, &tRelationTypeTag), TD_LOG_ERROR_AND_THROW);
		if (tRelationTypeTag != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPartRev, tRelationTypeTag, &iVendorParts, &tVendorParts), TD_LOG_ERROR_AND_THROW);
		}

		char  *pcVendorId = NULL,
			*pcVendorName = NULL,
			*pcVendorPartNum = NULL,
			*pcPrefStatus = NULL;
		for (int m = 0; m < iVendorParts; m++)
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPartRev, tVendorParts[m], tRelationTypeTag, &tRelationTag), TD_LOG_ERROR_AND_THROW);

			if (tRelationTag != NULLTAG)
			{
				tag_t tVendorFound = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tVendorParts[m], TD_VENDOR_PART_REL_NAME, TD_VENDOR, 0, &tVendorFound), TD_LOG_ERROR_AND_THROW);
				if (tVendorFound != NULLTAG)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorParts[m], "vendor_id", &pcVendorId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorParts[m], "vendor_name", &pcVendorName), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorParts[m], "vendor_part_num", &pcVendorPartNum), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRelationTag, TD_PREFERRED_STATUS_ATTR, &pcPrefStatus), TD_LOG_ERROR_AND_THROW);
					string strVendorId(pcVendorId), strVendorName(pcVendorName), strVendorPartNum(pcVendorPartNum), strPrefStatus(pcPrefStatus);

					avls->append("{");
					avls->append("\"vendor-id\":").append("\"").append(strVendorId).append("\"").append(",");
					avls->append("\"vendor-name\":").append("\"").append(escape_json(strVendorName)).append("\"").append(",");
					avls->append("\"vendor-part-number\":").append("\"").append(escape_json(pcVendorPartNum)).append("\"").append(",");
					avls->append("\"preferred-status\":").append("\"").append(strPrefStatus).append("\"");
					avls->append("}");

					if (m < iVendorParts - 1)
					{
						avls->append(",");
					}

				}
			}
		}

		Custom_free(pcVendorId);
		Custom_free(pcVendorName);
		Custom_free(pcVendorPartNum);
		Custom_free(pcPrefStatus);
		Custom_free(tVendorParts);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_part_bom(tag_t tPartRev, string* bom)
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_part_bom";
	TERADYNE_TRACE_ENTER();
	try
	{
		int bvrCount = 0;
		tag_t tPart = NULLTAG, *bvrTags = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tPartRev, &bvrCount, &bvrTags), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tPartRev, &tPart), TD_LOG_ERROR_AND_THROW);

		if (bvrCount > 0)
		{
			for (int jj = 0; jj < bvrCount; jj++)
			{
				tag_t tWindow = NULLTAG, tLine = NULLTAG, *tChildLines = NULL;
				int childCount = 0;

				TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow, tPart, tPartRev, NULLTAG, &tLine), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tLine, &childCount, &tChildLines), TD_LOG_ERROR_AND_THROW);

				for (int cc = 0; cc < childCount; cc++)
				{
					tag_t lineObjRev = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tChildLines[cc], "bl_line_object", &lineObjRev), TD_LOG_ERROR_AND_THROW);

					char *pcObjectType = NULL;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(lineObjRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

					string szAppliesToESI, szItemRev, szDesc, szPartType, szItemStatus, szCBU, szProjectName, szDateCreated, szDateModified, szHTS, szECCN;

					if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0)
					{
						string szObjAttr[] = { TD_ITEM_REV_ID_ATTR, TD_STANDARD_DESC_ATTR,TD_PART_TYPE_ATTR, TD_ITEM_STATUS_ATTR,
						TD_CONTRL_BUSS_UNIT,TD_PROJECT_NAME_ATTR, TD_CREATION_DATE, TD_MODIFIED_DATE, TD_HTS_ATTR};
						std::list<std::string> strAttr(szObjAttr, szObjAttr + sizeof(szObjAttr) / sizeof(string));

						map<string, string> strPropNameValueMap;

						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(lineObjRev, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
						if (strPropNameValueMap.size() > 0)
						{
							szAppliesToESI = "";
							szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
							szDesc = strPropNameValueMap.find(TD_STANDARD_DESC_ATTR)->second;
							szDesc = escape_json(szDesc);

							szPartType = strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second;
							szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
							szCBU = strPropNameValueMap.find(TD_CONTRL_BUSS_UNIT)->second;

							szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second;
							szDateCreated = strPropNameValueMap.find(TD_CREATION_DATE)->second;
							szDateModified = strPropNameValueMap.find(TD_MODIFIED_DATE)->second;

							szHTS = strPropNameValueMap.find(TD_HTS_ATTR)->second;
							szECCN = strPropNameValueMap.find(TD_ECCN_ATTR)->second;

						}

					}
					else if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
					{
						string szObjAttr[] = { TD_APPLIES_ESI_ATTR, TD_ITEM_REV_ID_ATTR, TD_DESC_ATTR,TD_PART_TYPE_ATTR, TD_ITEM_STATUS_ATTR,
						TD_CONTRL_BUSS_UNIT,TD_PROJECT_NAME_ATTR, TD_CREATION_DATE, TD_MODIFIED_DATE, TD_HTS_ATTR, TD_ECCN_ATTR};
						std::list<std::string> strAttr(szObjAttr, szObjAttr + sizeof(szObjAttr) / sizeof(string));

						map<string, string> strPropNameValueMap;

						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(lineObjRev, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
						if (strPropNameValueMap.size() > 0)
						{
							szAppliesToESI = strPropNameValueMap.find(TD_APPLIES_ESI_ATTR)->second;
							szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
							szDesc = strPropNameValueMap.find(TD_DESC_ATTR)->second;
							szDesc = escape_json(szDesc);

							szPartType = strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second;
							szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
							szCBU = strPropNameValueMap.find(TD_CONTRL_BUSS_UNIT)->second;

							szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second;
							szDateCreated = strPropNameValueMap.find(TD_CREATION_DATE)->second;
							szDateModified = strPropNameValueMap.find(TD_MODIFIED_DATE)->second;

							szHTS = strPropNameValueMap.find(TD_HTS_ATTR)->second;
							szECCN = strPropNameValueMap.find(TD_ECCN_ATTR)->second;

						}
					}

					char *childItemId = "";
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildLines[cc], "bl_item_item_id", &childItemId), TD_LOG_ERROR_AND_THROW);
					char *childQty = "";
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildLines[cc], "bl_quantity", &childQty), TD_LOG_ERROR_AND_THROW);
					char *findNum = "";
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildLines[cc], "bl_sequence_no", &findNum), TD_LOG_ERROR_AND_THROW);
					char *skipFindNumFlag = "";
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildLines[cc], "bl_occ_td4SkipFindNumber", &skipFindNumFlag), TD_LOG_ERROR_AND_THROW);
					char *td4Remarks = "";
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChildLines[cc], "TD4Remarks", &td4Remarks), TD_LOG_ERROR_AND_THROW);

					char **pcUnitOfMeasure = NULL;
					int numValues = 0;
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_displayable_values(tChildLines[cc], "bl_uom", &numValues, &pcUnitOfMeasure), TD_LOG_ERROR_AND_THROW);

					string strChildUom;
					if (numValues == 1)
					{
						strChildUom.append(pcUnitOfMeasure[0]);
					}
					else
					{
						strChildUom.append("");
					}

					string strChildItemId(childItemId), strChildQty(childQty), strFindNum(findNum), strFindNumFlag(skipFindNumFlag), strRemark(td4Remarks);
					strRemark = escape_json(strRemark);
					bom->append("{");
					bom->append("\"applies-to-esi\":").append("\"").append(szAppliesToESI).append("\"").append(",");
					bom->append("\"part-number\":").append("\"").append(strChildItemId).append("\"").append(",");
					bom->append("\"part-revision\":").append("\"").append(szItemRev).append("\"").append(",");
					bom->append("\"description\":").append("\"").append(szDesc).append("\"").append(",");
					bom->append("\"project-name\":").append("\"").append(szProjectName).append("\"").append(",");
					bom->append("\"quantity\":").append("\"").append(strChildQty).append("\"").append(",");
					bom->append("\"find-number\":").append("\"").append(strFindNum).append("\"").append(",");
					bom->append("\"skip-find-number-flag\":").append("\"").append(strFindNumFlag).append("\"").append(",");
					bom->append("\"remark\":").append("\"").append(strRemark).append("\"").append(",");
					bom->append("\"unit-of-measure\":").append("\"").append(strChildUom).append("\"").append(",");
					bom->append("\"item-status\":").append("\"").append(szItemStatus).append("\"").append(",");
					bom->append("\"eccn\":").append("\"").append(szECCN).append("\"").append(",");
					bom->append("\"hts\":").append("\"").append(szHTS).append("\"").append(",");
					string avls = "";
					TERADYNE_TRACE_CALL(iStatus = teradyne_part_avl(lineObjRev, &avls), TD_LOG_ERROR_AND_THROW);
					bom->append("\"avl\":").append("[").append(avls).append("]");
					bom->append("}");

					if (cc < childCount - 1)
					{
						bom->append(",");
					}
					Custom_free(childItemId);
					Custom_free(childQty);
					Custom_free(findNum);
				}

				TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow), TD_LOG_ERROR_AND_THROW);
			}

		}

		Custom_free(bvrTags);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


int teradyne_bom_changes(tag_t tPartRev, string* bom_changes)
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_bom_changes";
	TERADYNE_TRACE_ENTER();
	try
	{
		vector<string> resBLDiffValue;

		tag_t tPrevRev = NULLTAG;
		TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tPartRev, &tPrevRev), TD_LOG_ERROR_AND_THROW);
		if (tPrevRev != NULLTAG)
		{
			iStatus = teradyne_list_bvr_diffs(tPrevRev, tPartRev, resBLDiffValue);
			if (iStatus == 0)
			{
				if (resBLDiffValue.size() > 0)
				{
					int iTypesize = (int)resBLDiffValue.size();
					int bcSzie = iTypesize / 9;
					int iCompRes = 0, iPartNum = 1, iFindNum = 3, iQuantity = 4, iRemarks = 5;
					for (int row = 0; row < bcSzie; row++)
					{
						bom_changes->append("{");
						bom_changes->append("\"compare-result\":").append("\"").append(resBLDiffValue[iCompRes]).append("\"").append(",");
						bom_changes->append("\"part-number\":").append("\"").append(resBLDiffValue[iPartNum]).append("\"").append(",");
						bom_changes->append("\"find-number\":").append("\"").append(resBLDiffValue[iFindNum]).append("\"").append(",");
						bom_changes->append("\"quantity\":").append("\"").append(resBLDiffValue[iQuantity]).append("\"").append(",");
						bom_changes->append("\"remark\":").append("\"").append(resBLDiffValue[iRemarks]).append("\"").append(",");
						bom_changes->append("\"unit-of-measure\":").append("\"").append("").append("\"");

						bom_changes->append("}");
						iCompRes = iCompRes + 9;
						iPartNum = iPartNum + 9;
						iFindNum = iFindNum + 9;
						iQuantity = iQuantity + 9;
						iRemarks = iRemarks + 9;

						if (row < bcSzie - 1)
						{
							bom_changes->append(",");
						}
					}
				}
			}
			else
			{
				bom_changes->append("");
				iStatus = 0;
			}
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_get_ecn_prop(tag_t epmTask, char **pcItemId, char **pcSynopsis, char **pcChangeReason, char **pcECNRequestor)
{

	int	iStatus = ITK_ok,
		iCount = 0;
	tag_t tRelType = NULLTAG,
		tGroupMember = NULLTAG,
		tUser = NULLTAG,
		*tAttaches = NULL;

	char *pcTypeName = NULL;

	const char * __function__ = "teradyne_get_ecn_itemid";
	TERADYNE_TRACE_ENTER();

	try {

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ECR_SOLREL_NAME, &tRelType), TD_LOG_ERROR_AND_THROW);
		if (tRelType != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(epmTask, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);

			for (int j = 0; j < iCount; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[j], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0
					|| tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0 || tc_strcmp(pcTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tAttaches[j], pcItemId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[j], "td4Description", pcSynopsis), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[j], TD_REASON_ATTR, pcChangeReason), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tAttaches[j], "Requestor", &tGroupMember), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tGroupMember, "user", &tUser), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUser, pcECNRequestor), TD_LOG_ERROR_AND_THROW);
					break;
				}
				else if (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tAttaches[j], pcItemId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[j], "td4Description", pcSynopsis), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tAttaches[j], "Requestor", &tGroupMember), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tGroupMember, "user", &tUser), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUser, pcECNRequestor), TD_LOG_ERROR_AND_THROW);
					break;
				}
			}

		}

	}
	catch (...) {

		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tAttaches);
	Custom_free(pcTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_send_to_ESI(const char* eventType, tag_t epmTask, tag_t objTagRev)
{
	int iStatus = ITK_ok;

	char   *pcRelStatusType = NULL,
		*pcEcnItemId = NULL,
		*pcSynopsis = NULL,
		*pcChangeReason = NULL,
		*pcECNRequestor = NULL,
		*owningUser = NULL,
		*lastModUser = NULL,
		*pTaskUid = NULL,
		*pcRevId = NULL;

	tag_t	tOwningUser = NULLTAG,
		tLastModUser = NULLTAG;
	const char * __function__ = "teradyne_send_to_ESI";
	TERADYNE_TRACE_ENTER();

	try
	{

		ITK__convert_tag_to_uid(epmTask, &pTaskUid);

		char *pcObjectType = NULL;
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(objTagRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

		if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0)
		{

			string szObjAttr[] = { TD_ITEM_ID_ATTR, TD_ITEM_REV_ID_ATTR, TD_STANDARD_DESC_ATTR, TD_COMMODITY_LEVEL_1,TD_PART_TYPE_ATTR, TD_ITEM_STATUS_ATTR,
				TD_CONTRL_BUSS_UNIT,TD_PROJECT_NAME_ATTR, TD_CREATION_DATE, TD_MODIFIED_DATE, TD_HTS_ATTR, TD_ECCN_ATTR, TD_ECCN_ATTR,
				TD_COUNTRY_OF_ORIGIN,TD_COUNTRY_OF_ORIGIN_CODE,TD_MEU_ASSESSMENT_TAG };
			std::list<std::string> strAttr(szObjAttr, szObjAttr + sizeof(szObjAttr) / sizeof(string));

			string szUnitOfMeasure;
			tag_t objTag = NULLTAG;
			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(objTagRev, &objTag), TD_LOG_ERROR_AND_THROW);

			char **pcUnitOfMeasure = NULL;
			int numValues = 0;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_displayable_values(objTag, TD_UNIT_OF_MEASURE_TAG, &numValues, &pcUnitOfMeasure), TD_LOG_ERROR_AND_THROW);
			if (numValues == 1)
			{
				szUnitOfMeasure.append(pcUnitOfMeasure[0]);
			}
			else
			{
				szUnitOfMeasure.append("");
			}

			map<string, string> strPropNameValueMap;

			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(objTagRev, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
			if (strPropNameValueMap.size() > 0)
			{
				string szItemId = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;
				string szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
				string szDesc = strPropNameValueMap.find(TD_STANDARD_DESC_ATTR)->second;
				szDesc = escape_json(szDesc);
				string szCommLevel1 = strPropNameValueMap.find(TD_COMMODITY_LEVEL_1)->second;
				string szPartType = strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second;
				string szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
				string szCBU = strPropNameValueMap.find(TD_CONTRL_BUSS_UNIT)->second;

				string szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second;
				string szDateCreated = strPropNameValueMap.find(TD_CREATION_DATE)->second;
				string szDateModified = strPropNameValueMap.find(TD_MODIFIED_DATE)->second;

				string szEcnNumber = "";
				string szSynopsis = "";
				string szChangeReason = "";
				string szECNRequestor = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_ecn_prop(epmTask, &pcEcnItemId, &pcSynopsis, &pcChangeReason, &pcECNRequestor), TD_LOG_ERROR_AND_THROW);
				if (pcEcnItemId != NULL)
				{
					szEcnNumber = string(pcEcnItemId);
				}

				if (pcSynopsis != NULL)
				{
					szSynopsis = escape_json(string(pcSynopsis));
				}
				if (pcChangeReason != NULL)
				{
					szChangeReason = string(pcChangeReason);
				}
				if (pcECNRequestor != NULL)
				{
					szECNRequestor = string(pcECNRequestor);
				}

				string szHTS = strPropNameValueMap.find(TD_HTS_ATTR)->second;
				string szECCN = strPropNameValueMap.find(TD_ECCN_ATTR)->second;

				string szeCOO = strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN)->second;
				string szeCOOCode = strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN_CODE)->second;
				string szeMEUTAG = strPropNameValueMap.find(TD_MEU_ASSESSMENT_TAG)->second;

				tag_t  *tRelStatus = { NULLTAG };
				int	   iRelCnt = 0;

				string szRelStat = "";
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(objTagRev, &iRelCnt, &tRelStatus), TD_LOG_ERROR_AND_THROW);
				for (int i = 0; i < iRelCnt; i++)
				{
					TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tRelStatus[i], &pcRelStatusType), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcRelStatusType, TD_REL_STATUS_NAME) == 0)
					{
						szRelStat = "released";
						break;
					}
				}
				tag_t tPrevRev = NULLTAG;
				string szPrevItemRev = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(objTagRev, &tPrevRev), TD_LOG_ERROR_AND_THROW);
				if (tPrevRev != NULLTAG)
				{
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_rev_id2(tPrevRev, &pcRevId), TD_LOG_ERROR_AND_THROW);
					szPrevItemRev = string(pcRevId);
				}

				string pTaskUID = string(pTaskUid);
				string jsonData = "\"data\":{";
				jsonData.append("\"task-uid\":").append("\"").append(pTaskUID).append("\"").append(",");
				jsonData.append("\"release-status\":").append("\"").append(szRelStat).append("\"").append(",");
				jsonData.append("\"project-name\":").append("\"").append(szProjectName).append("\"").append(",");
				jsonData.append("\"controlling-business-unit\":").append("\"").append(szCBU).append("\"").append(",");
				jsonData.append("\"commodity-level\":").append("\"").append(szCommLevel1).append("\"").append(",");
				jsonData.append("\"part-type\":").append("\"").append("divisional-part").append("\"").append(",");
				jsonData.append("\"part-class\":").append("\"").append(szPartType).append("\"").append(",");
				jsonData.append("\"item-status\":").append("\"").append(szItemStatus).append("\"").append(",");
				jsonData.append("\"part-number\":").append("\"").append(szItemId).append("\"").append(",");
				jsonData.append("\"part-revision\":").append("\"").append(szItemRev).append("\"").append(",");
				jsonData.append("\"previous-part-revision\":").append("\"").append(szPrevItemRev).append("\"").append(",");
				jsonData.append("\"description\":").append("\"").append(szDesc).append("\"").append(",");
				jsonData.append("\"unit-of-measure\":").append("\"").append(szUnitOfMeasure).append("\"").append(",");
				jsonData.append("\"ecn-number\":").append("\"").append(szEcnNumber).append("\"").append(",");
				jsonData.append("\"ecn-synopsis\":").append("\"").append(szSynopsis).append("\"").append(",");
				jsonData.append("\"eff-date\":").append("\"").append("").append("\"").append(",");
				jsonData.append("\"ecn-reason\":").append("\"").append(szChangeReason).append("\"").append(",");
				jsonData.append("\"ecn-requestor\":").append("\"").append(szECNRequestor).append("\"").append(",");
				jsonData.append("\"eccn\":").append("\"").append(szECCN).append("\"").append(",");
				jsonData.append("\"hts\":").append("\"").append(szHTS).append("\"").append(",");

				jsonData.append("\"country-of-origin\":").append("\"").append(szeCOO).append("\"").append(",");
				jsonData.append("\"country-of-origin-code\":").append("\"").append(szeCOOCode).append("\"").append(",");
				jsonData.append("\"meu-assesment-tag\":").append("\"").append(szeMEUTAG).append("\"").append(",");
			
				string avls = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_part_avl(objTagRev, &avls), TD_LOG_ERROR_AND_THROW);
				jsonData.append("\"avl\":").append("[").append(avls).append("]").append(",");

				string bom = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_part_bom(objTagRev, &bom), TD_LOG_ERROR_AND_THROW);
				jsonData.append("\"bom\":").append("[").append(bom).append("]").append(",");


				string bom_changes = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_bom_changes(objTagRev, &bom_changes), TD_LOG_ERROR_AND_THROW);
				jsonData.append("\"bom-changes\":").append("[").append(bom_changes).append("]");

				jsonData.append("}");

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(objTagRev, "owning_user", &tOwningUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tOwningUser, &owningUser), TD_LOG_ERROR_AND_THROW);
				string szOwningUser = string(owningUser);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(objTagRev, "last_mod_user", &tLastModUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tLastModUser, &lastModUser), TD_LOG_ERROR_AND_THROW);
				string szLastModUser = string(lastModUser);

				string jsonMetadata = "\"metadata\":{";
				jsonMetadata.append("\"date-created\":").append("\"").append(szDateCreated).append("\"").append(",");
				jsonMetadata.append("\"date-modified\":").append("\"").append(szDateModified).append("\"").append(",");
				jsonMetadata.append("\"owning-user\":").append("\"").append(szOwningUser).append("\"").append(",");
				jsonMetadata.append("\"last-mod-user\":").append("\"").append(szLastModUser).append("\"");
				jsonMetadata.append("}");

				char *es_url = NULL;
				//Getting Preference Value to get Workflow template name
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_ES_URL_PREF, TC_preference_site, 0, &es_url), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = postEvent(eventType, es_url, jsonMetadata, jsonData), TD_LOG_ERROR_AND_THROW);

			}
			Custom_free(pcUnitOfMeasure);
		}
		else if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
		{
			string szObjAttr[] = { TD_ITEM_ID_ATTR, TD_ITEM_REV_ID_ATTR, TD_DESCR_ATTR, TD_COMMODITY_LEVEL_1,TD_PART_TYPE_ATTR, TD_ITEM_STATUS_ATTR,
			TD_CONTRL_BUSS_UNIT,TD_PROJECT_NAME_ATTR, TD_CREATION_DATE, TD_MODIFIED_DATE, TD_HTS_ATTR, TD_ECCN_ATTR,
			TD_COUNTRY_OF_ORIGIN,TD_COUNTRY_OF_ORIGIN_CODE,TD_MEU_ASSESSMENT_TAG };
			std::list<std::string> strAttr(szObjAttr, szObjAttr + sizeof(szObjAttr) / sizeof(string));

			string szUnitOfMeasure;
			tag_t objTag = NULLTAG;
			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(objTagRev, &objTag), TD_LOG_ERROR_AND_THROW);

			char **pcUnitOfMeasure = NULL;
			int numValues = 0;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_displayable_values(objTag, TD_UNIT_OF_MEASURE_TAG, &numValues, &pcUnitOfMeasure), TD_LOG_ERROR_AND_THROW);
			if (numValues == 1)
			{
				szUnitOfMeasure.append(pcUnitOfMeasure[0]);
			}
			else
			{
				szUnitOfMeasure.append("");
			}

			map<string, string> strPropNameValueMap;

			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(objTagRev, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
			if (strPropNameValueMap.size() > 0)
			{
				string szItemId = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;
				string szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
				string szDesc = strPropNameValueMap.find(TD_DESCR_ATTR)->second;
				szDesc = escape_json(szDesc);
				string szCommLevel1 = strPropNameValueMap.find(TD_COMMODITY_LEVEL_1)->second;
				string szPartType = strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second;
				string szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
				string szCBU = strPropNameValueMap.find(TD_CONTRL_BUSS_UNIT)->second;

				string szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second;
				string szDateCreated = strPropNameValueMap.find(TD_CREATION_DATE)->second;
				string szDateModified = strPropNameValueMap.find(TD_MODIFIED_DATE)->second;
				string szHTS = strPropNameValueMap.find(TD_HTS_ATTR)->second;
				string szECCN = strPropNameValueMap.find(TD_ECCN_ATTR)->second;

				string szeCOO = strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN)->second;
				string szeCOOCode = strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN_CODE)->second;
				string szeMEUTAG = strPropNameValueMap.find(TD_MEU_ASSESSMENT_TAG)->second;

				string pTaskUID = string(pTaskUid);
				string jsonData = "\"data\":{";
				jsonData.append("\"task-uid\":").append("\"").append(pTaskUID).append("\"").append(",");
				jsonData.append("\"project-name\":").append("\"").append(szProjectName).append("\"").append(",");
				jsonData.append("\"controlling-business-unit\":").append("\"").append(szCBU).append("\"").append(",");
				jsonData.append("\"commodity-level\":").append("\"").append(szCommLevel1).append("\"").append(",");
				jsonData.append("\"part-type\":").append("\"").append("commercial-part").append("\"").append(",");
				jsonData.append("\"part-class\":").append("\"").append(szPartType).append("\"").append(",");
				jsonData.append("\"item-status\":").append("\"").append(szItemStatus).append("\"").append(",");
				jsonData.append("\"part-number\":").append("\"").append(szItemId).append("\"").append(",");
				jsonData.append("\"part-revision\":").append("\"").append(szItemRev).append("\"").append(",");
				jsonData.append("\"description\":").append("\"").append(szDesc).append("\"").append(",");
				jsonData.append("\"unit-of-measure\":").append("\"").append(szUnitOfMeasure).append("\"").append(",");
				jsonData.append("\"request-number\":").append("\"").append("").append("\"").append(",");
				jsonData.append("\"eccn\":").append("\"").append(szECCN).append("\"").append(",");
				jsonData.append("\"hts\":").append("\"").append(szHTS).append("\"").append(",");

				jsonData.append("\"country-of-origin\":").append("\"").append(szeCOO).append("\"").append(",");
				jsonData.append("\"country-of-origin-code\":").append("\"").append(szeCOOCode).append("\"").append(",");
				jsonData.append("\"meu-assesment-tag\":").append("\"").append(szeMEUTAG).append("\"").append(",");

				string avls = "";
				TERADYNE_TRACE_CALL(iStatus = teradyne_part_avl(objTagRev, &avls), TD_LOG_ERROR_AND_THROW);
				jsonData.append("\"avl\":").append("[").append(avls).append("]");

				jsonData.append("}");

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(objTagRev, "owning_user", &tOwningUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tOwningUser, &owningUser), TD_LOG_ERROR_AND_THROW);
				string szOwningUser = string(owningUser);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(objTagRev, "last_mod_user", &tLastModUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tLastModUser, &lastModUser), TD_LOG_ERROR_AND_THROW);
				string szLastModUser = string(lastModUser);

				string jsonMetadata = "\"metadata\":{";
				jsonMetadata.append("\"date-created\":").append("\"").append(szDateCreated).append("\"").append(",");
				jsonMetadata.append("\"date-modified\":").append("\"").append(szDateModified).append("\"").append(",");
				jsonMetadata.append("\"owning-user\":").append("\"").append(szOwningUser).append("\"").append(",");
				jsonMetadata.append("\"last-mod-user\":").append("\"").append(szLastModUser).append("\"");
				jsonMetadata.append("}");

				char *es_url = NULL;
				//Getting Preference Value to get Workflow template name
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_ES_URL_PREF, TC_preference_site, 0, &es_url), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = postEvent(eventType, es_url, jsonMetadata, jsonData), TD_LOG_ERROR_AND_THROW);

			}
			Custom_free(pcUnitOfMeasure);
		}
		Custom_free(pcObjectType);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcRevId);
	Custom_free(pTaskUid);
	Custom_free(owningUser);
	Custom_free(lastModUser);
	Custom_free(pcRelStatusType);
	Custom_free(pcEcnItemId);
	Custom_free(pcSynopsis);
	Custom_free(pcChangeReason);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_submitPartToESI
 * Description				:
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      :
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1.
 * NOTES					:
 ******************************************************************************/
int teradyne_submitPartToESI(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iReferences = 0,
		iCount = 0,
		iItemCount = 0;

	tag_t *tAttaches = NULL,
		*tReferences = NULL,
		*tObjects = NULL;

	char *pcAttachType = NULL,
		*pcEventType = NULL;

	const char * __function__ = "teradyne_submitPartToESI";
	TERADYNE_TRACE_ENTER();

	try
	{
		teradyne_get_handler_opts(msg.arguments,
			"-eventTypeValue", &pcEventType,
			NULL);

		if (msg.task != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for (int i = 0; i < iCount; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if (!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE))
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iItemCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					for (int jj = 0; jj < iItemCount; jj++)
					{
						pcAttachType = "";
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjects[jj], &pcAttachType), TD_LOG_ERROR_AND_THROW);
						if (!tc_strcmp(pcAttachType, TD_DIV_PART_REV))
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(TD_PART_RELEASED_EVENT, msg.task, tObjects[jj]), TD_LOG_ERROR_AND_THROW);
						}
					}

				}
				else if (!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE))
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iItemCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					for (int jj = 0; jj < iItemCount; jj++)
					{
						pcAttachType = "";
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjects[jj], &pcAttachType), TD_LOG_ERROR_AND_THROW);
						if (!tc_strcmp(pcAttachType, TD_DIV_PART_REV))
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(TD_PART_REVISED_EVENT, msg.task, tObjects[jj]), TD_LOG_ERROR_AND_THROW);
						}
					}
				}
				else if (!tc_strcmp(pcAttachType, TD_DIV_PART_REV) || !tc_strcmp(pcAttachType, TD_COMM_PART_REV))
				{
					if (tc_strcmp(pcEventType, TD_PART_CREATED_EVENT) == 0)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(TD_PART_CREATED_EVENT, msg.task, tAttaches[i]), TD_LOG_ERROR_AND_THROW);;
					}
					else if (tc_strcmp(pcEventType, TD_PART_UPDATED_EVENT) == 0)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(TD_PART_UPDATED_EVENT, msg.task, tAttaches[i]), TD_LOG_ERROR_AND_THROW);
					}
					else if (tc_strcmp(pcEventType, TD_BOM_PUSHED_EVENT) == 0)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(TD_BOM_PUSHED_EVENT, msg.task, tAttaches[i]), TD_LOG_ERROR_AND_THROW);
					}
				}
				else if (!tc_strcmp(pcAttachType, TD_PART_MOD_REQ_REV) && pcEventType != NULL)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_PART_TO_BE_MODIFIED_REL, &iItemCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					for (int jj = 0; jj < iItemCount; jj++)
					{
						pcAttachType = "";
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjects[jj], &pcAttachType), TD_LOG_ERROR_AND_THROW);
						if (!tc_strcmp(pcAttachType, TD_DIV_PART_REV) || !tc_strcmp(pcAttachType, TD_COMM_PART_REV))
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ESI(pcEventType, msg.task, tObjects[jj]), TD_LOG_ERROR_AND_THROW);
						}
					}
				}

			}

		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcAttachType);
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}