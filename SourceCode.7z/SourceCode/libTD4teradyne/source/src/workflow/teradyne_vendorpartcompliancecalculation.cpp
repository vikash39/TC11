/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_vendorpartcompliancecalculation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CreateCmplChkForm action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  30-Mar-2015                       Haripriya                    	    Initial Creation
#  04-Jun-2015                       Vijayasekhar                    	Added code changes to update current time and added the vendor part to "Vendor Part Compliance" folder
#  11-Jun-2015                       Haripriya                    	    Modified the function to check whether the folder exists or not.  
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_vendorpartcompliancecalculation
 * Description				: This handler creates Scp0SndToCmplChkForm and updates scp0part_details,scp0regulation_name
 *                            and attaching to EPMTask
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_vendorpartcompliancecalculation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0,
		iPrefCount				= 0,
		iFolder					= 0;

	tag_t *tAttaches			= NULL,
		  tFormTag				= NULLTAG,
		  tRootTask				= NULLTAG,
		  *tFolder				= NULL;
	 
	char **pcPrefvalue			= NULL,
		  *pcattachtype         = NULL,
		  *pcitemid				= NULL;

	string szval				= "",
		   strCurTimeStamp		= "";
	date_t curDate;
	const char * __function__ = "teradyne_vendorpartcompliancecalculation";
	TERADYNE_TRACE_ENTER();

	try {
		
		if(msg.task != NULLTAG) 
		{
            //Getting all the Attachments from Target folder
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus =teradyne_ask_object_type(tAttaches[i],&pcattachtype),TD_LOG_ERROR_AND_THROW);
				//Checking whether the object type is VendorPart
				if(tc_strcmp(pcattachtype,TD_MFG_PART) == 0)
				{
					//getting TD_AUTO_CMPL_CHECK_PREF value,if empty will throw an error
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_AUTO_CMPLCHECK_REGULATION,TC_preference_site,&iPrefCount,&pcPrefvalue),TD_LOG_ERROR_AND_THROW);
					if(iPrefCount > 0)
					{
						for(int j=0;j<iPrefCount;j++)
						{
							if(j!=0)
							{
								szval.append(TD_COMMA_CONSTANT).append(pcPrefvalue[j]);
							}
							else
								szval.append(pcPrefvalue[j]);
						}
					    //creating and updating Scp0SndToCmplChkForm  form and attaching to job
						TERADYNE_TRACE_CALL(iStatus=teradyne_create_object(TD_SND_TO_CMPL_CHK_FORM_TYPE,"SndToCmplChkForm",&tFormTag),TD_LOG_ERROR_AND_THROW);
						if(tFormTag != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tAttaches[i],TD_ITEM_ID_ATTR,&pcitemid),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tFormTag,TD_PART_DETAILS_ATTR,pcitemid),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tFormTag,TD_REGULATION_NAME_ATTR,szval),TD_LOG_ERROR_AND_THROW);
							tag_t attachments[1]={NULLTAG};
							attachments[0]=tFormTag;
							int attachments_type[1]={EPM_target_attachment};
							TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus=EPM_add_attachments(tRootTask,1,attachments,attachments_type),TD_LOG_ERROR_AND_THROW);
							//Update the vendor part property td4SentToCmpl with current time.
							TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i], true), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_date(tAttaches[i], TD_SENT_TO_COMPL_ATTR, curDate), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttaches[i]), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i], false), TD_LOG_ERROR_AND_THROW);
							//Add the vendor part to folder �Vendor Part Compliance�.Assuming that there is only one folder available
							TERADYNE_TRACE_CALL(iStatus = WSOM_find2(TD_VENDOR_PART_CMPL_FLDR, &iFolder, &tFolder), TD_LOG_ERROR_AND_THROW);
							if(iFolder > 0)
							{
								TERADYNE_TRACE_CALL(iStatus = teradyne_check_given_object_in_folder(tFolder[0], tAttaches[i]), TD_LOG_ERROR_AND_THROW);
								Custom_free(tFolder);
							}
						}
						Custom_free(pcitemid);
						Custom_free(pcPrefvalue);
					}
					else
					{
						TERADYNE_TRACE_CALL(iStatus=EMH_store_error_s1 (EMH_severity_error,TD_PREF_VALUE_NULL_ERROR,TD_AUTO_CMPLCHECK_REGULATION),TD_LOG_ERROR_AND_THROW);
						iStatus = TD_PREF_VALUE_NULL_ERROR;
						throw iStatus;
					}
				}
				Custom_free(pcattachtype)
			}	
			Custom_free(tAttaches);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
