/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_get_part_type_to_modify        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-GetPartTypeForModification action handler
#      Project         :           libTD4teradyne          
#      Author          :                    
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_get_part_type_to_modify
 * Description				: 
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_part_type_to_modify(EPM_action_message_t msg) 
{
	int iStatus					= ITK_ok,
		iReferences             = 0,
		iItemCount              = 0,
		iCount					= 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tObjects				= NULL;
	
	char *pcAttachType			= NULL,
		 *pcProjAttr			= NULL,
	     *pcItemStatus				= NULL;

	bool isItemStatusProtoType = false;

	const char * __function__ = "teradyne_get_part_type_to_modify";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(msg.task != NULLTAG) 
		{ 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_PART_MOD_REQ_REV))
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_PART_TO_BE_MODIFIED_REL, &iItemCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					 for(int jj = 0; jj < iItemCount; jj++) 
					 {
						pcAttachType = "";
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjects[jj], &pcAttachType), TD_LOG_ERROR_AND_THROW);
						if(!tc_strcmp(pcAttachType, TD_DIV_PART_REV) || !tc_strcmp(pcAttachType, TD_COMM_PART_REV)) 
						{
							TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, pcAttachType), TD_LOG_ERROR_AND_THROW);
							break;
						}
					 }
				}
			}

			
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcItemStatus);
	Custom_free(pcProjAttr);
	Custom_free(pcAttachType);
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}