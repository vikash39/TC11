/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_validateOPSTaskreviewer.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ValidateOPSTaskReviewer action handler
#      Project         :           libTD4teradyne          
#      Author          :           Karl Reimann          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  11-21-2017                   Karl									Initial creation
#  12-06-2017                   Karl									Added comments
#
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_validateOPSTaskreviewer
 * Description				: This function will check the group and role of the assigned user for OPS Task.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-action","-task"  in task and action argument is mandatory.
 *							 2. For the given task ,given action is performed.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_validateOPSTaskreviewer(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iSignoffAttCount	= 0,
		*iProfCount			= 0;

	tag_t tMember			= NULLTAG,
		  tGroup			= NULLTAG,
		  tRole				= NULLTAG,
		  tUserTag			= NULLTAG;

	tag_t* tSignoffAttachments;
	
	SIGNOFF_TYPE_t memberType;

	char *pcTypeName			= NULL,
		 *pcGroupName			= NULL,
		 *pcRoleName			= NULL;

	const char * __function__    = "teradyne_validateOPSTaskreviewer";
	TERADYNE_TRACE_ENTER();
	
	try {
		if(msg.task != NULLTAG && msg.action == EPM_complete_action) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
             if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMSelectSignoffTask") == 0))) { //checks if task is select signoff task
				TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(msg.task, EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW); //gets attachments(sign off list) of the task
				if(iSignoffAttCount == 1)
				{
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_signoff_member(tSignoffAttachments[0], &tMember, &memberType), TD_LOG_ERROR_AND_THROW); //gets the member tag of people in the sign off list
					TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_user(tMember, &tUserTag), TD_LOG_ERROR_AND_THROW); //gets the user id

					TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_group(tMember, &tGroup), TD_LOG_ERROR_AND_THROW); //gets the group of the reviewer
					TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tGroup, &pcGroupName), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_role(tMember, &tRole), TD_LOG_ERROR_AND_THROW); //gets the role of the reviewer
					TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(tRole, &pcRoleName), TD_LOG_ERROR_AND_THROW);

					if(tc_strcmp(pcGroupName, TD_OPS_GROUP_NAME2) != 0) //validates if the group and role of the reviewer
					{
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR;
						throw iStatus;
					}
					else
					{
						if(tc_strcmp(pcRoleName, TD_COMM_SUPPORT_ENGG_ROLE) == 0 || tc_strcmp(pcRoleName, TD_COMM_ENGG_ROLE) == 0 || tc_strcmp(pcRoleName, TD_ROHS_COORDINATOR_ROLE) == 0)
						{
							//do nothing if the reviewer is in the correct group and role
						}
						else 
						{
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR; //return an error if the assigned user is not in the correct group and role
							throw iStatus;
						}
					}
				}
				else
				{
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_OPS_TASK_MULTIPLE_REVIEWER_ERROR), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_OPS_TASK_MULTIPLE_REVIEWER_ERROR; //return an error if there is more than one reviewer assigned
					throw iStatus;
				}
			}
			Custom_free(pcRoleName);
			Custom_free(pcGroupName);
			Custom_free(pcTypeName);
		}
	} catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}


 