#include <workflow/teradyne_handlers.h>

EPM_decision_t ur_ecn_validation_datasetcheck(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t root_task, *attachments = NULL, t_relation1 = NULL, *t_SecObj1 = NULLTAG, t_relation2 = NULL, *t_SecObj2 = NULLTAG, t_relation3 = NULL, *t_SecObj3 = NULL;
	tag_t t_relation4 = NULL, *t_SecObj4 = NULL, *t_Secobj5 = NULLTAG;
	int iStatus, count1 = 0, i = 0, count2 = 0, j = 0, count3 = 0, k = 0, count4 = 0, count5 = 0, l = 0, C1 = 0, c2 = 0;
	char *sec_obj_type = NULL, *t_ObjType = NULL, *t_ObjType1 = NULL, *c_Pvalue4 = NULL, *PartObjString = NULL, *ECNObjString = NULL;
	decision = EPM_go;

	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count1, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count1; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if ((tc_strcmp(sec_obj_type, "TD4ReleaseECNRevision") == 0) || (tc_strcmp(sec_obj_type, "TD4StandardECNRevision") == 0))
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &ECNObjString), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation1, &count2, &t_SecObj1), TD_LOG_ERROR_AND_THROW);
			for (j = 0; j < count2; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[j], &t_ObjType1), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(t_ObjType1, "TD4DivPartRevision") == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("TD4RefMaterialRel", &t_relation4), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(t_SecObj1[j], t_relation4, &count5, &t_SecObj4), TD_LOG_ERROR_AND_THROW);

					if (count5 > 0)
					{

						decision = EPM_go;

					}
					else
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &PartObjString), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("IMAN_specification", &t_relation2), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(t_SecObj1[j], t_relation2, &count3, &t_SecObj2), TD_LOG_ERROR_AND_THROW);
						if (count3 == 0)
						{
							decision = EPM_nogo;
							TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Design_DOC_with_Dataset_missing, ECNObjString, PartObjString), TD_LOG_ERROR_AND_THROW);
							c2++;
						}
						else
						{
							for (k = 0; k < count3; k++)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj2[k], &t_ObjType), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(t_ObjType, "TD4DesignDocRevision") == 0)
								{
									TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("TD4RefMaterialRel", &t_relation3), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(t_SecObj2[k], t_relation3, &count4, &t_SecObj3), TD_LOG_ERROR_AND_THROW);
									if (count4 > 0)
									{
										decision = EPM_go;
									}
									else
									{
										decision = EPM_nogo;
										TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Design_DOC_with_Dataset_missing, ECNObjString, PartObjString), TD_LOG_ERROR_AND_THROW);
										c2++;
									}
									Custom_free(t_SecObj3);
									C1++;
								}


								Custom_free(t_ObjType);
							}
							if (C1 == 0)
							{
								decision = EPM_nogo;
								TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Design_DOC_with_Dataset_missing, ECNObjString, PartObjString), TD_LOG_ERROR_AND_THROW);
								c2++;
							}
						}

						Custom_free(t_SecObj2);
						Custom_free(PartObjString);
					}
					C1 = 0;
				}

				Custom_free(t_ObjType1);

			}
			Custom_free(t_SecObj1);
			Custom_free(ECNObjString);

		}
		Custom_free(sec_obj_type);
	}
	if (c2 > 0)
	{
		decision = EPM_nogo;
	}
	Custom_free(attachments);
	return decision;
}


