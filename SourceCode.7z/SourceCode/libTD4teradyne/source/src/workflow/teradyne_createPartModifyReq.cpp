
#include <workflow/teradyne_handlers.h>

extern "C"
int teradyne_createPartModifyReq(EPM_action_message_t msg)
{
	int		iStatus			= ITK_ok;
	tag_t	tRootTask		= NULLTAG,
			*ptAttaches		= NULL,
			*tTerParts		= NULL,
			tNewProcess     = NULLTAG;
	int		iAttachCount	= 0,
			iTerParts		= 0;

	char	*pcTypeName		= NULL,
			*pcItemId		= NULL,
			*pcProjectName	= NULL,
			*pcProcessTemplateName = NULL,
			*pcCBU				   = NULL;

	const char * __function__ = "teradyne_createPartModifyReq";
	TERADYNE_TRACE_ENTER();
	
	try 
	{
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
		for(int ii = 0; ii < iAttachCount; ii++) 
		{			
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[ii], &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(pcTypeName != NULL && (tc_strcmp(pcTypeName, "TD4PartModReqRevision") == 0))
			{
				tag_t	tRelationTypeTag = NULL;
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ECR_REF_NAME, &tRelationTypeTag), TD_LOG_ERROR_AND_THROW); 
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches[ii], tRelationTypeTag, &iTerParts, &tTerParts), TD_LOG_ERROR_AND_THROW);
				
				for(int jj=0;jj<iTerParts;jj++)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTerParts[jj], &pcTypeName), TD_LOG_ERROR_AND_THROW);
					if(pcTypeName != NULL && (tc_strcmp(pcTypeName, TD_DIV_PART_REV) == 0 || tc_strcmp(pcTypeName, TD_COMM_PART_REV) == 0))
					{
						AM__set_application_bypass(true);
						tag_t tObjTypeTag = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus=TCTYPE_find_type("TD4PartModifyReq","TD4PartModifyReq",&tObjTypeTag),TD_LOG_ERROR_AND_THROW);
						tag_t tPartModifyReqCreate = NULL;
						TERADYNE_TRACE_CALL(iStatus=TCTYPE_construct_create_input (tObjTypeTag, &tPartModifyReqCreate),TD_LOG_ERROR_AND_THROW);

						tag_t tPartModifyReqTag = NULL;
						TERADYNE_TRACE_CALL(iStatus=TCTYPE_create_object(tPartModifyReqCreate, &tPartModifyReqTag),TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus=AOM_save_without_extensions(tPartModifyReqTag),TD_LOG_ERROR_AND_THROW);

						tag_t	tPartModifyReqRevTag = NULL;
						TERADYNE_TRACE_CALL(iStatus=ITEM_ask_latest_rev(tPartModifyReqTag,&tPartModifyReqRevTag),TD_LOG_ERROR_AND_THROW);
					
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTerParts[jj], TD_ITEM_ID_ATTR, &pcItemId), TD_LOG_ERROR_AND_THROW);
						//TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTerParts[jj], TD_PROJECT_NAME_ATTR, &pcProjectName), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPartModifyReqRevTag,"object_name", TD_PART_MODIFY_REQUEST_OBJECT_NAME), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPartModifyReqRevTag,"td4TERPartNumReqChg", pcItemId), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tTerParts[jj], TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

						if(pcCBU != NULL)
						{
							TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tPartModifyReqRevTag,TD_CONTRL_BUS_UNIT, pcCBU),TD_LOG_ERROR_AND_THROW);
						}

						string szCreRequestPart_Attr[]	= {"td4DescribeDesireChng","td4ReasonForChange",TD_PROJECT_NAME_ATTR};
						std::list<string> strCreReqPartAttrList( szCreRequestPart_Attr, szCreRequestPart_Attr + sizeof(szCreRequestPart_Attr) / sizeof(string) );

						std::map<string,string> strPropNameValueMap;

						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[ii],strCreReqPartAttrList,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPartModifyReqRevTag,"td4DescribeDesireChng", strPropNameValueMap.find("td4DescribeDesireChng")->second), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPartModifyReqRevTag,"td4ReasonForChange", strPropNameValueMap.find("td4ReasonForChange")->second), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPartModifyReqRevTag,TD_PROJECT_NAME_ATTR,strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second), TD_LOG_ERROR_AND_THROW);

						tag_t  tPartToBeModRelTag = NULLTAG; 
			
						TERADYNE_TRACE_CALL(iStatus=GRM_find_relation_type("TD4PartToBeModifiedRel",&tPartToBeModRelTag),TD_LOG_ERROR_AND_THROW);

						if(tPartToBeModRelTag !=NULLTAG)
						{
						
							tag_t tNewRelation	= NULLTAG;

							//Attach to Teradyne Parts (Part to be modified)
							TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(tPartModifyReqRevTag,tTerParts[jj],tPartToBeModRelTag,NULLTAG,&tNewRelation),TD_LOG_ERROR_AND_THROW);

							if(tNewRelation != NULLTAG)
							{
								TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tNewRelation),TD_LOG_ERROR_AND_THROW);
							}
						}

						tag_t tCMRefRelation	= NULLTAG;
						TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(ptAttaches[ii],tPartModifyReqRevTag,tRelationTypeTag,NULLTAG,&tCMRefRelation),TD_LOG_ERROR_AND_THROW);
						if(tCMRefRelation != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tCMRefRelation),TD_LOG_ERROR_AND_THROW);
						}

						TERADYNE_TRACE_CALL(iStatus=AOM_save_with_extensions(tPartModifyReqRevTag),TD_LOG_ERROR_AND_THROW);



						//Propagate dataset to PartModifyRequestRevision ....
						
						tag_t tReferencesTag = NULLTAG;
						tag_t *tReferences=NULL;
						int iTerReferences=0;
						char *pcRefTypeName =NULL;

						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ECR_REF_NAME, &tReferencesTag), TD_LOG_ERROR_AND_THROW); 
				        TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches[ii], tReferencesTag, &iTerReferences, &tReferences), TD_LOG_ERROR_AND_THROW);
					
						for(int iRef=0;iRef<iTerReferences;iRef++){

							  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReferences[iRef], &pcRefTypeName), TD_LOG_ERROR_AND_THROW);
					          if(pcRefTypeName != NULL && tc_strcmp(pcRefTypeName, TD_DIV_PART_REV) != 0 && tc_strcmp(pcRefTypeName, TD_COMM_PART_REV) != 0 && tc_strcmp(pcRefTypeName, TD_PART_MOD_REQ_REV) != 0){
						         AM__set_application_bypass(true);

							          //Create a relationship for part modify request and datasets
					              tag_t tRelation = NULLTAG;
								  tag_t tTCAttachesRelTag =NULLTAG;
					              TERADYNE_TRACE_CALL(iStatus=GRM_find_relation_type(TD_ATTACHES_REL_NAME,&tTCAttachesRelTag),TD_LOG_ERROR_AND_THROW);
							      TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPartModifyReqRevTag,tReferences[iRef], tTCAttachesRelTag, &tRelation), TD_LOG_ERROR_AND_THROW);

					                  if(tRelation ==NULLTAG){
						                 tag_t tNewRelation	= NULLTAG;
                                         TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(tPartModifyReqRevTag,tReferences[iRef],tTCAttachesRelTag,NULLTAG,&tNewRelation),TD_LOG_ERROR_AND_THROW);
										
										     if(tNewRelation != NULLTAG){
							                     TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tNewRelation),TD_LOG_ERROR_AND_THROW);
						                     }
					                  }

                               AM__set_application_bypass(false);
					  
					        }
						}

						//TERADYNE_TRACE_CALL(iStatus=ITEM_save_item(tPartModifyReqTag),TD_LOG_ERROR_AND_THROW);

						//Getting Preference Value to get Workflow template name
						TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_PARTMODIFYREQUEST_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
						// Calling function to Initiate T4O_Item_Push Workflow on Created DIVPARTREVISION
						TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tPartModifyReqRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);

						AM__set_application_bypass(false);
						break;
					}
				}

				break;	
			}
		}
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(pcTypeName);
	Custom_free(tTerParts);
	Custom_free(pcItemId);
	Custom_free(pcProjectName);
	Custom_free(pcProcessTemplateName);
	Custom_free(pcCBU);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}