/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_abort_ecn_tasks.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AbortECNTasks handler
#      Project         :           libTD4teradyne          
#      Author          :                    

#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_abort_ecn_tasks
 * Description				: This function will ecn tasks
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. 
 *							 2.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_abort_ecn_tasks(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iCount              = 0,
		iValCount           = 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tActuatedInterActive = NULL,
		  *tObjects				= NULL;

	
	
	char *pcAttachType			= NULL,
		*pcUserName		      	= NULL,
		 *pcEventType			= NULL;

	 char *pcTaskName                    = NULL;
	 char *pcTypeName					= NULL;
	 tag_t tUser					= NULLTAG;
		

	const char * __function__    = "teradyne_abort_ecn_tasks" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) { 
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			POM_AM__set_application_bypass(true);
			for(int i=0;i<iCount;i++){
			    TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)  || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE)   ){
				     TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tAttaches[i],"fnd0StartedWorkflowTasks", &iValCount, &tActuatedInterActive),TD_LOG_ERROR_AND_THROW);
					 for(int t=0;t<iValCount;t++){
						   
						 TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tActuatedInterActive[t], &pcTypeName), TD_LOG_ERROR_AND_THROW);
						 if(!tc_strcmp("EPMDoTask", pcTypeName)){
						     TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tActuatedInterActive[t], "fnd0AliasTaskName", &pcTaskName), TD_LOG_ERROR_AND_THROW);
							  if(!tc_strcmp("Authoring Task", pcTaskName) || !tc_strcmp("ECN Author Work", pcTaskName) ){
								 TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
								 TERADYNE_TRACE_CALL(iStatus = EPM_assign_responsible_party(tActuatedInterActive[t],tUser), TD_LOG_ERROR_AND_THROW);
								 TERADYNE_TRACE_CALL(iStatus = EPM_trigger_action(tActuatedInterActive[t],EPM_abort_action,"Abort ECN Authoring Task"), TD_LOG_ERROR_AND_THROW);
							  }
						 }
						 
							 
					 }
			    }


			}
			POM_AM__set_application_bypass(false);
		
		
		}

		
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}