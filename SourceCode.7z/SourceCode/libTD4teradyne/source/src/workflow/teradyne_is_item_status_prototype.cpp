/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_is_item_status_prototype        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SubmitCommPartRevToT4O action handler
#      Project         :           libTD4teradyne          
#      Author          :                    
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_is_item_status_prototype
 * Description				: 
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_is_item_status_prototype(EPM_action_message_t msg) 
{
	int iStatus					= ITK_ok,
		iReferences             = 0,
		iCount					= 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tObjects				= NULL;
	
	char *pcAttachType			= NULL,
		 *pcProjAttr			= NULL,
	     *pcItemStatus				= NULL;

	bool isItemStatusProtoType = false;

	const char * __function__ = "teradyne_is_item_status_prototype";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(msg.task != NULLTAG) 
		{ 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_DIV_PART_REV)) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tAttaches[i], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
					
				    if(!tc_strcmp(pcItemStatus, TD_PROTO_TYPE_ATTR)) 
					{
						isItemStatusProtoType = true;
						break;
					}
				}
			}

			if(isItemStatusProtoType) 
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_True), TD_LOG_ERROR_AND_THROW);
			}
			else 
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_False), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcItemStatus);
	Custom_free(pcProjAttr);
	Custom_free(pcAttachType);
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}