/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assignrevmatdynamicparticipant.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignReviewerMatrixSignoffParticipant action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  15-Apr-2015                       Haripriya                    	    Initial Creation
#  07-May-2015                       Haripriya                    	    Modified handler arguments
#  11-May-2015                       Haripriya                    	    Added Type Check
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assignrevmatdynamicparticipant.
 * Description				: Assignes the participants to the review task based on the given handler arguments              
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 *  ALGORITHM				: 1. Read the arguments "-project_attrbute","-property","-assignparticipant", in task.
 *							  2. Read attribute name given in -project_attrbute argument from target object and get corresponding user id for assignee and assigned to the current task.
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_assignrevmatdynamicparticipant(EPM_action_message_t msg) { 

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iUsers					= 0,
		iGrpMemCount				= 0,
		iPropVals				= 0,
		iParticipantCount		= 0;

	char *pcProjectAttr			= NULL,
		 *pcPropertyName		= NULL,
		 *pcAssignParticipants	= NULL,
		 **pcPropVals			= NULL,
		 *pcPersonName			= NULL;

	tag_t *tAttaches			= NULL,	
		   tGroup				= NULLTAG,
		  *tUsers				= NULL,
		  *tGrpMem				= NULL,
		  tParticipantType		= NULLTAG,
		  *tParticipantlist		= NULL,
		  tParticipant			= NULLTAG;

	vector<string> CBreviewerValues;

	const char * __function__ = "teradyne_assignrevmatdynamicparticipant";
	TERADYNE_TRACE_ENTER();

	try 
	{
		teradyne_get_handler_opts(msg.arguments, "-project_attribute", &pcProjectAttr,
												 "-property", &pcPropertyName,
												 "-assignparticipant", &pcAssignParticipants,
												 NULL);
		if((pcProjectAttr != NULL &&  tc_strcmp(pcProjectAttr, "") != 0) && (pcPropertyName != NULL && tc_strcmp(pcPropertyName, "") != 0)) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);		
			for(int i = 0; i < iAttaches; i++)
			{ 
				char *pcTypeName = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				if( (tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0 ))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tAttaches[i], pcPropertyName, &iPropVals, &pcPropVals), TD_LOG_ERROR_AND_THROW);//td4ReqdTechReviewersList // td4ObserversList
					for(int j = 0; j < iPropVals; j++) 
					{
						if(!tc_strcmp(pcPropVals[j], pcProjectAttr))
						{
							for(int k = j+1; k < iPropVals; k++) 
							{
								string strTemp(pcPropVals[k]);
								size_t pos = strTemp.find(":");
								if(pos == -1) 
								{
									CBreviewerValues.push_back(strTemp);
								}
								else
								{
									break;
								}
							}
						}
					}
					Custom_free(pcPropVals);

					//Getting the Participant Tag and clearing the members in that
					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype(pcAssignParticipants,&tParticipantType),TD_LOG_ERROR_AND_THROW );
					TERADYNE_TRACE_CALL(iStatus = ITEM_rev_ask_participants(tAttaches[i],tParticipantType,&iParticipantCount, &tParticipantlist),TD_LOG_ERROR_AND_THROW );

					for(int k = 0; k < iParticipantCount; k++) 
					{	
							POM_AM__set_application_bypass(true);
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i],true),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_remove_participant(tAttaches[i],tParticipantlist[k]),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttaches[i]),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i],false),TD_LOG_ERROR_AND_THROW );
							POM_AM__set_application_bypass(false);
					}
					Custom_free(tParticipantlist);
				
					for(int l=0;l<CBreviewerValues.size();l++)
					{
						tag_t	   tResponsibleUser     = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = SA_extent_user(&iUsers, &tUsers),TD_LOG_ERROR_AND_THROW );
						for(int k = 0; k < iUsers; k++) 
						{ 	
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUsers[k], &pcPersonName),TD_LOG_ERROR_AND_THROW );
							if(tc_strcmp(CBreviewerValues.at(l).c_str(), pcPersonName) == 0)
							{
								tResponsibleUser = tUsers[k];
								Custom_free(pcPersonName);
								break;
							}
						}
						if (tResponsibleUser != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_login_group(tResponsibleUser, &tGroup),TD_LOG_ERROR_AND_THROW ); 

							TERADYNE_TRACE_CALL(iStatus = SA_find_groupmembers (tResponsibleUser, tGroup, &iGrpMemCount, &tGrpMem),TD_LOG_ERROR_AND_THROW ); 

							if(iGrpMemCount > 0) 
							{
								//Assign assignee as responsible party of current task
								POM_AM__set_application_bypass(true);
								TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tGrpMem[0],tParticipantType,&tParticipant),TD_LOG_ERROR_AND_THROW );
								TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i],true),TD_LOG_ERROR_AND_THROW );
								TERADYNE_TRACE_CALL(iStatus = ITEM_rev_add_participant(tAttaches[i],tParticipant),TD_LOG_ERROR_AND_THROW );
								TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttaches[i]),TD_LOG_ERROR_AND_THROW );
								TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i],false),TD_LOG_ERROR_AND_THROW );
								POM_AM__set_application_bypass(false);
							}
							Custom_free(tGrpMem);
						}
						Custom_free(tUsers);
					}
				}

			}
			Custom_free(tAttaches);
		}	
	} 
	catch(...) 
	{

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	CBreviewerValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}