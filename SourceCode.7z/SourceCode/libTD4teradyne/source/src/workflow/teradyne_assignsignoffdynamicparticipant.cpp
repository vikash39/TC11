/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assignsignoffdynamicparticipant.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignSignOffDynamicParticipant action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Apr-2015                       Vijayasekhar                    	Added function definition for teradyne_assignsignoffdynamicparticipant
#  15-Apr-2015                       Vijayasekhar                    	Removed the code to free memory for the handler arguments
#  21-Apr-2015                       Haripriya                    	    Modified the handler to remove participant member if the given property has empty value
#  24-Apr-2015                       Haripriya                    	    Modified the handler to work even only two argument is given.
#  29-Apr-2015						 Haripriya                          Modified the code to work only for first target object
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assignsignoffdynamicparticipant
 * Description				: Assignes the participants to the review task based on the given handler arguments                            
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Read the arguments "-assigneevalue","-assignparticipant","-from_include_type","-from_attach","-from_relation","-from_include_related_type"  in task.
 *							  2. Read attribute name given in -assigneevalue argument from target object and get corresponding user id for assignee and assigned to the current task.
 *							
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_assignsignoffdynamicparticipant(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iRelObjects				= 0,
		iPropCount				= 0,
		iUsers					= 0,
		iMembers				= 0,
		iParticipantCount		= 0;
	char *pcAssignee			= NULL,
		 *pcAssignParticipants	= NULL,
		 *pcfromattach			= NULL,
		 *pcrelation			= NULL,
		 *pcreltype				= NULL,
		 *pcTypeName			= NULL,
		 **pcAssigneevalue		= NULL,
		 *pcfromtype			= NULL,
		*roleName				= NULL,
		*grpName				= NULL,
		*usrID					= NULL,
		 *pcPersonName			= NULL;
	tag_t *tAttaches			= NULL,
		  *tRelObjects			= NULL,
		  *tUsers				= NULL,
		  *tMembers				= NULL,
			tGroup				= NULLTAG,
		roleTag					= NULLTAG,
		  tParticipantType		= NULLTAG,
		  *tParticipantlist		= NULL,
		 targetObjTag           = NULLTAG,
		  tParticipant			= NULLTAG;
	bool bTemp					= true;

	const char * __function__ = "teradyne_assignsignoffdynamicparticipant";
	TERADYNE_TRACE_ENTER();

	try {
		//read the handler arguments
		teradyne_get_handler_opts(msg.arguments, "-assigneevalue", &pcAssignee,
												 "-assignparticipant", &pcAssignParticipants, 
												 "-from_attach", &pcfromattach,
												 "-from_relation", &pcrelation,
												 "-from_include_related_type", &pcreltype,
												 "-from_include_type", &pcfromtype,
												 NULL);
		
		if((pcAssignee != NULL &&  tc_strcmp(pcAssignee, "") != 0) && (pcAssignParticipants != NULL && tc_strcmp(pcAssignParticipants, "") != 0)) {
	
			//get the attachment based on "-from_attach" argument
			if( pcfromattach != NULL && tc_strcmp(pcfromattach,"reference") == 0)
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			else 
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);		
			
			TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype(pcAssignParticipants,&tParticipantType),TD_LOG_ERROR_AND_THROW );
			for(int i = 0; i < iAttaches; i++) {
				bTemp = true;
				targetObjTag = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				//Get target object for retrieving expected properties; These are the target objects that this handler is currently used in a workflow tasks
				if( pcTypeName != NULL && (tc_strcmp(pcTypeName,TD_STD_ECN_REV_TYPE) == 0 ) || tc_strcmp(pcTypeName,TD_PROTOBOM_ECN_REV_TYPE)==0 || tc_strcmp(pcTypeName,TD_REL_ECN_REV_TYPE)==0 || tc_strcmp(pcTypeName,TD_PROTOPART_ECN_REV_TYPE)==0 || tc_strcmp(pcTypeName, TD_SUPPLIER_ADD_REQ_REV) == 0){
								targetObjTag  =tAttaches[i];	
			    }
				

				
				if(pcrelation != NULL && pcreltype != NULL) 
				{
					//Gets the objects related to the given relation
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], pcrelation, &iRelObjects, &tRelObjects), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iRelObjects; j++)
					{ 
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type( tRelObjects[j], &pcTypeName), TD_LOG_ERROR_AND_THROW);
						if( pcTypeName != NULL && tc_strcmp(pcTypeName, pcreltype) == 0 ) 
						{
							TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_strings( tRelObjects[j],pcAssignee,&iPropCount,&pcAssigneevalue),TD_LOG_ERROR_AND_THROW );		
							break; //only one object related to the the object
						}
						Custom_free(pcTypeName);
					}


					//ProtoPart ECN 



				} 
				if ( pcfromtype != NULL )
				{
					
					//request will be processed for the below specified item revisions
					if( (tc_strcmp(pcTypeName, pcfromtype) == 0) ) 
					{
						TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_strings (tAttaches[i],pcAssignee,&iPropCount,&pcAssigneevalue),TD_LOG_ERROR_AND_THROW );
					}
				}
				if ( ( pcfromtype == NULL ) && ( pcreltype == NULL ) && (pcrelation == NULL) && (targetObjTag != NULLTAG) )
				{
					//request will be processed for the below specified item revisions
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(targetObjTag,pcAssignee,&iPropCount,&pcAssigneevalue),TD_LOG_ERROR_AND_THROW);
				}

				if(pcAssigneevalue == NULL)
				{
					if(targetObjTag != NULLTAG && tc_strcmp(pcreltype, TD_ADDITIONAL_REVIEWER_REL_NAME) != 0)
					{
						TERADYNE_TRACE_CALL(iStatus = ITEM_rev_ask_participants(targetObjTag,tParticipantType,&iParticipantCount, &tParticipantlist),TD_LOG_ERROR_AND_THROW );
						for(int l = 0; l < iParticipantCount; l++) 
						{	
							 POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,true),TD_LOG_ERROR_AND_THROW );		
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_remove_participant(targetObjTag,tParticipantlist[l]),TD_LOG_ERROR_AND_THROW );
							TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(targetObjTag),TD_LOG_ERROR_AND_THROW );
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,false),TD_LOG_ERROR_AND_THROW );
							 POM_AM__set_application_bypass(false);
						}
					}
				}
				else
				{
					TERADYNE_TRACE_CALL(iStatus = SA_extent_user(&iUsers, &tUsers),TD_LOG_ERROR_AND_THROW );
					for(int j = 0; j < iPropCount; j++) 
				    { 
						for(int k = 0; k < iUsers; k++) 
					    { 
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUsers[k], &pcPersonName),TD_LOG_ERROR_AND_THROW );
							if(tc_strcmp(pcAssigneevalue[j], pcPersonName) == 0) 
							{

								TERADYNE_TRACE_CALL(iStatus = SA_ask_user_login_group(tUsers[k], &tGroup), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = SA_ask_user_default_role_in_group(tUsers[k], tGroup, &roleTag), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(roleTag, &roleName), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tGroup, &grpName), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = SA_ask_user_identifier2(tUsers[k], &usrID), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = SA_find_groupmember_by_rolename(roleName, grpName, usrID, &iMembers, &tMembers), TD_LOG_ERROR_AND_THROW);
								//TERADYNE_TRACE_CALL(iStatus = SA_find_groupmembers(tUsers[k], tGroup, &iMembers, &tMembers), TD_LOG_ERROR_AND_THROW);
								//TERADYNE_TRACE_CALL(iStatus = SA_find_groupmember_by_user(tUsers[k], &iMembers, &tMembers), TD_LOG_ERROR_AND_THROW);
								if(iMembers > 0) 
                                {
									if(bTemp)
									{
										//removing the parcipants if exists for the object
										TERADYNE_TRACE_CALL(iStatus = ITEM_rev_ask_participants(targetObjTag,tParticipantType,&iParticipantCount, &tParticipantlist),TD_LOG_ERROR_AND_THROW );
										for(int l = 0; l < iParticipantCount; l++)
										{	
											TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_remove_participant(targetObjTag,tParticipantlist[l]),TD_LOG_ERROR_AND_THROW );
										}
										bTemp = false;
									}
									//Assign assignee as responsible party of current task.
									
									    POM_AM__set_application_bypass(true);
									    TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembers[0],tParticipantType,&tParticipant),TD_LOG_ERROR_AND_THROW );
									    TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,true),TD_LOG_ERROR_AND_THROW );
									    TERADYNE_TRACE_CALL(iStatus = ITEM_rev_add_participant(targetObjTag,tParticipant),TD_LOG_ERROR_AND_THROW );
									    TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(targetObjTag),TD_LOG_ERROR_AND_THROW );
									    TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,false),TD_LOG_ERROR_AND_THROW );
									    POM_AM__set_application_bypass(false);
										
									
								}
								break;
							}
							Custom_free(pcPersonName);
						}
						Custom_free(pcPersonName);
						Custom_free(roleName);
						Custom_free(grpName);
						Custom_free(usrID);
						Custom_free(tMembers);
						Custom_free(tParticipantlist);
					}
				}
				Custom_free(tRelObjects);
				Custom_free(pcTypeName);
				Custom_free(pcAssigneevalue);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	Custom_free(tUsers);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}