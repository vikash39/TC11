#include <workflow/teradyne_handlers.h>


EPM_decision_t ur_ecn_validation_impacted(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t *t_SecObj = NULL, *attachments = NULL, root_task = NULL, t_relation1 = NULL, *t_SecObj1 = NULL, t_rev = NULL, t_relation2 = NULL;
	tag_t *t_SecObj2 = NULL, t_item = NULLTAG;
	int iStatus, i = 0, count = 0, count1 = 0, j = 0, p = 0, count2 = 0, k = 0, propvalue = 0, c = 0, d = 0;
	char *sec_obj_type = NULL, *t_ObjType = NULL, *c_RelStatus = NULL, *c_PartRevObjString = NULL, *c_PartobjString = NULL, *c_ECNObjString = NULL, *c_objValue4 = NULL;

	decision = EPM_go;
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if ((tc_strcmp(sec_obj_type, "TD4StandardECNRevision") == 0) || (tc_strcmp(t_ObjType, "TD4ReleaseECNRevision") == 0))
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasImpactedItem", &t_relation1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation1, &count1, &t_SecObj1), TD_LOG_ERROR_AND_THROW);
			for (j = 0; j < count1; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[j], &t_ObjType), TD_LOG_ERROR_AND_THROW);

				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &c_PartobjString), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "release_status_list", &c_RelStatus), TD_LOG_ERROR_AND_THROW);

					if (tc_strcmp(c_RelStatus, "") != 0)
					{


						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(t_SecObj1[j], &t_item), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(t_item, &t_rev), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_rev, "object_string", &c_PartRevObjString), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &c_ECNObjString), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation2), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation2, &count2, &t_SecObj2), TD_LOG_ERROR_AND_THROW);
						if (count2 > 0)
						{
							for (k = 0; k < count2; k++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj2[k], "object_string", &c_objValue4), TD_LOG_ERROR_AND_THROW);
								if ((tc_strcmp(c_PartRevObjString, c_objValue4) == 0))
								{
									c++;
								}

								Custom_free(c_objValue4);
							}

						}
						else
						{
							decision = EPM_nogo;
							TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Revise_ImpacteItem_TO_SolutioItem, c_ECNObjString, c_PartobjString), TD_LOG_ERROR_AND_THROW);
							d++;
						}
						if (c > 0)
						{
							decision = EPM_go;
						}
						else
						{
							decision = EPM_nogo;
							TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Revise_ImpacteItem_TO_SolutioItem, c_ECNObjString, c_PartobjString), TD_LOG_ERROR_AND_THROW);
							d++;
						}

						Custom_free(c_PartRevObjString);
						Custom_free(c_ECNObjString);
						Custom_free(t_SecObj2);
						p++;
					}

					c = 0;
				}
			}

		}
	}
	if (d > 0)
	{
		decision = EPM_nogo;
	}
	Custom_free(t_SecObj1);
	Custom_free(attachments);
	return decision;
}
