/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_update_vendorpartstatus.cpp       
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateVPStatus action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Mar-2015						Kameshwaran D						Intital creation
#  29-Apr-2015					    Vijayasekhar                    	Added condition to check the suitable target objects
#  05-May-2015					    Vijayasekhar                    	Changed the relation from IMAN_specification to "Part to be Disconinued"
#  12-May-2015					    Haripriya                    	    Removed Asking Latest revision for Teradyne Parts in teradyne_part_related_to_vendor_part_operation Function
#  13-May-2015					    Haripriya                    	    Modified Updating SBM Form under Teradyne Parts in teradyne_part_related_to_vendor_part_operation Function
#  09-Jun-2015					    Haripriya                    	    Modified teradyne_update_vendorpartstatus to update property value in the relation
#  10-Jun-2015					    Vijayasekhar                    	Modified the definition teradyne_part_related_to_vendor_part_operation setting the preferred status from relation tag instead of Vendor part revision
#  09-Jul-2015					    Vijayasekhar                    	Bypassed while setting the PartInternalStatus attribute on SBM Form.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_update_vendorpartstatus
 * Description				: This function to update the prefered status of all relation between teradyne and vendor part
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_update_vendorpartstatus(EPM_action_message_t msg) {
	int iStatus					= ITK_ok,
		iCount					= 0;
		// Update preferred_status

	tag_t *tAttaches			= NULL,
		  tSecObjs              = NULLTAG;
		   
	char *pcAttachType			= NULL;

	string	szUpdateStatus	    = "Obsolete";

	const char * __function__	= "teradyne_update_vendorpartstatus";
	
	TERADYNE_TRACE_ENTER();

	try {

			if(msg.task != NULLTAG) { 
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);

				for(int i = 0; i < iCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_DISCON_DOC_REV_TYPE)) { 
					
						// Get Secondary object tag value
						TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tAttaches[i],TD_PART_TOBE_DISCON_REL,TD_MFG_PART_REV,0,&tSecObjs),TD_LOG_ERROR_AND_THROW);
						if(tSecObjs != NULLTAG)
						{
							tag_t tVendorPart= NULLTAG,tRelationTypeTag=NULLTAG,*tPriObjTag={NULLTAG},*tSecObjTag={NULLTAG};
							int iPriObjCount      = 0,iSecObjCount=0;
							//Get the Vendor part by using Vendor part revision
							TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSecObjs,&tVendorPart),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationTypeTag),TD_LOG_ERROR_AND_THROW);			
							TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tVendorPart,tRelationTypeTag,&iPriObjCount,&tPriObjTag),TD_LOG_ERROR_AND_THROW);

							for(int j = 0; j < iPriObjCount; j++) 
							{
								TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPriObjTag[j],tRelationTypeTag,&iSecObjCount,&tSecObjTag),TD_LOG_ERROR_AND_THROW);
								for(int k = 0; k < iSecObjCount; k++) 
								{
									tag_t tRelationTag = NULLTAG;
									//Getting the relation between VendorPart and TeradynePart.
									TERADYNE_TRACE_CALL(iStatus=GRM_find_relation(tPriObjTag[j],tSecObjTag[k],tRelationTypeTag,&tRelationTag),TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tRelationTag,TD_PREFERRED_STATUS_ATTR,szUpdateStatus),TD_LOG_ERROR_AND_THROW);
								}
								Custom_free(tSecObjTag);
							}

							Custom_free(tPriObjTag);
							
						}
					}
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/***************************************************************************************************
 * Function Name			: teradyne_get_preferred_status_value
 * Description				: This function to get the preffered status attribute value from vendor part
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tVendorTag (Tag)			 -  vendor part tag
 *							  szPreffered_Status (string)-  Return the preferred status value 
 *							 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. To all Vendor part attribute value
 * NOTES					: 
 ******************************************************************************************************/
int teradyne_get_preferred_status_value(tag_t tVendorTag,string *szPreffered_Status)
{
	int iStatus = ITK_ok;
	std::map<string,string> stVMRepRelationAttrMap;

	string szVMRepresent_Attr[]			= {TD_PREFERRED_STATUS_ATTR};

	const char * __function__		   = "teradyne_get_preferred_status_value";

	TERADYNE_TRACE_ENTER();
	try{
		
			std::list<string> strCommonAttrList( szVMRepresent_Attr, szVMRepresent_Attr + sizeof(szVMRepresent_Attr) / sizeof(string) );
			//Get the VMRepresent relation attribute preffered_status value
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tVendorTag,strCommonAttrList,stVMRepRelationAttrMap),TD_LOG_ERROR_AND_THROW);
		
			if ( stVMRepRelationAttrMap.size() > 0 )
			{
				szPreffered_Status->assign(stVMRepRelationAttrMap.find(TD_PREFERRED_STATUS_ATTR)->second);
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/***************************************************************************************************
 * Function Name			: teradyne_part_related_to_vendor_part_operation
 * Description				: This function to get the Teradyne part and Vendor part tag 
 *							  which are under VMRepresent relation.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRevTag (Tag)		-  Revision tag of attachment
 *							  iFlagCheck(I)		-  FLag to decide which operation to trigger
 *											[0] -> Invalid
 *											[1] -> Update preferred_status
 *											[2] -> Update Teradyne part DSP SBM Form
 *							 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. To all Vendor part revision in attachment tag
 *							  2. Get the Vendor part Tag
 *							  3. Get the All teradyne parts tag with respect to VMRepresent relation
 *							  4. Update the all relation attribute preffered_status to Obsolete
 * NOTES					: 
 ******************************************************************************************************/
int teradyne_part_related_to_vendor_part_operation(tag_t tRevTag,int iFlagCheck)
{
	int iStatus			= 0,
		iUpdateStatus	= 1,
		iUpdateDSPForm	= 2;

	string szPreffered_Status = "";

	std::vector<tag_t> tVendorPartRevTagVec;

	const char * __function__		   = "teradyne_part_related_to_vendor_part_operation";

	TERADYNE_TRACE_ENTER();

	try{	

			int		iObjCnt			 = 0;

			tag_t	*tFindObjTag	 = NULL,
					tRelationTag	 = NULLTAG;

			string	szSetStatusTo	= "Obsolete",
					szStatusRemove	= "Removed",
					szSetInterPrtTo	= "NO NEW USE-DISCONTINUED";

			//Get the IMAN_specification relation type tag
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PART_TOBE_DISCON_REL,&tRelationTag),TD_LOG_ERROR_AND_THROW);

			//Get Secondary objects of the attach object
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevTag,tRelationTag,&iObjCnt,&tFindObjTag),TD_LOG_ERROR_AND_THROW);
			for(int iPos=0; iPos< iObjCnt; iPos++)
			{
				/*Need to proccess only Vendor part object. Here we seperating those by pushing it to vector*/
				char *objecttype = NULL;
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tFindObjTag[iPos],&objecttype),TD_LOG_ERROR_AND_THROW);
				string strObjectType(objecttype);
				if(strObjectType.compare(TD_MFG_PART_REV) == 0)
				{
					tVendorPartRevTagVec.push_back(tFindObjTag[iPos]);
				}
				Custom_free(objecttype);
			}
			//Processing Vector containing Vendor parts revision one by one.
			size_t iSize = tVendorPartRevTagVec.size();
			for(int iVecPos = 0; iVecPos < iSize ; iVecPos++)
			{
				tag_t	tVendorPartRev	= tVendorPartRevTagVec.at(iVecPos),
						tVendorPart		= NULL,
						tRelationType	= NULLTAG,
						*tFindTeraObjTag= NULL;

				int		iObjCount		= 0;

				//Get the Vendor part by using Vendor part revision
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tVendorPartRev,&tVendorPart),TD_LOG_ERROR_AND_THROW);
				//Get relation type based on VMRepresents relation
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationType),TD_LOG_ERROR_AND_THROW);
				//Get the primary object which are in VMRepresents relation
				TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tVendorPart,tRelationType,&iObjCount,&tFindTeraObjTag),TD_LOG_ERROR_AND_THROW);
				//Loop to execute code for all the primary object
				for(int iSecPos = 0 ; iSecPos < iObjCount ; iSecPos++)
				{
					char*	ObjTerType			= NULL;
					int		iObjCountVendor		= 0;
					tag_t	*tFindTeraVendorTag	= {NULLTAG};

					TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tFindTeraObjTag[iSecPos],&ObjTerType),TD_LOG_ERROR_AND_THROW);
					//Check the object are Divisional Part revision /Commercial Part revision only.
					string strObjTer(ObjTerType);
					if(strObjTer.compare(TD_DIV_PART_REV) == 0 ||  strObjTer.compare(TD_COMM_PART_REV) == 0 )
					{
						Custom_free(ObjTerType);
						//Get the Vendor part attached with Teradyne parts in relation VMReperesnts
						TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tFindTeraObjTag[iSecPos],tRelationType,&iObjCountVendor,&tFindTeraVendorTag),TD_LOG_ERROR_AND_THROW);
						bool bUpdateSBMForm = false;	
						tag_t tSecObjs		= NULLTAG;
						for(int iPos = 0 ; iPos < iObjCountVendor ; iPos++)
						{
							TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tFindTeraVendorTag[iPos],&ObjTerType),TD_LOG_ERROR_AND_THROW);

							string strObjTerVendor(ObjTerType);
							if(strObjTerVendor.compare(TD_MFG_PART) == 0)
							{
								Custom_free(ObjTerType);
								tag_t tTerVendorPartRel = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tFindTeraObjTag[iSecPos],tFindTeraVendorTag[iPos],tRelationType,&tTerVendorPartRel),TD_LOG_ERROR_AND_THROW);
								if(iFlagCheck == iUpdateStatus)
								{
									//Update all the Relation between Teradyne part and Vendor part with preferred_status to 'Obsolete'.
									TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tTerVendorPartRel,TD_PREFERRED_STATUS_ATTR,szSetStatusTo), TD_LOG_ERROR_AND_THROW);
									
								}
								else if(iFlagCheck == iUpdateDSPForm)
								{
									tag_t tRevTag	= NULLTAG;
									szPreffered_Status = "";
								    TERADYNE_TRACE_CALL(iStatus = teradyne_get_preferred_status_value(tTerVendorPartRel,&szPreffered_Status),TD_LOG_ERROR_AND_THROW);
									if(szPreffered_Status.length() > 0 )
									{	
										if(szPreffered_Status.compare(szSetStatusTo) == 0 || szPreffered_Status.compare(szStatusRemove) == 0) {
										
											bUpdateSBMForm = true;
											continue;
										}
									}
									else 
									{
										bUpdateSBMForm = false;
										break;
									}
								}
							}
						}
						if(bUpdateSBMForm)
						{ //Get the SBM Form tag 
							TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tFindTeraObjTag[iSecPos],TD_DIS_SPEC_REL_NAME,TD_SBM_FORM_TYPE,0,&tSecObjs),TD_LOG_ERROR_AND_THROW);
							if (tSecObjs != NULLTAG )
							{
								//Calling function to set the property value
								POM_AM__set_application_bypass(true);
								TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tSecObjs,TD_INTERNAL_PART_STATUS_ATTR,szSetInterPrtTo), TD_LOG_ERROR_AND_THROW);
								POM_AM__set_application_bypass(false);
							}
						}
					}
				}
			}
	   }catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	tVendorPartRevTagVec.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
