/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_trace.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Trace handler for debugging         
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  03-Feb-2015						 kameshwaran						Added type conversion to avoid warning during compilation.
#  22-Sep-2015                       Manimaran                          Removed the macro to fix the user preference "TERADYNE_LIB_TRACE" not found error.
#  $HISTORY$                    
#  =================================================================================================*/ 

#include <common/teradyne_trace.h>
#include <stdio.h>

// Global Constants for Trace Initialization
static int		globalTD4TraceIndention				= 0;
static bool	    globalTD4TraceInitialized			= false	;
static bool	    globalTD4TraceIsOn					= false	;


/*******************************************************************************
 * Function Name	: teradyne_get_error_text
 * Description		: Gets the severity error message from the error stack
 *                    based on the inpurt error code
 *
 * REQUIRED HEADERS	: 
 * INPUT PARAMS		: int iErrorCode, char** msg
 *                    
 * RETURN VALUE		: int iStatus - Error Code or Success Code
 * GLOBALS USED		:
 * FUNCTIONS CALLED	:
 *
 * ALGORITHM		:
 *
 *
 * NOTES			:
 *------------------------------------------------------------------------------
 * Date         	Name                 Description of Change
 * 30-Oct.-2014   	Vivek		         Initial Code
 *------------------------------------------------------------------------------
 */
int teradyne_get_error_text( int iErrorCode, char** msg )
{
	int iStatus = ITK_ok;
	int iErrorCount;
	int* iSeverities;
	int* iFails;
	char** cTexts = NULL;

	try
	{
		//Get the errors on stack
		iStatus = EMH_ask_errors( &iErrorCount, (const int**)&iSeverities, (const int**)&iFails, (const char***)&cTexts );
		if( iErrorCount > 0 )
		{
			for( int i = (iErrorCount -1); i >= 0; i-- )
			{
				//check whether the error code matches the thrown error code
				if( iErrorCode == iFails[i] && cTexts[i] != NULL )
				{
					*msg =  (char*)MEM_alloc( (int)(tc_strlen( cTexts[i] ) + 1 ) * sizeof(char));
					tc_strcpy( (*msg), cTexts[i] );
					break;
				}
			}
		}
	}
	catch(...)
	{
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("teradyne_get_error_text: Unhandled Exception.\n" );
		}
	}
	return iStatus;
}

/*******************************************************************************
 * Function Name	: td4_is_trace_handler_on
 * Description		: Checks if the preference TERADYNE_LIB_TRACE is set and value is TRUE OR ON
                      or YES and initializes the logger
 *
 * REQUIRED HEADERS	: 
 * INPUT PARAMS		: 
 *                    
 * RETURN VALUE		: bool - true or false
 * GLOBALS USED		:
 * FUNCTIONS CALLED	:
 *
 * ALGORITHM		:
 *
 *
 * NOTES			:
 *------------------------------------------------------------------------------
 * Date         	Name                 Description of Change
 * 30-Oct.-2014   	Vivek		         Initial Code
 *------------------------------------------------------------------------------
 */
bool td4_is_trace_handler_on ( void )
{
	char	*pcTrace = NULL;

	if ( !globalTD4TraceInitialized )
	{
		int		iStatus = ITK_ok	;

		// Set the current search scope to user
		iStatus = PREF_ask_char_value_at_location ( "TERADYNE_LIB_TRACE" , TC_preference_user, 0 , &pcTrace );

		// Not found, look for site preference
		if ( ( iStatus != ITK_ok ) || ( pcTrace == NULL ) || ( tc_strlen ( pcTrace ) <= 0 ) )
		{
			// Set the current search scope to site
			TERADYNE_ITKCALL_F(iStatus = PREF_ask_char_value_at_location ( "TERADYNE_LIB_TRACE" , TC_preference_site, 0 , &pcTrace ));
		}

		if ( ( pcTrace != NULL ) && ( tc_strlen ( pcTrace ) > 0 ) )
		{
			if ( tc_strcmp ( pcTrace, "ON" ) == 0 || tc_strcmp ( pcTrace, "YES" ) == 0 || tc_strcmp ( pcTrace, "TRUE" ) == 0) 
			{
				globalTD4TraceIsOn = true ;
			}
		}

		globalTD4TraceInitialized = true;
	}

	if(pcTrace != NULL) {
		MEM_free(pcTrace);
		pcTrace = NULL;
	}
	return globalTD4TraceIsOn;
}

void teradyne_log_local_time(void)
{
	struct timeb timebuffer ;
	ftime( &timebuffer ) ;

	time_t tt = timebuffer.time ;
	struct tm *ptm = localtime( &tt ) ;
	date_t curDate ;
	curDate.year = ptm -> tm_year + 1900 ;
	curDate.month = ptm -> tm_mon ;
	curDate.day = ptm -> tm_mday ;
	curDate.hour = ptm -> tm_hour ;
	curDate.minute = ptm -> tm_min ;
	curDate.second = ptm -> tm_sec ;

	int msec = timebuffer.millitm ;

	char *strDate = NULL ;
	DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;

	TC_write_syslog( "\n%s.%03d", strDate, msec );

	return;
}


void teradyne_change_indent ( const char cChange )
{
	if ( cChange == '+' ) globalTD4TraceIndention = globalTD4TraceIndention + 3 ;
	else if ( cChange == '-' ) globalTD4TraceIndention = globalTD4TraceIndention - 3 ;
	return ;
}

void teradyne_printIndent()
{
	char	cIndentFmt[128+1] = ""	; 
	sprintf ( cIndentFmt , "%%%ds" , globalTD4TraceIndention ) ;
	TC_write_syslog( cIndentFmt , "" ) ; 
}