/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_common.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains Common functions and methods          
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  31-Oct-2014                       Haripriya                          Added teradyne_getproperty_values,teradyne_setproperty_value functions
#  10-Nov-2014                       Haripriya                          Added teradyne_getprimaryorsecondary_relation_objecttag
#  11-Nov-2014                       Vijayasekhar                       Added teradyne_current_timestamp                                                                     
#  14-Nov-2014                       Vijayasekhar                       Added declarations for common function related to handlers
#  14-Nov-2014                       Haripriya                          Added teradyne_create_object function
#  17-Nov-2014                       Vijayasekhar                       Added definitions for getting target objects of workflow process
#  18-Nov-2014                       Vivek                              Modified teradyne_current_timestamp to free memory block																	
#  28-Jan-2015                       Haripriya                          Added teradyne_send_os_mail,teradyne_os_mail_body,teradyne_ask_person_mailaddress functions
#  30-Jan-2015                       Haripriya                          Removed property value length check in teradyne_setproperty_value function
#  03-Feb-2015						 Kameshwaran						Added NULLTAG check to all the function where tag_t is used as argument as reference.
#  09-Feb-2015						 Selvi								Added teradyne_find_latest_released_revision.
#  12-Feb-2015                       Vijayasekhar                       Added Definition for teradyne_ask_item_id_from_rev_tag
#  12-Feb-2015						 Selvi								Added teradyne_get_handler_opts function.
#  16-Feb-2015                       Haripriya                          Modified jobname in teradyne_create_process
#  18-Feb-2015						 Vijayasekhar						Modified the function definition teradyne_getprimaryorsecondary_relation_objecttag
#  19-Feb-2015						 Kameshwaran D						Added typecasting to avoid warnings while compiling source code
#  12-Mar-2015						 Vijayasekhar						Modified the function definition teradyne_get_attachments
#  16-Mar-2015						 Selvi						        Added teradyne_is_workspace_object and teradyne_generate_tokens functions.
#  16-Mar-2015						 Selvi						        Modified teradyne_getproperty_values function to retrieve all type of Property values.
#  17-Mar-2015						 Selvi						        Added teradyne_create_and_attach_dataset functions.
#  17-Mar-2015						 Haripriya						    Added teradyne_get_arrayproperty_value,teradyne_set_arrayproperty_value functions
#  18-Mar-2015						 Vijayasekhar						Added function definition teradyne_parse_input_date and teradyne_get_week_from_date.
#  20-Mar-2015						 Vijayasekhar						Added function definition teradyne_assign_task_to_users.
#  24-Mar-2015						 Vijayasekhar						Added function definition teradyne_list_all_revisions_from_revtag
#  30-Mar-2015						 Vijayasekhar						Modified the function definition teradyne_current_timestamp
#  15-Apr-2015						 Haripriya						    Modified teradyne_setproperty_value functions.
#  17-Apr-2015						 Selvi						        Added teredyne_replace_string
#  20-Apr-2015                       Haripriya                          Modified teradyne_get_arrayproperty_value for ue_errors
#  22-Apr-2015                       Selvi                              Modified teradyne_getproperty_values.
#  22-Apr-2015                       Haripriya                          Modified teradyne_get_arrayproperty_value.
#  23-Apr-2015                       Haripriya                          Modified teradyne_get_arrayproperty_value.
#  24-Apr-2015                       Haripriya                          Modified teradyne_get_arrayproperty_value.
#  07-May-2015                       Vijayasekhar						Added function definition teradyne_delete_relation
#  07-May-2015                       Selvi                              Added Function teradyne_find_execute_qry and removed teradyne_find_latest_released_revision.
#  29-May-2015						 Kameshwaran D						Added Function teradyne_UpdateTerPartRevComplAtr used in both for extensions and handlers also.
#  04-Jun-2015                       Vijayasekhar                    	Modified the function definition teradyne_UpdateTerPartRevComplAtr
#  09-Jun-2015						 Haripriya  						Removed Function teradyne_UpdateTerPartRevComplAtr and Modified teradyne_setproperty_value function.
#  10-Jun-2015						 Haripriya  						Modified teradyne_create_process function for initiating workflow on vendor part .
#  07-Jul-2015                       Haripriya                          Added teradyne_find_prev_revision function
#  21-Jul-2015					     Haripriya                      	Modified teradyne_get_arrayproperty_value for  merging the vectors.
#  05-Oct-2015                       Deepachitra                        Modified teradyne_create_process function to Modify Job name for ECN.
#  12-Nov-2015                       Manimaran                          Added teradyne_convert_vector_to_array function.
#  08-Dec-2015                       Manimaran                          Added code for Dataset workflow job name in teradyne_create_process function.
#  17-Dec-2015						 Janani								Added new function teradyne_create_dataset.
#  22-Dec-2015                       Manimaran                          Added teradyne_latest_rev_from_rev function.
#  22-Dec-2015                       Vivek                              Added new function splitString
#  27-Dec-2015						 kameshwaran						Remove print statement
#  12-Jan-2016						 Kameshwaran						Added logical condition to call import file if it is binary dataset format
#  29-Jul-2016						 Kameshwaran						Replaced Project with Synopsis (20 characters) on the create process task name.
#  02-Sep-2016                       Manimaran                          Reverted the synopsis change done for BT1523.
#  31-Jan-2017						 Karl Reimann						Added teradyneBuildSubscriptionSubject and teradyneBuildSubscriptionBodyContent for subscription workaround
#  07-May-2018						 Marjorie							Added TD4OPSTask in teradyne_create_process.
#  $HISTORY$
#  =================================================================================================*/ 

#include <common/teradyne_common.h>

bool gNULLPropertyExecution = false;

/*******************************************************************************
 * Function Name			: teradyne_ask_object_display_type
 * Description				: This function will get the object type display name for given tag.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject     (I)  - object tag
 *							  pcTypeName  (OF)  - object type
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 *
 * NOTES					:
 ******************************************************************************/
 int teradyne_ask_object_display_type(tag_t tObject,char** pcTypeName)
 {
	int iStatus                 = ITK_ok;
	tag_t tagObjType            = NULLTAG;

	const char * __function__    = "teradyne_ask_object_display_type" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_object_type( tObject,&tagObjType),TD_LOG_ERROR_AND_THROW );

			if (tagObjType != NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_display_name( tagObjType, pcTypeName ),TD_LOG_ERROR_AND_THROW );
			}			
		}
	}
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}


/*******************************************************************************
 * Function Name			: teradyne_ask_object_type
 * Description				: This function will get the object type name for given tag.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject     (I)  - object tag
 *							  pcTypeName  (OF)  - object type
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 *
 * NOTES					:
 ******************************************************************************/
 int teradyne_ask_object_type(tag_t tObject,char** pcTypeName)
 {
	int iStatus                 = ITK_ok;
	tag_t tagObjType            = NULLTAG;

	const char * __function__    = "teradyne_ask_object_type" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_object_type( tObject,&tagObjType),TD_LOG_ERROR_AND_THROW );

			if (tagObjType != NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_name2( tagObjType, pcTypeName ),TD_LOG_ERROR_AND_THROW );
			}			
		}
	}
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}


/*******************************************************************************
 * Function Name			: teradyne_create_process
 * Description				: This function will launch the workflow process for the given
 *                            object and attach it as target or reference attachment
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strProcessTemplateName  (I) - Process template name
 *							  strDescription          (I) - Process description
 *                            iAttachmentType         (I) - Attachment type (target or reference)
 *                            tAttachmentObject       (I) - Object to be attached
 *                            tNewProcess             (O) - New process tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1.	Function will check if the given process template found in TC  
 *									and create the process for the given target object. 
 *							  2.	If process description is not given then assigns the default description.
 *                            3.	If attachment type is not given then defaults it to target attachment.
 *
 * NOTES					:
 ******************************************************************************/
 int teradyne_create_process(string strProcessTemplateName,string strDescription,int iAttachmentType,tag_t tAttachmentObject,tag_t *tNewProcess)
{
	int iStatus                   = ITK_ok;
	int iCount                    = 0 ;
	int iSeqId                    = 0;
	tag_t tProcessTemplate		  = NULLTAG;
	string szCommon_Attr[]        = {TD_ITEM_ID_ATTR,TD_ITEM_REV_ID_ATTR,TD_OBJECT_NAME_ATTR},
		   szJobname              = "";
	char *pcObjectType            = NULL,
		*pcPrimaryproject         = NULL,
	    *pcEcntype                = NULL,
		*pcPrimaryprojects        =NULL,
		*pcReason                 =NULL;

	char *pECNFor = NULL, *pLifecycle = NULL;

	std::map<string,string> strWorkflowValueMap;
	const char * __function__     = "teradyne_create_process" ;
	TERADYNE_TRACE_ENTER();

	if ( tNewProcess != NULLTAG )
			*tNewProcess = NULLTAG;

	try
	{
		if(tAttachmentObject != NULLTAG)
		{
			if(strProcessTemplateName != "" && strProcessTemplateName.length() > 0)
			{
				TERADYNE_TRACE_CALL ( iStatus= EPM_find_process_template(strProcessTemplateName.c_str(),&tProcessTemplate),TD_LOG_ERROR_AND_THROW );

				if(tProcessTemplate != NULLTAG)
				{
					iCount++;

					//Check if process description is defined else provide default description
					if(strDescription == "" || strDescription.length() <= 0)
						strDescription.assign(TD_DEFAULT_PROCESS_DESCRIPTION);

					//Check if attachment type is given else default to target attachment
					if( iAttachmentType != EPM_target_attachment || iAttachmentType != EPM_reference_attachment)
						iAttachmentType = EPM_target_attachment;

					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachmentObject,&pcObjectType),TD_LOG_ERROR_AND_THROW);

					if(tc_strcmp(pcObjectType, TD_TER_CSV)==0) {
						char *pcItemId = NULL;
						char *pcRevId  = NULL;
						string szBOMImport = "BOMImport";

						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ITEMID_ATTR, &pcItemId),TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_REVID_ATTR, &pcRevId),TD_LOG_ERROR_AND_THROW);
						szJobname.append(pcItemId).append("/").append(pcRevId).append("-").append(szBOMImport);
						Custom_free(pcItemId);
						Custom_free(pcRevId);
					}
					else if(tc_strcmp(pcObjectType,TD_MFG_PART)==0)
					{
						char *pcItemId = NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject,TD_ITEM_ID_ATTR,&pcItemId),TD_LOG_ERROR_AND_THROW);						
						szJobname.append(pcItemId);
					}
					else if(tc_strcmp(pcObjectType,TD_OPS_TASK_REV)==0)
					{
						char *pcItemId = NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject,TD_OBJECT_NAME_ATTR,&pcItemId),TD_LOG_ERROR_AND_THROW);						
						szJobname.append(pcItemId);
					}
					else
					{
						std::list<string> strCommonAttrList( szCommon_Attr, szCommon_Attr + sizeof(szCommon_Attr) / sizeof(string) );
						//calling function to get common property values and objecttype
						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttachmentObject,strCommonAttrList,strWorkflowValueMap),TD_LOG_ERROR_AND_THROW);
					
						if ( strWorkflowValueMap.size() > 0 )
						{
							if((!tc_strcmp(pcObjectType,TD_DIV_PART_REV)) || (!tc_strcmp(pcObjectType,TD_COMM_PART_REV)))
							{
								szJobname.append(strWorkflowValueMap.find(TD_ITEM_ID_ATTR)->second).append("/").append(strWorkflowValueMap.find(TD_ITEM_REV_ID_ATTR)->second).append("-").append(strProcessTemplateName);
							}
							else if (!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE))
							{

								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_PRIMARY_PRJ, &pcPrimaryproject), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_TYPE_ATTR, &pcEcntype), TD_LOG_ERROR_AND_THROW);

								//added by anandha bharathi FOR UR Requirement

								// "Release ECN"+"-"+Project+"-"+ECN Type+"-"+ECN For+"-"+"LC:"+ Lifecycle Status (Job Name Change)
								TC_write_syslog("Inside else if condition !tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE):");
								iStatus = ur_validateOwningGroup();
								if (iStatus == 0)
								{

									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_FOR_ATTR, &pECNFor), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_LIFE_CYCLE_STATUS_ATTR, &pLifecycle), TD_LOG_ERROR_AND_THROW);
									string strReleaseECn = "Release ECN";
									szJobname.append(strReleaseECn.append("-").append(pcPrimaryproject).append("-").append(pcEcntype).append("-").append(pECNFor).append("-").append("LC:").append(pLifecycle));

									TC_write_syslog("szJobname : %s", szJobname);
								}
								else
								{
									szJobname.append(strWorkflowValueMap.find(TD_ITEM_ID_ATTR)->second).append("/").append(strWorkflowValueMap.find(TD_ITEM_REV_ID_ATTR)->second).append("-").append(pcPrimaryproject).append("-").append(pcEcntype);
								}
							}
							else if(!(tc_strcmp(pcObjectType,TD_STD_ECN_REV_TYPE))||(!tc_strcmp(pcObjectType,TD_PROTOBOM_ECN_REV_TYPE)) ||(!tc_strcmp(pcObjectType,TD_PROTOPART_ECN_REV_TYPE)))
							{
							
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_PRIMARY_PRJ, &pcPrimaryprojects), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachmentObject, TD_ECN_REASON, &pcReason), TD_LOG_ERROR_AND_THROW);
							
						    szJobname.append(strWorkflowValueMap.find(TD_ITEM_ID_ATTR)->second).append("/").append(strWorkflowValueMap.find(TD_ITEM_REV_ID_ATTR)->second).append("-").append(pcPrimaryprojects).append("-").append(pcReason);
                            }
							else
							{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_int(tAttachmentObject,TD_SEQUENCE_ID_ATTR,&iSeqId),TD_LOG_ERROR_AND_THROW);
		
							stringstream convert; 
							convert << iSeqId;
							szJobname.append(strWorkflowValueMap.find(TD_ITEM_ID_ATTR)->second).append("/").append(strWorkflowValueMap.find(TD_ITEM_REV_ID_ATTR)->second).append(TD_SEMICOLON_CONSTANT).append(convert.str()).append("-").append(strWorkflowValueMap.find(TD_OBJECT_NAME_ATTR)->second);

							}
						 }
					}
					//launch process and add targets
					TERADYNE_TRACE_CALL ( iStatus = EPM_create_process ( szJobname.c_str(), strDescription.c_str(),
																		 tProcessTemplate, iCount,&tAttachmentObject, &iAttachmentType, tNewProcess) ,
																		 TD_LOG_ERROR_AND_THROW) ;
				}
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pECNFor);
	Custom_free(pLifecycle);

	Custom_free(pcObjectType);
	Custom_free(pcPrimaryprojects);
	Custom_free(pcPrimaryproject);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_get_current_user_and_group
 * Description				: This function will get the current logged in user's name, 
 *                            group name, group full name, User tag and Group tag
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcUsername  (OF) - Current logged in user name
 *                            pcRoleName (OF) - Current logged in user role name
 *                            pcGroupName (OF) - Current logged in group name
 *                            pcGroupFullName (OF) - Current logged in group hierarchial name
 *                            tUserTag (O) - User tag
 *                            tGroupTag (O) - Group tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
 int teradyne_get_current_user_and_group(char** pcUsername, char** pcRoleName, char** pcGroupName, char** pcGroupFullName, tag_t* tUserTag, tag_t* tRoleTag, tag_t* tGroupTag)
{
	int iStatus = ITK_ok;

	const char * __function__     = "teradyne_get_current_user_and_group" ;
	TERADYNE_TRACE_ENTER();

	if(tUserTag!=NULLTAG)
		*tUserTag = NULLTAG;
	if(tRoleTag!=NULLTAG)
		*tRoleTag = NULLTAG;
	if(tGroupTag!=NULLTAG)
		*tGroupTag = NULLTAG;

	try
	{
		TERADYNE_TRACE_CALL(iStatus = POM_get_user(pcUsername,tUserTag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = POM_ask_group(pcGroupName,tGroupTag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = POM_ask_group_name(*tGroupTag,pcGroupFullName),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = SA_ask_current_role(tRoleTag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(*tRoleTag,pcRoleName),TD_LOG_ERROR_AND_THROW);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_current_timestamp
 * Description				: this function will return current time stamp in the 
 *                            format YYYY-MM-DD HH:MM:SS(EX:2014-11-10 15:09:24)
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strFormat (I)   - Format for the time stamp
 *							: strTimeStamp (O) - Output time stamp
 *							: curDate(O)	-	Current date date_t	
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_current_timestamp(string strFormat, string &strTimeStamp, date_t &curDate)
{
	int iStatus = ITK_ok;
	char *strDate = NULL ;

	const char * __function__     = "teradyne_current_timestamp" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		struct timeb timebuffer ;
		ftime( &timebuffer ) ;

		time_t tt = timebuffer.time ;
		struct tm *ptm = localtime( &tt ) ;
		//date_t curDate ;
		curDate.year = ptm -> tm_year + 1900 ;
		curDate.month = ptm -> tm_mon ;
		curDate.day = ptm -> tm_mday ;
		curDate.hour = ptm -> tm_hour ;
		curDate.minute = ptm -> tm_min ;
		curDate.second = ptm -> tm_sec ;
		if(strFormat.length() > 0) {
	
			TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( curDate, strFormat.c_str(), &strDate),TD_LOG_ERROR_AND_THROW) ;
			strTimeStamp = strDate;
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(strDate);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus; 
}

/*******************************************************************************
* Function Name	    : teradyne_setproperty_value
* Description		:  sets the value for given propertyname and tag 
*                    
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tRevtag (I)    - objecttag
*                     szPropname (I) - AttributeName
*                     pcPropvalue (I)- Attributevalue
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :sets the value on given propertyname for given object
*
*
* NOTES				:
******************************************************************************/
int teradyne_setproperty_value(tag_t tRevtag,string szPropname,string strPropvalue) 
{
	//Declartion and Initialization of Local Variables
	int   iStatus           = ITK_ok;
    bool bisverdict         = true;
	  PROP_value_type_t  valtype;
	  char *pcTypeName=NULL;
	char* __function__ = "teradyne_setproperty_value";
	TERADYNE_TRACE_ENTER();

	try
	{
		if( szPropname.length() > 0 && tRevtag!=NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tRevtag,&bisverdict),TD_LOG_ERROR_AND_THROW);
			if(!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tRevtag,true),TD_LOG_ERROR_AND_THROW);				
			}
			TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_type(tRevtag,szPropname.c_str(),&valtype,&pcTypeName),TD_LOG_ERROR_AND_THROW);	
			if(valtype == PROP_string)
			{
				TERADYNE_TRACE_CALL(iStatus=AOM_set_value_string(tRevtag,szPropname.c_str(),strPropvalue.c_str()),TD_LOG_ERROR_AND_THROW);			
			}
			else if(valtype == PROP_int)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_int(tRevtag,szPropname.c_str(),atoi(strPropvalue.c_str())),TD_LOG_ERROR_AND_THROW);					
			}
			else if(valtype == PROP_double || valtype == PROP_float)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_double(tRevtag,szPropname.c_str(),atoi(strPropvalue.c_str())),TD_LOG_ERROR_AND_THROW);					
			}
			else if(valtype == PROP_logical )
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tRevtag,szPropname.c_str(),atoi(strPropvalue.c_str())),TD_LOG_ERROR_AND_THROW);					
			}
			TERADYNE_TRACE_CALL(iStatus= AOM_save_without_extensions(tRevtag),TD_LOG_ERROR_AND_THROW);
			if(!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tRevtag,false),TD_LOG_ERROR_AND_THROW);				
			}		  
		}	
	}
	catch(...)
	{
		AOM_refresh(tRevtag,false);		
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
* Function Name	    : teradyne_getproperty_values  
* Description		: This function will read the string attributes from the given object whose properties
*                     are passed as an array
*                    
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tRevtag   (I)           - objecttag
*                     szDivRevAttr (I)        - Property Names
*                     iArrSize (I)            - Size 
*                     strPropNameValueMap (O) - Map to store property name and value pair
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		:
*
*
* NOTES			:
******************************************************************************/
void setgNULLPropertyExecution(bool setBool)
{
    gNULLPropertyExecution = setBool;
}

int teradyne_getproperty_values(tag_t tRevTag,std::list<string> strAttr,std::map<string,string> &strPropNameValueMap) 
 {
	//Declartion and Initialization of Local Variables
	int   iStatus           = ITK_ok,
          iValCount			= 0,
          iAttribute		= 0,
          iPropVals         = 0;

	char cValue				= NULL,
	     *cValues			= NULL,
	     *pcAttrValue       = NULL,
	     *pcTypeName        = NULL,
	     **pcStrAttrVals    = NULL,
	     *pcObjectString    = NULL;

	double dblAttribute     = 0.0;

	date_t dtAttribute;

	bool isWSO              = false;
	bool isContinue			= true;

        tag_t tagAttribute     = NULL,
	      *tpAttributes    = NULL;

        PROP_value_type_t  valtype;

	char* __function__ = "teradyne_getproperty_values";
	TERADYNE_TRACE_ENTER();
			
	TC_write_syslog("Inside  teradyne_getproperty_values");
	try
	{
		if (!strPropNameValueMap.empty())
			strPropNameValueMap.clear();

		if ( tRevTag != NULLTAG )
		{
			for (std::list<string>::iterator it = strAttr.begin(); it != strAttr.end(); it++)
			{
				if( ((string)*it).empty() )
					continue;

				if (tc_strcmp(((string)*it).c_str(), "NULL") == 0)
               	{
					isContinue = false;						
					pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
					strcpy(pcAttrValue,"");
				}
				
				if((gNULLPropertyExecution) && (tc_strcmp(((string)*it).c_str(), "NULL") != 0))
               	{
					iStatus = AOM_ask_max_num_elements(tRevTag, ((string)*it).c_str(), &iPropVals);
				    if(iStatus != ITK_ok)
					{
						iStatus = 0;
						isContinue = false;
						pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
						strcpy(pcAttrValue,"");
					} 
					else 
						isContinue = true;
				}
				if(isContinue)
               	{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_max_num_elements(tRevTag, ((string)*it).c_str(), &iPropVals),TD_LOG_ERROR_AND_THROW);
				
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_type(tRevTag,((string)*it).c_str(),&valtype,&pcTypeName),TD_LOG_ERROR_AND_THROW);
					if(iPropVals == 1)
					{			  
						//check if string
						if(valtype == PROP_string)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag,((string)*it).c_str(),&pcAttrValue),TD_LOG_ERROR_AND_THROW);						
						}
						 //check if char
						else if(valtype == PROP_char)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_char(tRevTag,((string)*it).c_str(),&cValue),TD_LOG_ERROR_AND_THROW);
							pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
							sprintf(pcAttrValue,"%c",cValue);
						}
						//check if date
						else if(valtype == PROP_date)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(tRevTag,((string)*it).c_str(), &dtAttribute),TD_LOG_ERROR_AND_THROW);	
							TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( dtAttribute, TD_DATE_YMD_CONSTANT, &pcAttrValue),TD_LOG_ERROR_AND_THROW);	
    					}
						//check if double or float
						else if(valtype == PROP_double || valtype == PROP_float)
						{		
							char pcBuffer[1024];
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevTag,((string)*it).c_str(),&dblAttribute),TD_LOG_ERROR_AND_THROW);
							sprintf(pcBuffer,"%f",dblAttribute);
							pcAttrValue = (char *) MEM_alloc(sizeof(char) * (int)(tc_strlen(pcBuffer)+ 1) );
							sprintf(pcAttrValue,"%f",dblAttribute);
						}
						//Check if logical
						else if(valtype == PROP_logical)
						{
							logical isLogicalAttribute = false;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tRevTag,((string)*it).c_str(),&isLogicalAttribute),TD_LOG_ERROR_AND_THROW);	
							pcAttrValue = (char *) MEM_alloc(sizeof(char)*5);
							if(isLogicalAttribute)
								sprintf(pcAttrValue,"%s","true");
							else
								sprintf(pcAttrValue,"%s","false");
						}
						//check if int or short
						else if(valtype == PROP_int || valtype == PROP_short)
						{
							char pcBuffer[1024];
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_int(tRevTag,((string)*it).c_str(), &iAttribute),TD_LOG_ERROR_AND_THROW);					
							sprintf(pcBuffer,"%d",iAttribute);
							pcAttrValue = (char *) MEM_alloc(sizeof(char)* (int)(tc_strlen(pcBuffer)+ 1));
							sprintf(pcAttrValue,"%d",iAttribute);
						}
				
						//check if typed reference          
						else if(valtype == PROP_typed_reference || valtype == PROP_untyped_reference)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tRevTag,((string)*it).c_str(),&tagAttribute),TD_LOG_ERROR_AND_THROW);					
							isWSO = teradyne_is_workspace_object(tagAttribute);
							if(isWSO == true)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_id_string(tagAttribute, &pcAttrValue),TD_LOG_ERROR_AND_THROW);	
							}						
							else 
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tagAttribute,TD_OBJECT_STRING,&pcAttrValue),TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					else if(iPropVals == -1 || iPropVals > 1)
					{
						//check if string
						if(valtype == PROP_string)
						{
							std::string strAttributeVals("");
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tRevTag,((string)*it).c_str(), &iValCount, &pcStrAttrVals),TD_LOG_ERROR_AND_THROW);				
							for(int iCount = 0; iCount < iValCount; iCount++)
							{
								if(iCount == 0)
								{
									strAttributeVals.assign(pcStrAttrVals[iCount]);
								}
								else
								{
									strAttributeVals.append(",");
									strAttributeVals.append(pcStrAttrVals[iCount]);
								}
							}

							pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int) (strAttributeVals.length() + 1));
							sprintf(pcAttrValue,"%s",strAttributeVals.c_str());
							Custom_free(pcStrAttrVals);
						}
						//check if char
						else if(valtype == PROP_char)
						{
							char pcBuffer[1];
							std::string strAttrVals("");

							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_chars(tRevTag, ((string)*it).c_str(), &iValCount, &cValues),TD_LOG_ERROR_AND_THROW);
							for(int iCount = 0; iCount < iValCount; iCount++)
							{
								sprintf(pcBuffer,"%c",cValues[iCount]);
								if(iCount == 0)
								{
									strAttrVals.assign(pcBuffer);
								}
								else
								{
									strAttrVals.append(",");
									strAttrVals.append(pcBuffer);
								}
							}
							pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int)(strAttrVals.length() + 1));
							sprintf(pcAttrValue,"%s",strAttrVals.c_str());
							Custom_free(pcStrAttrVals);
							Custom_free(cValues);
						}
						else if(valtype == PROP_typed_reference || valtype == PROP_untyped_reference)
						{
							std::string strAttrVals("");
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tRevTag, ((string)*it).c_str(), &iValCount, &tpAttributes),TD_LOG_ERROR_AND_THROW);
						
							for(int iCount = 0; iCount < iValCount; iCount++)
							{							
								isWSO = teradyne_is_workspace_object(tpAttributes[iCount]);							
								if(isWSO == true)
								{
									TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_id_string(tpAttributes[iCount], &pcObjectString),TD_LOG_ERROR_AND_THROW);
								}
								else
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tpAttributes[iCount],TD_OBJECT_STRING, &pcObjectString),TD_LOG_ERROR_AND_THROW);
								}

								if(iCount == 0)
								{
									strAttrVals.assign(pcObjectString);
								}
								else
								{
									strAttrVals.append(",");
									strAttrVals.append(pcObjectString);
								}
								Custom_free(pcObjectString);
							}
							pcAttrValue = (char*)MEM_alloc(sizeof(char) * (int)(strAttrVals.length() +1 ));
							sprintf(pcAttrValue,"%s",strAttrVals.c_str());
							Custom_free(tpAttributes);
						}
					}
					Custom_free(pcTypeName);
				}				
				strPropNameValueMap.insert(::make_pair((string)*it,(string)pcAttrValue));
				Custom_free(pcAttrValue);				
			}
		}
	}		
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TC_write_syslog("Outside  teradyne_getproperty_values");
	Custom_free(pcAttrValue);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name	    : teradyne_getprimaryorsecondary_relation_objecttag
* Description		: Returns the Objecttag if the giventype object is found
*                    
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tObjecttag  (I)     - Objecttag
*                     szRelName (I)       - RelationName
*                     *pcObjecttype (I)   - ObjectType
*                     *tObjFoundTag (O)    - FoundObjectTag
*                     iRelType (I)        - if value is 0,finds primary objects 
                                            else ,finds secondary objects.

* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			:
*
*
* NOTES				:
******************************************************************************/
int teradyne_getprimaryorsecondary_relation_objecttag(tag_t tObjecttag,string szRelName,string szObjecttype,int iRelType,tag_t *tObjFoundTag) 
{
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok,
		iObjCount               = 0;

	tag_t  tRelationTag        = NULLTAG,
		   *tFindObjTag        = NULL;

	char *pcTypeName            = NULL;

	char* __function__ = "teradyne_getprimaryorsecondary_relation_objecttag";
	TERADYNE_TRACE_ENTER();

	if ( tObjFoundTag != NULLTAG)
			*tObjFoundTag = NULLTAG;

	try
	{	
		if (  tObjecttag != NULLTAG )
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(szRelName.c_str(),&tRelationTag),TD_LOG_ERROR_AND_THROW);			
			if ( iRelType )
			{
				TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tObjecttag,tRelationTag,&iObjCount,&tFindObjTag),TD_LOG_ERROR_AND_THROW);
			}
			else
			{
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tObjecttag,tRelationTag,&iObjCount,&tFindObjTag),TD_LOG_ERROR_AND_THROW);
			}			
			if( ( tFindObjTag != NULL ) && ( iObjCount > 0 ) )
			{
				for ( int iCount = 0;iCount < iObjCount;iCount++ )
				{
					if(szObjecttype.length() == 0)
					{
						*tObjFoundTag=tFindObjTag[iCount];
					    break;
					} 
					else {
					
					TERADYNE_TRACE_CALL(iStatus=teradyne_ask_object_type( tFindObjTag[iCount] ,&pcTypeName ),TD_LOG_ERROR_AND_THROW);						
					if( !tc_strcmp ( pcTypeName,szObjecttype.c_str() ) )
					{
						*tObjFoundTag=tFindObjTag[iCount];
							break;
					}
					Custom_free(pcTypeName);
				}
					
				}
			}
		}
	}
	catch(...)
	{
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tFindObjTag);
	Custom_free(pcTypeName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_create_object
 * Description				: Creates the object
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : szTypeName   (I)		   - Type of object shuould be created
 *							  szObjectName (I)		   - Object name
 *							  tCreObj		(O)		   - Created object tag
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_create_object(string szTypeName, string szObjectName, tag_t *tCreObj)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	tag_t tFormTag = NULLTAG,
		tFormTypeTag = NULLTAG,
		tForm_CreateInputTag = NULLTAG;

	char* __function__ = "teradyne_create_object";
	TERADYNE_TRACE_ENTER();

	if (tCreObj != NULLTAG)
	{
		*tCreObj = NULLTAG;
	}

	try
	{
		TERADYNE_TRACE_CALL(iStatus=TCTYPE_find_type(szTypeName.c_str(),NULL,&tFormTypeTag),TD_LOG_ERROR_AND_THROW);
		if( tFormTypeTag != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus=TCTYPE_construct_create_input(tFormTypeTag,&tForm_CreateInputTag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=AOM_set_value_string(tForm_CreateInputTag,TD_OBJECT_NAME_ATTR,(char*)szObjectName.c_str()),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=TCTYPE_create_object(tForm_CreateInputTag,&tFormTag),TD_LOG_ERROR_AND_THROW);
			if( tFormTag != NULLTAG )
			{
				TERADYNE_TRACE_CALL(iStatus= AOM_save_without_extensions(tFormTag),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tFormTag, false), TD_LOG_ERROR_AND_THROW);
				*tCreObj=tFormTag;
			}	
		}
	}
	catch(...)
	{
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_attachments
 * Description				: Will get the target attachments.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tTask   (I)		   - Task name of workflow
 *							  iAttachCount	(O)	   - Count of attached objects
 *							  ptAttaches    (OF)   - List of attached object tags
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the root task of the workflow.
 *							  2. Will get all the target object tags by using the root task.
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_attachments(tag_t tTask, int iAttachType, int *iAttachCount, tag_t **ptAttaches) {

	int iStatus					= ITK_ok;
	tag_t tRootTask				= NULLTAG;

	const char * __function__    = "teradyne_get_attachments" ;
	TERADYNE_TRACE_ENTER();
	
	if ( *ptAttaches != NULL)
			*ptAttaches = NULL;

	try {
	
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_root_task(tTask, &tRootTask), TD_LOG_ERROR_AND_THROW);
		if(tRootTask != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(tRootTask, iAttachType, iAttachCount, ptAttaches), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_get_root_task
 * Description				: Will get the root task of the work flow
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tTask   (I)		   - Task name of workflow
 *							  tRootTask	(O)		   - Root task tag of the work flow
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_root_task(tag_t tTask, tag_t *tRootTask) {

	int iStatus					= ITK_ok;
	tag_t tJob					= NULLTAG;

	const char * __function__    = "teradyne_get_root_task" ;
	TERADYNE_TRACE_ENTER();

	if ( tRootTask != NULLTAG)
			*tRootTask = NULLTAG;

	try {
	
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_job(tTask, &tJob), TD_LOG_ERROR_AND_THROW);
		if(tJob != NULLTAG) {
			
			TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(tJob, tRootTask), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
	
}
/*******************************************************************************
 * Function Name			: teradyne_send_os_mail
 * Description				: Sends mail using tc_mail_smtp utility
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : szSubject   (I)		       - Subject of the Mail
 *							  szMailBodyFilePath(I)		   - File Which contains content of the Mail
 *                            szToMailAddress(I)           - Mail Address to send
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_send_os_mail(string szSubject,string szMailBodyFilePath,string szToMailAddress)
{
    int iStatus                   = ITK_ok,
        ipref_count               = 0;

    std::string  system_comm("");

    char *pcServerName            = NULL,
         *pcServerPort            = NULL,
         *pcSenderName            = NULL,
         *pcSenderEmailAddr       = NULL;

    tag_t tSenderTag              = NULLTAG,
          tSenderPerson           = NULLTAG;

    const char * __function__ = "teradyne_send_os_mail" ;
    TERADYNE_TRACE_ENTER();

    try
    {
        #if defined(WNT)
        system_comm += "%TC_BIN%\\tc_mail_smtp ";
        #else
        system_comm += "$TC_BIN/tc_mail_smtp ";
        #endif

        system_comm += " -to=\"";
        system_comm += szToMailAddress.c_str();
        system_comm += "\" ";

        system_comm += " -subject=";
        system_comm += "\"";
        system_comm += szSubject.c_str();
        system_comm += "\" ";


        // get the current user name and user tag.
        TERADYNE_TRACE_CALL(iStatus=POM_get_user(&pcSenderName,&tSenderTag),TD_LOG_ERROR_AND_THROW);
        if( iStatus == ITK_ok )
        {
            // get the email address for current user.
			 TERADYNE_TRACE_CALL(iStatus=teradyne_ask_person_mailaddress(tSenderTag,&pcSenderEmailAddr),TD_LOG_ERROR_AND_THROW);
                if((iStatus == ITK_ok) && (pcSenderEmailAddr != 0) )
                {
                   system_comm += " -user=\"";
                   system_comm += pcSenderEmailAddr;
                   system_comm += "\" ";
                }
             }
        

        Custom_free(pcSenderName);
        Custom_free(pcSenderEmailAddr) ;


       TERADYNE_TRACE_CALL(iStatus=PREF_ask_value_count_at_location(TD_MAIL_SERVER_PREF,TC_preference_site, &ipref_count ),TD_LOG_ERROR_AND_THROW);

        if( (iStatus == ITK_ok) && ipref_count != 0 )
        {
          if( PREF_ask_char_value_at_location(TD_MAIL_SERVER_PREF,TC_preference_site, 0, &pcServerName ) == ITK_ok )
          {

              system_comm += "-server=" ;
              system_comm += "\"" ;
              system_comm += pcServerName;
              system_comm += "\" ";
          }

          if( pcServerName != 0 )
          {
              Custom_free(pcServerName);
          }
        }
        if( PREF_ask_char_value_at_location(TD_MAIL_PORT_PREF,TC_preference_site,0, &pcServerPort ) == ITK_ok && pcServerPort != 0 )
        {
            system_comm += "-port=" ;
            system_comm += "\"" ;
            system_comm += pcServerPort;
            system_comm += "\" ";

            Custom_free( pcServerPort );
        }
		system_comm += "-body=";
        system_comm += "\"";
        system_comm += szMailBodyFilePath.c_str();
        system_comm += "\" ";
  
		TC_write_syslog("\n%s\n",system_comm.c_str());
        system( system_comm.c_str() );
    }
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
    return iStatus ;
}

/*****************************************************************************************************
 * Function Name			: teradyne_os_mail_body
 * Description			    : Creates the Mail Content File
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : szMailBodyFilePath (I)   - File to write the content of the Mail
 *							  szMailContent(I)		   - content of the Mail
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 *
 *******************************************************************************************************/
int teradyne_os_mail_body(string szMailBodyFilePath,string szMailContent)
{
	int iStatus = ITK_ok;

	FILE *fpMailBody            = NULL;

	const char * __function__ = "teradyne_os_mail_body" ;
    TERADYNE_TRACE_ENTER();

    try
    {
		fpMailBody = fopen(szMailBodyFilePath.c_str(), "w");
		if(fpMailBody != NULL) {
		
			fprintf(fpMailBody,"%s ",szMailContent.c_str());
			fclose(fpMailBody);
		}	
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	return iStatus ;
}
/*****************************************************************************************************
 * Function Name			: teradyne_ask_person_mailaddress
 * Description			    : used to get the persons email address
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tSenderTag (I)       - Person Tag
 *							  pcSenderEmailAddr(OF) - Sender Email Address
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 *
 *******************************************************************************************************/
int teradyne_ask_person_mailaddress(tag_t tSenderTag,char** pcSenderEmailAddr)
{
	int iStatus = ITK_ok;

	tag_t tSenderPerson =NULLTAG;

	const char * __function__ = "teradyne_ask_person_mailaddress" ;
    TERADYNE_TRACE_ENTER();

    try
    {

		TERADYNE_TRACE_CALL(iStatus=SA_ask_user_person( tSenderTag, &tSenderPerson ),TD_LOG_ERROR_AND_THROW);
		 if ( iStatus == ITK_ok )
		 {
			TERADYNE_TRACE_CALL(iStatus=SA_ask_person_email_address( tSenderPerson,pcSenderEmailAddr ),TD_LOG_ERROR_AND_THROW);
		 }
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	return iStatus ;
}
/**************************************************************************************************
*    Function Name      :teradyne_find_execute_qry
*    Description            :This function will EXECUTE QUERY BASED on Entries and values passed by function
*   REQUIRED HEADERS    :teradyne_common.h
*    INPUT/OUTPUT PARAMS    : 
*
*   RETURN VALUE        : tag_t  returnTag:tag of result .
*   GLOBALS USED        :  None
*   FUNCTIONS CALLED    :  None
*   ALGORITHM           :  
*******************************************************************************************************/
int teradyne_find_execute_qry(char *pcQueryName, std::map<string,string> strQryEntriesMap, int* count,tag_t** ptLatestRev)
{
    int iStatus			= ITK_ok;
	int iTypesize		= 0;
	int iAttrCount		= 0;

	tag_t tQuery		= NULLTAG;

    const char * __function__ = "teradyne_find_execute_qry" ;
    TERADYNE_TRACE_ENTER();

   try {
		*count = 0;
		*ptLatestRev = NULL;
		TERADYNE_TRACE_CALL(iStatus = QRY_find2(pcQueryName, &tQuery), TD_LOG_ERROR_AND_THROW);    
		if(tQuery != NULLTAG)
		{
			char** pcEntries = NULL;
			char** pcValues = NULL;

			iTypesize = (int)strQryEntriesMap.size();
			//Allocate memory to query entries and values
			pcEntries = (char**)MEM_alloc(iTypesize*sizeof(char*));
			pcValues = (char**)MEM_alloc(iTypesize*sizeof(char*));
			for ( map<string, string>::iterator it = strQryEntriesMap.begin( ); it != strQryEntriesMap.end( ); it++ )
			{		
				pcEntries[iAttrCount] = (char*)MEM_alloc((int)((strlen(it->first.c_str()) +1)*sizeof(char)));			
				pcValues[iAttrCount] = (char*)MEM_alloc((int)((strlen(it->second.c_str()) +1)*sizeof (char)));
		        tc_strcpy(pcEntries[iAttrCount], it->first.c_str());
				tc_strcpy(pcValues[iAttrCount], it->second.c_str());
				iAttrCount++;
			}						

			//Execute query
			TERADYNE_TRACE_CALL(iStatus = QRY_execute(tQuery, iAttrCount, pcEntries, pcValues, count, ptLatestRev),TD_LOG_ERROR_AND_THROW);

			for (int i=0; i<iTypesize; i++ )
			{
				MEM_free(pcEntries[i]);
				MEM_free(pcValues[i]);
			}
			MEM_free(pcEntries);
			MEM_free(pcValues);
		}
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_ask_item_id_from_rev_tag
 * Description				: This function will get the ItemID from Revision tag.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject     (I)  - object tag
 *							  pcItemId  (OF)  - itemID
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 *
 * NOTES					:
 ******************************************************************************/
 int teradyne_ask_item_id_from_rev_tag(tag_t tObject,char** pcItemId)
 {
	int iStatus                 = ITK_ok;
	tag_t tItemTag	            = NULLTAG;

	const char * __function__    = "teradyne_ask_item_id_from_rev_tag" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL ( iStatus = ITEM_ask_item_of_rev(tObject, &tItemTag),TD_LOG_ERROR_AND_THROW );

			if(tItemTag != NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = ITEM_ask_id2(tItemTag, pcItemId),TD_LOG_ERROR_AND_THROW );
			}
		}
	}
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}
 /***************************************************************************************
*   Function Name       :teradyne_get_handler_opts
*   Description         :This function reads all the arguments and returns the values of all the arguments
*
*   REQUIRED HEADERS    :
*   INPUT/OUTPUT PARAMS :1.IMAN_argument_list_t* givenArgList
*                        2.char* pcGivenOptions  
*						 3.set of pairs (given Option, return Value) terminated by
*                          a NULL pointer.
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*
*********************************************************************************************/
void teradyne_get_handler_opts (IMAN_argument_list_t* givenArgList, char* pcGivenOptions, ...)
{
	int iStatus					= ITK_ok;
	int           iArgCount     = 0;
	char*         pcArgValue    = NULL;
	char*         pcOptions = pcGivenOptions;
	char*         pcEqualSign   = NULL;
	char**        pcOptValue    = NULL;
	logical       bFound        = FALSE;
	va_list       functArgs;

    const char * __function__   = "teradyne_get_handler_opts" ;
    TERADYNE_TRACE_ENTER();

	iArgCount = TC_number_of_arguments(givenArgList);

	va_start(functArgs, pcGivenOptions);
	while (pcOptions)
	{
		pcOptValue = va_arg(functArgs, char**);

		bFound = FALSE;
		IMAN_init_argument_list(givenArgList);

		for (int iCounter = 0; iCounter < iArgCount && !bFound; iCounter++)
		{
			pcArgValue = TC_next_argument(givenArgList);

			if (!strncmp(pcArgValue, pcOptions, strlen(pcOptions)))
			{
				bFound = TRUE;
				pcEqualSign = strchr(pcArgValue, '=');

				if (pcEqualSign)
				{
					*pcOptValue = pcEqualSign + 1;
				}
				else
				{
					*pcOptValue = pcArgValue;
				}

			}//if (!strncmp(pcArgValue, pcOptions, strlen(pcOptions)))

		}//end of for (int iCounter = 0;;)

		if (!bFound)
		{
			*pcOptValue = NULL;
		}

		pcOptions = va_arg(functArgs, char*);

	}//end of while loop


  va_end(functArgs);
  TERADYNE_TRACE_LEAVE(iStatus);
}  

/******************************************************************************************
 * Function Name    : teradyne_is_workspace_object
 * Description      : This function will return true if given object is workspace object

 * REQUIRED HEADERS :
 *
 * RETURN VALUE     : int (0 \ Error Code)
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 **********************************************************************************************/
bool teradyne_is_workspace_object(tag_t tObjectTag)
{
	int   iStatus  = ITK_ok;
	tag_t tCalssId = NULLTAG ;
	tag_t tWSOTag = NULLTAG ;
	bool  isWSOMObject = false;

	const char * __function__    = "teradyne_is_workspace_object" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = POM_class_of_instance(tObjectTag,&tCalssId), TD_LOG_ERROR_AND_THROW);		
		TERADYNE_TRACE_CALL(iStatus = POM_class_id_of_class( "WorkspaceObject", &tWSOTag ), TD_LOG_ERROR_AND_THROW);   
		TERADYNE_TRACE_CALL(iStatus = POM_is_descendant( tWSOTag, tCalssId, &isWSOMObject ), TD_LOG_ERROR_AND_THROW);		
	}
	catch(...)
	{

	}
    return isWSOMObject;
}

/**************************************************************************************
*  Function Name		: teradyne_generate_tokens
*  Description          : This function generates tokens in terms of Parent,Attribute
*                  
*  INPUT/OUTPUT PARAMS  : Input:  input string to be parsed, 
*                          delimiter. (Here "." )      
*						  Output: vector<string> tokens
*   RETURN VALUE		: ITK_ok for success
*                         iStatus value in case of failures
*   GLOBALS USED        : None
*   FUNCTIONS CALLED    :
*
**************************************************************************************/
vector<string> teradyne_generate_tokens(std::string inputStr, std::string delimiterFormat)
{
    int iCount = 0;
    char *pcGetData = NULL;
    vector<string> vectorTokens;
    std::string splitTokens(inputStr);
    const char * __function__ = "teradyne_generate_tokens";
    TERADYNE_TRACE_ENTER();

    try
    {
        if(inputStr.length() < 1)
        {
            return vectorTokens;
        }

        pcGetData = strtok((char *)splitTokens.c_str(), delimiterFormat.c_str());

        while (pcGetData != NULL)
        {
            vectorTokens.push_back(pcGetData);
            pcGetData = strtok (NULL, delimiterFormat.c_str());      
            iCount++;
        }
    }
    catch(...) 
	{
		
    }

    Custom_free(pcGetData);
	
    return vectorTokens;
}
/***************************************************************************************
*   Function Name       : teradyne_create_and_attach_dataset
*   Description         : This function creates a dataset under S_PnTask Rev,
*                         attaches a xml file as named reference.
*   REQUIRED HEADERS    : teradyne_product_notification.h
*                         teradyne_transform_memory_manager_impl.h
*   INPUT/OUTPUT PARAMS : char  *cDatasetName
*                         char  *cDatasetDesc
*                         char  *cDatasetType
*                         char  *cFormatName
*                         char  *cDatasetRefName
*                         char  *cRelationTypeName
*                         tag_t  tagRevTag
*                         bool   lDeleteFile
*                         tag_t *tagNew_dataset
*
*   RETURN VALUE        :ITK_ok for success
*                        iStatus value in case of failures
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
int teradyne_create_and_attach_dataset (char *cDatasetName, 
										char *cDatasetDesc, 
										char *cDatasetType, 
										char *cFormatName, 
										char *cDatasetRefName,         
                                        char *cReferenceName,          
                                        char *cRelationTypeName,       
                                       AE_reference_type_t ref_type,   
                                        tag_t  tagRevTag,              
                                        tag_t *tagNew_dataset)          
{

   //Declaration For  Newly Created DataSet
   int   iStatus                = ITK_ok;

   tag_t tagDefault_tool_tag    = NULLTAG;
   tag_t tagDataset_type        = NULLTAG;
   tag_t tagRelation_Type       = NULLTAG;
   tag_t tagRelation            = NULLTAG;
   tag_t tagFileTag             = NULLTAG;

   IMF_file_t file_desc;

   const char * __function__ = "teradyne_create_and_attach_dataset" ;
   TERADYNE_TRACE_ENTER();

   try
   {        
		TERADYNE_TRACE_CALL (iStatus = AE_find_datasettype2(cDatasetType,&tagDataset_type), TD_LOG_ERROR_AND_THROW);
	    
		if(tagDataset_type!=NULLTAG)
		{
			//creates a Dataset by specified type, cName, description, id, and rev.
			TERADYNE_TRACE_CALL ( iStatus = AE_create_dataset_with_id(tagDataset_type,cDatasetName,cDatasetDesc,NULL,NULL,&(*tagNew_dataset) ), TD_LOG_ERROR_AND_THROW);
			
			TERADYNE_TRACE_CALL ( iStatus = AE_ask_datasettype_def_tool(tagDataset_type,&tagDefault_tool_tag), TD_LOG_ERROR_AND_THROW);		
		 
			if((*tagNew_dataset)!=NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = AE_set_dataset_format2((*tagNew_dataset),cFormatName), TD_LOG_ERROR_AND_THROW);		

				// Set the default tool for the new dataset
				TERADYNE_TRACE_CALL ( iStatus = AE_set_dataset_tool((*tagNew_dataset),tagDefault_tool_tag), TD_LOG_ERROR_AND_THROW);

				if(tc_strcmp(cFormatName,TD_BINARY_FORMATTYPE)==0)
				{
					TERADYNE_TRACE_CALL ( iStatus = IMF_import_file (cDatasetRefName, NULL, SS_BINARY, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);
				}
				else
				{
					TERADYNE_TRACE_CALL ( iStatus = IMF_import_file (cDatasetRefName, NULL, SS_TEXT, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);		
				}
		       
				TERADYNE_TRACE_CALL ( iStatus = IMF_close_file (file_desc), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL ( iStatus = AOM_save_without_extensions(tagFileTag), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh((*tagNew_dataset),true), TD_LOG_ERROR_AND_THROW);		
				// adds named reference
				TERADYNE_TRACE_CALL ( iStatus = AE_add_dataset_named_ref2 ((*tagNew_dataset),cReferenceName,ref_type,tagFileTag), TD_LOG_ERROR_AND_THROW);		

				//TERADYNE_TRACE_CALL ( iStatus = AOM_set_value_int( (*tagNew_dataset),SIEMENS_REVISION_LIMIT,SIEMENS_DATASET_VERSION_LIMIT) , TD_LOG_ERROR_AND_THROW);		

				TERADYNE_TRACE_CALL ( iStatus = AOM_save_without_extensions((*tagNew_dataset)), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh((*tagNew_dataset),false), TD_LOG_ERROR_AND_THROW);

				POM_AM__set_application_bypass(true);

				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh(tagRevTag,true), TD_LOG_ERROR_AND_THROW);
								
				// create tagRelation between  Item Revisions & newly created  dataset  for avaliable Items
				TERADYNE_TRACE_CALL ( iStatus = GRM_find_relation_type(cRelationTypeName,&tagRelation_Type), TD_LOG_ERROR_AND_THROW);		
			
				TERADYNE_TRACE_CALL ( iStatus = GRM_create_relation(tagRevTag,(*tagNew_dataset),tagRelation_Type,NULLTAG,&tagRelation), TD_LOG_ERROR_AND_THROW);		
			
				TERADYNE_TRACE_CALL ( iStatus = GRM_save_relation(tagRelation), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh(tagRevTag,false), TD_LOG_ERROR_AND_THROW);

				POM_AM__set_application_bypass(false);

			}
		}
     }
     catch(...)
     {
		POM_AM__set_application_bypass(false);
		AOM_refresh((*tagNew_dataset),false);		
		TC_write_syslog("%s: Unhandled Exception",__function__);
		iStatus = TERADYNE_UNKNOWN_ERROR;
     }
	 	TERADYNE_TRACE_LEAVE(iStatus);
	 return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_get_arrayproperty_value  
* Description		: This function will read the attributes value from the given object whose properties
*                     are array
*                    
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tRevtag   (I)           - objecttag
*                     szpropname (I)          - Property Name
*                     VectorValues (O)        - Vector to store property value
*                     szPropertyname          - Property name for error msg
*                     bcheck (I)              - True indicates property is mandatory,
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		:
*
*
* NOTES			:
******************************************************************************/
int teradyne_get_arrayproperty_value(tag_t tRevTag,string szpropname,std::vector<std::string> &VectorValues,string szPropertyname,bool bcheck) 
 {
	//Declartion and Initialization of Local Variables
	int   iStatus           = ITK_ok,
		  iPropVals         = 0,
		  iPropCnt          = 0;
	char **pcAttrValue       = NULL;
    
	std::vector<std::string> TempVectorValues,
		                     TempVectorUserValues,
							 TempVectorPropvalues;
	std::vector<int> TempValues;


	char* __function__ = "teradyne_get_arrayproperty_value";
	TERADYNE_TRACE_ENTER();
		
	try
	{
	   
		if ( tRevTag != NULLTAG )
		{
			TERADYNE_TRACE_CALL(iStatus =iStatus = AOM_ask_max_num_elements(tRevTag,szpropname.c_str(),&iPropVals),TD_LOG_ERROR_AND_THROW);
			string szprop="";
		    int iPropPos=0;	
			if(bcheck)
			{
				szprop=szpropname.substr(3).append(":");
			}
			else
			{
				szprop=szpropname.substr(3,szpropname.length()-1).append(":");
			}
			for(int i=0;i<VectorValues.size();i++)
			{
				if(tc_strcmp(VectorValues.at(i).c_str(),szprop.c_str()) == 0)
				{
					iPropPos=i+1;
					break;
				}
			}
			if(iPropVals == 1) //single-value property
			{
				char *pcpropValue = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag,szpropname.c_str(),&pcpropValue),TD_LOG_ERROR_AND_THROW);
				if(pcpropValue !=NULL)
				{
					if(iPropPos==VectorValues.size())
					{
						VectorValues.push_back(pcpropValue);
					}
					else if(iPropPos<VectorValues.size())
					{
						int iFound=0;
  						for(int i=iPropPos-1;i<VectorValues.size();i++)
						{
							if(tc_strcmp(VectorValues.at(i).c_str(),pcpropValue)== 0)
							{
								iFound++;
								break;
							}
						}
						if(iFound==0)
						{
				VectorValues.push_back(pcpropValue);
						}
					}
				}

				if(iPropPos==VectorValues.size() && (!VectorValues.empty()))
				{
					if(tc_strlen(pcpropValue)==0)
					{
						VectorValues.erase(VectorValues.end()-1);
					}
				}
				
				Custom_free(pcpropValue);
			}
			else //multi-value property
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tRevTag,szpropname.c_str(),&iPropCnt,&pcAttrValue),TD_LOG_ERROR_AND_THROW);
				if( ( iPropCnt == 0 ) && (bcheck))
				{
					char *pcprojname=NULL;
					AOM_ask_value_string (tRevTag,TD_OBJECT_NAME_ATTR,&pcprojname);
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_REVIEWER_MANDATORY_ERROR,szPropertyname.c_str(),szpropname.c_str(),pcprojname), TD_LOG_ERROR_AND_THROW);
					Custom_free(pcprojname);
					iStatus = TD_REVIEWER_MANDATORY_ERROR;
					throw iStatus;
			  
				}
				if(iPropCnt>0)
				{
					if(iPropPos==VectorValues.size())
					{
						for(int i=0;i<iPropCnt;i++)
						{	
							TempVectorValues.push_back(pcAttrValue[i]);
						}
					}
					else if(iPropPos<VectorValues.size())
					{
  						for(int i=iPropPos-1;i<VectorValues.size();i++)
						{
							for(int j=0;j<iPropCnt;j++)
							{	
								if(tc_strcmp(VectorValues.at(i).c_str(),pcAttrValue[j])== 0)
								{
									TempValues.push_back(j);
								}
							}
						}
						if(!TempValues.empty())
						{
							for(int i=0;i<iPropCnt;i++)
							{	
								int iFound=0;
								for(int j=0;j<TempValues.size();j++)
								{	
									if(i== TempValues.at(j))
									{
										iFound++;
										break;

									}
								}
								if(iFound==0)
								{
									TempVectorValues.push_back(pcAttrValue[i]);
								}
								
							}
						}
						else
						{
							for(int i=0;i<iPropCnt;i++)
							{	
								TempVectorValues.push_back(pcAttrValue[i]);
							}
						}
					}
					
					//getting Unique Vector Values
					sort(TempVectorValues.begin(),TempVectorValues.end());
					vector<string>::iterator it = std::unique(TempVectorValues.begin(),TempVectorValues.end());
					TempVectorValues.erase(it,TempVectorValues.end());

					for(int i=0;i<TempVectorValues.size();i++)
					{
						size_t pos = TempVectorValues.at(i).find(":");
						if(pos == -1)
						{
							TempVectorUserValues.push_back(TempVectorValues.at(i));
						}
						else
						{
							TempVectorPropvalues.push_back(TempVectorValues.at(i));
						}
					}
			
					if(!TempVectorValues.empty())
					{
						VectorValues.insert(VectorValues.end(),TempVectorPropvalues.begin(),TempVectorPropvalues.end());
						VectorValues.insert(VectorValues.end(),TempVectorUserValues.begin(),TempVectorUserValues.end());
					}

						
				}
				if(iPropPos==VectorValues.size() && (!VectorValues.empty()) && VectorValues.at(VectorValues.size() - 1).c_str() == "")
				{
					if(iPropCnt == 0)
					{
						VectorValues.erase(VectorValues.end()-1);
					}
				}
 			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TempVectorValues.clear();
	TempVectorUserValues.clear();
	TempVectorPropvalues.clear();
	TempValues.clear();
	Custom_free(pcAttrValue);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_set_arrayproperty_value
* Description		:  sets the value for given propertyname and tag 
*                    
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tRevtag (I)    - objecttag
*                     szPropname (I) - AttributeName
*                     iPropCnt (I)   - ValueCount
*                     pcPropvalue (I)- Attributevalue
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :sets the value on given propertyname for given object
*
*
* NOTES				:
******************************************************************************/
int teradyne_set_arrayproperty_value(tag_t tRevtag,string szPropname,int iPropCnt,char** pcPropvalue) 
{
	//Declartion and Initialization of Local Variables
	int   iStatus           = ITK_ok;
    bool bisverdict         = true;

	char* __function__ = "teradyne_set_arrayproperty_value";
	TERADYNE_TRACE_ENTER();

	try
	{
		if( szPropname.length() > 0 && tRevtag!=NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tRevtag,&bisverdict),TD_LOG_ERROR_AND_THROW);
			if(!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tRevtag,true),TD_LOG_ERROR_AND_THROW);				
			}
			TERADYNE_TRACE_CALL(iStatus=AOM_set_value_strings(tRevtag,szPropname.c_str(),iPropCnt,pcPropvalue),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus= AOM_save_without_extensions(tRevtag),TD_LOG_ERROR_AND_THROW);
			if(!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tRevtag,false),TD_LOG_ERROR_AND_THROW);				
			}		  
		}	
	}
	catch(...)
	{
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_week_from_date
 * Description				: Will get the week number from the date
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strInputDate   (I) - Given date string
 *							  strGetWeek (O)     - Week number string
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_week_from_date (string strInputDate, string &strGetWeek) {

	int iStatus					= ITK_ok,
		iDay					= 0,
		iMonth					= 0,
		iYear					= 0,
		iWeekNumber				= 0,
		iDaysK					= 0,
		iDaysDiff				= 0;
	bool bFlag					= false;
	double dDateDiff			= 0;

	time_t dateCheck_t;
	time_t dateStamp_t;
	struct tm tmDateCheck;
	struct tm tmDateStamp;

	struct tm tm;
	struct tm tmDec31ThisYear;
	struct tm tmJan1ThisYear;
	char timebuff[64];

	int weekNumber=0;
	  bool thisYearHas53Weeks=false;
	  bool isJan1PartWeekNumberThisYear=false;  //included in the week number this year
	  bool isDec31PartWeekNumberThisYear=false;//included in the week number this year

	  char weekDayDec31[100];
	  char weekDayJan1[100];
	  int theWeekDayOfDec31=0;
	  int theWeekDayOfJan1=0;
	  int SUNDAY=0;
	  int MONDAY=1;
	  int TUESDAY=2;
	  int WEDNESDAY=3;
	  int THURSDAY=4;
	  int FRIDAY=5;
	  int SAT=6;

	  

	const char * __function__ = "teradyne_get_week_from_date";
	TERADYNE_TRACE_ENTER();

	try {
		//parsing the date farmat
		if(strInputDate.length() > 0) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_parse_input_date(strInputDate, &iYear, &iMonth, &iDay), TD_LOG_ERROR_AND_THROW);
			



			memset(&tm,0,sizeof(struct tm));

			tm.tm_sec=0;
	        tm.tm_min=0;
	        tm.tm_hour=23;
	        tm.tm_mday=iDay;
	        tm.tm_mon=iMonth-1;
	        tm.tm_year= iYear - 1900;

			//Decemer 31 of this year 
			memset(&tmDec31ThisYear, 0, sizeof(tmDec31ThisYear));
		    tmDec31ThisYear.tm_sec=0;
			tmDec31ThisYear.tm_min=0;
			tmDec31ThisYear.tm_hour=23;
			tmDec31ThisYear.tm_mday=31;
			tmDec31ThisYear.tm_mon=11;
			tmDec31ThisYear.tm_year= iYear - 1900;
			
			mktime(&tmDec31ThisYear);


			//January 1 of this year
			 memset(&tmJan1ThisYear, 0, sizeof(tmJan1ThisYear));
			 tmJan1ThisYear.tm_sec=0;
			 tmJan1ThisYear.tm_min=0;
			 tmJan1ThisYear.tm_hour=23;
			 tmJan1ThisYear.tm_mday=1;
			 tmJan1ThisYear.tm_mon=0;
			 tmJan1ThisYear.tm_year= iYear - 1900;
			 
		     mktime(&tmJan1ThisYear);


			 // Weekday of December 31 of this year
			 if(strftime(weekDayDec31,sizeof(weekDayDec31),"%w",&tmDec31ThisYear)!=0){
					theWeekDayOfDec31 =atoi(weekDayDec31);
			 } 

			 //Wekday of January 1 of this year
			 if(strftime(weekDayJan1,sizeof(weekDayJan1),"%w",&tmJan1ThisYear)!=0){
						 theWeekDayOfJan1 =atoi(weekDayJan1);
			 }  


	 
    
             // Is January 1 included in the week number one of this year ? 
			 if(theWeekDayOfJan1 >= MONDAY && theWeekDayOfJan1 <=THURSDAY){  
				  isJan1PartWeekNumberThisYear=true;
			 }
	  
			 // Is December 31 included in the week number(52/53) of this year 
			 if(theWeekDayOfDec31 >= THURSDAY || theWeekDayOfDec31 == SUNDAY){ //based on ISO Calendar 
				  isDec31PartWeekNumberThisYear=true;
			 }
	  

	  
			 if(isJan1PartWeekNumberThisYear && isDec31PartWeekNumberThisYear){
				thisYearHas53Weeks=true;
			 }

             mktime(&tm);
			 char pWeekNumber[3];
		  
		      int yearToDisplay=iYear;
			  if(strftime(pWeekNumber,sizeof(pWeekNumber),"%W",&tm)!=0){
				  if(!isJan1PartWeekNumberThisYear){
					  weekNumber =atoi(pWeekNumber);
				      if(weekNumber ==0){
						  //Gets the week number last year
					   
							 weekNumber=52;  //Initialize default
							 struct tm tmDec31LastYear;
							 memset(&tmDec31LastYear, 0, sizeof( tmDec31LastYear));
							 tmDec31LastYear.tm_sec=0;
							 tmDec31LastYear.tm_min=0;
							 tmDec31LastYear.tm_hour=23;
							 tmDec31LastYear.tm_mday=31;
							 tmDec31LastYear.tm_mon=11;
							 tmDec31LastYear.tm_year= (iYear-1) - 1900;

							 mktime(&tmDec31LastYear);
							 
							 struct tm tmJan1LastYear;
							 memset(&tmJan1LastYear, 0, sizeof(tmJan1LastYear));
							  tmJan1LastYear.tm_sec=0;
							  tmJan1LastYear.tm_min=0;
							  tmJan1LastYear.tm_hour=23;
							  tmJan1LastYear.tm_mday=1;
							  tmJan1LastYear.tm_mon=0;
							  tmJan1LastYear.tm_year= (iYear-1) - 1900;
							  
							  mktime(&tmJan1LastYear);
							 
							 
							 
							 

							 char weekDayDec31LastYear[3];
							 int theWeekDayOfDec31LastYear=0;
							 bool isDec31PartWeekNumberLastYear=false;
							 
							 
							 char weekDayJan1LastYear[100];
						     int theWeekDayOfJan1LastYear=0;
						     bool isJan1PartWeekNumberLastYear=false;
							 
							 if(strftime(weekDayDec31LastYear,sizeof(weekDayDec31LastYear),"%w",&tmDec31LastYear)!=0){
								 theWeekDayOfDec31LastYear =atoi(weekDayDec31LastYear);
							 }  


							 if(theWeekDayOfDec31LastYear >= THURSDAY || theWeekDayOfDec31LastYear == SUNDAY){ //based on ISO Calendar 
								isDec31PartWeekNumberLastYear=true;
							 }

							
							 if(strftime(weekDayJan1LastYear,sizeof(weekDayJan1LastYear),"%w",&tmJan1LastYear)!=0){
							   theWeekDayOfJan1LastYear =atoi(weekDayJan1LastYear);
							 }  


						
						     if(theWeekDayOfJan1LastYear >= MONDAY && theWeekDayOfJan1LastYear <=THURSDAY){  
								 isJan1PartWeekNumberLastYear=true;
					         }



						      bool lastYearHas53Weeks=false;
						     if(isJan1PartWeekNumberLastYear && isDec31PartWeekNumberLastYear){
								 lastYearHas53Weeks=true;
								 weekNumber =53;
						     }
							
							
					              yearToDisplay=iYear-1;
					   }
			  
				  }else{
					    if(theWeekDayOfJan1 ==MONDAY){ //strftime generate 1 if January falls on MONDAY
			     	         weekNumber =atoi(pWeekNumber);
				        }else{
					 weekNumber =atoi(pWeekNumber)+1;
				        }
					 
						if(weekNumber > 52 && !thisYearHas53Weeks){
								weekNumber=1;
								yearToDisplay=iYear+1;
						}
					 
					 
				  }

	  
				  
			  }
	  



			  strGetWeek.append(to_string((long long )yearToDisplay));
				if ((to_string((long long)weekNumber)).length() == 1){
					strGetWeek.append("0");
				}
				strGetWeek.append(to_string((long long)weekNumber));
				strGetWeek = strGetWeek.substr(2);





			
			/*
			memset(&tmDateCheck, 0, sizeof(tmDateCheck));
			memset(&tmDateStamp, 0, sizeof(tmDateStamp));
			//Date structures
			tmDateCheck.tm_year  = iYear - 1900; 
			tmDateCheck.tm_mon   = iMonth - 1;
			tmDateCheck.tm_mday  = iDay;

			tmDateStamp.tm_year  = iYear - 1900;
			tmDateStamp.tm_mon   = 01 - 1;
			tmDateStamp.tm_mday  = 01;
			//create time_t 
			dateCheck_t = mktime(&tmDateCheck);
			dateStamp_t = mktime(&tmDateStamp);
			dDateDiff = difftime(dateCheck_t, dateStamp_t);
			//translate to days
			if(iYear <= 2013) {
			
				if (iMonth == 12 && iDay > 29){
					bFlag = true;
					iYear = 2014;
					iWeekNumber = 01;
				} else {
					iDaysK=1;
			  }
			} else if (iYear <= 2014) {
				
				if (iMonth == 12 && iDay > 28){
					bFlag = true;
					iYear = 2014;
					iWeekNumber = 52;
				} else {
					iDaysK=2;
			  }
			}
		    else if(iYear <= 2015)
			{
				if (iMonth == 1 && iDay < 5)
				{
					bFlag = true;
					iYear = 2015;
					iWeekNumber = 01;
				} else {
					iDaysK=4;
			  }
			}
			else if(iYear <= 2016)
			{
				if (iMonth == 1 && iDay < 4)
				{
					bFlag = true;
					iYear = 2015;
					iWeekNumber = 52;
				} else {
					iDaysK=3;
				}
			}
		   if(bFlag) {
			   //translate to days
			   strGetWeek.append(to_string((long long )iYear));
			   strGetWeek.append(to_string((long long)iWeekNumber));
		   } else {
		   
			   //translate to days
				iDaysDiff = (int)dDateDiff/86400;
				iWeekNumber = ((iDaysDiff - iDaysK) / 7)+1; 
				strGetWeek.append(to_string((long long )iYear));
				if ((to_string((long long)iWeekNumber)).length() == 1)
					strGetWeek.append("0");
				
				strGetWeek.append(to_string((long long)iWeekNumber));
		   }
			  
		   strGetWeek = strGetWeek.substr(2);*/
			  


			  
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_parse_input_date
 * Description				: Will get the the Year, Month and Day numbers from the given date format
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strInputDate (I) - Date string
 *							  iYear (O)		   - Year int
 *							  iMonth (O)	   - Year int
 *							  iDay (O)		   - Year int
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: date format dd-Month(string of 3 char)-yyyy ex; 17-Mar-2015
 * NOTES					: 
 ******************************************************************************/
int teradyne_parse_input_date(string strInputDate, int* iYear, int* iMonth, int* iDay) {

	int iStatus					= ITK_ok;
	string strMonth				= "";

	string strMonthArr[12]		= {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	int iMonthArr[]				= {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

	const char * __function__ = "teradyne_parse_input_date";
	TERADYNE_TRACE_ENTER();

	try {
		*iDay = stoi(strInputDate.substr(0,2));
		strMonth = strInputDate.substr(3,3);
		*iYear = stoi(strInputDate.substr(7, 4));
		for(int i = 0; i < 12; i++) {
		
			if(strMonth.compare(strMonthArr[i]) == 0) {
			
				*iMonth = iMonthArr[i];
				break;
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_assign_task_to_users
 * Description				: Will assign task to reviewers
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tTask (I) - Task tag
 *							  tUser (I) - User tag
 *							  pcRole, pcGroup, pcUser (I) - Input role, group and user names const char*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_assign_task_to_users(tag_t tTask, tag_t tUser, const char* pcRole, const char* pcGroup, const char* pcUser) {

	int iStatus					= ITK_ok,
		iMembers				= 0,
		iSignoffs				= 0;
	tag_t *tMembers				= NULL,
		  *tSignoffs			= NULL;

	const char * __function__ = "teradyne_assign_task_to_users";
	TERADYNE_TRACE_ENTER();

	try {
		if(tUser != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = SA_find_groupmember_by_user(tUser, &iMembers, &tMembers), TD_LOG_ERROR_AND_THROW);
		} else if(pcRole != NULL ||pcGroup != NULL || pcUser != NULL){

			TERADYNE_TRACE_CALL(iStatus = SA_find_groupmember_by_rolename(pcRole, pcGroup, pcUser, &iMembers, &tMembers), TD_LOG_ERROR_AND_THROW);
		}
		for(int i = 0; i < iMembers; i++) {
			//Assigns the reviewers to the task
			iSignoffs = 0;
			TERADYNE_TRACE_CALL(iStatus = EPM_create_adhoc_signoff(tTask, tMembers[i], &iSignoffs, &tSignoffs), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = EPM_set_adhoc_signoff_selection_done(tTask, true),TD_LOG_ERROR_AND_THROW);
			Custom_free(tSignoffs);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tMembers);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_list_all_revisions_from_revtag
 * Description				: This function will list all item revision sorted by the Item Revision creation date
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRevOfItem	          (I) - Revision tag of the Item tag_t
 *							  iRevs                   (O) - Count of Revisions int*
 *                            tRevs 		          (OF)- List of Revisions tag_t**
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
int teradyne_list_all_revisions_from_revtag(tag_t tRevOfItem, int* iRevs, tag_t** tRevs) {

	int iStatus					= ITK_ok;
	tag_t tItem					= NULLTAG;

	const char * __function__ = "teradyne_list_all_revisions_from_revtag";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevOfItem, &tItem), TD_LOG_ERROR_AND_THROW);
		if(tItem != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = ITEM_list_all_revs(tItem, iRevs, tRevs), TD_LOG_ERROR_AND_THROW);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name	    : teredyne_replace_string
* Description		: Replace the string      
* REQUIRED HEADERS	: 
* INPUT PARAMS		: strDirPath - String in which replace to has to be done.
*					  toReplace	 - which string you want to replace.
*					  replaceWith- with which string you want to replace.
*                    
* RETURN VALUE		: string - string after replaced with new string.
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :1. find the replaceto string .
*					 2. replace the string with replace with.
*					 3. return the replaced the string.
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
string teredyne_replace_string(std::string &strDirPath,
                      std::string toReplace,
                      std::string replaceWith)
{
	std::size_t found=0;
	while(std::string::npos != strDirPath.find(toReplace,found))
	{
		found = strDirPath.find(toReplace,found);
		strDirPath = (strDirPath.replace(found, toReplace.length(), replaceWith));
		found = found + 2;
	}

	return strDirPath;
}
/*******************************************************************************
 * Function Name			: teradyne_convert_xls2xlsx 
 * Description				: Converts the report from xls to xlsx
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strxlsPath	(I) - xls file name with full path string
 *							: strOutxlsxPath(O) - xlsx filename with full path string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_convert_xls2xlsx(string strxlsPath, string &strOutxlsxPath) {

	int iStatus					= ITK_ok;

	const char * __function__ = "teradyne_convert_xls2xlsx";
	TERADYNE_TRACE_ENTER();

	try {
		if(strxlsPath.length() > 0) {

			string strxlsxPath = strxlsPath + "x";
			string strTCRootPath(getenv(TD_TC_ROOT_PATH_ENV));
			if(strTCRootPath.length() > 0) {
			
				string strUtilPath = strTCRootPath + "\\" + "teradyne_util";
				string strxls2xlsxCommand = strUtilPath + "\\" + "teradyne_xls2xlsx_script.vbs" + " \"" + strxlsPath + "\" \"" + strxlsxPath + "\"";

				int status = system(strxls2xlsxCommand.c_str());

				if(status == 0) {
		
					strOutxlsxPath = strxlsxPath;
				} else {
				
					cout << "###### Error while converting xls file to xlsx for the command = " << strxls2xlsxCommand << endl; 
				}
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}/*******************************************************************************
 * Function Name			: teradyne_delete_relation 
 * Description				: Deletes the ralation
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tPrimary	(I) - primary object tag_t
 *							: tSecondary (I) - secondary object tag_t
 *							: strRelTypeName(I) - Relation type name const char*
 *							: tRelation(O) - Relation tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_delete_relation(tag_t tPrimary, tag_t tSecondary, const char* strRelTypeName) {

	int iStatus					= ITK_ok;
	tag_t tRelType				= NULLTAG,
		  tRelation			    = NULLTAG;

	const char * __function__ = "teradyne_delete_relation";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(strRelTypeName, &tRelType), TD_LOG_ERROR_AND_THROW);
		if(tRelType != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimary, tSecondary, tRelType, &tRelation), TD_LOG_ERROR_AND_THROW);
			if(tRelation != NULLTAG) {
			
				TERADYNE_TRACE_CALL(iStatus = GRM_delete_relation(tRelation), TD_LOG_ERROR_AND_THROW);
			}
		}
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_find_prev_revision
 * Description				: Returns the Previous Revision for the Given Revision.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObjTag   (I)	  - tag_t
 *							  tprevTag  (O)   - tag_t
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_find_prev_revision(tag_t tObjTag,tag_t *tprevTag)
{
	int iStatus					= ITK_ok,
		iRevCnt                 = 0;

	tag_t *tRevTag              = {NULLTAG},
		   tItemtag             = NULLTAG;

	const char * __function__ = "teradyne_find_prev_revision";
	TERADYNE_TRACE_ENTER();

	try 
	{
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev( tObjTag,&tItemtag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = ITEM_list_all_revs(tItemtag,&iRevCnt,&tRevTag), TD_LOG_ERROR_AND_THROW);
		for(int i=0;i<iRevCnt;i++)
		{
			 if((tRevTag[i]==tObjTag) && (i > 0))
			 {
				  *tprevTag=tRevTag[i-1];
			 }								 
		}												
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tRevTag);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_convert_vector_to_array
 * Description				: converting vector to char array
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : VectorValues   (I)		  - vector<string>
 *							  pctechreviewerarray  (OF)   -  char***
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_convert_vector_to_array( vector<string> VectorValues,char ***pctechreviewerarray)
{

	int iStatus					= ITK_ok;

	char **pcreviewerarray         =NULL;
	const char * __function__ = "teradyne_convert_vector_to_array";
	TERADYNE_TRACE_ENTER();

	try
	{
		pcreviewerarray= (char **) MEM_alloc(sizeof(char *) * (int)VectorValues.size());
		*pctechreviewerarray= (char **) MEM_alloc(sizeof(char *) * (int)VectorValues.size());
		for(int pos=0;pos < VectorValues.size();pos++)
		{
			pcreviewerarray[pos] =  (char *) MEM_alloc(sizeof(char) * (int)(strlen(VectorValues.at(pos).c_str()) + 1));
			tc_strcpy(pcreviewerarray[pos],VectorValues.at(pos).c_str());
		}
		*pctechreviewerarray =pcreviewerarray;
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/***************************************************************************************
*   Function Name       : teradyne_create_dataset
*   INPUT/OUTPUT PARAMS : char  *cDatasetName
*                         char  *cDatasetDesc
*                         char  *cDatasetType
*                         char  *cFormatName
*                         char  *cDatasetRefName
*                         tag_t *tagNew_dataset
*
*   RETURN VALUE        :ITK_ok for success
*                        iStatus value in case of failures
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
int teradyne_create_dataset (char *cDatasetName, 
										char *cDatasetDesc, 
										char *cDatasetType, 
										char *cFormatName, 
										char *cDatasetRefName,         
                                        char *cReferenceName,          
                                        AE_reference_type_t ref_type,                
                                        tag_t *tagNew_dataset)          
{

   //Declaration For  Newly Created DataSet
   int   iStatus                = ITK_ok;

   tag_t tagDefault_tool_tag    = NULLTAG;
   tag_t tagDataset_type        = NULLTAG;
   tag_t tagRelation_Type       = NULLTAG;
   tag_t tagRelation            = NULLTAG;
   tag_t tagFileTag             = NULLTAG;

   IMF_file_t file_desc;

   const char * __function__ = "teradyne_create_and_dataset" ;
   TERADYNE_TRACE_ENTER();

   try
   {        
		TERADYNE_TRACE_CALL (iStatus = AE_find_datasettype2(cDatasetType,&tagDataset_type), TD_LOG_ERROR_AND_THROW);
	    
		if(tagDataset_type!=NULLTAG)
		{
			//creates a Dataset by specified type, cName, description, id, and rev.
			TERADYNE_TRACE_CALL ( iStatus = AE_create_dataset_with_id(tagDataset_type,cDatasetName,cDatasetDesc,NULL,NULL,&(*tagNew_dataset) ), TD_LOG_ERROR_AND_THROW);
			
			TERADYNE_TRACE_CALL ( iStatus = AE_ask_datasettype_def_tool(tagDataset_type,&tagDefault_tool_tag), TD_LOG_ERROR_AND_THROW);		
		 
			if((*tagNew_dataset)!=NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = AE_set_dataset_format2((*tagNew_dataset),cFormatName), TD_LOG_ERROR_AND_THROW);		

				// Set the default tool for the new dataset
				TERADYNE_TRACE_CALL ( iStatus = AE_set_dataset_tool((*tagNew_dataset),tagDefault_tool_tag), TD_LOG_ERROR_AND_THROW);
				POM_AM__set_application_bypass(true);

				if(tc_strcmp(cFormatName,TD_BINARY_FORMATTYPE)==0)
				{
					TERADYNE_TRACE_CALL ( iStatus = IMF_import_file (cDatasetRefName, NULL, SS_BINARY, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);
				}
				else
				{
					TERADYNE_TRACE_CALL ( iStatus = IMF_import_file (cDatasetRefName, NULL, SS_TEXT, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);		
				}
				TERADYNE_TRACE_CALL ( iStatus = IMF_close_file (file_desc), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL ( iStatus = AOM_save_without_extensions(tagFileTag), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh((*tagNew_dataset),true), TD_LOG_ERROR_AND_THROW);
			
				// adds named reference
				TERADYNE_TRACE_CALL ( iStatus = AE_add_dataset_named_ref2 ((*tagNew_dataset),cReferenceName,ref_type,tagFileTag), TD_LOG_ERROR_AND_THROW);		

				POM_AM__set_application_bypass(false);
				//TERADYNE_TRACE_CALL ( iStatus = AOM_set_value_int( (*tagNew_dataset),SIEMENS_REVISION_LIMIT,SIEMENS_DATASET_VERSION_LIMIT) , TD_LOG_ERROR_AND_THROW);		

				TERADYNE_TRACE_CALL ( iStatus = AOM_save_without_extensions((*tagNew_dataset)), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL ( iStatus = AOM_refresh((*tagNew_dataset),false), TD_LOG_ERROR_AND_THROW);

			}
		}
     }
     catch(...)
     {
		POM_AM__set_application_bypass(false);
		AOM_refresh((*tagNew_dataset),false);		
		TC_write_syslog("%s: Unhandled Exception",__function__);
		iStatus = TERADYNE_UNKNOWN_ERROR;
     }
	 	TERADYNE_TRACE_LEAVE(iStatus);
	 return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_latest_rev_from_rev
 * Description				: Will get the latest revision tag from any revision of the item.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRev   (I)	- input revision tag_t
 *							  tLatestRev  (O)      - Latest revision tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_latest_rev_from_rev(tag_t tRev, tag_t* tLatestRev) {

	int iStatus			    = ITK_ok;
	tag_t tItem				= NULLTAG;

	const char * __function__    = "teradyne_latest_rev_from_rev" ;
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRev, &tItem), TD_LOG_ERROR_AND_THROW);
		if(tItem != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tItem, tLatestRev), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	return iStatus;
}

/***************************************************************************************
*   Function Name       : splitString
*   Description         : This function splits the given string by a given delimiter.
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         char delim
*
*   RETURN VALUE        : vector of elements
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::vector<std::string> splitString(std::string theString, string delim, bool splitQuotes) 
{
    std::vector<std::string> elems;
	std::string quotedDelim = "\"" + delim;
	std::string replaceStr = "#~#";
	std::string searchStr = "";
	char quotes = '"';

	if(splitQuotes)
	{
		if( theString != "" && theString.length() > 0 )
		{
			size_t it = 0;
			while(it != string::npos && it < theString.length())
			{
				if(it == 0)
				{
					if(quotes == theString[0])
					{
						it = theString.find(quotedDelim);
						searchStr = quotedDelim;
					}
					else
					{
						it = theString.find(delim);
						searchStr = delim;
					}
				}
				else
				{
					if(theString[it] == quotes)
					{
						theString.replace(it, 1, "");
						it = theString.find(quotedDelim,it);
						searchStr = quotedDelim;
					}
					else
					{
						it = theString.find(delim,it);
						searchStr = delim;
					}
				}

				if(it != string::npos)
				{
					theString.replace(it, searchStr.length(), replaceStr);
					it += replaceStr.length();
				}
			}

			if(theString[0] == quotes)
			{
				theString.replace(0,1,"");
			}
			size_t strLen = theString.length() - 1;
			if(theString[strLen] == quotes)
			{
				theString.replace(strLen, 1, "");
			}
		}

		delim = "#~#";
	}

	auto start = 0U;
    auto end = theString.find(delim);
    while (end != std::string::npos)
    {
		elems.push_back( theString.substr(start, end - start) );
        start = end + delim.length();
        end = theString.find(delim, start);
    }
	elems.push_back(theString.substr(start, end));
    return elems;
}

/****************************************************************************
*   Function Name		:  Logger constructor with parameter
*   Description			:  Parameterized constructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
Logger::Logger()
{
	strFilePath = "";
	strFileName = "";
	isFileOpen = false;
	bwasFileWritten = false;
}
/****************************************************************************
*   Function Name		:  Logger destructor
*   Description			:  Standard destructor for this class.
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
Logger::~Logger()
{
	//Close the file
	if(isFileOpen)
		outfile.close();

	//Delete the file
	remove(strFilePath.c_str());
}

/****************************************************************************
*   Function Name		:  createLogFile
*   Description			:  Function to create the log file name
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
void Logger::createLogFile(string strLogFileName, string strFileExt)
{
	string strCurTimeStamp;
	string strTempPath;
	date_t currDate;
	teradyne_current_timestamp("%Y-%m-%dT%H-%M-%SZ", strCurTimeStamp, currDate);

	strFileName = strLogFileName;

	if(strFileName == "" || strFileName.length() <= 0 )
		strFileName.assign("LogFile").append("_").append(strCurTimeStamp);
	else
		strFileName.append(strCurTimeStamp);

	char* pcTEMP_env = getenv ( "TEMP" );
    if ( pcTEMP_env == NULL )
    {
        pcTEMP_env = getenv("TMP");
    }

	if(pcTEMP_env != NULL)
	{
		strTempPath.assign(pcTEMP_env); 
	}

	if(strTempPath == "" || strTempPath.length() <= 0)
		strTempPath.assign(TD_TEMP_PATH);

	strFilePath.append(strTempPath).append("/").append(strFileName).append(strFileExt);

	outfile.open(strFilePath);
	if(outfile.is_open())
		isFileOpen = true;
}

/****************************************************************************
*   Function Name		:  Log
*   Description			:  Function to write the log file contents
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
void Logger::log(string data, Logger::LogLevel logL)
{
	string strCurTimeStamp = "";
	string strLevelMsg = "";
	date_t currDate;
	teradyne_current_timestamp("%Y.%m.%d %H:%M:%S", strCurTimeStamp, currDate);
	if(isFileOpen && data != "" && data.length() > 0)
	{
		if(logL == Logger::DEBUG_LEVEL) { strLevelMsg = "[DEBUG]"; }
		else if(logL == Logger::ERROR_LEVEL) { strLevelMsg = "[ERROR]";}
		else if(logL == Logger::INFO_LEVEL) { strLevelMsg = "[INFO]";}
		else if(logL == Logger::WARN_LEVEL) { strLevelMsg = "[WARN]";}
		else {strLevelMsg = "[IFNO]";}

		if(strCurTimeStamp == "" || strCurTimeStamp.length() <= 0) { strCurTimeStamp == "NULL DATE"; }
		outfile << strCurTimeStamp << ":" << TD_SPACE_CONSTANT << strLevelMsg << TD_SPACE_CONSTANT  << data << endl;
		if(!bwasFileWritten)
			bwasFileWritten = true;
	}
}

/****************************************************************************
*   Function Name		:  Log
*   Description			:  Function to write the log file contents
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
void Logger::log(string data)
{
	if(isFileOpen && data != "" && data.length() > 0)
	{
		outfile << data << endl;
		if(!bwasFileWritten)
			bwasFileWritten = true;
	}
}

/****************************************************************************
*   Function Name		:  closeFile
*   Description			:  Function to close the log file
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
void Logger::closeFile()
{
	if( isFileOpen )
	{
		outfile.close();
		isFileOpen = false;
	}
}

/****************************************************************************
*   Function Name		:  getFilePath
*   Description			:  Getter method
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
string Logger::getFilePath()
{
	return strFilePath;
}

/****************************************************************************
*   Function Name		:  getFileName
*   Description			:  Getter method
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
string Logger::getFileName()
{
	return strFileName;
}

/****************************************************************************
*   Function Name		:  getisFileOpen
*   Description			:  Getter method
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
bool Logger::getisFileOpen()
{
	return isFileOpen;
}

/****************************************************************************
*   Function Name		:  getisFileOpen
*   Description			:  Getter method
*                          
*	REQUIRED HEADERS	:  
*   INPUT/OUTPUT PARAMS	:  
*	RETURN VALUE		:  
*	GLOBALS USED		:  None
* 
****************************************************************************/
bool Logger::getWasFileWritten()
{
	return bwasFileWritten;
}

/***************************************************************************************
*   Function Name       : teradyne_export_file_to_temp
*   Description         : This function export a dataset file to temp directory
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         char delim
*
*   RETURN VALUE        : vector of elements
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
int teradyne_export_file_to_temp(tag_t tDataset, tag_t tNamedRef, string strRefName, string &strFilePath)
{
	int iStatus = ITK_ok;

	char *pcFileName = NULL;

	const char * __function__    = "teradyne_export_file_to_temp" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		char* pcTEMP_env = getenv ( "TEMP" );
		if ( pcTEMP_env == NULL )
		{
			pcTEMP_env = getenv("TMP");
		}

		if(pcTEMP_env != NULL)
		{
			strFilePath.assign(pcTEMP_env); 
		}

		if(strFilePath == "" || strFilePath.length() <= 0)
			strFilePath.assign(TD_TEMP_PATH);

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tNamedRef,TD_ORG_FILE_NAME_ATTR,&pcFileName), TD_LOG_ERROR_AND_THROW);
		strFilePath.append("/").append(pcFileName);
		TERADYNE_TRACE_CALL(iStatus = AE_export_named_ref(tDataset,strRefName.c_str(),(char *)strFilePath.c_str()), TD_LOG_ERROR_AND_THROW);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcFileName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/***************************************************************************************
*   Function Name       : ltrim
*   Description         : This function trims the left leading whitespaces
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &ltrim(std::string &s) {
        s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
        return s;
}

/***************************************************************************************
*   Function Name       : rtrim
*   Description         : This function trims the right trailing whitespaces
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &rtrim(std::string &s) {
        s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
        return s;
}

/***************************************************************************************
*   Function Name       : trim
*   Description         : This function trims the leading and trailing whitespaces
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &trim(std::string &s) {
        return ltrim(rtrim(s));
}

/***************************************************************************************
*   Function Name       : isDigitWSAllowed
*   Description         : This function checks if a string is numeric
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isDigitWSAllowed(std::string str)
{
	if(str == "" || str.length() <= 0)
		return false;

	for(int n = 0; n < str.length(); n++)
	{
		if(std::isspace(str[n]))
			continue;
		if(!std::isdigit(str[n]))
			return false;
	}

	return true;
}

/***************************************************************************************
*   Function Name       : isAlphaWSAllowed
*   Description         : This function checks if a string is alpha
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaWSAllowed(std::string str)
{
	if(str == "" || str.length() <= 0)
		return false;

	for(int n = 0; n < str.length(); n++)
	{
		if(std::isspace(str[n]))
			continue;
		if(!std::isalpha(str[n]))
			return false;
	}

	return true;
}


/***************************************************************************************
*   Function Name       : isAlphaNumericWSAllowed
*   Description         : This function checks if a string is alphanumeric
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaNumericWSAllowed(std::string str)
{
	if(str == "" || str.length() <= 0)
		return false;

	std::regex e("^(?:\\w|\\s)*$");

	if(std::regex_match(str.begin(), str.end(),e))
		return true;

	return false;
}

/***************************************************************************************
*   Function Name       : isAlphaNumericStrict
*   Description         : This function checks if a string is strictly alphanumeric only
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : 
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaNumericStrict(std::string str) {
	if(isAlphaWSAllowed(str) || isDigitWSAllowed(str))
		return false;
	if(!isAlphaNumericWSAllowed(str))
		return false;
	return true;
}

/***************************************************************************************
*   Function Name       : incrementedAlpha
*   Description         : This function increments a string by one
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : string buf
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string incrementedAlpha(std::string text)
{
	// We will not process empty string
	auto len = text.length();
    if (len == 0)
		return text;

	// Determine whether the last char is numeric. We need to find out the
    // the numeric char as whole value to increment
    auto charLen = text.length() - 1;
    int numPos = -1;
    bool numFound = false;
    for (int i = charLen; i >= 0; i-- ) {
        if(std::isdigit(text.at(i))) {
        	numFound = true;
        	continue;
        } else {
            numPos = i;
            break;
        }
    }

	if(numPos == -1 && numFound) 
	{  // Case1: All Numerics
		int incr = stoi(text);
		incr++;
		return toString(incr);
	} 
	else if(numPos != -1 && numFound) 
	{ // Case2: Partial Numeric
		string strCons = text.substr(0, numPos + 1);
		string strIncr = text.substr(numPos + 1, text.length());
		int incr = stoi(strIncr);
		incr++;
		return strCons + toString(incr);
	} 
	else 
	{
		// Determine where does the first alpha-numeric starts.
	    bool alphaNum = false;
	    int alphaNumPos = -1;
		for (int cn = 0; cn < text.size(); cn++) 
		{
	        alphaNumPos++;
			if (std::isdigit(text.at(cn)) || std::isalpha(text.at(cn))) 
			{
	            alphaNum = true;
	            break;
	        }
	    }

		// Now we go calculate the next successor char of the given text.
	    string buf = text;
	    if (!alphaNum || alphaNumPos == 0 || alphaNumPos == len) {
	        // do the entire input text
	        getNextAlpha(buf, buf.length() - 1, alphaNum);
	    } else {
	        // Strip the input text for non alpha numeric prefix. We do not need to process these prefix but to save and
	        // re-attach it later after the result.
	        string prefix = text.substr(0, alphaNumPos);
	        buf = text.substr(alphaNumPos);
	        getNextAlpha(buf, buf.length() - 1, alphaNum);
	        buf.insert(0, prefix);
	    }

		return buf;
	}

}

/***************************************************************************************
*   Function Name       : getNextAlpha
*   Description         : This function will get the next aplha/numeric sequence
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        :
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
void getNextAlpha(string &buf, int pos, bool alphaNum)
{
	// We are asked to carry over next value for the left most char
    if (pos == -1) {
        char c = buf.at(0);
        string rep = "";
        if (std::isdigit(c))
            rep = "1";
        else if (std::islower(c))
            rep = "a";
        else if (std::isupper(c))
            rep = "A";
        else
            rep = ++c;
        buf.insert(0, rep);
        return;
    }

	char c = buf.at(pos);
    if (std::isdigit(c)) {
        if (c == '9') {
            buf.replace(pos, pos + 1, "0");
            getNextAlpha(buf, pos - 1, alphaNum);
        } else {
			std::string s(1,++c);
			buf.replace(pos, pos + 1, s);
        }
    }
	else if (std::islower(c)) {
        if (c == 'z') {
            buf.replace(pos, pos + 1, "a");
            getNextAlpha(buf, pos - 1, alphaNum);
        } else {
			std::string s(1,++c);
            buf.replace(pos, pos + 1, s);
        }
	} else if (std::isupper(c)) {
        if (c == 'Z') {
            buf.replace(pos, pos + 1, "A");
            getNextAlpha(buf, pos - 1, alphaNum);
        } else {
			std::string s(1,++c);
            buf.replace(pos, pos + 1, s);
        }
    } else {
        // If input text has any alpha num at all then we are to calc next these characters only and ignore the
        // we will do this by recursively call into next char in buf.
        if (alphaNum) {
            getNextAlpha(buf, pos - 1, alphaNum);
        } else {
            // However if the entire input text is non alpha numeric, then we will calc successor by simply
            // increment to the next char in range (including non-printable char!)
			if (c == CHAR_MAX) {
				std::string s(1,CHAR_MIN);
                buf.replace(pos, pos + 1, s);
                getNextAlpha(buf, pos - 1, alphaNum);
            } else {
				std::string s(1,++c);
                buf.replace(pos, pos + 1, s);
            }
        }
    }
}

/*******************************************************************************
 * Function Name			: teradyneBuildNotificationSubject
 * Description				: Will return the subject for notification email
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  strSubject     - The subject for notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
 std::string teradyneBuildNotificationSubject(EPM_action_message_t msg){
  int iStatus			    = ITK_ok,
  iAttachCount			    = 0;
  string bufferSubject = " ";
  char *jobName=NULL,*currentTask=NULL,*parentTaskName=NULL, *synopsis=NULL, *project=NULL, *materialImpact=NULL;
  const char * __function__    = "teradyneBuildNotificationSubject";
  char  *pcTypeName			= NULL,
	    *pcTargetAttachmentType=NULL;
  tag_t  *ptAttaches		= NULL;
  
  try {
  
	  TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
	  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[0], &pcTargetAttachmentType), TD_LOG_ERROR_AND_THROW);

	  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(msg.task, &pcTypeName), TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"job_name",&jobName),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_string",&currentTask),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"parent_name",&parentTaskName),TD_LOG_ERROR_AND_THROW);
      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_name",&synopsis),TD_LOG_ERROR_AND_THROW);

	  if( pcTargetAttachmentType != NULL && (tc_strcmp(pcTargetAttachmentType,TD_STD_ECN_REV_TYPE) == 0 )  ){
		  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[0],"td4PrimaryProject",&project),TD_LOG_ERROR_AND_THROW);
	      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[0],"td4MaterialImpact",&materialImpact),TD_LOG_ERROR_AND_THROW);			
							
	  }else if(pcTargetAttachmentType != NULL && (tc_strcmp(pcTargetAttachmentType,TD_REL_ECN_REV_TYPE) == 0 )){
		  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[0],"td4PrimaryProject",&project),TD_LOG_ERROR_AND_THROW);
	  }else if(pcTargetAttachmentType != NULL && (tc_strcmp(pcTargetAttachmentType,TD_PROTOBOM_ECN_REV_TYPE) == 0 )){
	      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[0],"td4PrimaryProject",&project),TD_LOG_ERROR_AND_THROW);
	  }
				
      bufferSubject.append(parentTaskName).append(" task is assigned to you: ").append(jobName).append(", ").append(synopsis);

	  if(project !=NULL){
		  bufferSubject.append(",").append(project);
	  }
		  
	  if(materialImpact !=NULL){
		  bufferSubject.append(",").append(materialImpact);
	  }
		 
  
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  return bufferSubject;
 }
 
 /*******************************************************************************
 * Function Name			: teradyneBuildNotificationBodyContent
 * Description				: Will build the html body content for notification 
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  bufferContent  - the html content for the notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
std::string teradyneBuildNotificationBodyContent(EPM_action_message_t msg){
  int iStatus			    = ITK_ok,
  iCount              = 0;
  string bufferHTMLContent = "<html><head></head><body>";
  char *pcComment=NULL,*jobName=NULL,*currentTask=NULL,*description=NULL,*pcDueDate;
  date_t due_date;
  tag_t *tAttaches			= NULL;
  
  
  const char * __function__    = "teradyneBuildNotificationBodyContent";
  
  try {
  
     TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"comments",&pcComment),TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"job_name",&jobName),TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_string",&currentTask),TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(msg.task,"due_date",&due_date),TD_LOG_ERROR_AND_THROW);
	 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task,"object_desc",&description),TD_LOG_ERROR_AND_THROW);
	 
	 if(due_date.year==0 && due_date.month==0 && due_date.day==0){
	      pcDueDate = (char *) MEM_alloc(sizeof(char) * 2);
		  strcpy(pcDueDate,"None");  
	 }else{
	     DATE_date_to_string	(due_date,"%d-%b-%Y %H:%M",&pcDueDate); // convert the date to string 
	 }
	 
	
	 
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
	 bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(jobName).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcComment).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(description).append("</font>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>");
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); //end table
	 bufferHTMLContent.append("<br>");
	 
	 // Target Attachments
     TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Target:</b></font>\r\n");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>\r\n");
	 
	 bufferHTMLContent.append("<tr height=\"8\">\r\n");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">\r\n");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>\r\n");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
	 
     for(int iTarget=0; iTarget < iCount;iTarget++){
	   char *pcItemId = NULL,*pcObjectType = NULL;
	   TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tAttaches[iTarget], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	   TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[iTarget],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
	   
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType); 
	 
	  }
     
     bufferHTMLContent.append("</tbody></table>\r\n"); // end target attachment tables
     bufferHTMLContent.append("<br><br>");
     
     
      // Target References
     int iRefCount=0;
	 tag_t *tReferenceAttachments;

	 TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iRefCount, &tReferenceAttachments), TD_LOG_ERROR_AND_THROW);
	 bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\"><b>Reference:</b></font>");
	 bufferHTMLContent.append("<table width=\"100%\" style=\"border-collapse:collapse;\"><tbody>");
	 
	 bufferHTMLContent.append("<tr height=\"8\">");
	 bufferHTMLContent.append("<td width=\"71%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Name</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("<td width=\"28%\" bgcolor=\"#f0f0f0\" style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\">");
	 bufferHTMLContent.append("<div align=\"center\">").append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>Type</b></font>").append("</div>");
	 bufferHTMLContent.append("</td>");
	 bufferHTMLContent.append("</tr>\r\n");
     
      
     for(int iReference=0; iReference < iRefCount;iReference++){
        char *pcItemId = NULL,*pcObjectType = NULL;
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_display_type(tReferenceAttachments[iReference], &pcObjectType), TD_LOG_ERROR_AND_THROW);
	    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tReferenceAttachments[iReference],"object_string",&pcItemId),TD_LOG_ERROR_AND_THROW);
						    
	    bufferHTMLContent.append("<tr height=\"8\">\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcItemId).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("<td style=\"border-style:solid solid solid solid;border-color:#808080;border-width:1px 1px 1px 1px;padding:1px 1px;\" >\r\n");
	    bufferHTMLContent.append("<div align=\"center\">\r\n");
	    bufferHTMLContent.append("<font size=\"3\" face=\"Arial\" >").append(pcObjectType).append("</font>\r\n");
	    bufferHTMLContent.append("</div>\r\n");
	    bufferHTMLContent.append("</td>\r\n");
	    bufferHTMLContent.append("</tr>\r\n");
	    
	    Custom_free(pcItemId); 
	    Custom_free(pcObjectType); 
	 
	 }
	 
	 bufferHTMLContent.append("</tbody></table>\r\n"); // end target references
     bufferHTMLContent.append("<br><br>");
     
     bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");
     
     
     Custom_free(tAttaches);
     Custom_free(tReferenceAttachments);
  
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  bufferHTMLContent.append("</body></html>\r\n");
  
  return bufferHTMLContent;
 }

 
/*******************************************************************************
 * Function Name			: teradyneBuildSubscriptionSubject
 * Description				: Will return the subject for subscription email
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  strSubject     - The subject for subscription
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
 std::string teradyneBuildSubscriptionSubject(tag_t tItemRevTag, string subscriptionName){
  int iStatus			    = ITK_ok;
  string bufferSubject = " ";
  char	*pcItemID		= NULL,
		*pcPartType		= NULL;
  const char * __function__    = "teradyneBuildSubscriptionSubject";
  
  try {
	  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRevTag,TD_ITEM_ID_ATTR, &pcItemID), TD_LOG_ERROR_AND_THROW);
	  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRevTag,TD_PART_TYPE_ATTR, &pcPartType), TD_LOG_ERROR_AND_THROW);
      bufferSubject.append("Part number ").append(pcItemID).append(" of type ").append(pcPartType).append(" has been created.");
	  
	  Custom_free(pcItemID);
	  Custom_free(pcPartType);
  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  return bufferSubject;
 }
 
 /*******************************************************************************
 * Function Name			: teradyneBuildSubscriptionBodyContent
 * Description				: Will build the html body content for subscription
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  bufferContent  - the html content for the subscription
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
std::string teradyneBuildSubscriptionBodyContent(tag_t tItemRevTag, string subscriptionName){
  int iStatus			    = ITK_ok;

  string bufferHTMLContent = "";

  char	*pcStdDesc	= NULL,
		*pcItemID		= NULL,
		*pcOwningUser	= NULL,
		*pcPartType		= NULL,
		*pcCreationDate		= NULL;

  date_t	creationDate;
  
  tag_t tOwningUser = NULL;

  const char * __function__    = "teradyneBuildSubscriptionBodyContent";
  
  try {
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRevTag,TD_ITEM_ID_ATTR, &pcItemID), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRevTag,TD_PART_TYPE_ATTR, &pcPartType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRevTag,TD_STANDARD_DESC_ATTR, &pcStdDesc), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(tItemRevTag, &tOwningUser), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tOwningUser, &pcOwningUser), TD_LOG_ERROR_AND_THROW); //gets the user full name
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(tItemRevTag,TD_START_DATE, &creationDate), TD_LOG_ERROR_AND_THROW);
		DATE_date_to_string	(creationDate,"%d-%b-%Y %H:%M",&pcCreationDate);

		bufferHTMLContent.append("<html>\n");
		bufferHTMLContent.append("<body>\n");
		bufferHTMLContent.append("<font face=\"Arial\">\n");
		bufferHTMLContent.append("<p>\n");
		bufferHTMLContent.append("<h3></h3>\n");
		bufferHTMLContent.append("</p>\n");
		bufferHTMLContent.append("<p>Subscription Name:  ").append(subscriptionName).append("</p>\n");
		bufferHTMLContent.append("<p>Part Number:  ").append(pcItemID).append("/").append(pcStdDesc).append("</p>\n");
		bufferHTMLContent.append("<p>Subscription object type:  ").append(pcPartType).append("</p>\n");
		bufferHTMLContent.append("<p>Notification for event:  Create</p>\n");
		bufferHTMLContent.append("<p>Owner:  ").append(pcOwningUser).append("</p>\n");
		bufferHTMLContent.append("<p>Time of event:  ").append(pcCreationDate).append("</p>\n");
		bufferHTMLContent.append("<p>Site name:  IMC--1955579894</p>\n");
		bufferHTMLContent.append("<h3>This email was sent from Teamcenter.</h3>\n");
		bufferHTMLContent.append("</font>\n");
		bufferHTMLContent.append("</body>\n");
		bufferHTMLContent.append("</html>\n");
		bufferHTMLContent.append("\n");

		Custom_free(pcPartType);
		Custom_free(pcItemID);
		Custom_free(pcStdDesc);
		Custom_free(pcOwningUser);
		Custom_free(pcCreationDate);

  } catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
		}
	}
  
  bufferHTMLContent.append("</body></html>\r\n");
  
  return bufferHTMLContent;
 }



/*******************************************************************************
 * Function Name			: teradyne_get_object_tag
 * Description				: This function retrieves object tag based on object name and object type
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      :
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_object_tag(const char* objectName,char* objectType,tag_t *objectTag) {

	int iStatus					= ITK_ok;
	int objCount                = 0;
	tag_t objTag                =NULLTAG;
	tag_t *listTag             = {NULLTAG};
	char *pcObjectType		= NULL;
	
	const char * __function__ = "teradyne_get_object_tag";
	TERADYNE_TRACE_ENTER();

	try {
		
		TERADYNE_TRACE_CALL(iStatus = WSOM_find2(objectName,&objCount,&listTag),TD_LOG_ERROR_AND_THROW);

		for(int count=0;count<objCount;count++){
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(listTag[count], &pcObjectType), TD_LOG_ERROR_AND_THROW);
		    if(tc_strcmp(pcObjectType,objectType)==0){
			    *objectTag=listTag[count];
				break;
			}

		}

		Custom_free(listTag);
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_get_cbu_from_project(tag_t tObjTag, const char* projAttr, char **pcCBU)
{
	int iStatus = ITK_ok,
		iFound = 0;

	char *pcProjAttr = NULL;

	tag_t projectTag = NULLTAG;

	const char * __function__ = "teradyne_get_cbu_from_project";
	TERADYNE_TRACE_ENTER();

	try
	{

		//Getting the project value
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjTag, projAttr, &pcProjAttr), TD_LOG_ERROR_AND_THROW);

		if (tc_strlen(pcProjAttr) > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_object_tag(pcProjAttr, TD_PROJECT_FORM_TYPE, &projectTag), TD_LOG_ERROR_AND_THROW);
			if (NULLTAG !=projectTag) {
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(projectTag, TD_CONTRL_BUSS_UNIT, pcCBU), TD_LOG_ERROR_AND_THROW);
			}
			
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcProjAttr);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/***************************************************************************************
*   Function Name       : teradyneGenerateNextTestRevisionID
*   Description         : This function returns the next numeric sequence for NextTest revision
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string theString
*                         
*
*   RETURN VALUE        : string buf
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
int teradyneGenerateNextTestRevisionID(char *currentRevID, char **newRevID)
{
     
	int iStatus					= ITK_ok;

	const char * __function__ = "teradyneGenerateNextTestRevisionID";
	TERADYNE_TRACE_ENTER();
	try 
	{
      int nextSequence;
      nextSequence =atoi(currentRevID);
	  nextSequence= nextSequence + 1;

	  char *strNewRevID ;
	  strNewRevID =(char *)malloc(100*sizeof(char));

	  sprintf(strNewRevID,"%03d",nextSequence);
	  *newRevID= strNewRevID;

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_send_to_ERP(const char* eventType, tag_t objTagRev,bool skipT4OPush)
{
	int iStatus						= ITK_ok;
	char *pcProcessTemplateName     = NULL;
	tag_t  tNewProcess              = NULLTAG;
	
	const char * __function__ = "teradyne_send_to_ERP";
	TERADYNE_TRACE_ENTER();
	try
	{
		
		char *pcDivPartID = NULL;
		char *pcObjectType = NULL;
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(objTagRev,&pcObjectType),TD_LOG_ERROR_AND_THROW);
		if(tc_strcmp(pcObjectType,TD_DIV_PART_REV)==0)
		{
			char *pcCBU = NULL;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(objTagRev, TD_CONTRL_BUSS_UNIT, &pcCBU), TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcCBU,TD_NXT)==0)
			{
				if(tc_strcmp(eventType,TD_PART_CREATED_EVENT)==0)
				{
					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_CREATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				} 
				else if(tc_strcmp(eventType,TD_PART_UPDATED_EVENT)==0)
				{
					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_UPDATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,objTagRev,&tNewProcess),TD_LOG_ERROR_AND_THROW);
			} 
			else
			{
				//Getting Preference Value to get Workflow template name
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_T4O_ITEM_PUSH_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				// Calling function to Initiate T4O_Item_Push Workflow on Created DIVPARTREVISION
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,objTagRev,&tNewProcess),TD_LOG_ERROR_AND_THROW);
			}
			Custom_free(pcCBU);
		}
		else if(tc_strcmp(pcObjectType,TD_COMM_PART_REV)==0)
		{
			char *pcCBU = NULL;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(objTagRev, TD_CONTRL_BUSS_UNIT, &pcCBU), TD_LOG_ERROR_AND_THROW);

			logical isAppliesToESI = false;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(objTagRev,TD_APPLIES_ESI_ATTR, &isAppliesToESI), TD_LOG_ERROR_AND_THROW);
			 
			if(tc_strcmp(eventType,TD_PART_CREATED_EVENT)==0)
			{
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_CREATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,objTagRev,&tNewProcess),TD_LOG_ERROR_AND_THROW);
			} 
			else if(tc_strcmp(eventType,TD_PART_UPDATED_EVENT)==0 && (tc_strcmp(pcCBU,TD_NXT)==0 || isAppliesToESI))
			{
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_UPDATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,objTagRev,&tNewProcess),TD_LOG_ERROR_AND_THROW);
			}

			logical isNXTMigPart = false;
			
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(objTagRev, &pcDivPartID), TD_LOG_ERROR_AND_THROW);
			string pcItemId = string(pcDivPartID);
			if(pcItemId.front()=='5' && pcItemId.length() == 6) 
			{
				isNXTMigPart = true;
			}

			if(!isNXTMigPart){
				//Getting Preference Value to get Workflow template name
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_T4O_ITEM_PUSH_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				//Calling function to Initiate Workflow on Created CommPartRevision
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,objTagRev,&tNewProcess),TD_LOG_ERROR_AND_THROW);
		    }
			Custom_free(pcCBU);
		}
		Custom_free(pcObjectType);
		Custom_free(pcDivPartID);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
 * Function Name			: teradyne_update_object_name
 * Description				: Update object_name with the description
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : szTypeName   (I)		   - Type of object shuould be created
 *							  szObjectName (I)		   - Object name
 *							  tCreObj		(O)		   - Created object tag
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_update_object_name(tag_t objTagRev) 
{
	//Declartion and Initialization of Local Variables
	int   iStatus              = ITK_ok;

	

	char* __function__ = "teradyne_update_object_name";
	char *pcItemRevTypeName = NULL;
	char *pctd4StandardDescription = NULL;
	char *pctd4Description =NULL;
	char *pcAttrValue=NULL;
	int textLength=0;
	tag_t tItemTag          = NULLTAG;

	try
	{
		TERADYNE_TRACE(iStatus=teradyne_ask_object_type(objTagRev, &pcItemRevTypeName));
		TERADYNE_TRACE_CALL(iStatus=ITEM_ask_item_of_rev(objTagRev,&tItemTag),TD_LOG_ERROR_AND_THROW);

		if ( strcmp(pcItemRevTypeName,TD_DIV_PART_REV)==0 ) {
		
		           TERADYNE_TRACE(iStatus=AOM_ask_value_string(objTagRev,TD_STANDARD_DESC_ATTR, &pctd4StandardDescription));

				   std::string strStandardDesc("");
				   strStandardDesc.assign(pctd4StandardDescription);
				   int textLength= strStandardDesc.length();
				   if(textLength > 40){
					   std::string strStandardDescToSave= strStandardDesc.substr(0,40);
					    pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int) (strStandardDescToSave.length() + 1));
						sprintf(pcAttrValue,"%s",strStandardDescToSave.c_str());
				   }else{
					    pcAttrValue=pctd4StandardDescription;
				   }

				  
				  
		            AM__set_application_bypass(true);// Bypass is set true to update change admin form
						//Calling function to set the property value
						TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(objTagRev,TD_OBJECT_NAME_ATTR,pcAttrValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tItemTag,TD_OBJECT_NAME_ATTR,pcAttrValue), TD_LOG_ERROR_AND_THROW);
				    AM__set_application_bypass(false);
		
		     Custom_free(pctd4StandardDescription);
		}
	

		if ( strcmp(pcItemRevTypeName,TD_COMM_PART_REV)==0 ) {
		
		           TERADYNE_TRACE(iStatus=AOM_ask_value_string(objTagRev,TD_DESC_ATTR, &pctd4Description));
				    std::string strStandardDesc("");
				    strStandardDesc.assign(pctd4Description);
				   int textLength= strStandardDesc.length();
				   if(textLength > 40){
					   std::string strStandardDescToSave= strStandardDesc.substr(0,40);
					    pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int) (strStandardDescToSave.length() + 1));
						sprintf(pcAttrValue,"%s",strStandardDescToSave.c_str());
				   }else{
					    pcAttrValue=pctd4Description;
				   }


		            AM__set_application_bypass(true);// Bypass is set true to update change admin form
						//Calling function to set the property value
						TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(objTagRev,TD_OBJECT_NAME_ATTR, pcAttrValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tItemTag,TD_OBJECT_NAME_ATTR,pcAttrValue), TD_LOG_ERROR_AND_THROW);
				    AM__set_application_bypass(false);
		    Custom_free(pctd4Description);
		}
	
		//Custom_free(pcAttrValue);


	}
	catch(...)
	{
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

bool hasInvalidChar(char* text, char **invalid) 
{
	 bool result = false;

	 char* sChars = "";
	 if( PREF_ask_char_value_at_location(TD_INVALID_CHAR_PREF,TC_preference_site, 0, &sChars ) == ITK_ok ) 
	 {
		string textString(text);
		size_t found = textString.find_first_of(sChars);

		if(found != string::npos) 
		{
			*invalid = &text[found];
			result = true;
		}
	 } 
	 else 
	 {
		 result = true;
		 *invalid = "No Preference found!";
	 }

	return result;
}



/***************************************************************************************
*   Function Name       : hasLeadingSpaces
*   Description         : This function check if inputted string has leading spaces
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string text
*                         
*
*   RETURN VALUE        : boolean
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool hasLeadingSpaces(char* text) 
{
	 bool result = false;
	 
       if(text[0]==' '){
	     result=true;
	   }


	return result;
}



/***************************************************************************************
*   Function Name       : hasTrailingSpaces
*   Description         : This function check if inputted string has trailing spaces
*   REQUIRED HEADERS    : 
*                         
*   INPUT/OUTPUT PARAMS : string text
*                         
*
*   RETURN VALUE        : boolean
*                        
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool hasTrailingSpaces(char* text) 
{
	 bool result = false;
	 
       if(text[strlen(text)-1]==' '){
	     result=true;
	   }


	return result;
}



/*******************************************************************************
* Function Name	    : teradyne_create_form
* Description		: Creates Custom form under given object
*					  in given Relation
*
* REQUIRED HEADERS	:
* INPUT PARAMS		: tRevtag            (I) - object tag
*                     strFormTypeNameMap (I) - Input has Form name and Type
*                     bisSpecification   (I) - to check Specification Relation or not
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: 1.If bisSpecification value is true Creates form in ImanSpecification Relation
*                     2.If bisSpecification value is false Creates form in DisciplineSpecific and OracleOrg Relation
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_create_form(tag_t tRevTag, std::map<string, string> strFormTypeNameMap, bool bisSpecification)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	tag_t tFormTag = NULLTAG,
		tItemTag = NULLTAG,
		tOrgRelTag = NULLTAG,
		tDisSpecRelTag = NULLTAG,
		tNewRelation = NULLTAG;

	char* __function__ = "teradyne_create_form";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tRevTag != NULLTAG)
		{
			if (bisSpecification)
			{
				//Getting ImanSpecification relation tag
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_IMAN_SPEC_REL_NAME, &tDisSpecRelTag), TD_LOG_ERROR_AND_THROW);
			}
			else
			{
				//Getting DisciplineSpecific and OracleOrg relation tags
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ORG_REL_NAME, &tOrgRelTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tDisSpecRelTag), TD_LOG_ERROR_AND_THROW);
			}
			for (std::map<string, string>::iterator it = strFormTypeNameMap.begin(); it != strFormTypeNameMap.end(); ++it)
			{
				//calling function to create form with the given type and name
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_object(it->first, it->second, &tFormTag), TD_LOG_ERROR_AND_THROW);
				if (tFormTag != NULLTAG)
				{
					if (it->first.compare(TD_ORACLE_ORG_FORM_TYPE) == 0)
					{
						//Attaching Oracle form to Part
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevTag, &tItemTag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tItemTag, tFormTag, tOrgRelTag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);
					}
					else
					{
						//Attaching form to the Revision in found relation tag
						TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevTag, tFormTag, tDisSpecRelTag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tNewRelation), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: ur_validateOwningGroup
 * Description				: Validate Owning Group of UR
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      :
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/

int ur_validateOwningGroup()
{
	int iStatus = 0,
		ValidGrp;

	char  *pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG;

	char* __function__ = "checkingOwningGroup";

	try
	{
		TERADYNE_TRACE_ENTER();

		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

		TC_write_syslog("pcRoleName :: %s", pcRoleName);
		TC_write_syslog("pcGroupName :: %s", pcGroupName);
		TC_write_syslog("pcGroupFullName :: %s", pcGroupFullName);
		char *pGrpname = "";
		pGrpname = strstr(pcGroupFullName, "UR");
		if (pGrpname != NULL)
		{
			ValidGrp = 0;
		}
		else
		{
			ValidGrp = 1;
		}
		TC_write_syslog("pGrpname :: %s", pGrpname);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcUsername);
	Custom_free(pcRoleName);
	Custom_free(pcGroupName);
	Custom_free(pcGroupFullName);
	Custom_free(pcParentGroupName);

	TERADYNE_TRACE_LEAVE(iStatus);
	//return iStatus;

	return ValidGrp;
}

int teradyne_getCOOValueforVendoPart(tag_t tVendorPart, char ** cooVendorPart, int isMFGPart) {

	int       		iStatus = ITK_ok;
	int				valueCount = 0;
	char ** 		td4CountryOfOriginVP = NULL;
	int 			iFlag = 0;
	int				iNonPendingCount = 0;
	int				iTemp = 0;
	const char * __function__ = "getTd4Country_of_OriginBase";

	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tVendorPart, TD_COUNTRY_OF_ORIGIN_LIST, &valueCount, &td4CountryOfOriginVP), TD_LOG_ERROR_AND_THROW);

		if (valueCount != 0 && valueCount != NULL) {
			for (int inx = 0; inx < valueCount; inx++)
			{
				if (strstr(td4CountryOfOriginVP[inx], "Pending") == NULL)
				{
					iNonPendingCount++;
					iTemp = inx;
				}
			}
			if (iNonPendingCount == 1)
			{
				char *token = tc_strtok(td4CountryOfOriginVP[iTemp], "|");

				*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(td4CountryOfOriginVP[iTemp])) + 1));

				tc_strcpy(*cooVendorPart, td4CountryOfOriginVP[iTemp]);
			}
			else if (valueCount == 1 && (isMFGPart == 1 || strstr(td4CountryOfOriginVP[0], "Pending") == NULL))
			{
				char *token = tc_strtok(td4CountryOfOriginVP[0], "|");

				*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(td4CountryOfOriginVP[0])) + 1));

				tc_strcpy(*cooVendorPart, td4CountryOfOriginVP[0]);
			}
			else if (valueCount > 1)
			{
				for (int iny = 0; iny < valueCount; iny++)
				{
					if (strstr(td4CountryOfOriginVP[iny], "Pending") == NULL)
					{
						char *token = tc_strtok(td4CountryOfOriginVP[iny], "|");

						if (tc_strcmp(td4CountryOfOriginVP[iny], TD_MULTI_USA) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_VIRGIN_ISLANDS) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_GUAM) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_NORTHERN_MARIANA_ISLANDS) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_AMERICAN_SAMOA) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_PUERTO_RICO) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_US_MINOR_OUTLYING_ISLANDS) == 0)
						{
							iFlag = 1;
							break;
						}
						else if (tc_strcmp(td4CountryOfOriginVP[iny], TD_USA) == 0)
						{
							iFlag = iFlag + 1;
						}
						else if (iFlag != 0)
						{
							iFlag = 1;
						}
					}
				}
				if (iFlag == valueCount)
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_USA);
				}
				else if (iFlag > 0 && iFlag < valueCount)
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_MULTI_USA);
				}
				else
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_NON_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_MULTI_NON_USA);
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


extern int teradyne_AddToTagArray(tag_t tObject, int piNumTags, tag_t **pTagArray)
{
	int ifail = ITK_ok;

	if (tObject != NULLTAG)
	{
		if ((piNumTags) == 0)
		{
			(*pTagArray) = (tag_t*)MEM_alloc(1 * sizeof(tag_t));
		}
		else
		{
			(*pTagArray) = (tag_t*)MEM_realloc((*pTagArray), sizeof(tag_t) * ((piNumTags)+1));
		}
		(*pTagArray)[piNumTags] = tObject;

	}
	return ifail;
}

int teradyne_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
	int   ifail = ITK_ok;

	// Ignore a duplicate tag.
	if (teradyne_find_tag_in_array(*tagCnt, *tagArray, addTag) > -1) 
	{
		goto CLEANUP;
	}
		

	teradyne_add_tag_to_array(tagCnt, tagArray, addTag);

CLEANUP:
	return (ifail);
}

int teradyne_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag)
{
	int   i = 0;
	int foundIdx = -1;

	if (!tagArray || (tagCnt < 1))
		goto CLEANUP;

	for (i = 0; i < tagCnt; i++)
	{
		if (tagArray[i] == tag)
		{
			foundIdx = i;
			goto CLEANUP;
		}
	}

CLEANUP:
	return foundIdx;
}

int teradyne_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
	int   ifail = ITK_ok;

	*tagArray = (tag_t *)MEM_realloc(*tagArray, sizeof(tag_t) * (*tagCnt + 1));

	if (*tagArray != NULL)
	{
		(*tagArray)[*tagCnt] = addTag;
		(*tagCnt)++;
	}
	else
	{
		goto CLEANUP;
	}

CLEANUP:
	return (ifail);
}