/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_DeviateNoticeRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in DeviateNotice ECN revision
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  ================================================================================================= 
#  =================================================================================================                    
#  Date                            Name                           Description of Change
#  5-Mar-2015                      Kameshwaran D                     Initial Creation 
#  $HISTORY$                    
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_DeviateNoticeRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :1.  				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_DeviateNoticeRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					= ITK_ok;

	tag_t   tItemtag				= NULLTAG,
			tRevtag					= NULLTAG;

	const char*	pcRevid				= NULL;

	const char* __function__		= "TD4_postaction_on_save_DeviateNoticeRevision";

	char *pcWrkFlowName = TD_DEVIATIE_NOTICE_REV_WF_PREF;

	try
	{
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		if( bisNew )
		{
			//To initiate the workflow
			TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName,tRevtag) ,TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}