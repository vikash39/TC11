//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension getTd4COO_CalculatedBase
 *
 */

#include <extensions/getTd4Country_of_OriginBase.hxx>
#include <extensions/getTd4COO_CalculatedBase.hxx>

int getTd4COO_CalculatedBase(METHOD_message_t * msg, va_list args)
{
	int       		iStatus 			= ITK_ok;
	tag_t 			tSelectedObject 		= msg->object_tag;
	tag_t  			tPropTag 			= va_arg(args, tag_t);
	char**			propCalculatedValue 		= NULL;
	char*			cooVendorPartValue 		= NULL;
	const char* 		cpAttname 			= msg->prop_name;
	propCalculatedValue = va_arg(args, char**);
	int 			iFlag 				= 0;
	tag_t 			tRelationType 			= NULLTAG;
	int			valueCount 			= 0;
	char ** 		td4CountryOfOriginVP		= NULL;
	
	
	const char * __function__ = "getTd4Country_of_OriginBase";
	TERADYNE_TRACE_ENTER();

	try
	{
		getCOOValueforVendoPart(tSelectedObject, &cooVendorPartValue, 1);

		*propCalculatedValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(cooVendorPartValue)) + 1));

		tc_strcpy(*propCalculatedValue, cooVendorPartValue);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}