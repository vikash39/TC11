/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_InitiateWorkflow.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Custom Request Objects
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  19-Feb-2015                       Haripriya                          Initial Creation
#  06-Mar-2015						 Kameshwaran D						Added function "teradyne_update_forms_of_createormodify_request" to update Model Forms value
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_InitiateWorkflow
* Description		: Postaction to initiate workflow process for DTGModlModReqRevision,
*                     PartModReqRevision,TAGModlCreReqRevision,TAGModlModReqRevision, CommercialPartRequestRevision
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and initiate workflow while creating 
*                     DTGModlModReqRevision,PartModReqRevision,TAGModlCreReqRevision,
*                     TAGModlModReqRevision,CommercialPartRequestRevision
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_CommPartReqRevisionAWC(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int  iStatus				= ITK_ok,
		 iFlag					= 0,
		 iVendorPartCount1		= 0,
		 iVendorPartCount2		= 0,
		 iVendorPartCount3		= 0,
		 iPrimaryObjCount1		= 0,
		 iPrimaryObjCount2		= 0,
		 iPrimaryObjCount3		= 0,
		 iPartExist				= 0;

	tag_t tNewProcess           = NULLTAG,
		  tRevTag				= NULLTAG,
		  tPartTypeTag1			= NULLTAG,
		  tPartTypeTag2			= NULLTAG,
		  tPartTypeTag3			= NULLTAG,
		  tVendorPartCreateInput1= NULLTAG,
		  tVendorPartCreateInput2= NULLTAG,
		  tVendorPartCreateInput3= NULLTAG,
		  tVendorPartTag1		= NULLTAG,
		  tVendorPartTag2		= NULLTAG,
		  tVendorPartTag3		= NULLTAG,
		  tVMRepresentsRelTag1	= NULLTAG,
		  tVMRepresentsRelTag2	= NULLTAG,
		  tVMRepresentsRelTag3	= NULLTAG,
		  tVendorTag1			= NULLTAG,
		  tVendorTag2			= NULLTAG,
		  tVendorTag3			= NULLTAG,
		  tRelationType1		= NULLTAG,
		  tRelationType2		= NULLTAG,
		  tRelationType3		= NULLTAG,
		  tVMRepresentsRelObject1 = NULLTAG,
		  tVMRepresentsRelObject2 = NULLTAG,
		  tVMRepresentsRelObject3 = NULLTAG,
		  *tMfgPartTags1		= NULLTAG,
		  *tMfgPartTags2		= NULLTAG,
		  *tMfgPartTags3		= NULLTAG,
		  *tPrimaryObjects1		= NULLTAG,
		  *tPrimaryObjects2		= NULLTAG,
		  *tPrimaryObjects3		= NULLTAG;

	bool bMapModelUpdate		= false,
		 is_latest				= false;

	char *pcProcessTemplateName = NULL,
		 *pcWorkflowName        = NULL,
		 *pcCBU = NULL,
		 *psManufacturer1 		= NULL,
		 *psManufacturer2		= NULL,
		 *psManufacturer3		= NULL,
		 *pcObjectType          = NULL,
		 *tTempValue			= NULL,
		 *psCommLevel1			= NULL,
		 *psSupplierCategory	= NULL,
		 *MfrPartNumber1		= NULL,
		 *MfrPartNumber2		= NULL,
		 *MfrPartNumber3 		= NULL,
		 *sStatusName			= NULL,
		 *sVendorName			= NULL;
	const char*	pcRevid			= NULL;
	

	const char* __function__ = "TD4_postaction_on_save_CommPartReqRevisionAWC";

	TERADYNE_TRACE_ENTER();


	try
	{
		tRevTag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		bool bIsConceptPart				= false;

		if( bisNew )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcObjectType),TD_LOG_ERROR_AND_THROW);
			
			if (!tc_strcmp(pcObjectType,TD_COMM_PART_REQ_REV))
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_1_ATTR, &psManufacturer1), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_2_ATTR, &psManufacturer2), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_3_ATTR, &psManufacturer3), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_PAER_1_ATTR, &MfrPartNumber1), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_PAER_2_ATTR, &MfrPartNumber2), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_PAER_3_ATTR, &MfrPartNumber3), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tRevTag, TD_IS_CONCEPT_PART, &bIsConceptPart), TD_LOG_ERROR_AND_THROW);

				if (MfrPartNumber1 != NULL && tc_strcmp(MfrPartNumber1, "") != 0 && psManufacturer1 != NULL && tc_strcmp(psManufacturer1, "") != 0)
				{
					if (strstr(psManufacturer1, "APPROVED") != NULL || strstr(psManufacturer1, "PREFERRED") != NULL)
					{		
						std::map<string, string> strVendorPartPropNameValueMap;

						strVendorPartPropNameValueMap.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber1));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strVendorPartPropNameValueMap, &iVendorPartCount1, &tMfgPartTags1), TD_LOG_ERROR_AND_THROW);

						if (iVendorPartCount1 > 0)
						{
							for (int i = 0; i < iVendorPartCount1; i++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags1[i], TD_VENDOR_REFERENCE_ATTR, &tVendorTag1), TD_LOG_ERROR_AND_THROW);

								if (tVendorTag1 != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag1, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);
									
									if (sVendorName != NULL && strstr(psManufacturer1, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType1), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags1[i], tRelationType1, &iPrimaryObjCount1, &tPrimaryObjects1), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount1 != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount1; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects1[itr], &is_latest), TD_LOG_ERROR);
												if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects1[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects1[itr], tMfgPartTags1[i], tRelationType1, &tVMRepresentsRelObject1), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject1, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															iFlag = 1;
															iPartExist = 1;
				}
													}
												}
											}
										}
									}
								}
							}
						}
						if (iFlag == 0)
				{
							TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_MFG_PART, TD_MFG_PART, &tPartTypeTag1), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tPartTypeTag1, &tVendorPartCreateInput1), TD_LOG_ERROR_AND_THROW);

							char * tempManufacturer = NULL;

							tempManufacturer = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(psManufacturer1)) + 1));

							tc_strcpy(tempManufacturer, psManufacturer1);

							char *token = tc_strtok(psManufacturer1, "|");

							int iCount = 0;

							tag_t *tVendorTags = NULLTAG;

							std::map<string, string> strPropNameValueMap;

							strPropNameValueMap.insert(::make_pair((string)TD_NAME_INPUT, (string)token));

							TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDORS", strPropNameValueMap, &iCount, &tVendorTags), TD_LOG_ERROR_AND_THROW);

							if (iCount != 0)
							{
								for (int inx = 0; inx < iCount; inx++)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4CommLevel1", &psCommLevel1), TD_LOG_ERROR_AND_THROW);

									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4SupplierCategory", &psSupplierCategory), TD_LOG_ERROR_AND_THROW);

									if (strstr(tempManufacturer, psCommLevel1) != NULL && strstr(tempManufacturer, psSupplierCategory) != NULL)
									{
										AM__set_application_bypass(true);
										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_tag(tVendorPartCreateInput1, TD_VENDOR_REFERENCE_ATTR, tVendorTags[inx]), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tVendorPartCreateInput1, TD_ITEM_ID_ATTR, MfrPartNumber1), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tVendorPartCreateInput1, &tVendorPartTag1), TD_LOG_ERROR_AND_THROW);
										if (tVendorPartTag1 != NULLTAG)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tVendorPartTag1), TD_LOG_ERROR_AND_THROW);
										}
										AM__set_application_bypass(false);
									}
								}
							}							
						}
					}
				}
				if (MfrPartNumber2 != NULL && tc_strcmp(MfrPartNumber2, "") != 0 && psManufacturer2 != NULL && tc_strcmp(psManufacturer2, "") != 0)
				{
					iFlag = 0;
					if (strstr(psManufacturer2, "APPROVED") != NULL || strstr(psManufacturer2, "PREFERRED") != NULL)
					{
						std::map<string, string> strVendorPartPropNameValueMap;
						
						strVendorPartPropNameValueMap.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber2));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strVendorPartPropNameValueMap, &iVendorPartCount2, &tMfgPartTags2), TD_LOG_ERROR_AND_THROW);
					
						if (iVendorPartCount2 > 0)
						{
							for (int i = 0; i < iVendorPartCount2; i++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags2[i], TD_VENDOR_REFERENCE_ATTR, &tVendorTag2), TD_LOG_ERROR_AND_THROW);

								if (tVendorTag2 != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag2, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);

									if (sVendorName != NULL && strstr(psManufacturer2, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType2), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags2[i], tRelationType2, &iPrimaryObjCount2, &tPrimaryObjects2), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount2 != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount2; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects2[itr], &is_latest), TD_LOG_ERROR);
												if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects2[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects2[itr], tMfgPartTags2[i], tRelationType2, &tVMRepresentsRelObject2), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject2, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															iFlag = 1;
															iPartExist = 1;
														}
													}
												}
											}
										}
									}
								}
							}
						}
						if (iFlag == 0)
						{
							TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_MFG_PART, TD_MFG_PART, &tPartTypeTag2), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tPartTypeTag2, &tVendorPartCreateInput2), TD_LOG_ERROR_AND_THROW);

							char * tempManufacturer = NULL;

							tempManufacturer = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(psManufacturer2)) + 1));

							tc_strcpy(tempManufacturer, psManufacturer2);

							char *token = tc_strtok(psManufacturer2, "|");

							int iCount = 0;

							tag_t *tVendorTags = NULLTAG;

							std::map<string, string> strPropNameValueMap;

							strPropNameValueMap.insert(::make_pair((string)TD_NAME_INPUT, (string)token));

							TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDORS", strPropNameValueMap, &iCount, &tVendorTags), TD_LOG_ERROR_AND_THROW);

							if (iCount != 0)
							{
								for (int inx = 0; inx < iCount; inx++)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4CommLevel1", &psCommLevel1), TD_LOG_ERROR_AND_THROW);

									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4SupplierCategory", &psSupplierCategory), TD_LOG_ERROR_AND_THROW);

									if (strstr(tempManufacturer, psCommLevel1) != NULL && strstr(tempManufacturer, psSupplierCategory) != NULL)
									{
										AM__set_application_bypass(true);
										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_tag(tVendorPartCreateInput2, TD_VENDOR_REFERENCE_ATTR, tVendorTags[inx]), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tVendorPartCreateInput2, TD_ITEM_ID_ATTR, MfrPartNumber2), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tVendorPartCreateInput2, &tVendorPartTag2), TD_LOG_ERROR_AND_THROW);

										if (tVendorPartTag2 != NULLTAG)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tVendorPartTag2), TD_LOG_ERROR_AND_THROW);
										}
										AM__set_application_bypass(false);
									}
								}
							}
						}
					}
				}
				if (MfrPartNumber3 != NULL && tc_strcmp(MfrPartNumber3, "") != 0 && psManufacturer3 != NULL && tc_strcmp(psManufacturer3, "") != 0)
				{
					iFlag = 0;
					if (strstr(psManufacturer3, "APPROVED") != NULL || strstr(psManufacturer3, "PREFERRED") != NULL)
					{
						std::map<string, string> strVendorPartPropNameValueMap;

						strVendorPartPropNameValueMap.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber3));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strVendorPartPropNameValueMap, &iVendorPartCount3, &tMfgPartTags3), TD_LOG_ERROR_AND_THROW);

						if (iVendorPartCount3 > 0)
						{
							for (int i = 0; i < iVendorPartCount3; i++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags3[i], TD_VENDOR_REFERENCE_ATTR, &tVendorTag3), TD_LOG_ERROR_AND_THROW);

								if (tVendorTag3 != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag3, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);

									if (sVendorName != NULL && strstr(psManufacturer3, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType3), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags3[i], tRelationType3, &iPrimaryObjCount3, &tPrimaryObjects3), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount3 != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount3; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects3[itr], &is_latest), TD_LOG_ERROR);
												if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects3[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects3[itr], tMfgPartTags3[i], tRelationType3, &tVMRepresentsRelObject3), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject3, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															iFlag = 1;
															iPartExist = 1;
														}
													}
												}
											}
										}
									}
								}
							}
						}
						if (iFlag == 0)
						{
							TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_MFG_PART, TD_MFG_PART, &tPartTypeTag3), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tPartTypeTag3, &tVendorPartCreateInput3), TD_LOG_ERROR_AND_THROW);

							char * tempManufacturer = NULL;

							tempManufacturer = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(psManufacturer3)) + 1));

							tc_strcpy(tempManufacturer, psManufacturer3);

							char *token = tc_strtok(psManufacturer3, "|");

							int iCount = 0;

							tag_t *tVendorTags = NULLTAG;

							std::map<string, string> strPropNameValueMap;

							strPropNameValueMap.insert(::make_pair((string)TD_NAME_INPUT, (string)token));

							TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDORS", strPropNameValueMap, &iCount, &tVendorTags), TD_LOG_ERROR_AND_THROW);

							if (iCount != 0)
							{
								for (int inx = 0; inx < iCount; inx++)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4CommLevel1", &psCommLevel1), TD_LOG_ERROR_AND_THROW);

									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTags[inx], "td4SupplierCategory", &psSupplierCategory), TD_LOG_ERROR_AND_THROW);

									if (strstr(tempManufacturer, psCommLevel1) != NULL && strstr(tempManufacturer, psSupplierCategory) != NULL)
									{
										AM__set_application_bypass(true);
										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_tag(tVendorPartCreateInput3, TD_VENDOR_REFERENCE_ATTR, tVendorTags[inx]), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tVendorPartCreateInput3, TD_ITEM_ID_ATTR, MfrPartNumber3), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tVendorPartCreateInput3, &tVendorPartTag3), TD_LOG_ERROR_AND_THROW);

										if (tVendorPartTag3 != NULLTAG)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tVendorPartTag3), TD_LOG_ERROR_AND_THROW);
										}
										AM__set_application_bypass(false);
									}
								}
							}
						}
					}
				}
				if (iPartExist == 0)
				{
					AM__set_application_bypass(false);
					tag_t	tObjTypeTag = NULLTAG, tObjRevTypeTag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_COMM_PART, TD_COMM_PART, &tObjTypeTag), TD_LOG_ERROR_AND_THROW);
					tag_t tCommPartCreateInput = NULL;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tObjTypeTag, &tCommPartCreateInput), TD_LOG_ERROR_AND_THROW);

					tag_t tCommPartTag = NULL;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tCommPartCreateInput, &tCommPartTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartTag, TD_OBJECT_NAME_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tCommPartTag), TD_LOG_ERROR_AND_THROW);

					tag_t	tCommPartRevTag = NULL;
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tCommPartTag, &tCommPartRevTag), TD_LOG_ERROR_AND_THROW);

					string szCreRequestPart_Attr[] = { TD_PROJECT_NAME_ATTR,TD_REQUESTORS_DIV };

					std::list<string> strCreReqPartAttrList(szCreRequestPart_Attr, szCreRequestPart_Attr + sizeof(szCreRequestPart_Attr) / sizeof(string));

					std::map<string, string> strPropNameValueMap;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevTag, strCreReqPartAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_DESCR_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_PROJECT_NAME_ATTR, strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_CONTRL_BUSS_UNIT, strPropNameValueMap.find(TD_REQUESTORS_DIV)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_ITEM_STATUS_ATTR, TD_PROTO_TYPE_ATTR), TD_LOG_ERROR_AND_THROW);

					tag_t  tReqResultsRelTag = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_REQ_RESULTS_IN_PART_REL, &tReqResultsRelTag), TD_LOG_ERROR_AND_THROW);

					if (tReqResultsRelTag != NULLTAG)
					{

						tag_t tNewRelation = NULLTAG;

						//Attach to Comm Part Request (Results In)
						TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevTag, tCommPartTag, tReqResultsRelTag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);

						if (tNewRelation != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tNewRelation), TD_LOG_ERROR_AND_THROW);
						}
					}
					if (tVendorPartTag1 != NULLTAG)
					{
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME, &tVMRepresentsRelTag1), TD_LOG_ERROR_AND_THROW);

						if (tVMRepresentsRelTag1 != NULLTAG)
						{
							tag_t tVendorRelationTag = NULLTAG;

							TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tCommPartRevTag, tVendorPartTag1, tVMRepresentsRelTag1, NULLTAG, &tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							if (tVendorRelationTag != NULLTAG)
							{
								TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					if (tVendorPartTag2 != NULLTAG)
					{
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME, &tVMRepresentsRelTag2), TD_LOG_ERROR_AND_THROW);

						if (tVMRepresentsRelTag2 != NULLTAG)
						{
							tag_t tVendorRelationTag = NULLTAG;

							TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tCommPartRevTag, tVendorPartTag2, tVMRepresentsRelTag2, NULLTAG, &tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							if (tVendorRelationTag != NULLTAG)
							{
								TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					if (tVendorPartTag3 != NULLTAG)
					{
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME, &tVMRepresentsRelTag3), TD_LOG_ERROR_AND_THROW);

						if (tVMRepresentsRelTag3 != NULLTAG)
						{
							tag_t tVendorRelationTag = NULLTAG;

							TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tCommPartRevTag, tVendorPartTag3, tVMRepresentsRelTag3, NULLTAG, &tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							if (tVendorRelationTag != NULLTAG)
							{
								TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tVendorRelationTag), TD_LOG_ERROR_AND_THROW);
							}
						}
					}

					TERADYNE_TRACE_CALL(iStatus = teradyne_create_discipleSpecificForms(tCommPartRevTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tCommPartRevTag, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_CONTRL_BUSS_UNIT, pcCBU), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = ITEM_save_rev(tCommPartRevTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = ITEM_save_item(tCommPartTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_ESI_ITEM_CREATE_WF_PREF, TC_preference_site, 0, &pcProcessTemplateName), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName, "", EPM_target_attachment, tCommPartRevTag, &tNewProcess), TD_LOG_ERROR_AND_THROW);

					// -----------------     Submit created comm part revision  to workflow ---------------

					//Getting Preference Value to get Workflow template name

					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_T4O_ITEM_PUSH_WF_PREF, TC_preference_site, 0, &pcProcessTemplateName), TD_LOG_ERROR_AND_THROW);

					// Calling function to Initiate T4O_Item_Push Workflow on commercial part revision
					TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName, "", EPM_target_attachment, tCommPartRevTag, &tNewProcess), TD_LOG_ERROR_AND_THROW);

					AM__set_application_bypass(false);
				}
					if (bIsConceptPart)
					{
						AM__set_application_bypass(true);
						tag_t	tObjTypeTag = NULLTAG, tObjRevTypeTag = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_COMM_PART, TD_COMM_PART, &tObjTypeTag), TD_LOG_ERROR_AND_THROW);
						tag_t tCommPartCreateInput = NULL;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tObjTypeTag, &tCommPartCreateInput), TD_LOG_ERROR_AND_THROW);

						tag_t tCommPartTag = NULL;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tCommPartCreateInput, &tCommPartTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartTag,TD_OBJECT_NAME_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus=AOM_save_with_extensions(tCommPartTag),TD_LOG_ERROR_AND_THROW);

					tag_t	tCommPartRevTag = NULL;
					TERADYNE_TRACE_CALL(iStatus=ITEM_ask_latest_rev(tCommPartTag,&tCommPartRevTag),TD_LOG_ERROR_AND_THROW);

					string szCreRequestPart_Attr[]	= {TD_PROJECT_NAME_ATTR,TD_REQUESTORS_DIV};
						
					std::list<string> strCreReqPartAttrList( szCreRequestPart_Attr, szCreRequestPart_Attr + sizeof(szCreRequestPart_Attr) / sizeof(string) );

					std::map<string,string> strPropNameValueMap;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevTag,strCreReqPartAttrList,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_DESCR_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_PROJECT_NAME_ATTR, strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_CONTRL_BUSS_UNIT, strPropNameValueMap.find(TD_REQUESTORS_DIV)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_ITEM_STATUS_ATTR,TD_PROTO_TYPE_ATTR),TD_LOG_ERROR_AND_THROW);

					tag_t  tReqResultsRelTag = NULLTAG; 
			
					TERADYNE_TRACE_CALL(iStatus=GRM_find_relation_type(TD_REQ_RESULTS_IN_PART_REL,&tReqResultsRelTag),TD_LOG_ERROR_AND_THROW);

						if (tReqResultsRelTag != NULLTAG)
						{

							tag_t tNewRelation = NULLTAG;

						//Attach to Comm Part Request (Results In)
						TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(tRevTag,tCommPartTag,tReqResultsRelTag,NULLTAG,&tNewRelation),TD_LOG_ERROR_AND_THROW);

						if(tNewRelation != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tNewRelation),TD_LOG_ERROR_AND_THROW);
						}
					}


					TERADYNE_TRACE_CALL(iStatus = teradyne_create_discipleSpecificForms(tCommPartRevTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tCommPartRevTag, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_CONTRL_BUSS_UNIT, pcCBU), TD_LOG_ERROR_AND_THROW);




					TERADYNE_TRACE_CALL(iStatus=ITEM_save_rev(tCommPartRevTag),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus=ITEM_save_item(tCommPartTag),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_CREATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				    TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tCommPartRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);

					// -----------------     Submit created comm part revision  to workflow ---------------

					//Getting Preference Value to get Workflow template name
				
					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_T4O_ITEM_PUSH_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				
					 // Calling function to Initiate T4O_Item_Push Workflow on commercial part revision
				     TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tCommPartRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);

						AM__set_application_bypass(false);
					}

			}
			
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcObjectType);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
