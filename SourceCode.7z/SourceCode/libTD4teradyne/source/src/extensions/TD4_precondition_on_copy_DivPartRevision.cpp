/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_copy_DivPartRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for precondition to check whether Divisional Part revision can be revised or not
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  09-Feb-2015						 Haripriya                          Initial Creation
#  17-Feb-2015						 Haripriya                          Change Admin Role can Revise if  DivPartRevision is not in the Teradyne Revision Scheme
#  17-Apr-2015						 Haripriya                          Modified the code to work as per teradyne Revision scheme
#  28-Apr-2015						 Haripriya                          Modified the code to work as per teradyne Revision scheme
#  20-May-2015						 Haripriya                          Modified the code for freeing memory
#  02-Jun-2015						 Vijayasekhar                       Modified the code to handle the preference values
#  18-Jun-2015						 Vijayasekhar                       Added Revision rule condition for non CM Admin group
#  23-Jun-2015					     Vijayasekhar                       Added current timestamp to the file path related to mail content
#  30-Jun-2015						 Vijayasekhar                       Added condition to handle Revision skip letters for DivPart
#  17-Jul-2015                       Manimaran                          Commented the code which prevents the user from skipping the revision id.
#  30-Sep-2015                       Manimaran                          Modified the code to check whether the Part Revision being revised is the Latest Revision.
#  23-Dec-2015                       Manimaran                          Modified the code to enable teradyne revision scheme check for CM Admin and to send mail to all users assigned to custom Address List in TC.
#  24-Dec-2015                       Manimaran                          Added code to get the new revision id if the system returned revision id is null.
#  02-Feb-2018						 Karl Reimann						Added check if revision is not in schema/rule and prevent revising and send a mail to the revision list
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_precondition_on_copy_DivPartRevision
* Description		: PreCondition to check Revise Operation is possible or not
*                           
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1.Gets the value of DivpartRevision,checks whether it is attached to Impacted Items Relation.
*					  2.If the Relation is Found,then the validate revision scheme,else throw an error.
*                           
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_precondition_on_copy_DivPartRevision(METHOD_message_t *msg , va_list args)
{
	int     iStatus				   = ITK_ok,
			iprefcnt               = 0,
			iIndexWorkflow         = 0,
			iReferencers           = 0;

	char    *pcCurRevId			   = NULL,
			**prefvalue            = NULL,
			 *pcObjectString       = NULL,
			 *pcControllingBusUnit  =NULL,
			 *pcRevId               =NULL,
			 *pcPrevRevId           = NULL;

	char	*pcRoleName = NULL,
			*pcGroupFullName = NULL,
			*pcGroupName = NULL,
			*pcUsername = NULL,
			*pcParentGroupName = NULL;

	tag_t   tRevTag                = NULLTAG,
			tRelationTag           = NULLTAG,
			*tReferencerTag        = {NULLTAG},
			tLatestRev			   = NULLTAG, 
			tUserTag			   = NULLTAG,
			tRoleTag = NULLTAG,
			tGroupTag = NULLTAG;


	std::map<string,string> strRevNameValueMap;

	const char* __function__ = "TD4_precondition_on_copy_DivPartRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments from item_copy_rev msg
		tRevTag = va_arg(args, tag_t);
		pcCurRevId = va_arg(args, char*);

		// Added by Anandha Bharathi on 8-2-2021 

		// Set RevisionScheme preference for based on owning Group is either R&D.UR or BusinessAdmin.CM Admin.UR or dba

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

			if (pcGroupFullName != NULL)
			{
				if (strcmp(pcGroupFullName, TD_UR_ADMIN_GRP_CONSTANT) == 0 || strcmp(pcGroupFullName, TD_UR_RD_GRP_CONSTANT) == 0 || strcmp(pcGroupFullName, TD_DBA_GROUP) ==0)
				{
					// UR revision Scheme
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_UR_REV_PREF, TC_preference_site, &iprefcnt, &prefvalue), TD_LOG_ERROR_AND_THROW);
				}
			}
			else
			{
				// TER Revision Scheme
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_TERADYNE_REV_PREF, TC_preference_site, &iprefcnt, &prefvalue), TD_LOG_ERROR_AND_THROW);
			}
		
		for(int i=0;i<iprefcnt;i++)
		{
			string szvalue=prefvalue[i];
			size_t ifound=szvalue.find(":");
			strRevNameValueMap.insert(::make_pair(szvalue.substr(0,ifound),szvalue.substr(ifound+1)));
		}
		//Getting  where Referenced Value for given Revtag
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_IMPACTED_ITEM_REL_NAME,&tRelationTag),TD_LOG_ERROR_AND_THROW);			
		TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only( tRevTag,tRelationTag,&iReferencers,&tReferencerTag),TD_LOG_ERROR_AND_THROW);

		//if CMHasImpactedItem Relation is found,validates the existing Revision
		if( (tReferencerTag != NULLTAG ))
		{
			//Getting Previous Revision Id
			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tRevTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);

			
			//Check if the revision copied to impacted folder exist in workflows(StandardECN,ProtoBOMECN,ReleaseECN)
			tag_t *pcFindAllWorkflows = {NULLTAG};
			
			
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tRevTag,TD_FND_STARTED_WORKFLOWS,&iIndexWorkflow,&pcFindAllWorkflows), TD_LOG_ERROR_AND_THROW);
			
			EMH_clear_errors();

		    if(pcFindAllWorkflows !=NULLTAG){

			    for(int iCount=0;iCount<iIndexWorkflow;iCount++) {
				
				     TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(pcFindAllWorkflows[iCount],TD_OBJECT_STRING, &pcObjectString),TD_LOG_ERROR_AND_THROW);
				     string workflowType(pcObjectString);

				     if( (workflowType.compare("TER_ProtoBOMECNWF")==0) || (workflowType.compare("TER_ReleaseECNWF")==0)  || (workflowType.compare("TER_StandardChangeECNWF"))==0 ){
			           TERADYNE_TRACE_CALL(iStatus=EMH_store_error(EMH_severity_error,TD_ITEM_EXIST_IN_WORKFLOW_ERROR), TD_LOG_ERROR_AND_THROW);
				       iStatus = TD_ITEM_EXIST_IN_WORKFLOW_ERROR;
				       throw iStatus;
				     }
		    
				Custom_free(pcObjectString);
				}
			
			Custom_free(pcFindAllWorkflows);
			}

			if (tRevTag != tLatestRev) {
				TERADYNE_TRACE_CALL(iStatus=EMH_store_error(EMH_severity_error, TD_NOT_LATEST_REV_ERROR), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_NOT_LATEST_REV_ERROR;
				throw iStatus;
			}

			if(tLatestRev != NULLTAG) {

				TERADYNE_TRACE_CALL(iStatus=ITEM_ask_rev_id2( tLatestRev, &pcPrevRevId),TD_LOG_ERROR_AND_THROW);
			}



			//Check if the div part controlling business unit is Nextest and has numeric revision , the sequence of revision will be numeric
			// IF true, dont proceed with the standard business validation exit in this function a let the post action handle the logic for Nextest
	        TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tRevTag,TD_CONTRL_BUSS_UNIT, &pcControllingBusUnit),TD_LOG_ERROR_AND_THROW);
		    TERADYNE_TRACE_CALL(iStatus=ITEM_ask_rev_id2(tRevTag, &pcRevId),TD_LOG_ERROR_AND_THROW);
		    string controllingBusUnit(pcControllingBusUnit);
		    if(isDigitWSAllowed(pcRevId) && controllingBusUnit.compare(TD_NXT)==0){
               return ITK_ok;
		    }
			/*#################################  End Checking for Nextest   ############################ */


			string StrPrevRevId(pcPrevRevId);
			bool bNonAlpha;
			bNonAlpha = !std::regex_match(StrPrevRevId, std::regex("^[A-Z]+$"));

			//checking current and terayne revision scheme
			if(strRevNameValueMap.find(pcPrevRevId) != strRevNameValueMap.end()) {

				string strCurRevId(pcCurRevId);

				if (strCurRevId.length() == 0 && strCurRevId == "") {
					tag_t tItemTag = NULLTAG;
					tag_t tItemTypeTag = NULLTAG;
					bool bIsModifiable = false;
					char *pcNewRevId = NULL;

					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevTag, &tItemTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_object_type(tItemTag, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = ITEM_new_revision_id(tItemTag, tItemTypeTag, &bIsModifiable, &pcNewRevId), TD_LOG_ERROR_AND_THROW);

					strCurRevId.assign(pcNewRevId);
					Custom_free(pcNewRevId);
				}

				if(strCurRevId.compare(strRevNameValueMap.find(pcPrevRevId)->second) != 0) {

					//content for mail notification
					string strCurTimeStamp = "";
					date_t currDate;
					TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", strCurTimeStamp, currDate), TD_LOG_ERROR_AND_THROW);

					char *pcDivPartID = NULL;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tRevTag, &pcDivPartID), TD_LOG_ERROR_AND_THROW);

					string szMailContent = "";
					szMailContent.append(TD_DIVPART_REV_MISMATCH_MAIL_BODY).append(pcDivPartID).append(" and ").append(strCurRevId);
					string strMailFilePath = TD_TEMP_PATH;
					strMailFilePath.append("DIVPART_REVISONMISMATCH_").append(strCurTimeStamp).append(".txt");
					TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, szMailContent), TD_LOG_ERROR_AND_THROW);

					char *pcReviseList = NULL;
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_REVISE_ADDRESS_LIST_PREF, TC_preference_site, 0, &pcReviseList), TD_LOG_ERROR_AND_THROW);
					tag_t tDistributionList = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = MAIL_find_alias_list2(pcReviseList, &tDistributionList), TD_LOG_ERROR_AND_THROW);

					int iMemberCount = 0;
					char **pcMembers = NULL;
					TERADYNE_TRACE_CALL(iStatus = MAIL_ask_alias_list_members(tDistributionList, &iMemberCount, &pcMembers), TD_LOG_ERROR_AND_THROW);

					for (int iUserCount = 0; iUserCount < iMemberCount; iUserCount++) {
						tag_t tUserTag = NULLTAG;
						char *the_sender_email_addr = NULL;

						TERADYNE_TRACE_CALL(iStatus = SA_find_user2(pcMembers[iUserCount], &tUserTag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW);

						if (tc_strlen(the_sender_email_addr) > 0 && the_sender_email_addr != NULL)
						{
							TERADYNE_TRACE_CALL(iStatus=teradyne_send_os_mail(TD_DIVPART_REV_MISMATCH_MAIL_SUBJECT,strMailFilePath,the_sender_email_addr),TD_LOG_ERROR_AND_THROW);
						}
						Custom_free(the_sender_email_addr);
					}

					DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail

					TERADYNE_TRACE_CALL(iStatus=EMH_store_error_s2(EMH_severity_error, TD_DIV_PART_REV_FORMAT_ERROR, pcDivPartID, pcPrevRevId),TD_LOG_ERROR_AND_THROW);
					iStatus = TD_DIV_PART_REV_FORMAT_ERROR;
					Custom_free(pcDivPartID);
					Custom_free(pcReviseList);
					Custom_free(pcMembers);
				    throw iStatus;
				}
			}
			else if(bNonAlpha)
			{
				//content for mail notification
				string strCurTimeStamp = "";
				date_t currDate;
				TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", strCurTimeStamp, currDate), TD_LOG_ERROR_AND_THROW);

				char *pcDivPartID = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tRevTag, &pcDivPartID), TD_LOG_ERROR_AND_THROW);

				string szMailContent = "";
				szMailContent.append(TD_DIVPART_REV_NOT_IN_REV_RULE_BODY).append(pcDivPartID).append(" and ").append(StrPrevRevId);
				string strMailFilePath = TD_TEMP_PATH;
				strMailFilePath.append("TD_DIVPART_REV_NOT_IN_REV_RULE").append(strCurTimeStamp).append(".txt");
				TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, szMailContent), TD_LOG_ERROR_AND_THROW);

				char *pcReviseList = NULL;
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_REVISE_ADDRESS_LIST_PREF, TC_preference_site, 0, &pcReviseList), TD_LOG_ERROR_AND_THROW);
				tag_t tDistributionList = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = MAIL_find_alias_list2(pcReviseList, &tDistributionList), TD_LOG_ERROR_AND_THROW);

				int iMemberCount = 0;
				char **pcMembers = NULL;
				TERADYNE_TRACE_CALL(iStatus = MAIL_ask_alias_list_members(tDistributionList, &iMemberCount, &pcMembers), TD_LOG_ERROR_AND_THROW);

				for (int iUserCount = 0; iUserCount < iMemberCount; iUserCount++) {
					tag_t tUserTag = NULLTAG;
					char *the_sender_email_addr = NULL;

					TERADYNE_TRACE_CALL(iStatus = SA_find_user2(pcMembers[iUserCount], &tUserTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW);

					if (tc_strlen(the_sender_email_addr) > 0 && the_sender_email_addr != NULL)
					{
						TERADYNE_TRACE_CALL(iStatus=teradyne_send_os_mail(TD_DIVPART_REV_NOT_IN_REV_RULE_SUBJECT,strMailFilePath,the_sender_email_addr),TD_LOG_ERROR_AND_THROW);
					}
					Custom_free(the_sender_email_addr);
				}

				DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail

				TERADYNE_TRACE_CALL(iStatus=EMH_store_error_s2(EMH_severity_error, TD_DIV_PART_REV_NOT_IN_SCHEMA_ERROR, pcDivPartID, pcPrevRevId),TD_LOG_ERROR_AND_THROW);
				iStatus = TD_DIV_PART_REV_NOT_IN_SCHEMA_ERROR;
				Custom_free(pcDivPartID);
				Custom_free(pcReviseList);
				Custom_free(pcMembers);
				throw iStatus;
			}
		}
		else
		{
			//if CMHasImpactedItem Relation is not found,throws an error
			TERADYNE_TRACE_CALL(iStatus=EMH_store_error(EMH_severity_error,TD_DIV_PART_IMPACTED_ITEM_ERROR),TD_LOG_ERROR_AND_THROW);
			iStatus = TD_DIV_PART_IMPACTED_ITEM_ERROR;
			throw iStatus;
		}		
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tReferencerTag);
	Custom_free(pcPrevRevId);
	Custom_free(prefvalue);
	

	TERADYNE_TRACE_LEAVE(iStatus);	
	return iStatus;
}
