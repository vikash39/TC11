/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_CMHasSolutionItem.cpp
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in CMHasSolutionItem
#      Project         :           libTD4teradyne          
#      Author          :           Manimaran
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Nov-2015                       Manimaran                          Initial Creation
#  19-Nov-2015                       Manimaran                          Added code to get the ECN Revision synopsis value and update the Divisional Part Revision attached in solution item folder.
#  16-Mar-2016                       Manimaran                          Modified the code to fix access denied error when div part revision (released or in t4o workflow) is pasted in solution items folder of ReleaseECN.
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_postaction_on_create_CMHasSolutionItem
 * Description      : This function will be executed whenever IMAN_save
 *                    happens on CMHasSolutionItem between ECN Revision
 *                    and Part Revision
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I) - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_postaction_on_create_CMHasSolutionItem(METHOD_message_t*  msg, va_list args)
{
	int iStatus					= ITK_ok;

	char  *pcPrimaryTypeName    = NULL,
		  *pcSecondaryTypeName  = NULL;

	tag_t tObject               = NULLTAG,
	      tPrimaryObject        = NULLTAG,
		  tSecondaryObject      = NULLTAG;

	const char* __function__ = "TD4_postaction_on_create_CMHasSolutionItem";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);

		//Getting Primary and Secondary Object for the Relation
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject, &tPrimaryObject),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject, &tSecondaryObject),TD_LOG_ERROR_AND_THROW);
		if ((tPrimaryObject != NULLTAG) && (tSecondaryObject != NULLTAG))
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject, &pcPrimaryTypeName),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject, &pcSecondaryTypeName),TD_LOG_ERROR_AND_THROW);

			if(((tc_strcmp(pcPrimaryTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_REL_ECN_REV_TYPE) == 0)) && (tc_strcmp(pcSecondaryTypeName, TD_DIV_PART_REV) == 0))
			{
				char *pcSynopsis = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPrimaryObject, TD_ECN_SYNOP, &pcSynopsis),TD_LOG_ERROR_AND_THROW);
				POM_AM__set_application_bypass(true);
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tSecondaryObject, TD_SYNOPSIS_ATTR, pcSynopsis), TD_LOG_ERROR_AND_THROW);
				POM_AM__set_application_bypass(false);
				Custom_free(pcSynopsis);
			}
		}
	} 
	catch(...)
	{
		POM_AM__set_application_bypass(false);
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
