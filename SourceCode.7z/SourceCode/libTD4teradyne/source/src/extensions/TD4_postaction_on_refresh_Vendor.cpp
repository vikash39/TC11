
/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_refresh_Vendor.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on Iman_refresh in Vendor
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Feb-2015                       Haripriya                          Initial Creation
#  12-Nov-2015                       Manimaran                          Modified the code to update the Manufacturer LOV when the same vendor is classified under different classes.
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_postaction_on_refresh_Vendor
 * Description      : This function will be executed whenever Iman_refresh is called on 
 *                    Vendor.
 *                    
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I)  - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 1.On Iman_refresh,if lock is modifiable,vendor is explicitly
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_postaction_on_refresh_Vendor(METHOD_message_t*  msg, va_list args)
{
	int iStatus					= ITK_ok;

	tag_t tObject               = NULLTAG,
	      vendor_tag        = NULLTAG,
		  tSecondaryObject      = NULLTAG;

	const char* __function__ = "TD4_postaction_on_refresh_Vendor  ";
	TERADYNE_TRACE_ENTER();

	try
	{ 
		vendor_tag = va_arg(args, tag_t);
		bool bLock =va_arg(args, logical);

		if(bLock)
		{   
			tag_t tRelationTag = NULLTAG;
			int iObjCount = 0;
			tag_t *tObjFoundTag = NULL;
			char *pcSMZeroFiveValue = NULL;
			char *pcSMZeroOneValue = NULL;
			char *pcObjName = NULL;

			vector<string> vSupplierRatingValues;

			if (vendor_tag != NULLTAG) {
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(vendor_tag, TD_OBJECT_NAME_ATTR, &pcObjName), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_IMAN_CLASSIFICATION_REL_NAME, &tRelationTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(vendor_tag, tRelationTag, &iObjCount, &tObjFoundTag),TD_LOG_ERROR_AND_THROW);

				if (iObjCount > 0) {
					for (int i=0; i < iObjCount; i++) {

						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_ICM0_SM05_ATTR, &pcSMZeroFiveValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_ICM0_SM01_ATTR, &pcSMZeroOneValue), TD_LOG_ERROR_AND_THROW);

						string szORSymbol = TD_OR_CONSTANT;
						string szTempVal = pcObjName + szORSymbol + pcSMZeroFiveValue + szORSymbol + pcSMZeroOneValue;

						vSupplierRatingValues.push_back(szTempVal);
						Custom_free(pcSMZeroFiveValue);
						Custom_free(pcSMZeroOneValue);

					}
					char **pcSuppRatingarray   = NULL;

					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array(vSupplierRatingValues, &pcSuppRatingarray),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(vendor_tag, TD_SUPPLIER_RATINGS_ATTR, (int)vSupplierRatingValues.size(), pcSuppRatingarray),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcSuppRatingarray);
					vSupplierRatingValues.clear();

				}

				Custom_free(pcObjName);
				Custom_free(tObjFoundTag);
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
