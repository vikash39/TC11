/*==================================================================================================                    
#                Copyright (c) 2020 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_format_change_reason_history.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for formatting Change Reason History
#      Project         :           libTD4teradyne          
#      Author          :           Rodji C. Sande          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#   $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>


typedef map<string,string> MapChangeReason;

struct ChangeReasonComparator{
  bool operator()(MapChangeReason changeReasonOne,MapChangeReason changeReasonTwo ){
	   return (changeReasonOne.find(TD_CHANGE_REASON_SORT_KEY)->second > changeReasonTwo.find(TD_CHANGE_REASON_SORT_KEY)->second);
   }

};

/*******************************************************************************
 * Function Name    : teradyne_format_change_reason_history
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int teradyne_format_change_reason_history(METHOD_message_t*  m, va_list args)
{
	int iStatus = ITK_ok,
	    iPriCount =0 ,
		iSecCount =0 ;
	tag_t tProperty = va_arg(args, tag_t);
	char **pcValue = va_arg(args, char**);
	tag_t tItemRev = NULLTAG;
	tag_t tUser					= NULLTAG,
		  tRelationType			= NULLTAG,
		  *ptPriObjs			= NULL,
		  *ptSecObjs			= NULL;
    char  *pcChangeHistory = NULL,
		  *pcObjTypeName = NULL,
	      *pcObject;
	char  *pcFormattedChangeHistory=NULL;
	const char * __function__ = "teradyne_format_change_reason_history";
	TERADYNE_TRACE_ENTER();

	try {
		
		METHOD_PROP_MESSAGE_OBJECT(m, tItemRev);


		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjTypeName), TD_LOG_ERROR_AND_THROW);
		if (pcObjTypeName != NULL && tc_strcmp(pcObjTypeName, TD_VENDOR) == 0) {
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_CHG_HSTRY_ATTR, &pcChangeHistory), TD_LOG_ERROR_AND_THROW);
		}
		else {
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tRelationType), TD_LOG_ERROR_AND_THROW);
			if (tRelationType != NULLTAG) {
				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tItemRev, tRelationType, &iSecCount, &ptSecObjs), TD_LOG_ERROR_AND_THROW);
				for (int i = 0; i < iSecCount; i++) {

					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptSecObjs[i], &pcObjTypeName), TD_LOG_ERROR_AND_THROW); //getting the object type name
					if (pcObjTypeName != NULL && tc_strcmp(pcObjTypeName, TD_CHANGEHISTORY_FORM_TYPE) == 0) {
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptSecObjs[i], TD_CHG_HSTRY_ATTR, &pcChangeHistory), TD_LOG_ERROR_AND_THROW);
					}
				}
			}
		}

		if (pcChangeHistory != NULL) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_transform_change_history(pcChangeHistory, &pcFormattedChangeHistory),TD_LOG_ERROR_AND_THROW);
			*pcValue = (char*)MEM_alloc((int)(strlen(pcFormattedChangeHistory) + 1 * sizeof(char)));
			strcpy(*pcValue, pcFormattedChangeHistory);
			Custom_free(pcFormattedChangeHistory);
		}
		

	}
	catch (...) {
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	
	}

	return iStatus;
}




int teradyne_transform_change_history(char* changeReasonHistory, char** formattedChangeHistory){

  
  int iStatus = ITK_ok;
  
  const char *changeReasonHistorySeparator="------";
  string changeReason;

  vector<string> vChangeReasonHistory;
  vector<string> vChangeReason;
  set<MapChangeReason, ChangeReasonComparator> setMapChangeReason;
  

 const char * __function__ = "teradyne_transform_change_history";
 TERADYNE_TRACE_ENTER();
  try {

	  if (!setMapChangeReason.empty()) {
		  setMapChangeReason.clear();
	  }
	  
	  string replaceFrom(changeReasonHistorySeparator);
	  string changeReasonHistoryToParse(changeReasonHistory);
	  TERADYNE_TRACE_CALL(iStatus = replace_all_string(changeReasonHistoryToParse,replaceFrom,"|" ), TD_LOG_ERROR_AND_THROW);
	  
	  
	  vChangeReasonHistory=teradyne_generate_tokens(changeReasonHistoryToParse,"|");

	  int vSizeChangeReasonHistory = vChangeReasonHistory.size();
	  
	       for(int i=0;i< vSizeChangeReasonHistory;i++){

              if (tc_strcmp(vChangeReasonHistory[i].c_str(),"\n") && vChangeReasonHistory[i].length() > 0) {
				  changeReason = vChangeReasonHistory[i].c_str();
				  vChangeReason = splitString(changeReason,">", true);
				  string strDateTimeStamp ;
				  vector<string> vStrDateTimeStamp;
				  vector<string> vStrDate;
				  string strFormattedDateTimeStamp("");
				  string strChangeReasonSortKey("");
				  
				  MapChangeReason mapChangeReason;
				 
				  if (vChangeReason.size()==3) {
					  strDateTimeStamp = vChangeReason[1];
					  if (strstr(changeReason.c_str(), "--->") != NULL) {
						  if (strstr(strDateTimeStamp.c_str(), "/") != NULL) {
							  vStrDateTimeStamp = splitString(strDateTimeStamp, "-", false);
							  if (vStrDateTimeStamp.size()>=2) {
								  vStrDate = splitString(vStrDateTimeStamp[0], "/", false);
								  if (vStrDate.size()>=3) {
									  strFormattedDateTimeStamp = vStrDate[1];
									  strFormattedDateTimeStamp.append("/");
									  strFormattedDateTimeStamp.append(vStrDate[2]);
									  strFormattedDateTimeStamp.append("/");
									  strFormattedDateTimeStamp.append(vStrDate[0]);
									  strFormattedDateTimeStamp.append(" ");
									  strFormattedDateTimeStamp.append((splitString(vStrDateTimeStamp[1], "-", false))[0]);


									  strChangeReasonSortKey = vStrDate[0];
									  if ((vStrDate[1]).length() == 1) {
										  strChangeReasonSortKey.append("0");
									  }
									  strChangeReasonSortKey.append(vStrDate[1]);
									  strChangeReasonSortKey.append(vStrDate[2]);
									  strChangeReasonSortKey.append((splitString(vStrDateTimeStamp[1], "-", false))[0]);
								  }
							  }
						  }
						  else if (strstr(strDateTimeStamp.c_str(), "-") != NULL) {
							  vStrDateTimeStamp = splitString(strDateTimeStamp, "-", false);
							  if (vStrDateTimeStamp.size()>=4) {
								  strFormattedDateTimeStamp = vStrDateTimeStamp[1];
								  strFormattedDateTimeStamp.append("/");
								  strFormattedDateTimeStamp.append(vStrDateTimeStamp[2]);
								  strFormattedDateTimeStamp.append("/");
								  strFormattedDateTimeStamp.append(vStrDateTimeStamp[0]);
								  strFormattedDateTimeStamp.append(" ");
								  strFormattedDateTimeStamp.append(vStrDateTimeStamp[3]);


								  strChangeReasonSortKey = vStrDateTimeStamp[0];
								  if ((vStrDateTimeStamp[1]).length() == 1) {
									  strChangeReasonSortKey.append("0");
								  }
								  strChangeReasonSortKey.append(vStrDateTimeStamp[1]);
								  strChangeReasonSortKey.append(vStrDateTimeStamp[2]);
								  strChangeReasonSortKey.append(vStrDateTimeStamp[3]);
							  }
						  }

					  }else if(strstr(changeReason.c_str(), "-->") != NULL){
			              if (strstr(strDateTimeStamp.c_str(), "/") !=NULL) {
							  strFormattedDateTimeStamp = (splitString(strDateTimeStamp, "-", false))[0];
							  vStrDateTimeStamp = splitString(strDateTimeStamp, "-", false);
							  if (vStrDateTimeStamp.size()>=3) {
								  vStrDate = splitString(vStrDateTimeStamp[0], "/", false);
								  strChangeReasonSortKey = vStrDate[2];
								  if ((vStrDate[0]).length() == 1) {
									  strChangeReasonSortKey.append("0");
								  }
								  strChangeReasonSortKey.append(vStrDate[0]);
								  strChangeReasonSortKey.append(vStrDate[1]);
							  }
						  }
						  else if (strstr(strDateTimeStamp.c_str(), "-") != NULL) {
							  vStrDateTimeStamp = splitString(strDateTimeStamp, "-", false);
							  strChangeReasonSortKey = vStrDateTimeStamp[2];
							  if ((vStrDateTimeStamp[0]).length() == 1) {
								  strChangeReasonSortKey.append("0"); 
							  }
							  strChangeReasonSortKey.append(vStrDateTimeStamp[0]);
							  strChangeReasonSortKey.append(vStrDateTimeStamp[1]);

							  strFormattedDateTimeStamp = vStrDateTimeStamp[0];
							  strFormattedDateTimeStamp.append("/");
							  strFormattedDateTimeStamp.append(vStrDateTimeStamp[1]);
							  strFormattedDateTimeStamp.append("/");
							  strFormattedDateTimeStamp.append(vStrDateTimeStamp[2]);
						  
						  }
						  
						  
                      }else if (strstr(changeReason.c_str(), "->") != NULL) {
						  vStrDateTimeStamp = splitString(strDateTimeStamp," ",false);
						  if (vStrDateTimeStamp.size()==2) {
							  vStrDate = splitString(vStrDateTimeStamp[0], "-", false);
								  if (vStrDate.size() >= 3) {
									strFormattedDateTimeStamp = vStrDate[1];
									strFormattedDateTimeStamp.append("/");
								    strFormattedDateTimeStamp.append(vStrDate[2]);
								    strFormattedDateTimeStamp.append("/");
								    strFormattedDateTimeStamp.append(vStrDate[0]);
								    strFormattedDateTimeStamp.append(" ");
								    strFormattedDateTimeStamp.append((splitString(vStrDateTimeStamp[1], "-", false))[0]);

								    strChangeReasonSortKey = vStrDate[0];
								       if ((vStrDate[1]).length() == 1) {
									      strChangeReasonSortKey.append("0");
								      }
								    strChangeReasonSortKey.append(vStrDate[1]);
								    strChangeReasonSortKey.append(vStrDate[2]);
								    strChangeReasonSortKey.append((splitString(vStrDateTimeStamp[1], "-", false))[0]);
							  }
						  }

					  }
					  

					  mapChangeReason.insert(::make_pair(TD_CHANGE_REASON_SORT_KEY, strChangeReasonSortKey));
					  mapChangeReason.insert(::make_pair(TD_CHANGE_REASON_AUTHOR, vChangeReason[0]));
					  mapChangeReason.insert(::make_pair(TD_CHANGE_REASON_DATE, strFormattedDateTimeStamp));
					  mapChangeReason.insert(::make_pair(TD_CHANGE_REASON_COMMENT, vChangeReason[2]));

					  setMapChangeReason.insert(mapChangeReason);
					  
				  
				  }
				}
		   }


		   string strFormattedChangeHistory("");
		   const char *newDelimeter = "->";
		   const char *newLineSeparator = "------";
		   char *pcFormattedChangeHistory = NULL;

		   for (set<MapChangeReason, ChangeReasonComparator>::iterator it = setMapChangeReason.begin(); it != setMapChangeReason.end(); ++it) {
			   MapChangeReason mapChangeReason = *it;
			   string author = (splitString(mapChangeReason.find(TD_CHANGE_REASON_AUTHOR)->second, "-", false))[0];
			   string comment = mapChangeReason.find(TD_CHANGE_REASON_COMMENT)->second;
			   if (author.length() > 0 && author[0] !='\n') {
				   strFormattedChangeHistory.append("\n");
			   }
			   strFormattedChangeHistory.append(author);
			   strFormattedChangeHistory.append(newDelimeter);
			   strFormattedChangeHistory.append(mapChangeReason.find(TD_CHANGE_REASON_DATE)->second);
			   strFormattedChangeHistory.append(newDelimeter);
			   strFormattedChangeHistory.append(comment);
			   
			   if (setMapChangeReason.size() > 1) {
				   if (comment.length() > 0 && comment[comment.length()-1]!='\n') {
					   strFormattedChangeHistory.append("\n").append(newLineSeparator);
				   }else {
					   strFormattedChangeHistory.append(newLineSeparator);
				   }
			   }

		   }
		   pcFormattedChangeHistory = (char *) MEM_alloc(sizeof(char) * (int)strFormattedChangeHistory.length() +1 );
		   tc_strcpy(pcFormattedChangeHistory,strFormattedChangeHistory.c_str());
		   *formattedChangeHistory = pcFormattedChangeHistory;


	  

  }catch(...){
    if (iStatus == ITK_ok){
	 TC_write_syslog("%s: Unhandled Exception", __function__);
	 iStatus = TERADYNE_UNKNOWN_ERROR;
	}

  }

  return iStatus;
}
	
/*******************************************************************************
* Function Name : replace_all_string
* Description :
*
* REQUIRED HEADERS :
*INPUT PARAMS : string& data, string toSearch, string replaceStrs
*
* RETURN VALUE : int : 0 / error code
* GLOBALS USED :
*FUNCTIONS CALLED :
*
* ALGORITHM :
*
*
* NOTES :
******************************************************************************/
int replace_all_string(string& data, string toSearch, string replaceStr) {

	int iStatus = ITK_ok;
	const char * __function__ = "replace_all_string";


	try {
		// Get the first occurrence
		size_t pos = data.find(toSearch);
		// Repeat till end is reached
		while (pos != std::string::npos)
		{
			// Replace this occurrence of Sub String
			data.replace(pos, toSearch.size(), replaceStr);
			// Get the next occurrence from the current position
			pos = data.find(toSearch, pos + replaceStr.size());
		}


	}
	catch (...) {
		if (iStatus == ITK_ok) {
			TC_write_syslog("%s: Unhandled Exception", __function__);

		}
	}
	return iStatus;
}