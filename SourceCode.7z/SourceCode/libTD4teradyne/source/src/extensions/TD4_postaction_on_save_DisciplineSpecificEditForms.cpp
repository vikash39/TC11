/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_DisciplineSpecificEditForms.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :          
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#                     
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>
#include <teradyne_register_user_exit.h>

/*******************************************************************************
 * Function Name    : teradyne_postaction_on_checkin_msg
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_postaction_on_save_DisciplineSpecificEditForms(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok,
		iCount					= 0,
		iRevCount				= 0;
	
    char *pcTypeName            = NULL,
		 *pcObjTypeName         = NULL,
		 *pcProcessTemplateName	= NULL,
		  *pcChgReason			= NULL,
		  *pcCheckedOut         = NULL,
		 *pcItemID		        = NULL;

	tag_t tObject				= NULLTAG,
		  tOrgRelTag            = NULLTAG,
		  tLatRevTag            = NULLTAG,
		  tObjFoundTag          = NULLTAG,
		  *tRevTags				= NULLTAG,
		  tNewProcess               = NULLTAG;
	bool pcUpdatedFromAWC =false;
	

	std::map<string,string> strPropNameValueMap;

	const char* __function__ = "TD4_postaction_on_save_ChangeAdminForm";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);

		
		
		   if(tObject != NULLTAG){
			
		      TC_write_syslog("\n############################## Executing Post action Discipline Specific Edit Forms  #########################################################\n");
			  
			  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObject,&pcTypeName),TD_LOG_ERROR_AND_THROW);
			 
		        if(tc_strcmp(pcTypeName, TD_CHANGEADMIN_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_DFM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_RELIABILITY_FORM_TYPE) == 0 
					|| tc_strcmp(pcTypeName, TD_SBM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_SAFETY_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_TRADE_COMPL_FORM_TYPE) == 0 )
					{

				     bool bisverdict = true;
					 
					 POM_AM__set_application_bypass(true);
							
					 TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tObject,&bisverdict),TD_LOG_ERROR_AND_THROW);
							
					 if(!bisverdict){
						TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tObject,true),TD_LOG_ERROR_AND_THROW);				
					 }
							
					 TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tObject,TD_UPDATED_FROM_AWC,false), TD_LOG_ERROR_AND_THROW);
					 TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tObject), TD_LOG_ERROR_AND_THROW);
					 
					 if(!bisverdict)
					 {
						TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tObject,false),TD_LOG_ERROR_AND_THROW);		
					 }		
					 POM_AM__set_application_bypass(false);	



					 TERADYNE_TRACE_CALL(iStatus= teradyne_validateObjectBeforeCheckIn(tObject),TD_LOG_ERROR_AND_THROW);

					 TERADYNE_TRACE_CALL(iStatus= teradyne_performActionAfterCheckIn(tObject),TD_LOG_ERROR_AND_THROW);
				 }
			  
			  

			 
		   }
	}catch(...){
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcProcessTemplateName);
	Custom_free(pcObjTypeName);
	Custom_free(pcTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
