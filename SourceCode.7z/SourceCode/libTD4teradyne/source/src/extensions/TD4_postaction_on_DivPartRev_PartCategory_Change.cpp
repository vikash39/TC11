/*==================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_postaction_on_DivPartRev_PartCategory_Change.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This function defines the post action on Part Sub Category property set on DivPartRevision
#      Project         :           libTD4teradyne
#      Author          :           Gurunathan S
#  =================================================================================================
#  Date                              Name                               Description of Change
#  11-Aug-2018						 Gurunathan                          Initial Creation
#  
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_DivPartRev_PartCategory_Change
* Description		: 
*
* REQUIRED HEADERS	:
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/

extern "C"
int TD4_postaction_on_DivPartRev_PartCategory_Change(METHOD_message_t* msg, va_list args)
{
	int iStatus = ITK_ok;
	tag_t tDivPartRev = NULLTAG;
	tag_t tNamingKeyProp = NULLTAG;

	char *partCategory = NULL,
		*partSubCategory = NULL;
	
	const char* __function__ = "TD4_postaction_on_part_sub_category_change";
	TERADYNE_TRACE_ENTER();

	try
	{
		va_list largs;
		va_copy(largs, args);
		tNamingKeyProp = va_arg(largs, tag_t);

		if (tNamingKeyProp != NULLTAG)
		{
			std::string propName(msg->prop_name);

			//get owning object of property
			METHOD_PROP_MESSAGE_OBJECT(msg, tDivPartRev);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDivPartRev, TD_PART_CATEGORY_ATTR, &partCategory), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDivPartRev, TD_PART_SUBCATEGORY_ATTR, &partSubCategory), TD_LOG_ERROR_AND_THROW);
			if ((tc_strcmp(partCategory, "") != 0) && (tc_strcmp(partSubCategory, "") != 0))
			{
								
				//Calling function to Update Form Values from DIVISIONALPARTMAP Form
				TERADYNE_TRACE_CALL(iStatus = teradyne_searchform_updateattributevalue(partCategory, partSubCategory, tDivPartRev, false,true), TD_LOG_ERROR_AND_THROW);
			}

		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(partCategory);
	Custom_free(partSubCategory);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}