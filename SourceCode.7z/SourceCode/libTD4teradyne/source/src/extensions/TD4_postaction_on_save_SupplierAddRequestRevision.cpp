/*==================================================================================================                    
#                Copyright (c) 2019 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_SupplierAddRequestRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Divisional Part revision
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================  */                  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_SupplierAddRequestRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                           
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_SupplierAddRequestRevision(METHOD_message_t *msg , va_list args)
{
	
	int   iStatus                     = ITK_ok;
    int iCount                        =0;
    tag_t  tRevtag		              = NULLTAG;
	tag_t *tCommodityFormList	= NULL,
		  tPrimaryObj			= NULLTAG,
		  tSecondaryObj         = NULLTAG,
		  tCommRel				= NULLTAG,
		  tComodityRelType		= NULLTAG;
	char *pcFormName			= NULL,
		  *pcObjType			= NULL;

	char *pcWrkFlowName = TD_SUPPLIER_ADD_REQ_REV_WF_PREF;

	char* __function__ = "TD4_postaction_on_save_SupplierAddRequestRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting values from iman_save action
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);

		if ( tRevtag !=NULLTAG ){


			if ( bisNew ){

				//To initiate the workflow
			    TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName,tRevtag) ,TD_LOG_ERROR_AND_THROW);
			}else{


				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_COMPONENT_COMMODITY_TYPE, &pcFormName), TD_LOG_ERROR_AND_THROW);
				 if(pcFormName !=NULL){
				     std::map<string,string> strPropNameValueMap;
					 strPropNameValueMap.insert(::make_pair((string)TD_NAME_INPUT,(string)pcFormName));
					 TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry(TD_FORM_NAME_QUERY, strPropNameValueMap, &iCount, &tCommodityFormList),TD_LOG_ERROR_AND_THROW);
					   for(int i = 0; i < iCount; i++) {
							  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tCommodityFormList[i], &pcObjType), TD_LOG_ERROR_AND_THROW);
								if(pcObjType != NULL && tc_strcmp(pcObjType, TD_COMMODITY_FORM_TYPE) == 0) {
				
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_COMMODITY_LVL1_REL_NAME, &tComodityRelType), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus =teradyne_getprimaryorsecondary_relation_objecttag(tRevtag, TD_COMMODITY_LVL1_REL_NAME, "", 0, &tSecondaryObj), TD_LOG_ERROR_AND_THROW); //getting primary object for SBM form 
										AM__set_application_bypass(true); //bypassing to create or delete relation
										if(tSecondaryObj !=NULLTAG){
											 //deleting commodity level 1 forms if already exists in the relation
											TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_delete_relation(tComodityRelType, tRevtag),TD_LOG_ERROR_AND_THROW);
										}
						
										//attaching the commodity level 1 form to the part revision with commodity level 1 relation
										TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevtag, tCommodityFormList[i], tComodityRelType, NULLTAG, &tCommRel), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tCommRel),TD_LOG_ERROR_AND_THROW);
							    
									   AM__set_application_bypass(false);
									   break;
								}
					   }
				}


			}

				
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


