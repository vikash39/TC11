/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_create_VMRepresentsRel.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on GRM_create in VMRepresentsRel
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  12-Nov-2014                       Haripriya                          Initial Creation
#  07-Jul-2015                       Haripriya                          Modified the function not to be called during Revise
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_precondition_on_create_VMRepresentsRel
 * Description      : This function will be executed whenever GRM_create
 *                    happens on VMRepresents between TD4ManufacturerPart
 *                    and Part Revision
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I) - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 1.Gets the Primary and Secondary object type.
 *					  2.If the Primary Object type is Part Revision
 *                    and Secondary Object type is TD4ManufacturerPart ,then check for 
 *                    TD4_VMRepresents_creator Preference.
 *                    3.If the Preference has Value ,the check the current logged
 *                    in Role is same as Preference ,if true allows to create the Relation 
 *                    and if false restricts to create the Relation..
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_precondition_on_create_VMRepresentsRel(METHOD_message_t*  msg, va_list args) 
{
	int iStatus					= ITK_ok,ifound=0;

	char  *pcPrimaryTypeName    = NULL,
		  *pcSecondaryTypeName  = NULL;

	tag_t tObject               = NULLTAG,
	      tPrimaryObject        = NULLTAG,
		  tSecondaryObject      = NULLTAG;

	const char* __function__ = "TD4_precondition_on_create_VMRepresentsRel";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);

		
		TCTYPE_save_operation_context_t saveOperationContext;
		
		TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&saveOperationContext),TD_LOG_ERROR_AND_THROW);
		if(saveOperationContext != TCTYPE_unknown_operation_context){
		
		//Getting Primary and Secondary Object for the Relation
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject,&tPrimaryObject),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject,&tSecondaryObject),TD_LOG_ERROR_AND_THROW);
		if ( (tPrimaryObject != NULLTAG) && ( tSecondaryObject != NULLTAG ) )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject,&pcPrimaryTypeName),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject,&pcSecondaryTypeName),TD_LOG_ERROR_AND_THROW);
			// if the Primary type is TD4DivPartRevision or TD4CommPartRevision and secondary type is TD4ManufacturerPart
			if( ( (tc_strcmp(pcPrimaryTypeName, TD_DIV_PART_REV) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_COMM_PART_REV) == 0) ) && (tc_strcmp(pcSecondaryTypeName, TD_MFG_PART) == 0))
			{
				bool bisValidationSuccess   = true;
				tag_t tPrevRev              = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tPrimaryObject, &tPrevRev),TD_LOG_ERROR_AND_THROW);
	            if(tPrevRev != NULLTAG)
				{
					tag_t tRelationTag =NULLTAG;
					int iObjCount = 0;

					tag_t *tFindObjTag =NULL;
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationTag),TD_LOG_ERROR_AND_THROW);	

					TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPrevRev,tRelationTag,&iObjCount,&tFindObjTag),TD_LOG_ERROR_AND_THROW);

					if(iObjCount > 0)
					{

						for ( int iCount = 0;iCount < iObjCount;iCount++ )
						{
							if (tSecondaryObject == tFindObjTag[iCount]) 
							{
								ifound++;
								break;
							}
						}
					}
					Custom_free(tFindObjTag);
				}

				if(ifound == 0)
				{
					//calling function whether to create the Relation or not
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel(TD_VMREPRESENTS_CREATE_PREF,bisValidationSuccess),TD_LOG_ERROR_AND_THROW);
					if(!bisValidationSuccess)
					{
						TERADYNE_TRACE_CALL(iStatus=EMH_store_error(EMH_severity_error,TD_VMREPRESENTS_CREATE_REL_ERROR),TD_LOG_ERROR_AND_THROW);
						iStatus = TD_VMREPRESENTS_CREATE_REL_ERROR;
						throw iStatus;
					}
				}
			}
		}
	} 
	} 
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name    : teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel
 * Description      : This will check whether the current logged in user is from 
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : szPrefName           (I) - Preference name
 *                    bisValidationSuccess (O) - Validation Success or Failure
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel(string szPrefName,bool &bisValidationSuccess)
{
	int    iStatus				= ITK_ok,
		   iPrefCount           = 0;

	char   *pcUserName          = NULL,
		   *pcRoleName          = NULL,
	       *pcGroupName         = NULL,
	       *pcFullGroupName     = NULL,
		   **pcPrefvalue        = NULL;

	tag_t  tUserTag             = NULLTAG,
		   tRoleTag             = NULLTAG,
	       tGroupTag            = NULLTAG;

	const char* __function__ = "teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUserName,&pcRoleName,&pcGroupName,&pcFullGroupName,&tUserTag,&tRoleTag,&tGroupTag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(szPrefName.c_str(),TC_preference_site,&iPrefCount,&pcPrefvalue),TD_LOG_ERROR_AND_THROW);
		if(iPrefCount > 0)
		{
			std::vector<std::string> prefValues (pcPrefvalue,pcPrefvalue+iPrefCount);
			std::vector<std::string>::iterator it;
			it = find (prefValues.begin(), prefValues.end(),pcRoleName);
			if (it == prefValues.end())
			{
				bisValidationSuccess = false;
			}
		}
		else
		{
			TERADYNE_TRACE_CALL(iStatus=EMH_store_error_s1 (EMH_severity_error,TD_PREF_VALUE_NULL_ERROR,szPrefName.c_str()),TD_LOG_ERROR_AND_THROW);
			iStatus = TD_PREF_VALUE_NULL_ERROR;
			throw iStatus;
		}		
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcUserName);
	Custom_free(pcRoleName);
	Custom_free(pcGroupName);
	Custom_free(pcFullGroupName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}