/*==================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_postaction_on_save_TERBOMCSV.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :
#      Project         :           libTD4teradyne
#      Author          :           Manimaran
#  =================================================================================================
#  =================================================================================================
#  Date                            Name                           Description of Change
#  30-Nov-2015                     Manimaran                      Initial Creation
#  26-Dec-2015                     Manimaran                      Modified the code to skip the post action during Redo dataset creation.
#  $HISTORY$
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_TERBOMCSV
* Description		: Post action to update custom attributes value and to initiate workflow on TD4TER_CSV dataset.
* REQUIRED HEADERS	:
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1. Get the Latest Divisional Part Revision, Divisional Part ID and Divisional Part Rev ID from dataset name.
*                     2. Update custom "Item ID" and "Rev ID" attributes.
*                     3. Update custom �Update BOM� attribute to true if there is already a BOM in Teamcenter.
*                     3. Initiate "TER_BOMImport_WF" workflow on the dataset.
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_TERBOMCSV(METHOD_message_t *msg, va_list args)
{
	int iStatus = ITK_ok;

	tag_t tDatasetTag = NULLTAG;

	const char* __function__ = "TD4_postaction_on_save_TERBOMCSV";
	TERADYNE_TRACE_ENTER();

	char *pcWrkFlowName = TD_BOM_IMPORT_WF_PREF;

	try
	{
		tDatasetTag = va_arg(args, tag_t);
		bool bisNew = va_arg(args, logical);

		TCTYPE_save_operation_context_t saveOperationContext;
		TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&saveOperationContext), TD_LOG_ERROR_AND_THROW);

		if (!bisNew) {
			return ITK_ok;
		}

		if (saveOperationContext == TCTYPE_save_on_create || saveOperationContext == TCTYPE_save_on_update) {
			char *pcDatasetIDName = NULL;
			char *pcFileName = NULL;

			/*#################################### Pre Condition ###################################################*/
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDatasetTag, TD_OBJECT_NAME_ATTR, &pcDatasetIDName), TD_LOG_ERROR_AND_THROW);
			string strDatasetName(pcDatasetIDName);

			TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_BOM_IMPORT_REDO_FILE_NAME_FORMAT_PREF, TC_preference_site, 0, &pcFileName), TD_LOG_ERROR_AND_THROW);
			string strFileName(pcFileName);

			int iFound = (int)strFileName.find_first_of("_");
			string strFilePrefix = strFileName.substr(0, iFound);
			size_t pos = strDatasetName.find(strFilePrefix);

			if (pos == -1) {
				tag_t tDivPartLatestRev = NULLTAG;
				char *pcDivPartID = NULL;
				char *pcDivPartRevID = NULL;

				//Get the Latest Divisional Part Revision, Divisional Part ID and Divisional Part Rev ID from Dataset name
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_divpart_details_from_datasetname(pcDatasetIDName, &tDivPartLatestRev, &pcDivPartID, &pcDivPartRevID), TD_LOG_ERROR_AND_THROW);

				int iRelStatusCount = 0;
				tag_t *tReleaseStatuslist = NULL;
				//Check if the Latest Divisional Part Revision is not released
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tDivPartLatestRev, &iRelStatusCount, &tReleaseStatuslist), TD_LOG_ERROR_AND_THROW);

				//Display the error message if Latest Divisional Part Revision is released
				if (iRelStatusCount > 0) {
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DIV_PART_LATEST_REV_RELEASED_ERROR, pcDivPartID, pcDivPartRevID), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_DIV_PART_LATEST_REV_RELEASED_ERROR;
					throw iStatus;
				}
				Custom_free(tReleaseStatuslist);

				bool bIsReserved = false;
				//Check if the Latest Divisional Part Revision is not checked-out
				TERADYNE_TRACE_CALL(iStatus = RES_is_checked_out(tDivPartLatestRev, &bIsReserved), TD_LOG_ERROR_AND_THROW);

				//Display the error message if the Latest Divisional Part Revision is checked out
				if (bIsReserved) {
					tag_t tUserTag = NULLTAG;
					tag_t tGroupTag = NULLTAG;
					char *pcUserName = NULL;
					char *pcUserID = NULL;
					string szUserName = "";

					TERADYNE_TRACE_CALL(iStatus = RES_who_checked_object_out(tDivPartLatestRev, &tUserTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUserTag, &pcUserName), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = SA_ask_user_identifier2(tUserTag, &pcUserID), TD_LOG_ERROR_AND_THROW);

					szUserName.assign(pcUserName);
					szUserName.append(" ");
					szUserName.append("(");
					szUserName.append(pcUserID);
					szUserName.append(")");

					Custom_free(pcUserName);
					Custom_free(pcUserID);
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_DIVPART_LATESTREV_CHECKEDOUT_ERROR, pcDivPartID, pcDivPartRevID, szUserName.c_str()), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_DIVPART_LATESTREV_CHECKEDOUT_ERROR;
					throw iStatus;
				}

				bool bHasWriteAccess = false;
				//Check if the user has Write access on Latest Divisional Part Revision
				TERADYNE_TRACE_CALL(iStatus = AM_check_privilege(tDivPartLatestRev, TD_WRITE_PRIVILEGE, &bHasWriteAccess), TD_LOG_ERROR_AND_THROW);

				//Display the error message if user does not have Write access on Latest Divisional Part Revision
				if (!bHasWriteAccess) {
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DIV_PART_LATEST_REV_NO_WRITE_ACCESS_ERROR, pcDivPartID, pcDivPartRevID), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_DIV_PART_LATEST_REV_NO_WRITE_ACCESS_ERROR;
					throw iStatus;
				}

				int iTotalRows = 0;
				void*** pvQueryResults = NULL;

				//Search Dataset based on Divisional Part ID and Divisional Part Rev ID.
				TERADYNE_TRACE_CALL(iStatus = teradyne_search_dataset_based_on_divpartid_and_divpartrevid(pcDivPartID, pcDivPartRevID, &iTotalRows, &pvQueryResults), TD_LOG_ERROR_AND_THROW);

				if (iTotalRows != 0)
				{
					tag_t *tdatasetList = NULL;

					tdatasetList = (tag_t *)MEM_alloc(iTotalRows * sizeof(tag_t));
					for (int iresult = 0; iresult < iTotalRows; iresult++)
					{
						tdatasetList[iresult] = *((tag_t *)pvQueryResults[iresult][0]);

						//Check whether another BOM Import WF running for the same Divisional Part Revision
						int iReferencers = 0;
						int *iLevels = 0;
						tag_t *tReferencersTag = NULL;
						char **pcRelations = NULL;

						TERADYNE_TRACE_CALL(iStatus = WSOM_where_referenced2(tdatasetList[iresult], 1, &iReferencers, &iLevels, &tReferencersTag, &pcRelations), TD_LOG_ERROR_AND_THROW);

						if (iReferencers > 0) {
							bool bInBOMImportWF = false;
							for (int j = 0; j < iReferencers; j++) {
								char *pcTaskTypeName = NULL;
								char *pcTaskName = NULL;
								char *pcProcessTemplateName = NULL;

								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReferencersTag[j], &pcTaskTypeName), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(pcTaskTypeName, TD_EPMTASK_TYPE) == 0) {
									TERADYNE_TRACE_CALL(iStatus = EPM_ask_name2(tReferencersTag[j], &pcTaskName), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_BOM_IMPORT_WF_PREF, TC_preference_site, 0, &pcProcessTemplateName), TD_LOG_ERROR_AND_THROW);
									if (tc_strcmp(pcTaskName, pcProcessTemplateName) == 0) {
										EPM_state_t state;
										char *pcStateString = NULL;
										TERADYNE_TRACE_CALL(iStatus = EPM_ask_state(tReferencersTag[j], &state), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = EPM_ask_state_string2(state, &pcStateString), TD_LOG_ERROR_AND_THROW);
										if (tc_strcmp(pcStateString, TASK_COMPLETE_STATE) != 0) {
											bInBOMImportWF = true;
											break;
										}
										Custom_free(pcStateString);
									}
								}
								Custom_free(pcTaskTypeName);
								Custom_free(pcTaskName);
								Custom_free(pcProcessTemplateName);
							}

							//Display the error message if there is another BOM Import WF running for the same Divisional Part Revision
							if (bInBOMImportWF) {
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DIVPART_LATESTREV_IN_BOMIMPORT_WF_ERROR, pcDivPartID, pcDivPartRevID), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_DIVPART_LATESTREV_IN_BOMIMPORT_WF_ERROR;
								throw iStatus;
							}
						}
						Custom_free(iLevels);
						Custom_free(tReferencersTag);
						Custom_free(pcRelations);
					}
					Custom_free(tdatasetList);
				}
				Custom_free(pvQueryResults);
				Custom_free(pcDivPartID);
				Custom_free(pcDivPartRevID);
			}




			/*#################################### End Pre Condition ###################################################*/

			//TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDatasetTag, TD_OBJECT_NAME_ATTR, &pcDatasetIDName), TD_LOG_ERROR_AND_THROW);
			//string strDatasetName(pcDatasetIDName);

			//TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_BOM_IMPORT_REDO_FILE_NAME_FORMAT_PREF, TC_preference_site, 0, &pcFileName),TD_LOG_ERROR_AND_THROW);
			//string strFileName(pcFileName);

			//int iFound = (int)strFileName.find_first_of("_");
			//string strFilePrefix = strFileName.substr(0, iFound);
			//size_t pos = strDatasetName.find(strFilePrefix);

			if (pos == -1) {
				tag_t tDivPartLatestRev = NULLTAG;
				char *pcDivPartID = NULL;
				char *pcDivPartRevID = NULL;

				//Get the Latest Divisional Part Revision, Divisional Part ID and Divisional Part Rev ID from dataset name.
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_divpart_details_from_datasetname(pcDatasetIDName, &tDivPartLatestRev, &pcDivPartID, &pcDivPartRevID), TD_LOG_ERROR_AND_THROW);

				//Update custom "Item ID" and "Rev ID" attributes.
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tDatasetTag, TD_ITEMID_ATTR, pcDivPartID), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tDatasetTag, TD_REVID_ATTR, pcDivPartRevID), TD_LOG_ERROR_AND_THROW);

				int iBomCount = 0;
				tag_t *tBomViewRevs = NULL;
				TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tDivPartLatestRev, &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW);

				//Update custom �Update BOM� attribute to true if there is already a BOM in Teamcenter.
				if (iBomCount > 0) {
					bool bAttrValue = true;
					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_logical(tDatasetTag, TD_UPDATEBOM_ATTR, bAttrValue), TD_LOG_ERROR_AND_THROW);
				}
				Custom_free(tBomViewRevs);
				Custom_free(pcDivPartID);
				Custom_free(pcDivPartRevID);

				//Initiate "TER_BOMImport_WF" workflow on the dataset.
				TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName, tDatasetTag), TD_LOG_ERROR_AND_THROW);
			}
			Custom_free(pcDatasetIDName);
			Custom_free(pcFileName);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
