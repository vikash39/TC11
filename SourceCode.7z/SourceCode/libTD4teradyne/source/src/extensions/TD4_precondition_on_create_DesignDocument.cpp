/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_create_DesignDocument.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for postaction on createPost in a Form
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  30-May-2018                      Marjorie                              Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_precondition_on_create_DesignDocument
 * Description      : This precondition will pre-fill in ID, Description, Project, fields for Design Document from Divisional Part properties
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 
 *					1. Get input item_id
 *        			2. Search for puid of DivPart having that item_id
 *				    3. Retrieve the DivPart attributes: project and description
 *				    4. Set the values into the input fields
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_precondition_on_create_DesignDocument(METHOD_message_t*  msg, va_list args)
{
	const char* __function__ = "TD4_precondition_on_create_DesignDocument";
	TERADYNE_TRACE_ENTER();

	int iStatus					= ITK_ok;
	tag_t  tRevtag				= NULLTAG,
		    tItemTag            = NULLTAG;
	
	char *description			= NULL, 
		 *project				= NULL; 
	
	string szDivRevAttr[]       = {TD_ITEM_ID_ATTR,TD_ITEM_REV_ID_ATTR, TD_PROJECT_NAME_ATTR, TD_FREE_FORM_DESC_ATTR};
	std::map<string,string> strPropNameValueMap;

	char *pcRevId       = NULL;
	char *itemID		= NULL;

	TERADYNE_TRACE_ENTER();
	
	//Get the input arguments
	tItemTag     = va_arg(args, tag_t);
	
	if(  tItemTag != NULLTAG  )
	{
		try
		{
			
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemTag, TD_ITEM_REV_ID_ATTR, &pcRevId), TD_LOG_ERROR_AND_THROW);
			
			bool bisNew = va_arg(args, logical);
			if (bisNew)
			{
				string	szUsergroup = "";

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup), TD_LOG_ERROR_AND_THROW);
				string szRevid(pcRevId);

				if ((szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) == 0) || (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) == 0))
				{
				}
				else if (szRevid.compare("A") != 0)
				{
					//validating RevId based on role
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_REV_ID_ERROR), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_REV_ID_ERROR;
					throw iStatus;
				}

				TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tItemTag, &tRevtag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_ID_ATTR, &itemID), TD_LOG_ERROR_AND_THROW);

				tag_t tag = NULLTAG;

				std::list<std::string> strAttr(szDivRevAttr, szDivRevAttr + sizeof(szDivRevAttr) / sizeof(string));
				std::map<string, string> strPropNameValueMap;

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_object_tag(itemID, TD_DIV_PART_REV, &tag), TD_LOG_ERROR_AND_THROW);
				if (tag != NULL)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tag, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);

					if (strPropNameValueMap.size() > 0)
					{
						string szItemId = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_object_tag(szItemId.c_str(), TD_DIV_PART_REV, &tag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tag, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tag, TD_PROJECT_NAME_ATTR, &project), TD_LOG_ERROR_AND_THROW);

						if (project != NULL || project != '\0')
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_PROJECT_NAME_ATTR, project), TD_LOG_ERROR_AND_THROW);
						}

						//for user input description
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_OBJECT_DESC_ATTR, &description), TD_LOG_ERROR_AND_THROW);
						if (description == NULL || tc_strlen(description) == 0)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tag, TD_FREE_FORM_DESC_ATTR, &description), TD_LOG_ERROR_AND_THROW);
							if (description != NULL || description != '\0')
							{
								TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_OBJECT_DESC_ATTR, description), TD_LOG_ERROR_AND_THROW);
							}
							else
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NO_DESDOC_DESCRIPTION_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_NO_DESDOC_DESCRIPTION_ERROR;
								throw iStatus;
							}
						}
						else
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_OBJECT_DESC_ATTR, description), TD_LOG_ERROR_AND_THROW);
						}

					}
				}
				//check description if null
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_OBJECT_DESC_ATTR, &description), TD_LOG_ERROR_AND_THROW);
				if (description == NULL || tc_strlen(description) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NO_DESDOC_DESCRIPTION_ERROR), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_NO_DESDOC_DESCRIPTION_ERROR;
					throw iStatus;
				}
			}
		}		
		catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	}
	Custom_free(pcRevId);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}


/*******************************************************************************
* Function Name	    : teradyne_get_usergroup_as_string
* Description		:
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:szUsergroup (String) - get the User group as string value
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_usergroup_as_string(string *szUsergroup)
{
	int		iStatus = ITK_ok;
	tag_t	tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tParentTag = NULLTAG;

	char	*pcUsername = NULL,
		*pcRoleName = NULL,
		*pcGroupName = NULL,
		*pcGroupFullName = NULL,
		*pcParentGroupName = NULL;

	char* __function__ = "teradyne_get_usergroup_as_string";
	TERADYNE_TRACE_ENTER();

	try {
		//check revision entered by user is in sequence or not only when the user is not Change admin group
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = SA_ask_group_parent(tGroupTag, &tParentTag), TD_LOG_ERROR_AND_THROW);
		if (tParentTag != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tParentTag, &pcParentGroupName), TD_LOG_ERROR_AND_THROW);
			*szUsergroup = string(pcParentGroupName) + TD_DOT_CONSTANT + string(pcGroupName) + TD_DOT_CONSTANT + string(pcRoleName);
		}
		else
		{
			*szUsergroup = string(pcGroupName) + TD_DOT_CONSTANT + string(pcRoleName);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
