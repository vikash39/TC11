/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_create_DocumentRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for pre-conditon to apply rule over item revision id
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  21-Apr-2015                      Kameshwaran D.                      Initial Creation
#  23-Mar-2016                      Manimaran                           Modified the code to allow dba to create any revision like CM Admin.
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
* Function Name	    : TD4_precondition_on_create_DocumentRevision
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*					 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/

int TD4_precondition_on_create_DocumentRevision(METHOD_message_t *msg , va_list args)
{
	int		iStatus				= ITK_ok;

	tag_t	tItemtag = NULLTAG;

	char* __function__ = "TD4_precondition_on_create_DocumentRevision";
	
	TERADYNE_TRACE_ENTER();

	try 
	{
		
		tItemtag = msg->object_tag;
		bool bisNew = va_arg(args, logical);
	
		if (bisNew)
		{
			
			string	szUsergroup = "";
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup), TD_LOG_ERROR_AND_THROW);

			char *pcRevid = NULL;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemtag, TD_ITEM_REV_ID_ATTR, &pcRevid), TD_LOG_ERROR_AND_THROW);

			string szRevid(pcRevid);

			if ((szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) == 0) || (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) == 0))
			{
				return iStatus;
			}
			else if (szRevid.compare("A") != 0)
			{
				//validating RevId based on role
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_REV_ID_ERROR), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_REV_ID_ERROR;
				throw iStatus;
			}
			Custom_free(pcRevid);
		}
			
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

