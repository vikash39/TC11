/*==================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_postaction_on_save_DivPartRevision.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains function for post action on IMAN_save in Divisional Part revision
#      Project         :           libTD4teradyne
#      Author          :           Vivek
#  =================================================================================================
#  Date                              Name                               Description of Change
#  05-Nov-2014                       Haripriya                          Initial Creation
#  16-Jan-2015						 Kameshwaran D.						To popluate the "Controlling Business Unit" attribute from "Controlling Business Unit on Create" field.
#  29-Jan-2015						 Haripriya					        Added Trade Complaince form attribute to update while creating.
#  04-Feb-2015						 Haripriya                          Modified the Code to update changeadmin and trade form while creating DivpartRevision and update trade form while saving DivpartRevision.
#  06-Feb-2015						 Haripriya                          Modified the Code to Validate Standard Description and PartCategory while saving DivpartRevision.
#  12-Feb-2015						 Selvi								Called AM__set_application_bypass to bypass the application.
#  13-Feb-2015						 Kameshwaran D.						Bypass set true to update change admin form.
#  19-Feb-2015						 Haripriya                          Modified code to initiate the Workflow on creation.
#  05-Mar-2015                       Haripriya                          Modified teradyne_validate_required_attribute calling function arguments.
#  28-Jul-2015						 Selvi								Handled code to supress PartCategory and PartSubcategory value "-" specific to migration data.
#  25-Jun-2018						 Marjorie							Added code that will relate Div Part and Design Documents under Specifications foler
#  $HISTORY$
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>
#include <sqlext.h>
#include <sql.h>
/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_DivPartRevision
* Description		: Postaction to update trade form values based on partcategory,
*                     partsubcategory value and initiate worklow on creation.
* REQUIRED HEADERS	:
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1.Gets the value of partcategory ,partsubcategory value from DivpartRevision.
*					  2.Searches DivpartMapForm,if Found updates PartType_ATTR in DivPartRevision
*					   and ECCN_ATTR ,HTS_ATTR in TradeCompliance Form while saving
*					   DivPartRevision.
*                     3.Populate TD_CONTRL_BUSS_UNIT value in ChangeAdmin Form
*                     from DivPartRevision TD_CONTRL_BUSS_UNIT_CRE attribute
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_DivPartRevision(METHOD_message_t *msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	string szDivPartCatergoryName = "",
		szDivPartSubCatergoryName = "",
		szControlBussUnit = "",
		szDivPartProjectName = "",
		szDivPart_Attr[] = { TD_PART_CATEGORY_ATTR,TD_PART_SUBCATEGORY_ATTR,TD_PROJECT_NAME_ATTR };

	tag_t   tRevtag = NULLTAG;

	std::map<string, string> strDivPartPropNameValueMap;

	char	*freeFormDispName = NULL,
		*description = NULL,
		*pcCBU = NULL;

	char* __function__ = "TD4_postaction_on_save_DivPartRevision";

	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting values from iman_save action
		tRevtag = va_arg(args, tag_t);
		bool bisNew = va_arg(args, logical);

		if (tRevtag != NULLTAG)
		{
			if (bisNew)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_discipleSpecificForms(tRevtag), TD_LOG_ERROR_AND_THROW);
			}

			char *specialChar = NULL;

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_FREE_FORM_DESC_ATTR, &description), TD_LOG_ERROR_AND_THROW);
			if (hasInvalidChar(description, &specialChar))
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_name(tRevtag, TD_FREE_FORM_DESC_ATTR, &freeFormDispName), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_INVALID_CHAR, freeFormDispName, specialChar), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_INVALID_CHAR;
				throw iStatus;
			}

			std::list<string> strDivPartAttrList(szDivPart_Attr, szDivPart_Attr + sizeof(szDivPart_Attr) / sizeof(string));

			//calling function to get DivPartRevision property values
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevtag, strDivPartAttrList, strDivPartPropNameValueMap), TD_LOG_ERROR_AND_THROW);
			if (strDivPartPropNameValueMap.size() > 0)
			{
				szDivPartCatergoryName.assign(strDivPartPropNameValueMap.find(TD_PART_CATEGORY_ATTR)->second);
				szDivPartSubCatergoryName.assign(strDivPartPropNameValueMap.find(TD_PART_SUBCATEGORY_ATTR)->second);
				szDivPartProjectName.assign(strDivPartPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second);
			}

			if ((tc_strcmp(szDivPartCatergoryName.c_str(), "-") != 0) && (tc_strcmp(szDivPartSubCatergoryName.c_str(), "-") != 0))
			{
				//calling function to validate Part Category Value
				bool bIsCreateCheck = false;
				TERADYNE_TRACE_CALL(iStatus = teradyne_validate_required_attribute(tRevtag, strDivPartPropNameValueMap, " ", bIsCreateCheck), TD_LOG_ERROR_AND_THROW);
				//Calling function to Update Form Values from DIVISIONALPARTMAP Form
				//modified for BT27
				TERADYNE_TRACE_CALL(iStatus = teradyne_searchform_updateattributevalue(szDivPartCatergoryName, szDivPartSubCatergoryName, tRevtag, false, bisNew), TD_LOG_ERROR_AND_THROW);
			}
			else
			{
				//legacy part
				bool isSalesOption = false;
				string szFreeFormDesc = "";
				char   *pcFreeFormDesc = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tRevtag, TD_SALES_OPTION, &isSalesOption), TD_LOG_ERROR_AND_THROW);
				if (isSalesOption)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_FREE_FORM_DESC_ATTR, &pcFreeFormDesc), TD_LOG_ERROR_AND_THROW);
					szFreeFormDesc.append(pcFreeFormDesc);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_STANDARD_DESC_ATTR, szFreeFormDesc), TD_LOG_ERROR_AND_THROW);
				}

			}

			if (bisNew)
			{
				tag_t tItemTag = va_arg(args, tag_t);

				// Calling function to validate Revisionid,BasePart check,partcategory and StandardDesc_Attr length
				TERADYNE_TRACE_CALL(iStatus = teradyne_precondition_on_create_DivPartRevision(tItemTag, tRevtag), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tRevtag, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

				if (pcCBU != NULL)
				{
					szControlBussUnit.assign(pcCBU);
				}

				// This Part of code is to populate "Controlling Business Unit" attribute from "Controlling Business Unit on Create" field
				if (szControlBussUnit.length() > 0)
				{
					tag_t tSecObjs = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevtag, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tSecObjs), TD_LOG_ERROR_AND_THROW);

					if (tSecObjs != NULLTAG)
					{
						AM__set_application_bypass(true);// Bypass is set true to update change admin form
						//Calling function to set the property value
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tSecObjs, TD_CONTRL_BUSS_UNIT, szControlBussUnit), TD_LOG_ERROR_AND_THROW);
						AM__set_application_bypass(false);
					}
				}

				TERADYNE_TRACE_CALL(iStatus = teradyne_create_divpart_designDocs(tRevtag), TD_LOG_ERROR_AND_THROW);

				//--------------------------- Relate design documents to Div Part Specifications folder
				char *docType1 = NULL, *docType2 = NULL, *docType3 = NULL, *divPartID = NULL;

				std::vector<std::string> docTypes;

				//Get Design Document Types
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE1_ATTR, &docType1), TD_LOG_ERROR_AND_THROW);
				if (docType1 != NULL && *docType1 != '\0') {
					docTypes.push_back(docType1);
				}

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE2_ATTR, &docType2), TD_LOG_ERROR_AND_THROW);
				if (docType2 != NULL && *docType2 != '\0'  && strcmp(docType1, docType2) != 0) {
					docTypes.push_back(docType2);
				}

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE3_ATTR, &docType3), TD_LOG_ERROR_AND_THROW);
				if (docType3 != NULL && *docType3 != '\0' && strcmp(docType3, docType1) != 0 && strcmp(docType3, docType2) != 0) {
					docTypes.push_back(docType3);
				}

				if (docTypes.size() > 0)
				{
					tag_t relation_type_tag = NULLTAG;
					std::map<string, string> strPropNameValueMap;
					tag_t *tDocRevTags = NULLTAG;
					tag_t tRelation = NULLTAG;
					int iCount = 0;

					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_IMAN_SPEC_REL_NAME, &relation_type_tag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_ID_ATTR, &divPartID), TD_LOG_ERROR_AND_THROW);


					strPropNameValueMap.insert(::make_pair((string)TD_ITEMID_INPUT, (string)divPartID));
					TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry(TD_DESIGN_DOCUMENT_QUERY, strPropNameValueMap, &iCount, &tDocRevTags), TD_LOG_ERROR_AND_THROW);

					for (int i = 0; i < iCount; i++)
					{

						tag_t relation_tag = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tRevtag, tDocRevTags[i], relation_type_tag, &tRelation), TD_LOG_ERROR_AND_THROW);

						if (tRelation == NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevtag, tDocRevTags[i], relation_type_tag, NULLTAG, &relation_tag), TD_LOG_ERROR_AND_THROW);
						}

						TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(relation_tag), TD_LOG_ERROR_AND_THROW);

					}

					Custom_free(docType1);
					Custom_free(docType2);
					Custom_free(docType3);
					Custom_free(divPartID);

				}

				TERADYNE_TRACE_CALL(iStatus = teradyne_update_object_name(tRevtag), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_CREATED_EVENT, tRevtag, false), TD_LOG_ERROR_AND_THROW);

			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(freeFormDispName);
	Custom_free(description);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_update_trade_compliance_form
*
* Description		: Finds TradeCompliance form and update attributes
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag (I)                              - current object
*                     map<string,string> strPropNameValueMap(I) - Map having key and value
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: 1.Finds TradeCompliance form in DisciplineSpecific Relation
*					   for given objecttag
*                     2.Updates ECCN and HTS Value in TradeCompliance form from
*                       DivisionalPartMap Form
*
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_update_trade_compliance_form(tag_t tRevTag, std::map<string, string> strPropNameValueMap)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	tag_t  tSecObjs = NULLTAG;

	string szTradeForm_ATTR[] = { TD_HTS_ATTR,TD_ECCN_ATTR };

	char* __function__ = "teradyne_update_trade_compliance_form";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Checking for Trade Compliance Form and Updating the attribute values in it
		if ((tRevTag != NULLTAG) && (strPropNameValueMap.size() > 0))
		{
			int iArraySize = sizeof(szTradeForm_ATTR) / sizeof(string);
			bool isPrimary = 0;
			TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevTag, TD_DIS_SPEC_REL_NAME, TD_TRADE_COMPL_FORM_TYPE, isPrimary, &tSecObjs), TD_LOG_ERROR_AND_THROW);
			if (tSecObjs != NULLTAG)
			{
				for (int iCount = 0; iCount < iArraySize; iCount++)
				{
					AM__set_application_bypass(true);
					//Calling function to set the property value
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tSecObjs, szTradeForm_ATTR[iCount], strPropNameValueMap.find(szTradeForm_ATTR[iCount])->second), TD_LOG_ERROR_AND_THROW);
					AM__set_application_bypass(false);
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name    : teradyne_search_nextid
 * Description      : This function will gives the next id in the counter
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : *tDivpartcounterTag (O) - objectTag
 *
 *
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
string teradyne_search_nextid()
{
	HENV hEnv; // for allocating memory usingSQLAllocEnv
	HDBC hDBC; // connection handler
	HSTMT hStmt; // statement handler

	char	*stmt = NULL;
	int iStatus = PREF_ask_char_value_at_location("TERADYNE_SQL_NEXT_VAL", TC_preference_site, 0, &stmt);
	char *conn = NULL;
	iStatus = PREF_ask_char_value_at_location("TERADYNE_SQL_CONN_STRING", TC_preference_site, 0, &conn);

	SQLLEN indicator;
	string connString = string(conn);
	wstring connWstring;

	connWstring.resize(connString.size());

	mbstowcs(&connWstring[0], connString.c_str(), connString.size());

	RETCODE retcode;
	int rcod = 0;

	SQLAllocEnv(&hEnv);
	SQLAllocConnect(hEnv, &hDBC);

	SQLWCHAR retconstring[1024];

	SQLCHAR sqlResult[256];

	retcode = SQLDriverConnect(hDBC, NULL, (SQLWCHAR*)connWstring.c_str(),
		SQL_NTS, retconstring, 1024, NULL, SQL_DRIVER_NOPROMPT);

	if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
	{

		SQLAllocHandle(SQL_HANDLE_STMT, hDBC, &hStmt);
		retcode = SQLExecDirectA(hStmt, (SQLCHAR*)stmt, SQL_NTS);

		while (SQLFetch(hStmt) == SQL_SUCCESS)
		{
			retcode = SQLGetData(hStmt, 1, SQL_C_CHAR, &sqlResult, sizeof(sqlResult), &indicator);
		}

		SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
	}
	else
	{
		rcod = 1;
	}

	string tempId = string((char*)sqlResult);

	SQLFreeConnect(hDBC);
	SQLFreeEnv(hEnv);
	return tempId;
}

int teradyne_create_discipleSpecificForms(tag_t tRevTag)
{
	int   iStatus = ITK_ok;

	string szFormName[] = { "Trade Compliance Form","Safety Form","SBM Form","DFM Form","Change Admin Form","Change History Form","ORG" },
		szFormType[] = { TD_TRADE_COMPL_FORM_TYPE,TD_SAFETY_FORM_TYPE,TD_SBM_FORM_TYPE,TD_DFM_FORM_TYPE,TD_CHANGEADMIN_FORM_TYPE,TD_CHANGEHISTORY_FORM_TYPE,TD_ORACLE_ORG_FORM_TYPE };

	std::map<string, string> strFormTypeNameMap;

	char* __function__ = "teradyne_create_discipleSpecificForms";
	TERADYNE_TRACE_ENTER();

	try
	{
		int iTypesize = sizeof(szFormName) / sizeof(string);
		for (int iCount = 0; iCount < iTypesize; iCount++)
		{
			strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
		}
		// Calling function to create Forms under DisciplineSpecific & OracleOrg DIVPARTREVISION
		TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, false), TD_LOG_ERROR_AND_THROW);

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}


/*******************************************************************************
 * Function Name    : teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory
 * Description      : This function will search the DivisionalPartMapForm based on PartCategory
 *                    and partSubCategory value.
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : *partCategory (I) - PartCategory attr value
 *                    *partSubCategory  (I)- PartSubCategory attr value
 *					   bcheck			(I) - boolean
 *                    *tDivpartTag (O) - objectTag
 *
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory(char*partCategory, char*partSubCategory, tag_t *tDivpartTag, bool bCheck)
{
	//Declartion and Initialization of Local Variables
	int iStatus = ITK_ok;
	char* pcEnquiryID = "Search DivPartForm with Partcategory and PartSubCategory Value";
	const char* cpSelectAttrs[] = { "puid" };
	char* pcFormType = TD_DIV_PART_MAP_FORM_TYPE;
	const int iActiveSeq = 0;
	int iTotalRows = 0;
	int iTotalCols = 0;
	void*** pvQueryResults = NULL;

	const char* __function__ = "teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory";
	TERADYNE_TRACE_ENTER();

	try
	{
		if ((partCategory != NULL) && (partSubCategory != NULL))
		{
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_create(pcEnquiryID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_add_select_attrs(pcEnquiryID, TD_DIV_PART_MAP_FORM_STORAGE, 1, cpSelectAttrs), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(pcEnquiryID, "partCategory", 1, (const char**)&partCategory, POM_enquiry_bind_value), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(pcEnquiryID, "partSubCategory", 1, (const char**)&partSubCategory, POM_enquiry_bind_value), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(pcEnquiryID, "formType", 1, (const char**)&pcFormType, POM_enquiry_bind_value), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_int_value(pcEnquiryID, "active_seq_val", 1, &iActiveSeq, POM_enquiry_const_value), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "join_expr", TD_WORKSPACEOBJECT_TYPE, TD_PUID_CONSTANT,
				POM_enquiry_equal, TD_FORM_CLASS, TD_PUID_CONSTANT), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "join_expr1", TD_FORM_CLASS, TD_DATAFILE_PROP,
				POM_enquiry_equal, TD_DIV_PART_MAP_FORM_STORAGE, TD_PUID_CONSTANT), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr1", TD_DIV_PART_MAP_FORM_STORAGE, TD_PART_CATEGORY_ATTR,
				POM_enquiry_equal, "partCategory"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr2", TD_DIV_PART_MAP_FORM_STORAGE, TD_PART_SUBCATEGORY_ATTR,
				POM_enquiry_equal, "partSubCategory"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr3", TD_WORKSPACEOBJECT_TYPE, TD_OBJECT_TYPE_ATTR,
				POM_enquiry_equal, "formType"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr4", TD_WORKSPACEOBJECT_TYPE, TD_ACTIVE_SEQUENCE_ATTR,
				POM_enquiry_not_equal, "active_seq_val"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr5", "expr1", POM_enquiry_and, "expr2"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr6", "expr5", POM_enquiry_and, "expr3"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr7", "expr6", POM_enquiry_and, "expr4"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr8", "expr7", POM_enquiry_and, "join_expr"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr9", "expr8", POM_enquiry_and, "join_expr1"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_where_expr(pcEnquiryID, "expr9"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_execute(pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults), TD_LOG_ERROR_AND_THROW);
		    if (iTotalRows != 0)
			{
				if (iTotalRows == 1) //bCheck == true && 
				{
					*tDivpartTag = (*((tag_t*)pvQueryResults[0][0]));
				}
				else
				{
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TERADYNE_DIVPARTMAP_FORM_WITH_NAME_EXISTS_ERROR, partCategory, partSubCategory), TD_LOG_ERROR_AND_THROW);
					iStatus = TERADYNE_DIVPARTMAP_FORM_WITH_NAME_EXISTS_ERROR;
					throw iStatus;
				}

			}
			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_delete(pcEnquiryID), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		TERADYNE_TRACE_CALL(POM_enquiry_delete(pcEnquiryID), TD_LOG_ERROR);
	}

	Custom_free(pvQueryResults);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_validate_required_attribute
* Description		: Validating PartCategory & PartSubcategory
*                     attribute in DivPartRevision
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                      bisCreate (I)                 - boolean value to indicate calling create (true) or save (false) action
*                      *pcUsername                   - Logged in username
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : Gets the PartCategory & PartSubcategory Value
*                     from DivisionalPartRevision and checks
*                     whether the value has NOTLISTED Value
*                     and if not concatenates the value with hypen .
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_validate_required_attribute(tag_t tRevTag, std::map<string, string> strPropNameValueMap, char *pcUsername, bool bisCreate)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char *pcPartCategoryEmail = NULL;
	string strErrMsg = "",
		szDivpartSub = "";

	char* __function__ = "teradyne_validate_required_attribute";
	TERADYNE_TRACE_ENTER();

	try
	{
		if ((tRevTag != NULLTAG) && (strPropNameValueMap.size() > 0))
		{
			if ((strPropNameValueMap.find(TD_PART_CATEGORY_ATTR)->second.compare(TD_NOT_LISTED_CONSTANT) == 0))
			{
				if (bisCreate)
				{
					//Calling function to create the mail content file
					string szDivPartMailBody = "";
					string strCurTimeStamp = "";
					date_t currDate;
					TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", strCurTimeStamp, currDate), TD_LOG_ERROR_AND_THROW);
					string strMailFilePath = TD_TEMP_PATH;
					strMailFilePath.append("DIVPART_PARTCATEGORY_").append(strCurTimeStamp).append(".txt");
					szDivPartMailBody.append("A Divisional Part could not be created due to Part Category of Not Listed was selected.Please contact ").append(pcUsername).append(" for further details about the part that needs to be created.");
					TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, szDivPartMailBody), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_PART_CATEGORY_EMAIL_PREF, TC_preference_site, 0, &pcPartCategoryEmail), TD_LOG_ERROR_AND_THROW);
					//Calling function to send the mail using tc_mail_smtp utility
					szDivpartSub.append(TD_DIVPART_PARTCATEGORY_MAIL_SUBJECT).append(strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second);

					TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(TD_DIVPART_PARTCATEGORY_MAIL_SUBJECT, strMailFilePath, pcPartCategoryEmail), TD_LOG_ERROR_AND_THROW);
					DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
					strErrMsg = "Create";
				}
				else {

					strErrMsg = "Modify";
				}
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_PARTCATEGORY_NOT_LISTED_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_PARTCATEGORY_NOT_LISTED_ERROR;
				throw iStatus;
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
* Function Name	    : teradyne_searchform_updateattributevalue
* Description		: Finds DIvisionalPartMap Form
*

* REQUIRED HEADERS	:
* INPUT PARAMS		:  szDivPartCatergoryName (I)    - PartCategory attr value
*                      szDivPartSubCatergoryName (I) - PartSubCategory attr value
*					  tCurRevTag          (I)        - Objecttag
*                     bisExecuteCondition  (I)       - boolean value
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: Finds DIvisionalPartMap Form with PartCategory
*                    and PartSubcategory value from DIvisionalPartRevision
*                    and updates FREE_FORM_DESC,STANDARD_DESC,Part_Type value in
*                    DIvisionalPartRevision.
*
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_searchform_updateattributevalue(string szDivPartCatergoryName, string szDivPartSubCatergoryName, tag_t tCurRevTag, bool bisExecuteCondition,bool bisNew)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	tag_t  tFindItem = NULL;

	char   *pcFreeFormDesc = NULL,
		*pcItemRevID = NULL;

	string szFreeFormDesc = "",
		szAttrValue = "",
		szPartType = "",
		szDivPartMapFormAttr[] = { TD_PREFIX_ATTR,TD_SUFFIX_ATTR,TD_HTS_ATTR,TD_ECCN_ATTR,TD_PART_TYPE_ATTR };

	std::map<string, string> strPropNameValueMap;

	char* __function__ = "teradyne_searchForm_updateattributevalue";
	TERADYNE_TRACE_ENTER();

	try

	{
		if ((tCurRevTag != NULLTAG) && (szDivPartCatergoryName.length() > 0) && (szDivPartSubCatergoryName.length() > 0))
		{
			//Finding DivisionalPartMap Form
			TERADYNE_TRACE_CALL(iStatus = teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory((char*)szDivPartCatergoryName.c_str(), (char*)szDivPartSubCatergoryName.c_str(), &tFindItem, true), TD_LOG_ERROR_AND_THROW);
			if (tFindItem != NULLTAG)
			{
				//Getting FreeFormDescription Value
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tCurRevTag, TD_FREE_FORM_DESC_ATTR, &pcFreeFormDesc), TD_LOG_ERROR_AND_THROW);

				//calling function to get Prefix,Suffix,HTS,ECCn,PartType property values
				std::list<std::string> strAttr(szDivPartMapFormAttr, szDivPartMapFormAttr + sizeof(szDivPartMapFormAttr) / sizeof(string));
				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tFindItem, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
				if (strPropNameValueMap.size() > 0)
				{

					bool isSalesOption = false;

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tCurRevTag, TD_SALES_OPTION, &isSalesOption), TD_LOG_ERROR_AND_THROW);

					if (isSalesOption) {
						szFreeFormDesc.append(pcFreeFormDesc);

					}
					else {
						if ((strPropNameValueMap.find(TD_PREFIX_ATTR)->second.length()) > 0 && (strPropNameValueMap.find(TD_SUFFIX_ATTR)->second.length()) > 0)
						{
							szFreeFormDesc.append(strPropNameValueMap.find(TD_PREFIX_ATTR)->second).append(TD_COMMA_CONSTANT).append(TD_SPACE_CONSTANT).append(pcFreeFormDesc).append(TD_COMMA_CONSTANT).append(TD_SPACE_CONSTANT).append(strPropNameValueMap.find(TD_SUFFIX_ATTR)->second);
						}
						else if ((strPropNameValueMap.find(TD_PREFIX_ATTR)->second.length()) > 0 && (strPropNameValueMap.find(TD_SUFFIX_ATTR)->second.length()) == 0)
						{
							szFreeFormDesc.append(strPropNameValueMap.find(TD_PREFIX_ATTR)->second).append(TD_COMMA_CONSTANT).append(TD_SPACE_CONSTANT).append(pcFreeFormDesc);
						}
						else if ((strPropNameValueMap.find(TD_PREFIX_ATTR)->second.length()) == 0 && (strPropNameValueMap.find(TD_SUFFIX_ATTR)->second.length()) > 0)
						{
							szFreeFormDesc.append(pcFreeFormDesc).append(TD_COMMA_CONSTANT).append(TD_SPACE_CONSTANT).append(strPropNameValueMap.find(TD_SUFFIX_ATTR)->second);
						}
						else if ((strPropNameValueMap.find(TD_PREFIX_ATTR)->second.length()) == 0 && (strPropNameValueMap.find(TD_SUFFIX_ATTR)->second.length()) == 0)
						{
							szFreeFormDesc.append(pcFreeFormDesc);
						}

					}



					if (bisExecuteCondition)
					{
						// Validating the length of standarddescription
						if (tc_strlen(szFreeFormDesc.c_str()) > 80)
						{
							string strErrMsg = "Create";
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_STD_DESC_UNKOWN_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_STD_DESC_UNKOWN_ERROR;
							throw iStatus;
						}
					}
					else
					{
						// Converting the standarddescription value to uppercase
						if (szFreeFormDesc != "" && szFreeFormDesc.length() <= 80)
						{
							std::transform(szFreeFormDesc.begin(), szFreeFormDesc.end(), szFreeFormDesc.begin(), ::toupper);
							
							// Calling function to update Values on Trade Compliance Form
							//updated for BT27
							if(bisNew)
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_trade_compliance_form(tCurRevTag, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
							//Calling function to update Values on DivPartRevision
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCurRevTag, TD_PART_TYPE_ATTR, strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCurRevTag, TD_STANDARD_DESC_ATTR, szFreeFormDesc), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCurRevTag, TD_HTS_DEF_ATTR, strPropNameValueMap.find(TD_HTS_ATTR)->second), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCurRevTag, TD_ECCN_DEF_ATTR, strPropNameValueMap.find(TD_ECCN_ATTR)->second), TD_LOG_ERROR_AND_THROW);

							//notification for PCB or PCBA part type
							//gets ptd4PartType
							szPartType = strPropNameValueMap.find(TD_PART_TYPE_ATTR)->second;
							//gets rev ID
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tCurRevTag, TD_ITEM_REV_ID_ATTR, &pcItemRevID), TD_LOG_ERROR_AND_THROW);
							//checks ptd4PartType and if initial revision for pcb/pcba subscription
							if ((szPartType.compare("PCB") == 0 || szPartType.compare("PCBA") == 0) && !tc_strcmp(pcItemRevID, "A"))
							{
								string	strCurTimeStamp = "",
									strMailFilePath = TD_TEMP_PATH,
									subject = "";

								date_t	currDate;

								TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", strCurTimeStamp, currDate), TD_LOG_ERROR_AND_THROW);
								strMailFilePath.append("SUBSCRIPTION_NOTIFICATION").append(strCurTimeStamp).append(".htm");

								//builds the email subject
								subject.assign(teradyneBuildSubscriptionSubject(tCurRevTag, "PCB-PCBA Subscription"));
								//builds the email body
								string htmlBodyContent = teradyneBuildSubscriptionBodyContent(tCurRevTag, "PCB-PCBA Subscription");
								//creates the email body file
								TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW);

								//send to address list
								char *pcAddressList = NULL;
								TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_PCB_PCBA_ADDRESS_LIST_PREF, TC_preference_site, 0, &pcAddressList), TD_LOG_ERROR_AND_THROW);
								tag_t tDistributionList = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = MAIL_find_alias_list2(pcAddressList, &tDistributionList), TD_LOG_ERROR_AND_THROW);
								int iMemberCount = 0;
								char **pcMembers = NULL;
								TERADYNE_TRACE_CALL(iStatus = MAIL_ask_alias_list_members(tDistributionList, &iMemberCount, &pcMembers), TD_LOG_ERROR_AND_THROW);
								for (int iUserCount = 0; iUserCount < iMemberCount; iUserCount++)
								{
									tag_t tUserTag = NULLTAG;
									char *the_sender_email_addr = NULL;

									TERADYNE_TRACE_CALL(iStatus = SA_find_user2(pcMembers[iUserCount], &tUserTag), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW);

									if (tc_strlen(the_sender_email_addr) > 0 && the_sender_email_addr != NULL)
									{
										//sends the email
										TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject, strMailFilePath, the_sender_email_addr), TD_LOG_ERROR_AND_THROW);
									}
									Custom_free(the_sender_email_addr);
								}
								DeleteFileA(strMailFilePath.c_str());
								Custom_free(pcAddressList);
								Custom_free(pcMembers);
							}
						}
						else
						{
							string strErrMsg = "Update";
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_STD_DESC_UNKOWN_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_STD_DESC_UNKOWN_ERROR;
							throw iStatus;
						}

					}
				}

			}
			else
			{
				string strErrMsg = "";
				if (bisExecuteCondition)
				{
					strErrMsg = "Created";
				}
				else
				{
					strErrMsg = "Updated";
				}
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_DIV_PART_MAP_FORM_ERROR, szDivPartCatergoryName.c_str(), szDivPartSubCatergoryName.c_str(), strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_DIV_PART_MAP_FORM_ERROR;
				throw iStatus;

			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcFreeFormDesc);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_precondition_on_create_DivPartRevision
* Description		: Precondition to validate revisionid,partcategory,
*                     partsubcategory
* REQUIRED HEADERS	:
* INPUT PARAMS		: tRevTag (I) - objecttag
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_precondition_on_create_DivPartRevision(tag_t tIPItemTag, tag_t tRevTag)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char  *pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;

	string szDivPartCatergoryName = "",
		szDivPartSubCatergoryName = "",
		szUsergroup = "",
		szDivRevAttr[] = { TD_ITEM_ID_ATTR,TD_ITEM_REV_ID_ATTR,TD_PART_CATEGORY_ATTR,TD_PART_SUBCATEGORY_ATTR };

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tParentTag = NULLTAG,
		tItemTag = NULLTAG;

	const char *pcRevId = NULL;

	std::map<string, string> strPropNameValueMap;

	char* __function__ = "teradyne_precondition_on_create_DivPartRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting values from iman_save action

		if (tRevTag != NULLTAG)
		{
			//calling function to get itemid and revisionid property values
			std::list<std::string> strAttr(szDivRevAttr, szDivRevAttr + sizeof(szDivRevAttr) / sizeof(string));
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevTag, strAttr, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
			//calling function to get user ,role,group names
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = SA_ask_group_parent(tGroupTag, &tParentTag), TD_LOG_ERROR_AND_THROW);
			if (tParentTag != NULLTAG)
			{
				TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tParentTag, &pcParentGroupName), TD_LOG_ERROR_AND_THROW);
				szUsergroup = string(pcParentGroupName) + TD_DOT_CONSTANT + string(pcGroupName) + TD_DOT_CONSTANT + string(pcRoleName);
			}
			else
			{
				szUsergroup = string(pcGroupName) + TD_DOT_CONSTANT + string(pcRoleName);
			}
			/*************************************************************************************************************/
			// UR Validation
			iStatus = ur_validateOwningGroup(); // UR Process Logics
			if (iStatus == 0)
			{
				if (strPropNameValueMap.size() > 0)
				{
					szDivPartCatergoryName.assign(strPropNameValueMap.find(TD_PART_CATEGORY_ATTR)->second);
					szDivPartSubCatergoryName.assign(strPropNameValueMap.find(TD_PART_SUBCATEGORY_ATTR)->second);
					ur_DivPart_PostAction(tRevTag, szDivPartCatergoryName, szDivPartSubCatergoryName);
				}
			}
			else // TER Process
			{
				
			if (strPropNameValueMap.size() > 0)
			{
				//Checking  naming Pattern condition for other Than CMAdmin Roles
				string szItemId = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;
				size_t pos = -1, pos1 = -1, iConVal = 0;
				pos = szItemId.find("-");
				pos1 = szItemId.find("-", pos + 1);
				if ((pos == 3) && (pos1 == 7))
				{
					iConVal = 1;
					for (int j = 0; j < szItemId.length(); j++)
					{
						if ((j == 3) || (j == 7))
						{
							continue;
						}
						else
						{
							if (isdigit(szItemId[j]))
							{
								iConVal = 1;
							}
							else
							{
								iConVal = 0;
								break;
							}
						}
					}
				}
				else
				{
					iConVal = 0;
				}

				char *pcIdCheck = strrchr((char*)szItemId.c_str(), TD_HYPHEN_CONSTANT);

				if ((szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) != 0))
				{
					//Except DBA and CMAdmin Role others cannot Create Revision ID other Than A
					if (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) != 0)
					{
						if (strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second.compare("A") != 0 && (iConVal == 1))
						{
							//validating RevId based on role
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_REV_ID_ERROR), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_REV_ID_ERROR;
							throw iStatus;
						}
					}
					if ((iConVal == 1) && (tc_strlen(pcIdCheck) == 3) && (tc_strcmp(pcIdCheck, TD_DIV_PART_ITEM_ID_SUFFIX)))
					{
						//create part NNN-NN-01 if NNN-NN-00 exists else throw an error
						int iFound = (int)szItemId.find_last_of("-");
						int iDivPart = 0;
						tag_t *tFindItemTag = { NULLTAG };
						int iFounditem = 0;
						string szFindItemID = string(szItemId.substr(0, iFound)) + TD_DIV_PART_ITEM_ID_SUFFIX;
						TERADYNE_TRACE_CALL(iStatus = ITEM_find((char*)szFindItemID.c_str(), &iFounditem, &tFindItemTag), TD_LOG_ERROR_AND_THROW);
						for (int iInitialItem = 0; iInitialItem < iFounditem; iInitialItem++)
						{
							char *pcTypeName = NULL;
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindItemTag[iInitialItem], &pcTypeName), TD_LOG_ERROR_AND_THROW);
							// if type is TD4DivPartRevision
							if (tc_strcmp(pcTypeName, TD_DIV_PART) == 0)
							{
								iDivPart++;
							}
							MEM_free(pcTypeName);
						}
						if ((iFounditem == 0) || (iDivPart == 0))
						{
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_DIV_BASE_PART_ERROR, szItemId.c_str()), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_DIV_BASE_PART_ERROR;
							throw iStatus;
						}
						MEM_free(tFindItemTag);
					}
					else if ((tc_strlen(pcIdCheck) > 3) || (iConVal == 0))
					{
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_DIV_PART_ITEM_ID_ERROR, szItemId.c_str()), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_DIV_PART_ITEM_ID_ERROR;
						throw iStatus;
					}
					//Except DBA and CMAdmin Role others cannot enter ItemID manually
					if (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) != 0)
					{
						tag_t tFindItemTag = NULLTAG;
						int iFound = (int)szItemId.find_last_of("-");
						int ifirstFound = (int)szItemId.find_first_of("-");

						string szPreffixItemID = string(szItemId.substr(0, ifirstFound));
						int iPreffixItemID = stoi(szPreffixItemID);
						string szSuffixItemID = string(szItemId.substr(iFound + 1));
						string szFindItemID = string(szItemId.substr(0, iFound));

						int iMiddleFound = (int)szFindItemID.find_last_of("-");
						if (tc_strcmp(szSuffixItemID.c_str(), "00") == 0)
						{
							int iNextID = 0, iprevID = 0, iPrefixNextID = 0;

							string szMItemID = string(szFindItemID.substr(iMiddleFound + 1));
							int currentMItemID = atoi(szMItemID.c_str());

							//char *pcNextItemID = NULL;

							//TERADYNE_TRACE_CALL(iStatus=NR_next_value(TD_DIV_PART, TD_ITEM_ID_ATTR, NULLTAG, "", "", "", NULLTAG, "", "", &pcNextItemID), TD_LOG_ERROR_AND_THROW);

							//TERADYNE_TRACE_CALL(iStatus = teradyne_search_nextid(&pcNextItemID), TD_LOG_ERROR_AND_THROW);

							string nextItemID = teradyne_search_nextid();

							int iNextFound = (int)nextItemID.find_last_of("-");
							string findNextItemID = string(nextItemID.substr(0, iNextFound));
							int iNextMidFound = (int)findNextItemID.find_last_of("-");
							string szNextMItemID = string(findNextItemID.substr(iNextMidFound + 1));

							iprevID = atoi(szNextMItemID.c_str());

							int iNextFirstFound = nextItemID.find_first_of("-");
							string szPrefixNextItemID = string(nextItemID.substr(0, iNextFirstFound));
							iPrefixNextID = atoi(szPrefixNextItemID.c_str());

							if ((currentMItemID >= (iprevID + 5)) || (iPreffixItemID != iPrefixNextID))
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_DIV_PART_ASSIGN_ITEM_ID_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_DIV_PART_ASSIGN_ITEM_ID_ERROR;
								throw iStatus;
							}

						}
					}

				}
				}
			}

				//Calling function to Validate PartCategory Value
				bool bisCreate = true;
				TERADYNE_TRACE_CALL(iStatus = teradyne_validate_required_attribute(tRevTag, strPropNameValueMap, pcUsername, bisCreate), TD_LOG_ERROR_AND_THROW);

				bool bisExecuteCondition = true;
				szDivPartCatergoryName.assign(strPropNameValueMap.find(TD_PART_CATEGORY_ATTR)->second);
				szDivPartSubCatergoryName.assign(strPropNameValueMap.find(TD_PART_SUBCATEGORY_ATTR)->second);
				//Calling function to Validate length of standard description value
				TERADYNE_TRACE_CALL(iStatus = teradyne_searchform_updateattributevalue(szDivPartCatergoryName, szDivPartSubCatergoryName, tRevTag, bisExecuteCondition, false), TD_LOG_ERROR_AND_THROW);

		

	}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcUsername);
	Custom_free(pcRoleName);
	Custom_free(pcGroupName);
	Custom_free(pcGroupFullName);
	Custom_free(pcParentGroupName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
int ur_DivPart_PostAction(tag_t tRevTag, string szDivPartCatergoryName, string szDivPartSubCatergoryName)
{
			int iStatus = 1;

	
			tag_t tChgeAdminForm = NULLTAG,
				*tOrgForm = NULLTAG,
				tRelationTag = NULL_TAG;

			char* __function__ = "ur_DivPart_PostAction";
			try
			{
				TERADYNE_TRACE_ENTER();

				// To get Change Admin Form Object
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevTag, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tChgeAdminForm), TD_LOG_ERROR_AND_THROW);

				int iObjCount = 0;
				tag_t tItemTag = NULL_TAG;

				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevTag, &tItemTag), TD_LOG_ERROR_AND_THROW);

				// To get TD4OracleOrg Form Object
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ORG_REL_NAME, &tRelationTag), TD_LOG_ERROR_AND_THROW);

				if (tRelationTag != NULL_TAG)
					TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tItemTag, tRelationTag, &iObjCount, &tOrgForm), TD_LOG_ERROR_AND_THROW);

				if (tChgeAdminForm != NULLTAG)
				{
					AM__set_application_bypass(true);// Bypass is set true to update change admin form

					//Calling function to set the property value (Item Status Property)
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgeAdminForm, TD_ITEM_STATUS_ATTR, "Concept"), TD_LOG_ERROR_AND_THROW);

					AM__set_application_bypass(false);
				}
				if (iObjCount > 0 && tOrgForm != NULL_TAG)
				{
					AM__set_application_bypass(true);// Bypass is set true to update TD4OracleOrg form

					//Calling function to set the property value (td4DefaultOrg Property)
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tOrgForm[0], TD_DEFAULT_ORG_NAME, "URDK"), TD_LOG_ERROR_AND_THROW);

					AM__set_application_bypass(false);
				}

				char *pccpPartType = NULL,
					*pcsevDigItemID = NULL,
					*pcsixDigItem = NULL;

				tag_t tdivPartmapForm = NULLTAG;


				// To get DivMapForm
				TERADYNE_TRACE_CALL(iStatus = teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory((char*)szDivPartCatergoryName.c_str(), (char*)szDivPartSubCatergoryName.c_str(), &tdivPartmapForm, true), TD_LOG_ERROR_AND_THROW);

				if (tdivPartmapForm != NULLTAG)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tdivPartmapForm, TD_PART_TYPE_ATTR, &pccpPartType), TD_LOG_ERROR_AND_THROW);

					tag_t tItemTag = NULL_TAG;
					logical isAvail = FALSE;

					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevTag, &tItemTag), TD_LOG_ERROR_AND_THROW);

			if (pccpPartType != NULL && tItemTag != NULL_TAG)
			{

				iStatus = ur_divpart_CMAdminRole_PostAction(tRevTag);
				if (iStatus == 2)
				{
					TC_write_syslog("\n UR CM ADmin User");
				}
				else
				{
					if ((tc_strcmp(pccpPartType, "Semi-Finished") == 0) || (tc_strcmp(pccpPartType, "Intangible") == 0) || (tc_strcmp(pccpPartType, "Component") == 0))
					{
						TERADYNE_TRACE_CALL(iStatus = NR_pattern_next_value(TD_DIV_PART, TD_ITEM_ID_ATTR, NULLTAG, "", "", "", NULLTAG, "", "", "NNNNNNN", &pcsevDigItemID), TD_LOG_ERROR_AND_THROW);

							//ITEM_id_exists(pcsevDigItemID, &isAvail);

							AM__set_application_bypass(true);

							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tItemTag, "item_id", pcsevDigItemID), TD_LOG_ERROR_AND_THROW);

							AM__set_application_bypass(false);
						}
						else if ((tc_strcmp(pccpPartType, "Finished Good") == 0))
						{
							TERADYNE_TRACE_CALL(iStatus = NR_pattern_next_value(TD_DIV_PART, TD_ITEM_ID_ATTR, NULLTAG, "", "", "", NULLTAG, "", "", "NNNNNN", &pcsixDigItem), TD_LOG_ERROR_AND_THROW);

							AM__set_application_bypass(true);

							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tItemTag, "item_id", pcsixDigItem), TD_LOG_ERROR_AND_THROW);

						AM__set_application_bypass(false);
					}
				}
			}
			else
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_DIV_PART_MAP_FORM_PART_TYPE_ERROR), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_DIV_PART_MAP_FORM_PART_TYPE_ERROR;
				throw iStatus;
			}
		}
		else
		{

					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_DIV_PART_MAP_FORM_ERROR, szDivPartCatergoryName.c_str(), szDivPartSubCatergoryName.c_str(), "Created"), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_DIV_PART_MAP_FORM_ERROR;
					throw iStatus;
				}
				/********************************************************************************************************************************************************/
			}
			catch (...)
			{
				if (iStatus == ITK_ok)
				{
					TC_write_syslog("Unhandled exception occured %s", __function__);
					iStatus = TERADYNE_UNKNOWN_ERROR;
				}
			}
	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
int teradyne_create_divpart_designDocs(tag_t tRevtag)
{
	int iStatus = ITK_ok;

	char *predefinedRevId = NULL;

	const char* __function__ = "teradyne_create_divpart_designDocs";
	TERADYNE_TRACE_ENTER();

	try
	{
		std::vector<std::string> docTypes;

		char *docType1 = NULL, *docType2 = NULL, *docType3 = NULL, *projectName = NULL, *description = NULL, *ID = NULL;

		//Get Design Document Types
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE1_ATTR, &docType1), TD_LOG_ERROR_AND_THROW);
		if (docType1 != NULL && *docType1 != '\0') {
			docTypes.push_back(docType1);
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE2_ATTR, &docType2), TD_LOG_ERROR_AND_THROW);
		if (docType2 != NULL && *docType2 != '\0'  && strcmp(docType1, docType2) != 0) {
			docTypes.push_back(docType2);
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DES_DOC_TYPE3_ATTR, &docType3), TD_LOG_ERROR_AND_THROW);
		if (docType3 != NULL && *docType3 != '\0' && strcmp(docType3, docType1) != 0 && strcmp(docType3, docType2) != 0) {
			docTypes.push_back(docType3);
		}

		//check if there are inputted doc types
		if ((docType1 != NULL && *docType1 != '\0') || (docType2 != NULL && *docType2 != '\0') || (docType3 != NULL && *docType3 != '\0'))
		{

			//Get ProjectName, Description and ID
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_PROJECT_NAME_ATTR, &projectName), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_FREE_FORM_DESC_ATTR, &description), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_ID_ATTR, &ID), TD_LOG_ERROR_AND_THROW);

			//New tag for new Design Doc
			tag_t type_tag = NULLTAG;
			const char* docID[] = { ID };
			const char *docDescription[] = { description };
			const char *docProject[] = { projectName };
			const char *revisionId[] = { "A" };

			// Need to check if a predefined revision was inputted 
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_REV_ID_ATTR, &predefinedRevId), TD_LOG_ERROR_AND_THROW);
			if (NULL != predefinedRevId)
			{
				*revisionId = predefinedRevId;
			}

			for (int i = 0; i < docTypes.size(); i++)
			{
				try
				{
					std::string name = docTypes[i].c_str();
					name = ((string)ID).append(name);
					std::string holder = name.append("/").append(revisionId[0]);

					const char* item_rev[] = { holder.c_str() };
					const char *documentType[] = { docTypes[i].c_str() };

					//-----------------------------Design Doc revision master
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_DESIGN_DOCUMENT_REV_MASTER_ATTR, TD_DESIGN_DOCUMENT_REV_MASTER_ATTR, &type_tag), TD_LOG_ERROR_AND_THROW);

					tag_t ddrmf_create_input_tag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(type_tag, &ddrmf_create_input_tag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(ddrmf_create_input_tag, TD_OBJECT_NAME_ATTR, 1, item_rev), TD_LOG_ERROR_AND_THROW);
					tag_t formTag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(ddrmf_create_input_tag, &formTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(formTag), TD_LOG_ERROR_AND_THROW);

					//------------------------------Design Document Revision
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_DESIGN_DOC_REV_TYPE, TD_DESIGN_DOC_REV_TYPE, &type_tag), TD_LOG_ERROR_AND_THROW);
					tag_t rev_create_input_tag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(type_tag, &rev_create_input_tag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_tag(rev_create_input_tag, TD_ITEM_MASTER_TAG_ATTR, formTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(rev_create_input_tag, TD_OBJECT_NAME_ATTR, 1, documentType), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(rev_create_input_tag, TD_OBJECT_DESC_ATTR, 1, docDescription), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(rev_create_input_tag, TD_ITEM_REV_ID_ATTR, 1, revisionId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(rev_create_input_tag, TD_PROJECT_NAME_ATTR, 1, docProject), TD_LOG_ERROR_AND_THROW);

					//------------------------------- Design Document
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_DESIGN_DOC_TYPE, TD_DESIGN_DOC_TYPE, &type_tag), TD_LOG_ERROR_AND_THROW);
					tag_t item_create_input_tag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(type_tag, &item_create_input_tag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(item_create_input_tag, TD_OBJECT_NAME_ATTR, 1, documentType), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(item_create_input_tag, TD_ITEM_ID_ATTR, 1, docID), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_set_create_display_value(item_create_input_tag, TD_OBJECT_DESC_ATTR, 1, docDescription), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_tag(item_create_input_tag, TD_REVISION_ATTR, rev_create_input_tag), TD_LOG_ERROR_AND_THROW);

					tag_t item_tag = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(item_create_input_tag, &item_tag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = ITEM_save_item(item_tag), TD_LOG_ERROR_AND_THROW);

				}
				catch (...)
				{
					if (iStatus == ITK_ok)
					{
						TC_write_syslog("Unhandled exception occured %s", __function__);
						iStatus = TERADYNE_UNKNOWN_ERROR;
					}
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(predefinedRevId);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}
int ur_divpart_CMAdminRole_PostAction(tag_t iRevTag)
{
	const char* __function__ = "ur_divpart_CMAdminRole_PostAction";

	int iStatus = 1;

	char	*pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;


	tag_t	tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tItemTag = NULLTAG;

	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);
		if (pcGroupFullName != NULL)
		{
			if (strcmp(pcGroupFullName, TD_UR_ADMIN_GRP_CONSTANT) == 0)
			{
				// Add logic for checking CM Admin.UR/Admin role in UR group could be possible to enter id manually
				char *cpItemId = NULL, *pcsevDigItemID = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(iRevTag, TD_ITEM_ID_ATTR, &cpItemId), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

				if (pcGroupFullName != NULL)
				{
					if (strcmp(pcGroupFullName, TD_UR_ADMIN_GRP_CONSTANT) == 0)
					{
						if (cpItemId != NULL)
						{
							pcsevDigItemID = cpItemId;

							AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(iRevTag, &tItemTag), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tItemTag, "item_id", pcsevDigItemID), TD_LOG_ERROR_AND_THROW);
							AM__set_application_bypass(false);
							iStatus = 2;
						}
						else
						{
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DIV_PART_ITEM_ID_NTFOUND_ERROR, "", ""), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_DIV_PART_ITEM_ID_NTFOUND_ERROR;
							throw iStatus;
						}
					}
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcGroupFullName);
	Custom_free(pcRoleName);
	Custom_free(pcUsername);
	Custom_free(pcParentGroupName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

	/**************************************************************************************************************************/
}