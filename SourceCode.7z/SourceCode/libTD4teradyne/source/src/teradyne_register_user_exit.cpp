/*==================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_register_user_exit.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           Register all the user exit here
#      Project         :           libTD4teradyne
#      Author          :           Vivek
#  =================================================================================================
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  14-Nov-2014                       Vijayasekhar                       Registered action handlers Teradyne-PopulateDynamicURL and Teradyne-WhereUsedTERPart4ROHS
#  13-Jan-2015						 Kameshwaran						Pre-condition for check-in action to check 'Change Reason' attribute value.
#  12-Mar-2015                       Vijayasekhar                       Registered action handlers Teradyne-StandardECNValidation, Teradyne-AssignStatus and Teradyne-AssignStatusOnDesignDoc
#  16-Mar-2015						 Selvi						        Registered action handlers Teradyne-GenerateECNSummaryReport.
#  17-Mar-2015						 Kameshwaran 						Registered action handlers teradyne_set_releasestatus_ECN, teradyne_set_effectivedate_on_ECNpart, teradyne_assign_itemstatus_asper_ECNstatus.
#  17-Mar-2015                       Haripriya                          Registered action handlers Teradyne-ReviewerMatrix.
#  18-Mar-2015                       Vijayasekhar                       Registered action handlers Teradyne-RevStampCalculation, Teradyne-ReleaseECNValidations
#  18-Mar-2015                       Haripriya                          Registered action handlers Teradyne-PopulateTechReviewer,Teradyne-PopulateTechReviewerProtobom
#  20-Mar-2015                       Vijayasekhar                       Registered action handlers Teradyne-ProtoBOMEcnValidations, Teradyne-ProtoBOMECNSetRevStamp and Teradyne-DeviationAcknowledgeTask
#																		And Registered the rule handlers Teradyne_IsObjectOwnerSameAsTheProcessInitator.
#  23-Mar-2015						 Kameshwaran D						Registered action handlers Teradyne-UpdateVPStatus,Teradyne-UpdateTERPartInternalStatus,Teradyne-DiscDocWhereUsedTERPart4ROHS
#  24-Mar-2015                       Vijayasekhar                    	Registered action handlers Teradyne-CreateAndCopyDSEForms and Teradyne-AttachReleaseStatusToDSEForms
#  24-Mar-2015                       Haripriya                          Registered action handlers Teradyne-EffectivityAssignment,Teradyne-EffectivityPropagation.
#  30-Mar-2015                       Vijayasekhar                    	Registered action handlers Teradyne-SetDate
#  13-Apr-2015                       Vijayasekhar                    	Registered action handlers Teradyne-UnLockEffectivity, Teradyne-LockEffectivity and Teradyne-AssignSignOffDynamicParticipant
#  15-Apr-2015                       Haripriya                    	    Registered action handlers Teradyne-AssignReviewerMatrixSignoffParticipant
#  16-Apr-2015                       Vijayasekhar                    	Registered action handlers Teradyne-GenDeviationReport
#  17-Apr-2015						 Kameshwaran D						Registered action handlers Teradyne-UpdateEnggControlFlagECN
#  20-Apr-2015						 Kameshwaran D						Registered action handlers Teradyne-WhereUsedVendorPart4ROHS
#  22-Apr-2015						 Selvi								Registered action handlers Teradyne-CreateExcemptionForm.
#  24-Apr-2015						 Kameshwaran D						Registered action handlers Teradyne-CheckEffectivityDate
#  27-Apr-2015						 Selvi								Registered action handlers Teradyne-FindLatestResult.
#  30-Apr-2015						 Haripriya						    Registered action handlers for Teradyne-CreateCmplChkForm,Teradyne-UpdateCmplAttrs handlers.
#  05-May-2015						 Haripriya						    Registered action handlers for Teradyne-change-all-started-to-suspend-resume handlers.
#  07-May-2015						 Vijayasekhar					    Registered the action handler Teradyne-UpdateSupplierInformation
#  08-May-2015						 Haripriya						    Registered the action handler Teradyne-AdhocSignoff
#  20-May-2015						 Vijayasekhar					    Registered the action handler Teradyne-ReleaseECNRevStampCalculation
#  02-Jun-2015						 Vijayasekhar					    Registered the action handler Teradyne-ReviseToSolutionItem
#  19-Jun-2015						 Vijayasekhar					    Registered the action handler Teradyne-UpdateROHSCmplStatusFromLatestResult
#  05-Aug-2015						 Haripriya						    Registered the Rule handler Teradyne-SolutionItems-ORG-Check
#  14-Aug-2015						 Haripriya						    Registered the Rule handler Teradyne-Check-SolutionItems
#  17-Dec-2015						 Janani								Registered the Rule handler Teradyne-Check-BOM-File
#  17-Aug-2016						 Haripriya						    Registered the action handler Teradyne-UpdateMaterialImpact.
#  19-Sep-2016                       Rodji                              Registered the run time property for status column in structure manager
#  28-Oct-2016						 Karl								Registered action handler for Teradyne-PartModReq-Notification.
#  7-Dec-2016						 Karl								Registered action handler for Teradyne-Reject-Notification.
#  17-Jul-2017						 Karl								Teradyne-Check-Effectivity-Revise-Eff
#  08-May-2018						 Marjorie							Registered action handler Teradyne-ValidateOPSTaskReviewer
#  07-Jun-2018						 Marjorie							Registered action handler Teradyne-assignMarketingResource
#  23-Jan-2019						 Marjorie							Registered action handler Teradyne-Update-EffectivityDate
#  $HISTORY$
#  =================================================================================================*/

#include <teradyne_register_user_exit.h>

/*******************************************************************************
 * Function Name    : libTD4teradyne_register_callbacks
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     :
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 *
 ******************************************************************************/
int libTD4teradyne_register_callbacks()
{
	const char * __function__ = "libTD4teradyne_register_callbacks";
	TERADYNE_TRACE_ENTER();

	// register workflow action handlers
	TERADYNE_TRACE(CUSTOM_register_exit("libTD4teradyne", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)libTD4teradyne_register_custom_handlers));

	TERADYNE_TRACE(CUSTOM_register_exit("libTD4teradyne", "USER_init_module", (CUSTOM_EXIT_ftn_t)libTD4teradyne_register_custom_methods));

	TERADYNE_TRACE_LEAVE(ITK_ok);
	return (ITK_ok);
}

/*******************************************************************************
 * Function Name    : libTD4teradyne_register_custom_handlers
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : int *decision , va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int libTD4teradyne_register_custom_handlers(int *decision, va_list args)
{
	int iReturnStatus = ITK_ok;

	const char * __function__ = "libTD4teradyne_register_custom_handlers";
	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE(teradyne_register_action_handlers());
	TERADYNE_TRACE(teradyne_register_rule_handlers());

	*decision = ALL_CUSTOMIZATIONS;

	TERADYNE_TRACE_LEAVE(iReturnStatus);

	return iReturnStatus;
}

/*******************************************************************************
 * Function Name    : teradyne_register_action_handlers
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     :
 *
 * RETURN VALUE     :int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_register_action_handlers()
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_register_action_handlers";
	TERADYNE_TRACE_ENTER();

	//registering the action handler Teradyne-PopulateDynamicURL
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-PopulateDynamicURL",
		"Populates the Dynamic URL",
		teradyne_populatedynamicURL
	));

	//registering the action handler Teradyne-WhereUsedTERPart4ROHS
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-WhereUsedTERPart4ROHS",
		"Gets the where used parts for ROHS",
		teradyne_whereusedterpart4ROHS
	));

	//registering the action handler Teradyne-AssignDynamicParticipant
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignDynamicParticipant",
		"Gets the user id from Participant",
		teradyne_assigndynamicparticipant
	));

	//registering the action handler Teradyne-StandardECNValidation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-StandardECNValidation",
		"Validates the production state on the BOM",
		teradyne_standardECNvalidation
	));

	//registering the action handler Teradyne-AssignStatus
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignStatus",
		"Releases all the part in Solution Item folder",
		teradyne_assignstatus
	));

	//registering the action handler Teradyne-AssignStatusOnDesignDoc 
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignStatusOnDesignDoc",
		"Will release all the Design Documents in the custom relation folder call PCBA Design Document",
		teradyne_assignstatusondesigndoc
	));

	//registering the action handler Teradyne-SetReleaseStatus
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SetReleaseStatus",
		"Handler will assign release status to all the Parts and Documents in the Solution Items folder of an ECN",
		teradyne_set_releasestatus_ECN
	));

	//registering the action handler Teradyne-SetEffectivtyDate
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SetEffectivityDate",
		"Handler will assign Effectivity date to all the Parts revision of ECN by getting the release status type",
		teradyne_set_effectivedate_on_ECNpart
	));

	//registering the action handler Teradyne-AssignItemStatus
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignItemStatus",
		"Handler will assign item status as per the ECN type ",
		teradyne_assign_itemstatus_asper_ECNstatus
	));

	//registering the action handler Teradyne-GenerateECNSummaryReport
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-GenerateECNSummaryReport",
		"Generate ECN Summary Report",
		teradyne_genECNSummaryReport
	));
	//registering the action handler Teradyne-ReviewerMatrix
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ReviewerMatrix",
		"Sets the TechReviewer and CB Reviewer Value on ECN Revision",
		teradyne_reviewermatrix
	));

	//registering the action handler Teradyne-RevStampCalculation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-RevStampCalculation",
		"Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ECN and the Change Admin Form",
		teradyne_revstampcalculation
	));

	//registering the action handler Teradyne-ReleaseECNValidation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ReleaseECNValidation",
		"Will validate the required rules",
		teradyne_releaseECNvalidation
	));

	//registering the action handler Teradyne-PopulateTechReviewer
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-PopulateTechReviewerRelease",
		"Populates the Technical Reviewer List",
		teradyne_populatetechnicalreviewer_releaseecn
	));

	//registering the action handler Teradyne-PopulateTechReviewerProtobom
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-PopulateTechReviewerProtobom",
		"Populates the Technical Reviewer List",
		teradyne_populatetechnicalreviewer_protobomecn
	));

	//registering the action handler Teradyne-ProtoBOMECNValidations
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ProtoBOMECNValidations",
		"Will validate the required rules",
		teradyne_protobomecnvalidations
	));

	//registering the action handler Teradyne-ProtoBOMECNValidations
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ProtoPartECNValidations",
		"Will validate the required rules",
		teradyne_protopartecnvalidations
	));


	//registering the action handler Teradyne-ProtoBOMECNSetRevStamp
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ProtoBOMECNSetRevStamp",
		"Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ProtoBOMECN and the Change Admin Form",
		teradyne_protobomecnsetrevstamp
	));

	//registering the action handler Teradyne-DeviationAcknowledgeTask
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-DeviationAcknowledgeTask",
		"Will assign a review task to users based on attribute 'Additional Users for Acknowledgement'",
		teradyne_deviationacknowledgetask
	));

	//registering the action handler Teradyne-UpdateVPStatus
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateVPStatus",
		"Update Vendor Part Status to Obselete for every relation between Teradyne parts and vendor part",
		teradyne_update_vendorpartstatus
	));

	//registering the action handler Teradyne-UpdateTERPartInternalStatus
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateTERPartInternalStatus",
		"Update SBM form attribute of all Teradyne parts related with vendor part",
		teradyne_update_sbm_form_vendor_part
	));

	//registering the action handler Teradyne-DiscDocWhereUsedTERPart4ROHS
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-DiscDocWhereUsedTERPart4ROHS",
		"Gets the where used parts for ROHS",
		teradyne_discdoc_whereusedterpart4ROHS
	));

	//registering the action handler Teradyne-CreateAndCopyDSEForms
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CreateAndCopyDSEForms",
		"Will create the DSE forms for the Div part rivision and copy the values of previous revision DSE forms",
		teradyne_createandcopydseforms
	));

	//registering the action handler Teradyne-AttachReleaseStatusToDSEForms 
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AttachReleaseStatusToDSEForms",
		"Will attach Release status for DSE forms of previous revision",
		teradyne_attachreleasestatustodseforms
	));

	//registering the action handler Teradyne-EffectivityAssignment
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-EffectivityAssignment",
		"Assign Effectivity for the Components",
		teradyne_effectivityassignment
	));

	//registering the action handler Teradyne-EffectivityPropagation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-EffectivityPropagation",
		"Assign Effectivity for the Assemblies",
		teradyne_effectivitypropagation
	));

	//registering the action handler Teradyne-SetDate
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SetDate",
		"Sets the timestamp of author signing off the task",
		teradyne_setdate
	));

	//registering the action handler Teradyne-LockEffectivity
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-LockEffectivity",
		"Enables the protection for the effectivity",
		teradyne_lockeffectivity
	));

	//registering the action handler Teradyne-UnLockEffectivity
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UnLockEffectivity",
		"Unlocks the protection for the effectivity",
		teradyne_unlockeffectivity
	));

	//registering the action handler Teradyne-AssignSignOffDynamicParticipant
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignSignOffDynamicParticipant",
		"Gets the user id from Participant",
		teradyne_assignsignoffdynamicparticipant
	));

	//registering the action handler Teradyne-AssignReviewerMatrixSignoffParticipant
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AssignReviewerMatrixSignoffParticipant",
		"Assigns participant from ReviewerMatrix",
		teradyne_assignrevmatdynamicparticipant
	));

	//registering the action handler Teradyne-GenDeviationReport
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-GenDeviationReport",
		"Generates the deviation report",
		teradyne_gendeviationreport
	));

	//registering the action handler Teradyne-UpdateEnggControlFlagECN
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateEnggControlFlagECN",
		"Update Engg Control Flag on ECN",
		teradyne_updateenggcontrolflagECN
	));

	//registering the action handler Teradyne-WhereUsedVendorPart4ROHS
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-WhereUsedVendorPart4ROHS",
		"Gets the where used parts from Vendor Part for ROHS",
		teradyne_whereusedvendorpart4ROHS
	));

	//registering the action handler Teradyne-CreateExcemptionForm
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CreateExcemptionForm",
		"Create Apply exemption Form for VendorPart",
		teradyne_createExcemptionForm
	));

	//registering the action handler Teradyne-FindLatestResult
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-FindLatestResult",
		"Create Apply exemption Form for VendorPart",
		teradyne_findLatestResult
	));

	//registering the action handler Teradyne-CheckEffectivityDate
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CheckEffectivityDate",
		"Check effectivity date is an earlier date",
		teradyne_checkeffectivitydatewithtodaydate
	));

	//registering the action handler Teradyne-CreateCmplChkForm
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CreateCmplChkForm",
		"Creates CmplChkForm",
		teradyne_vendorpartcompliancecalculation
	));

	//registering the action handler Teradyne-UpdateCmplAttrs
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateCmplAttrs",
		"Updates Compliance Attributes",
		teradyne_updatingteradynepartswithcomplianceattributes
	));

	//registering the action handler Teradyne-change-all-started-to-suspend-resume
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-change-all-started-to-suspend-resume",
		"changes the task state as per the action given",
		teradyne_change_all_started_to_suspend_resume
	));

	//registering the action handler Teradyne-UpdateSupplierInformation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateSupplierInformation",
		"Updates the supplier information",
		teradyne_updatesupplierinformation
	));

	//registering the action handler Teradyne-AdhocSignoffs
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AdhocSignoff",
		"Assign Signoff Member for the given task",
		teradyne_adhoc_signoff
	));

	//registering the action handler Teradyne-ReleaseECNRevStampCalculation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ReleaseECNRevStampCalculation",
		"Will translate the effectivity date into TER format and update the parts that have no Rev Stamp value",
		teradyne_releaseECNrevstampcalculation
	));

	//registering the action handler Teradyne-ReviseToSolutionItem
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ReviseToSolutionItem",
		"Will Revise the teradyne parts to solution items folder",
		teradyne_revise_to_solution_item
	));

	//registering the action handler Teradyne-UpdateROHSCmplStatusFromLatestResult
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateROHSCmplStatusFromLatestResult",
		"Will update ROHS Compliant status from the latest Result object",
		teradyne_updateROHScmplstatusfromlatestresult
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Check-BOM-File",
		"Will validate and create a log file and attach to reference folder",
		teradyne_dataset_bom_file_validation
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ImportBOMs",
		"Validate and create log, redo file",
		teradyne_bom_import_from_csv
	));

	//registering the action handler Teradyne-UpdateMaterialImpact
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateMaterialImpact",
		"Updates MaterialImpact Property On ECN from Custom form",
		teradyne_update_materialimpact_ECN_Form
	));

	//registering the action handler Teradyne-ReassignNotification
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-ReassignNotification",
		"Send notification to newly assigned user for a certain task",
		teradyne_reassignNotification
	));

	//registering the action handler Teradyne-CheckDiscSpecForm
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CheckDiscSpecForm",
		"Release ECN, check solution item discipline specific forms",
		teradyne_checkDiscSpecForms
	));

	//registering the action handler Teradyne-PartModReq-Notification
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-PartModReq-Notification",
		"Sends the comments from STD and STG signoff at the final notification",
		teradyne_partmodreq_notification
	));

	//registering the action handler Teradyne-Reject-Notification
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Reject-Notification",
		"Sends a notification upon every single reject signoff.",
		teradyne_rejectNotification
	));

	//registering the action handler Teradyne-Check-Effectivity-Revise-Eff
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Check-Effectivity-Revise-Eff",
		"Checks the effectivity date during Revise Effectivity Workflow.",
		teradyne_checkeffectivitydate_reviseeff
	));

	//registering the action handler Teradyne-UpdateVendorPartMaterialInformation
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-UpdateVendorPartMaterialInformation",
		"Updates Vendor with Material Information",
		teradyne_updatevendorpart_materialinfo
	));


	//registering the action handler Teradyne-Validate-OPSTask-Reviewer
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Validate-OPSTask-Reviewer",
		"Checks the role and group of the assigned reviewer",
		teradyne_validateOPSTaskreviewer
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Validate-MarketingResource",
		"Validate Marketing Resource in Project Form",
		teradyne_validateMarketingResource
	));

	//registering the action handler Teradyne-SubmitCommPartRevToT4O
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SubmitCommPartRevToT4O",
		"Submit Comm Part Rev to T4O",
		teradyne_submitCommPartRevToT4O
	));

	//registering the action handler Teradyne-Comment-Notification
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Comment-Notification",
		"Includes comments in email notification",
		teradyne_commentNotification
	));

	//registering the action handler Teradyne-SubmitPartToESI
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SubmitPartToESI",
		"Submits Teradyne Parts to ESI",
		teradyne_submitPartToESI
	));

	//registering the action handler Teradyne-IsControllingBusinessUnit-NXT
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-IsControllingBusinessUnit-NXT",
		"Checks whether the Controlling Business Unit is NXT or not",
		teradyne_is_controlling_bus_unit_NXT
	));


	//registering the action handler Teradyne-IsItemStatus-ProtoType
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-IsItemStatus-ProtoType",
		"Checks whether the item status is ProtoType",
		teradyne_is_item_status_prototype
	));


	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-CheckoutCheckinObject",
		"Checkout/Checkin Object",
		teradyne_checkout_checkin_object
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-GetPartTypeForModification",
		"Get the part type in Request for Modification",
		teradyne_get_part_type_to_modify
	));

	//registering the action handler Teradyne-IsControllingBusinessUnit-NXT
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Create-Part-Modify-Request",
		"Creates Part Modify Request (Document) based on Part Modify Request (Change)",
		teradyne_createPartModifyReq
	));

	//registering the action handler Teradyne-Update-EffectivityDate
	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Update-EffectivityDate",
		"Updates the effectivity date of the ECN to today if the effectivity date is less than today",
		teradyne_update_effectivitydate
	));


	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-AbortECNTasks",
		"Abort ECN Tasks",
		teradyne_abort_ecn_tasks
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-HasChangeManagementAccess",
		"This handler will check if user has change management access",
		teradyne_has_change_management_access
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Generate-SafetyReport",
		"Generates ECN Safety report",
		teradyne_genECNSafetyReport
	));



	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-SemicolonToCSVConverter",
		"This will convert semicolon to csv from bom files from UR",
		teradyne_convert_semicolon_to_csv
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-IsControllingBusUnit-UR",
		"This handler will check if the Project is UR or CBU is UR",
		teradyne_is_controlling_bus_unit_UR
	));
	

    TERADYNE_TRACE(iStatus = EPM_register_action_handler (
            "Teradyne-SupplierAddRequestValidation",
            "This handle will validate the Supplier Add Request  object",
            teradyne_supplierAddRequestValidation
    ));


	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Check-VendorPartCOO",
		"This handler will validate Vendor Part COO property",
		teradyne_check_vendorPartCOO
	));


	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Check-Manufacturer-Status",
		"Validate CPR that have a Approved or Preferred supplier",
		teradyne_check_manufacturer_status
	));

	TERADYNE_TRACE(iStatus = EPM_register_action_handler(
		"Teradyne-Check-Commercial-Parts-Exists",
		"Validate Commercial part exits with Manufacturer ID that user have provided. (without Obselete status)",
		teradyne_check_commercial_parts_exists
	));

	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name    : teradyne_register_rule_handlers
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     :
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_register_rule_handlers()
{
	int iReturnStatus = ITK_ok;

	const char * __function__ = "teradyne_register_rule_handlers";
	TERADYNE_TRACE_ENTER();

	//registering the rule handler Teradyne-IsObjectOwnerSameAsTheProcessInitator
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"Teradyne-IsObjectOwnerSameAsTheProcessInitator",
		"Validate Object Owner is same as WF initiator",
		teradyne_isobjectownersameastheprocessinitator
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"Teradyne-SolutionItems-ORG-Check",
		"Validate Oracle Form and child ORG Value in Oracle name property",
		teradyne_solutionitems_org_check
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"Teradyne-Check-SolutionItems",
		"Validate itemRev under Solution item has the relation already",
		teradyne_check_solutionitems
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"Teradyne-Provide-Information-To-User",
		"Validate itemRev under Solution item has the relation already",
		teradyne_provide_information_to_user
	));
	
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-PartTypeCheck",
		"Validate PartType Revision under Solution item of ECN Revision and compare property value",
		ur_ecn_validation_parttypecheck
	));

	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-StatusCheck",
		"Validate PartType Revision under Solution item of ECN Revision and check Itemstatus with ECNtype",
		ur_ecn_validation_statuscheck
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-BOMCheck",
		"Validate PartType Revision under Solution item of ECN Revision and check BOM with at least one component",
		ur_ecn_validation_bomcheck
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-BOMStatusCheck",
		"Validate PartType Revision under Solution item of ECN Revision and check BOM with at least one component",
		ur_ecn_validation_bomstatuscheck
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-Impacted",
		"Validate PartType Revision under Solution item of ECN Revision and check BOM component statuses",
		ur_ecn_validation_impacted
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"UR-ECN-Validation-DatasetCheck",
		"Validate PartType Revision under Solution item of ECN Revision and check design document with dataset",
		ur_ecn_validation_datasetcheck
	));
	TERADYNE_TRACE(iReturnStatus = EPM_register_rule_handler(
		"teradyne-check-PMR-properties",
		"Validate send to CE and ENG properties in PMR Revision",
		teradyne_check_PMR_properties
	));

	TERADYNE_TRACE_LEAVE(iReturnStatus);
	return iReturnStatus;
}

/*******************************************************************************
 * Function Name    : libTD4teradyne_register_custom_methods
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : int *decision, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int libTD4teradyne_register_custom_methods(int *decision, va_list args)
{
	const char * __function__ = "libTD4teradyne_register_custom_methods";
	TERADYNE_TRACE_ENTER();

	int iStatus = ITK_ok;
	METHOD_id_t method_id;

	//check if a method is registered already
	TERADYNE_TRACE(iStatus = METHOD_find_method(RES_Type, RES_checkin_msg, &method_id));

	if (method_id.id != 0)
	{
		TERADYNE_TRACE(iStatus = METHOD_add_pre_condition(method_id, (METHOD_function_t)teradyne_precondition_on_checkin_msg, NULL));

		//Adding a postaction if a method is available
		TERADYNE_TRACE(iStatus = METHOD_add_action(method_id, METHOD_post_action_type, (METHOD_function_t)teradyne_postaction_on_checkin_msg, NULL));
	}

	*decision = ALL_CUSTOMIZATIONS;

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int  teradyne_ask_td4ItemStatus(METHOD_message_t *  m, va_list  args)
{

	int iStatus = ITK_ok;
	tag_t tProperty = va_arg(args, tag_t);

	char **pcValue = va_arg(args, char**);

	tag_t tBomLine = NULLTAG, tItemRev = NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(m, tBomLine);

	TERADYNE_TRACE(iStatus = AOM_ask_value_tag(tBomLine, TD_REV_TAG_ATTR, &tItemRev));

	char *pcItemRevTypeName = NULL, *pcAttrValue = NULL;

	TERADYNE_TRACE(iStatus = teradyne_ask_object_type(tItemRev, &pcItemRevTypeName));

	if (strcmp(pcItemRevTypeName, TD_DIV_PART_REV) == 0 || strcmp(pcItemRevTypeName, TD_COMM_PART_REV) == 0) {

		TERADYNE_TRACE(iStatus = AOM_ask_value_string(tItemRev, TD_ITEM_STATUS_ATTR, &pcAttrValue));

		*pcValue = (char*)MEM_alloc((int)(strlen(pcAttrValue) + 1 * sizeof(char)));
		strcpy(*pcValue, pcAttrValue);


		Custom_free(pcAttrValue);
	}

	Custom_free(pcItemRevTypeName);

	return iStatus;
}

int  teradyne_ask_td4SafetyLicense(METHOD_message_t *  m, va_list  args)
{

	int iStatus = ITK_ok;
	tag_t tProperty = va_arg(args, tag_t);

	char **pcValue = va_arg(args, char**);

	tag_t tBomLine = NULLTAG, tItemRev = NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(m, tBomLine);

	TERADYNE_TRACE(iStatus = AOM_ask_value_tag(tBomLine, TD_REV_TAG_ATTR, &tItemRev));

	char *pcItemRevTypeName = NULL, *pcAttrValue = NULL;

	TERADYNE_TRACE(iStatus = teradyne_ask_object_type(tItemRev, &pcItemRevTypeName));

	if (strcmp(pcItemRevTypeName, TD_DIV_PART_REV) == 0 || strcmp(pcItemRevTypeName, TD_COMM_PART_REV) == 0) {

		TERADYNE_TRACE(iStatus = AOM_ask_value_string(tItemRev, TD_SAFETY_LICENSE_ATTR, &pcAttrValue));

		*pcValue = (char*)MEM_alloc((int)(strlen(pcAttrValue) + 1 * sizeof(char)));
		strcpy(*pcValue, pcAttrValue);


		Custom_free(pcAttrValue);
	}

	Custom_free(pcItemRevTypeName);

	return iStatus;
}

int TD4_BOMLine_Properties(METHOD_message_t * /*msg*/, va_list /*args*/)
{
	int iStatus = ITK_ok;

	const char * __function__ = "TD4_BOMLine_Properties";

	ResultStatus stat;

	try
	{
		METHOD_id_t  method;
		stat = METHOD_find_prop_method("BOMLine", TD_ITEM_STATUS_ATTR, "PROP_UIF_ask_value", &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_ask_td4ItemStatus, NULL);
		}
		stat = METHOD_find_prop_method("BOMLine", TD_SAFETY_LICENSE_ATTR, "PROP_UIF_ask_value", &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_ask_td4SafetyLicense, NULL);
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}

int TD4_CommPartReqRevision_Properties(METHOD_message_t * /*msg*/, va_list /*args*/)
{
	int iStatus = ITK_ok;

	const char * __function__ = "TD4_CommPartReqRevision_Properties";

	ResultStatus stat;

	try
	{
		METHOD_id_t  method;
		stat = METHOD_find_prop_method(TD_COMM_PART_REQ_REV, TD_AWC_SIGNOFF_TASKS, PROP_ask_value_tags_msg, &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_ask_td4AWCSignOffTsks, NULL);
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}


int TD4_CommPartRevision_Properties(METHOD_message_t * /*msg*/, va_list /*args*/)
{
	int iStatus = ITK_ok;

	const char * __function__ = "TD4_CommPartRevision_Properties";

	ResultStatus stat;

	try
	{
		METHOD_id_t  method;
		stat = METHOD_find_prop_method(TD_COMM_PART_REV, TD_COMMODITY_PART_REQUESTS,PROP_ask_value_tags_msg, &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_ask_td4CommPartRequests, NULL);
		}

		stat = METHOD_find_prop_method(TD_COMM_PART_REV, TD_FORMAT_CHANGE_REASON_HISTORY, "PROP_UIF_ask_value", &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_format_change_reason_history, NULL);
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}



int TD4_DivPartRevision_Properties(METHOD_message_t * /*msg*/, va_list /*args*/)
{
	int iStatus = ITK_ok;

	const char * __function__ = "TD4_DivPartRevision_Properties";

	ResultStatus stat;

	try
	{
		METHOD_id_t  method;
		stat = METHOD_find_prop_method(TD_DIV_PART_REV, TD_FORMAT_CHANGE_REASON_HISTORY, "PROP_UIF_ask_value", &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_format_change_reason_history, NULL);
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}



int TD4_Vendor_Properties(METHOD_message_t * /*msg*/, va_list /*args*/)
{
	int iStatus = ITK_ok;

	const char * __function__ = "TD4_Vendor_Properties";

	ResultStatus stat;

	try
	{
		METHOD_id_t  method;
		stat = METHOD_find_prop_method(TD_VENDOR, TD_FORMAT_CHANGE_REASON_HISTORY, "PROP_UIF_ask_value", &method);
		if (method.id != NULLTAG)
		{
			stat = METHOD_add_action(method, METHOD_post_action_type, teradyne_format_change_reason_history, NULL);
		}

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}








/*******************************************************************************
 * Function Name			: teradyneGenerateCommPartReqAWCSignOffs
 * Description				: This function will show the selected conditional tasks to Commercial Part
 *                            Request Revision SignOff Tab in Active Workspace.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject     (I)  - object tag
 *							  pcTypeName  (OF)  - object type
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 *
 * NOTES					:
 ******************************************************************************/
int  teradyne_ask_td4AWCSignOffTsks(METHOD_message_t *  m, va_list  args)
{

	int iStatus = ITK_ok;

	tag_t tItemRev = m->object_tag;
	va_list largs;
	va_copy(largs, args);
	tag_t prop_tag = va_arg(largs, tag_t);
	int *num_tags = va_arg(largs, int*);
	tag_t **tags = va_arg(largs, tag_t**);
	

	tag_t *tActuatedInterActive = NULL;

	int iValCount = 0,
		ii = 0,
		iAWCTaskCount = 0;
	
	char *pcTypeName = NULL,
		*pcTaskName = NULL;
	std::vector<tag_t>	tVecTaskToInclude;


	string arrConditionTaskToInclude[] = { "CSE Work","CSE Additional Work" };
	const char * __function__ = "teradyne_ask_td4AWCSignOffTsk";
	TERADYNE_TRACE_ENTER();

	*num_tags = 0;
	*tags = 0;
	
	try {

		std::set<string> setConditionalTask(arrConditionTaskToInclude, arrConditionTaskToInclude + sizeof(arrConditionTaskToInclude) / sizeof(string));
		
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tItemRev, "fnd0ActuatedInteractiveTsks", &iValCount, &tActuatedInterActive), TD_LOG_ERROR_AND_THROW);

		for (ii = 0; ii < iValCount; ii++) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tActuatedInterActive[ii], &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, "EPMConditionTask") == 0))) {

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tActuatedInterActive[ii], "fnd0AliasTaskName", &pcTaskName), TD_LOG_ERROR_AND_THROW);

				if (pcTaskName != NULL && setConditionalTask.count(pcTaskName) == 0) {
					continue;
				}
			}

			tVecTaskToInclude.push_back(tActuatedInterActive[ii]);

		}


		*num_tags = tVecTaskToInclude.size();
		*tags = (tag_t *)MEM_alloc((int)tVecTaskToInclude.size() * sizeof(tag_t));
		
        for (int iFilteredTask = 0; iFilteredTask < tVecTaskToInclude.size(); iFilteredTask++) {
			(*tags)[iFilteredTask] = tVecTaskToInclude.at(iFilteredTask);
		}

		
		va_end(largs);
		
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}



/*******************************************************************************
 * Function Name			: teradyneGenerateCommPartRequests
 * Description				: This function will show related commercial part requests to comm part revision ,since there is no relation established between commercial revision to requests
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject     (I)  - object tag
 *							  pcTypeName  (OF)  - object type
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 *
 * NOTES					:
 ******************************************************************************/

int  teradyne_ask_td4CommPartRequests(METHOD_message_t *  m, va_list  args)
{

	int iStatus = ITK_ok;

	tag_t tItemRev = m->object_tag;
	va_list largs;
	va_copy(largs, args);
	tag_t prop_tag = va_arg(largs, tag_t);
	int *num_tags = va_arg(largs, int*);
	tag_t **tags = va_arg(largs, tag_t**);


	tag_t tItemTag = NULLTAG;
	std::vector<tag_t>	tVecCommercialPartRequests;

	char *pcTypeName = NULL;
	const char * __function__ = " teradyne_ask_td4CommPartRequests";
	TERADYNE_TRACE_ENTER();

	*num_tags = 0;
	*tags = 0;

	try {

      tag_t	tRelationType = NULLTAG,
			*tFindTeraObjTag = NULL;
		int iObjCount = 0;

		
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tItemRev, &tItemTag), TD_LOG_ERROR_AND_THROW);


		if (tItemTag != NULLTAG) {
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_REQ_RESULTS_IN_PART_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tItemTag, tRelationType, &iObjCount, &tFindTeraObjTag), TD_LOG_ERROR_AND_THROW);


			for (int iPos = 0; iPos < iObjCount; iPos++) {
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindTeraObjTag[iPos], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0))) {
					tVecCommercialPartRequests.push_back(tFindTeraObjTag[iPos]);

				}


			}
		}

		*num_tags= tVecCommercialPartRequests.size();

		*tags = (tag_t *)MEM_alloc((int)tVecCommercialPartRequests.size() * sizeof(tag_t));
		for (int iFilteredTask = 0; iFilteredTask < tVecCommercialPartRequests.size(); iFilteredTask++) {
			(*tags)[iFilteredTask] = tVecCommercialPartRequests.at(iFilteredTask);
		}
	
		va_end(largs);

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}

char* td4PrimaryObjUID = "ABC";



