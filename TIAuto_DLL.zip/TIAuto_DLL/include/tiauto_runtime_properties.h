/*H*****************************************************************************
*
* FILENAME : tiauto_runtime_properties.h
*
* DESCRIPTION :
*       This file provides the required header files for all runtime properties
*
* USEAGE :
*       When using functions from tiauto_runtime_properties.c this file should be #included.
*
*
* NOTES :
*
* CHANGES :
*	REF NO   DATE			WHO			DETAIL
*              
*	001		08/13/2009		N Kamath	Initial Creation
*	002		12/31/2010		Dipak Naik	Added TIAUTO_BOMLine_property_method
*	003     11/Jun/2019		Jugunu      Added TIAUTO_Get2D_PDF
*H*/

#ifndef TIAUTO_RUNTIME_PROPS_H
#define TIAUTO_RUNTIME_PROPS_H

#include <stdarg.h>
#include <tccore/method.h>
#include <time.h>

/*******************************************************************************
* Server Exits
*******************************************************************************/

int t1aAUTO_register_runtime_properties (int *decision, va_list args );

extern int TIAUTO_display_task_properties(METHOD_message_t* m, va_list args );

int  Set_prop_value_ActiveTask( METHOD_message_t *  message, va_list  args );
int  Set_prop_value_ResponsiblePrty( METHOD_message_t *  message, va_list  args );
int  Set_prop_value_TaskStartDate( METHOD_message_t *  message, va_list  args );

extern int TIAUTO_BOMLine_property_method(METHOD_message_t* m, va_list args );
extern int TIAUTO_Get2D_PDF(METHOD_message_t* m, va_list args );
extern int  Set_Property_2DDrawing( METHOD_message_t *  message, va_list  args );
extern int TIAUTO_Get3D_data(METHOD_message_t* m, va_list args );
extern int  Set_Property_3DData( METHOD_message_t *  message, va_list  args );
#endif /* tiauto_runtime_properties.h ------ END OF FILE ------*/
