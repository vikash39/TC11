/*H*****************************************************************************
*
* FILENAME : tiauto_utils.h
*
* DESCRIPTION :
*       This file provides the prototypes of utility functions
*
* USEAGE :
*       When using tiatuo utility functions, this file should be #included.
*
*
* NOTES :
*
*
*
* CHANGES :
*	REF NO   DATE			WHO		DETAIL
*              
*		06/20/2007		Srikanth P	Initial Creation
*       07/06/2007      Srikanth P  Merged with Rajesh code - t1aAUTO_check_document
*		27/01/2009		Garima		Added few generic code for error handling and printing
*		02/04/2009		Rajesh N	Added 3 new re-usable methods - tiauto_is_value_available_in_list & 
*									tiauto_get_lov_values & tiauto_get_itemrev_name
*		11/02/2009		Dipak Naik	Added "tiauto_get_related_objects" to get all the objects
									attached to the item revision with the specified relation. 
*		17/03/2009		Garima		Added 2 new re-usable methods - tiauto_check_if_itemType_isOEM & 
*									tiauto_clearErrorMsgStack
*		14/04/2009		Garima		Added 2 new re-usable methods -  
*									tiauto_checkIf_affected_isA_proEInstance_getGenericPart &
*									tiauto_search_changeProcess_for_itemRev_getDetails
*		29/04/2009		Dipak Naik	added 3 methods
*									tiauto_getItemRevDetails
*									tiauto_getUser
*									tiauto_sendEMail
		28/07/2009		Rajesh N	added tiauto_getFormAttachedToObject method
*		15/04/2010		Dipak Naik	Added - tiauto_get_stacked_DAP_changeProcess_Details
*       28/07/2010		Nivedita    Added tiauto-get-values-from-comma-separated-string
*		10/08/2010		Dipak Naik	Added - tiauto_get_Form_attribute_value_of_ItemRev
*											remove_forward_AND_trailing_space									
*H*/

#ifndef tiauto_utils_h
#define tiauto_utils_h
/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
#include <tiauto_defines.h>

/* typedefs for structures */
typedef struct	STATUS_Struct_s
{
	int     iCount;
    char    **StatusArray;
} STATUS_Struct_t, *STATUS_Struct_p_t;

/* typedefs for structures to hold array of strings and string count */
typedef struct	STRING_Array_Struct_s
{
	int     iCount;
    char    **ValueArray;
} STRING_Array_Struct_t, *STRING_Array_Struct_p_t;

typedef struct	TARGET_RELEASE_Struct_s
{
	int     iLevel;
    char    szTargetReleaseStatus[WSO_name_size_c+1];
} TARGET_RELEASE_Struct_t, *TARGET_RELEASE_p_t;

typedef struct ErrorItems
{
	char  szErrorItems[TIAUTO_error_message_len + 1];
	struct ErrorItems * next;
}TIA_ErrorItems;

/* tiauto external function prototypes */
extern int  tiauto_get_release_status (tag_t wsObj, char *releaseStatus);

extern int  tiauto_get_class_name_of_instance(tag_t tInstance, char    **pszClassName);

extern void tiauto_initialize_status_progression_stuct(STATUS_Struct_t    *StatusProgression);

extern int  tiauto_get_object_name (tag_t   object_tag, char    *type_name);

extern int  tiauto_get_target_release_status (tag_t  tEngChangeRev, char *pszReleaseStatus);

extern int  tiauto_check_if_affected_is_an_assembly(tag_t tObject, logical* lIsAnAssembly);

extern int  tiauto_get_task_attachments (EPM_action_message_t msg, int attachment_type,          
                                         int   *num_attachments,   tag_t   **attachment_tags); 

extern int  tiauto_status_progression_index (char   *pszReleaseStatus,
                                             STATUS_Struct_t    StatusProgression) ;

extern int  tiauto_get_status_progression_array( STATUS_Struct_t    *StatusProgression);

//extern int tiauto_get_change_item_rev (EPM_rule_message_t msg,    tag_t    *tEngChangeRev); 

extern int tiauto_get_change_item_rev (tag_t    msgTask,    tag_t    *tEngChangeRev); 

extern int tiauto_get_newchange_item_rev (tag_t    msgTask,    tag_t    *tEngChangeRev);

extern logical tiauto_isComponent_partOf_affectedItems(tag_t    tItemRev, tag_t    tEngChangeRev);
extern int tiauto_checkIf_affected_isA_proEInstance_getGenericPart(tag_t    tItem, logical *lProE, tag_t   *genItemRevTag, char	 *pcGenItemAltIdName);


extern int  tiauto_search_changeProcess_for_itemRev_getDetails (tag_t      itemRevTag,  STATUS_Struct_t	StatusProgression, char     **pcOtherTargetReleaseStatus, char     **pcOtherProcessName);


extern void tiauto_writeErrorMsgToStack(TIA_ErrorMessage **currErrMsg, int iFail, char* sError);

extern void tiauto_clearErrorMsgStack(TIA_ErrorMessage *currErrMsg);

/* START : added by Rajesh N on 02/04/2009 for check cro items rule handler */

extern   void tiauto_is_value_available_in_list( STRING_Array_Struct_t stLovValues, char *pcValueToCheck, logical *result);
extern  int tiauto_get_lov_values (char  *pcLovName, STRING_Array_Struct_t    *psLovValues);
extern  int tiauto_get_itemrev_name (tag_t tItemRevTag, char** pcItemRevName);

/* END :  added by Rajesh N on 02/04/2009 for check cro items rule handler */

extern int tiauto_check_if_itemType_isOEM(tag_t		objTag, logical	*isOEM);

extern  int  tiauto_get_related_objects( char acRelationName[TCTYPE_name_size_c+1],
										 tag_t tItemRevTag,int *piObjCount,
										 tag_t	**ptAttachs );
extern int tiauto_getItemRevDetails(tag_t tItemRev, char *pcItemId, 
					 char *pcRevId, char *pcName);
extern int tiauto_getUser(tag_t tRootTask,char *pcTaskName  ,tag_t *tResponsibleParty);


extern int tiauto_sendEMail(const char *subject,const char *receiverList,const char *pcMailBodyFileName ) ;

extern int tiauto_sendEMailFromPLMAdmin(	const char *subject,const char *pcreceiverList,	const char *pcMailBodyFileName );

extern int  tiauto_getFormAttachedToObject(tag_t  tObj, char *szFormType, tag_t *tForm );

extern int tiauto_get_target_folder (tag_t    msgTask,  
                                       tag_t    *tFolder);
extern int  tiauto_getFormAttachedToFolder(tag_t  tObj, char *szFormType, tag_t *tForm );

extern int  tiauto_get_target_release_sts_quick_progression(tag_t  tEngChangeRev,char *pcFormType, char *szTargetReleaseStatus);

extern int  tiauto_get_stacked_DAP_changeProcess_Details ( tag_t itemRevTag,char  **pcOtherProcessName);

extern int  tiauto_get_Form_attribute_value_of_ItemRev( tag_t  tEngChangeRev,   /* <I> */
														char *pcFormType,		/* <I> */
														char *pcAttributeName,  /* <I> */
														char *pcAttributeValue); /* <O> */

void remove_forward_AND_trailing_space(char *pcValue);

extern  int tiauto_get_values_from_comma_separated_string (char  *pszValue,STATUS_Struct_t    *AllowedStatus);

void tiauto_Store_wsom_tags(TIA_UniqueWSOMObjects **TagsList,int *iNumTags, tag_t tWsomtag);
extern void tiauto_clearTagStack(TIA_UniqueWSOMObjects *UniqueObjs);
extern void TI_sprintf(char* buffer, char* format, ... );
//parse the string by using comma(,) separator and put into sub string into the structure
extern int tiauto_get_values_from_any_delimiter_string (char *pszDelim,char  *pszValue, STATUS_Struct_t    *AllowedStatus);

extern logical  tiauto_writeErrorItemsToStack(TIA_ErrorItems **currErrMsg, char* sError);

extern int tiauto_check_if_itemType_isDOC(tag_t		objTag,	/*<I>*/ 
										  logical	*lIsDOC	/*<O>*/ );

extern int check_related_revision_folder(tag_t	tItemRev, TIA_ErrorMessage **currErrMsg );

extern int Validate_IRM_form_mandatory_Attributes(int iNumAffected, tag_t *ptItemRevList, TIA_ErrorMessage **errMsgStack_);

 //to get the target object tag based on the input object type
extern int get_target_object(tag_t tTask,char *pcTargetTypeName,tag_t *tTargetObject);

extern int verify_Valid_ERP_Plant(tag_t tTask,boolean *bValidERPPlant,boolean *bMfgRelAuth,char **pcValidReleaseStatusList);

extern int verify_MfgReleaseAuthorisation_Creation_Condition(tag_t tItemRev,char *pcTargetStatus,char *pcValidStatusList,
																boolean *bMfgRelAuth);

extern int verify_MfgReleaseAuthorisation_Creation_Additional_Condition( tag_t tItemRev,
																  tag_t tEngChgRev, 
																  char *pcTargetReleaseStatus,																 
																  STATUS_Struct_t	*StatusProgression,
																  TARGET_RELEASE_Struct_t *TargetReleaseStatus,
																  boolean bIsComponentMRA,
																  int iNewAseemCount,
																  tag_t *ptNewAssembly,
																  boolean *bIsValid);

extern int verify_ChildPart_in_ParentBOM(tag_t tChildPart,tag_t tParent,boolean *bFound);

extern int tiauto_checkIf_affected_isA_SWConfig_getDocument(tag_t    tItem, logical *lIsSW, tag_t   *docItemRevTag, char	 *pcDocItemAltIdName);

extern int check_document_related_revision_folder(	tag_t	tDocRev, TIA_ErrorMessage **currWarMsg );

void RemoveTrailingBlanks(char *pcValue);
extern long fsize(FILE* binaryStream);

extern char* fgetsr(char* buf, int n, FILE* binaryStream);

int GetTaskNameDateAndUserInfo(char acInput[SS_MAXLLEN], char** pctempActionName,char** pctempTaskName,char** pctempDateNTime,
								char** pctempUserName,char** pctempSurrUserName);

int parseWorkflowAuditInfoFromDatabase( tag_t tRoot,char **pcComment, char **pcRespName, char **pcRespGroup,char **pcRespRole, char **pcRejected_Task);

void tiauto_Store_ChangeAttrs(TIA_ChangeAttrs **ChangeAttrs,int *iNumTags, const char* pcAttr);

int verify_Valid_MRA_Condition(tag_t tTask,boolean *bMfgRelToBeCreated,char **pcValidReleaseStatusList);

int verify_Valid_ACD_Condition(tag_t tTask,boolean *bMfgRelToBeCreated,char **pcValidReleaseStatusList);

int verify_Valid_PRA_Condition(tag_t tTask,boolean *bProRelToBeCreated,char **pcValidReleaseStatusList);

int verify_ProReleaseAuthorisation_Creation_Condition(tag_t tItemRev,char *pcTargetStatus,char *pcValidStatusList,
																boolean *bProRelAuth);

int verify_ProReleaseAuthorisation_Creation_Additional_Condition( tag_t tItemRev,
																  tag_t tEngChgRev, 
																  char *pcTargetReleaseStatus,																 
																  STATUS_Struct_t	*StatusProgression,
																  TARGET_RELEASE_Struct_t *TargetReleaseStatus,
																  boolean bIsComponentPRA,
																  int iNewAseemCount,
																  tag_t *ptNewAssembly,
																  boolean *bIsValid);

#endif /* tiauto_utils.h ------ END OF FILE ------*/
