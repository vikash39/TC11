/*H*****************************************************************************
*
* FILENAME : tiauto_user_query.h
*
* DESCRIPTION :
*       This file provides all the #defines for the implementation
*
* USEAGE :
*       When using any tiatuo custom #define, this file should be included.
*
*
* NOTES :
**********************************************************************************/

#ifndef TIAUTO_USER_QUERY_H
#define TIAUTO_USER_QUERY_H

#include <tiauto_defines.h>
#include <tiauto_utils.h>
#include <tiauto_item_rev_any_prt_num_functions.h>

#include <user_exits/user_exit_msg.h>
#include <stdarg.h>

extern int t1aAUTO_register_user_query (int *decision, va_list args );
extern int TIAUTO_item_rev_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found);
extern int TIAUTO_item_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int TIAUTO_find_tasks_assigned_to_users(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);
extern int find_tasks_assigned_to_users(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int find_tasks_assigned_to_signoff_users(const char* Keyword ,int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int find_change_affected_program_in_form(char		*pcProgName,char	*pcChangeID,date_t	pcCreAfter, date_t	pcCreBefore, date_t	pcModAfter,
												date_t	pcModBefore, char		*pcDiv, char		*pcDesc, char		*pcSite, char		*pcGroup,
												char		*pcOwner, char		*pcLast_Mod_User, char		*pcRel_Stat, char		*pcTask,
												logical	alIn_data[12], char	*pcForm,char	*pcFo_Attr, char	*pcFo_ADiv,char	*pcFo_ADesc, int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_change_rev_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );

extern int find_change_rev_affected_program_in_form(char		*pcProgName,char	*pcChangeID,char	*pcRevID,date_t	pcCreAfter, date_t	pcCreBefore, date_t	pcModAfter,
												date_t	pcModBefore, char		*pcDiv, char		*pcDesc, char		*pcSite, char		*pcGroup,
												char		*pcOwner, char		*pcLast_Mod_User, char		*pcRel_Stat, char		*pcTask,
												logical	alIn_data[12], char	*pcForm,char	*pcFo_Attr, char	*pcFo_ADiv,char	*pcFo_ADesc, int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_partner_submission_documents(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);
extern int TIAUTO_find_assembly_having_substitute_parts(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_assembly_having_substitute_parts(const char* Keyword_ItemID,const char* Keyword_RevisionID,const char* Keyword_Name,const char* Keyword_ItemType,
												 const char* Keyword_CAD,const char* Keyword_CBD, const char* Keyword_MAD, const char* Keyword_MBD,
												 int *iNumFound,tag_t **foundTags);

extern int find_partner_submission_data(const char* Keyword_DocumentID,const char* Keyword_RevisionID,const char* Keyword_Name,const char* Keyword_DocumentType,
										const char* Keyword_CAD,const char* Keyword_CBD, const char* Keyword_MAD, const char* Keyword_MBD,
										const char* Keyword_PdeJobNumber,const char* Keyword_SendingCompanyName,const char* Keyword_SendingCountry,
										const char* Keyword_SendingCity,const char* Keyword_SenderName,const char* Keyword_SenderEmailAddr,
										const char* Keyword_ReceivingCompanyName,const char* Keyword_ReceivingCountry,
										const char* Keyword_ReceivingCity,const char* Keyword_ReceiverName,const char* Keyword_ReceiverDept,
										const char* Keyword_ReceiverMailAddr,const char* Keyword_ReceiverFax,const char* Keyword_ReceivingLocation,
										const char* Keyword_ReceivingPostalCode,const char* Keyword_ReceivingStreet,const char* Keyword_ReceiverContactNum,const char* Keyword_SenderContactNum,
										const char* Keyword_SenderDept,const char* Keyword_SenderFax,const char* Keyword_SenderPostalcode,
										const char* Keyword_SendingLocation,const char* Keyword_SendingStreet,    
										const char* Keyword_tempkey_Action, const char* Keyword_tempkey_DocDescription, 
										const char* Keyword_tempkey_DocNumber,	const char* Keyword_tempkey_Information, 
										const char* Keyword_tempkey_PartNumber, const char* Keyword_tempkey_PartRev, 
										const char* Keyword_tempkey_State,
										int *iNumFound,tag_t **foundTags, char *pcClassName);

extern int TIAUTO_find_parts_by_customer_info(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_parts_by_customer_info(const char* pcKeyword_ProgramName,const char* pcKeyword_CustomerName,const char* pcKeyword_CompanyType,
									   const char* pcKeyword_CBD,const char* pcKeyword_CAD, const char* pcKeyword_MBD, const char* pcKeyword_MAD,
									   int *iNumFound,tag_t **foundTags);


extern int TIAUTO_find_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );

extern int find_change (const char* pcChangeID,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags);
extern int find_change_cap (const char* pcChangeID,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int find_change_rev (const char* pcChangeID,const char* pcChangeRev,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags);
extern int find_change_rev_cap (const char* pcChangeID,const char* pcChangeRev,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_CAP_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int TIAUTO_find_CAP_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );

extern int find_CAP_change (const char* pcItemID,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,const char* pcMBD,const char* pcOwningUser,
							const char* pcOwningGroup, const char* pcOwningSite,const char* pcLastModUser,const char* pcReleaseStatus,const char* pcCurrentTask,
							const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPgms,const char* pcAffPlant,const char* pcTIChangeDesc,const char* pcChangeDriver,
							const char* pcTargetReleaseStatus,const char* pcReqGroup,const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,
							const char* pcImpAfter,const char* pcImpBefore,
							char* pcForm,
							int *iNumFound,tag_t **foundTags);

extern int find_CAP_change_rev (const char* pcItemID,const char* pcRev,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,
								const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,const char* pcOwningGroup, 
								const char* pcOwningSite,const char* pcLastModUser,const char* pcReleaseStatus,const char* pcCurrentTask,
								const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPgms,const char* pcAffPlant,const char* pcTIChangeDesc,
								const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,const char* pcCustTrackingNum,
								const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcImpAfter,const char* pcImpBefore,
								char* pcForm,
								int *iNumFound,tag_t **foundTags);

extern int TIAUTO_find_PMR_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int TIAUTO_find_PMR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int TIAUTO_find_CCR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int TIAUTO_find_CCR_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found );
extern int find_PMR_change (const char* pcItemID,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,const char* pcMBD,
							const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite,const char* pcLastModUser,
							const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcTIDiv,const char* pcProductGroup,
							const char* pcAffPgms,const char* pcAffPlant,const char* pcBillCompType,const char* pcBillComp,
							const char* pcCustNameType,const char* pcCustName,const char* pcTIChangeDesc,const char* pcChangeDriver,
							const char* pcTargetReleaseStatus,const char* pcReqGroup,const char* pcLevOfReq,const char* pcTypeOfChange,
							const char* pcPMRReason,const char* pcSuppTrackingNum,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,
							char* pcForm,
							int *iNumFound,tag_t **foundTags);

extern int find_PMR_change_rev (const char* pcItemID,const char* pcRev,const char* pcName,const char* pcCAD,const char* pcCBD,
								const char* pcMAD,const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,
								const char* pcOwningGroup,const char* pcOwningSite,const char* pcLastModUser,const char* pcReleaseStatus,
								const char* pcCurrentTask,const char* pcTIDiv,const char* pcProductGroup,
								const char* pcAffPgms,const char* pcAffPlant,const char* pcBillCompType,const char* pcBillComp,
								const char* pcCustNameType,const char* pcCustName,const char* pcTIChangeDesc,const char* pcChangeDriver,
								const char* pcTargetReleaseStatus,const char* pcReqGroup,const char* pcLevOfReq,const char* pcTypeOfChange,
								const char* pcPMRReason,const char* pcSuppTrackingNum,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,
								char* pcForm,
								int *iNumFound,tag_t **foundTags);
extern int find_CCR_change_rev (const char* pcItemID,const char* pcRevision,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,
								const char* pcOwningGroup, const char* pcOwningSite,const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcPricingGuidance,const char* pcSplCustCommerReq,
								const char* pcLaborEcoYrmax,const char* pcLaborEcoYrmin,const char* pcPackaging,const char* pcTypeofQuote,const char* pcBillCompType,const char* pcBillComp,const char* pcCustAuthorNum,const char* pcCustContName,
								const char* pcCustContEmail,const char* pcCustPhone,const char* pcEstNum, const char* pcVarEstNum, const char* pcCostofChangeCur,const char* pcToolCostmax,const char* pcToolCostmin,const char* pcCustPaidToolmax,
								const char* pcCustPaidToolmin,const char* pcPurExWorkCostmax,const char* pcPurExWorkCostmin,const char* pcPurDelDutyPaidCostmax,const char* pcPurDelDutyPaidCostmin,const char* pcLogisCostmax, 
								const char* pcLogisCostmin,const char* pcMfgLaborCostmax,const char* pcMfgLaborCostmin,const char* pcMatCostmax,const char* pcMatCostmin,const char* pcMfgVarCostmax,const char* pcMfgVarCostmin,
								const char* pcMfgScrapPermax,const char* pcMfgScrapPermin,const char* pcTotalVarCostmax,const char* pcTotalVarCostmin,const char* pcMfgSellingTransPricemax,const char* pcMfgSellingTransPricemin,
								const char* pcTIMarkupUnitCurrmax,const char* pcTIMarkupUnitCurrmin,const char* pcScreeningReq,const char* pcCustAppReq,const char* pcCustAppType,const char* pcRFQIssuemax, const char* pcRFQIssuemin, 
								const char* pcRFQCustDuemax,const char* pcRFQCustDuemin,const char* pcProtoDuemax,const char* pcProtoDuemin,const char* pcProtoQltSignmax, const char* pcProtoQltSignmin,const char* pcDesignValDuemax,
								const char* pcDesignValDuemin,const char* pcPPAPReq,const char* pcTarPPAPLevel, const char* pcCritPathItem,const char* pcCriPathItemPPAPmax,const char* pcCriPathItemPPAPmin,const char* pcPPAPBuildEvemax,
								const char* pcPPAPBuildEvemin,const char* pcProValSignmax,const char* pcProValSignmin,const char* pcRunRateSignmax, const char* pcRunRateSignmin, const char* pcPPAPSignmax, const char* pcPPAPSignmin, 
								const char* pcProSignmax, const char* pcProSignmin, const char* pcProdMatReqmax,const char* pcProdMatReqmin,const char* pcStartProdmax,const char* pcStartProdmin,const char* pcEndProdmax,const char* pcEndProdmin,
								char* pcForm,
								int *iNumFound,tag_t **foundTags);
extern int find_CCR_change (const char* pcItemID,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,
								const char* pcOwningGroup, const char* pcOwningSite,const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcPricingGuidance,const char* pcSplCustCommerReq,
								const char* pcLaborEcoYrmax,const char* pcLaborEcoYrmin,const char* pcPackaging,const char* pcTypeofQuote,const char* pcBillCompType,const char* pcBillComp,const char* pcCustAuthorNum,const char* pcCustContName,
								const char* pcCustContEmail,const char* pcCustPhone,const char* pcEstNum, const char* pcVarEstNum, const char* pcCostofChangeCur,const char* pcToolCostmax,const char* pcToolCostmin,const char* pcCustPaidToolmax,
								const char* pcCustPaidToolmin,const char* pcPurExWorkCostmax,const char* pcPurExWorkCostmin,const char* pcPurDelDutyPaidCostmax,const char* pcPurDelDutyPaidCostmin,const char* pcLogisCostmax, 
								const char* pcLogisCostmin,const char* pcMfgLaborCostmax,const char* pcMfgLaborCostmin,const char* pcMatCostmax,const char* pcMatCostmin,const char* pcMfgVarCostmax,const char* pcMfgVarCostmin,
								const char* pcMfgScrapPermax,const char* pcMfgScrapPermin,const char* pcTotalVarCostmax,const char* pcTotalVarCostmin,const char* pcMfgSellingTransPricemax,const char* pcMfgSellingTransPricemin,
								const char* pcTIMarkupUnitCurrmax,const char* pcTIMarkupUnitCurrmin,const char* pcScreeningReq,const char* pcCustAppReq,const char* pcCustAppType,const char* pcRFQIssuemax, const char* pcRFQIssuemin, 
								const char* pcRFQCustDuemax,const char* pcRFQCustDuemin,const char* pcProtoDuemax,const char* pcProtoDuemin,const char* pcProtoQltSignmax, const char* pcProtoQltSignmin,const char* pcDesignValDuemax,
								const char* pcDesignValDuemin,const char* pcPPAPReq,const char* pcTarPPAPLevel, const char* pcCritPathItem,const char* pcCriPathItemPPAPmax,const char* pcCriPathItemPPAPmin,const char* pcPPAPBuildEvemax,
								const char* pcPPAPBuildEvemin,const char* pcProValSignmax,const char* pcProValSignmin,const char* pcRunRateSignmax, const char* pcRunRateSignmin, const char* pcPPAPSignmax, const char* pcPPAPSignmin, 
								const char* pcProSignmax, const char* pcProSignmin, const char* pcProdMatReqmax,const char* pcProdMatReqmin,const char* pcStartProdmax,const char* pcStartProdmin,const char* pcEndProdmax,const char* pcEndProdmin,
								char* pcForm,
								int *iNumFound,tag_t **foundTags);								
//find OEM Items
extern int TIAUTO_find_OEM(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_OEM (const char* pcItemID,const char* pcName,const char* pcObjType,const char* pcProgramType,const char* pcLaunchModelYear,
								const char* pcReleasedByChange,const char* pcCustomerName,const char* pcCustomerReleaseNo,
								const char* pcOwningUser,const char* pcOwningGroup,const char* pcOwningSite,const char* pcLastModUser,
								const char* pcCreatedAfter,const char* pcCreatedBefore,const char* pcModifiedAfter,const char* pcModifiedBefore,const char* pcReleasedAfter,
								const char* pcReleasedBefore,const char* pcReleaseStatus,const char* pcCurrentTask,
								int *iNumFound,tag_t **foundTags);

//find OEM Item Revs
extern int TIAUTO_find_OEM_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_OEM_rev (const char* pcItemID,const char* pcRevID,const char* pcName,const char* pcObjType,const char* pcProgramType,const char* pcLaunchModelYear,
								const char* pcReleasedByChange,const char* pcCustomerName,const char* pcCustomerReleaseNo,
								const char* pcOwningUser,const char* pcOwningGroup,const char* pcOwningSite,const char* pcLastModUser,
								const char* pcCreatedAfter,const char* pcCreatedBefore,const char* pcModifiedAfter,const char* pcModifiedBefore,const char* pcReleasedAfter,
								const char* pcReleasedBefore,const char* pcReleaseStatus,const char* pcCurrentTask,
								int *iNumFound,tag_t **foundTags);

//find Doc Items
extern int TIAUTO_find_Doc(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_Doc_Item (const char* pcItemID,const char* pcName,const char* pcObjType,const char* pcDescription,
								const char* pcReleasedByChange,const char* pcCustomerName,const char* pcCustomerReleaseNo,
								const char* pcOwningUser,const char* pcOwningGroup,const char* pcOwningSite,const char* pcLastModUser,
								const char* pcCreatedAfter,const char* pcCreatedBefore,const char* pcModifiedAfter,const char* pcModifiedBefore,const char* pcReleasedAfter,
								const char* pcReleasedBefore,const char* pcReleaseStatus,const char* pcCurrentTask,
								int *iNumFound,tag_t **foundTags);

//find Doc Item Revs
extern int TIAUTO_find_Doc_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/);

extern int find_Doc_Item_rev (const char* pcItemID,const char* pcRevID,const char* pcName,const char* pcObjType,const char* pcDescription,
								const char* pcReleasedByChange,const char* pcCustomerName,const char* pcCustomerReleaseNo,
								const char* pcOwningUser,const char* pcOwningGroup,const char* pcOwningSite,const char* pcLastModUser,
								const char* pcCreatedAfter,const char* pcCreatedBefore,const char* pcModifiedAfter,const char* pcModifiedBefore,const char* pcReleasedAfter,
								const char* pcReleasedBefore,const char* pcReleaseStatus,const char* pcCurrentTask,
								int *iNumFound,tag_t **foundTags);	


//findWorkSpaceObject

extern int TIAUTO_Find_WorkspaceObject(const char *pcname, int inumargs, char **pcnames, char **pcvalues,
                                              int *inum_found, tag_t **ptfound /*<OF num_found>*/);
extern int TIAUTO_Find_WorkspaceObjectQuery (const char* pcobjpuid,int *iNumFound,tag_t **ptfoundTags);



#endif /* ------ END OF FILE ------*/