/*Header for user query functions - Item Revision Any Part Number*/
#ifndef TIAUTO_ITEM_REV_PRT_NUM_H
#define TIAUTO_ITEM_REV_PRT_NUM_H

#include <tiauto_defines.h>
#include <tiauto_utils.h>

extern int IsPresentInAltId(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInAltIdName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInAltIdDescription(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetDescription(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetNamedRef(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartNum(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemId(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemRevDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartNum(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInIFSCATPart(const char* Keyword ,int *iNumTotalTags,TIA_UniqueWSOMObjects **UniqueObjects);
extern int IsPresentInAltId_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInAltIdName_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInAltIdDescription_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetName_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetDescription_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInDatasetNamedRef_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartNum_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartDesc_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInLegacyPartName_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemId_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemName_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemDesc_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInItemRevDesc_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartNum_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartDesc_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPurchSuppPartName_item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInIFSCATPart_item(const char* Keyword ,int *iNumTotalTags,TIA_UniqueWSOMObjects **UniqueObjects);
extern int IsPresentInPartnerSubmissionDocNum_Item(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerSubmissionPartNum_Item(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerSubmissionPartNum(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerSubmissionDocNum(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADFileName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADFileName_Item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADPartName_Item(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADPartNumber(const char* Keyword ,int *iNumFound,tag_t **foundTags);
extern int IsPresentInPartnerCADPartNumber_Item(const char* Keyword ,int *iNumFound,tag_t **foundTags);


/*function declarations for query "Item Any Prt Number"*/
#endif