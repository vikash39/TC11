#include <pie/aiws.h>
#include <tccore/custom.h>
#include <tccore/typecannedmethod.h>
#include <tc/tc_arguments.h>
#include <tccore/typecannedmethod_errors.h>
#include <tccore/item_msg.h>
#include <tccore/item.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <lov/lov.h>
#include <form/form.h>
#include <tc/preferences.h>

int t1aFamilyFormCreation( METHOD_message_t * msg, va_list args );
int t1aAUTO_register_canned_methods(int *decision, va_list args);

