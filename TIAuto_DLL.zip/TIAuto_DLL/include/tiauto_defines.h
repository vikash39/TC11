/*H*****************************************************************************
*
* FILENAME : tiauto_defines.h
*
* DESCRIPTION :
*       This file provides all the #defines for the implementation
*
* USEAGE :
*       When using any tiatuo custom #define, this file should be included.
*
*
* NOTES :
*
*
*
* CHANGES :
*	REF NO   DATE			WHO		DETAIL
*
*		07/06/2007		Srikanth P	Initial Creation - created new file from ti_custom_handlers.h
        12/17/2007      Arun M      Modifed for TIAUTO-check-deviation
*		01/27/2009		Garima D	Defined status( Study Approved) and Error message Structure
*		01/16/2009		Rajesh N	Added defines for TIAUTO-check-cro-items
*		02/02/2009		Rajesh N	Added lov.h
*		02/03/2009      Dipak Naik  Defined ALTREP_REV and an error code TIAUTO_VERIFY_RELATED_REVISIONS_ERROR
*		02/15/2009		Dipak Naik	Defined status "Cad Release Only"
*		03/17/2009		Dipak Naik  Defined OEM and ItemRevision Type
*		30 Apr 2009		Rajesh N	added ict_userservice.h
*		18/08/2009		Dipak Naik	added defines for arguments of "TIAUTO-validate-status-progression" handler
*		12/11/2009		Dipak Naik  added define for mail body for the handler "TIAUTO-AH-send-email-to-all"
*		13/06/2012		Mahesh BS	Added constants/constants.h and defined an error code TIAUTO_NOT_FILLED_REQUIRED_PROPERTY
*		14/06/2019		Jugunu      Defined constant for ER 9981. pdf,Adobe etc.
*       14/06/2019		Trisha      Defined Item revision Progression Error

*H*/

#ifndef tiauto_defines_h
#define tiauto_defines_h

/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
/*---- System and platform files ---------------------------------------------*/
#include <ae/ae.h>
#include <sa/am.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <epm/epm.h>
#include <pom/enq/enq.h>
#include <epm/epm_task_template_itk.h>
#include <user_exits/epm_toolkit_utils.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <tc/emh_errors.h>
#include <form/form.h>
#include <tccore/method.h>
#include <fclasses/tc_date.h>
#include <tccore/item_msg.h>
#include <tccore/item_errors.h>
#include <tc/emh_const.h>
#include <ecm/ecm_errors.h>
#include <ecm/ecm.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <ps/ps.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <qry/qry.h>
#include <itk/bmf.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <textsrv/textserver.h>
#include <tc/preferences.h>
#include <form/formtype.h>
#include <sa/user.h>
#include <lov/lov.h>
#include <ict/ict_userservice.h>
#include <tc/folder.h>
#include <property/propdesc.h>
#include <itk/mem.h>
#include <tc/aliaslist.h>
#include <epm/cr_action_handlers.h>
#include <epm/cr_errors.h>
#include <tc/distributionlist.h>
#include <tc/emh.h>
#include <unidefs.h>
#include <pom/pom/pom_errors.h>
#include <sa/sa.h>
#include <sa/sa_errors.h>
#include <ss/ss_errors.h>
#include <stdlib.h>
#include <string.h>
#include <tc/wsouif_errors.h>
#include <user_exits/user_exits.h>
#include <tc/tc_errors.h>
#include <tc/tc_util.h>
#include <sa/site_errors.h>
#include <objio/bier_errors.h>
#include <objio/objio.h>
#include <publication/idsm_errors.h>
#include <constants/constants.h>
#include <dispatcher/dispatcher_itk.h>
#include <dispatcher/libdispatcher_exports.h>
#include <dispatcher/dispatcher_errors.h>
#include <dispatcher/libdispatcher_undef.h>
#include <property/nr.h>
#include <res/res_itk.h>
#include <sa/tcfile_cache.h>
#include <sa/audit.h>
#include <epm/signoff.h>
#include <tccore/project.h>
//============================================================================
#define SAFE_MEM_free(x)\
  if(x != NULL)\
  MEM_free(x);               \
  x = NULL;

#define TIAUTO_ITKCALL(rc,f) {\
  char *msg = NULL;\
  (rc) = (f);\
  if ((rc) != ITK_ok) {\
    EMH_ask_error_text ((rc), &msg);\
    if (msg != NULL) {\
      if( DEBUG_PRINT ) {\
	  printf("ERROR[%d]: %s\n\t(file: %s, line:%d)\n", (rc), msg, __FILE__, __LINE__);\
	  TC_write_syslog("ERROR[%d]: %s\n\t(file: %s, line:%d)\n", (rc), msg, __FILE__, __LINE__);\
	  }\
      SAFE_MEM_free (msg);\
      msg=NULL;\
    }\
  }\
}

/* for Debug Print statements */
#define DEBUG_PRINT 1

#define TI_DEBUG_PRINT1(format,p1) {\
	if ( DEBUG_PRINT ) {\
	    fprintf (stderr, (format),(p1));\
	}\
}

#define TI_DEBUG_PRINT2(format,p1,p2) {\
	if ( DEBUG_PRINT ) {\
	    fprintf (stderr, (format),(p1),(p2));\
	}\
}

#define TI_DEBUG_PRINT3(format,p1,p2,p3) {\
	if ( DEBUG_PRINT ) {\
	    fprintf (stderr, (format),(p1),(p2),(p3));\
	}\
}

/* For reading arguments of "t1aAUTO_set_task_due_date" */
#define TIAUTO_ATTRIBUTE_NAME       "att_name"
#define TIAUTO_FORM_TYPE            "form_type"

/* For "t1aAUTO_allow_form_changese" */
#define TIAUTO_ALLOWED_FORMS        "allowed_forms"

#define TIAUTO_error_message_len    512

/* #defines for Check Target Object */
#define TIAUTO_ALLOWED_STATUS       "status_allow"
#define TIAUTO_LOV                  "lov"

/* #defines for Status Name */
#define     STUDY_APPROVED           "Study Approved"
#define		CRO						 "Cad Release Only"
#define     OBSOLETE                 "Obsolete"
#define     QUOTED					 "Quoted"
#define     AWARDED					 "Awarded"
#define     PROTOTYPE				 "Prototype"
#define     PRODUCTION_RELEASED      "Production Released"
#define     PRODUCTION_LAUNCHED      "Production Launched"
#define     TECHNOLOGY			     "Technology"

#define		APPROVE						"Approve"
#define		COMMENTS					"comments"
#define		REL_IMAN_SPEC				"IMAN_specification"
#define		ATTR_IS_PROD_IMPACTED		"t8_t1a190isproductimacted"
#define		OPTIN						"Opt In"
#define     PROCESS_STAGE               "process_stage"

#define		Rel_Change_ObjectRev			"IMAN_based_on"
#define		CAP_TARGET_REL_STS				"t8_t1a190targetreleasestate"
#define		PMR_TARGET_REL_STS				"t8_193targetreleasestate"

/* #defines for Check CRO items */
#define CHECK_CRO_LOV_ARG_NAME                  "lov"

/* Relation Type name for Changed Forms (History Relation) */
#define TIAUTO_HISTORY_FORM_REL_TYPE    "TI_FormHistory"

/* argument name of the "TIAUTO_RH_verify_status_progression_StackedCR" rule handler */
#define ARG_NAME_PROGRESSION_CHECK_RULE_HANDLER "skipCheck"

/* argument name of the "TIAUTO-validate-status-progression" rule handler */
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER1 "REPORT"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER2 "FAIL"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER3 "notification"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER4 "END_OF_WARNING_MESSAGE"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5 "target_release_status"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER6 "progression_checks_performed"
#define ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER7 "level"


/* argument value of the "TIAUTO-validate-status-progression" rule handler */
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1 "ERROR"
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2 "WARNING"
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3 "ERROR_NO_WARNING"
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4 "WARNING_NO_ERROR"
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5 "ERROR_OR_WARNING"
#define ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6 "ERROR_AND_WARNING"

/* argument value of the "TIAUTO-check-checkedout-remote-objects" rule handler */
#define ARG_NAME_REMOTE_AND_CHECK_CHECKEDOUT_HANDLER "folder"


#define MISSING_ITEMS_FOLDER "Item Revisions - To be added"
#define DATA_REMOVAL_FOLDER "Item Revisions - To be removed"
#define MASTER_DRAWING_FOLDER "Item Revisions - Update Master Drawing Attributes"

/*TIAUTO_RH_verify_designwork_required rule hanlder*/
#define TIAUTO_ERROR_MSG		"error_message"
#define	TIAUTO_TI_ECR			"T8_TI_ECR"
#define	ATTR_DESIGN_WORK		"t8_t1a133designworkrequired"
#define	VALUE_YES				"Yes"
#define	TIAUTO_OPTOUT			"Opt Out"
/*TIAUTO_RH_verify_designwork_required rule hanlder*/

#define TIAUTO_ITEMREVISION		"ItemRevision"
#define TIAUTO_FORM				"Form"
#define TIAUTO_TI_DOCUMENTREVISION	"TI_Document_0_Revision_alt0"
#define	TIAUTO_TI_DOCUMENT			"TI_Document"
#define	TIAUTO_ITEM				"Item"
#define	TIAUTO_PROCESS_STAGE_LIST	"process_stage_list"
		

typedef struct errMessage
{
	char   errMsg[TIAUTO_error_message_len + 1];
	int    iRetCode;
	struct errMessage * next;
}TIA_ErrorMessage;

//
typedef struct taskNamesPerUser
{
	tag_t tUniqueUser;
	char allTasks[2048];
	struct taskNamesPerUser *next;
}TIA_TaskNamesAssignedPerUser;

typedef struct taskNamesPerUserSupplier
{
	tag_t tUniqueUser;
	char allTasks[1024];
	struct taskNamesPerUserSupplier *next;
}TIA_TaskNamesAssignedPerSupplier;

//for notify stacked wait user
typedef struct waitTaskDetail
{
	tag_t tWaitTask;
	char acWaitStackedChangeRev[256];
	char acWaitTaskName[256];
	struct waitTaskDetail *next;
}TIA_WaitTaskDetails;

typedef struct stackedTask
{
	tag_t tTask;
	char acChangeRev[256];
	char acWaitTaskName[256];
	char acStackedItemRev[2048];
	struct stackedTask *next;
}TIA_StackedTask;

typedef struct UniqueWSOMObjects
{
	tag_t tUniqueWSOMObjects;
	struct UniqueWSOMObjects *next;
}TIA_UniqueWSOMObjects;

typedef struct ChangeAttrs
{
	char   acChangeAttrs[2048];
	struct ChangeAttrs *next;
}TIA_ChangeAttrs;

/* Custom Error Codes for Check document Handler */
#define     TIAUTO_CHECK_DOCUMENT_NO_OF_ARGS_ERROR              (EMH_USER_error_base + 11)
#define     TIAUTO_CHECK_DOCUMENT_NO_ENG_CHANGE_REV_ERROR       (EMH_USER_error_base + 12)
#define     TIAUTO_CHECK_DOCUMENT_NO_AFFECTED_ITEMS_ERROR       (EMH_USER_error_base + 13)
#define     TIAUTO_CHECK_DOCUMENT_NO_SPEC_ERROR                 (EMH_USER_error_base + 14)
#define     TIAUTO_CHECK_DOCUMENT_NO_ATTRIBUTE_ERROR            (EMH_USER_error_base + 15)
#define     TIAUTO_CHECK_DOCUMENT_INVALID_DOCUMENT_ERROR        (EMH_USER_error_base + 16)
#define     TIAUTO_CHECK_DOCUMENT_NO_FORM_ERROR                 (EMH_USER_error_base + 17)

/* Custom Error Codes for Item Rev Progression Checks  */
#define     TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS                (EMH_USER_error_base + 100)
#define     TIAUTO_IMPRECISE_BVR_FOUND                          (EMH_USER_error_base + 101)
#define     TIAUTO_COMPONENT_INVALID_STATUS                     (EMH_USER_error_base + 102)
#define     TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE  (EMH_USER_error_base + 103)
#define     TIAUTO_PROGRESSION_PATH_NOT_FOUND                   (EMH_USER_error_base + 104)
#define     TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER                   (EMH_USER_error_base + 105)
#define     TIAUTO_CHILD_PART_INVALID_STATUS                    (EMH_USER_error_base + 106)
#define     TIAUTO_PARTREV_INVALID_STATUS                       (EMH_USER_error_base + 107)
#define     TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR          (EMH_USER_error_base + 108)
#define     TIAUTO_GENREICREV_PROGRESSING_ERROR			(EMH_USER_error_base + 109)
#define     TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR      (EMH_USER_error_base + 110)
#define     TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR      (EMH_USER_error_base + 111)
#define     TIAUTO_ADVANCE_TECHNOLOGY_ITEM_INCORRECT_STATUS_ERROR (EMH_USER_error_base + 277)
#define		TIAUTO_DOCUMENTREV_PROGRESSING_ERROR			(EMH_USER_error_base + 121)		
#define     TIAUTO_PARTREV_EQUAL_STATUS                       (EMH_USER_error_base + 281)
/*Custom Error Code for Master drawing information Check on Product Revisions */
#define		TIAUTO_MASTER_DRAWING_ATTRIBUTES_NOT_FOUND		(EMH_USER_error_base + 122)	

/*Custom Error Code for Master Drawing Reference linked object status Check on Product Revisions */
#define		TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS		(EMH_USER_error_base + 123)	

//For quick Progression Check
#define TIAUTO_QUICKPROGRESSION_ERROR   (EMH_USER_error_base + 112)
#define TIAUTO_QUICKPROGRESSION_BACKWARD_ERROR   (EMH_USER_error_base + 113)
#define TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR  (EMH_USER_error_base + 114)
#define TIAUTO_QUICKPROGRESSION_GENERIC_ERROR   (EMH_USER_error_base + 115)
#define TIAUTO_QUICKPROGRESSION_GENERIC_WARNING  (EMH_USER_error_base + 116)
#define TIAUTO_QUICKPROGRESSION_ASSEMBLY_ERROR   (EMH_USER_error_base + 117)
#define TIAUTO_QUICKPROGRESSION_ASSEMBLY_WARNING  (EMH_USER_error_base + 118 )
#define TIAUTO_QUICKPROGRESSION_RELATEED_REV_ERROR  (EMH_USER_error_base + 253 )
#define TIAUTO_QUICKPROGRESSION_RELATED_REV_WARNING  (EMH_USER_error_base + 260 )

//Backward Progression 6085 case errors
#define TIAUTO_FOUND_IN_AFFECTED (EMH_USER_error_base + 119)
#define TIAUTO_NOT_FOUND_IN_AFFECTED (EMH_USER_error_base + 120)

/* Custom Error Codes for Setting Task Due dates Handler  */
#define     TIAUTO_FORM_DATE_ATTRIBUTE_READ_ERROR               (EMH_USER_error_base + 200)

/* Custom Error Codes for Checking Target Object Status Handler  */
#define     TIAUTO_SPECIFIED_LOV_NOT_FOUND                      (EMH_USER_error_base + 210)
#define     TIAUTO_CHANGE_ITEM_REV_INVALID_STATUS               (EMH_USER_error_base + 211)
#define     TIAUTO_ITEM_REV_INVALID_STATUS                      (EMH_USER_error_base + 212)
#define     TIAUTO_CHANGE_REV_NOT_FOUND                         (EMH_USER_error_base + 213)

/* Custom Error Codes for Add Detailed Instructions form Handler  */
#define     TIAUTO_DETAIL_INSTRUCTIONS_QRY_NOT_FOUND            (EMH_USER_error_base + 220)
#define     TIAUTO_DETAIL_INSTRUCTIONS_NOT_FOUND                (EMH_USER_error_base + 221)

/* Custom Error Codes for Deviation check Handler  */
#define     TIAUTO_HANDLER_VALIDATION_ERROR                     (EMH_USER_error_base + 230)

/* Custom Error Codes for Generic status check Handler  */
#define     TIAUTO_STATUS__CHECK_ERROR                     (EMH_USER_error_base + 231)
#define     TIAUTO_INSTANCE__CHECK_ERROR                     (EMH_USER_error_base + 232)

/* Custom Error Codes for check checked out and remote objects handler */
#define     TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR          (EMH_USER_error_base + 233)

/* Custom Error Codes for Check CRO items */
#define     TIAUTO_CHECK_CRO_ITEMS_ERROR				  (EMH_USER_error_base + 234)

/* Custom Error Codes for verify related revisions handler */
#define     TIAUTO_VERIFY_RELATED_REVISIONS_ERROR          (EMH_USER_error_base + 235)
#define     TIAUTO_VERIFY_RELATED_REVISIONS_WARNING         (EMH_USER_error_base + 236)

/* Custom Error Codes for quick progression check handler */
#define     TIAUTO_TARGETSTATUS_FORM_NOT_FOUND			          (EMH_USER_error_base + 240)
#define     TIAUTO_TARGETSTATUS_FORM_NO_TARGET_REL_STATUS          (EMH_USER_error_base + 241)

//Custom Error Codes for check for based on condition rule handler
#define     TIAUTO_NOT_VALID_TARGET_CHANGE_REV          (EMH_USER_error_base + 242)

/* Custom Error Codes for blank eng change revision check handler */
#define     TIAUTO_BLANK_CHANGE          (EMH_USER_error_base + 245)

/*Custom Error message for invalid query in based on check for workflow*/
#define    TIAUTO_NOT_VALID_QUERY         (EMH_USER_error_base + 246)

#define    TIAUTO_NOT_VALID_COND_OPTION         (EMH_USER_error_base + 247)

#define    TIAUTO_ASSIGNMENT_LIST_NOT_APPLIED         (EMH_USER_error_base + 248)
/*to make quantity non editable*/
#define     TIAUTO_QUANTITY_NON_EDITABLE        (EMH_USER_error_base + 249)
/*Custom Error Codes to get delimiter from preferences*/
#define     TIAUTO_DELIMITER_NOT_FOUND   (EMH_USER_error_base + 250)

#define     TIAUTO_CHECKEDOUT_ERROR          (EMH_USER_error_base + 251)
#define     TIAUTO_REMOTE_ERROR          (EMH_USER_error_base + 252)
/* Custom Error Codes for not selecting affected program in Find Changes by Affected Programs query*/
#define     TIAUTO_NOT_VALID_AFFECTED_PROGRAM	(EMH_USER_error_base + 254)
/* Custom Error Codes for not filled required peoperty in Item Revision Master form*/
#define     TIAUTO_NOT_FILLED_REQUIRED_PROPERTY	(EMH_USER_error_base + 255)
/* Custom Error Codes for specific object type not present in the targets*/
#define     TIAUTO_OBJECT_NOT_FOUND_IN_TARGET	(EMH_USER_error_base + 256)

/* Custom Error Codes for TIAUTO-RH-verify-product-impact handler*/
#define     TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR   (EMH_USER_error_base + 257)

#define     TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED   (EMH_USER_error_base + 258)
#define     TIAUTO_MRA_M2M_RELATION_CREATION_ERROR   (EMH_USER_error_base + 259)
//
#define     TIAUTO_CAE_REPORT_CREATION_PROCESS_NOT_COMPLETED   (EMH_USER_error_base + 260)

#define     TIAUTO_NOT_VALID_SAME_STATE   (EMH_USER_error_base + 261)
#define     TIAUTO_INVALID_DOCUMENT_OWNING_GROUP   (EMH_USER_error_base + 262)
#define     TIAUTO_INVALID_DOCUMENT_TYPE   (EMH_USER_error_base + 263)
#define     TIAUTO_INVALID_RFQ_ATTRIBUTE_VALUE   (EMH_USER_error_base + 264)
#define     TIAUTO_INVALID_SOP_ATTRIBUTE_VALUE   (EMH_USER_error_base + 265)
#define     TIAUTO_NOT_IN_BASEDON_CHANGE_REV   (EMH_USER_error_base + 266)
#define     TIAUTO_INVALID_MISMATCH_SOP_AND_PLANT_ATTRIBUTE_VALUE   (EMH_USER_error_base + 267)
#define     TIAUTO_INCORRECT_PLANT_ATTRIBUTE_VALUE   (EMH_USER_error_base + 268)
#define		TIAUTO_PLANT_ATTRIBUTE_VALUE_MISMATCH   (EMH_USER_error_base + 269)
#define		TIAUTO_NOT_ALLOWED_TO_COMPLETE_TASK   (EMH_USER_error_base + 270)
#define		TIAUTO_NOT_ALLOWED_TYPE   (EMH_USER_error_base + 271)

#define		TIAUTO_NOT_VALID_ECR_OPTION   (EMH_USER_error_base + 272)
#define		TIAUTO_ITEMS_NOT_IN_PROJ	  (EMH_USER_error_base + 273)
#define		TIAUTO_ACD_CREATION_PROCESS_NOT_COMPLETED		(EMH_USER_error_base + 274)	
#define		TIAUTO_COSTFORM_NOT_IN_PROJ				(EMH_USER_error_base + 275)
/* Custom Error Codes for TIAUTO-RH-verify-release-status-for-pci*/
#define		TIAUTO_PCI_INITIATION_PROCESS_NOT_ALLOWED				(EMH_USER_error_base + 276)

#define     TIAUTO_PRA_M2M_RELATION_CREATION_ERROR   (EMH_USER_error_base + 278)
#define     TIAUTO_PRA_CREATION_PROCESS_NOT_COMPLETED   (EMH_USER_error_base + 279)

#define		TIAUTO_ITEMS_IN_PROJ	  (EMH_USER_error_base + 280)

//Error Text
//---------------Assembly Progression Error----------------------------
#define TIAUTO_IMPRECISE_BVR_FOUND_TEXT "Part does not have precise BOM. So it is invalid BOM."
#define TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1 "The OEM component"
#define TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2 "of assembly"
#define TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3 "is not at a valid status(CRO). Please status the part with CRO workflow."
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1 "The component"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2 "of assembly"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4 "and is currently in another change process"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5 ". Please ensure that the process"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6 "which will status the component to"
#define TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7 "is completed"
#define TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1 "The component"
#define TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2 "of assembly"
#define TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4 "and is not a part of current change process. Please add the component to current change folder."
#define TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5 "and belongs to the site"
#define TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1         "The child component"
#define TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2   "has an obsolete status which is not valid for use inside an assembly to be released. Please replace the obsolete component with a component that has a valid status."
#define TIAUTO_ADVANCE_TECHNOLOGY_ITEM_INCORRECT_STATUS_TEXT2   "has Technology Released/Technology Prototype status which is not valid for use inside an assembly to be released. Please replace the Advance Technology component with a component that has a valid status."

//---------------Generic Progression Error----------------------------
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1 "The generic"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2 "of instance"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4 "and is currently in another change process"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5 ". Please ensure that the process"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6 "which will status the generic to"
#define TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7 "is completed"
#define TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1 "The generic"
#define TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2 "of instance"
#define TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4 "and is not a part of current change process. Please add the generic to current change folder."


#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1 "The document"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2 "of configuration"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4 "and is currently in another change process"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5 ". Please ensure that the process"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6 "which will status the document to"
#define TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7 "is completed"
#define TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1 "The doument"
#define TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2 "of configuration"
#define TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3 "is at lower status than the current targeted release state"
#define TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4 "and is not a part of current change process. Please add the document to current change folder."

//---------------Item revision Progression Error----------------------------
#define TIAUTO_PARTREV_INVALID_STATUS_TEXT1 "is at higher status than the current targeted release state"
#define TIAUTO_PARTREV_INVALID_STATUS_TEXT2 ". Please remove it from current change folder."
#define TIAUTO_PARTREV_EQUAL_STATUS_TEXT1 "is at same status as of current targeted release state"
#define TIAUTO_PARTREV_EQUAL_STATUS_TEXT2 ". Please remove it from current change folder."
//---------------Backward Progression Error----------------------------
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1 "has a later revision"
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2 "with same or higher status than the current targeted release state"
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3 "."
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4 "Use"
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5 "instead of"
#define TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6 "in the BOM."

//---------------Master Drawing Attributes Item Warning------------------------
#define TIAUTO_MASTER_DRAWING_ATTRIBUTES_WARNING_TEXT "Master Drawing information is missing on the product revision master form of "

#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT1 "Master Drawing revision"
#define	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT2 "of the"
#define	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT3 "has WIP status"
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT4 "and is currently in another change process"
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT5 ". Please ensure that the process"
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT6 "which will status the component to"
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT7 "is completed"
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT8 "is at lower status than the current targeted release state"

//---------------Master Drawing Reference linked object status check Error------------------------
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1 "Master Drawing revision "
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 "of the "
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT3 "has WIP status. "
#define TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT4 "is at lower status than the current targeted release state "

//---------------Body of Email----------------------------
#define TIAUTO_BODY_OF_EMAIL_TEXT1 "There are progression warnings at step"
#define TIAUTO_BODY_OF_EMAIL_TEXT2 ". However the current change process will be allowed to proceed till task"
#define TIAUTO_BODY_OF_EMAIL_TEXT3 "as these warnings may be corrected by the respective stacked changes."
//adding CAP3 changes
#define TIAUTO_BODY_OF_EMAIL_TASK_CR  "2_481 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS "10_193 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS1 "13_150 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_DAP "6_210 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_CRO "9_60 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_PMR "14_30 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_CAP "15_230 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP "19_400 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP "28_400 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_TPR "23_180 No Stacked Change?"
#define TIAUTO_BODY_OF_EMAIL_TASK_TER "25_100 No Stacked Change?"

#define TIAUTO_BODY_OF_EMAIL_TEXT4  "It is recommended to actively co-ordinate with the owners of those changes."

#define TIAUTO_BODY_OF_EMAIL_TEXT5 ". The current change process will not be allowed to proceed further till "\
									"the stacked changes are complete."

#define TIAUTO_BODY_OF_EMAIL_TEXT6 "If these warnings persist, the current change process can not move beyond task"
//---------------End of Body of Email----------------------------

#define TIAUTO_COMPONENT_INVALID_STATUS_TEXT "is already at SAME or GREATER status w.r.t current target release status:"

#define TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT  \
	        "The target Release Status is not found in the site Preference \"TI_Progression_Path\"."\
			"Please update the site preference value."

//---------------Body of Email after assigning the assignment list----------------------------
#define TIAUTO_ASSIGNMENT_EMAIL_TEXT1 "You have been assigned to perform tasks in PLM for Change #"
#define TIAUTO_ASSIGNMENT_EMAIL_TEXT2 ". The specific tasks assigned to you are -"

#define TIAUTO_ASSIGNMENT_EMAIL_TEXT3 "You can expect that these tasks will arrive in your worklist in the near future. "\
									  "You are encouraged to log into PLM immediately to review this change and"\
									  " commence preparations for the tasks that you have been assigned to."

//---------------End of Body of Email after assigning the assignment list----------------------------


#define     INCORRECT_ARGS_MSG         "Incorrect no of arguments to the handler."
#define     CHANGE_REV                 "EngChange Revision"
#define     NEWCHANGE_REV              "T8_TI_ChangeRevision"
#define     DOCUMENT_REV               "TI_Document Revision"
#define     PROGRESSION_PATH           "TI_Progression_Path"
#define     OEM_REV                    "_OEM Revision"
#define     ITEM_REV                   "ItemRevision"
#define     ALTREP_REV				   "TI_AltRep Revision"
#define     FOLDER                     "Folder"
#define     DELIMITER_PREF             "WSOM_find_list_separator"
#define     ALTTOOL_REV				   "TI_AltTool Revision"
#define     ALTCONSTRUCT_REV           "T8_TI_AltConstr Revision"

/* #defines for Form types */
#define     CCR_FORM                        "TI_CCR"
#define     ECR_FORM                        "TI_ECR"
#define     TI_DETAILED_INSTRUCTIONS_FORM   "TI_DetailedInstructions"

/* #defines for Form Attributes */
#define     TARGET_REL_STATE           "t1a40targetreleasestate"

#define		TI_ERP_INTEGRATION_USER		"erpintegration"
/* #defines for Queries */
#define     TIAUTO_DETAILED_INSTRUCTIONS_QRY_NAME               "__t1a_Get_Detailed_Instructions"

#define Rel_Change_ObjectRev		"IMAN_based_on"
#define PROP_All_Workflows			"fnd0AllWorkflows"
#define PROP_Task_name				"fnd0AliasTaskName"
#define VAL_Workflow_Process_name	"CAP - Change Approval Process"
#define	COMMENTS "comments"
#define NEWCCR_FORM		"T8_TI_CCR2"
#define	APPROVE "Approve"
#define REL_IMAN_SPEC "IMAN_specification"
#define	ATTR_IS_PROD_IMPACTED	"t8_t1a190isproductimacted"

#define	EPM_Review_Task				"EPMReviewTask"
#define	EPM_Task					"EPMTask"
#define	EPM_Perform_Signoff_Task	"EPMPerformSignoffTask"
#define	EPM_Condition_Task			"EPMConditionTask"

#define	TIAUTO_Find_Obj_BasedOn_UID	"Find Objects Based On UIDs"
#define	TIAUTO_PUID						"UID"
#define	TIAUTO_WORKSPACE_OBJECT_ENQ		"find_WorkSpaceObject"

/*Defines for user queries Doc and OEM*/
#define     IMAN_MASTER_FORM           	"IMAN_master_form"
#define     TI_DOCUMENT           		"TI_Document"
#define     T1A47DOCREVREVMASTER        "t1a47DocRevMaster"
#define     T1A47RELEASEDBYCHANGE       "t1a47releasedbychange"
#define     T1A47CUSTOMERNAME           "t1a47customername"
#define     T1A47CUSTOMERRELEASENO      "t1a47customerreleaseno"
#define     LOCAL					  	"Local"
#define     _OEM           			   "_OEM"
#define     T1A2OEMREVMASTER           "t1a2OEMRevMaster"
#define     T1A2PROGRAMARRAY           "t1a2programarray"
#define     T1A2LAUNCHMODELYEAR        "t1a2launchmodelyear"
#define     T1A2RELEASEDBYCHANGE       "t1a2releasedbychange"
#define     T1A2CUSTOMERNAME           "t1a2customername"
#define     T1A2CUSTOMERRELEASENO      "t1a2customerreleaseno"
#define		TIAUTO_PROJ_LIST			"projects_list"
#define		TIAUTO_PROJ_ID				"Adv_Group-Adv Group"
#define		TIAUTO_COMMA				","
#define		TIAUTO_ITEM_ID				"item_id"
#define		TIAUTO_REV_ID				"item_revision_id"
#define		TIAUTO_FRONT_SLASH			"/"
#define		TIAUTO_TECH_REL_STATUS		"T8_Technology Released"
#define		TIAUTO_TPR_APPROVED			"T8_TPR Approved"
#define		TIAUTO_TER_APPROVED			"T8_TER Approved"
#define		TIAUTO_TI_TPR				"T8_TI_TPR"
#define		TIAUTO_TI_TER				"T8_TI_TER"
#define		TIAUTO_TPR_TAR_REL_STATE	"t8_t1a201targetreleasestate"
#define		TIAUTO_TER_TAR_REL_STATe	"t8_t1a205targetreleasestate"
#define		TI_FORM						"Form"
#define		TIAUTO_HYPHEN				"-"
#define		TIAUTO_SUMM_IMAG_REL		"T8_CMTISummaryImages"
#define		TIAUTO_OBJECT_TYPE			"object_type"
#define		TIAUTO_TPR_TAR_REL_STATE	"t8_t1a201targetreleasestate"
#define		TIAUTO_TER_TAR_REL_STATE	"t8_t1a205targetreleasestate"
#define		TIAUTO_TECH_REL				"Technology Released"
#define		TIAUTO_IMAN_SPEC_REL		"IMAN_specification"
#define		TIAUTO_COST_FORM_REL		"TI_CostForms"
#define		TIAUTO_ADV_CHANGE_REV		"T8_T_AdvChangeRevision"
#define		TIAUTO_OBJECT_NAME			"object_name"
#define		TIAUTO_MSWORDX				"MSWordX"
#define		TIAUTO_REL_RENDERING		"IMAN_Rendering"
#define		TIAUTO_REL_DRAWING		    "IMAN_Drawing"
#define		TIAUTO_UGPART			    "UGPART"
#define		TIAUTO_UGMASTER			    "UGMASTER"
#define		TIAUTO_ADOBE			    "AdobeAcrobat"
#define		TIAUTO_PDF			        "PDF"
#define     TIAUTO_REL_DocProd          "TI_DocProdRevisions"
#define     TIAUTO_CATIA                "catia"
#define     TIAUTO_CATPART              "CATPart"
#define     TIAUTO_CATPRODUCT           "CATProduct"
#define     TIAUTO_IDEASPART            "IdeasPart"
#define     TIAUTO_IDEASASSEBMLY        "IdeasAssembly"
#define     TIAUTO_PROPRT               "ProPrt"
#define     TIAUTO_PROASM               "ProAsm"
#define     TIAUTO_SWPRT                "SWPrt"
#define     TIAUTO_SWASM                "SWAsm" 
#define     TIAUTO_AIPART               "AIPart" 
#define     TIAUTO_AIASSEMBLY           "AIAssembly"
#define     TIAUTO_ACADDWG              "ACADDWG"
#define     TIAUTO_AIDRAWING            "AIDrawing"
#define     TIAUTO_CATDRAWING           "CATDrawing"
#define     TIAUTO_IDEASDRW             "IdeasDrawing"
#define     TIAUTO_PRODRW               "ProDrw"
#define     TIAUTO_UGPART               "UGPART"
#define     TIAUTO_CATIA2D              "catia2D"
#define     TIAUTO_SWDRW                "SWDrw"
#define     TIAUTO_DWG                  "DWG"
#define     TIAUTO_DXF                  "DXF"
#define     TIAUTO_CADKEY               "CADKEY"





#endif /* tiauto_defines.h ------ END OF FILE ------*/
