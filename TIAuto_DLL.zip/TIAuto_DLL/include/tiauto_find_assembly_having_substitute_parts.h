/*Header for user query functions - find_partner_submission_documents*/

#include <tiauto_defines.h>
#include <tiauto_utils.h>



/*function declarations for query "find_partner_submission_documents"*/
