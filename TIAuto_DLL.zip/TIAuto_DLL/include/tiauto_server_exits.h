/*H*****************************************************************************
*
* FILENAME : tiauto_server_exits.h
*
* DESCRIPTION :
*       This file provides the required header files for all server exits
*
* USEAGE :
*       When using functions from tiauto_server-exits.c this file should be #included.
*
*
* NOTES :
*
Revision History :
Date            Revision    Who              Description
June 01, 2010    1.0        Dipak Naik		 Initial Creation

*H*/

#ifndef TIAUTO_SERVER_EXITS_H
#define TIAUTO_SERVER_EXITS_H

#include <stdarg.h>
/*******************************************************************************
* Server Exits
*******************************************************************************/

int t1aAUTO_register_server_exits (int *decision, va_list args );

extern int TAUTO_check_blank_change(void *return_value /*<O>*/);
extern int TAUTO_AssignmentList_info_to_Audit(void *return_value);
extern int TAUTO_Create_Data_Migration_Item(void *return_value);
extern int TAUTO_Add_Rev_Status_to_Secondary(void *return_value);
extern int TAUTO_ERP_Change_Attribute_Value(void *return_value);
extern int TAUTO_Create_Item(void *return_value);
extern int TAUTO_set_status_on_object(void *return_value);
extern int TAUTO_clear_signoff_attachments(void *return_value);
extern int TIAUTO_get_approval_report_data(void *return_value);

#endif /* tiauto_server_exits.h ------ END OF FILE ------*/
