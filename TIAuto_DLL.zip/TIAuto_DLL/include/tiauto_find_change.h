/*Header for user query functions - find_partner_submission_documents*/
#ifndef TIAUTO_ITEM_REV_PRT_NUM_H
#define TIAUTO_ITEM_REV_PRT_NUM_H

#include <tiauto_defines.h>
#include <tiauto_utils.h>


/*function declarations for query "find_partner_submission_documents"*/
#endif