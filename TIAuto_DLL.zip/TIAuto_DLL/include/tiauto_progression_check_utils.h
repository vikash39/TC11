
#ifndef TIAUTO_PROGRESSION_CHECK_UTILS_H
#define TIAUTO_PROGRESSION_CHECK_UTILS_H

#include <stdlib.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>

int copyErrorItemsToFolder(tag_t tFolder, char* folderName, TIA_UniqueWSOMObjects *errorList);

extern int ti_check_for_item_revision_progression( tag_t _tItem,
												   STATUS_Struct_t _StatusProgression,
												   TARGET_RELEASE_Struct_t _TargetReleaseStatus,
													int _iPopulateErrMsgInStack,
													int *iError_, 
													TIA_ErrorMessage **errMsgStack_, ... );


extern int ti_check_for_backward_progression ( tag_t _tItemRev,
												tag_t *ptAffectedItems, int iNumAffected,
												STATUS_Struct_t _StatusProgression,
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
												int _iPopulateErrMsgInStack,
												int *iError_, 
												TIA_ErrorMessage **errMsgStack_,... );


extern int ti_check_for_assembly_progression( tag_t _tItemRev, 
												tag_t *_ptAffectedItems,
												int _iNumAffectedItems,
												STATUS_Struct_t _StatusProgression, 
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
												char	*pcEndOfWarningMsg,
												int _iPopulateWarningMsgInStack,
												int _iPopulateErrMsgInStack,
												char	*pcRootTaskName,
												int		iLevel,
												int *iError_, 
												TIA_ErrorMessage **warningMsgStack_,
												TIA_ErrorMessage **errMsgStack_,...); 

extern int ti_check_for_assembly_progression_pci( tag_t _tItemRev, 
												tag_t *_ptAffectedItems,
												int _iNumAffectedItems,
												STATUS_Struct_t _StatusProgression, 
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
												char	*pcEndOfWarningMsg,
												int _iPopulateWarningMsgInStack,
												int _iPopulateErrMsgInStack,
												char	*pcRootTaskName,
												int		iLevel,
												int *iError_, 
												TIA_ErrorMessage **warningMsgStack_,
												TIA_ErrorMessage **errMsgStack_,...); 

extern int ti_check_for_generic_progression( tag_t _tItemRev, 
												tag_t *_ptAffectedItems,
												int _iNumAffectedItems,
												STATUS_Struct_t _StatusProgression, 
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
												char	*pcEndOfWarningMsg,
												int _iPopulateWarningMsgInStack,
												int _iPopulateErrMsgInStack,
												char	*pcRootTaskName,
												int *iError_, 
												TIA_ErrorMessage **warningMsgStack_,
												TIA_ErrorMessage **errMsgStack_ ,...);

extern int ti_check_for_generic_progression_pci( tag_t _tItemRev, 
												tag_t *_ptAffectedItems,
												int _iNumAffectedItems,
												STATUS_Struct_t _StatusProgression, 
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
												char	*pcEndOfWarningMsg,
												int _iPopulateWarningMsgInStack,
												int _iPopulateErrMsgInStack,
												char	*pcRootTaskName,
												int *iError_, 
												TIA_ErrorMessage **warningMsgStack_,
												TIA_ErrorMessage **errMsgStack_ ,...);

extern void ti_writeErrorsMsgToAuditFile(tag_t tMsgTask, TIA_ErrorMessage *backwordProgErrMsgStack,
											TIA_ErrorMessage *itemRevProgErrMsgStack,
											TIA_ErrorMessage *assemblyProgErrMsgStack,
											TIA_ErrorMessage *genericProgErrMsgStack,
											TIA_ErrorMessage *assemblyProgWarningMsgStack,
											TIA_ErrorMessage *genericProgWarningMsgStack,
											TIA_ErrorMessage *masterDrawingReferenceObjectWarningMsgStack,
											TIA_ErrorMessage *masterDrawingReferenceObjectErrMsgStack);

extern void ti_writeSuccessMsgToAuditFile(tag_t tMsgTask);

void IsExistInAffectedFolder( tag_t tInput, tag_t* ptArray, int iNum, int *iFound );

extern int check_status_of_Alternates(		tag_t						_tParentBVR,
											tag_t						_tOccurrence,
											tag_t						_tPreferredChild,
											char						*szItemRevInChangeId,
											tag_t						*_ptAffectedItems,
											int							_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression, 
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											char						*pcEndOfWarningMsg,
											int							_iPopulateWarningMsgInStack,
											int							_iPopulateErrMsgInStack,
											char						*pcRootTaskName,
											int							iLevel, 
											int							*iError_,
											TIA_ErrorMessage			**warningMsgStack_,
											TIA_ErrorMessage			**errMsgStack_,...);

extern int check_status_of_Alternates_pci(		tag_t						_tParentBVR,
											tag_t						_tOccurrence,
											tag_t						_tPreferredChild,
											char						*szItemRevInChangeId,
											tag_t						*_ptAffectedItems,
											int							_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression, 
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											char						*pcEndOfWarningMsg,
											int							_iPopulateWarningMsgInStack,
											int							_iPopulateErrMsgInStack,
											char						*pcRootTaskName,
											int							iLevel, 
											int							*iError_,
											TIA_ErrorMessage			**warningMsgStack_,
											TIA_ErrorMessage			**errMsgStack_,...);


int ti_where_used_in_BOM(	tag_t			tErrorItem,
						tag_t			*_ptAffectedItems,
						int				_iNumAffectedItems,
						char			*szItemRevs,
						TIA_ErrorItems  **sBOMItemRevs);

extern int ti_Verify_MasterDrawingInfo( 	tag_t					_tItemRev,
											tag_t					*_ptAffectedItems,
											int						_iNumAffectedItems,
												STATUS_Struct_t _StatusProgression, 
												TARGET_RELEASE_Struct_t _TargetReleaseStatus,
											int						_iPopulateErrMsgInStack,
											int						*iError_,
											TIA_ErrorMessage		**warningMsgStack_,
											TIA_ErrorMessage		**errMsgStack_, ...) ;

extern int ti_Verify_MasterDrawingReferenceLinkedObjectStatus (	tag_t						_tItemRev,
																tag_t						*_ptAffectedItems,
																int							_iNumAffectedItems,
																STATUS_Struct_t				_StatusProgression,
																TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
																int                         _iPopulateWarningMsgInStack,
																int							_iPopulateErrMsgInStack,
																int							*iError_,
																TIA_ErrorMessage			**warningMsgStack_,
																TIA_ErrorMessage			**errMsgStack_,
																char						*pcEndOfWarningMsg,... );


extern int ti_Verify_MasterDrawingReferenceLinkedObjectStatus_pci (	tag_t						_tItemRev,
																tag_t						*_ptAffectedItems,
																int							_iNumAffectedItems,
																STATUS_Struct_t				_StatusProgression,
																TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
																int							_iPopulateErrMsgInStack,
																int							*iError_, 
																TIA_ErrorMessage			**errMsgStack_, ... );


#endif //END OF TIAUTO_PROGRESSION_CHECK_UTILS_H

