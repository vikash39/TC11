/*H*****************************************************************************
*
* FILENAME : tiauto_custom_handlers.h
*
* DESCRIPTION :
*       This file provides the required header files and compilation
*
* USEAGE :
*       When using functions from tiauto_custom_handlers.c this file should be #included.
*
*
* NOTES :
*
*
*
* CHANGES :
*	REF NO   DATE			WHO		DETAIL
*              
*		04/20/2007		Srikanth P	Initial Creation
*       06/07/2007      Srikanth P  Merged with Rajesh code - t1aAUTO_check_document
        12/17/2007      Arun M      Added t1aAUTO_deviation_effectivity.
		02/19/2008      Arun M      Added demote email
		01/02/2009		Rajesh N	Added t1aAUTO_check_checkedout_remote_objects method
*       01/13/2009      Garima D    Modified for t1aAUTO_check_assembly_progression
		01/02/2009		Rajesh N	Added t1aAUTO_check_checkedout_remote_objects method
*		02/03/2009		Dipak Naik	Added t1aAUTO_verify_related_revisions.
*		28/04/2009		Dipak Naik	registered t1aAUTO_verify_status_progression_in_parallel_crProcess handler 
*		30/07/2009		Rajesh N	changed the progression check handler method name
*		10/09/2009		Dipak Naik	Added the TIAUTO_RH_verify_status_progression_quick
*		12/11/2009		Dipak Naik	Added the t1aAUTO_send_email_toAll method
        10/02/2010      Nivedita    Registered TIAUTO-AH-block-sol-relation action handler
*                                   and TIAUTO-AH-block-aff-relation
*		15/02/2010		Rajesh N	Registered TIAUTO-AH-check-non-doc-status action handler
*       18/02/2010      Nivedita    Added entry for TIAUTO_RH_check_ccr_form.
*		24/02/2010		Rajesh N	Added entry for TIAUTO-AH-unset-conditional-task
*		24/02/2010		Rajesh N	Merged the code for ER-5923-Workflow-for-Supplier-Requests
*       05/03/2010      Dipak Naik  removed the handler TIAUTO_RH_check_ccr_form.
*       12-04-2010      Nivedita    Added a handler TIAUTO_ah_create_access_solitem_rel for the Pre-condition TIAIsCreateRelationAllowed
*       13-04-2010      Nivedita    Added a handler TIAUTO_ah_create_access_affecteditem_rel for the Pre-condition TIAIsCreateRelationAllowed
*		15/04/2010		Dipak Naik	Added the entry for the progresssion check handlers:
*									1) TIAUTO-AH-check-status-progression
*									2) TIAUTO-RH-check-status-progression-stacked-change
*       03/06/2010      Dipak Naik  Added entry for TIAUTO-AH-check-blank-change action handler.
*		01/10/2010		Dipak Naik	Registered TIAUTO-AH-notify-stacked-wait-user action handler
*		13/06/2012		Mahesh 		Registered TIAUTO-RH-check-mandatory-attributes Rule handler
*

*H*/

#ifndef tiauto_custom_handlers_h
#define tiauto_custom_handlers_h

#include <tiauto_defines.h>

/*******************************************************************************
* Custom Handlers prototypes
*******************************************************************************/
int t1aAUTO_register_custom_handlers (int *decision, va_list args );

/*******************************************************************************
* Action Handlers 
*******************************************************************************/
extern int TIAUTO_AH_verify_status_progression(EPM_action_message_t     msg);
extern int t1aAUTO_validate_status(EPM_action_message_t     msg);
extern int t1aAUTO_set_task_due_date(EPM_action_message_t    msg);

extern int t1aAUTO_allow_form_changes(EPM_action_message_t msg);

extern int t1aAUTO_add_detailed_instructions(EPM_action_message_t msg);
extern int t1aAUTO_demote_email(EPM_action_message_t msg);
extern int t1aAUTO_send_email_toAll(EPM_action_message_t msg);
extern int tiauto_ah_set_rev_master_form_value(EPM_action_message_t msg);
extern int tiauto_ah_block_affitem_relation(EPM_action_message_t msg);
extern int tiauto_ah_block_solitem_relation(EPM_action_message_t msg);
extern int tiauto_ah_block_probitem_relation(EPM_action_message_t msg);
extern int tiauto_ah_check_non_doc_status(EPM_action_message_t msg);
extern int tiauto_ah_unset_conditional_task(EPM_action_message_t msg);
extern int t1aAUTO_set_responsible_party(EPM_action_message_t msg);
extern int t1aAUTO_set_initiator_approval_date(EPM_action_message_t msg);
extern int t1aAUTO_send_email(EPM_action_message_t msg);
extern int TIAUTO_AH_check_status_progression(EPM_action_message_t     msg);
extern int TIAUTO_AH_check_blank_change(EPM_action_message_t msg);
extern int TIAUTO_AH_notify_stacked_wait_user(EPM_action_message_t msg);
extern int tiauto_ah_create_access_solitem_rel(EPM_action_message_t msg);
extern int tiauto_ah_create_access_affecteditem_rel(EPM_action_message_t msg);
extern int tiauto_ah_create_access_referenceitem_rel(EPM_action_message_t msg);
extern int TIAUTO_CR_notify( EPM_action_message_t msg );
extern int t1aAUTO_send_targets_to_sites(EPM_action_message_t  msg);
extern int t1aAUTO_set_signoff_as_responsible_party(EPM_action_message_t msg);
extern int TIAUTO_AH_check_doc_status(EPM_action_message_t msg);
extern int TIAUTO_set_attribute_value(EPM_action_message_t msg);
extern int TIAUTO_ah_attach_related_primary_object(EPM_action_message_t msg);
extern int TIAUTO_AH_create_erp_translation_request(EPM_action_message_t msg);
extern int TAUTO_AH_Create_ToolNote_Item(EPM_action_message_t msg);
extern int TAUTO_AH_Create_MfgRelAuthorisation_Item(EPM_action_message_t msg);
extern int TIAUTO_AH_remove_parts_from_change_folder(EPM_action_message_t msg);
extern int TIAUTO_AH_set_conditional_task_based_on_reviewer_list(EPM_action_message_t msg);
extern int TIAUTO_AH_attach_purchasedparts_form (EPM_action_message_t msg);
extern int TIAUTO_AH_create_cae_report_translation_request(EPM_action_message_t msg);
extern int TIAUTO_AH_create_form_history(EPM_action_message_t msg);
extern int TIAUTO_AH_update_irm_with_change_info(EPM_action_message_t msg);
extern int TIAUTO_AH_update_history_form_on_rejection(EPM_action_message_t msg);
extern int TIAUTO_AH_remove_status_from_root_task(EPM_action_message_t msg);
extern int TIAUTO_AH_create_baselinewatermark_translation_request(EPM_action_message_t msg);
extern int t1aAUTO_AH_set_task_due_date(EPM_action_message_t    msg);
extern int t1aAUTO_AH_set_optedin_user_as_resp_party(EPM_action_message_t    msg);
extern int t1aAUTO_AH_send_mandatory_screening_notification(EPM_action_message_t    msg);
extern int t1aAUTO_AH_set_additional_reviewers_as_resp_party(EPM_action_message_t    msg);


extern int t1aAUTO_AH_block_drawing_relation(EPM_action_message_t    msg);
extern int t1aAUTO_AH_block_summary_relation(EPM_action_message_t    msg);
extern int t1aAUTO_AH_allow_drawing_relation(EPM_action_message_t    msg);
extern int t1aAUTO_AH_allow_drawing_relation_on_approved(EPM_action_message_t    msg);
extern int t1aAUTO_AH_allow_solution_relation_on_approved(EPM_action_message_t    msg);
extern int t1aAUTO_AH_copy_and_attach_timing_form(EPM_action_message_t    msg);
extern int t1aAUTO_AH_set_prototype_task_result(EPM_action_message_t    msg);
extern int t1aAUTO_AH_add_child_compoenents_to_target(EPM_action_message_t    msg);
extern int t1aAUTO_ah_notify_based_on_change_participants(EPM_action_message_t    msg);
extern int t1aAUTO_ah_check_mandatory_screening_need(EPM_action_message_t msg);
extern int TIAUTO_AH_update_standard_info_on_irm(EPM_action_message_t msg);
extern int TIAUTO_AH_create_remote_release_translation_request(EPM_action_message_t msg);
extern int TAUTO_AH_Create_SummaryImage_Item(EPM_action_message_t msg);
extern int TAUTO_AH_Update_Affected_Program_Info_On_PCI(EPM_action_message_t msg);
extern int t1aAUTO_AH_notify_to_additional_notifiers(EPM_action_message_t msg);
extern int t1aAUTO_AH_remove_signoff_attachments(EPM_action_message_t msg);
extern int TIAUTO_AH_remove_items_from_project(EPM_action_message_t msg );
extern int TIAUTO_AH_Create_ACD_Item(EPM_action_message_t msg);

//PRP
extern int TAUTO_AH_Create_ProRelAuthorisation_Item(EPM_action_message_t msg);

//Risk Assessment Document for CAP3
extern int TAUTO_AH_Create_RiskAssessment_Item(EPM_action_message_t msg);
//set resp party for CAP3
extern int t1aAUTO_AH_set_resp_party(EPM_action_message_t msg);

/*******************************************************************************
* Rule Handlers 
*******************************************************************************/

EPM_decision_t t1aAUTO_check_document(EPM_rule_message_t message);
EPM_decision_t t1aAUTO_deviation_effectivity(EPM_rule_message_t message);
extern EPM_decision_t t1aAUTO_check_target_object(EPM_rule_message_t msg);
EPM_decision_t t1aAUTO_ProE_integritycheck(EPM_rule_message_t message);

EPM_decision_t t1aAUTO_check_checkedout_remote_objects(EPM_rule_message_t message);
EPM_decision_t t1aAUTO_check_assembly_progression(EPM_rule_message_t message);
EPM_decision_t t1aAUTO_check_cro_items(EPM_rule_message_t message);
EPM_decision_t t1aAUTO_verify_related_revisions(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_status_progression_stacked_change(EPM_rule_message_t msg);

EPM_decision_t TIAUTO_RH_verify_status_progression_quick(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_ccr_form( EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_status_progression_stacked_change(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_based_on_condition(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_action_performer_role(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_conditional_task_result(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_wait_for_parallel_path(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_assignment_list(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_checkedout_objects(EPM_rule_message_t message);
EPM_decision_t TIAUTO_RH_check_remote_objects(EPM_rule_message_t message);
EPM_decision_t TIAUTO_RH_check_mandatory_attributes(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_related_objects(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_valid_erp_plant(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_product_impacted(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_mra_dataset_creation(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_caereport_dataset_creation(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_component_MRA_generation(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_engineer_feasible_task_result(EPM_rule_message_t msg );

EPM_decision_t TIAUTO_RH_check_targets_from_based_on_change(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_targets_are_on_same_state(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_child_comps_are_on_same_state(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_owning_group(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_masterdrawing_and_partfamily_attributes(EPM_rule_message_t msg );

EPM_decision_t TIAUTO_RH_check_reference_items(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_change_form_mandatory_attributes(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_changetiming_form_attribute_value(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_references_from_based_on_change(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_check_plant_value_in_changetiming_and_pci(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_mra_definition_attributes(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_parallel_path_tasks(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_designwork_required(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_items_for_project(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_items_notin_project(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_verify_release_status_for_pci(EPM_rule_message_t msg );

//PRP
EPM_decision_t TIAUTO_RH_verify_pra_definition_attributes(EPM_rule_message_t msg);
EPM_decision_t TIAUTO_RH_verify_component_PRA_generation(EPM_rule_message_t msg );
EPM_decision_t TIAUTO_RH_check_pra_dataset_creation(EPM_rule_message_t msg);

#endif /* tiauto_custom_handlers.h ------ END OF FILE ------*/
