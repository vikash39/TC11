
#ifndef TIAUTO_WORKFLOW_UTILS_H
#define TIAUTO_WORKFLOW_UTILS_H


#include <tiauto_defines.h>
#include <tiauto_utils.h>

extern int check_for_item_rev_progression( tag_t _tItem,
                                     STATUS_Struct_t _StatusProgression,
                                     TARGET_RELEASE_Struct_t _TargetReleaseStatus,
									 int _iPopulateErrMsgInStack,
								     int *iError_, //0 in case of the stacked cr rule handler, 1 for others 
									 TIA_ErrorMessage **errMsgStack_ );


extern int check_for_backward_progression ( tag_t _tItemRev,
										   tag_t *ptAffectedItems, int iNumAffected,
                                     STATUS_Struct_t _StatusProgression,
									 TARGET_RELEASE_Struct_t _TargetReleaseStatus,
									 int _iPopulateErrMsgInStack,
									 int *iError_, //0 in case of the stacked cr rule handler, 1 for others 
									 TIA_ErrorMessage **errMsgStack_ );


extern int check_for_assembly_progression( tag_t _tItemRev, 
	                                 tag_t *_ptAffectedItems,
									 int _iNumAffectedItems,
                                     STATUS_Struct_t _StatusProgression, 
									 TARGET_RELEASE_Struct_t _TargetReleaseStatus,
									 char	*pcEndOfWarningMsg,
									 int _iPopulateWarningMsgInStack,
									 int _iPopulateErrMsgInStack,
									 int *iError_, //0 in case of the stacked cr rule handler, 1 for others
							         TIA_ErrorMessage **warningMsgStack_,
									 TIA_ErrorMessage **errMsgStack_); 


extern int check_for_generic_progression( tag_t _tItemRev, 
	                               tag_t *_ptAffectedItems,
								   int _iNumAffectedItems,
                                   STATUS_Struct_t _StatusProgression, 
								   TARGET_RELEASE_Struct_t _TargetReleaseStatus,
								   char	*pcEndOfWarningMsg,
								   int _iPopulateWarningMsgInStack,
								   int _iPopulateErrMsgInStack,
								   int *iError_, //0 in case of the stacked cr rule handler, 1 for others
							       TIA_ErrorMessage **warningMsgStack_,
							       TIA_ErrorMessage **errMsgStack_ );


extern void writeErrorsMsgToAuditFile(tag_t tMsgTask, TIA_ErrorMessage *backwordProgErrMsgStack,
									  TIA_ErrorMessage *itemRevProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgErrMsgStack,
									  TIA_ErrorMessage *genericProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgWarningMsgStack,
									  TIA_ErrorMessage *genericProgWarningMsgStack);

extern void IsTagExistsInArray( tag_t tInput, tag_t* ptArray, int iNum, int *iFound );

extern void free_TIA_ErrorMessage_Stack( TIA_ErrorMessage *errMsgStack );

int Where_used_in_BOM(	tag_t			tErrorItem,
						tag_t			*_ptAffectedItems,
						int				_iNumAffectedItems,
						char			*szItemRevs,
						TIA_ErrorItems  **sBOMItemRevs);


#endif //END OF TIAUTO_WORKFLOW_UTILS_H

