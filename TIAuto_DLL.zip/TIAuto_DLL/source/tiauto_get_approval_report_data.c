/*******************************************************************************************************************************************************************************
File         : tiauto_get_approval_report_data.c

Description  : This server exit method gets the data required for approval report		  

Author       : TCS

Revision History :
Date            Revision    Who                 Description
***********************************************************************************************************************************************************************************
Feb 21, 2017    1.0        Jiten			Initial Creation
Mar 10, 2017 	2.0		   Jiten			Implemented the following changes
												1. Handle the scenario where the user id has be renamed. In such scenario's print the id instead of name
												2. In some cases the perform signoff task appears before the review or ack. Code updated to handle such cases
												3. For condition and other such tasks if the task is compeleted then check if the group and role values are defined in the pref
										            If yes read from pref else read from the query result
Mar 22, 2017	3.0 	   Jiten			Display the comments, if any, for pending tasks(except perform signoff)	
											Modified the code to display the proper result for auto demoted task
											Corrected the ITK api to get the default role of the user
Apr 19, 2017	4.0		   Jiten			If cond task is reassigned then display the resp party from assign event of the task instead of start event
Aug 10, 2017	5.0		   kantesh			Fixed for ER 9277
***************************************************************************************************************************************************************************************/

#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>

/**********************************************************************************
// Function    	 : TITAUTO_ProcessAuditInfo()
// Description 	 : Process the query data and define the output string array
// Input Parms 	 : iRowCnt - number of rows returned from the query
				   report  - query data
				   pcTaskNames - Task Names got from the preference
				   pcTaskGroups - Group Names of the task got from the preference
				   pcTaskRoles  - Role Names of the task got from the preference
				   iTaskArraySize - Size of array values got from the preference
// Return Parms  : iArraySize - Size of the output string array		
				   pcReportData - output string
/**********************************************************************************/
int TITAUTO_ProcessAuditInfo(int iRowCnt, void ***report,char **pcTaskNames, char **pcTaskGroups, char **pcTaskRoles, int iTaskArraySize, int *iArraySize, char ***pcReportData)
{
	int		iRetCode			= ITK_ok;	
	char 	*pcTempStr 			= NULL;
	int 	iTempStrLen 		= 0;
	int 	iTemCommentsStr 	= 0;
	int 	inx 				= 0;
	*iArraySize = 0;
	*pcReportData = NULL;	
	//while(!vsTaskNames.empty())
	for(inx = 0; inx < iTaskArraySize; inx++)
	{
		char 	*pcTaskName 			= NULL;
		char 	*pcGroup 				= NULL;
		char 	*pcRole 				= NULL;		
		char 	**pcSignoffUsers 		= NULL;
		char 	**pcSignoffGroups 		= NULL;
		char 	**pcSignoffRoles 		= NULL;
		char 	**pcSignoffUserNames	= NULL;
		char 	*pcReviewStartDate		= NULL;
		char 	*pcSignoffTaskName		= NULL;
		char 	*pcSignoffTaskType		= NULL;
		char 	*pcDemotedTaskName 	= NULL;
		int 	iSignoffArraySize 		= 0;
		int 	indx 					= 0;
		char 	*pcPerformComments 		= NULL;
		char 	*pcRespPartyAssignTask 		= NULL;
		char 	*pcUserIdAssignTask 		= NULL;
		//Get the task name from pref
		pcTaskName = (char *)MEM_alloc(((int)tc_strlen(pcTaskNames[inx]) + 1) * sizeof(char));
		tc_strcpy(pcTaskName, pcTaskNames[inx]);
		//Get the group name from pref
		pcGroup = (char *)MEM_alloc(((int)tc_strlen(pcTaskGroups[inx]) + 1) * sizeof(char));
		tc_strcpy(pcGroup, pcTaskGroups[inx]);
		//Get the role name from pref
		pcRole = (char *)MEM_alloc(((int)tc_strlen(pcTaskRoles[inx]) + 1) * sizeof(char));
		tc_strcpy(pcRole, pcTaskRoles[inx]);			
		//process each row from the query 
		for(indx = 0; indx < iRowCnt && (iRetCode == ITK_ok) ; indx++)
		{				
			if(report[indx][1] != NULL)
			{
				char 	*pcObjectName		= NULL;
				char 	*pcObjectType		= NULL;
				char 	*pcEventTypeName	= NULL;		
				char 	*pcParentTaskName 	= NULL;					
							
				//Task name
				pcObjectName = (char *)MEM_alloc(((int)tc_strlen((char *)(report[indx][1])) + 1)* sizeof(char));
				tc_strcpy(pcObjectName, (char *)report[indx][1]);
				//Event type name
				if(report[indx][3] != NULL)
				{
					pcEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][3]) + 1)* sizeof(char));
					tc_strcpy(pcEventTypeName, (char *)report[indx][3]);					
				}
				//Task type
				if(report[indx][2] != NULL)
				{
					pcObjectType = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][2]) + 1)* sizeof(char));
					tc_strcpy(pcObjectType, (char *)report[indx][2]);						
				}	
					
				//If there is a complete event before the start event then print the details and skip the start even.
				//This is a special scenario for select signoff task where the dates for start and complete task are same and the complete task is retrieved before its corresponding start task
				if((tc_strcmp(pcObjectName, pcTaskName) == 0) && (tc_strcmp(pcEventTypeName, "__Complete") == 0) && (tc_strcmp(pcObjectType, "EPMSelectSignoffTask") == 0))
				{
					char	*sStartDate				= NULL;
					date_t	dtStartDate				= NULLDATE;	
					char 	*pcResponsibleParty		= NULL;					
					char 	*pcTaskResult			= NULL;
					char 	*pcComments				= NULL;
					char 	*pcGroupName 			= NULL;
					char 	*pcRoleName 			= NULL;
					char	*pcNextTaskName 		= NULL;
					char 	*pcNextEventTypeName 	= NULL;
					int 	knx 					= 0;
					//Get the logged date of the task which will be the start date and end date
					if(report[indx][16] != NULL)
					{
						dtStartDate = *(date_t *)report[indx][16];
						//Converting start date to string format 
						TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtStartDate, &sStartDate));
					}					
					//Responsible party
					if(report[indx][0] != NULL)
					{
						pcResponsibleParty = tc_strtok((char *)report[indx][0], "(");						
					}
					//Group name
					if(report[indx][5] != NULL)
					{
						pcGroupName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][5]) + 1)* sizeof(char));
						tc_strcpy(pcGroupName, (char *)report[indx][5]);									
					}
					//Role name
					if(report[indx][6] != NULL)
					{
						pcRoleName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][6]) + 1)* sizeof(char));
						tc_strcpy(pcRoleName, (char *)report[indx][6]);									
					}
					//Task Result
					if(report[indx][8] != NULL)
					{
						pcTaskResult = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][8]) + 1)* sizeof(char));
						tc_strcpy(pcTaskResult, (char *)report[indx][8]);									
					}
					//Comments
					if(((char *)report[indx][9]) != NULL && (tc_strlen((char *)report[indx][9]) != 0))
					{
						pcComments = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][9]) + 1)* sizeof(char));
						tc_strcpy(pcComments, (char *)report[indx][9]);									
					}
					iTemCommentsStr = (int)tc_strlen(pcComments);
					pcTempStr = NULL;
					iTempStrLen = (int)tc_strlen(pcObjectName) + (int)tc_strlen("||") + (int)tc_strlen(sStartDate) + (int)tc_strlen("||") + (int)tc_strlen(sStartDate) + (int)tc_strlen("||") + (int)tc_strlen(pcResponsibleParty) + (int)tc_strlen("||") + (int)tc_strlen(pcGroupName) + (int)tc_strlen("||") + (int)tc_strlen(pcRoleName) + (int)tc_strlen("||") + (int)tc_strlen(pcComments) + (int)tc_strlen("||") + (int)tc_strlen(pcTaskResult) + (int)tc_strlen("||") + (int)tc_strlen(pcObjectType);							
					pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1));
					if(iTemCommentsStr == 0)
					{
						sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||||%s||%s", pcObjectName, sStartDate, sStartDate, pcResponsibleParty, pcGroupName, pcRoleName, pcTaskResult, pcObjectType);
					}
					else
					{
						sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||%s||%s||%s", pcObjectName, sStartDate, sStartDate, pcResponsibleParty, pcGroupName, pcRoleName, pcComments, pcTaskResult, pcObjectType);
					}
					//TC_write_syslog("Len %d\n%s\n",iTempStrLen, pcTempStr);
					*iArraySize = (*iArraySize) + 1;
					*pcReportData = (char**) MEM_realloc( *pcReportData, sizeof(char*) * (*iArraySize) );
					(*pcReportData)[(*iArraySize) - 1] = pcTempStr;					
					//It is assumed that the start event for this task will be present in the next row of the complete event					
					//Next task name
					pcNextTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx + 1][1]) + 1)* sizeof(char));
					tc_strcpy(pcNextTaskName, (char *)report[indx + 1][1]);
					//Next Event name				
					pcNextEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx + 1][3]) + 1)* sizeof(char));
					tc_strcpy(pcNextEventTypeName, (char *)report[indx + 1][3]);								
					if((tc_strcmp(pcNextTaskName, pcTaskName) == 0) && (tc_strcmp(pcNextEventTypeName, "__Start") == 0) && (tc_strcmp(pcObjectType, "EPMSelectSignoffTask") == 0))
					{
						//in this case indx is complete event, indx + 1 is the start event(this has to be skipped), indx + 2 will be the row after the start event
						indx = indx + 2;
					}
					else
					{
						TC_write_syslog("\n*** Error. Found a complete event at row %d for the task %s which does not have a start event.\nThe next task found is %s \n ****",indx, pcTaskName, pcNextTaskName);						
					}					
					SAFE_MEM_free(sStartDate);
					SAFE_MEM_free(pcTaskResult);
					SAFE_MEM_free(pcComments);								
					SAFE_MEM_free(pcGroupName);								
					SAFE_MEM_free(pcRoleName);	
					SAFE_MEM_free(pcNextTaskName);	
					SAFE_MEM_free(pcNextEventTypeName);	
				}
				//Check the start event for the task other than EPMAcknowledgeTask and EPMReviewTask
				if((tc_strcmp(pcObjectName, pcTaskName) == 0) && (tc_strcmp(pcEventTypeName, "__Start") == 0) && (tc_strcmp(pcObjectType, "EPMAcknowledgeTask") != 0) && (tc_strcmp(pcObjectType, "EPMReviewTask") != 0))
				{
					logical	lNextTaskFound	= false;										
					char	*sStartDate		= NULL;
					date_t	dtStartDate		= NULLDATE;
					int 	jnx 			= 0;
					//Get the logged date of the task which will be the start date
					if(report[indx][16] != NULL)
					{
						dtStartDate = *(date_t *)report[indx][16];
						//Converting start date to string format 
						TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtStartDate, &sStartDate));
					}										
					//Get the subsequent complete or demote event for the task
					for(jnx = indx + 1; jnx < iRowCnt; jnx++)
					{
						if(report[jnx][1] != NULL)
						{
							char	*pcNextTaskName 		= NULL;
							char 	*pcNextEventTypeName 	= NULL;
							char 	*pcTaskResult			= NULL;
							//Next task name
							pcNextTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][1]) + 1)* sizeof(char));
							tc_strcpy(pcNextTaskName, (char *)report[jnx][1]);
							//Event name
							if(report[jnx][3] != NULL)
							{
								pcNextEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][3]) + 1)* sizeof(char));
								tc_strcpy(pcNextEventTypeName, (char *)report[jnx][3]);								
							}
                            //Store the latest comments for perform task
							if((tc_strcmp(pcObjectName, pcNextTaskName) == 0) && (tc_strcmp(pcNextEventTypeName, "__Perform") == 0))
							{
								//Comments
								if(((char *)report[jnx][9]) != NULL && (tc_strlen((char *)report[jnx][9]) != 0))
								{
									SAFE_MEM_free(pcPerformComments);
									pcPerformComments = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][9]) + 1)* sizeof(char));
									tc_strcpy(pcPerformComments, (char *)report[jnx][9]);									
								}
							}
							//Get the resp party from the assign task
							if((tc_strcmp(pcObjectName, pcNextTaskName) == 0) && (tc_strcmp(pcNextEventTypeName, "__Assign") == 0))
							{
								//Responsible party
								if(report[jnx][0] != NULL)
								{									
									pcRespPartyAssignTask = tc_strtok((char *)report[jnx][0], "(");
									pcUserIdAssignTask = tc_strtok(NULL, ")");
								}
							}
							//Task Result
							if(report[jnx][8] != NULL)
							{
								pcTaskResult = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][8]) + 1)* sizeof(char));
								tc_strcpy(pcTaskResult, (char *)report[jnx][8]);									
							}
							//Capture the demoted task name
							if((tc_strcmp(pcNextEventTypeName, "__Complete") == 0 || tc_strcmp(pcNextEventTypeName, "__Demote") == 0) && ((tc_strcmp(pcTaskResult, "Demote") == 0) || (tc_strcmp(pcTaskResult, "Rework AM") == 0) || (tc_strcmp(pcTaskResult, "Rework Design") == 0) || (tc_strcmp(pcTaskResult, "Rework Engineering") == 0) || (tc_strcmp(pcTaskResult, "Add Engineering Items") == 0) || (tc_strcmp(pcTaskResult, "Add Design Items") == 0) || (tc_strcmp(pcTaskResult, "Rework Finance Manager") == 0) || (tc_strcmp(pcTaskResult, "Rework Account Manager") == 0) || (tc_strcmp(pcTaskResult, "Rework") == 0) || (tc_strcmp(pcTaskResult, "Add Items") == 0) || (tc_strcmp(pcTaskResult, "Reject Change") == 0) || (tc_strcmp(pcTaskResult, "Reject Change & Targets") == 0) || (tc_strcmp(pcTaskResult, "Rework Design Manager") == 0)))
							{
								SAFE_MEM_free(pcDemotedTaskName);
								pcDemotedTaskName = (char *)MEM_alloc(((int)tc_strlen(pcNextTaskName) + 1)* sizeof(char));
								tc_strcpy(pcDemotedTaskName, pcNextTaskName);									
							}
							//Check for complete or demote event
							if((tc_strcmp(pcObjectName, pcNextTaskName) == 0) && ((tc_strcmp(pcNextEventTypeName, "__Complete") == 0) || (tc_strcmp(pcNextEventTypeName, "__Demote") == 0)))
							{
								tag_t 	tGroupTag 				= NULLTAG;
								date_t	dtEndDate				= NULLDATE;
								char 	*pcResponsibleParty		= NULL;
								char 	*pcUserIdStr		= NULL;
								char	*sEndDate				= NULL;								
								char 	*pcComments				= NULL;
								char 	*pcGroupName 			= NULL;
								char 	*pcRoleName 			= NULL;
								//Responsible party
								if(report[jnx][0] != NULL)
								{
									//value stored is in the format plmserac (plmserac)
									pcResponsibleParty = tc_strtok((char *)report[jnx][0], "(");
									pcUserIdStr = tc_strtok(NULL, ")");									
								}
								//Group name
								if(report[jnx][5] != NULL)
								{
									//If group name is not given the pref then read from the table
									if(tc_strlen(pcGroup) == 0)
									{
										//if feasibility tasks are completed by "tida_complete_worflow_task" utility take default group of user which is not set in preference, #ER9277
										if(tc_strstr(pcTaskResult,"_No Response") != NULL)
										{
											tag_t tUserTag = NULLTAG;										
											//Get the user tag
											TIAUTO_ITKCALL(iRetCode, SA_find_user2(stripBlanks(pcUserIdStr), &tUserTag));
											if(iRetCode == ITK_ok && tUserTag != NULLTAG)
											{	
												//Get the default group tag
												TIAUTO_ITKCALL(iRetCode, AOM_ask_value_tag(tUserTag, "default_group", &tGroupTag));
												if(iRetCode == ITK_ok && tGroupTag != NULLTAG)
												{
													SAFE_MEM_free(pcGroupName);
													//Get the group name
													TIAUTO_ITKCALL(iRetCode, SA_ask_group_name2(tGroupTag, &pcGroupName));
												}
											}
										}
										else
										{
											pcGroupName = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][5]) + 1)* sizeof(char));
											tc_strcpy(pcGroupName, (char *)report[jnx][5]);
										}											
									}
									//else take the value from pref
									else
									{
										pcGroupName = (char *)MEM_alloc(((int)tc_strlen(pcGroup) + 1)* sizeof(char));
										tc_strcpy(pcGroupName, pcGroup);
									}
								}
								//Role name
								if(report[jnx][6] != NULL)
								{									
									//If role name is not given the pref then read from the table
									if(tc_strlen(pcRole) == 0)
									{
										//if feasibility tasks are completed by "tida_complete_worflow_task" utility take default role of user which is not set in preference, #ER9277
										if(tc_strstr(pcTaskResult,"_No Response") != NULL)
										{
											tag_t tRoleTag = NULLTAG;
											//Get the default role tag									
											TIAUTO_ITKCALL(iRetCode, SA_ask_group_default_role(tGroupTag, &tRoleTag));
											if(iRetCode == ITK_ok && tRoleTag != NULLTAG)
											{
												SAFE_MEM_free(pcRoleName);
												//Get the role name
												TIAUTO_ITKCALL(iRetCode, SA_ask_role_name2(tRoleTag, &pcRoleName));
											}
										}
										else
										{
											pcRoleName = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][6]) + 1)* sizeof(char));
											tc_strcpy(pcRoleName, (char *)report[jnx][6]);
										}											
									}
									//else take the value from pref
									else
									{
										pcRoleName = (char *)MEM_alloc(((int)tc_strlen(pcRole) + 1)* sizeof(char));
										tc_strcpy(pcRoleName, pcRole);		
									}
								}
								//Task Result
								/*if(report[jnx][8] != NULL)
								{
									pcTaskResult = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][8]) + 1)* sizeof(char));
									tc_strcpy(pcTaskResult, (char *)report[jnx][8]);									
								}*/
								//Comments
								if(((char *)report[jnx][9]) != NULL && (tc_strlen((char *)report[jnx][9]) != 0))
								{
									pcComments = (char *)MEM_alloc(((int)tc_strlen((char *)report[jnx][9]) + 1)* sizeof(char));
									tc_strcpy(pcComments, (char *)report[jnx][9]);									
								}
								//Logged date of the task which will be the end date
								if(report[jnx][16] != NULL)
								{
									dtEndDate = *(date_t *)report[jnx][16];
									//Converting start date to string format 
									TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtEndDate, &sEndDate));
								}																
								//Capture the demoted task name
								if((tc_strcmp(pcNextEventTypeName, "__Complete") == 0 || tc_strcmp(pcNextEventTypeName, "__Demote") == 0) && ((tc_strcmp(pcTaskResult, "Demote") == 0) || (tc_strcmp(pcTaskResult, "Rework AM") == 0) || (tc_strcmp(pcTaskResult, "Rework Design") == 0) || (tc_strcmp(pcTaskResult, "Rework Engineering") == 0) || (tc_strcmp(pcTaskResult, "Add Engineering Items") == 0) || (tc_strcmp(pcTaskResult, "Add Design Items") == 0) || (tc_strcmp(pcTaskResult, "Rework Finance Manager") == 0) || (tc_strcmp(pcTaskResult, "Rework Account Manager") == 0) || (tc_strcmp(pcTaskResult, "Rework") == 0) || (tc_strcmp(pcTaskResult, "Add Items") == 0) || (tc_strcmp(pcTaskResult, "Reject Change") == 0) || (tc_strcmp(pcTaskResult, "Reject Change & Targets") == 0) || (tc_strcmp(pcTaskResult, "Rework Design Manager") == 0)))
								{
									SAFE_MEM_free(pcDemotedTaskName);
									pcDemotedTaskName = (char *)MEM_alloc(((int)tc_strlen(pcObjectName) + 1)* sizeof(char));
									tc_strcpy(pcDemotedTaskName, pcObjectName);									
								}
								//Define the result text for auto demoted tasks
								if((tc_strcmp(pcNextEventTypeName, "__Demote") == 0) && (tc_strcmp(pcTaskResult, "Unset") == 0))
								{
									//comments should be blank for auto demoted tasks
									SAFE_MEM_free(pcComments);
									//if the demoted task is not found then iterate the rest of the rows to get the task
									if(pcDemotedTaskName == NULL)
									{
										int lnx = 0;
										logical lFoundDemoteTask = false;
										for(lnx = jnx + 1; lnx < iRowCnt; lnx++)
										{	
											char 	*pcNextDemoteEventTypeName 	= NULL;
											char 	*pcDemoteTaskResult 		= NULL;
											//Event name
											if(report[lnx][3] != NULL)
											{
												pcNextDemoteEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[lnx][3]) + 1)* sizeof(char));
												tc_strcpy(pcNextDemoteEventTypeName, (char *)report[lnx][3]);								
											}	
											//Task Result
											if(report[lnx][8] != NULL)
											{
												pcDemoteTaskResult = (char *)MEM_alloc(((int)tc_strlen((char *)report[lnx][8]) + 1)* sizeof(char));
												tc_strcpy(pcDemoteTaskResult, (char *)report[lnx][8]);									
											}											
											//Capture the demoted task name
											if((tc_strcmp(pcNextEventTypeName, "__Complete") == 0 || tc_strcmp(pcNextEventTypeName, "__Demote") == 0) && ((tc_strcmp(pcDemoteTaskResult, "Demote") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework AM") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework Design") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework Engineering") == 0) || (tc_strcmp(pcDemoteTaskResult, "Add Engineering Items") == 0) || (tc_strcmp(pcDemoteTaskResult, "Add Design Items") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework Finance Manager") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework Account Manager") == 0) || (tc_strcmp(pcDemoteTaskResult, "Rework") == 0) || (tc_strcmp(pcDemoteTaskResult, "Add Items") == 0) || (tc_strcmp(pcDemoteTaskResult, "Reject Change") == 0) || (tc_strcmp(pcDemoteTaskResult, "Reject Change & Targets") == 0) || (tc_strcmp(pcTaskResult, "Rework Design Manager") == 0)))
											{
												//task name												
												SAFE_MEM_free(pcDemotedTaskName);
												pcDemotedTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)report[lnx][1]) + 1)* sizeof(char));
												tc_strcpy(pcDemotedTaskName, (char *)report[lnx][1]);												
												lFoundDemoteTask = true;
											}
											SAFE_MEM_free(pcNextDemoteEventTypeName);
											SAFE_MEM_free(pcDemoteTaskResult);
											if(lFoundDemoteTask)
											{
												break;
											}
										}
									}									
									pcTaskResult = (char *)MEM_alloc(((int)tc_strlen("Auto Demoted (Decision at ") + (int)tc_strlen(pcDemotedTaskName) + (int)tc_strlen(")") + 1 )* sizeof(char));
									if(tc_strlen(pcDemotedTaskName) != 0)
									{
										sprintf(pcTaskResult, "Auto Demoted (Decision at %s)", pcDemotedTaskName);									
									}
									else
									{
										sprintf(pcTaskResult, "Auto Demoted (Decision at )");
									}

									SAFE_MEM_free(pcGroupName);
									SAFE_MEM_free(pcRoleName);
									//Get the group name from pref
									pcGroupName = (char *)MEM_alloc(((int)tc_strlen(pcTaskGroups[inx]) + 1) * sizeof(char));
									tc_strcpy(pcGroupName, pcTaskGroups[inx]);
									//Get the role name from pref
									pcRoleName = (char *)MEM_alloc(((int)tc_strlen(pcTaskRoles[inx]) + 1) * sizeof(char));
									tc_strcpy(pcRoleName, pcTaskRoles[inx]);	

									//If the group and role info is not given in the pref value
									if(tc_strlen(pcGroupName) == 0)
									{
										tag_t tUserTag = NULLTAG;										
										//Get the user tag
										TIAUTO_ITKCALL(iRetCode, SA_find_user2(stripBlanks(pcUserIdStr), &tUserTag));
										if(iRetCode == ITK_ok && tUserTag != NULLTAG)
										{	
											tag_t tGroupTag = NULLTAG;
											//Get the default group tag
											TIAUTO_ITKCALL(iRetCode, AOM_ask_value_tag(tUserTag, "default_group", &tGroupTag));
											if(iRetCode == ITK_ok && tGroupTag != NULLTAG)
											{
												tag_t tRoleTag = NULLTAG;
												//Get the default role tag									
												TIAUTO_ITKCALL(iRetCode, SA_ask_group_default_role(tGroupTag, &tRoleTag));
												if(iRetCode == ITK_ok && tRoleTag != NULLTAG)
												{
													SAFE_MEM_free(pcRoleName);
													//Get the role name
													TIAUTO_ITKCALL(iRetCode, SA_ask_role_name2(tRoleTag, &pcRoleName));
												}
												if(iRetCode == ITK_ok)
												{
													SAFE_MEM_free(pcGroupName);
													//Get the group name
													TIAUTO_ITKCALL(iRetCode, SA_ask_group_name2(tGroupTag, &pcGroupName));
												}
									
											}
										}
									}
								}
								iTemCommentsStr = (int)tc_strlen(pcComments);
								pcTempStr = NULL;
								iTempStrLen = (int)tc_strlen(pcObjectName) + (int)tc_strlen("||") + (int)tc_strlen(sStartDate) + (int)tc_strlen("||") + (int)tc_strlen(sEndDate) + (int)tc_strlen("||") + (int)tc_strlen(pcResponsibleParty) + (int)tc_strlen("||") + (int)tc_strlen(pcGroupName) + (int)tc_strlen("||") + (int)tc_strlen(pcRoleName) + (int)tc_strlen("||") + (int)tc_strlen(pcComments) + (int)tc_strlen("||") + (int)tc_strlen(pcTaskResult) + (int)tc_strlen("||") + (int)tc_strlen(pcObjectType);							
								pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1));
								if(iTemCommentsStr == 0)
								{
									sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||||%s||%s", pcObjectName, sStartDate, sEndDate, pcResponsibleParty, pcGroupName, pcRoleName, pcTaskResult, pcObjectType);
								}
								else
								{
									sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||%s||%s||%s", pcObjectName, sStartDate, sEndDate, pcResponsibleParty, pcGroupName, pcRoleName, pcComments, pcTaskResult, pcObjectType);
								}
								//TC_write_syslog("Len1 %d\n%s\n",iTempStrLen, pcTempStr);
								*iArraySize = (*iArraySize) + 1;
								*pcReportData = (char**) MEM_realloc( *pcReportData, sizeof(char*) * (*iArraySize) );
								(*pcReportData)[(*iArraySize) - 1] = pcTempStr;
								lNextTaskFound = true;								
								SAFE_MEM_free(sEndDate);
								//SAFE_MEM_free(pcResponsibleParty);								
								SAFE_MEM_free(pcComments);								
								SAFE_MEM_free(pcGroupName);								
								SAFE_MEM_free(pcRoleName);								
							}	
							SAFE_MEM_free(pcNextTaskName);
							SAFE_MEM_free(pcNextEventTypeName);		
							SAFE_MEM_free(pcTaskResult);
							if(lNextTaskFound)
							{
								//since jnx number of rows are already processed indx can continue processing from the next row
								indx = jnx + 1;
								break;
							}
						}											
					}
					//Task does not have complete or demote event
					if(!lNextTaskFound)
					{
						char	*pcNextEventTypeName 	= NULL;						
						char 	*pcResponsibleParty		= NULL;
						char 	*pcUserIdStr 			= NULL;
						//If the task is reassigned then take the resp party from assign event
						if(pcRespPartyAssignTask != NULL)
						{
							pcResponsibleParty = (char *)MEM_alloc(((int)tc_strlen(pcRespPartyAssignTask) + 1)* sizeof(char));
							tc_strcpy(pcResponsibleParty, pcRespPartyAssignTask);
							pcUserIdStr = (char *)MEM_alloc(((int)tc_strlen(pcUserIdAssignTask) + 1)* sizeof(char));
							tc_strcpy(pcUserIdStr, pcUserIdAssignTask);
						}
						//else take the resp party from start event
						else
						{
							//Responsible party
							if(report[indx][0] != NULL)
							{
								pcResponsibleParty = tc_strtok((char *)report[indx][0], "(");
								pcUserIdStr = tc_strtok(NULL, ")");
							}
						}
						//Event type
						if(report[indx][3] != NULL)
						{
							pcNextEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][3]) + 1)* sizeof(char));
							tc_strcpy(pcNextEventTypeName, (char *)report[indx][3]);							
						}		
						//If the group and role info is not given in the pref value
						if(tc_strlen(pcGroup) == 0)
						{
							tag_t tUserTag = NULLTAG;
							//Get the user tag
							TIAUTO_ITKCALL(iRetCode, SA_find_user2(stripBlanks(pcUserIdStr), &tUserTag));
							if(iRetCode == ITK_ok && tUserTag != NULLTAG)
							{	
								tag_t tGroupTag = NULLTAG;
								//Get the default group tag
								TIAUTO_ITKCALL(iRetCode, AOM_ask_value_tag(tUserTag, "default_group", &tGroupTag));
								if(iRetCode == ITK_ok && tGroupTag != NULLTAG)
								{
									tag_t tRoleTag = NULLTAG;
									//Get the default role tag									
									//TIAUTO_ITKCALL(iRetCode, SA_ask_group_default_role(tGroupTag, &tRoleTag));
									TIAUTO_ITKCALL(iRetCode, SA_ask_user_default_role_in_group(tUserTag, tGroupTag, &tRoleTag));
									if(iRetCode == ITK_ok && tRoleTag != NULLTAG)
									{
										SAFE_MEM_free(pcRole);
										//Get the role name
										TIAUTO_ITKCALL(iRetCode, SA_ask_role_name2(tRoleTag, &pcRole));
									}
									if(iRetCode == ITK_ok)
									{
										SAFE_MEM_free(pcGroup);
										//Get the group name
										TIAUTO_ITKCALL(iRetCode, SA_ask_group_name2(tGroupTag, &pcGroup));
									}
									
								}
							}
						}
						pcTempStr = NULL;
						if(pcPerformComments == NULL)
						{
							iTempStrLen = (int)tc_strlen(pcObjectName) + (int)tc_strlen("||") + (int)tc_strlen(sStartDate) + (int)tc_strlen("||||") + (int)tc_strlen(pcResponsibleParty) + (int)tc_strlen("||") + (int)tc_strlen(pcGroup) + (int)tc_strlen("||") + (int)tc_strlen(pcRole) + (int)tc_strlen("||||")  + (int)tc_strlen("||") + (int)tc_strlen(pcObjectType);;
							pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1 ) );
							sprintf(pcTempStr, "%s||%s||||%s||%s||%s||||||%s", pcObjectName, sStartDate, pcResponsibleParty, pcGroup, pcRole, pcObjectType);
						}
						else
						{
							iTempStrLen = (int)tc_strlen(pcObjectName) + (int)tc_strlen("||") + (int)tc_strlen(sStartDate) + (int)tc_strlen("||||") + (int)tc_strlen(pcResponsibleParty) + (int)tc_strlen("||") + (int)tc_strlen(pcGroup) + (int)tc_strlen("||") + (int)tc_strlen(pcRole) + (int)tc_strlen("||") + (int)tc_strlen(pcPerformComments) + (int)tc_strlen("||")  + (int)tc_strlen("||") + (int)tc_strlen(pcObjectType);;
							pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1 ) );
							sprintf(pcTempStr, "%s||%s||||%s||%s||%s||%s||||%s", pcObjectName, sStartDate, pcResponsibleParty, pcGroup, pcRole, pcPerformComments, pcObjectType);
						}
						//TC_write_syslog("Len2 %d \n %s \n",iTempStrLen, pcTempStr);
						*iArraySize = (*iArraySize) + 1;
						*pcReportData = (char**) MEM_realloc( *pcReportData, sizeof(char*) * (*iArraySize) );
						(*pcReportData)[(*iArraySize) - 1] = pcTempStr;						
						SAFE_MEM_free(pcNextEventTypeName);
						//SAFE_MEM_free(pcResponsibleParty);
					}										
					SAFE_MEM_free(sStartDate);
				}
				//logic for review or ack task
				else
				{
					
					//Get the parent task name
					if(report[indx][17] != NULL)
					{
						pcParentTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][17]) + 1)* sizeof(char));
						tc_strcpy(pcParentTaskName, (char *)report[indx][17]);								
					}
					//Get the signoff users for review task
					if((tc_strcmp(pcParentTaskName, pcTaskName) == 0) && (tc_strcmp(pcObjectType, "EPMSelectSignoffTask") == 0) && (tc_strcmp(pcEventTypeName, "__Add_Attachment") == 0))
					{
						//If sigoffuserid field is not null
						if(report[indx][11] != NULL)
						{
							tag_t tUserTag = NULLTAG;
							iSignoffArraySize = iSignoffArraySize + 1;
							//sign off user										
							pcSignoffUsers = (char **) MEM_realloc( pcSignoffUsers, sizeof(char *) * iSignoffArraySize );
							pcSignoffUsers[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][11]) + 1)* sizeof(char));
							tc_strcpy(pcSignoffUsers[iSignoffArraySize - 1], (char *)report[indx][11]);
							//sign off group						
							pcSignoffGroups = (char **) MEM_realloc(pcSignoffGroups, sizeof(char *) * iSignoffArraySize );
							pcSignoffGroups[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][12]) + 1)* sizeof(char));
							tc_strcpy(pcSignoffGroups[iSignoffArraySize - 1], (char *)report[indx][12]);							
							//sign off role						
							pcSignoffRoles = (char **) MEM_realloc(pcSignoffRoles, sizeof(char *) * iSignoffArraySize );
							pcSignoffRoles[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][13]) + 1)* sizeof(char));
							tc_strcpy(pcSignoffRoles[iSignoffArraySize - 1], (char *)report[indx][13]);	
							//Get the user tag
							TIAUTO_ITKCALL(iRetCode, SA_find_user2((char *)report[indx][11], &tUserTag));
							if(iRetCode == ITK_ok && tUserTag != NULLTAG)
							{
								char *pcSignOfPersonName = NULL;
								TIAUTO_ITKCALL(iRetCode, SA_ask_user_person_name2(tUserTag, &pcSignOfPersonName));
								//sign off person name
								pcSignoffUserNames = (char **) MEM_realloc( pcSignoffUserNames, sizeof(char *) * iSignoffArraySize );
								pcSignoffUserNames[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen(pcSignOfPersonName) + 1)* sizeof(char));
								tc_strcpy(pcSignoffUserNames[iSignoffArraySize - 1], pcSignOfPersonName);
								SAFE_MEM_free(pcSignOfPersonName);
							}
							else if((char *)report[indx][11] != NULL)
							{
								pcSignoffUserNames = (char **) MEM_realloc( pcSignoffUserNames, sizeof(char *) * iSignoffArraySize );
								pcSignoffUserNames[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[indx][11]) + 1)* sizeof(char));
								tc_strcpy(pcSignoffUserNames[iSignoffArraySize - 1], (char *)report[indx][11]);
							}
						}
					}							
					//There are cases when the query returns EPMPerformSignoffTask before its corresponding review or ack task
					if((tc_strcmp(pcParentTaskName, pcTaskName) == 0) && (tc_strcmp(pcObjectType, "EPMPerformSignoffTask") == 0) && (tc_strcmp(pcEventTypeName, "__Start") == 0))
					{
						//Get the logged date of the task which will be the start date
						if(report[indx][16] != NULL)
						{
							date_t	dtReviewStartDate	= NULLDATE;	
							dtReviewStartDate = *(date_t *)report[indx][16];
							//Converting start date to string format 
							TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtReviewStartDate, &pcReviewStartDate));
						}
						//perform signoff task name							
						pcSignoffTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)(report[indx][1])) + 1)* sizeof(char));
						tc_strcpy(pcSignoffTaskName, (char *)report[indx][1]);
						//perform signoff task type							
						pcSignoffTaskType = (char *)MEM_alloc(((int)tc_strlen(pcObjectType) + 1)* sizeof(char));
						tc_strcpy(pcSignoffTaskType, pcObjectType);
					}
					//Logic for review or ack task
					if((tc_strcmp(pcObjectName, pcTaskName) == 0) && ((tc_strcmp(pcObjectType, "EPMReviewTask") == 0) || (tc_strcmp(pcObjectType, "EPMAcknowledgeTask") == 0)) && (tc_strcmp(pcEventTypeName, "__Start") == 0))
					{
						int 	iSignoffCompArraySize 	= 0;
						char 	**pcSignOffComments 	= NULL;
						char 	**pcSignoffDate			= NULL;
						char 	**pcSignOffCompUserId	= NULL;
						char 	**pcSignOffDecision		= NULL;						
						logical	lFoundEndTask 			= false;
						int 	knx 					= 0;			
						//Get the subsequent rows 
						for(knx = indx + 1; knx < iRowCnt; knx++)
						{
							char 	*pcNextTaskEventTypeName	= NULL;
							char 	*pcNextTaskObjectType 		= NULL;
							char 	*pcNextParentTaskName 		= NULL;
							char 	*pcNextTaskName 			= NULL;
							
							//Task name
							if(report[knx][3] != NULL)
							{							
								pcNextTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)(report[knx][1])) + 1)* sizeof(char));
								tc_strcpy(pcNextTaskName, (char *)report[knx][1]);
							}						
							//Event type name
							if(report[knx][3] != NULL)
							{
								pcNextTaskEventTypeName = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][3]) + 1)* sizeof(char));
								tc_strcpy(pcNextTaskEventTypeName, (char *)report[knx][3]);					
							}
							//Task type
							if(report[knx][2] != NULL)
							{
								pcNextTaskObjectType = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][2]) + 1)* sizeof(char));
								tc_strcpy(pcNextTaskObjectType, (char *)report[knx][2]);						
							}
							//Get the parent task name
							if(report[knx][17] != NULL)
							{
								pcNextParentTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][17]) + 1)* sizeof(char));
								tc_strcpy(pcNextParentTaskName, (char *)report[knx][17]);								
							}
							//Start date for review/ack task
							if((tc_strcmp(pcNextParentTaskName, pcTaskName) == 0) && (tc_strcmp(pcNextTaskObjectType, "EPMPerformSignoffTask") == 0) && (tc_strcmp(pcNextTaskEventTypeName, "__Start") == 0))
							{
								//Get the logged date of the task which will be the start date
								if(report[knx][16] != NULL)
								{
									date_t	dtReviewStartDate	= NULLDATE;	
									dtReviewStartDate = *(date_t *)report[knx][16];
									//Converting start date to string format 
									TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtReviewStartDate, &pcReviewStartDate));
								}
								//perform signoff task name							
								pcSignoffTaskName = (char *)MEM_alloc(((int)tc_strlen((char *)(report[knx][1])) + 1)* sizeof(char));
								tc_strcpy(pcSignoffTaskName, (char *)report[knx][1]);
								//perform signoff task type							
								pcSignoffTaskType = (char *)MEM_alloc(((int)tc_strlen(pcNextTaskObjectType) + 1)* sizeof(char));
								tc_strcpy(pcSignoffTaskType, pcNextTaskObjectType);
							}
							//End date, signoffcomments
							if((tc_strcmp(pcNextParentTaskName, pcTaskName) == 0) && (tc_strcmp(pcNextTaskObjectType, "EPMPerformSignoffTask") == 0) && ((tc_strcmp(pcNextTaskEventTypeName, "__Approve") == 0) || (tc_strcmp(pcNextTaskEventTypeName, "__Reject") == 0) || (tc_strcmp(pcNextTaskEventTypeName, "__Demote") == 0)))
							{							
								//signoff user
								if(((char *)report[knx][11]) != NULL)
								{
									iSignoffCompArraySize = iSignoffCompArraySize + 1;
									//sign off comments
									if(((char *)report[knx][10]) != NULL && (tc_strlen((char *)report[knx][10]) != 0))
									{
										pcSignOffComments = (char **) MEM_realloc( pcSignOffComments, sizeof(char *) * iSignoffCompArraySize );
										pcSignOffComments[iSignoffCompArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][10]) + 1)* sizeof(char));
										tc_strcpy(pcSignOffComments[iSignoffCompArraySize - 1], (char *)report[knx][10]);									
									}
									//Logged date of the task which will be the end date
									if(report[knx][16] != NULL)
									{
										char *pcEndDate = NULL;
										date_t	dtSignOffDate	= NULLDATE;
										dtSignOffDate = *(date_t *)report[knx][16];
										//Converting start date to string format 
										TIAUTO_ITKCALL(iRetCode,ITK_date_to_string(dtSignOffDate, &pcEndDate));
										pcSignoffDate = (char **) MEM_realloc(pcSignoffDate, sizeof(char *) * iSignoffCompArraySize );
										pcSignoffDate[iSignoffCompArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen(pcEndDate) + 1)* sizeof(char));
										tc_strcpy(pcSignoffDate[iSignoffCompArraySize - 1], pcEndDate);
										SAFE_MEM_free(pcEndDate);
									}
									//signoff user
									pcSignOffCompUserId = (char **) MEM_realloc( pcSignOffCompUserId, sizeof(char *) * iSignoffCompArraySize );
									pcSignOffCompUserId[iSignoffCompArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][11]) + 1)* sizeof(char));
									tc_strcpy(pcSignOffCompUserId[iSignoffCompArraySize - 1], (char *)report[knx][11]);																											
									//result																			
									pcSignOffDecision = (char **) MEM_realloc( pcSignOffDecision, sizeof(char *) * iSignoffCompArraySize );
									pcSignOffDecision[iSignoffCompArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen(pcNextTaskEventTypeName) + 1)* sizeof(char));
									tc_strcpy(pcSignOffDecision[iSignoffCompArraySize - 1], pcNextTaskEventTypeName);
								}
							}
							//Get the signoff users for review task
							if((tc_strcmp(pcNextParentTaskName, pcTaskName) == 0) && (tc_strcmp(pcNextTaskObjectType, "EPMSelectSignoffTask") == 0) && (tc_strcmp(pcNextTaskEventTypeName, "__Add_Attachment") == 0))
							{
								//If sigoffuserid field is not null
								if(report[knx][11] != NULL)
								{
									tag_t tUserTag = NULLTAG;
									iSignoffArraySize = iSignoffArraySize + 1;
									//sign off user id										
									pcSignoffUsers = (char **) MEM_realloc( pcSignoffUsers, sizeof(char *) * iSignoffArraySize );
									pcSignoffUsers[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][11]) + 1)* sizeof(char));
									tc_strcpy(pcSignoffUsers[iSignoffArraySize - 1], (char *)report[knx][11]);
									//sign off group						
									pcSignoffGroups = (char **) MEM_realloc(pcSignoffGroups, sizeof(char *) * iSignoffArraySize );
									pcSignoffGroups[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][12]) + 1)* sizeof(char));
									tc_strcpy(pcSignoffGroups[iSignoffArraySize - 1], (char *)report[knx][12]);							
									//sign off role						
									pcSignoffRoles = (char **) MEM_realloc(pcSignoffRoles, sizeof(char *) * iSignoffArraySize );
									pcSignoffRoles[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][13]) + 1)* sizeof(char));
									tc_strcpy(pcSignoffRoles[iSignoffArraySize - 1], (char *)report[knx][13]);
									//Get the user tag
									TIAUTO_ITKCALL(iRetCode, SA_find_user2((char *)report[knx][11], &tUserTag));
									if(iRetCode == ITK_ok && tUserTag != NULLTAG)
									{
										char *pcSignOfPersonName = NULL;
										TIAUTO_ITKCALL(iRetCode, SA_ask_user_person_name2(tUserTag, &pcSignOfPersonName));
										//sign off person name
										pcSignoffUserNames = (char **) MEM_realloc( pcSignoffUserNames, sizeof(char *) * iSignoffArraySize );
										pcSignoffUserNames[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen(pcSignOfPersonName) + 1)* sizeof(char));
										tc_strcpy(pcSignoffUserNames[iSignoffArraySize - 1], pcSignOfPersonName);
										SAFE_MEM_free(pcSignOfPersonName);
									}	
									else if((char *)report[knx][11] != NULL)
									{
										pcSignoffUserNames = (char **) MEM_realloc( pcSignoffUserNames, sizeof(char *) * iSignoffArraySize );
										pcSignoffUserNames[iSignoffArraySize - 1] = (char *)MEM_alloc(((int)tc_strlen((char *)report[knx][11]) + 1)* sizeof(char));
										tc_strcpy(pcSignoffUserNames[iSignoffArraySize - 1], (char *)report[knx][11]);
									}
								}
							}
							//Check if the review or ack task is completed
							if((tc_strcmp(pcNextTaskName, pcTaskName) == 0) && ((tc_strcmp(pcNextTaskObjectType, "EPMReviewTask") == 0) || (tc_strcmp(pcNextTaskObjectType, "EPMAcknowledgeTask") == 0)) && ((tc_strcmp(pcNextTaskEventTypeName, "__Complete") == 0) || (tc_strcmp(pcNextTaskEventTypeName, "__Demote") == 0)))
							{								
								lFoundEndTask = true;
							}
							SAFE_MEM_free(pcNextTaskEventTypeName);
							SAFE_MEM_free(pcNextTaskObjectType);
							SAFE_MEM_free(pcNextParentTaskName);
							SAFE_MEM_free(pcNextTaskName);
							if(lFoundEndTask && pcSignOffCompUserId != NULL)
							{
								//since knx number of rows are already processed indx can continue processing from the next row
								indx = knx + 1;
								break;
							}
						}
						if(iSignoffArraySize > 0)
						{
							int lnx = 0;
							for(lnx = 0; lnx < iSignoffArraySize; lnx++)
							{
								int 	pnx 			= 0;
								logical lSignOffComp 	= false;
								for(pnx = 0; pnx < iSignoffCompArraySize; pnx++)
								{
									//Sign off task is completed
									if(tc_strcmp(pcSignoffUsers[lnx], pcSignOffCompUserId[pnx]) == 0)
									{
										pcTempStr = NULL;						
										iTempStrLen = (int)tc_strlen(pcSignoffTaskName) + (int)tc_strlen("||") + (int)tc_strlen(pcReviewStartDate) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffDate[pnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffUserNames[lnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffGroups[lnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffRoles[lnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignOffComments[pnx]) + (int)tc_strlen("||")+ (int)tc_strlen(pcSignOffDecision[pnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffTaskType);
										pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1 ) );
										if(tc_strlen(pcSignOffComments[pnx]) != 0)
										{
											sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||%s||%s||%s", pcSignoffTaskName, pcReviewStartDate, pcSignoffDate[pnx], pcSignoffUserNames[lnx], pcSignoffGroups[lnx], pcSignoffRoles[lnx], pcSignOffComments[pnx], pcSignOffDecision[pnx], pcSignoffTaskType);
										}
										else
										{
											sprintf(pcTempStr, "%s||%s||%s||%s||%s||%s||||%s||%s", pcSignoffTaskName, pcReviewStartDate, pcSignoffDate[pnx], pcSignoffUserNames[lnx], pcSignoffGroups[lnx], pcSignoffRoles[lnx], pcSignOffDecision[pnx], pcSignoffTaskType);
										}
										//TC_write_syslog("Len3 %d \n %s \n",iTempStrLen, pcTempStr);
										*iArraySize = (*iArraySize) + 1;
										*pcReportData = (char**) MEM_realloc( *pcReportData, sizeof(char*) * (*iArraySize) );
										(*pcReportData)[(*iArraySize) - 1] = pcTempStr;
										lSignOffComp = true;
										break;
									}
								}
								//Sign off task is pending
								if(!lSignOffComp)
								{
									pcTempStr = NULL;						
									iTempStrLen = (int)tc_strlen(pcSignoffTaskName) + (int)tc_strlen("||") + (int)tc_strlen(pcReviewStartDate) + (int)tc_strlen("||||") + (int)tc_strlen(pcSignoffUserNames[lnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffGroups[lnx]) + (int)tc_strlen("||") + (int)tc_strlen(pcSignoffRoles[lnx]) + (int)tc_strlen("||||") + (int)tc_strlen("||")+ (int)tc_strlen(pcSignoffTaskType);
									pcTempStr = (char*) MEM_alloc( sizeof(char) * (iTempStrLen + 1 ) );
									sprintf(pcTempStr, "%s||%s||||%s||%s||%s||||||%s", pcSignoffTaskName, pcReviewStartDate, pcSignoffUserNames[lnx], pcSignoffGroups[lnx], pcSignoffRoles[lnx], pcSignoffTaskType);
									//TC_write_syslog("Len4 %d \n %s \n",iTempStrLen, pcTempStr);
									*iArraySize = (*iArraySize) + 1;
									*pcReportData = (char**) MEM_realloc( *pcReportData, sizeof(char*) * (*iArraySize) );
									(*pcReportData)[(*iArraySize) - 1] = pcTempStr;
								}
							}
						}
						SAFE_MEM_free(pcSignOffComments);
						SAFE_MEM_free(pcSignoffDate);
						SAFE_MEM_free(pcSignOffCompUserId);
						SAFE_MEM_free(pcSignOffDecision);
						SAFE_MEM_free(pcReviewStartDate);
						SAFE_MEM_free(pcSignoffTaskName);
						SAFE_MEM_free(pcSignoffTaskType);
					}
				}
				SAFE_MEM_free(pcObjectName);
				SAFE_MEM_free(pcObjectType);
				SAFE_MEM_free(pcEventTypeName);				
				SAFE_MEM_free(pcParentTaskName);
			}
		}
		SAFE_MEM_free(pcTaskName);
		SAFE_MEM_free(pcGroup);
		SAFE_MEM_free(pcRole);
		SAFE_MEM_free(pcPerformComments);
		SAFE_MEM_free(pcDemotedTaskName);
		if(iSignoffArraySize > 0)
		{
			SAFE_MEM_free(pcSignoffUsers);
			SAFE_MEM_free(pcSignoffGroups);
			SAFE_MEM_free(pcSignoffRoles);		
			SAFE_MEM_free(pcSignoffUserNames);		
		}
	}		
	
	return iRetCode;
}
/**********************************************************************************
// Function    	 : TITAUTO_GetAuditInfo()
// Description 	 : POM query to get the audit details for the given job name from Pfnd0workflowaudit table
// Input Parms 	 : sJobName - Job Name
				   report  - query data
				   pcTaskNames - Task Names got from the preference
				   pcTaskGroups - Group Names of the task got from the preference
				   pcTaskRoles  - Role Names of the task got from the preference
				   iTaskArraySize - Size of array values got from the preference
// Return Parms  : rows - number of rows returned
				   cols - number of cols returned
				   report - output data
/**********************************************************************************/
int TITAUTO_GetAuditInfo(const char* sJobName, int *rows, int *cols, void ****report)
{	
	//Sql query to build
	/*	Select Presponsible_Partydisp,Pobject_Name,Pobject_Type,Pfnd0eventtypename,Pfnd0userid,Pfnd0groupname,Pfnd0rolename,
		Ptask_State,Ptask_Result,Pcomments,Pfnd0loggeddate,Pfnd0signoffcomments,Pfnd0signoffuserid,Pfnd0signoffgroupname,
		Pfnd0signoffrolename,Pfnd0enddate,Pfnd0startdate,pparent_taskdisp,plsd 
		From Pfnd0workflowaudit
		Where Pjob_Name = <job_name> And
		Pobject_Type Not In ('EPMOrTask','EPMTask') And
		Pfnd0eventtypename In ('__Start','__Complete','__Approve','__Reject','__Demote','__Add_Attachment','__Perform','__Assign')
		ORDER BY plsd asc;	
	*/
	
	int		iRetCode	= ITK_ok;

	/*Initializing input parameters*/
	const char* sObjType[]	 = {"EPMOrTask","EPMTask"};
	const char* sEventType[] = {"__Start","__Complete","__Approve","__Reject","__Demote","__Add_Attachment","__Perform","__Assign"};
	/*output column list */
	const char* select_attr_list1[] =  {"responsible_partydisp","object_Name","object_Type","fnd0eventtypename",
										"fnd0userid","fnd0groupname","fnd0rolename","task_state",
										"task_result","comments","fnd0signoffcomments","fnd0signoffuserid",
										"fnd0signoffgroupname","fnd0signoffrolename","fnd0enddate","fnd0startdate",
										"fnd0loggeddate","parent_taskdisp","lsd"};
	/*Create a query */	
	TIAUTO_ITKCALL(iRetCode,POM_enquiry_create ("FindObject"));
	
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_add_select_attrs ("FindObject","fnd0workflowaudit",19,select_attr_list1));

	/*Bind values */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_string_value ("FindObject","aunique_value_id1",1,&sJobName,POM_enquiry_bind_value));		
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_string_value ("FindObject","aunique_value_id2",2,sObjType,POM_enquiry_bind_value));
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_string_value ("FindObject","aunique_value_id3",8,sEventType,POM_enquiry_bind_value));
	
	/*start query EXPRESSION */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_attr_expr ("FindObject","auniqueExprId_1","fnd0workflowaudit","job_name",POM_enquiry_equal,"aunique_value_id1"));
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_attr_expr ("FindObject","auniqueExprId_2","fnd0workflowaudit","object_type",POM_enquiry_not_in,"aunique_value_id2"));
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_attr_expr ("FindObject","auniqueExprId_3","fnd0workflowaudit","fnd0eventtypename",POM_enquiry_in,"aunique_value_id3"));
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_add_order_attr ("FindObject","fnd0workflowaudit","lsd",POM_enquiry_asc_order));
	 
	/*join the above expression */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_expr ("FindObject","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2" ));
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_expr ("FindObject","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_3" ));

	/*set the where expression */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_where_expr ("FindObject","auniqueExprId_11"));

	/*select distinct.*/
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_set_distinct ("FindObject",true));

	/* execute the query */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_execute ("FindObject",rows,cols,report));	

	/*delete the query */
	TIAUTO_ITKCALL(iRetCode, POM_enquiry_delete ("FindObject"));

	return iRetCode;
}
/**********************************************************************************
// Function    	 : TIAUTO_get_approval_report_data()
// Description 	 : Server exit call to get the report data for the given job name
// Input Parms 	 : JobName and Preference name for the task list 
// Return Parms  : String array of the report data						
/**********************************************************************************/
extern int TIAUTO_get_approval_report_data(void *returnValue)
{
	int     iRetCode 		= 0;	
	char 	*pcJobName 		= NULL;
	char 	*pcPrefName 	= NULL;
	char 	**pcReportData 	= NULL;
	char 	**pcPrefValues 	= NULL;
	char 	**pcTaskNames 	= NULL; 
	char 	**pcTaskGroups 	= NULL;
	char 	**pcTaskRoles 	= NULL; 
	int		iTaskArraySize 	= 0;	
	int 	iArraySize 		= 0;	
	int 	iPrefCnt 		= 0;	
	USERSERVICE_array_t arrayStruct;
	
	//Get the job name
	TIAUTO_ITKCALL(iRetCode, USERARG_get_string_argument(&pcJobName));
	//Get the preference for the list of tasks to be displayed for the report
	TIAUTO_ITKCALL(iRetCode, USERARG_get_string_argument(&pcPrefName));
	//Get the preference values
	if(pcPrefName != NULL && pcJobName != NULL)
	{
		int inx = 0;
		TIAUTO_ITKCALL(iRetCode, PREF_ask_char_values(pcPrefName, &iPrefCnt, &pcPrefValues));
		for(inx = 0; inx < iPrefCnt; inx++)
		{
			char	*pcTaskName 	= NULL;
			char 	*pcRole 		= NULL;
			char 	*pcGroup 		= NULL;
			
			pcTaskName = tc_strtok(pcPrefValues[inx], ",");
			pcRole = tc_strtok(NULL, ",");
			pcGroup = tc_strtok(NULL, ",");
			iTaskArraySize = (iTaskArraySize) + 1;
			//Task Names
			pcTaskNames = (char**) MEM_realloc(pcTaskNames, sizeof(char*) * iTaskArraySize );
			pcTaskNames[iTaskArraySize - 1] = (char*)MEM_alloc(sizeof(char) * ((int)tc_strlen(pcTaskName) + 1 ));
			tc_strcpy(pcTaskNames[iTaskArraySize - 1], pcTaskName);
			//Group Names
			pcTaskGroups = (char**) MEM_realloc(pcTaskGroups, sizeof(char*) * iTaskArraySize );
			pcTaskGroups[iTaskArraySize - 1] = (char*) MEM_alloc( sizeof(char) * ( (int)tc_strlen(pcGroup) + 1 ) );
			tc_strcpy(pcTaskGroups[iTaskArraySize - 1], pcGroup);
			//Roles Names
			pcTaskRoles = (char**) MEM_realloc(pcTaskRoles, sizeof(char*) * iTaskArraySize );
			pcTaskRoles[iTaskArraySize - 1] = (char*) MEM_alloc( sizeof(char) * ( (int)tc_strlen(pcRole) + 1 ) );
			tc_strcpy(pcTaskRoles[iTaskArraySize - 1], pcRole);
		}		
		if(iRetCode == ITK_ok && iTaskArraySize > 0)
		{
			int 	iRowCnt 	= 0;
			int 	iColCnt 	= 0;
			void***	report		= NULL;
			
			//Query to get the workflow audit information for the given job name
			TIAUTO_ITKCALL(iRetCode, TITAUTO_GetAuditInfo(pcJobName, &iRowCnt, &iColCnt, &report));
			if(iRetCode == ITK_ok && iRowCnt > 0)
			{
				//Process the query data to get the output in the required format
				TIAUTO_ITKCALL(iRetCode, TITAUTO_ProcessAuditInfo(iRowCnt, report, pcTaskNames, pcTaskGroups, pcTaskRoles, iTaskArraySize, &iArraySize, &pcReportData));
			}
			SAFE_MEM_free(report);
			
		}
	}	
    EMH_clear_errors();	
	USERSERVICE_return_string_array((const char**)pcReportData, iArraySize, &arrayStruct);
    if (arrayStruct.length != 0)
	{
		*((USERSERVICE_array_t*) returnValue) = arrayStruct;
	}
	SAFE_MEM_free(pcJobName);
	SAFE_MEM_free(pcPrefName);	
	SAFE_MEM_free(pcReportData);
	SAFE_MEM_free(pcTaskNames);
	SAFE_MEM_free(pcTaskGroups);
	SAFE_MEM_free(pcTaskRoles);
	SAFE_MEM_free(pcPrefValues);
	return iRetCode;
}
