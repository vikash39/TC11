
/*******************************************************************************
FILE        :   tiauto_rh_check_valid_erp_plant.c
Details     :   This is a dummy rule handler. This is used to check whether a
				perticular task is assigned to user that matches with the role
				and group name mentioned in the handler argument during apply
				assignment

REVISION HISTORY :

Date              Revision        Who						Description
Sept  2, 2011     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_valid_erp_plant(EPM_rule_message_t msg )
{
    int iRetCode = ITK_ok;
	boolean bValidERPPlant = false;
	boolean bMfgRelToBeCreated = false;
	char *pcErrMsg = NULL;
	char *pcValidReleaseStatusList = NULL;
	EPM_decision_t decision = EPM_go;
	tag_t tRootTask = NULLTAG;
	char   acRootTaskName[WSO_name_size_c + 1] = "";

	//get the root task
	iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	if( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0)
	{
		iRetCode = verify_Valid_ERP_Plant(msg.task,&bValidERPPlant,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else if(tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0 )
	{
		iRetCode = verify_Valid_PRA_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else
	{
		iRetCode = verify_Valid_MRA_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	
	//if there are any ITK failure
	if ( iRetCode != ITK_ok && iRetCode != EPM_invalid_argument_value)
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	//Conditional Task result decision
	//if (iRetCode == ITK_ok && bMfgRelToBeCreated == true)// bValidERPPlant == true && bMfgRelToBeCreated == true && iRetCode == ITK_ok)	
	if ( iRetCode == ITK_ok && ( (bMfgRelToBeCreated == true && 
										( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0  ||
										tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0) ||
										( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0 )) ||
				( ( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || 
				   tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0) && 
				   bValidERPPlant == true && bMfgRelToBeCreated == true ) ) )
	{
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_TRUE);
	}
	else if ( bValidERPPlant == true && bMfgRelToBeCreated == false && iRetCode == ITK_ok)	
	{
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
	}
	else if(bValidERPPlant == false || iRetCode != ITK_ok)
	{					
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
	}
    
	return decision;
}
