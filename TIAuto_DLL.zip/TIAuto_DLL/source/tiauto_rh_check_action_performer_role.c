
/*******************************************************************************
FILE        :   tiauto_rh_check_action_performer_role.c
Details     :   This is a dummy rule handler. This is used to check whether a
				perticular task is assigned to user that matches with the role
				and group name mentioned in the handler argument during apply
				assignment

REVISION HISTORY :

Date              Revision        Who						Description
Sept  2, 2011     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_action_performer_role(EPM_rule_message_t msg )
{
	EPM_decision_t decision = EPM_go;


	return decision;
}
