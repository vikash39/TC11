/************************************************************************************************
FILE        :   tiauto_verify_related_revisions.c

DESCRIPTION :   This rule handler validates the Document revision/Altrep revision in the
				�Affected Items� and the �Solutions Items� folders of the target change
				revision. If the target is Document Revision or AltRep revision then it
				validates the target Document Revision or AltRep Revision.  It validates
				the Document revision/Altrep revision by checking the "Related Revisions"
				Folder under the document revision/Altrep revision. The document revision
				and AltRep revision are valid if it contains atleast one item revision in
				the �Related Revisions� folder. If the Document revision/Altrep revision
				does not contain any item revision in the "Related Revisions" Folder, then
				the rule handler throws appropriate error message to the user.

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
Feb 03, 2009    1.0        Dipak Naik       Initial Creation
Mar 26, 2012	1.1		   Dipak Naik		Modified the code to work when attached to the
											perform action of the task.
Feb 19, 2014	1.2		   Shruti			Modified the code according to the ER - 7468
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t t1aAUTO_verify_related_revisions(EPM_rule_message_t msg)
{
    int		iRetCode									=	ITK_ok;
	int		iNumArgs									=	0;
	int     iNumAffected								=	0;
	int     iNumAttachments								=	0;
	int		iAttachmentIndex							=   0;
	int		iCheck										=	0;
	int		iLovs										=	0;
	int		iLovValues									=	0;
	int     iLovValuesIndex								=   0;

	EPM_decision_t decision								=	EPM_go;

	char	*pcUserName									= NULL;
	char	*pcTaskTypeName								= NULL;

	char	acParentType[TCTYPE_name_size_c+1]			=	 "";
	char    actypeName[TCTYPE_name_size_c+1]			=	 "";
	char    acErrorString[TIAUTO_error_message_len+1]	=	 "";

	char	*pcErrMsg									=	 NULL;
	char	**pcLovValues								=	NULL;

	TIA_ErrorMessage *currErrMsg						=	 NULL;

    tag_t	tUser										= NULLTAG;
    tag_t	tTaskType									= NULLTAG;
	tag_t   tRootTask									=	NULLTAG;

    tag_t   *ptattachmentTags							=	NULL;
	tag_t   *ptAffectedItems							=	NULL;
	tag_t	*ptLovs										=	NULL;

	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}
	/* get the number of arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if(iNumArgs == 0)
    {
		/* get the root task */
		iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
		/* get the target attachment */
		if (iRetCode == ITK_ok)
			iRetCode = EPM_ask_attachments( tRootTask,EPM_target_attachment,
											&iNumAttachments,&ptattachmentTags );

		if(iNumAttachments > 0)
		{
			//get the object types list from the LOV T8_ObjectTypes
			iRetCode = LOV_find( "T8_VerifyRelatedRevisions" ,&iLovs,&ptLovs);

			if (iRetCode == ITK_ok && ptLovs != NULL)
				iRetCode = LOV_ask_values_string (ptLovs[0],&iLovValues ,&pcLovValues);
		}
		
		for (iAttachmentIndex = 0; iAttachmentIndex < iNumAttachments && (iRetCode == ITK_ok); iAttachmentIndex++)
		{
			/* get the object type */
			iRetCode = WSOM_ask_object_type(ptattachmentTags[iAttachmentIndex], actypeName);
			if( ( (tc_strcasecmp (actypeName , CHANGE_REV)== 0) || (tc_strcasecmp (actypeName , NEWCHANGE_REV)== 0)) && (iRetCode == ITK_ok) )
			{
				/* get the objects in the solution and the affected items folder */
				iRetCode = ECM_get_affected_items(ptattachmentTags[0], &iNumAffected, &ptAffectedItems);
				if( iRetCode == ITK_ok)
				{
					for(iCheck = 0; iCheck < iNumAffected && (iRetCode == ITK_ok) ; iCheck++ )
					{
						tc_strcpy(acParentType,"");
						/* get the object type */
						iRetCode = WSOM_ask_object_type (ptAffectedItems[iCheck], acParentType);
						for (iLovValuesIndex = 0; iLovValuesIndex < iLovValues && (iRetCode == ITK_ok); iLovValuesIndex++)
						{
							if (tc_strcasecmp( acParentType , pcLovValues[iLovValuesIndex])== 0 && (iRetCode == ITK_ok) )
							{
								iRetCode = check_related_revision_folder(ptAffectedItems[iCheck], &currErrMsg );
								break;
							}
						}
						/*if (tc_strcasecmp( acParentType , ALTREP_REV)== 0 && (iRetCode == ITK_ok) )
						{
							iRetCode = check_related_revision_folder(ptAffectedItems[iCheck], &currErrMsg );
						}
						if (tc_strcasecmp( acParentType , ALTTOOL_REV)== 0 && (iRetCode == ITK_ok) )
						{
							iRetCode = check_related_revision_folder(ptAffectedItems[iCheck], &currErrMsg );
						}
						if (tc_strcasecmp( acParentType , "T8_TI_AltConstr Revision" )== 0 && (iRetCode == ITK_ok) )
						{
							iRetCode = check_related_revision_folder(ptAffectedItems[iCheck], &currErrMsg );
						}*/
						//else if(iRetCode == ITK_ok)
						//{
						//	/* get the object type */
						//	iRetCode = TCTYPE_ask_object_type(ptAffectedItems[iCheck], &tObjectType );
						//	/* get the parent type tag*/
						//	if (iRetCode == ITK_ok)
						//		iRetCode = TCTYPE_ask_parent_type(tObjectType, &tParentType);
						//	/* get the parent type name*/
						//	if (iRetCode == ITK_ok)
						//		iRetCode = TCTYPE_ask_name(tParentType, acParentType);
						//	if (tc_strcasecmp( acParentType , DOCUMENT_REV)== 0 && (iRetCode == ITK_ok) )
						//	{
						//		iRetCode = check_related_revision_folder( ptAffectedItems[iCheck], &currErrMsg );
						//	}
						//}
					}

				}
			}
			else
			{
				for (iLovValuesIndex = 0; iLovValuesIndex < iLovValues && (iRetCode == ITK_ok); iLovValuesIndex++)
				{
					if (tc_strcasecmp( actypeName , pcLovValues[iLovValuesIndex])== 0 && (iRetCode == ITK_ok) )
					{
						iRetCode = check_related_revision_folder(ptattachmentTags[iAttachmentIndex], &currErrMsg );
						break;
					}
				}
			}
			/*else if (tc_strcasecmp( actypeName , ALTREP_REV)== 0 && (iRetCode == ITK_ok) )
			{
				iRetCode = check_related_revision_folder(ptattachmentTags[iAttachmentIndex], &currErrMsg );
			}
			else if (tc_strcasecmp( actypeName , ALTTOOL_REV)== 0 && (iRetCode == ITK_ok) )
			{
				iRetCode = check_related_revision_folder(ptattachmentTags[iAttachmentIndex], &currErrMsg );
			}
			else if (tc_strcasecmp( actypeName , "T8_TI_AltConstr Revision")== 0 && (iRetCode == ITK_ok) )
			{
				iRetCode = check_related_revision_folder(ptattachmentTags[iAttachmentIndex], &currErrMsg );
			}*/
			//else if (iRetCode == ITK_ok)
			//{
			//	/* get the object type */
			//	iRetCode = TCTYPE_ask_object_type(ptattachmentTags[iAttachmentIndex], &tObjectType );
			//	/* get the parent type tag*/
			//	if (iRetCode == ITK_ok)
			//		iRetCode = TCTYPE_ask_parent_type(tObjectType, &tParentType);
			//	/* get the parent type name*/
			//	if (iRetCode == ITK_ok)
			//		iRetCode = TCTYPE_ask_name(tParentType, actypeName);
			//	if (tc_strcasecmp( actypeName , DOCUMENT_REV)== 0 && (iRetCode == ITK_ok) )
			//	{
			//		iRetCode = check_related_revision_folder( ptattachmentTags[iAttachmentIndex], &currErrMsg );
			//	}
			//}
		}
	}
	else
	{
        iRetCode = TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER;
	}
	/* if ITK error during the handler exceution */
    if( iRetCode != ITK_ok )
	{
		decision = EPM_nogo;
		if( iRetCode == TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER )
		{
			TI_sprintf(acErrorString, "No Arguments allowed to \"TIAUTO-verify-related-revisions\" handler.");
			TC_write_syslog (acErrorString);
			EMH_store_error_s1(EMH_severity_error, TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER , acErrorString);
		}
		else
		{
			EMH_ask_error_text(iRetCode, &pcErrMsg );
			EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
			SAFE_MEM_free (pcErrMsg);
		}
	}

	if( currErrMsg != NULL)
	{
		decision = EPM_nogo;
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
		iRetCode = TIAUTO_VERIFY_RELATED_REVISIONS_ERROR;
		TI_sprintf( acErrorString, "To fix this problem, Please add at least one item revision to the Related Revisions folder for the above item revisions."  );
		EMH_store_error_s1(EMH_severity_error, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString );
		while(currErrMsg)
		{
			EMH_store_error_s1(EMH_severity_error, currErrMsg->iRetCode, currErrMsg->errMsg);
			TC_write_syslog(currErrMsg->errMsg);
			TC_write_syslog("\n");
         	currErrMsg = currErrMsg->next;
		}

	}

	SAFE_MEM_free (ptAffectedItems);
	SAFE_MEM_free (ptattachmentTags);
	SAFE_MEM_free (currErrMsg);
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);
	SAFE_MEM_free (ptLovs);
	SAFE_MEM_free (pcLovValues);

	return decision;
}
