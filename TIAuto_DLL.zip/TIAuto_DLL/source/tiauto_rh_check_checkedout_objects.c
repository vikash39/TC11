/*******************************************************************************
File         : tiauto_rh_check_checkedout_objects.c

Description  : This rule handler validates the targeted object on which the workflow
                is initiated whether the targeted object and it's secondary objects 
				such as Datasets, Forms etc� that are checked out or not. If there are 
				checked out objects then this rule handler will provide appropriate 
				error message to the user. 
				Arguments:
				-type=<targeted object type on which the workflow is initiated>
				-relation=<relation name>
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who					  Description
*******************************************************************************
Dec 29, 2011    1.0         Dipak Naik		      Initial Creation
Feb 20, 2017	1.1			Shilpa				  ER#9144 - Documents Revisions has been converted to primary
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <stdio.h>
#include <res/res_itk.h>
#include <tiauto_defines.h>

int Validate_Secondary_Objects(int iNumAffected,tag_t *ptAffectedObjects,char *pcFolderName,
							  logical *lValidationFailed,TIA_ErrorMessage **pstCurrErrMsg);
int Is_Checked_out(tag_t tObject,logical *lIsCheckedOut,char **pcCheckedOutUserName,char **pcCheckedOutDate);

//---------------------------------------------------------------------------------------------------
//Main method for the rule handler "TIAUTO-RH-check-checkedout-objects"
//---------------------------------------------------------------------------------------------------
EPM_decision_t TIAUTO_RH_check_checkedout_objects(EPM_rule_message_t message)
{
    int		iFail					= ITK_ok;
	int		iNumAffected			= 0;
	int		iAttchCntr				= 0;
	int		iNumArgs				= 0;
	int		indx = 0;
	int		iRelNameCount			= 0;
	int		iNumAttachments		= 0;

	tag_t	tRelation				= NULLTAG;	
	tag_t	tTargetObject			= NULLTAG;
	tag_t	tTargetObjectType		= NULLTAG;
	tag_t	tRootTask				= NULLTAG;
	tag_t	*ptAffectedObjects		= NULL;
	tag_t	*ptAttachments = NULL;

	char	acErrorString[512]		= "";
	char    pszObject[WSO_name_size_c+1]="";
	char	*pcValue				= NULL;
    char	*pcFlag					= NULL;
	char	*pcTypeName				= NULL;	
	char	*pcRelation				= NULL;
	char	*pcPseudoFolderName		= NULL;
	char	*pcErrMsg				= NULL;
	char	*pcTemp					= NULL;
	char	**pcRelationNames		= NULL;	
	char	*pcCheckedOutUserName		= NULL;
	char	*pcCheckedOutDate			= NULL;
	char	*pcObjectName				= NULL;
	
	logical	lValidationFailed		= false;
	logical lTargetObjCheckedOut    = false;
	TIA_ErrorMessage *pstCurrErrMsg = NULL;
	TIA_ErrorMessage *tempErrMsg	= NULL;

	EPM_decision_t decision = EPM_go;	

	tag_t	tGroupmember = NULLTAG;
	tag_t tGroup = NULLTAG;
	char          acUserGroup[SA_group_name_size_c + 1] = "";
	
	if(iFail == ITK_ok)
		iFail = SA_ask_current_groupmember(&tGroupmember);

	
	if(iFail == ITK_ok && tGroupmember != NULLTAG)
		iFail = SA_ask_groupmember_group(tGroupmember, &tGroup);

	if(iFail == ITK_ok && tGroup != NULLTAG)
	    iFail = SA_ask_group_name(tGroup, acUserGroup);

	if(tc_strcmp(acUserGroup,"dba") == 0)
	{
		decision = EPM_go;
		return decision;
	}

	iNumArgs = TC_number_of_arguments(message.arguments);
  
    if (iNumArgs == 2)
	{
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iFail = ITK_ask_argument_named_value(TC_next_argument(message.arguments), &pcFlag, &pcValue );
			if ( iFail == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag, "type") == 0 && pcValue != NULL)
				{
					pcTypeName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTypeName, pcValue);
				}
				else if( tc_strcasecmp(pcFlag, "relation") == 0 && pcValue != NULL)
				{
					pcRelation = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcRelation, pcValue);
				}
				else
				{
					iFail = EPM_invalid_argument;
				}
			}
		}
	}
	else
	{
		iFail = EPM_wrong_number_of_arguments;
	}
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcValue);
	if(iFail == ITK_ok && ((pcTypeName == NULL) || (pcRelation == NULL)) )
	{
		iFail = EPM_invalid_argument;
		decision = EPM_nogo;
	}
	//get the targeted object
	if (iFail == ITK_ok )
	{
		iFail = EPM_ask_root_task(message.task , &tRootTask);
	}
	if (iFail == ITK_ok && tRootTask != NULLTAG)
	{
		iFail = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments,&ptAttachments);
	}
	for (indx = 0; indx < iNumAttachments && (iFail == ITK_ok); indx++)
    {
        iFail = WSOM_ask_object_type(ptAttachments[indx], pszObject);
        if (iFail == ITK_ok && tc_strcmp (pszObject, pcTypeName) == 0 )
        {
            tTargetObject = ptAttachments[indx];
            break;  
        }
    }
	if(tTargetObject == NULLTAG)
	{
		return decision;
	}
	if(iFail == ITK_ok && pcRelation != NULL)
	{
		pcRelationNames = (char **)malloc(10* sizeof(char *));			
		pcTemp = tc_strtok (pcRelation,",");
		//to remove the forward and trailing space
		//remove_forward_AND_trailing_space(pcTemp);
		while(pcTemp != NULL && iFail == ITK_ok)
		{
			//to remove the forward and trailing space
			//remove_forward_AND_trailing_space(pcTemp);
			//validate the input argument value				
			iFail = AOM_ask_descriptor (tTargetObject,pcTemp,&tRelation);
			if(iFail == ITK_ok && tRelation != NULLTAG)
			{
				pcRelationNames[iRelNameCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
				tc_strcpy(pcRelationNames[iRelNameCount],pcTemp);			
				iRelNameCount++;					
				pcTemp = tc_strtok(NULL,",");
			}
			else
			{
				iFail = EPM_invalid_argument_value;
				TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"relation\".");
				EMH_store_error_s1( EMH_severity_error, iFail, acErrorString) ;						
				TC_write_syslog(acErrorString);
				decision = EPM_nogo;
				break;
			}
		}	
	}
	if(iFail == ITK_ok && pcTypeName != NULL)
	{
		iFail = TCTYPE_find_type (pcTypeName,NULL,&tTargetObjectType);
		if(tTargetObjectType == NULLTAG)
		{
			iFail = EPM_invalid_argument_value;
			TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"type\".");
			EMH_store_error_s1( EMH_severity_error, iFail, acErrorString) ;						
			TC_write_syslog(acErrorString);
			decision = EPM_nogo;
		}
	}	

	if (iFail == ITK_ok && tTargetObject != NULLTAG && pcRelation != NULL)
	{			
		//Validate the secondary objects are checked-out or not	
		for(iAttchCntr = 0; (iAttchCntr < iRelNameCount) && (iFail == ITK_ok); iAttchCntr++)
		{
			tRelation = NULLTAG;
			iNumAffected = 0;
			iFail = GRM_find_relation_type (pcRelationNames[iAttchCntr],&tRelation);
			if(iFail == ITK_ok)
				iFail = TCTYPE_ask_display_name   (tRelation,&pcPseudoFolderName);
			if( iFail == ITK_ok) 
			{
				iFail = GRM_list_secondary_objects_only(tTargetObject,tRelation,&iNumAffected,&ptAffectedObjects);
			}
			if(iFail == ITK_ok && iNumAffected > 0)
			{
				iFail = Validate_Secondary_Objects(iNumAffected,ptAffectedObjects,pcPseudoFolderName,&lValidationFailed,&pstCurrErrMsg);
			}
			SAFE_MEM_free(ptAffectedObjects);
			SAFE_MEM_free(pcPseudoFolderName);
			
		}					
		
		iFail = Is_Checked_out(tTargetObject,&lTargetObjCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
		if(iFail == ITK_ok && lTargetObjCheckedOut == true)
		{
			iFail = WSOM_ask_object_id_string (tTargetObject,&pcObjectName);
			TI_sprintf(acErrorString, "The targeted object \"%s\" is checked out by \"%s\" on \"%s\".",pcObjectName,pcCheckedOutUserName,pcCheckedOutDate); 
			tiauto_writeErrorMsgToStack(&pstCurrErrMsg, TIAUTO_CHECKEDOUT_ERROR, acErrorString);
			SAFE_MEM_free(pcObjectName);
			free(pcCheckedOutUserName);
			SAFE_MEM_free(pcCheckedOutDate);
		}
	}
	
	if(pcRelation != NULL)
	{
		SAFE_MEM_free(pcRelation);
	}
	if(pcRelationNames != NULL)
	{
		free(pcRelationNames);
		pcRelation = NULL;
	}
	
	if( iFail != ITK_ok && iFail != EPM_invalid_argument_value)
	{
		decision = EPM_nogo;
		EMH_ask_error_text(iFail, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iFail,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}

	/* if the validation failed */
	if( iFail == ITK_ok && ((lValidationFailed == true)||(lTargetObjCheckedOut == true)) )
	{
		decision = EPM_nogo;
		iFail = TIAUTO_CHECKEDOUT_ERROR;
		TI_sprintf( acErrorString, "\nPlease check-in the checked-out objects before completing the task. "  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_CHECKEDOUT_ERROR, acErrorString );
		
		tempErrMsg = pstCurrErrMsg;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
		tiauto_clearErrorMsgStack(pstCurrErrMsg);
	}
		
	return decision;
}

//-----------------------------------------------------------------------------------------------------
// This method checks whether any objects present in the pseudo folder including their secondary objects
// are checked out and remote object. If either any object or their secondary object is checked out/
// remote object, then error message will be displayed
//-----------------------------------------------------------------------------------------------------
int Validate_Secondary_Objects( int		iNumAffected,				/*<I>*/
							   tag_t	*ptAffectedObjects,			/*<I>*/
							   char		*pcFolderName,				/*<I>*/
							   logical	*lValidationFailed,			/*<O>*/
							   TIA_ErrorMessage **pstCurrErrMsg)	/*<O>*/
{
	int		iFail						= ITK_ok;
	int		iAffCntr					= 0;

	tag_t	tItem						= NULLTAG;

	char	*pcClassName				= NULL;
	char	*pcCheckedOutUserName		= NULL;
	char	*pcCheckedOutDate			= NULL;
	char	*pcObjName					= NULL;
	char	acItemId[ITEM_id_size_c+1]	= "";
	char	acRevId[ITEM_id_size_c+1]	= "";
	char	acErrorString[512]			= "";
	
	logical lCheckedOut					= false;		
	
	for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iFail == ITK_ok) ; iAffCntr++)
	{
		lCheckedOut = false;
		pcCheckedOutUserName = NULL;
		pcCheckedOutDate = NULL;
		//get the classname of the object
		if (iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG )
			iFail = tiauto_get_class_name_of_instance (ptAffectedObjects[iAffCntr], &pcClassName);
		//getting parent class if the class name is NOT ITEM or ITEMREVISION
			if ((tc_strcmp (pcClassName,TIAUTO_ITEM) != 0) || (tc_strcmp (pcClassName,TIAUTO_ITEMREVISION) != 0))
			{
				tag_t	tTargetType					= NULLTAG;

				if(iFail == ITK_ok)
				{
					TIAUTO_ITKCALL(iFail,TCTYPE_ask_object_type(ptAffectedObjects[iAffCntr],&tTargetType));
				}
				if(tTargetType != NULLTAG)
				{
					tag_t	tParentType					= NULLTAG;

					TIAUTO_ITKCALL(iFail,TCTYPE_ask_parent_type(tTargetType,&tParentType));
					if(tParentType != NULLTAG)
					{
						SAFE_MEM_free(pcClassName);
						TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tParentType, &pcClassName));
					}
				}
						
			}		

		//check if the classname of the targeted object pseudo folder is Item or Document
		if((iFail == ITK_ok)  && ((tc_strcasecmp (pcClassName , TIAUTO_ITEM)== 0) || (tc_strcasecmp (pcClassName , TIAUTO_TI_DOCUMENT)== 0)))
		{
			tc_strcpy(acItemId,"");
			// get item id string 
			if(iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG)
				iFail = ITEM_ask_id(ptAffectedObjects[iAffCntr], acItemId);			
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			//if object is checked out, store the error message in the error stack
			if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The item \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",acItemId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}
		}
		// check if the classname of the targeted object pseudo folder is ItemRevision
		else if((iFail == ITK_ok)  && ((tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) ||  (tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
		{	
			// get item tag
			iFail = ITEM_ask_item_of_rev(ptAffectedObjects[iAffCntr], &tItem);
			// get item id string 
			if(iFail == ITK_ok && tItem != NULLTAG)
				iFail = ITEM_ask_id(tItem, acItemId);
			// get item rev id string 
			if( iFail == ITK_ok)
				iFail = ITEM_ask_rev_id(ptAffectedObjects[iAffCntr],acRevId );
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The item revision \"%s/%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",acItemId,acRevId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_ERROR, acErrorString);
				*lValidationFailed = true;
				lCheckedOut = false;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}
		}
		// check if the classname of the targeted object pseudo folder is Form		
		else if((iFail == ITK_ok)  && (tc_strcasecmp (pcClassName , "Form")== 0) )
		{
			//get form name 
			if(iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG)
				iFail = AOM_ask_name(ptAffectedObjects[iAffCntr],&pcObjName); 
			
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			if( iFail == ITK_ok && lCheckedOut == false )
			{
			}
			else if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The Form \"%s\" attached to the targeted object with \"%s\" relation is checked out by \"%s\" on \"%s\".",pcObjName,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_ERROR, acErrorString);
				*lValidationFailed = true;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}			
			SAFE_MEM_free(pcObjName);
		}
		SAFE_MEM_free(pcClassName);
	}

	return iFail;
}
//-----------------------------------------------------------------------------------------------------
// This method checks whether any objects is checked-out or not. If the object is checked-out, then
// a true flag along with the checked-out user name and the date on which the object is  
// checked out will be returned
//-----------------------------------------------------------------------------------------------------
int Is_Checked_out(tag_t		tObject,					/*<I>*/
						  logical	*lIsCheckedOut,				/*<O>*/
						  char		**pcCheckedOutUserName,		/*<O>*/
						  char		**pcCheckedOutDate)			/*<O>*/
{
	int		iFail							= ITK_ok;
	tag_t	tCheckedOutUser					= NULLTAG;
	tag_t	tCheckedOutGroup				= NULLTAG;
	char	acOSUserName[SA_name_size_c+1]	= "";

	*lIsCheckedOut = false;
	// check if item revision is checked out
	if ( iFail == ITK_ok && tObject != NULLTAG)
		iFail = RES_is_checked_out( tObject, lIsCheckedOut );
	if( iFail == ITK_ok && *lIsCheckedOut == true)
	{
		iFail = RES_who_checked_object_out (tObject,&tCheckedOutUser,&tCheckedOutGroup);
		if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
		{
			iFail = SA_ask_user_person_name (  tCheckedOutUser, acOSUserName );
			if ( iFail == ITK_ok)
			{
				*pcCheckedOutUserName = (char *)malloc((int)tc_strlen(acOSUserName)+1);
				tc_strcpy(*pcCheckedOutUserName,acOSUserName);
			}
		}
		if ( iFail == ITK_ok)
		{
			iFail = AOM_UIF_ask_value  (tObject,"checked_out_date",pcCheckedOutDate);
		}
	}
	return iFail;
}