/*******************************************************************************
File         : t1aAUTO_ah_update_affected_program_info_on_pci.c

Description  :

Input        : None

Output       : None

Author       : TCS

Revision History :
Date			  Revision		Who              Description
*******************************************************************************
14th Jul, 2016	  1.0           Pradeep          Initial Creation
Nov 23 2018		  1.1		    Jugunu          Updated for ER 9759 CAP3

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TAUTO_AH_Update_Affected_Program_Info_On_PCI(EPM_action_message_t msg)
{
	int				iRetCode									= ITK_ok;
	int				i											= 0;
	int				j											= 0;
	int				k											= 0;
	int             iTargetAttachments							= 0;
	int				iSecObjs									= 0;
	int             iNumAffPgrmValues							= 0;
	int             iNumAffPlants								= 0;
	tag_t           tCurrentTask								= NULLTAG;
	tag_t           tRootTask									= NULLTAG;
	tag_t           tBasedOnChgRev								= NULLTAG;
	tag_t			tRelationType								= NULLTAG;
	tag_t*          ptTargetAttachments							= NULL;
	tag_t*			ptSecObjs									= NULL;
	char			acObjectType[WSO_name_size_c+1]				= "";
	char**			pcAffectedProgramValues						= NULL;
	char**			pcAffectedPlants							= NULL;
	logical         lIsFound									= false;
	logical			lHasAccess									= false;
	int iDrwSecObjs = 0;
	tag_t *ptDrwSecObjs = NULL;
	tag_t tDrwRelationType = NULLTAG;
	tag_t tPCI = NULLTAG;

	tCurrentTask = msg.task;
	iRetCode = EPM_ask_root_task (tCurrentTask, &tRootTask);

	if (iRetCode == 0 && tRootTask != NULLTAG)
	{
		iRetCode = EPM_ask_attachments (tRootTask, EPM_target_attachment, &iTargetAttachments, &ptTargetAttachments);
		if (iRetCode == 0 && iTargetAttachments>0)
		{
			for (i; i<iTargetAttachments; i++)
			{
				iRetCode = WSOM_ask_object_type (ptTargetAttachments[i], acObjectType);
				if (iRetCode == ITK_ok && tc_strcmp(acObjectType, NEWCHANGE_REV) == 0 )
				{
					iRetCode = WSOM_ask_based_on (ptTargetAttachments[i], &tBasedOnChgRev);
					if (iRetCode == ITK_ok && tBasedOnChgRev != NULLTAG)
					{
						iRetCode = GRM_find_relation_type("IMAN_specification", &tRelationType);
						if (iRetCode == ITK_ok && tRelationType != NULLTAG)
						{
							iRetCode =  GRM_list_secondary_objects_only (tBasedOnChgRev , tRelationType, &iSecObjs, &ptSecObjs);
							for (j=0;j<iSecObjs && iRetCode == ITK_ok;j++)
							{
								tc_strcpy(acObjectType,"");
								iRetCode = WSOM_ask_object_type (ptSecObjs[j], acObjectType);

								if (iRetCode == ITK_ok)
								{
									if (tc_strcmp(acObjectType, "T8_TI_CAP") == 0)
									{
										lIsFound = true;
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_t1a120affectedprograms",&iNumAffPgrmValues,&pcAffectedProgramValues);
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_120tiplant",&iNumAffPlants,&pcAffectedPlants);
									}
									if (tc_strcmp(acObjectType, "T8_TI_CAP2") == 0)
									{
										lIsFound = true;
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_t1a190affectedprograms",&iNumAffPgrmValues,&pcAffectedProgramValues);
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_t1a190affectedplants",&iNumAffPlants,&pcAffectedPlants);
									}
									//adding CAP3 changes
									if (tc_strcmp(acObjectType, "T8_TI_CAP3") == 0)
									{
										lIsFound = true;
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_t1a190affectedprograms",&iNumAffPgrmValues,&pcAffectedProgramValues);
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_t1a190affectedplants",&iNumAffPlants,&pcAffectedPlants);
									}
									if (tc_strcmp(acObjectType, "TT_PMR") == 0)
									{
										lIsFound = true;
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t1A84affectedprogram",&iNumAffPgrmValues,&pcAffectedProgramValues);
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_84tiplant",&iNumAffPlants,&pcAffectedPlants);
									}
									if (tc_strcmp(acObjectType, "T8_TI_PMR") == 0)
									{
										lIsFound = true;
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_193affectedprogram",&iNumAffPgrmValues,&pcAffectedProgramValues);
										iRetCode = AOM_ask_value_strings  (ptSecObjs[j],"t8_193tiplant",&iNumAffPlants,&pcAffectedPlants);
									}
									if (iRetCode == ITK_ok && lIsFound == true)
										break;
								}
							}
							iSecObjs = 0;
							SAFE_MEM_free(ptSecObjs);
							iRetCode =  GRM_list_secondary_objects_only (ptTargetAttachments[i] , tRelationType, &iSecObjs, &ptSecObjs);
							for (k=0;k<iSecObjs && iRetCode == ITK_ok;k++)
							{
								tc_strcpy(acObjectType,"");
								iRetCode = WSOM_ask_object_type (ptSecObjs[k], acObjectType);

								if (iRetCode == ITK_ok && tc_strcmp(acObjectType,"T8_TI_PCI") == 0)
								{
									tPCI = ptSecObjs[k];
									break;
								}
							}
							if(tPCI != NULLTAG)
							{
								iRetCode = AM_check_privilege(tPCI,"WRITE",&lHasAccess);
								if(lHasAccess == true)
								{
									iRetCode = AOM_refresh(tPCI,true);

									if(iNumAffPgrmValues > 0)
										iRetCode = AOM_set_value_strings (tPCI, "t8_123affectedprograms", iNumAffPgrmValues, pcAffectedProgramValues);

									if(iNumAffPlants > 0)
										iRetCode = AOM_set_value_strings (tPCI, "t8_t1a123affectedplant", iNumAffPlants,pcAffectedPlants);

									//drawing items
									iRetCode = GRM_find_relation_type("T8_CMTIDrawingItems", &tDrwRelationType);
									iRetCode =  GRM_list_secondary_objects_only (tBasedOnChgRev , tDrwRelationType, &iDrwSecObjs, &ptDrwSecObjs);
									if(iDrwSecObjs > 0)
									{
										iRetCode = AOM_set_value_string (tPCI, "t8_t1a123updateddrawings", "Yes");
									}
									iRetCode = AOM_save(tPCI);
									iRetCode = AOM_refresh(tPCI,false);
								}
							}
						}
					}
				}
			}
		}
		SAFE_MEM_free(ptTargetAttachments);
	}

	return iRetCode;
}
