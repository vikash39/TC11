/*******************************************************************************************************************************
File         : tiauto_demote_email.c

Description  : This action handler notify the responsible party via email when task is rejected by reviewer.
  
Input        : None
                        
Output       : None

Author       : Arun Kumar,TCS

Revision History :
Date            Revision    Who              Description
Feb 09, 2008    1.0         Arun Kumar      Initial Creation
April 17, 2013  1.1         Pradeep M       Group / Role of user who rejected the change and the following details
											name of User who rejected the change
											Task at which the change was rejected
											Comments made by user who rejected the change
Jun 21,2019     1.2        Trisha Saha     Updated attachments with signoff_attachments for Mail to users
***************************************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <stdio.h>

#define INIT_LIST_SIZE         200


FILE *auditFilefp       =   NULL;
FILE *auditFilefp2      =   NULL;
//Function prototype
void release_string_array( int count,  char **list  );
//int getItemRevDetails(tag_t tItemRev, char *pcItemId,char *pcRevId, char *pcName); 
static int mail_send_os_demote_mail( const char *subject,              /* <I> */
								counted_list_t receiverList,      /* <I> */
								const char *pcMailBodyFileName        /* <I> */
							);

int do_it();

int parseAuditFile(tag_t tAuditFile, tag_t tRootTaskTag, char **pcTempcomment_value, char **pcTempReposibleParty_Name,
				   char **pcTempReposibleParty_GroupName, char **cTempReposibleParty_RoleName, char **pcTempRejected_Task);
	


extern int t1aAUTO_demote_email(EPM_action_message_t msg)
{
    int retcode = ITK_ok;
	int iFileOpenErrCode = 0;
	int             iSite               = 0;
	int             iSiteID             = 0;

	tag_t tUser = NULLTAG; 
	tag_t tResp = NULLTAG;
	tag_t tEngChangeRev = NULLTAG;
	tag_t tRootTask = NULLTAG;
	tag_t tjob  = NULLTAG;
	tag_t taudit_file = NULLTAG;
	tag_t           tSitetag            = NULLTAG;

	char acChnId[ITEM_id_size_c+1] = {'\0'};
	char acChnRevId[ITEM_id_size_c+1]  = {'\0'};
	char acChnName[ITEM_name_size_c+1] = {'\0'};
	char acSubject[BUFSIZ + 1] = {'\0'};
	char acCurrRelLevel[WSO_name_size_c+1] = "";
	char acSiteName[SA_site_size_c+1]	= {'\0'};

	char *pcMailBodyFileName = NULL;
    char *comments = NULL;
	char *strUserName = NULL;
	char *pcComment = NULL;
	char *pcRespName = NULL;
	char *pcRespGroup = NULL;
	char *pcRespRole = NULL;
	char *pcRejected_Task = NULL;

	FILE *fMailBodyFile      = NULL;
	
    //txt_t the_text_server = NULL;

	counted_tag_list_t tRecipients;
	counted_list_t     tMailAddresses;    /* call MEM_free */
	counted_list_t     tFinalMailList;    /* call MEM_free */

	tRecipients.count    = 0;
	tMailAddresses.count = 0;

	tFinalMailList.count = 0;
	tFinalMailList.list  = 0;

	retcode = POM_site_id(&iSite);
	if(iSite != 0)
		retcode = SA_find_site_by_id(iSite,&tSitetag);
	if(retcode == ITK_ok && tSitetag!= NULLTAG)
		retcode = SA_ask_site_info(tSitetag,acSiteName,&iSiteID);

    if (retcode== ITK_ok)
		retcode = EPM_ask_responsible_party (msg.task,&tResp);

    if (retcode== ITK_ok)
		retcode = POM_get_user(&strUserName,&tUser);
       
	if((retcode == ITK_ok) && (tUser != tResp))
	{
		retcode = EPM_ask_job(msg.task,&tjob);

		//get the root task
		if (retcode == ITK_ok && tjob != NULLTAG)
			retcode = EPM_ask_root_task (tjob, &tRootTask);

		if (retcode == ITK_ok && tRootTask != NULLTAG)
			retcode = EPM_ask_responsible_party (tRootTask,&tResp);

		/*get the audit file*/
		if (retcode == ITK_ok && tjob != NULLTAG)
			retcode = EPM_ask_audit_file(tjob, &taudit_file);

		if (taudit_file != NULLTAG)
		{
			/*parse the audit file*/
			if (retcode == ITK_ok && taudit_file != NULLTAG)
				retcode = parseAuditFile(taudit_file,tRootTask, &pcComment, &pcRespName, &pcRespGroup, &pcRespRole, &pcRejected_Task);
		}
		else
		{
			parseWorkflowAuditInfoFromDatabase( tRootTask,&pcComment, &pcRespName, &pcRespGroup,&pcRespRole, &pcRejected_Task);
		}
		
		if (retcode == ITK_ok)
			retcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);

		if (retcode== ITK_ok)
		    retcode = EPM_ask_name(msg.task, acCurrRelLevel);

        if (retcode== ITK_ok && tEngChangeRev != NULLTAG)
			retcode = tiauto_getItemRevDetails(tEngChangeRev, acChnId, acChnRevId, acChnName);
		    //retcode = getItemRevDetails(tEngChangeRev, acChnId, acChnRevId, acChnName);

		tRecipients.list    = (tag_t *)MEM_alloc( INIT_LIST_SIZE * (sizeof(tag_t)) );
		tMailAddresses.list = (char **)MEM_alloc( INIT_LIST_SIZE * sizeof(char*) );
		    
        if (retcode== ITK_ok && tResp != NULLTAG)
    	    retcode = EPM__add_to_tag_list(tResp,&tRecipients);

		// remove duplicate users
		if(retcode == ITK_ok)
			retcode = EPM_remove_duplicate_tags( &(tRecipients.count), &(tRecipients.list));

		// get list of mail address
		if(retcode == ITK_ok)
			retcode = EPM_get_mailing_list( tRecipients.count,tRecipients.list, &tMailAddresses);

		// remove duplicate nailing addresses
		if(retcode == ITK_ok)
			retcode = EPM_remove_duplicate_strings(tMailAddresses.count , tMailAddresses.list,
									&(tFinalMailList.count),&(tFinalMailList.list));
        
        if(retcode == ITK_ok)
		{
            /* Initialize TextServer here */
           // the_text_server = txt_ctor( "iman_text.xml" );
           // msg_name = "User_Comments";
           // comments = txt_noSubText(the_text_server, msg_name, (int)true);
            /* release text server object here...*/
           // txt_destructor(the_text_server);
        }
		if(retcode == ITK_ok)
		{
			pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
			iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
		}
		if(retcode == ITK_ok && fMailBodyFile != NULL)
		{
			TI_sprintf(acSubject, "Please perform the following task in %s : %s/%s-%s(%s)",acSiteName,acChnId, acChnRevId, acChnName,acCurrRelLevel);
			//TI_sprintf(acSubject, "The following user: %s-%s/%s has demoted the task with following comment: %s",pcRespName, pcRespGroup,pcRespRole,pcComment);
			fprintf(fMailBodyFile,"\nProcess Name : %s/%s-%s\n",acChnId, acChnRevId, acChnName);
			fprintf(fMailBodyFile,"\nCurrent Task : %s\n",acCurrRelLevel);
			fprintf(fMailBodyFile,"\nDatabase     : %s\n\n",acSiteName);

			if( pcRespName != NULL)
			{
				fprintf(fMailBodyFile,"\n\nDemotion Details: \n");//,pcRespName, pcRespGroup,pcRespRole,pcComment);
				fprintf(fMailBodyFile,"----------------------\n");
				fprintf(fMailBodyFile,"\nDemoted at Task       : %s\n",pcRejected_Task);
				fprintf(fMailBodyFile,"\nDemoted By            : %s\n",pcRespName);
				fprintf(fMailBodyFile,"\nRole Name             : %s\n",pcRespRole);
				fprintf(fMailBodyFile,"\nGroup Name            : %s\n",pcRespGroup);
				fprintf(fMailBodyFile,"\nReason for Demotion   : %s\n\n",pcComment);
			}
           // fprintf(fMailBodyFile, "\n%s : You have been assigned a task to perform. Please log into the PLM system and open your worklist to locate and perform this task\n", comments);			
			fprintf(fMailBodyFile, "\n\nComments : You have been assigned a task to perform. Please log into the PLM system and open your worklist to locate and perform this task\n");			
		}
		if(fMailBodyFile != NULL)
		{
			fclose(fMailBodyFile);
		}
		retcode = mail_send_os_demote_mail(acSubject, tFinalMailList, pcMailBodyFileName);

		SAFE_MEM_free(tRecipients.list);
		release_string_array(tMailAddresses.count, tMailAddresses.list);
		remove(pcMailBodyFileName);
		//free(pcMailBodyFileName);
        SAFE_MEM_free(comments); 
	}
	return (retcode);
}

static int mail_send_os_demote_mail( const char *subject,              /* <I> */
                       counted_list_t receiverList,      /* <I> */
                       const char *pcMailBodyFileName        /* <I> */
                     )
/*
 *  description: this function will send the mail through OS mail facility
*/
{
    int iRetCode = ITK_ok;
    int inx   = 0;
	int iFileOpenErrCode = 0;
    char system_comm[BUFSIZ +1];

    /* 4399740: Allow special characters in recipient field */

    TC_preference_search_scope_t old_scope = TC_preference_site;
    int pref_count = 0;
    char *server_name = NULL;
    char *charset = NULL;
    int mark, ifail;

    char *toListFileName = NULL;
    FILE *toListFile = NULL;
    char * address = NULL;
    //mail_attributes_t attrs;
    
    /*
     *  <vlm 8/17/98> Use the mail gateway code to send the mail for NT.
     *  PR # 693685
     */
    system_comm[0] = '\0';
#if defined(WNT)
    tc_strcpy(system_comm, "%TC_BIN%\\tc_mail_smtp ");
#else
    tc_strcpy(system_comm, "$TC_BIN/tc_mail_smtp ");
#endif
     
    
    /* PR#5182626: Open a temp file for writing email address for -to_list_file= */
    toListFileName = USER_new_file_name("to_email_addresses","TEXT","dat",1);
    iFileOpenErrCode = fopen_s(&toListFile,toListFileName, "w" );

    if (toListFile == NULL)
    {
        iRetCode = CR_cannot_open_file;
    }
    else
    {
        /* write all email addresses from receiver List into new file */
        for (inx=0; inx<receiverList.count; ++inx)
        {
            address = receiverList.list[inx];
   
            if( address != 0 )
                fprintf( toListFile , "%s\n", address);

            /*The memory is being freed in CR_notify function, do not free it here */
            /* MEM_free(address); */
        }

        if (receiverList.count > 0)
        {
            tc_strcat( system_comm, " -to_list_file=\"" );
            tc_strcat( system_comm, toListFileName );
            tc_strcat( system_comm, "\" " );
        }
        fclose(toListFile);
    }
    
    tc_strcat(system_comm, " -subject=");
    tc_strcat(system_comm, "\"");
    tc_strcat(system_comm, subject);
    tc_strcat(system_comm, "\" ");

    //PR#1319397 : If user has email address set in his/her "Person" record
    //             that email address should appear in "From" field.
    { 
       tag_t the_sender_tag = NULLTAG;
       tag_t the_sender_person = NULLTAG;
       char *the_sender_name = 0;
       char *the_sender_email_addr = 0;

       // get the current user name and user tag.
       ifail = POM_get_user(&the_sender_name,&the_sender_tag);
       if( ifail == ITK_ok )
       {
           // get the email address for current user.
           //ifail = EPM_get_user_email_addr( the_sender_tag,&the_sender_email_addr);
           //PR#5154023 : Issue where some SMTP servers cannot handle a "from" field which
           //             does not have a fully qualified email address. So, if the email
           //             address is explicitly spec'd in Person record then use it otherwise
           //             leave it blank (don't use the os name)
           ifail = SA_ask_user_person( the_sender_tag, &the_sender_person );
           if ( ifail == ITK_ok )
           {
               ifail = SA_ask_person_attr( the_sender_person, "PA9", &the_sender_email_addr );
               if((ifail == ITK_ok) && (the_sender_email_addr != 0) )
               {
                  tc_strcat(system_comm," -user=\"");
                  tc_strcat(system_comm,the_sender_email_addr);
                  tc_strcat(system_comm,"\" ");
               }
           }
        }
    
        MEM_free(the_sender_name);
        MEM_free(the_sender_email_addr) ;
    }

    EMH_set_protect_mark( &mark );

    /* check if any preferences are defined to specify the Mail server */
    ifail = PREF_initialize();
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_search_scope(&old_scope);
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_set_search_scope( TC_preference_site );
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_value_count( "Mail_server_name", &pref_count );
    }

    if((ifail == ITK_ok) && pref_count != 0 )
    {
        if(PREF_ask_char_value("Mail_server_name", 0, &server_name ) == ITK_ok )
        {
            if (tc_strcmp (server_name, "your mail server machine") == 0)
            {
            TC_write_syslog ("File %s; Line # %d; Please set your Mail_server_name preference in your site preference file"
                              ,__FILE__, __LINE__);
            }
            tc_strcat(system_comm, "-server=" );
            tc_strcat(system_comm, "\"" );
            tc_strcat(system_comm, server_name );
            tc_strcat(system_comm, "\" " );
        }

        if( server_name != NULL )
        {
            MEM_free(server_name);
        }
    }

    pref_count = 0;
    if(ifail == ITK_ok)
    {
		PREF_ask_value_count("Mail_server_charset", &pref_count);
    }

    if( (ifail == ITK_ok) && pref_count != 0 )
    {
        if( PREF_ask_char_value( "Mail_server_charset", 0, &charset ) == ITK_ok )
        {
            tc_strcat( system_comm, "-charset=" );
            tc_strcat( system_comm, "\"" );
            tc_strcat( system_comm, charset );
            tc_strcat( system_comm, "\" " );
        }
        else
        {
            tc_strcat( system_comm, "-charset=" );
            tc_strcat( system_comm, "\"ISO-8859-1\" " );
        }
        if( charset != NULL )
        {
            MEM_free( charset );
        }
    }
    else
    {
        tc_strcat( system_comm, "-charset=" );
        tc_strcat( system_comm, "\"ISO-8859-1\" " );
    }

    PREF_set_search_scope(old_scope);

    EMH_clear_errors();
    EMH_clear_protect_mark(mark);

    tc_strcat(system_comm, "-body=");
    tc_strcat(system_comm, pcMailBodyFileName);
    tc_strcat(system_comm, " ");

    system( system_comm );

	//Close the temporary file
	if(toListFile != NULL)
		fclose(toListFile);

    // delete temporary file here
    remove(toListFileName );
	//free(toListFileName);

    return(iRetCode);
}

void release_string_array( int count,  char **list  )
{
    int inx;

    if(list == 0)
    {
		return;
    }
     
    for(inx = 0; inx < count; inx++ )
    {
		SAFE_SM_FREE(list[inx]);
    }

    SAFE_SM_FREE(list);
    
    list = 0;
}
/***************************************************************/
//int getItemRevDetails(tag_t tItemRev, char *pcItemId, 
//					 char *pcRevId, char *pcName)
//{
//	int iRetCode   = ITK_ok;
//	tag_t tItem = NULLTAG;
//
//
//	iRetCode = ITEM_ask_item_of_rev(tItemRev, &tItem); 
//
//	if(iRetCode == ITK_ok && tItem != NULLTAG)
//		iRetCode = ITEM_ask_id(tItem, pcItemId);
//
//	if(iRetCode == ITK_ok && tItemRev != NULLTAG)
//		iRetCode = ITEM_ask_rev_id (tItemRev, pcRevId);
//
//	if(iRetCode == ITK_ok && tItemRev != NULLTAG)
//		iRetCode = ITEM_ask_rev_name(tItemRev, pcName);
//
//
//	return iRetCode;
//}



//-----------------------------------------------------------------------------
// parseAuditFile()
// prase the audit file line by line
//-----------------------------------------------------------------------------
int parseAuditFile(tag_t tAuditFile, tag_t tRootTaskTag, char **pcTempcomment_value, char **pcTempReposibleParty_Name,
				   char **pcTempReposibleParty_GroupName, char **cTempReposibleParty_RoleName, char **pcTempRejected_Task)
{
	int iretcode = ITK_ok;
	int i = ITK_ok;
	int inx = ITK_ok;
	int j = ITK_ok;
	int iSubTasksCount = ITK_ok;
	int iReviewsubTaskIndx = ITK_ok;
	int iCheckReviewsubTaskIndx = ITK_ok;
	int iReviewSubTaskCount = ITK_ok;
	int iNumAttachs = 0;
	int iAttchIndx = 0;
	int iCntActionHandlers = 0;
	int iCnt = 0;
	int iUndo_count = 0;
	int iAuditfile_linecnt = 0;
	int iStart_count = 0;
	int count = 0;

	
	char  cnew_Auditfile_pathname[500]="" ;//"Audit.txt";

	char acBuffer[200] = "";
	char cReposibleParty_RoleName[SA_name_size_c+1] = {'\0'};
	char cReposibleParty_GroupName[SA_name_size_c+1] = {'\0'};
	char cReposibleParty_Name[SA_user_size_c+1] = {'\0'};

	
	char *pcActionName  = NULL;
	char *pcTaskName  = NULL;
	char *pcDateNTime  = NULL;
	char *pcUserName	 = NULL;	
	char *pcSurrUserName	 = NULL;
	char *pcSubTaskName	 = NULL;
	char *ret = NULL;
	char *pcSubTaskTypeName = NULL;
	char *pcReviewSubTaskName = NULL;
	char *pcReviewSubTaskType = NULL;
	char *pcicon_key_PropValue  = NULL;
	char *pcHandlerName = NULL;
	char *pccomment_value = NULL;
	char *pcTempComment_value1 = NULL;
	char *pcTempComment_value2 = NULL;
	char *pcTempComment_value3 = NULL;
	char *pcTempComment_value4 = NULL;
	char *pcTempRejectTaskName = NULL;

	tag_t *ptSubTasksTags = NULL;
	tag_t *ptReviewSubTaskTags = NULL;
	tag_t *ptAttachsTagList = NULL;
	tag_t tReviewTask_ReposibleParty = NULLTAG;
	tag_t tSubTaskType = NULLTAG;
	tag_t tGroupMember = NULLTAG;
	tag_t tTemplate = NULLTAG;
	tag_t tReposibleParty = NULLTAG;
	tag_t tReposibleParty_Group = NULLTAG;
	tag_t tReposibleParty_Role = NULLTAG;
	tag_t *ptActionHandlers = NULLTAG;
	tag_t tHandler = NULLTAG;

	EPM_state_t		tSubTaskState;
	//IMF_file_t tnew_file_descriptor;
	//IMF_file_data_p_t file_data;

	long sz;
	char *auditFileName = NULL;
	char *tempStr = NULL;
	logical		isAutomatedTask								= false ;
	logical bIsValid = false;
	char        sztemp[200]="";
	DWORD        aa = GetTempPath(200, sztemp);
	time_t ltime;
	errno_t err;
    struct tm Tm; 
    ltime=time(NULL);
    //Tm=localtime(&ltime);
	err = localtime_s(&Tm,&ltime);
    
	/*Read the header of the audit file and get the process name and Process created date */
	//if (iretcode == ITK_ok)
        //iretcode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
	if (iretcode == ITK_ok)
	{
		iretcode = AOM_ask_value_string(tAuditFile,"original_file_name",&tempStr );
		//auditFileName = (char *) malloc(sizeof(char)*tc_strlen(tempStr));		
		//tc_strncpy(auditFileName, tempStr, tc_strlen(tempStr)-4);
		//*(auditFileName+ tc_strlen(tempStr)-4) = '\0';
		//printf("\n%d",Tm.tm_hour);
		TI_sprintf(cnew_Auditfile_pathname,"%s%s_%d%d%d%d%d%d.txt",sztemp,tempStr,Tm.tm_mday,Tm.tm_mon,Tm.tm_year,Tm.tm_hour,Tm.tm_min, Tm.tm_sec);	
		
		iretcode = IMF_export_file (tAuditFile,cnew_Auditfile_pathname);
		//iretcode = IMF_get_file_access (   tAuditFile,0, &file_data);
	}
	if (iretcode == ITK_ok)
	{
		//if(file_data != 0)
			//iretcode =  IMF_get_filename (file_data, &cnew_Auditfile_pathname);
		if(tc_strlen(cnew_Auditfile_pathname)>0)
			iretcode  = fopen_s(&auditFilefp,cnew_Auditfile_pathname, "rb");
	}
	if (auditFilefp == NULL) 
    {   
         printf("Error! Could not open audit file\n"); 
		//if(file_data != 0)
			//iretcode =  IMF_release_file_access(&file_data);

         return 0; // must include stdlib.h 
    }

	sz = fsize(auditFilefp);

	if (sz > 0)
	{
		char buf[256];
		fseek(auditFilefp, sz, SEEK_SET);
		while (fgetsr(buf, sizeof(buf), auditFilefp) != NULL)
		{
			//printf("%s", buf);
			iAuditfile_linecnt++;

			//Checkinf for Reject or Complete or Undo action type
			if( iretcode == ITK_ok )
			{
				if( tc_strlen(buf) > 0 )
				{
					if( ( (buf[0] >= 'A') && (buf[0] <= 'Z') ) || ( (buf[0] >= 'a') && (buf[0] <= 'z') ) )
					{
						tc_strcpy(acBuffer,"");
						//memset(&acBuffer[0], 0, sizeof(acBuffer));  //Clearing the acBuffer array
						for(i = 0,j = 0;  (i < 17) && (buf[i] != '\0'); i++, j++)
						{
							acBuffer[j] = buf[i];
						}
						RemoveTrailingBlanks(acBuffer);

						// Check for reject action in the audit file
						if (tc_strcmp(acBuffer,"Reject") == 0)
						{
							iretcode = GetTaskNameDateAndUserInfo(buf, &pcActionName, &pcTaskName, &pcDateNTime, &pcUserName, &pcSurrUserName);
						
							//Get the subtasks and iterate through them.
							if(iretcode == ITK_ok && tRootTaskTag != NULLTAG)
							{
								iretcode = EPM_ask_sub_tasks(tRootTaskTag,&iSubTasksCount,&ptSubTasksTags);
								if(iretcode == ITK_ok && iSubTasksCount > 0)
								{
									for(inx= 0;inx<iSubTasksCount;inx++)
									{
										iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
										if(iretcode == ITK_ok)
										{
											iretcode = EPM_ask_state(ptSubTasksTags[inx],&tSubTaskState);
										}
										if(iretcode == ITK_ok && pcSubTaskName!= NULL)
										{
											iretcode = TCTYPE_ask_object_type(ptSubTasksTags[inx],&tSubTaskType);
										}
										if(iretcode == ITK_ok && tSubTaskType != NULLTAG)
										{
											iretcode = AOM_ask_name(tSubTaskType,&pcSubTaskTypeName);
										}

										//for review and acknowledge task
										if( (tc_strcmp(pcSubTaskTypeName,"EPMReviewTask")==0) || (tc_strcmp(pcSubTaskTypeName,"EPMAcknowledgeTask")==0) )
										{
											iretcode = EPM_ask_sub_tasks( ptSubTasksTags[inx], &iReviewSubTaskCount, &ptReviewSubTaskTags );
											if( iretcode == ITK_ok && ptReviewSubTaskTags != NULL )
											{
												for(iCheckReviewsubTaskIndx=0; iCheckReviewsubTaskIndx < iReviewSubTaskCount && iretcode == ITK_ok; iCheckReviewsubTaskIndx++  )
												{
													bIsValid = false;
													iretcode = AOM_ask_value_string( ptReviewSubTaskTags[iCheckReviewsubTaskIndx], "task_type", &pcReviewSubTaskType);
													iretcode = AOM_ask_name(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],&pcReviewSubTaskName);
													//ret = tc_strstr(pcSubTaskName, pcTaskName);
													if(tc_strstr(pcReviewSubTaskName, pcTaskName) != NULL)
													{
														bIsValid = true;
														break;
													}
												}
												SAFE_MEM_free(pcReviewSubTaskType);
												SAFE_MEM_free(pcReviewSubTaskName);
												pcReviewSubTaskType = NULL;
												pcReviewSubTaskName = NULL;

												for(iReviewsubTaskIndx=0;bIsValid == true && iReviewsubTaskIndx < iReviewSubTaskCount && iretcode == ITK_ok; iReviewsubTaskIndx++  )
												{
													iretcode = AOM_ask_value_string( ptReviewSubTaskTags[iReviewsubTaskIndx], "task_type", &pcReviewSubTaskType);
													iretcode = AOM_ask_name(ptReviewSubTaskTags[iReviewsubTaskIndx],&pcReviewSubTaskName);

													if( iretcode == ITK_ok && pcReviewSubTaskType != NULL && 
														(tc_strcmp(pcReviewSubTaskType, "EPMSelectSignoffTask") == 0) )
													{
														// get the signoff object
														if( iretcode == ITK_ok && ptReviewSubTaskTags[iReviewsubTaskIndx] != NULLTAG)
															// 15.02 Mail Notification
															//iretcode = AOM_ask_value_tags(ptReviewSubTaskTags[iReviewsubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
														    iretcode = AOM_ask_value_tags(ptReviewSubTaskTags[iReviewsubTaskIndx], "signoff_attachments", &iNumAttachs, &ptAttachsTagList);
														// get the user tag from the signoff object
														for(iAttchIndx=0; iAttchIndx < iNumAttachs && iretcode == ITK_ok; iAttchIndx++)
														{
															if( iretcode == ITK_ok && ptAttachsTagList != NULL)
															{
																iretcode = AOM_ask_value_string( ptAttachsTagList[iAttchIndx], "comments", &pccomment_value );

																iretcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
																if( iretcode == ITK_ok && tGroupMember != NULLTAG)
																{
																	tReviewTask_ReposibleParty = NULLTAG;
																	iretcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
																	
																}
																/*Get task responsinble party's role and group*/
																if (iretcode == ITK_ok && tReposibleParty!=NULLTAG)
																	iretcode = SA_ask_user_identifier (tReposibleParty, cReposibleParty_Name) ;
																if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_Name,"") != 0))
																	iretcode = SA_ask_user_login_group(tReposibleParty,&tReposibleParty_Group );
																if (iretcode == ITK_ok)
																	iretcode = SA_ask_group_name (tReposibleParty_Group, cReposibleParty_GroupName);
																if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_GroupName,"") != 0))
																	iretcode = SA_ask_user_default_role_in_group(tReposibleParty,tReposibleParty_Group,&tReposibleParty_Role);
																if (iretcode == ITK_ok)
																	iretcode = SA_ask_role_name(tReposibleParty_Role, cReposibleParty_RoleName);
															}
														}
														MEM_free(ptAttachsTagList);
														MEM_free(pcicon_key_PropValue);
													}
													if( iretcode == ITK_ok && pcReviewSubTaskType != NULL && 
														(tc_strcmp(pcReviewSubTaskType, "EPMPerformSignoffTask") == 0) )
													{
														//Get the Task at which the change was rejected
														iretcode = AOM_ask_name(ptReviewSubTaskTags[iReviewsubTaskIndx],&pcTempRejectTaskName);
													}
												}
											}
											SAFE_MEM_free(ptReviewSubTaskTags);
										}
										if (tReposibleParty != NULLTAG)
										{
											//*pcTempRejected_Task = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);											
											*pcTempRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
											tc_strcpy(*pcTempRejected_Task, pcTempRejectTaskName);
											//SAFE_MEM_free(pcTempRejectTaskName);

											//*pcTempcomment_value = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
											*pcTempcomment_value = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
											tc_strcpy(*pcTempcomment_value, pccomment_value);
											//SAFE_MEM_free(pccomment_value);

											//*pcTempReposibleParty_Name = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_Name)+1);
											*pcTempReposibleParty_Name = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_Name)+1));
											tc_strcpy(*pcTempReposibleParty_Name, cReposibleParty_Name);

											//*pcTempReposibleParty_GroupName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_GroupName)+1);
											*pcTempReposibleParty_GroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_GroupName)+1));
											tc_strcpy(*pcTempReposibleParty_GroupName, cReposibleParty_GroupName);

											//*cTempReposibleParty_RoleName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_RoleName)+1);
											*cTempReposibleParty_RoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_RoleName)+1));
											tc_strcpy(*cTempReposibleParty_RoleName, cReposibleParty_RoleName);

											pcTempRejectTaskName = NULL;
											pccomment_value = NULL;
											//memset(&cReposibleParty_Name[0], 0, sizeof(cReposibleParty_Name));
											//memset(&cReposibleParty_GroupName[0], 0, sizeof(cReposibleParty_GroupName));
											//memset(&cReposibleParty_RoleName[0], 0, sizeof(cReposibleParty_RoleName));

											fclose(auditFilefp);
											SAFE_MEM_free( ptSubTasksTags);
											iretcode = remove(cnew_Auditfile_pathname);
											//if( iretcode == 0 )
											//	printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);
											//iretcode =  IMF_release_file_access(&file_data);

											return 0;
										}
									}
								}
								SAFE_MEM_free( ptSubTasksTags);
							}
						}

						// Check for Complete action in the audit file
						else if (tc_strcmp(acBuffer,"Complete") == 0)
						{
							iretcode = GetTaskNameDateAndUserInfo(buf, &pcActionName, &pcTaskName, &pcDateNTime, &pcUserName, &pcSurrUserName);
						
							//Get the subtasks and iterate through them.
							if(iretcode == ITK_ok && tRootTaskTag != NULLTAG)
							{
								iretcode = EPM_ask_sub_tasks(tRootTaskTag,&iSubTasksCount,&ptSubTasksTags);
								if(iretcode == ITK_ok && iSubTasksCount > 0)
								{
									for(inx= 0;inx<iSubTasksCount;inx++)
									{
										iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
										if(iretcode == ITK_ok)
											ret = tc_strstr(pcSubTaskName, pcTaskName);
										if (ret != NULL)
										{
											iretcode = EPM_ask_state(ptSubTasksTags[inx],&tSubTaskState);
											if(iretcode == ITK_ok && pcSubTaskName!= NULL)
											{
												iretcode = TCTYPE_ask_object_type(ptSubTasksTags[inx],&tSubTaskType);
											}
											if(iretcode == ITK_ok && tSubTaskType != NULLTAG)
											{
												iretcode = AOM_ask_name(tSubTaskType,&pcSubTaskTypeName);
											}

											//check if the task type is a ECO/Do Task/CheckList
											if( (tc_strcmp(pcSubTaskTypeName,"ECMPrepareECOTask")==0 ) ||
												(tc_strcmp(pcSubTaskTypeName,"EPMDoTask")== 0 ) ||
												(tc_strcmp(pcSubTaskTypeName,"ECMChecklistTask")== 0) )
											{
												//Get the comment passed by the responsible party
												iretcode = AOM_ask_value_string( ptSubTasksTags[inx], "comments", &pccomment_value );

												//Get the Task at which the change was rejected
												iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcTempRejectTaskName);

												//get the responsible party of the task
												iretcode = EPM_ask_responsible_party(ptSubTasksTags[inx],&tReposibleParty);
												if(iretcode == ITK_ok && tReposibleParty != NULLTAG)
												{
													/*Get task responsinble party's role and group*/
													if (iretcode == ITK_ok)
														iretcode = SA_ask_user_identifier(tReposibleParty, cReposibleParty_Name) ;
													if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_Name,"") != 0))
														iretcode = SA_ask_user_login_group(tReposibleParty,&tReposibleParty_Group );
													if (iretcode == ITK_ok)
														iretcode = SA_ask_group_name (tReposibleParty_Group, cReposibleParty_GroupName);
													if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_GroupName,"") != 0))
														iretcode = SA_ask_user_default_role_in_group(tReposibleParty,tReposibleParty_Group,&tReposibleParty_Role);
													if (iretcode == ITK_ok)
														iretcode = SA_ask_role_name(tReposibleParty_Role, cReposibleParty_RoleName);
														
												}
											}
											else if(tc_strcmp(pcSubTaskTypeName,"EPMConditionTask")==0 )
											{
												iretcode = AOM_ask_value_tag ( ptSubTasksTags[inx],"task_template" ,&tTemplate);
												//iRetcode = EPM_find_handler(tTemplate,EPM_action_handler_type,EPM_complete_action,cHandlerName,&tHandler);
												iretcode = EPM_ask_action_handlers(tTemplate,EPM_start_action,&iCntActionHandlers,&ptActionHandlers);
												for(iCnt = 0; iCnt < iCntActionHandlers ; iCnt++)
												{
													iretcode = AOM_ask_name(ptActionHandlers[iCnt],&pcHandlerName);
													if( iretcode == ITK_ok && (tc_strcmp(pcHandlerName,"set-condition") == 0 ||
														tc_strcmp(pcHandlerName,"TIAUTO-AH-verify-status-progression") == 0 ||
														tc_strcmp(pcHandlerName,"TIAUTO-AH-check-status-progression") == 0 ||
														tc_strcmp(pcHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 )
													  )
													{
														isAutomatedTask = true;
														break;
													}
												}
												SAFE_MEM_free( ptActionHandlers);
												if( isAutomatedTask == false)
												{
													iretcode = EPM_find_handler(tTemplate,EPM_rule_handler_type,EPM_start_action,"TIAUTO-RH-check-mra-dataset-creation",&tHandler);
													if(iretcode == ITK_ok && tHandler !=NULLTAG )
													{
														isAutomatedTask = true;
														break;
													}
												}
												if(isAutomatedTask == false )
												{
													//Get the comment passed by the responsible party
													iretcode = AOM_ask_value_string( ptSubTasksTags[inx], "comments", &pccomment_value );

													//Get the Task at which the change was rejected
													iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcTempRejectTaskName);

													//get the responsible party of the task
 													iretcode = EPM_ask_responsible_party(ptSubTasksTags[inx],&tReposibleParty);
													if(iretcode == ITK_ok && tReposibleParty != NULLTAG)
													{
														/*Get task responsinble party's role and group*/
														if (iretcode == ITK_ok)
															iretcode = SA_ask_user_identifier (tReposibleParty, cReposibleParty_Name) ;
														if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_Name,"") != 0))
															iretcode = SA_ask_user_login_group(tReposibleParty,&tReposibleParty_Group );
														if (iretcode == ITK_ok)
															iretcode = SA_ask_group_name (tReposibleParty_Group, cReposibleParty_GroupName);
														if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_GroupName,"") != 0))
															iretcode = SA_ask_user_default_role_in_group(tReposibleParty,tReposibleParty_Group,&tReposibleParty_Role);
														if (iretcode == ITK_ok)
															iretcode = SA_ask_role_name(tReposibleParty_Role, cReposibleParty_RoleName);	
													}
												}
											}
											break;
										}
									}
								}
								SAFE_MEM_free( ptSubTasksTags);
							}
							if (tReposibleParty != NULLTAG)
							{
								//*pcTempRejected_Task = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);
								*pcTempRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
								tc_strcpy(*pcTempRejected_Task, pcTempRejectTaskName);
								//SAFE_MEM_free( pcTempRejectTaskName);

								//*pcTempcomment_value = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
								*pcTempcomment_value = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
								tc_strcpy(*pcTempcomment_value, pccomment_value);
								//SAFE_MEM_free( pccomment_value);

								//*pcTempReposibleParty_Name = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_Name)+1);
								*pcTempReposibleParty_Name = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_Name)+1));
								tc_strcpy(*pcTempReposibleParty_Name, cReposibleParty_Name);

								//*pcTempReposibleParty_GroupName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_GroupName)+1);
								*pcTempReposibleParty_GroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_GroupName)+1));
								tc_strcpy(*pcTempReposibleParty_GroupName, cReposibleParty_GroupName);

								//*cTempReposibleParty_RoleName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_RoleName)+1);
								*cTempReposibleParty_RoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_RoleName)+1));
								tc_strcpy(*cTempReposibleParty_RoleName, cReposibleParty_RoleName);

								pcTempRejectTaskName = NULL;
								pccomment_value = NULL;
								//memset(&cReposibleParty_Name[0], 0, sizeof(cReposibleParty_Name));
								//memset(&cReposibleParty_GroupName[0], 0, sizeof(cReposibleParty_GroupName));
								//memset(&cReposibleParty_RoleName[0], 0, sizeof(cReposibleParty_RoleName));

								fclose(auditFilefp);
								//iretcode =  IMF_release_file_access(&file_data);
								iretcode = remove(cnew_Auditfile_pathname);
								if( iretcode == 0 )
									printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);

								return 0;
							}
						}
						// Check for Complete action in the audit file
						else if (tc_strcmp(acBuffer,"Undo") == 0)
						{
							iUndo_count = iAuditfile_linecnt;
						}
						else if (tc_strcmp(acBuffer,"Start") == 0)
						{
							iStart_count = 0;
							iStart_count = iAuditfile_linecnt;
							if ((iUndo_count != 0) )//&& (iStart_count < iUndo_count))//+3)) || (iStart_count == (iUndo_count+4))))
							{
								iretcode = GetTaskNameDateAndUserInfo(buf, &pcActionName, &pcTaskName, &pcDateNTime, &pcUserName, &pcSurrUserName);

								//Read Audit file to get commnet passed
								iretcode  = fopen_s(&auditFilefp2,cnew_Auditfile_pathname, "r");
								count = 0;
								if (auditFilefp2 == NULL) 
								{   
									// printf("Error! Could not open file\n"); 
									// exit(-1); // must include stdlib.h 
									//if(file_data != 0)
									//	iretcode =  IMF_release_file_access(&file_data);

									return 0;
								}
								sz = fsize(auditFilefp2);
								fclose(auditFilefp2);
								if (sz > 0)
								{
									char line[256] = "";
									int iTotalLines = 0;
									iretcode  = fopen_s(&auditFilefp2,cnew_Auditfile_pathname, "r");
									while(fgets(line, sizeof(line), auditFilefp2) != NULL)
									{									  
										iTotalLines++;									 
									}
									fclose(auditFilefp2);
									iretcode  = fopen_s(&auditFilefp2,cnew_Auditfile_pathname, "r");
									//memset(&line[0], 0, sizeof(line));
									//fseek(auditFilefp2, sz, SEEK_SET);
									while (fgets(line, sizeof(line), auditFilefp2) != NULL)
									{
										/*if (count == 115)
											printf("sfnslkfn");*/
										count++;
										if(count < ((iTotalLines - iAuditfile_linecnt)+1))
										{
											continue;
										}
										RemoveTrailingBlanks(line);

										
										//if(count>iUndo_count)
										//	break;	
										if ((tc_strcmp(line,"") != 0 ) && (tc_strncasecmp(line,"Undo",4) == 0))
										{
											if(fgets(line, sizeof(line), auditFilefp2) != NULL)
											{
												RemoveTrailingBlanks(line);
												pcTempComment_value1 = (char*)malloc(sizeof(char)*strlen(line)+1);
												tc_strcpy(pcTempComment_value1, line);
											}
											break;
										}
										/*else if ((tc_strcmp(line,"") != 0 ) && (tc_strncasecmp(line,"Undo",4) != 0) && (tc_strncasecmp(line,"Level:",6) != 0))
										{
										}
										if ((count == (iUndo_count - 1)) && (tc_strcmp(line,"") != 0 ) && (tc_strncasecmp(line,"Undo",4) != 0) && (tc_strncasecmp(line,"Level:",6) != 0))
										{
											pcTempComment_value1 = (char*)malloc(sizeof(char)*strlen(line));
											tc_strcpy(pcTempComment_value1, line);
										}
										if ((count == (iUndo_count - 2)) && (tc_strcmp(line,"") != 0 ) && (tc_strncasecmp(line,"Undo",4) != 0) && (tc_strncasecmp(line,"Level:",6) != 0))
										{
											pcTempComment_value2 = (char*)malloc(sizeof(char)*strlen(line));
											tc_strcpy(pcTempComment_value2, line);
										}
										if ((count == (iUndo_count - 3)) && (tc_strcmp(line,"") != 0 )&& (tc_strncasecmp(line,"Undo",4) != 0) && (tc_strncasecmp(line,"Level:",6) != 0))
										{
											//printf("line value =%s",line);
											
											pcTempComment_value3 = (char*)malloc(sizeof(char)*tc_strlen(line));
											tc_strcpy(pcTempComment_value3, line);
										}
										if ((count == (iUndo_count - 4)) && (tc_strcmp(line,"") != 0 )&& (tc_strncasecmp(line,"Undo",4) != 0) && (tc_strncasecmp(line,"Level:",6) != 0))
										{
											//printf("line value =%s",line);
											
											pcTempComment_value4 = (char*)malloc(sizeof(char)*strlen(line));
											tc_strcpy(pcTempComment_value4, line);
										}
											
											memset(&line[0], 0, sizeof(line));*/
									}
									fclose(auditFilefp2);
								}
								else
								{
								//file doesn't exist
								}

								  // Appeding the comment values
								  pccomment_value = NULL;

								  if (pcTempComment_value1 != NULL)
								  {
									  if (pcTempComment_value2 != NULL)
									  {
										tc_strcat(pcTempComment_value1, " ");
									  }
									  tc_strcat(pcTempComment_value1, pcTempComment_value2);
									  if (pcTempComment_value3 != NULL)
									  {
										tc_strcat(pcTempComment_value1, " ");
									  }
									  tc_strcat(pcTempComment_value1, pcTempComment_value3);
									  if (pcTempComment_value4 != NULL)
									  {
										tc_strcat(pcTempComment_value1, " ");
									  }
									  tc_strcat(pcTempComment_value1, pcTempComment_value4);

									  pccomment_value = (char*)malloc(sizeof(char)*tc_strlen(pcTempComment_value1)+1);
									  tc_strcpy(pccomment_value, pcTempComment_value1);
								  }

								  if ((pcTempComment_value1 == NULL) && (pcTempComment_value2 != NULL))
								  {
									  if (pcTempComment_value3 != NULL)
									  {
										tc_strcat(pcTempComment_value2, " ");
									  }
									  tc_strcat(pcTempComment_value2, pcTempComment_value3); 
									  if (pcTempComment_value4 != NULL)
									  {
										tc_strcat(pcTempComment_value2, " ");
									  }
									  tc_strcat(pcTempComment_value2, pcTempComment_value4);

									  pccomment_value = (char*)malloc(sizeof(char)*strlen(pcTempComment_value2)+1);
									  tc_strcpy(pccomment_value, pcTempComment_value2);
								  }

								  if ((pcTempComment_value1 == NULL)&& (pcTempComment_value2 == NULL) && (pcTempComment_value3 != NULL))
								  {
									  if (pcTempComment_value4 != NULL)
									  {
										tc_strcat(pcTempComment_value1, " ");
									  }
									  tc_strcat(pcTempComment_value3, pcTempComment_value4);

									  pccomment_value = (char*)malloc(sizeof(char)*tc_strlen(pcTempComment_value3)+1);
									  tc_strcpy(pccomment_value, pcTempComment_value3);
								  }
								  if ((pcTempComment_value1 == NULL)&& (pcTempComment_value2 == NULL) && (pcTempComment_value3 == NULL) && (pcTempComment_value4 != NULL))
								  {
									  pccomment_value = (char*)malloc(sizeof(char)*tc_strlen(pcTempComment_value4)+1);
									  tc_strcpy(pccomment_value, pcTempComment_value4);
								  }
								  /*free( pcTempComment_value1);
								  free( pcTempComment_value2);
								  free( pcTempComment_value3);
								  free( pcTempComment_value4);*/
								  pcTempComment_value1 = NULL;
								  pcTempComment_value2 = NULL;
								  pcTempComment_value3 = NULL;
								  pcTempComment_value4 = NULL;

								//Get the subtasks and iterate through them.
								if(iretcode == ITK_ok && tRootTaskTag != NULLTAG)
								{
									iretcode = EPM_ask_sub_tasks(tRootTaskTag,&iSubTasksCount,&ptSubTasksTags);
									if(iretcode == ITK_ok && iSubTasksCount > 0)
									{
										for(inx= 0;inx<iSubTasksCount;inx++)
										{
											iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
											if(iretcode == ITK_ok)
											{
												iretcode = EPM_ask_state(ptSubTasksTags[inx],&tSubTaskState);
											}
											if(iretcode == ITK_ok && pcSubTaskName!= NULL)
											{
												iretcode = TCTYPE_ask_object_type(ptSubTasksTags[inx],&tSubTaskType);
											}
											if(iretcode == ITK_ok && tSubTaskType != NULLTAG)
											{
												iretcode = AOM_ask_name(tSubTaskType,&pcSubTaskTypeName);
											}

											if( (tc_strcmp(pcSubTaskTypeName,"EPMReviewTask")!=0) || (tc_strcmp(pcSubTaskTypeName,"EPMAcknowledgeTask")!=0) )
											{
												ret = tc_strstr(pcSubTaskName, pcTaskName);
												if (ret != NULL)
												{
													//Get the Task at which the change was rejected
													iretcode = AOM_ask_name(ptSubTasksTags[inx],&pcTempRejectTaskName);

													//get the responsible party of the task
													iretcode = EPM_ask_responsible_party(ptSubTasksTags[inx],&tReposibleParty);
													if(iretcode == ITK_ok && tReposibleParty != NULLTAG)
													{
														/*Get task responsinble party's role and group*/
														if (iretcode == ITK_ok)
															iretcode = SA_ask_user_identifier (tReposibleParty, cReposibleParty_Name) ;
														if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_Name,"") != 0))
															iretcode = SA_ask_user_login_group(tReposibleParty,&tReposibleParty_Group );
														if (iretcode == ITK_ok)
															iretcode = SA_ask_group_name (tReposibleParty_Group, cReposibleParty_GroupName);
														if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_GroupName,"") != 0))
															iretcode = SA_ask_user_default_role_in_group(tReposibleParty,tReposibleParty_Group,&tReposibleParty_Role);
														if (iretcode == ITK_ok)
															iretcode = SA_ask_role_name(tReposibleParty_Role, cReposibleParty_RoleName);	
													}
												}
											}

											//for review and acknowledge task
											if( (tc_strcmp(pcSubTaskTypeName,"EPMReviewTask")==0) || (tc_strcmp(pcSubTaskTypeName,"EPMAcknowledgeTask")==0) )
											{
												iretcode = EPM_ask_sub_tasks( ptSubTasksTags[inx], &iReviewSubTaskCount, &ptReviewSubTaskTags );
												if( iretcode == ITK_ok && ptReviewSubTaskTags != NULL )
												{
													for(iCheckReviewsubTaskIndx=0; iCheckReviewsubTaskIndx < iReviewSubTaskCount && iretcode == ITK_ok; iCheckReviewsubTaskIndx++  )
													{
														bIsValid = false;
														iretcode = AOM_ask_value_string( ptReviewSubTaskTags[iCheckReviewsubTaskIndx], "task_type", &pcReviewSubTaskType);
														iretcode = AOM_ask_name(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],&pcReviewSubTaskName);
														//ret = tc_strstr(pcSubTaskName, pcTaskName);
														if(tc_strstr(pcReviewSubTaskName, pcTaskName) != NULL)
														{
															bIsValid = true;
															break;
														}
													}
													
													SAFE_MEM_free(pcReviewSubTaskType);
													SAFE_MEM_free(pcReviewSubTaskName);
													pcReviewSubTaskType = NULL;
													pcReviewSubTaskName = NULL;

													for(iReviewsubTaskIndx=0; bIsValid  == true && iReviewsubTaskIndx < iReviewSubTaskCount && iretcode == ITK_ok; iReviewsubTaskIndx++  )
													{
														iretcode = AOM_ask_value_string( ptReviewSubTaskTags[iReviewsubTaskIndx], "task_type", &pcReviewSubTaskType);
														iretcode = AOM_ask_name(ptReviewSubTaskTags[iReviewsubTaskIndx],&pcReviewSubTaskName);

														if( iretcode == ITK_ok && pcReviewSubTaskType != NULL && 
														(tc_strcmp(pcReviewSubTaskType, "EPMSelectSignoffTask") == 0) )
														{
															// get the signoff object
															if( iretcode == ITK_ok && ptReviewSubTaskTags[iReviewsubTaskIndx] != NULLTAG)
																// 15.02 Mail Notification
																//iretcode = AOM_ask_value_tags(ptReviewSubTaskTags[iReviewsubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
															    iretcode = AOM_ask_value_tags(ptReviewSubTaskTags[iReviewsubTaskIndx], "signoff_attachments", &iNumAttachs, &ptAttachsTagList);
															// get the user tag from the signoff object
															for(iAttchIndx=0; iAttchIndx < iNumAttachs && iretcode == ITK_ok; iAttchIndx++)
															{
																if( iretcode == ITK_ok && ptAttachsTagList != NULL)
																{
																	iretcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
																	if( iretcode == ITK_ok && tGroupMember != NULLTAG)
																	{
																		tReviewTask_ReposibleParty = NULLTAG;
																		iretcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
																		
																	}

																	/*Get task responsinble party's role and group*/
																	if (iretcode == ITK_ok)
																		iretcode = SA_ask_user_identifier (tReposibleParty, cReposibleParty_Name) ;
																	if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_Name,"") != 0))
																		iretcode = SA_ask_user_login_group(tReposibleParty,&tReposibleParty_Group );
																	if (iretcode == ITK_ok)
																		iretcode = SA_ask_group_name (tReposibleParty_Group, cReposibleParty_GroupName);
																	if ((iretcode == ITK_ok) && (tc_strcmp(cReposibleParty_GroupName,"") != 0))
																		iretcode = SA_ask_user_default_role_in_group(tReposibleParty,tReposibleParty_Group,&tReposibleParty_Role);
																	if (iretcode == ITK_ok)
																		iretcode = SA_ask_role_name(tReposibleParty_Role, cReposibleParty_RoleName);

																	if(tc_strstr(pccomment_value,"demote-on-reject handler") != NULL)
																	{
																		if(tc_strcmp(cReposibleParty_Name,"")!=0)
																		{
																			if(iNumAttachs > 1 && tc_strcmp(cReposibleParty_Name,pcUserName)!=0)
																				continue;
																			// found the rejection signoff																			
																			iretcode = AOM_ask_value_string( ptAttachsTagList[iAttchIndx], "comments", &pccomment_value );
																			if( iretcode==ITK_ok && pccomment_value!=NULL)
																			{
																				//*pccomment_value = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
																				//tc_strcpy(*pccomment_value, pccomment_value);																
																			}
																		}
																	}
																}
															}
															MEM_free(ptAttachsTagList);
															MEM_free(pcicon_key_PropValue);
														}
														if( iretcode == ITK_ok && pcReviewSubTaskType != NULL && 
															(tc_strcmp(pcReviewSubTaskType, "EPMPerformSignoffTask") == 0) )
														{
															//Get the Task at which the change was rejected
															iretcode = AOM_ask_name(ptReviewSubTaskTags[iReviewsubTaskIndx],&pcTempRejectTaskName);
														}
													}
													SAFE_MEM_free(ptReviewSubTaskTags);
												}
											}
											if (tReposibleParty != NULLTAG)
											{
												//*pcTempRejected_Task = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);
												*pcTempRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
												tc_strcpy(*pcTempRejected_Task, pcTempRejectTaskName);
												//SAFE_MEM_free(pcTempRejectTaskName);

												//*pcTempcomment_value = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
												*pcTempcomment_value = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
												tc_strcpy(*pcTempcomment_value, pccomment_value);
												//SAFE_MEM_free(pccomment_value);

												//*pcTempReposibleParty_Name = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_Name)+1);
												*pcTempReposibleParty_Name = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_Name)+1));
												tc_strcpy(*pcTempReposibleParty_Name, cReposibleParty_Name);

												//*pcTempReposibleParty_GroupName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_GroupName)+1);
												*pcTempReposibleParty_GroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_GroupName)+1));
												tc_strcpy(*pcTempReposibleParty_GroupName, cReposibleParty_GroupName);

												//*cTempReposibleParty_RoleName = (char*)malloc(sizeof(char)*tc_strlen(cReposibleParty_RoleName)+1);
												*cTempReposibleParty_RoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cReposibleParty_RoleName)+1));
												tc_strcpy(*cTempReposibleParty_RoleName, cReposibleParty_RoleName);

												pcTempRejectTaskName = NULL;
												pccomment_value = NULL;
												//memset(&cReposibleParty_Name[0], 0, sizeof(cReposibleParty_Name));
												//memset(&cReposibleParty_GroupName[0], 0, sizeof(cReposibleParty_GroupName));
												//memset(&cReposibleParty_RoleName[0], 0, sizeof(cReposibleParty_RoleName));

												fclose(auditFilefp);
												SAFE_MEM_free( ptSubTasksTags);
												//if(file_data != 0)
												//	iretcode =  IMF_release_file_access(&file_data);

												iretcode = remove(cnew_Auditfile_pathname);
												//if( iretcode == 0 )
												//	printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);

												return 0;
											}
										}
									}
									SAFE_MEM_free( ptSubTasksTags);
								}
							}
						}
					}
				}
			}
		}

	  }

	fclose(auditFilefp);
	//if(file_data != 0)
	//		iretcode =  IMF_release_file_access(&file_data);

	//if (iretcode == ITK_ok)
 //       iretcode = IMF_open_file(tFileDescriptor,  SS_RDONLY );
	//// get the process name and the process creation date
	//while(iretcode == ITK_ok)
	//{
	//	iretcode =  IMF_read_file_line( tFileDescriptor, text_line );
	//	if( iretcode == ITK_ok )
	//	{
	//		if(tc_strncasecmp(text_line, "------", 6) == 0 )
	//			break;
	//		else if(tc_strncasecmp(text_line, "Date Created", 12) == 0 )
	//		{
	//			for(i=17, j = 0; (i<37) && (text_line[i] != '\0'); i++, j++)
	//			{
	//				acBuffer[j] = text_line[i];
	//			}
	//			RemoveTrailingBlanks(acBuffer);
	//			//pcDateCreated = malloc(sizeof(char)*strlen(acBuffer));
	//			tc_strcpy(pcDateCreated, acBuffer);

	//			memset(&acBuffer[0], 0, sizeof(acBuffer));  //Clearing the acBuffer array
	//		}
	//		else if(tc_strncasecmp(text_line, "Process Name", 12) == 0 )
	//		{
	//			for(i=17,j=0; (text_line[i] != '\0'); i++,j++)
	//			{
	//				acBuffer[j] = text_line[i];
	//			}
	//			RemoveTrailingBlanks(acBuffer);
	//			//pcProcessName = malloc(sizeof(char)*strlen(acBuffer));
	//			tc_strcpy(pcProcessName, acBuffer);

	//			memset(&acBuffer[0], 0, sizeof(acBuffer));  //Clearing the acBuffer array
	//		}
	//	}
	//}

	//    iretcode = IMF_close_file(tFileDescriptor);
		return iretcode;
}
