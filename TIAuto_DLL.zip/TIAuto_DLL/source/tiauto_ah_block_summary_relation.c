/*******************************************************************************
File         : tiauto_ah_block_summary_relation.c

Description  : This handler is configured for a pre-condition(TIPrematureRelationCreation), so that 
               solution item relation creation can be stopped.
Sample Mail  :
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Feb 28, 2012    1.0        Nivedita Kamath     Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int t1aAUTO_AH_block_summary_relation(EPM_action_message_t msg)
{
   int iRetcode = ITK_ok;
	
	return iRetcode;  
}