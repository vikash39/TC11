/*******************************************************************************
File         : tiauto_ah_create_access_solitem_rel.c

Description  : Gets the responsibly party  from "from_task" argument and task result. If task result conatins Optin then set the responsible party of task with name as in "from_task" argument " to task with task name as in "to_task" argument and sets the condtional task result as true 
			   else false.

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 1, 2016		1.0        Shilpa			 Initial Creation
/*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>



extern int t1aAUTO_AH_set_optedin_user_as_resp_party(EPM_action_message_t msg)
{
	int				iRetcode			= ITK_ok;
	int             iNumArgs			= 0; 
	int				iLoopAllTasks		= 0;
	int				iAllTasks			= 0;
	int				iLoopNumArgs		= 0;
	tag_t			tRootTaskTag		= NULLTAG;
	tag_t			tTaskType			= NULLTAG;
	tag_t			*ptAllTaskTags		= NULL;
	char			*pcTaskName			= NULL;//to be freed
	char			*pcTaskTypeName		= NULL;//to be freed
	char			*pcToTaskName		= NULL;
	char			*pcFromTaskName		= NULL;
		tag_t		tRespParty				= NULL;
		char		*pcTaskResult			= NULL;
		int			iAllSubTasks			= 0;
		int			iLoopAllSubTasks		= 0;
		tag_t		*ptAllSubTaskTags	    = NULL;
		char		*pcSubTaskTypeName		= NULL;
		char		*pcSubTaskName			= NULL;
	
		tag_t		tFromTask					= NULLTAG;
		tag_t		tToTask					= NULLTAG;
	
		char			*pcFlag				= NULL;
		char			*pcValue			= NULL;
		char			*pcErrMsg			= NULL;
		
	char            szErrorString[TIAUTO_error_message_len+1]="";
	
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 2)
	{
		for(iLoopNumArgs = 0; iLoopNumArgs < iNumArgs; iLoopNumArgs++)
		{
			
			iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetcode == ITK_ok )
			{
				if (tc_strcasecmp(pcFlag, "from_task") == 0 && pcValue != NULL)
				{
					pcFromTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcFromTaskName, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, "to_task") == 0 && pcValue != NULL)
				{
					pcToTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcToTaskName, pcValue);
				}
								
			
				if( iRetcode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"tiauto_ah_set_additional_reviewers_as_resp_party\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;
					
				}
			}
		}
		SAFE_MEM_free(pcFlag);
		SAFE_MEM_free(pcValue);
	}
	else if (iNumArgs > 2 )
	{
		iRetcode = EPM_invalid_argument;
	}	

    if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		EPM_ask_sub_tasks	(tRootTaskTag,&iAllTasks,&ptAllTaskTags);
		for(iLoopAllTasks =0 ; iLoopAllTasks < iAllTasks; iLoopAllTasks++)
		{				
			iRetcode = EPM_ask_name2(ptAllTaskTags[iLoopAllTasks],&pcTaskName);
			
			if((tc_strcmp(pcTaskName,pcFromTaskName)==0) && iRetcode == ITK_ok)
			{				
				tFromTask = ptAllTaskTags[iLoopAllTasks];
				continue;			
			}
			else if((tc_strcmp(pcTaskName,pcToTaskName)==0) && iRetcode == ITK_ok)
			{				
				tToTask = ptAllTaskTags[iLoopAllTasks];
				continue;			
			}
					
			EPM_ask_sub_tasks	(ptAllTaskTags[iLoopAllTasks],&iAllSubTasks,&ptAllSubTaskTags);
			for(iLoopAllSubTasks =0 ; iLoopAllSubTasks < iAllSubTasks; iLoopAllSubTasks++)
			{				
				iRetcode = EPM_ask_name2(ptAllSubTaskTags[iLoopAllSubTasks],&pcSubTaskName);
				
				if((tc_strcmp(pcSubTaskName,pcFromTaskName)==0) && iRetcode == ITK_ok)
				{
					tFromTask = ptAllSubTaskTags[iLoopAllSubTasks];
					break;									
				}
				else if((tc_strcmp(pcSubTaskName,pcToTaskName)==0) && iRetcode == ITK_ok)
				{				
					tToTask = ptAllSubTaskTags[iLoopAllSubTasks];
					break;			
				}		
		
			}

			if(tFromTask != NULLTAG && tToTask != NULLTAG)
			{
				break;
			}
									
			
		}

		iRetcode = TCTYPE_ask_object_type(msg.task,&tTaskType);
		if(iRetcode == ITK_ok && tTaskType != NULLTAG)
		{
			iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
		}
		if(tFromTask != NULLTAG && tToTask != NULLTAG)
		{	

			iRetcode = EPM_ask_responsible_party(tFromTask,&tRespParty);
			iRetcode = EPM_get_task_result	(tFromTask,&pcTaskResult);

			if(tToTask != NULLTAG && pcTaskResult != NULL && (tc_strstr(pcTaskResult,OPTIN)!= NULL) && (tRespParty!= NULLTAG) && iRetcode == ITK_ok)
			{
				iRetcode = EPM_assign_responsible_party	(tToTask,tRespParty);
				if((tc_strcmp(pcTaskTypeName,"EPMConditionTask")==0) && iRetcode == ITK_ok)
				{				
					iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_TRUE);

				}
				
			}
			//else if((tc_strstr(pcTaskResult,OPTIN)== NULL) && (tc_strcmp(pcTaskName,pcToTaskName)==0)  && iRetcode == ITK_ok)
			else if( tToTask != NULLTAG  && iRetcode == ITK_ok)
			{
				if((tc_strcmp(pcTaskTypeName,"EPMConditionTask")==0) && iRetcode == ITK_ok)
				{
					iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
				}
				
			}
		}

		SAFE_MEM_free(pcTaskResult);
		SAFE_MEM_free(ptAllSubTaskTags);
		SAFE_MEM_free(pcSubTaskTypeName);
		SAFE_MEM_free(pcSubTaskName);
	
	}		
	else if ( iRetcode != ITK_ok )
	{
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(pcTaskName);
	SAFE_MEM_free(pcTaskTypeName);
	SAFE_MEM_free(pcToTaskName);
	SAFE_MEM_free(pcFromTaskName);
	
	return iRetcode;
}