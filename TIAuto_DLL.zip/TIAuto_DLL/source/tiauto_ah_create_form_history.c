/*******************************************************************************
File         : tiauto_ah_create_form_history.c

Description  : This handler is configured for a pre-condition(TIACheckNonDocumentITRStatus)
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Feb 15, 2010    1.0        Rajesh Natesan    Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>



extern int TIAUTO_AH_create_form_history(EPM_action_message_t msg)
{
   int iRetcode = ITK_ok;
	
	return iRetcode;  
}