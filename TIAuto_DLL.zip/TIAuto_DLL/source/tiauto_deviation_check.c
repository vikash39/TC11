/*******************************************************************************
File         : tiauto_deviation_check.c

Description  : This rule handler validates the documents present in the affected
               items and solution items change folders. The handler must not all
               ow the workflow to progress unless every product revision associa
               ted to it through the TI_DocProdRevisions relationship meets one 
               of the following criteria:
  
Input        : None
                        
Output       : None

Author       : Arun Kumar,TCS

Revision History :
Date            Revision    Who              Description
Nov 09, 2007    1.0         Arun Kumar      Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <stdio.h>
#include <time.h>

int DiffDays(struct tm *pTm_1,struct tm *pTm_2);
int Difference_days(char* date_string_start,char* date_string_end);

EPM_decision_t t1aAUTO_deviation_effectivity(EPM_rule_message_t message)
{

    int iFail = ITK_ok;
    int num_attachments = 0;
    int  count = 0;
	int indx = 0;
    int  days_d =0;

    tag_t   *attachment_tags = NULL;
    tag_t  *secondary_object_tags = NULL;
    tag_t   relation_type = NULLTAG;
	tag_t tRootTask = NULLTAG;

    char    type_name[TCTYPE_name_size_c+1] = "";
	char form_type[TCTYPE_name_size_c+1] = "TI_DEV";

    char*  start_date_att = "t1a51effectivitydatestar";
    char*  end_date_att = "t1a51effectivitydateend";
	char    *date_format = NULL;
    char    *date_string_start = NULL;
	char    *date_string_end = NULL;

	date_t start_date = NULLDATE;
	date_t end_date = NULLDATE;

	EPM_decision_t decision = EPM_go;
	
    date_format = (char *) TC_text ("DefaultDateFormat");
  

	iFail = EPM_ask_root_task(message.task , &tRootTask);
    if (iFail == ITK_ok)
        iFail = EPM_ask_attachments(tRootTask,EPM_target_attachment,
                                      &num_attachments,&attachment_tags);
    if (iFail == ITK_ok && attachment_tags[0] != NULLTAG )
            iFail = tiauto_get_object_name (attachment_tags[0], type_name);

    if( (tc_strcasecmp (type_name , CHANGE_REV)== 0 || tc_strcasecmp (type_name , NEWCHANGE_REV)== 0) && (iFail == ITK_ok) )
    {
        iFail = GRM_find_relation_type( TC_specification_rtype, &relation_type );
        if(iFail == ITK_ok)
            iFail = GRM_list_secondary_objects_only(attachment_tags[0], relation_type, 
                                                        &count, &secondary_object_tags);
    }
    for (indx = 0; indx < count && iFail == ITK_ok; indx++)
    {
        iFail = tiauto_get_object_name (secondary_object_tags[indx], type_name);

        if(tc_strcasecmp(type_name,form_type)== 0 && (iFail == ITK_ok))
           iFail = AOM_ask_value_date(secondary_object_tags[indx],start_date_att,&start_date);
        
		iFail = AOM_ask_value_date(secondary_object_tags[indx],end_date_att,&end_date);
	}
	if(iFail == ITK_ok)
	{
       DATE_date_to_string ( start_date , date_format , &date_string_start);
	   DATE_date_to_string ( end_date, date_format , &date_string_end);
	}

 	days_d = Difference_days(date_string_start,date_string_end);


	if(days_d >30)
	{
		 EMH_store_error_s1(EMH_severity_error,TIAUTO_HANDLER_VALIDATION_ERROR,"The duration between Start date and End date should not exceed 30 days.");
         decision = EPM_nogo;
	}
	else
		decision = EPM_go;
     

	 SAFE_MEM_free (attachment_tags);
	 SAFE_MEM_free (secondary_object_tags);

	return decision;
}

/* Parse the date into corresponding format and load the structure defined in time.h */

int Difference_days(char* date_string_start,char* date_string_end)
{
    
	int day = 0;
	char month[20];
	int month_n=0;
	int year = 0;
	int hour = 0;
	int min=0;
	int idx = 0;
	int year_start = 0;
    int year_end = 0;
	int days_d = 0;
	char dummy_a[10],dummy_c;
	char months[][12] = { "jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
	
	struct tm tm_start = {0};
    struct tm tm_end = {0};
   
 	sscanf_s(date_string_start,"%d %[- ] %[^-] %c %d %d %c %d",&day,dummy_a,9,month,14,&dummy_c,1,&year,&hour,&dummy_c,1,&min);
	printf("Day %d Month %s Year %d Hour %d Min %d\n",day,month,year,hour,min);
	
	month[3] = '\0'; /* Truncate to first character */

	month[0] = (char)tolower(month[0]);
	month[1] = (char)tolower(month[1]);
	month[2] = (char)tolower(month[2]);


	month_n = -1;
	/* A tricky way :( */
        for(idx=0;idx<12;idx++)
	{
		if(tc_strcmp(month,months[idx])==0)
                {
			month_n = idx;	
			break;
		}			
	}

    year_start = year-1900;
	tm_start.tm_sec = 00;
    tm_start.tm_min =min;
    tm_start.tm_hour =hour;
    /* End Time */
    /* Date */
    tm_start.tm_mday =day;
    tm_start.tm_mon  = month_n;  //Remember months start from 0 !one
    tm_start.tm_year = year_start;

	sscanf_s(date_string_end,"%d %[- ] %[^-] %c %d %d %c %d",&day,dummy_a,9,month,14,&dummy_c,1,&year,&hour,&dummy_c,1,&min);
	printf("Day %d Month %s Year %d Hour %d Min %d\n",day,month,year,hour,min);
	
	month[3] = '\0'; /* Truncate to first character */

	month[0] = (char)tolower(month[0]);
	month[1] = (char)tolower(month[1]);
	month[2] = (char)tolower(month[2]);


	month_n = -1;
	/* A tricky way :( */
        for(idx=0;idx<12;idx++)
	{
		if(tc_strcmp(month,months[idx])==0)
                {
			month_n = idx;	
			break;
		}			
	}

	 year_end = year-1900;
	tm_end.tm_sec = 00;
    tm_end.tm_min =min;
    tm_end.tm_hour =hour;
    /* End Time */
    /* Date */
    tm_end.tm_mday =day;
    tm_end.tm_mon  = month_n;  //Remember months start from 0 !one
    tm_end.tm_year = year_end;

   days_d = DiffDays(&tm_start,&tm_end);

  return days_d;

}
/* Function to calculate difference between end time and start time */
int DiffDays(struct tm *pTm_1,struct tm *pTm_2)
{
  time_t t1,t2;
  double diff = 0;
  double days = 0;
  
  t1 = mktime(pTm_1);
  t2 = mktime(pTm_2);
  
  diff = difftime(t2,t1);
  days = diff/(24*60*60);
  return (int)days;

}
