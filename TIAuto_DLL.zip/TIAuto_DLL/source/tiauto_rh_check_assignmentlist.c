/*******************************************************************************
File         : tiauto_rh_check_assignmentlist.c

Description  : This rule handler checks whether the assignment list is applied
				or not. If not, then this handler will display the error 
				message to the user and the decision will be EPM_nogo.
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who             Description
*******************************************************************************
Oct 17, 2011    1.0        Dipak Naik		Initial Creation
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_check_assignment_list(EPM_rule_message_t msg )
{
	int				iRetcode			= ITK_ok;
	int             iNumArgs			= 0; 
    int				i					= 0;
	int				inx					= 0;
	int				iCount				= 0;
	int				iSubTaskCnt			= 0;
	int				isubTaskIndx		= 0;
	int				iNumAttachs			= 0;
	int				iAttchIndx			= 0;

	tag_t			tRootTaskTag		= NULLTAG;
	tag_t			tReposibleParty		= NULLTAG;
	tag_t			tTaskType			= NULLTAG;
	tag_t			tInitiatorTag		= NULLTAG;
	tag_t			tJobTag				= NULLTAG;
	tag_t			tGroupMember		= NULLTAG;
	tag_t			tUser				= NULLTAG;
	tag_t			*ptAttachsTagList	= NULL;//to be freed
	tag_t			*ptTasks			= NULL;//to be freed
	tag_t			*ptReviewSubTasks	= NULL;//to be freed

	char			*pcTaskTypeName					= NULL;
	char			*pcSubTaskType					= NULL;	
	char			*pcErrorMsg						= NULL;
	char		    *pcValue						= NULL;
    char		    *pcFlag							= NULL;
	char			*pcErrMsg						= NULL;
	char			*pcUserName						= NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";
	
	EPM_decision_t decision = EPM_nogo;

	logical lAssignmentListApplied = false;

	EPM_state_t eState ;
	//for review task
	if(msg.proposed_action == EPM_perform_action || 
		msg.proposed_action == EPM_add_attachment_action ||
		msg.proposed_action == EPM_remove_attachment_action ||
		msg.proposed_action == EPM_reject_action ||
		msg.proposed_action == EPM_demote_action )
	{
		decision = EPM_go;
		return decision;
	}	
	//get the no. of arguments
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(i = 0; i < iNumArgs; i++)
		{			
			iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetcode == ITK_ok )
			{
				if (tc_strcasecmp(pcFlag, "error_message") == 0 && pcValue != NULL)
				{
					pcErrorMsg = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcErrorMsg, pcValue);
				}
				else
					iRetcode = EPM_invalid_argument;
			
				if( iRetcode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-RH-check-assignment-list\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;					
				}
			}
		}
		SAFE_MEM_free(pcFlag);
		SAFE_MEM_free(pcValue);
	}
	else
	{
		iRetcode = EPM_invalid_argument;
	}

    if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the user who has initiated the task
		if(iRetcode == ITK_ok)
		{
			iRetcode = AOM_ask_owner(tRootTaskTag,&tInitiatorTag);
		}		
		//Get the job tag
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_job(tRootTaskTag,&tJobTag);
		}
		//Get the subtasks and iterate through them.
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_sub_tasks(tRootTaskTag,&iCount,&ptTasks);
			if(iRetcode == ITK_ok && iCount > 0)
			{
				for(inx= 0;inx<iCount;inx++)
				{	
					if(iRetcode == ITK_ok)
					{
						iRetcode = EPM_ask_state(ptTasks[inx],&eState);
					}
					if(iRetcode == ITK_ok && ptTasks[inx] != NULLTAG)
					{
						iRetcode = TCTYPE_ask_object_type(ptTasks[inx],&tTaskType);
					}
					if(iRetcode == ITK_ok && tTaskType != NULLTAG)
					{
						iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
					}
					if(iRetcode == ITK_ok && eState == EPM_pending && pcTaskTypeName != NULL)
					{
						if( (tc_strcmp(pcTaskTypeName,"EPMReviewTask")==0) ||
								(tc_strcmp(pcTaskTypeName,"EPMAcknowledgeTask")==0) )
						{
							//for review and acknowledge task					
							iRetcode = EPM_ask_sub_tasks( ptTasks[inx], &iSubTaskCnt, &ptReviewSubTasks );
							if( iRetcode == ITK_ok && ptReviewSubTasks != NULL )
							{
								for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && iRetcode == ITK_ok; isubTaskIndx++  )
								{									
									iRetcode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
									if( iRetcode == ITK_ok && pcSubTaskType != NULL && 
										(tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
									{
										// get the signoff object
										if( iRetcode == ITK_ok && ptReviewSubTasks[isubTaskIndx] != NULLTAG)
											iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "signoff_attachments", &iNumAttachs, &ptAttachsTagList);
										// get the user tag from the signoff object
										for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetcode == ITK_ok; iAttchIndx++)
										{
											if( iRetcode == ITK_ok && ptAttachsTagList != NULL)
											{
												iRetcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
												if( iRetcode == ITK_ok && tGroupMember != NULLTAG)
												{
													tReposibleParty = NULLTAG;
													iRetcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
												}
												if( iRetcode == ITK_ok && tReposibleParty != tInitiatorTag)
												{
													lAssignmentListApplied = true;
													break;
												}												
											}
										}										
										SAFE_MEM_free(ptAttachsTagList);
										if(lAssignmentListApplied == true)
										{
											break;
										}
									}
									SAFE_MEM_free(pcSubTaskType);
								}
							}
							SAFE_MEM_free(ptReviewSubTasks);
						}
						//for other task type						
						else
						{
							//get the responsible party of the task
							iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
							if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
							{
								if( iRetcode == ITK_ok && tReposibleParty != tInitiatorTag)
								{
									lAssignmentListApplied = true;
									break;
								}	
							}
						}
						
						if(lAssignmentListApplied == true)
						{
							break;
						}
					}
					SAFE_MEM_free(pcTaskTypeName);	
				}//for loop ends here.
				SAFE_MEM_free(pcTaskTypeName);	
				SAFE_MEM_free(ptReviewSubTasks);
				SAFE_MEM_free(pcSubTaskType);
			}
		}
		
		//get current logged in user    	
		iRetcode = POM_get_user (&pcUserName, &tUser);
		if(iRetcode == ITK_ok && (msg.task != NULLTAG) )
		{
			iRetcode = TCTYPE_ask_object_type(msg.task,&tTaskType);
		}
		if(iRetcode == ITK_ok && tTaskType != NULLTAG)
		{
			iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
		}
		if(iRetcode == ITK_ok && lAssignmentListApplied == false && pcErrorMsg != NULL )
		{
			decision = EPM_nogo;
			if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
			{
				iRetcode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
			}
			iRetcode = TIAUTO_ASSIGNMENT_LIST_NOT_APPLIED;
			TC_write_syslog(pcErrorMsg);
			EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrorMsg) ;
			
		}
		else if(iRetcode == ITK_ok && lAssignmentListApplied == true)
		{
			decision = EPM_go;
		}
		SAFE_MEM_free(pcTaskTypeName);
		SAFE_MEM_free(ptTasks);
		SAFE_MEM_free(pcTaskTypeName);
	}

	if ( iRetcode != ITK_ok && iRetcode != TIAUTO_ASSIGNMENT_LIST_NOT_APPLIED)
	{
		decision = EPM_nogo;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	
	SAFE_MEM_free(pcErrorMsg);

	return decision;  
}
