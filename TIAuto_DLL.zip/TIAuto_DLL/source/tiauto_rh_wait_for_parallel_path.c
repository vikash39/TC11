/*******************************************************************************
File         : tiauto_rh_wait_for_parallel_path.c

Description  : This rule handler checks whether all the predecessor parallel tasks
				are completed or not. If not, then the task will wait for all the 
				dependency tasks completion.
               
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who					Description
*******************************************************************************
Oct 16, 2011    1.0		Dipak Naik		Initial Creation
*******************************************************************************/

/* includes */

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_wait_for_parallel_path( EPM_rule_message_t msg )
{
	int		iRetCode		= ITK_ok;
	int		i				= 0;
	int		iPredCnt		= 0;
	tag_t	tTemplate		= NULLTAG;
	tag_t	tRootTask		= NULLTAG;
	tag_t	tSubTask		= NULLTAG;
	tag_t	*ptPredecessor	= NULL;
	char	*pcTaskName		= NULL;
	
	EPM_state_t eState ;
	logical lAllPredSatisfied = true;

	EPM_decision_t decision = EPM_go;
	
	//Get the root task
	iRetCode =  EPM_ask_root_task( msg.task, &tRootTask);
	//get the task template
	if(iRetCode == ITK_ok && tRootTask != NULLTAG)
		iRetCode = AOM_ask_value_tag  ( msg.task, "task_template" , &tTemplate);
	//get the dependant task template
	if(iRetCode == ITK_ok && tTemplate != NULLTAG)
		iRetCode = AOM_ask_value_tags(tTemplate,"dependency_task_templates",&iPredCnt,&ptPredecessor); 
	
	for(i=0;(i<iPredCnt) && (iRetCode == ITK_ok) ;i++)
	{
		tSubTask = NULLTAG;
		//get the template name
		if(iRetCode == ITK_ok && ptPredecessor[i] != NULLTAG)
			iRetCode = AOM_ask_name(ptPredecessor[i],&pcTaskName);
		//get the task tag 
		if(iRetCode == ITK_ok && tRootTask != NULLTAG)
			iRetCode = EPM_ask_sub_task  (  tRootTask, pcTaskName,&tSubTask);
		//check the state of the task
		if(iRetCode == ITK_ok && tSubTask != NULLTAG)
			iRetCode = EPM_ask_state (tSubTask,&eState);

		SAFE_MEM_free(pcTaskName);
		if(iRetCode == ITK_ok && eState == EPM_completed)
		{
			lAllPredSatisfied = true;
		}
		else if(iRetCode == ITK_ok)
		{
			//if all the predecessors are not completed, then exit
			lAllPredSatisfied = false;
			break;
		}
	}

	if(iRetCode == ITK_ok && lAllPredSatisfied == true)
	{
		decision = EPM_go;
	}
	else
	{
		decision = EPM_undecided;
	}

	SAFE_MEM_free(ptPredecessor);

	return decision;
}
