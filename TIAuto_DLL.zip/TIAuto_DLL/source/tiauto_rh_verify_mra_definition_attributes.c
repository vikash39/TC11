/************************************************************************************************
FILE        :   tiauto_rh_verify_mra_definition_attributes.c

DESCRIPTION :   

AUTHOR      :   Pradeep, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
5 Aug, 2016    1.0        Dipak	         Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_mra_definition_attributes(EPM_rule_message_t msg)
{
	int				 iRetCode									= ITK_ok;
	int				iNewAseemCount								= 0;
	int				iCompMRACount								= 0;
	int             iCompMRAIndx                                = 0;
	int             iNewAssyIndx                                = 0;

	char		    acRootTaskName[WSO_name_size_c+1]			= "";
	char			szErrorString[TIAUTO_error_message_len+1]	= "";

	tag_t			tChangeRev									= NULLTAG;
	tag_t			tRootTask									= NULLTAG;
	tag_t           tChangeForm									= NULLTAG;
	
	tag_t			*ptNewAssembly								= NULL;
	tag_t			*ptCompMRA									= NULL;
	
	char *pcParentItemrev = NULL;
	char *pcObjectType = NULL;

	EPM_decision_t decision = EPM_go;

	//get the root task
	iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	

	//Conditional Task result decision
	//if ( bValidERPPlant == true && bMfgRelToBeCreated == true && iRetCode == ITK_ok)
	//if ( bMfgRelToBeCreated == true && iRetCode == ITK_ok)
	if ( iRetCode == ITK_ok && (  ( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0) || 
								  (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0)  ||
								  ( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0) || 
								  (tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0)  ||
								  ( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0) || 
								  (tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0)  ||
								  (tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0) ||
								  (tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0)) )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//read the change form and
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_120componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else 
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP2",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else 
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP3",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_PMR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PMR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TPR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201newacdassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201componentacd",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TER",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205newacdassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205componentmra",&iCompMRACount,&ptCompMRA);
				}
			}

			for(iNewAssyIndx = 0;iNewAssyIndx<iNewAseemCount;iNewAssyIndx++)
			{
				WSOM_ask_object_type2(ptNewAssembly[iNewAssyIndx],&pcObjectType);
				if(pcObjectType != NULL && tc_strcmp(pcObjectType,"TI_Product Revision") != 0 && tc_strcmp(pcObjectType,"TI_Prg_Variant Revision") != 0)
				{
					WSOM_ask_id_string(ptNewAssembly[iNewAssyIndx],&pcParentItemrev);
					tc_strcpy(szErrorString,"");
					TI_sprintf(szErrorString, "%s\n" ,pcParentItemrev);
					EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_ALLOWED_TYPE,szErrorString);	
					iRetCode = TIAUTO_NOT_ALLOWED_TYPE;
					decision = EPM_nogo;
				}
				for(iCompMRAIndx = iNewAssyIndx+1;iCompMRAIndx<iNewAseemCount;iCompMRAIndx++)
				{
					if(ptNewAssembly[iNewAssyIndx] == ptNewAssembly[iCompMRAIndx])
					{
						WSOM_ask_id_string(ptNewAssembly[iNewAssyIndx],&pcParentItemrev);
						tc_strcpy(szErrorString,"");
						TI_sprintf(szErrorString, "The item revision %s is added multiple times to the MRA Assembly field. Please remove the duplicate entries.\n" ,pcParentItemrev);
						EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_ALLOWED_TYPE,szErrorString);	
						iRetCode = TIAUTO_NOT_ALLOWED_TYPE;
						decision = EPM_nogo;
					}
				}
			}
			for(iCompMRAIndx = 0;iCompMRAIndx<iCompMRACount;iCompMRAIndx++)
			{
				WSOM_ask_object_type2(ptCompMRA[iCompMRAIndx],&pcObjectType);
				if(pcObjectType != NULL && tc_strcmp(pcObjectType,"TI_Product Revision") != 0 )
				{
					WSOM_ask_id_string(ptCompMRA[iCompMRAIndx],&pcParentItemrev);
					tc_strcpy(szErrorString,"");
					TI_sprintf(szErrorString, "%s\n" ,pcParentItemrev);
					EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_ALLOWED_TYPE,szErrorString);	
					iRetCode = TIAUTO_NOT_ALLOWED_TYPE;
					decision = EPM_nogo;
				}
			}

			
		}
	}
	
	if(decision == EPM_nogo)
	{
		if(tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
		{
			TI_sprintf(szErrorString, "\nYou are not allowed to add item revisions other than the TI_Product and TI_Prg_Variant Revision in MRA Assembly field and TI_Product Revision in Component MRA field of CAP Form (MRA Definition TAB).\n");
		}
		else if(tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0 )
		{
			TI_sprintf(szErrorString, "\nYou are not allowed to add item revisions other than the TI_Product Revision and TI_Prg_Variant Revision in MRA Assembly field and TI_Product Revision in Component MRA field of PMR Form (MRA Definition TAB).\n");
		}
		if(tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 || tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 )
		{
			TI_sprintf(szErrorString, "\nYou are not allowed to add item revisions other than the TI_Product Revision and TI_Prg_Variant Revision in TRA Assembly field and TI_Product Revision in Component TRA field of TER/TPR Form (TRA Definition TAB).\n");
		}
		TC_write_syslog(szErrorString);
		EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_ALLOWED_TYPE, szErrorString) ;
						
	}

	SAFE_MEM_free (ptNewAssembly);
	SAFE_MEM_free (ptCompMRA);

	return decision;
}
