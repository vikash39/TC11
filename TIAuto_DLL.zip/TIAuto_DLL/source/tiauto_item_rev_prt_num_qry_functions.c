/*==========================================================================================================
These are functions related to the user query - "Item Revision - Any Part Number"
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
06-Sep-2011		1.0			Nivedita K			Initial Creation     
01-Mar-2012		1.1			Mahesh BS			Modified the "IsPresentInIFSCATPart" function code to check query
												is returning form tag or Item revision tag if it is retruning form tag
												then getting the related Itemrevision tag.
******************************************************************************************************************/

#include <tiauto_item_rev_any_prt_num_functions.h>

/*=============================================================================================================
*		IsPresentInAltId()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the alt id and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInAltId(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	//craete alias
	ifail = POM_enquiry_create_class_alias ( "PresentinAltId", "Identifier",1,"Identifier_alias");
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","Item","puid",POM_enquiry_equal,"Identifier","altid_of");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_2", "Identifier","idfr_id",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_2",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_3","Identifier","puid",POM_enquiry_equal,"Identifier_alias","suppl_context");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_4","Identifier_alias","altid_of",POM_enquiry_equal,"ItemRevision","puid");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_5","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and, "auniqueExprId_3");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and, "auniqueExprId_4");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and, "auniqueExprId_5");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_13");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}

/*=============================================================================================================
*		IsPresentInAltIdName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the alt id name and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInAltIdName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	//craete alias
	ifail = POM_enquiry_create_class_alias ( "PresentinAltId", "Identifier",1,"Identifier_alias");
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","Item","puid",POM_enquiry_equal,"Identifier","altid_of");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_2","Identifier","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_3", "WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_3",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_4","Identifier","puid",POM_enquiry_equal,"Identifier_alias","suppl_context");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_5","Identifier_alias","altid_of",POM_enquiry_equal,"ItemRevision","puid");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_6","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and, "auniqueExprId_3");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and, "auniqueExprId_4");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and, "auniqueExprId_5");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_14","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_6");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_14");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInAltIdDescription()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the alt id description and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInAltIdDescription(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	//craete alias
	ifail = POM_enquiry_create_class_alias ( "PresentinAltId", "Identifier",1,"Identifier_alias");
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","Item","puid",POM_enquiry_equal,"Identifier","altid_of");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_2","Identifier","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_3", "WorkspaceObject","object_desc",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_3",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_4","Identifier","puid",POM_enquiry_equal,"Identifier_alias","suppl_context");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_5","Identifier_alias","altid_of",POM_enquiry_equal,"ItemRevision","puid");
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_6","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and, "auniqueExprId_3");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and, "auniqueExprId_4");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and, "auniqueExprId_5");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_14","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_6");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_14");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInDatasetName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the dataset name and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInDatasetName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	//create a query
	ifail = POM_enquiry_create ("PresentinDatasetName");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinDatasetName", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetName","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetName","auniqueExprId_2","Dataset","puid",POM_enquiry_equal,"ImanRelation","secondary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetName","auniqueExprId_3","Dataset","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinDatasetName", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinDatasetName","auniqueExprId_4","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinDatasetName","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetName","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetName","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetName","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinDatasetName","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinDatasetName", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinDatasetName",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinDatasetName");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}

	return ifail;
}
/*=============================================================================================================
*		IsPresentInDatasetDescription()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the dataset description and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInDatasetDescription(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
		ifail = POM_enquiry_create ("PresentinDatasetDesc");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinDatasetDesc", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetDesc","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetDesc","auniqueExprId_2","Dataset","puid",POM_enquiry_equal,"ImanRelation","secondary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetDesc","auniqueExprId_3","Dataset","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinDatasetDesc", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinDatasetDesc","auniqueExprId_4","WorkspaceObject","object_desc",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinDatasetDesc","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetDesc","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetDesc","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetDesc","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinDatasetDesc","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinDatasetDesc", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinDatasetDesc",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinDatasetDesc");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}		

	return ifail;
}
/*=============================================================================================================
*		IsPresentInDatasetNamedRef()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the dataset named reference and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInDatasetNamedRef(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	char *pcDotFind = NULL;
	int iStringSize = 0;
	const char *pcSearchKey = NULL;
	const char* select_attr_list1[] = { "puid"};
	
	iStringSize = (int)tc_strlen(Keyword);

	pcSearchKey = (char *)MEM_alloc(iStringSize + 3);
	tc_strcpy(pcSearchKey,Keyword);
		
	//check whether '.' is present in the string
	pcDotFind = strchr(Keyword, '.');

	if(pcDotFind == NULL)
	{		
		if( Keyword[(iStringSize-1)] != '*' )
		{
			tc_strcat(pcSearchKey,".*");
		}
	}
	//create the query
	ifail = POM_enquiry_create ("PresentinDatasetNamedRef");	
	/*Create a pseudo-class for the Dataset.ref_list attribute.*/
	ifail = POM_enquiry_set_pseudo_calias ( "PresentinDatasetNamedRef", "Dataset","ref_list","REF_LIST_0");
	//select statement
	ifail = POM_enquiry_add_select_attrs ( "PresentinDatasetNamedRef", "ItemRevision", 1, select_attr_list1);
	//query statement
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinDatasetNamedRef", "aunique_value_id1", 1,&pcSearchKey, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinDatasetNamedRef","auniqueExprId_1","ImanFile","original_file_name",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinDatasetNamedRef","auniqueExprId_1",POM_case_insensitive);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetNamedRef", "auniqueExprId_2","ImanFile","puid",POM_enquiry_equal,"REF_LIST_0","pval");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetNamedRef", "auniqueExprId_3","REF_LIST_0","puid",POM_enquiry_equal,"Dataset","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetNamedRef","auniqueExprId_4","Dataset","puid",POM_enquiry_equal,"ImanRelation","secondary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinDatasetNamedRef","auniqueExprId_5","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetNamedRef","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetNamedRef","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetNamedRef","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_4");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinDatasetNamedRef","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_5");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinDatasetNamedRef","auniqueExprId_13");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinDatasetNamedRef", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinDatasetNamedRef",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinDatasetNamedRef");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}		
	MEM_free(pcSearchKey);

	return ifail;
}
/*=============================================================================================================
*		IsPresentInLegacyPartNum()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the legacy form part number attribute and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInLegacyPartNum(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinLegacyPrtNum");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinLegacyPrtNum", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a24LegacySystem","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinLegacyPrtNum", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinLegacyPrtNum","auniqueExprId_4","t1a24LegacySystem","t1a24partnumber",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinLegacyPrtNum","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinLegacyPrtNum","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinLegacyPrtNum", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinLegacyPrtNum",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinLegacyPrtNum");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}

	return ifail;
}
/*=============================================================================================================
*		IsPresentInLegacyPartDesc()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the legacy form part description attribute and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInLegacyPartDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinLegacyPrtNum");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinLegacyPrtNum", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a24LegacySystem","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinLegacyPrtNum", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinLegacyPrtNum","auniqueExprId_4","t1a24LegacySystem","t1a24partdescription",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinLegacyPrtNum","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinLegacyPrtNum","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinLegacyPrtNum", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinLegacyPrtNum",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinLegacyPrtNum");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}	

	return ifail;
}
/*=============================================================================================================
*		IsPresentInItemId()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the legacy form part name field and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInLegacyPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinLegacyPrtNum");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinLegacyPrtNum", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinLegacyPrtNum","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a24LegacySystem","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinLegacyPrtNum", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinLegacyPrtNum","auniqueExprId_4","t1a24LegacySystem","t1a24partname",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinLegacyPrtNum","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinLegacyPrtNum","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinLegacyPrtNum","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinLegacyPrtNum", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinLegacyPrtNum",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinLegacyPrtNum");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}	

	return ifail;
}
/*=============================================================================================================
*		IsPresentInItemId()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the item id field and 
			matching item will be returned.
================================================================================================================*/
extern int IsPresentInItemId(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_1", "Item","item_id",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_1",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_2","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_10");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInItemName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the item name field and 
			matching item will be returned.
================================================================================================================*/
extern int IsPresentInItemName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_2", "WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_2",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_3","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and, "auniqueExprId_3");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_11");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInItemDesc()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the item description field and 
			matching item will be returned.
================================================================================================================*/
extern int IsPresentInItemDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_2", "WorkspaceObject","object_desc",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_2",POM_case_insensitive);
	ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_3","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and, "auniqueExprId_3");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_11");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInItemRevDesc()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the item revision description field and 
			matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInItemRevDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinAltId");	
	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinAltId", "ItemRevision", 1, select_attr_list1);
    
    ifail = POM_enquiry_set_join_expr ("PresentinAltId","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	ifail = POM_enquiry_set_string_value ( "PresentinAltId", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ( "PresentinAltId","auniqueExprId_2", "WorkspaceObject","object_desc",POM_enquiry_like,"aunique_value_id1");
	ifail = POM_enquiry_set_expr_proprety ("PresentinAltId","auniqueExprId_2",POM_case_insensitive);
	//join the expression
	ifail = POM_enquiry_set_expr("PresentinAltId","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinAltId","auniqueExprId_10");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinAltId", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinAltId",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinAltId");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}
/*=============================================================================================================
*		IsPresentInPurchSuppPartNum()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the supplier part number field of the Purchased Cost 
			form and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPurchSuppPartNum(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinPurchSuppPrtNum");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPurchSuppPrtNum", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtNum","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtNum","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtNum","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a18purchasedcost","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPurchSuppPrtNum", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPurchSuppPrtNum","auniqueExprId_4","t1a18purchasedcost","t1a18supplierpartnumber",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPurchSuppPrtNum","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtNum","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtNum","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtNum","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPurchSuppPrtNum","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPurchSuppPrtNum", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPurchSuppPrtNum",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPurchSuppPrtNum");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}

	return ifail;
}
/*=============================================================================================================
*		IsPresentInPurchSuppPartDesc()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the supplier part description field of the Purchased Cost 
			form and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPurchSuppPartDesc(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinPurchSuppPrtDesc");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPurchSuppPrtDesc", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtDesc","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtDesc","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtDesc","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a18purchasedcost","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ("PresentinPurchSuppPrtDesc", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPurchSuppPrtDesc","auniqueExprId_4","t1a18purchasedcost","t1a18supplierpartdescrip",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPurchSuppPrtDesc","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtDesc","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtDesc","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtDesc","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPurchSuppPrtDesc","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPurchSuppPrtDesc", true);
	//execute the wuery
	ifail = POM_enquiry_execute ("PresentinPurchSuppPrtDesc",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPurchSuppPrtDesc");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}	

	return ifail;
}
/*=============================================================================================================
*		IsPresentInPurchSuppPartName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the supplier part name field of the Purchased Cost 
			form and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPurchSuppPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("PresentinPurchSuppPrtName");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPurchSuppPrtName", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtName","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtName","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPurchSuppPrtName","auniqueExprId_3","Form","data_file",POM_enquiry_equal,"t1a18purchasedcost","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPurchSuppPrtName", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPurchSuppPrtName","auniqueExprId_4","t1a18purchasedcost","t1a18supplierpartname",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPurchSuppPrtName","auniqueExprId_4",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtName","auniqueExprId_5","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtName","auniqueExprId_6","auniqueExprId_5",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPurchSuppPrtName","auniqueExprId_7","auniqueExprId_6",POM_enquiry_and,"auniqueExprId_4");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPurchSuppPrtName","auniqueExprId_7");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPurchSuppPrtName", true);
	//execute the wuery
	ifail = POM_enquiry_execute ("PresentinPurchSuppPrtName",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPurchSuppPrtName");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}	

	return ifail;
}
/*=============================================================================================================
*		IsPresentInIFSCATPart()
*\param				const char* Keyword						<I>
*					int *iNumTotalTags						<O>
*					TIA_UniqueWSOMObjects **UniqueObjects	<O>
*\return int				
* Description:
*			Execute the IFS_CATPart_query with the value mentioned in the keyword and searches in all the 
			attributes of query and store the result in the structure UniqueObjects.
================================================================================================================*/
extern int IsPresentInIFSCATPart(const char* Keyword ,int *iNumTotalTags,TIA_UniqueWSOMObjects **UniqueObjects)
{
	int iRetCode		= ITK_ok;
	int iEnttryCnt		= 0;
	int iCount			= 0;
	int iResultCount	= 0;
	int indx			= 0;
	int	indy			= 0;
	int	iNo_Level		= 2;  
	int	iReffound		= 0; 
	int	*pilevels		= {0};  

	tag_t tQuery		= NULLTAG;
	tag_t *ptResults	= NULL;
	tag_t *ptRef		= NULL;  
	tag_t tClass_1		= NULL_TAG;
	tag_t tClass_2		= NULL_TAG;

	char    *pcQueryName = "IFS_CATPart_query";
	char	**pcQentries							= NULL;
	char	**pcQvalues								= NULL;
	char	**pcQueryEntries						= NULL;
	char	**pcQueryValues							= NULL;
	char	**pcRelations							= NULL;
	char	acObj_Class_1[TCTYPE_class_name_size_c+1]= "";
	char	acObj_Class_2[TCTYPE_class_name_size_c+1]= "";

	//check the given input query exist or not
	iRetCode = QRY_find(pcQueryName,&tQuery);
	if ( iRetCode == ITK_ok  && tQuery != NULLTAG)		
		iRetCode = QRY_find_user_entries( tQuery, &iEnttryCnt, &pcQentries, &pcQvalues );
	if ( iRetCode == ITK_ok  && tQuery != NULLTAG && iEnttryCnt > 0)
	{
		for(iCount = 0; iCount < iEnttryCnt;iCount++)
		{
			//assign the valule for the user entries
			pcQueryEntries = (char **)MEM_alloc(sizeof(char *));
			pcQueryEntries[0] = (char *) MEM_alloc((int)(tc_strlen(pcQentries[iCount]) + 1) * sizeof(char));
			TI_sprintf(pcQueryEntries[0],"%s",pcQentries[iCount]); 
			//assign the valule for the user entry value
			pcQueryValues = (char **)MEM_alloc(sizeof(char *));
			pcQueryValues[0] = (char *) MEM_alloc((int)(tc_strlen(Keyword) + 1) * sizeof(char));
			TI_sprintf(pcQueryValues[0],"%s",Keyword); 
			
			//execute the query
			iRetCode = QRY_execute(tQuery, 1, pcQueryEntries, pcQueryValues, &iResultCount, &ptResults);
			
			//store the output result
			for(indx = 0; (indx < iResultCount) && (iRetCode == ITK_ok );indx++)
			{
				iRetCode =TCTYPE_ask_object_type(ptResults[indx],&tClass_1);
				if(tClass_1!=NULL_TAG && iRetCode == ITK_ok)
				{
					tc_strcpy(acObj_Class_1,"");
					iRetCode =TCTYPE_ask_class_name(tClass_1,acObj_Class_1);
					if(tc_strcmp(acObj_Class_1,"ItemRevision")==0 && iRetCode==ITK_ok)
					{						
						tiauto_Store_wsom_tags(UniqueObjects,iNumTotalTags,ptResults[indx]);
					}
					else if(tc_strcmp(acObj_Class_1,"Form")==0 && iRetCode==ITK_ok)
					{
						iRetCode = WSOM_where_referenced(ptResults[indx],iNo_Level, &iReffound, &pilevels, &ptRef, &pcRelations);
						for(indy = 0; (indy < iReffound) && (iRetCode == ITK_ok );indy++)
						{
							iRetCode =TCTYPE_ask_object_type(ptRef[indy],&tClass_2);
							if(tClass_2 && iRetCode == ITK_ok)
							{
								tc_strcpy(acObj_Class_2,"");
								iRetCode =TCTYPE_ask_class_name (tClass_2,acObj_Class_2);
								if(iRetCode == ITK_ok && tc_strcmp(acObj_Class_2,"ItemRevision")==0)
								{						
									tiauto_Store_wsom_tags(UniqueObjects,iNumTotalTags,ptRef[indy]);
								}
							}
						}
						SAFE_MEM_free(ptRef);
						SAFE_MEM_free(pilevels);
						SAFE_MEM_free(pcRelations);		
					}
				}				
			}
			SAFE_MEM_free(ptResults);
			SAFE_MEM_free(pcQueryEntries);
			SAFE_MEM_free(pcQueryValues);
		}
		SAFE_MEM_free(pcQentries);
		SAFE_MEM_free(pcQvalues);
	}
	return iRetCode;
}


/*=============================================================================================================
*		IsPresentPartnerSubmission()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the partner submission form and 
			matching item will be returned.
================================================================================================================*/
extern int IsPresentInPartnerSubmissionPartNum(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags)
{
	int ifail	= ITK_ok;
	int rows	= 0;
	int cols	= 0;
	int i		=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinPartnerSubmission");	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinPartnerSubmission", "ItemRevision", 1, select_attr_list1);
	//create alias
	//ifail = POM_enquiry_create_class_alias ("PresentinPartnerSubmission", "WorkSpaceObject", 1, "WorkSpaceObject_alias");
    
    //ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_1","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_2","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");	
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_4","Form","data_file",POM_enquiry_equal,pcClassName,"puid");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_5","ItemRevision","puid",POM_enquiry_equal,"WorkSpaceObject","puid"); 
   // ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_6","ItemRevision","items_tag",POM_enquiry_equal,"WorkSpaceObject_alias","puid"); 
	//ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_7","WorkSpaceObject", "puid", POM_enquiry_equal, "Pom_application_object", "puid");

	ifail = POM_enquiry_set_string_value ("PresentinPartnerSubmission", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ("PresentinPartnerSubmission","auniqueExprId_8",pcClassName,"t8_partnumber",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerSubmission","auniqueExprId_8",POM_case_insensitive);
	//join the expression
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_11","auniqueExprId_2",POM_enquiry_and, "auniqueExprId_3");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and, "auniqueExprId_4");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and, "auniqueExprId_5");
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_14","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_6");
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_15","auniqueExprId_14",POM_enquiry_and, "auniqueExprId_7");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_16","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_8");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPartnerSubmission","auniqueExprId_16");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPartnerSubmission", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPartnerSubmission",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPartnerSubmission");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}

/*=============================================================================================================
*		IsPresentPartnerSubmission()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the partner submission form and 
			matching item will be returned.
================================================================================================================*/
extern int IsPresentInPartnerSubmissionDocNum(const char* Keyword ,char *pcClassName, int *iNumFound,tag_t **foundTags)
{
	int ifail	= ITK_ok;
	int rows	= 0;
	int cols	= 0;
	int i		=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};

    ifail = POM_enquiry_create ("PresentinPartnerSubmission");	
	//select output attribute
	ifail = POM_enquiry_add_select_attrs ( "PresentinPartnerSubmission", "ItemRevision", 1, select_attr_list1);
	//create alias
	//ifail = POM_enquiry_create_class_alias ("PresentinPartnerSubmission", "WorkSpaceObject", 1, "WorkSpaceObject_alias");
    
    //ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_1","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_2","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");	
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_4","Form","data_file",POM_enquiry_equal,pcClassName,"puid");
	ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_5","ItemRevision","puid",POM_enquiry_equal,"WorkSpaceObject","puid"); 
    //ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_6","ItemRevision","items_tag",POM_enquiry_equal,"WorkSpaceObject_alias","puid"); 
	//ifail = POM_enquiry_set_join_expr ("PresentinPartnerSubmission","auniqueExprId_7","WorkSpaceObject", "puid", POM_enquiry_equal, "Pom_application_object", "puid");

	ifail = POM_enquiry_set_string_value ("PresentinPartnerSubmission", "aunique_value_id1", 1,&Keyword, POM_enquiry_bind_value );
	ifail = POM_enquiry_set_attr_expr ("PresentinPartnerSubmission","auniqueExprId_8",pcClassName,"t8_documentnumber",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerSubmission","auniqueExprId_8",POM_case_insensitive);
	//join the expression
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_10","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_11","auniqueExprId_2",POM_enquiry_and, "auniqueExprId_3");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and, "auniqueExprId_4");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and, "auniqueExprId_5");
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_14","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_6");
	//ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_15","auniqueExprId_14",POM_enquiry_and, "auniqueExprId_7");
	ifail = POM_enquiry_set_expr("PresentinPartnerSubmission","auniqueExprId_16","auniqueExprId_13",POM_enquiry_and, "auniqueExprId_8");
	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPartnerSubmission","auniqueExprId_16");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPartnerSubmission", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPartnerSubmission",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPartnerSubmission");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}

		MEM_free(report);
	}
    return ifail;
}

/*=============================================================================================================
*		IsPresentInPartnerCADFileName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the File name field of the PartnerCADImportForm 
			and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPartnerCADFileName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	const char* Object_Type[] = { "T8_TI_PartnerCADImportForm"};

	ifail = POM_enquiry_create ("PresentinPartnerCADFileName");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPartnerCADFileName", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADFileName","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADFileName","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Dataset","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADFileName","auniqueExprId_3","Dataset","ref_list",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADFileName","auniqueExprId_4","Form","puid",POM_enquiry_equal,"WorkSpaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADFileName","auniqueExprId_5","Form","data_file",POM_enquiry_equal,"T8_176PartnerCADImportForm","puid");

	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADFileName", "aunique_value_id1", 1,Object_Type, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADFileName","auniqueExprId_6","WorkSpaceObject","object_type",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADFileName","auniqueExprId_6",POM_case_insensitive);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADFileName", "aunique_value_id2", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADFileName","auniqueExprId_7","T8_176PartnerCADImportForm","t8_176filename",POM_enquiry_like,"aunique_value_id2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADFileName","auniqueExprId_7",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_8","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_9","auniqueExprId_8",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_4");
	 if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_5");
	  if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_6");
	   if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADFileName","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_7");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPartnerCADFileName","auniqueExprId_13");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPartnerCADFileName", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPartnerCADFileName",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPartnerCADFileName");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}

	return ifail;
}
/*=============================================================================================================
*		IsPresentInPartnerCADPartName()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the Part name field of the PartnerCADImportForm 
			and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPartnerCADPartName(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	const char* Object_Type[] = { "T8_TI_PartnerCADImportForm"};

	ifail = POM_enquiry_create ("PresentinPartnerCADPartName");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPartnerCADPartName", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartName","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartName","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Dataset","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartName","auniqueExprId_3","Dataset","ref_list",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartName","auniqueExprId_4","Form","puid",POM_enquiry_equal,"WorkSpaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartName","auniqueExprId_5","Form","data_file",POM_enquiry_equal,"T8_176PartnerCADImportForm","puid");

	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADPartName", "aunique_value_id1", 1,Object_Type, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADPartName","auniqueExprId_6","WorkSpaceObject","object_type",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADPartName","auniqueExprId_6",POM_case_insensitive);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADPartName", "aunique_value_id2", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADPartName","auniqueExprId_7","T8_176PartnerCADImportForm","t8_176partname",POM_enquiry_like,"aunique_value_id2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADPartName","auniqueExprId_7",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_8","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_9","auniqueExprId_8",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_4");
	 if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_5");
	  if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_6");
	   if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartName","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_7");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPartnerCADPartName","auniqueExprId_13");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPartnerCADPartName", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPartnerCADPartName",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPartnerCADPartName");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}

	return ifail;
}
/*=============================================================================================================
*		IsPresentInPartnerCADPartNumber()
*\param				const char* Keyword						<I>
*					int *iNumFound							<O>
*					tag_t **foundTags						<O>
*\return int				
* Description:
*			Searches the value mentioned in the keyword in the Part number field of the PartnerCADImportForm 
			and matching item revision will be returned.
================================================================================================================*/
extern int IsPresentInPartnerCADPartNumber(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
	const char* Object_Type[] = { "T8_TI_PartnerCADImportForm"};

	ifail = POM_enquiry_create ("PresentinPartnerCADPartNumber");	
	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "PresentinPartnerCADPartNumber", "ItemRevision", 1, select_attr_list1);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartNumber","auniqueExprId_1","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartNumber","auniqueExprId_2","ImanRelation","secondary_object",POM_enquiry_equal,"Dataset","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartNumber","auniqueExprId_3","Dataset","ref_list",POM_enquiry_equal,"Form","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartNumber","auniqueExprId_4","Form","puid",POM_enquiry_equal,"WorkSpaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr ("PresentinPartnerCADPartNumber","auniqueExprId_5","Form","data_file",POM_enquiry_equal,"T8_176PartnerCADImportForm","puid");

	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADPartNumber", "aunique_value_id1", 1,Object_Type, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADPartNumber","auniqueExprId_6","WorkSpaceObject","object_type",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADPartNumber","auniqueExprId_6",POM_case_insensitive);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value ( "PresentinPartnerCADPartNumber", "aunique_value_id2", 1,&Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr ("PresentinPartnerCADPartNumber","auniqueExprId_7","T8_176PartnerCADImportForm","t8_176partnumber",POM_enquiry_like,"aunique_value_id2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("PresentinPartnerCADPartNumber","auniqueExprId_7",POM_case_insensitive);
	//join the expression
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_8","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_9","auniqueExprId_8",POM_enquiry_and,"auniqueExprId_3");
    if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_4");
	 if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_5");
	  if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_6");
	   if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr("PresentinPartnerCADPartNumber","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_7");

	//set where expression
	ifail = POM_enquiry_set_where_expr("PresentinPartnerCADPartNumber","auniqueExprId_13");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("PresentinPartnerCADPartNumber", true);
	//execute the wuery
	ifail = POM_enquiry_execute ( "PresentinPartnerCADPartNumber",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("PresentinPartnerCADPartNumber");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}

	return ifail;
}
