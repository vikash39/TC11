/************************************************************************************************************
File         : tiauto_ah_create_baselinewatermark_translation_request.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
Nov 13, 2014    1.0        Dipak Naik      Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <time.h>


int verify_DatasetType_NamedRef(tag_t tItemRev, logical* lisValid)
{
	int		iRetCode									= ITK_ok;
	int		iSecObjCnt									= 0;
	int		i											= 0;
	int		j											= 0;
	int		iDatasetRefCnt								= 0;

	char	acSecObjType[WSO_name_size_c+1]				= "";
	char	acDatasetName[WSO_name_size_c+1]			= "";
	char	acDatasetRefName[AE_reference_size_c + 1]	= "";
	char*	pcRefName									= NULL;
	char*	pcRet										= NULL;
	char*   pcParentItemRev								= NULL;
	char*   pcRelationTypeName							= NULL;	

	tag_t   tParentItemRev								= NULLTAG;
	tag_t	tDatasetRef									= NULLTAG;
	tag_t	tRefName									= NULLTAG;
	//tag_t*	ptSecObjList								= NULL;

	AE_reference_type_t    tdfDatasetRefType;

	GRM_relation_t*    tdSecObjList;

	*lisValid = false;

	iRetCode = WSOM_ask_based_on (tItemRev, &tParentItemRev);
	if (iRetCode == 0 && tParentItemRev != NULLTAG)
	{
		iRetCode = AOM_ask_value_string(tParentItemRev, "object_string", &pcParentItemRev);

		iRetCode = GRM_list_secondary_objects (tParentItemRev, NULLTAG, &iSecObjCnt, &tdSecObjList);
		for (i=0;i<iSecObjCnt && iRetCode == 0;i++)
		{
			tc_strcpy(acSecObjType,"");
			iRetCode = WSOM_ask_object_type (tdSecObjList[i].secondary, acSecObjType);

			if ( (iRetCode == 0) && (tc_strcmp(acSecObjType,"AdobeAcrobat") == 0) )
			{
				iRetCode = AOM_ask_name (tdSecObjList[i].relation_type,&pcRelationTypeName);
				if ( (iRetCode == 0) && (tc_strcmp(pcRelationTypeName,"IMAN_Rendering") == 0) )
				{
					*lisValid = true;
					SAFE_MEM_free(pcRelationTypeName);
					break;
				}
				SAFE_MEM_free(pcRelationTypeName);
			}
			else if ( (iRetCode == 0) && (tc_strcmp(acSecObjType,"DirectModel") == 0) )
			{
				iRetCode = AOM_ask_name (tdSecObjList[i].relation_type,&pcRelationTypeName);
				if ( (iRetCode == 0) && (tc_strcmp(pcRelationTypeName,"IMAN_Rendering") == 0) )
				{
					*lisValid = true;
					SAFE_MEM_free(pcRelationTypeName);
					break;
				}
				SAFE_MEM_free(pcRelationTypeName);
			}
			else if ( (iRetCode == 0) && (tc_strcmp(acSecObjType,"DrawingSheet") == 0) )
			{
				iRetCode = WSOM_ask_name(tdSecObjList[i].secondary, acDatasetName);

				// Ask Dataset's Named References count...
				iRetCode = AE_ask_dataset_ref_count(tdSecObjList[i].secondary, &iDatasetRefCnt);
				for (j = 0; j < iDatasetRefCnt && iRetCode == 0; j++)
				{
					iRetCode = AE_find_dataset_named_ref(tdSecObjList[i].secondary, j,acDatasetRefName, &tdfDatasetRefType, &tDatasetRef);
					//RetCode = PROP_UIF_ask_property_by_name(tDatasetRef, "Name", &tRefName);
					iRetCode = PROP_UIF_ask_property_by_name(tDatasetRef, "file_ext", &tRefName);
					iRetCode = PROP_UIF_ask_value(tRefName, &pcRefName);

					//pcRet = tc_strstr(pcRefName, ".cgm");				
					//if (pcRet != NULL)
					if (tc_strcasecmp(pcRefName, "cgm") == 0)
					{
						*lisValid = true;
						break;
					}
				}
				SAFE_MEM_free(pcRefName);
				if(*lisValid == true)
					break;
			}
		}
		SAFE_MEM_free(pcParentItemRev);
	}
	return iRetCode;
}

int clone_Dataset(tag_t tDatasetTag, tag_t tBaseSecObj, tag_t tAttachmentObj, tag_t tRenderingRelType)
{
	int iRetCode = ITK_ok;
	char *pcDatasetName = NULL; 
	//Get the dataset name
	iRetCode = AOM_ask_value_string(tDatasetTag, "object_name", &pcDatasetName);
	if(iRetCode == ITK_ok)
	{													
		char *pcItemAndRevId = NULL;
		char *pcNewDatasetName = NULL;
		//Get the itemid/revid of the orig rev
		iRetCode = WSOM_ask_id_string(tBaseSecObj, &pcItemAndRevId);													
		//Check if the dataset name is same as the item revision
		if(iRetCode == ITK_ok && tc_strcmp(pcDatasetName, pcItemAndRevId) == 0)
		{
			//Get the itemid/revid of the baseline revision which will be the new dataset name
			iRetCode = WSOM_ask_id_string(tAttachmentObj, &pcNewDatasetName);														
		}
		else
		{
			//If name is not same then retain the current dataset name will be the new dataset name
			iRetCode = AOM_ask_value_string(tDatasetTag, "object_name", &pcNewDatasetName);
		}
		if(iRetCode == ITK_ok)
		{
			tag_t tNewDataset = NULLTAG;
			//Create new dataset
			iRetCode = AE_copy_dataset_with_id(tDatasetTag, pcNewDatasetName, NULL, NULL, &tNewDataset);
			if(iRetCode == ITK_ok && tNewDataset != NULLTAG)
			{
				tag_t tNewRelation = NULLTAG;
				//Create IMAN_rendering relation between the baselined item rev and the new dataset
				iRetCode = GRM_create_relation(tAttachmentObj, tNewDataset, tRenderingRelType, NULLTAG, &tNewRelation);
				if(iRetCode == ITK_ok && tNewRelation != NULLTAG)
				{
					//Save the relation
					iRetCode = GRM_save_relation(tNewRelation);
				}
			}
		}
		SAFE_MEM_free(pcItemAndRevId);	
		SAFE_MEM_free(pcNewDatasetName);	
	}
	SAFE_MEM_free(pcDatasetName);											
	return iRetCode;										
}

extern int TIAUTO_AH_create_baselinewatermark_translation_request(EPM_action_message_t msg)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				iNumAttachments								= 0;

	tag_t			tRootTask				= NULLTAG;
	tag_t			tItemRev				= NULLTAG;
	tag_t			tRequest				= NULLTAG;
	tag_t			*ptAttachments			= NULL;

	char *pcClassName = NULL;
	char *pcErrMsg = NULL;
	logical			lisValid				= false;
	
	
	if (iRetCode == ITK_ok )
	{
		//iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
		if (iRetCode == ITK_ok && tRootTask != NULLTAG)
		{
			iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments,&ptAttachments);
		}
		for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
		{
			iRetCode = tiauto_get_class_name_of_instance (ptAttachments[indx], &pcClassName);
			if ( (iRetCode == ITK_ok) && (tc_strcmp(pcClassName,"ItemRevision") == 0) )
			{	
				tItemRev = ptAttachments[indx];
				iRetCode = verify_DatasetType_NamedRef(tItemRev, &lisValid);
				if (iRetCode == 0 && lisValid == true)
				{
					tag_t tBaselineRelType = NULLTAG;
					iRetCode = DISPATCHER_create_request  ( "TIAUTO", "baselinewatermark",3,0 ,0 ,0, 1,&tItemRev ,NULL,0  ,NULL,"Baseline_Watermark",0,NULL,NULL,&tRequest);
					//Start ER 5010 - Copy the drawing sheet or PDF dataset to the baseline revision
					//Get the relation type tag for IMAN_Baseline
					iRetCode = GRM_find_relation_type("IMAN_baseline", &tBaselineRelType);
					if(iRetCode == ITK_ok && tBaselineRelType != NULLTAG)
					{
						int iBaseSecObjCnt = 0;
						tag_t *ptBaseSecObjs = NULL;
						//Get the secondary objects of the baselined revision with IMAN_Baseline relation 
						iRetCode = GRM_list_secondary_objects_only(ptAttachments[indx], tBaselineRelType, &iBaseSecObjCnt, &ptBaseSecObjs);					
						if(iRetCode == ITK_ok && iBaseSecObjCnt > 0 && ptBaseSecObjs != NULL)
						{
							tag_t tRenderingRelType = NULLTAG;
							//Get the relation type tag for IMAN_Rendering
							iRetCode = GRM_find_relation_type("IMAN_Rendering", &tRenderingRelType);
							if(iRetCode == ITK_ok && tRenderingRelType != NULLTAG)
							{
								int iRenSecObjCnt = 0;
								tag_t *ptRenSecObjs = NULL;
								//Get the secondary objects of the original revision with IMAN_Rendering relation 
								iRetCode = GRM_list_secondary_objects_only(ptBaseSecObjs[0], tRenderingRelType, &iRenSecObjCnt, &ptRenSecObjs);		
								if(iRetCode == ITK_ok && iRenSecObjCnt > 0 && ptRenSecObjs != NULL)
								{
									int inx = 0;
									int iCGMDatasetFound = 0;
									//Check if there exists a CGM dataset
									for(inx = 0; inx < iRenSecObjCnt; inx ++)
									{
										if(iRetCode == ITK_ok)
										{
											char *pcObjType = NULL; 
											tag_t tObjType = NULLTAG;
											//Get the object type of the secondary object
											iRetCode = TCTYPE_ask_object_type(ptRenSecObjs[inx], &tObjType);
											//Get the type name
											if(iRetCode == ITK_ok)
											{
												iRetCode = TCTYPE_ask_name2(tObjType, &pcObjType);
											}
											//Check if the object is DrawingSheet(CGM) dataset
											if(iRetCode == ITK_ok && tc_strcmp(pcObjType, "DrawingSheet") == 0)
											{
												iCGMDatasetFound = 1;												
											}
											SAFE_MEM_free(pcObjType);
											if(iCGMDatasetFound == 1)
											{
												break;
											}
										}
									}
									//Create a copy of dataset
									for(inx = 0; inx < iRenSecObjCnt; inx ++)
									{
										if(iRetCode == ITK_ok)
										{
											char *pcObjType = NULL; 
											tag_t tObjType = NULLTAG;
											//Get the object type of the secondary object
											iRetCode = TCTYPE_ask_object_type(ptRenSecObjs[inx], &tObjType);
											//Get the type name
											if(iRetCode == ITK_ok)
											{
												iRetCode = TCTYPE_ask_name2(tObjType, &pcObjType);
											}
											//Check if the object is DrawingSheet or AdobeAcrobat dataset
											if(iRetCode == ITK_ok && tc_strcmp(pcObjType, "DrawingSheet") == 0)
											{												
												iRetCode = clone_Dataset(ptRenSecObjs[inx], ptBaseSecObjs[0], ptAttachments[indx], tRenderingRelType);
											}	
											//Clone pdf datasets only if CGM dataset is not there
											if(iRetCode == ITK_ok && iCGMDatasetFound == 0 && tc_strcmp(pcObjType, "AdobeAcrobat") == 0)
											{
												iRetCode = clone_Dataset(ptRenSecObjs[inx], ptBaseSecObjs[0], ptAttachments[indx], tRenderingRelType);
											}
											//Check if the object is Directmodel dataset
											if(iRetCode == ITK_ok && tc_strcmp(pcObjType, "DirectModel") == 0)
											{												
												iRetCode = clone_Dataset(ptRenSecObjs[inx], ptBaseSecObjs[0], ptAttachments[indx], tRenderingRelType);
											}	
											SAFE_MEM_free(pcObjType);
										}
									}
								}
								SAFE_MEM_free(ptRenSecObjs);
							}
						}
						SAFE_MEM_free(ptBaseSecObjs);
					}
					//End - ER 5010	
					break;
				}
			}			
		}
		SAFE_MEM_free(ptAttachments);
		SAFE_MEM_free(pcClassName);
	}
	if (iRetCode != ITK_ok ) 
	{
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	
	return iRetCode;
}
