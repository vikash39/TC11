/*******************************************************************************
FILE        :   tiauto_rh_TIAUTO_RH_verify_parallel_path_tasks.c
Details     :   This is used to check whether all other content creation tasks are completed before
				performing "Content Creation - Account Manager" task.
 
REVISION HISTORY :

Date              Revision        Who						Description
04/08/2016						Kantesh						Initial Creation

*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

#define DELIMITER ";"

/*=================================================================================
*    Implementation of Rule Handler -  TIAUTO_RH_check_content_creation_tasks_result
===================================================================================*/
EPM_decision_t TIAUTO_RH_verify_parallel_path_tasks(EPM_rule_message_t msg )
{
	//variable 
	int				iRetcode				= ITK_ok;
	int				iLoopVal				= 0;
	int				iNoCurrentTask			= 0;

	tag_t			tRootTaskTag			= NULLTAG;
	tag_t			tEngChangeRev			= NULLTAG;
	tag_t			*ptCurrentTasks			= NULL;

	char			*pcTaskName			= NULL;
	char            szErrorString[TIAUTO_error_message_len+1] = "";

	EPM_state_t State ;
	EPM_decision_t decision = EPM_go;

	if(iRetcode == ITK_ok)
	{
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		iRetcode =  tiauto_get_change_item_rev( msg.task, &tEngChangeRev);
		if(iRetcode == ITK_ok)
		{
			iRetcode = AOM_ask_value_tags (tEngChangeRev,"process_stage_list",&iNoCurrentTask,&ptCurrentTasks);
			for( iLoopVal = 0; iLoopVal < iNoCurrentTask && iRetcode == ITK_ok; iLoopVal++ )
			{
				if( ptCurrentTasks[iLoopVal] == tRootTaskTag ||  ptCurrentTasks[iLoopVal] == msg.task)
				{
					continue;
				}
				else
				{
					iRetcode = EPM_ask_state(ptCurrentTasks[iLoopVal],&State);
					if(iRetcode == ITK_ok && State == EPM_started)
					{
						decision = EPM_nogo;
						//error
						iRetcode = EPM_ask_name2(ptCurrentTasks[iLoopVal],&pcTaskName);
						TI_sprintf(szErrorString, "%s\n",pcTaskName);
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_ALLOWED_TO_COMPLETE_TASK, szErrorString) ;
						
					}
				}
			}
		}
	}

	if(decision == EPM_nogo)
	{
		TI_sprintf(szErrorString, "\nYou are not allowed to complete this task until the following content creation tasks are completed.\n");
		TC_write_syslog(szErrorString);
		EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_ALLOWED_TO_COMPLETE_TASK, szErrorString) ;
						
	}

	SAFE_MEM_free(ptCurrentTasks);
	
	return decision;

}



