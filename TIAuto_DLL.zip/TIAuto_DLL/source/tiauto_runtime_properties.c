/*******************************************************************************
*
* FILENAME : tiauto_runtime_properties.c
*
* DESCRIPTION :
*      
*
* FUNCTIONS :
*       int t1aAUTO_register_runtime_properties( int *decision, va_list args  );
*
*
* CHANGES :
*      REF NO		DATE            WHO             DETAIL
*         001     04/27/2009		Rajesh N		Initial Creation
*		  002	  12/31/2010		Dipak Naik	    Added TIAUTO_BOMLine_property_method
*         003     11/06/2019		Jugunu Vasu     Build 15.02  TIAUTO_Get2D_PDF for Item Revision,AlteRep ,AltTool &CADConstruct
********************************************************************************/

/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
#include <tiauto_defines.h>

/*******************************************************************************
* PUBLIC FUNCTION DEFINITIONS
*******************************************************************************/

/*******************************************************************************
* NAME :            int t1aAUTO_register_runtime_properties( int *decision, va_list args  )
*
* DESCRIPTION :     Register all of TI AUTO server exits here
*********************************************************************************/

#include <tiauto_runtime_properties.h>

int t1aAUTO_register_runtime_properties( int *decision, va_list args )
{

    int iSts = ITK_ok; 
    USER_prop_init_entry_t user_types_methods[] =
    {
		{ "EngChange Revision",TIAUTO_display_task_properties, NULL },
		{ "T8_TI_ChangeRevision",TIAUTO_display_task_properties, NULL },
		{ "BOMLine",TIAUTO_BOMLine_property_method, NULL },
		{"TI_Product Revision",TIAUTO_Get2D_PDF,NULL},
		{"TI_Tooling Revision",TIAUTO_Get2D_PDF,NULL},
		{"TI_AltRep Revision",TIAUTO_Get2D_PDF,NULL},
		{"TI_AltTool Revision",TIAUTO_Get2D_PDF,NULL},
		{"TI_CADConstruct Revision",TIAUTO_Get2D_PDF,NULL},
		{ ""          , 0                               , NULL }
    };
    int n_types = 0;
	n_types = sizeof(user_types_methods)/sizeof(USER_prop_init_entry_t);
    *decision  = ALL_CUSTOMIZATIONS;
    iSts = TCTYPE_register_properties(user_types_methods, n_types);
    return iSts;
}


