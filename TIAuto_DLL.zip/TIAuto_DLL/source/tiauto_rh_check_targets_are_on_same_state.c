
/*******************************************************************************
FILE        :   tiauto_rh_check_targets_are_on_same_state.c

Description  : To check target items are on same state inside Solution and Drwaing Items Folders.
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 09, 2016    1.0        Kantesh		   Initial Creation
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_targets_are_on_same_state(EPM_rule_message_t msg )
{
	int		iRetCode									=	ITK_ok;
	int		iCount										=	0;
	int		iLoop										=	0;

	tag_t	tECRev										=	NULLTAG;
	tag_t	*ptSecObjects								=	NULLTAG;
	tag_t	tRelationType								=	NULLTAG;

	char    szReleaseStatus[WSO_name_size_c+1]			=	"";
	char    acReleaseStatus[WSO_name_size_c+1]			=	"";
	char    szErrorString[TIAUTO_error_message_len+1]	=	"";

	logical	isDOC										=	false;
	boolean bTargetSameState							=	true;

	EPM_decision_t decision								=	EPM_go;

	iRetCode = tiauto_get_change_item_rev(msg.task, &tECRev);

	//Check for Solution Items Folder
	if(iRetCode == ITK_ok && tECRev)
	{
		iRetCode = GRM_find_relation_type ("CMHasSolutionItem", &tRelationType);

		if(tRelationType != NULLTAG)
		{
			iRetCode = GRM_list_secondary_objects_only(tECRev, tRelationType, &iCount, &ptSecObjects);
			for(iLoop = 0; iLoop < iCount; iLoop++)
			{
				iRetCode =  tiauto_check_if_itemType_isDOC(ptSecObjects[iLoop],&isDOC);
				if(isDOC == false)
				{					
					tc_strcpy(szReleaseStatus,"");
					iRetCode = tiauto_get_release_status(ptSecObjects[iLoop],szReleaseStatus);

					if(tc_strlen(acReleaseStatus) == 0)
					{
						tc_strcpy(acReleaseStatus,szReleaseStatus);
					}

					if(tc_strcmp(acReleaseStatus,szReleaseStatus) != 0)
					{
						bTargetSameState = false;
						break;
					}
					
				}
			}
		}
	}

	if(bTargetSameState == false)
	{
		iRetCode = TIAUTO_NOT_VALID_SAME_STATE;
		decision = EPM_nogo;
		TI_sprintf(szErrorString, "ItemRevisions available in the Soution Items Folder are not of the same state.\n");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_SAME_STATE, szErrorString) ;						
		TC_write_syslog(szErrorString);
	}

	//Check for Drawing Items Folder
	if(iRetCode == ITK_ok && tECRev)
	{
		iRetCode = GRM_find_relation_type ("T8_CMTIDrawingItems", &tRelationType);

		if(tRelationType != NULLTAG)
		{
			iRetCode = GRM_list_secondary_objects_only(tECRev, tRelationType, &iCount, &ptSecObjects);
			for(iLoop = 0; iLoop < iCount; iLoop++)
			{
				iRetCode =  tiauto_check_if_itemType_isDOC(ptSecObjects[iLoop],&isDOC);
				if(isDOC == false)
				{					
					tc_strcpy(szReleaseStatus,"");
					iRetCode = tiauto_get_release_status(ptSecObjects[iLoop],szReleaseStatus);

					if(tc_strlen(acReleaseStatus) == 0)
					{
						tc_strcpy(acReleaseStatus,szReleaseStatus);
					}

					if(tc_strcmp(acReleaseStatus,szReleaseStatus) != 0)
					{
						bTargetSameState = false;
						break;
					}
					
				}
			}
		}
	}

	if(bTargetSameState == false)
	{
		iRetCode = TIAUTO_NOT_VALID_SAME_STATE;
		decision = EPM_nogo;
		TI_sprintf(szErrorString, "ItemRevisions available in the Drawing Items Folder are not of the same state.\n");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_SAME_STATE, szErrorString) ;						
		TC_write_syslog(szErrorString);
	}
		
	return decision;
}
