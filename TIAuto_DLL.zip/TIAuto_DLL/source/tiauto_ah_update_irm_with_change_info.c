/************************************************************************************************************
File         : tiauto_ah_update_irm_with_change_info.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
May 12, 2014    1.0        Manik			 Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TIAUTO_AH_update_irm_with_change_info(EPM_action_message_t msg)
{
	int		iRetCode						= ITK_ok;
	int		iCount							= 0;
	int		indx							= 0;
	int		iNumArgs						= 0;
	char	*pcChangeRevStr					= NULL;
	char	*pcTargetTypeName				= NULL;
	char*	pcArgName						= NULL;
	char	*pcArgValue						= NULL;
	tag_t	tChangeRev						= NULLTAG;	
	tag_t	tRelation						= NULLTAG;
	tag_t	*ptChangeFolderSecObjs			= NULL;
	char	caObjectType[WSO_name_size_c+1]	= "";
	logical lIsModifiable = false;
	
	/* get the arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);

	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,"EngChange Revision");

	/* validate the handler arguments */
    if ( iNumArgs == 1)
	{
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if ( iRetCode == ITK_ok ) 
			{
				if( iRetCode == ITK_ok && tc_strcmp(pcArgName, "target_type" ) == 0)
				{
					tc_strcpy( pcTargetTypeName, pcArgValue);
				}
				/* if the argument mentioned is not "lov" */
				else
					iRetCode = EPM_invalid_argument;
			}
		}
	}

	iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		//get the change rev string
		iRetCode = tiauto_get_itemrev_name(tChangeRev,&pcChangeRevStr);
		//get the contents od the change forms folder under change revision
		if(iRetCode == ITK_ok && tc_strcmp(pcTargetTypeName,"EngChange Revision")	== 0)	
			iRetCode = AOM_ask_value_tags(tChangeRev, "t1achanged_forms", &iCount,&ptChangeFolderSecObjs);
		else if(iRetCode == ITK_ok && tc_strcmp(pcTargetTypeName,"T8_TI_ChangeRevision")	== 0)	
		{
			iRetCode = GRM_find_relation_type("T8_CMTIChangedForms",&tRelation);
			if(tRelation != NULLTAG)
				iRetCode = GRM_list_secondary_objects_only(tChangeRev, tRelation, &iCount,&ptChangeFolderSecObjs);
		}
		for (indx = 0; indx < iCount && (iRetCode == ITK_ok); indx++)
        {
			if (iRetCode == ITK_ok)
			{
				iRetCode = WSOM_ask_object_type(ptChangeFolderSecObjs[indx], caObjectType);
				if (iRetCode == ITK_ok && tc_strcmp (caObjectType, "TI_Product Revision Master") == 0 )
	            {
					iRetCode = AOM_ask_if_modifiable (ptChangeFolderSecObjs[indx],&lIsModifiable);
					if (iRetCode == ITK_ok && lIsModifiable == true)
					{
						iRetCode = AOM_refresh(ptChangeFolderSecObjs[indx], true);
						iRetCode = AOM_set_value_string (ptChangeFolderSecObjs[indx],"t8_1irmupdatedbychange",pcChangeRevStr);
						if(iRetCode == ITK_ok)
							iRetCode = AOM_save(ptChangeFolderSecObjs[indx]);
						if(iRetCode == ITK_ok)
							iRetCode = AOM_refresh(ptChangeFolderSecObjs[indx],false);
					}
					lIsModifiable = false;
				}
			}
		}
		SAFE_MEM_free(ptChangeFolderSecObjs);
		SAFE_MEM_free(pcChangeRevStr);
		return iRetCode;
	}
		
}