/*******************************************************************************
FILE        :   tiauto_ah_verify_status_progression.c

DESCRIPTION :   This file contains the implementation for
                "TIAUTO-AH-check-verify-status-progression" Custom Action Handler.
                This handler validates release status of the of the all item revisions
                for correct status progression. There are three different types of
                status progression checks are added in this handler. If any one check
                is failed, task will be demoted to application engieer for modifications.

                Status Progression Checks:
                � Backwards Progression -  Validates the status progression of current
                  revision of item w.r.t later revisions of the same item. Earlier
                  revision of an item will not be released to a status when a newer/later
                  version has been released to this status or higher.

                � Assembly Item Rev Progression - A check should be performed on all
                  item revisions contained in the affected and solution folder to ensure
                  that all first level components in it�s precise BOM meet one of the
                  following requirements:
                    1)	The component is included in the affected folder.
                    2)	The component is included in the solution folder.
                    3)	The component is at the target status.
                    4)	The component is at a status higher than the target status.

                � Component Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  meet one of the following requirements:
                    1)	The item revision is not yet released.
                    2)	The item revision is at a lower status than the target status.
                    3)	The item revision is already at the target status.
					

                � Generic Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  that have ProAsm or ProPrt dataset and are instance items, the generic item rev
				  should meet one of the following requirements:
                    1)	The generic is included in the affected folder.
                    2)	The generic is included in the solution folder.
                    3)	The generic is at the target status.
					4)  The generic is at a status higher than the target release status.


AUTHOR      :   Srikanth Pulluri, TCS

REVISION HISTORY :

Date              Revision        Who                    Description
April 20, 2007    1.0           Srikanth Pulluri     Initial Creation
July  26, 2007    1.1           Srikanth Pulluri     Modified code for child/assembly
                                                     item same rev progression
Jan   12, 2009	  1.2		    Garima Dewangan		 Modified code for Generic Item
													 progression check and get all 
													 failure items in one error message
Feb 15, 2009	 1.3			Dipak Naik			 Modified code for allowing item revisions
													 having "Cad release Only" staus.
March 10,2009	 1.4			Dipak Naik			 Modified the code to show both the generic
													 item revision and the Alternet id(if used)
Mar   17, 2009	 1.5		    Garima Dewangan		 Modified code for memory handling for Generic Item
													 progression check and allowing only OEM item revisions
													 to have "Cad release Only" staus as a valid status in 
													 assembly progression check.
Mar 12, 2009	 1.6			Garima Dewangan		 Modified code for allowing failure item revisions
     												 in parallel on-going CR's to be considered in current Process.
Apr 22, 2009     1.7            Dipak Naik			 Added the code for sending the mail.
june 23, 2009     1.7           Dipak Naik			 Moved all the progression ckeck functions to 
													 "tiauto_workflow_utils.c" file.
Jul 30 2009		 1.8			Rajesh N			 modified the code to send notification with input as task name
Aug 18 2009		 1.9			Dipak Naik			 Modified the code to route to the "Stacked Wait Tak" only when 
													 there is warning message.
Feb 22 2010      1.10			Dipak Naik			 Modified the task name as per the enhanced CRB workflow.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <tiauto_workflow_utils.h>

int executeProgressionCheckActionHandler(tag_t tmsgTask, tag_t tECRev,char *pcReportDecision,
										 char *pcFailDecision,char *pcEndOfWarningMsg, 
										 char *szTaskNameToSendMailToOwner, logical *lTaskResult);										
/*==================================================================
*    Implementation of ACTION Handler -  t1aAUTO_ah_verify_status_progression
====================================================================*/
extern int TIAUTO_AH_verify_status_progression (EPM_action_message_t msg )
{
    int             iRetCode		= ITK_ok;
    int             iNumArgs		= 0; 

    int				i = 0;
	//logical			lIsEmail = false;					// lIsEmail = true,  to send mail
	//													//			= false, not to send mail
	char			*szTaskNameToSendMailToOwner = NULL;
	char			*pcReportDecision			 = NULL;
	char			*pcFailDecision				 = NULL;
	char			*pcEndOfWarningMsg			 = NULL;
	char		    *pcValue  = NULL;
    char		    *pcFlag   = NULL;
	char			*pcErrMsg = NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";
	tag_t			tChangeRev = NULLTAG;
	logical			lTaskResult = true;

    iNumArgs = TC_number_of_arguments(msg.arguments);
    if( DEBUG_PRINT ) printf("\n TIAUTO_AH_verify_status_progression - Arguments : %d\n", iNumArgs);
    if (iNumArgs == 3 || iNumArgs == 4)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 && pcValue != NULL)
				{
					if( (tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
					{
						pcReportDecision = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcReportDecision, pcValue);
					}	
					else
						iRetCode = EPM_invalid_argument;
				}
				else if( tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 && pcValue != NULL)
				{
					if( (tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
					{
						pcFailDecision = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcFailDecision, pcValue);
					}	
					else
						iRetCode = EPM_invalid_argument;
				}				
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 && pcValue != NULL)
				{
					//The value of the argument "notification" will have the task name,
					//we need to send an email to the owner of that task 
					szTaskNameToSendMailToOwner = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( szTaskNameToSendMailToOwner, pcValue);
					//if( tc_strcasecmp(pcValue, "Yes") == 0 )
					//	lIsEmail = true;
					//else if( tc_strcasecmp(pcValue, "No") == 0 )
					///	lIsEmail = false;
					//else
					//	iRetCode = EPM_invalid_argument;
				}
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 && pcValue != NULL)
				{
					pcEndOfWarningMsg = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcEndOfWarningMsg, pcValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-validate-status-progression\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					
				}
			}
        	else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-validate-status-progression\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				
			}
		}
	}	
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }	
	//to check whether mandatory attributes are parsed or not
    if( (iRetCode == ITK_ok) && ((pcReportDecision == NULL) || (pcFailDecision == NULL)
								  || (pcEndOfWarningMsg == NULL) ) )
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	if( iRetCode == ITK_ok )
    {
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//Call the static function to execute the handler to do the Progression Check
			iRetCode = executeProgressionCheckActionHandler(msg.task,tChangeRev,pcReportDecision,pcFailDecision,
				                                            pcEndOfWarningMsg,szTaskNameToSendMailToOwner, &lTaskResult);
		}
	}
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	if ( lTaskResult == true && iRetCode == ITK_ok)	
	{
		// When status is valid, set to true to continue the process.
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_TRUE);
	}
	if(lTaskResult == false || iRetCode != ITK_ok)
	{
		// When status is invalid, set to false - for demoting the task to application engineer.					
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
	}
		
	SAFE_MEM_free (pcValue);
	SAFE_MEM_free (pcFlag);	
    return iRetCode;
}
																			
int executeProgressionCheckActionHandler(tag_t tmsgTask, tag_t tECRev,char *pcReportDecision,
										 char *pcFailDecision,char *pcEndOfWarningMsg, 
										 char *szTaskNameToSendMailToOwner, logical *lTaskResult)
{
	int			iRetCode									= ITK_ok;
    int			iNumAffected								= 0;	
    int			indx										= 0;	
	int			iError										= 0;	 
	int			iPopulateErrMsgInStack						= 1;			// for this handler, we need the error message.	
	int			iPopulateWarningMsgInStack					= 1;
    int         iFileOpenErrCode                            = 0;                                          // for this handler, we need the warning message.
    char		szErrorString[TIAUTO_error_message_len+1]	= "";
	char		caChnId[ITEM_id_size_c+1]					= {'\0'};
	char		caChnRevId[ITEM_id_size_c+1]				= {'\0'};
	char		caChnName[ITEM_name_size_c+1]				= {'\0'};
	char		caCurrentTaskName[WSO_name_size_c+1]		= {'\0'};
	tag_t		*ptAffectedItems							= NULL;
	tag_t		tUser										= NULLTAG;
	tag_t		tRootTask									= NULLTAG;

	txt_t		the_text_server								= NULL;
	char		*pcClassName								= NULL; 
    char		*pcComments									= NULL;
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	logical     lIsErrorPresent								= false;
	logical		lIsWarningPresent							= false;
	logical     lIsWriteToAuditFile							= false;
	FILE		*fMailBodyFile								= NULL;

    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

	TIA_ErrorMessage *backwordProgErrMsgStack		= NULL;
	TIA_ErrorMessage *itemRevProgErrMsgStack		= NULL;
	TIA_ErrorMessage *assemblyProgWarningMsgStack	= NULL;
	TIA_ErrorMessage *assemblyProgErrMsgStack		= NULL;
	TIA_ErrorMessage *genericProgWarningMsgStack	= NULL;
	TIA_ErrorMessage *genericProgErrMsgStack		= NULL;

	tiauto_initialize_status_progression_stuct(&StatusProgression); 
	iRetCode = tiauto_get_status_progression_array (&StatusProgression);
    if (iRetCode == ITK_ok)
    {
		iRetCode = tiauto_get_target_release_status(tECRev, TargetReleaseStatus.szTargetReleaseStatus);
		if(iRetCode == ITK_ok)
		{
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			if (TargetReleaseStatus.iLevel == -1)
			{
				TI_sprintf(szErrorString,"%s", TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT);
				iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
				EMH_store_error_s1( EMH_severity_error, iRetCode, 
					                TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT) ;
				TC_write_syslog(szErrorString);
			}
		}
		else
		{
			TI_sprintf(szErrorString, "Failed to verify Target Release Status with the site Preference \"TI_Progression_Path\". \n");
			EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;	
			TC_write_syslog(szErrorString);
		}
	}
	if (iRetCode == ITK_ok)
	{
		iRetCode = ECM_get_affected_items(tECRev, &iNumAffected, &ptAffectedItems);
	}
	
	for (indx = 0; (indx < iNumAffected) && (iRetCode == ITK_ok); indx++)
	{	
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pcClassName);
		if( (iRetCode == ITK_ok) && (tc_strcasecmp (pcClassName , "ItemRevision")== 0 ) )
        {
			//Backward progression check 	 
			iRetCode = check_for_backward_progression ( ptAffectedItems[indx],ptAffectedItems,iNumAffected, StatusProgression, 
											TargetReleaseStatus, iPopulateErrMsgInStack, &iError, &backwordProgErrMsgStack );
		
			if ( iRetCode == ITK_ok )
			{
				iRetCode = check_for_item_rev_progression ( ptAffectedItems[indx], StatusProgression, 
											TargetReleaseStatus, iPopulateErrMsgInStack, &iError, &itemRevProgErrMsgStack );
							
			}
			if ( iRetCode == ITK_ok)
			{
				iRetCode = check_for_assembly_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														iPopulateWarningMsgInStack, iPopulateErrMsgInStack, &iError, 
														&assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
							
			}
			if ( iRetCode == ITK_ok )
			{
				iRetCode = check_for_generic_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														iPopulateWarningMsgInStack, iPopulateErrMsgInStack, &iError, 
														&genericProgWarningMsgStack, &genericProgErrMsgStack);
			
			}
			
		}
	}	
    
	if(iRetCode == ITK_ok )
	{
		if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
			(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL))
		{
			lIsErrorPresent = true;
		}
		if((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
		{
			lIsWarningPresent = true;
		}
	}
	//for sending mail
	if(iRetCode == ITK_ok && lIsErrorPresent == false)
	{	
		
		if((szTaskNameToSendMailToOwner != NULL) && ((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL)))
			{
				TIA_ErrorMessage *tempErrMsg = NULL;
				iRetCode = EPM_ask_root_task(tmsgTask , &tRootTask);
				if(iRetCode == ITK_ok && tRootTask != NULLTAG)
					iRetCode = tiauto_getUser(tRootTask,szTaskNameToSendMailToOwner,&tUser);
				if(iRetCode == ITK_ok && tUser != NULLTAG)
				{
					iRetCode = EPM_get_user_email_addr  (  tUser,&pcEmailId )  ;
				}				
				//if(iRetCode == ITK_ok &&  tUser != NULLTAG)
				//{
					/* Initialize TextServer here */
					//the_text_server = txt_ctor( "iman_text.xml" );
					//pcMsgName = "User_Comments";
					//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
					/* release text server object here...*/
					//txt_destructor(the_text_server);
				//}
				if(iRetCode == ITK_ok &&  tUser != NULLTAG)
				{
					pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
					iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
				}
				if(iRetCode == ITK_ok &&  tUser != NULLTAG)
				{
					iRetCode = tiauto_getItemRevDetails(tECRev, caChnId, caChnRevId, caChnName);
					if(iRetCode == ITK_ok)
						iRetCode = EPM_ask_name(tmsgTask, caCurrentTaskName);
					if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"10_80") != NULL))
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS);
					}
					if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"13_8") != NULL))
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS1);
					}
					else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"2_153") != NULL) )
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CR,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CR);
					}
					else if( (iRetCode == ITK_ok) && ( (tc_strstr(caCurrentTaskName,"10_193") != NULL) ||
						    (tc_strstr(caCurrentTaskName,"13_150") != NULL)) )
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
					}
					else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"2_481") != NULL))
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
					}
					if(iRetCode == ITK_ok)
					{
						fprintf(fMailBodyFile,"\n\nWARNING MESSAGES:\n");
						tempErrMsg = assemblyProgWarningMsgStack;
						while(tempErrMsg != NULL)
						{
							fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						tempErrMsg = genericProgWarningMsgStack;
						while(tempErrMsg != NULL)
						{
							fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
					}            
				}
				if(fMailBodyFile != NULL &&  tUser != NULLTAG)
				{
					fclose(fMailBodyFile);
				}		
				TI_sprintf(szErrorString, "WARNING : %s/%s-%s(%s)",caChnId, caChnRevId, caChnName, 
					                                  szTaskNameToSendMailToOwner);
				if(pcEmailId != NULL)
					iRetCode = tiauto_sendEMail(szErrorString, pcEmailId, pcMailBodyFileName);
			}
		
	}
	
	
	if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
		 (assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL)||
		 (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
	{
		
		if(	tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{
			tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
			assemblyProgWarningMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
			genericProgWarningMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
			backwordProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
			itemRevProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
			assemblyProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgErrMsgStack);
			genericProgErrMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if( lIsWarningPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if( lIsErrorPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if( ( lIsWarningPresent == true) && (lIsErrorPresent == true) )
			{
				lIsWriteToAuditFile = true;
			}
			else
			{
				lIsWriteToAuditFile = false;
			}
		}
		// Writing failure reason in the workflow Audit File
		if(lIsWriteToAuditFile == true)
		{
			writeErrorsMsgToAuditFile(tmsgTask,backwordProgErrMsgStack,itemRevProgErrMsgStack,
									assemblyProgErrMsgStack,genericProgErrMsgStack,
									assemblyProgWarningMsgStack,genericProgWarningMsgStack);
		}
	}
   
	//to take the task decision: TRUE/FALSE
	if(iRetCode == ITK_ok )
	{
		if(	tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{			
			if(lIsErrorPresent == true)
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			if(lIsWarningPresent == true)
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if(lIsErrorPresent == true && lIsWarningPresent == false  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if(lIsErrorPresent == false && lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			if(lIsErrorPresent == true || lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if(lIsErrorPresent == true && lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}		
	}
	
	//free up allocated memory
    SAFE_MEM_free (StatusProgression.StatusArray);
	SAFE_MEM_free(ptAffectedItems);
	SAFE_MEM_free(pcClassName);
	//SAFE_MEM_free(pcMsgName);
	SAFE_MEM_free(pcComments);
	SAFE_MEM_free(pcEmailId);
	tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
	backwordProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
	itemRevProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
	assemblyProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgErrMsgStack);
	genericProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
	assemblyProgWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
	genericProgWarningMsgStack = NULL;
	remove(pcMailBodyFileName);
	
	return iRetCode;
}
