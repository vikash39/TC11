/*******************************************************************************
File         : tiauto_ah_send_mandatory_screening_notification.c

Description  : This handler is for sending the mandatory screening notification.
Sample Mail  :

Input        : None

Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jul 01, 2016    1.0        Dipak Naik		Initial Creation
Oct 03, 2018    1.1        Ramesh Kumar     "attachments" property is deprecated in TC 11.2, used new "signoff_attachments" property
Nov 23,2018		 1.5		Jugunu          Updated for ER 9759 CAP3
/*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200

extern void tiauto_Store_TaskNames_per_User(TIA_TaskNamesAssignedPerUser **currErrMsg, tag_t tUser, char* sError);
extern int Send_Mail(tag_t tUser,char *pcAllTasks,char *pcChangeId,char *pcRevId,char *pcSubject,char *pcSiteName);

void FreeMemoryForLinkdList(TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList);


extern int t1aAUTO_AH_send_mandatory_screening_notification(EPM_action_message_t msg)
{
	int				iRetCode								= ITK_ok;
	int				iCount									= 0;
	int             iSite               					= 0;
	int             iSiteID             					= 0;
	int             iFileOpenErrCode    					= 0;
	int				iReleaseStatus							= 0;
	int				iSolItemRevs							= 0;
	tag_t			tRootTaskTag							= NULLTAG;
	tag_t			tInitiatorTag							= NULLTAG;
	tag_t			tJobTag									= NULLTAG;
	tag_t			tEngChangeRev							= NULLTAG;
	tag_t			*ptTasks								= NULL;//to be freed
	tag_t           tpropTag            					= NULLTAG;
	tag_t           tSitetag            					= NULLTAG;
	tag_t			*ptSolItemRevs							= NULL;
	char			*pcUserMailId							= NULL;//to be freed
	char			*pcTaskName								= NULL;//to be freed
	char			*pcTaskTypeName							= NULL;//to be freed
	char			acSubject[1024]							= {'\0'};
	char			acChnId[ITEM_id_size_c+1]				= {'\0'};
	char			acChnRevId[ITEM_id_size_c+1]			= {'\0'};
	char			acChnName[ITEM_name_size_c+1]			= {'\0'};
	char			caTaskName[WSO_name_size_c+1]			= {'\0'};
	char            acSiteName[SA_site_size_c+1]			= {'\0'};
	char			acObjectType[WSO_name_size_c+1]			= "";	
	char			*pcMailSubject							= NULL;
	char			*pcBodyMsg								= NULL;
	char			*pcErrMsg								= NULL;
    char			*pcComments								= NULL;	
	char			*pcEmailId								= NULL;
	char			*pcMailBodyFileName						= NULL;
	char			*pcSiteName                             = NULL;
	tag_t			*ptReleaseStatusList					= NULL;
	char			*pcMRAURL								= NULL;
	char			*pcMRAId								= NULL;
	FILE			*fMailBodyFile							= NULL;
	logical			isMRAFound								= false;
	logical			isMRADocDetails							= false;
	char			*pcCommentValue							= NULL;
	int				iSecondaryObjNo							= 0;
	tag_t			*tSecObj								= NULL;
	int				i										= 0;
	char*			pcObjectType							= NULL;	
	char*			pcChangeAdmin							= NULL;

	char*			pcAffPrograms							= NULL;
	char*			pcAffPlants								= NULL;
	char*			pcBillableCmpany						= NULL;
	int				inx					= 0;
	int				iNumAttachs			= 0;
	int				iAttchIndx			= 0;

	
	tag_t			tTaskType								= NULLTAG;
	tag_t			tRelation								= NULLTAG;
	tag_t*			ptAttachsTagList							= NULL;
	tag_t			tGroupMember							= NULLTAG;
	tag_t			tReposibleParty							= NULLTAG;
	tag_t			tTemplate			= NULLTAG;
	char			*pcPropValue					= NULL;//to be freed
	char			*pcCurrency		= NULL;
	char			*pcChangeDescription	= NULL;
	tag_t tRelTemp = NULLTAG;
	char *pcsellingPrice = NULL;
	char *pcCustomerTooling = NULL;
	char *pcTICapitalInvestment = NULL;
	char *pcNetDevStartupCost = NULL;
	

	TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList = NULL;//to store all the task names per user
	
	//TIA_TaskNamesAssignedPerUser *NotifyUserList = NULL;

	//Get the root task
	iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
	if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
	{	
		iRetCode = AOM_ask_name(msg.task,&pcTaskName);
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
		if(iRetCode == ITK_ok && tTaskType != NULLTAG)
		{	//get the task type name
			iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
			if(iRetCode == ITK_ok &&  (tc_strcmp(pcTaskTypeName, "EPMSelectSignoffTask") == 0) )
			{	//get sub tasks
				iRetCode = AOM_ask_value_tag  ( msg.task, "task_template" , &tTemplate);
				if(iRetCode == ITK_ok && tTemplate != NULLTAG)
				{
					//get the task "icon_key" of the review task
					//to know whether the task is a notify task or review task
					iRetCode = AOM_UIF_ask_value ( tTemplate, "icon_key" , &pcPropValue);
				}
				// get the signoff object
				if( iRetCode == ITK_ok && msg.task != NULLTAG)
					iRetCode = AOM_ask_value_tags(msg.task, "signoff_attachments", &iNumAttachs, &ptAttachsTagList);

				if(iNumAttachs == 0)
				{
					return 0;
				}
				// get the user tag from the signoff object
				for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetCode == ITK_ok; iAttchIndx++)
				{
					if( iRetCode == ITK_ok && ptAttachsTagList != NULL)
					{
						iRetCode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
						if( iRetCode == ITK_ok && tGroupMember != NULLTAG)
						{
							tReposibleParty = NULLTAG;
							iRetCode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
						}
						if( iRetCode == ITK_ok && tReposibleParty != NULLTAG )
						{
							if(iRetCode == ITK_ok && (tc_strcmp(pcPropValue ,"notifyTask") != 0) )
							{
								//Get all the user tags and TaskNames in structure sMail WorkFlowStruc
								tiauto_Store_TaskNames_per_User(&TaskNamesPerUserList,tReposibleParty,pcTaskName);
							}	
						}												
					}
				}			
			}
			SAFE_MEM_free(pcTaskTypeName);
		}
		
		iRetCode = EPM_ask_sub_tasks(tRootTaskTag,&iCount,&ptTasks);
		if(iNumAttachs > 0 && iRetCode == ITK_ok && iCount > 0)
		{
			for(inx= 0;inx<iCount;inx++)
			{
				iRetCode = AOM_ask_name(ptTasks[inx],&pcTaskName);
									
				//if the task name contains "Incorrect Change Type", then that task will not be considered
				if(iRetCode == ITK_ok && (tc_strcmp(pcTaskName,"19_120 Proceed with Change?") == 0))
				{
					//get the responsible party of the task
					iRetCode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
					if(tReposibleParty != NULLTAG)
						iRetCode = SA_ask_user_person_name2(tReposibleParty,&pcChangeAdmin);

					break;
				}
			}
		}
	}
	//Get the user who has initiated the task
	if(iRetCode == ITK_ok)
	{
		iRetCode = AOM_ask_owner(tRootTaskTag,&tInitiatorTag);
	}
	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_get_user_email_addr(tInitiatorTag,&pcUserMailId);
	}

	//Get the job tag
	if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
	{
		iRetCode = EPM_ask_job(tRootTaskTag,&tJobTag);
	}
	//Get the change revision details
	if(iRetCode == ITK_ok && tRootTaskTag!= NULLTAG)
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
	}
	if(iRetCode == ITK_ok && tEngChangeRev!= NULLTAG)
	{
		iRetCode = tiauto_getItemRevDetails(tEngChangeRev, acChnId, acChnRevId, acChnName);
		iRetCode = AOM_ask_value_tags( tEngChangeRev, "release_status_list", &iReleaseStatus, &ptReleaseStatusList);
	}

	iRetCode = GRM_find_relation_type("IMAN_specification",&tRelation);

	iRetCode = GRM_list_secondary_objects_only (tEngChangeRev,tRelation,&iSecondaryObjNo,&tSecObj);

	if(iRetCode == ITK_ok && iNumAttachs > 0)
	{
		for(i = 0; i < iSecondaryObjNo; i++)
		{
			iRetCode = AOM_ask_value_string(tSecObj[i],"object_type",&pcObjectType);
			if((tc_strcmp(pcObjectType, "T8_TI_CAP2") == 0 || tc_strcmp(pcObjectType, "T8_TI_CAP3") == 0))
			{
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedprograms",&pcAffPrograms);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedplants",&pcAffPlants);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190changedescription",&pcChangeDescription);
			}
			if(tc_strcmp(pcObjectType , "T8_TI_CCR2") == 0)
			{
				//iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_191customername",&pcCustomer);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191currency",&pcCurrency);
				//iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191totalcashinvestmen",&pcTotalCashInv);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191billablecompany",&pcBillableCmpany);

				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191sellingprice",&pcsellingPrice);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191procustomertooling",&pcCustomerTooling);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191capextiautoowned",&pcTICapitalInvestment);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a191netdevstartupcost",&pcNetDevStartupCost);
			}
			
			if(tc_strcmp(pcObjectType , "T8_TI_PMR") == 0)
			{
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193affectedprogram",&pcAffPrograms);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193tiplant",&pcAffPlants);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193changedescription",&pcChangeDescription);
				//iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193customername",&pcCustomer);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193currency",&pcCurrency);
				//iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193totalcashinvestmen",&pcTotalCashInv);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193billablecompany",&pcBillableCmpany);

				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193sellingprice",&pcsellingPrice);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193procustomertooling",&pcCustomerTooling);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193capextiautoowned",&pcTICapitalInvestment);
				iRetCode = AOM_UIF_ask_value(tSecObj[i],"t8_193netdevstartupcost",&pcNetDevStartupCost);
			}
		}
	}
	if(iRetCode == ITK_ok && tEngChangeRev!= NULLTAG && iNumAttachs > 0)
	{
		iRetCode = AOM_ask_value_tag(tEngChangeRev,"owning_site",&tpropTag);
		if(iRetCode == ITK_ok && tpropTag != NULLTAG )
		{
			iRetCode = AOM_ask_name(tpropTag,&pcSiteName);
		}
		else
		{
			iRetCode = POM_site_id(&iSite);
			if(iSite != 0)
				iRetCode = SA_find_site_by_id(iSite,&tSitetag);
			if(iRetCode == ITK_ok && tSitetag!= NULLTAG)
				iRetCode = SA_ask_site_info(tSitetag,acSiteName,&iSiteID);
		}
	}
	if(iRetCode == ITK_ok /*&& pcMailSubject != NULL && pcBodyMsg != NULL*/)
	{		
		iRetCode = EPM_ask_name  ( msg.task , caTaskName);
		iRetCode = AOM_ask_name(tRootTaskTag,&pcTaskName);
		TI_sprintf(acSubject,"%s - %s (%s/%s)",acSiteName,"Screening Notification",acChnId,acChnRevId);

		pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);

		iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
		
		fprintf(fMailBodyFile,"Hello,\n");
		fprintf(fMailBodyFile," You have been identified as a user who should receive an email notification about this PLM Change.\n");
		fprintf(fMailBodyFile,"Please refer to the details below for information regarding this PLM change.\n\n");

		
		fprintf(fMailBodyFile,"Change Revision                    : %s/%s-%s\n",acChnId, acChnRevId, acChnName);
		fprintf(fMailBodyFile,"Change Description                 : %s\n",pcChangeDescription);
		//fprintf(fMailBodyFile,"Process Name          : %s\n",pcTaskName);
		//fprintf(fMailBodyFile,"Current Task Name     : %s\n",caTaskName);
		//fprintf(fMailBodyFile,"Total Cash Investment : %s %s\n",pcTotalCashInv,pcCurrency);
		fprintf(fMailBodyFile,"PLM Site                           : %s\n",acSiteName);
		fprintf(fMailBodyFile,"Billable Company                   : %s \n",pcBillableCmpany);

		fprintf(fMailBodyFile,"Selling Price                      : %s  %s\n",pcsellingPrice,pcCurrency);
		fprintf(fMailBodyFile,"Profit on Customer Tooling         : %s  %s\n",pcCustomerTooling,pcCurrency);
		fprintf(fMailBodyFile,"TI Capital Investment              : %s  %s\n",pcTICapitalInvestment,pcCurrency);
		fprintf(fMailBodyFile,"Net Development & Startup Costs    : %s  %s\n",pcNetDevStartupCost,pcCurrency);
	

		if(pcChangeAdmin != NULL)
			fprintf(fMailBodyFile,"Change Initiator                   : %s\n",pcChangeAdmin);
		else
			
			fprintf(fMailBodyFile,"Change Initiator                   : \n");

		/*if(pcCustomer != NULL)
			fprintf(fMailBodyFile,"Customer              : %s\n",pcCustomer);
		else
			fprintf(fMailBodyFile,"Customer              : \n");
		*/
		fprintf(fMailBodyFile,"Affected Programs                  : %s\n",pcAffPrograms);
		fprintf(fMailBodyFile,"Affected Plants                    : %s\n",pcAffPlants);
		
		//fprintf(fMailBodyFile,"\n\nLink to Qlik Access Point : https://bireporting.extranet.tiauto.com/qlikview/ \n\n");
		fprintf(fMailBodyFile,"\n\nTo reference information about this PLM Change, please access the Qlik Access Point at:  https://bireporting.extranet.tiauto.com/qlikview/ and type in change number (%s) in the search field. \n\n",acChnId);
		

		//find MRA Details
		if(tEngChangeRev != NULLTAG)
		{
			char    pszObjType[WSO_name_size_c+1]="";
			iRetCode = WSOM_ask_object_type(tEngChangeRev, pszObjType);
			//get all the MRA documents & check whether PDF dataset is present with named reference

			if (iRetCode == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
			{
				iRetCode = GRM_find_relation_type ("CMHasSolutionItem",&tRelTemp);
				if(iRetCode == ITK_ok && tRelTemp!=NULLTAG)
				{
					iRetCode = GRM_list_secondary_objects_only(tEngChangeRev,tRelTemp,&iSolItemRevs,&ptSolItemRevs);
				}
			}
			else
			iRetCode = ECM_get_contents (tEngChangeRev,"solution_items",&iSolItemRevs,&ptSolItemRevs);
			//verify in Ref. folder
			for (iCount = 0; iCount < iSolItemRevs ; iCount++)
			{
				tc_strcpy(acObjectType,"");
				/* get the object type */
				iRetCode = WSOM_ask_object_type (ptSolItemRevs[iCount], acObjectType);
				if(tc_strcmp(acObjectType,"T8_T_MfgRelAuth Revision") == 0)
				{
					isMRAFound = true;

					iRetCode = TC_tag_to_url(ptSolItemRevs[iCount],PORTAL,&pcMRAURL);
					WSOM_ask_id_string (ptSolItemRevs[iCount],&pcMRAId);

					if(isMRADocDetails == false)
					{
						isMRADocDetails = true;
						fprintf(fMailBodyFile,"\n\nMfgRelAuthorisation Revision(s)    : \n",pcCommentValue);
						fprintf(fMailBodyFile,"\n%-20s%s","MRA Revision Id","URL");
						fprintf(fMailBodyFile,"\n%-20s%s","---------------","----------------------------------");
					}

					if(pcMRAURL != NULL)
						fprintf(fMailBodyFile,"\n%-20s%s",pcMRAId,pcMRAURL);
				}
			}

			
		fprintf(fMailBodyFile,"\n\nNOTE: This is an automated PLM email notification.\n\n");
		}
		if(fMailBodyFile != NULL)
		{
			fclose(fMailBodyFile);
		}
		while(TaskNamesPerUserList != NULL && iRetCode == ITK_ok)
		{			
			iRetCode = EPM_get_user_email_addr(TaskNamesPerUserList->tUniqueUser,&pcEmailId );
				
			if(iRetCode == ITK_ok &&  pcEmailId != NULL)
			{
				if(pcEmailId != NULL)
					iRetCode = tiauto_sendEMail(acSubject, pcEmailId, pcMailBodyFileName);
			}
			TaskNamesPerUserList = TaskNamesPerUserList->next;
			SAFE_MEM_free(pcEmailId);
		} 
		
		SAFE_MEM_free(pcComments);				
		// delete temporary file here
		remove(pcMailBodyFileName );				
			
	}
	
	//free the memory for linked lists
	FreeMemoryForLinkdList(TaskNamesPerUserList);
	
	SAFE_MEM_free(pcTaskName);
	SAFE_MEM_free(pcTaskTypeName);
	SAFE_MEM_free(ptTasks);
	SAFE_MEM_free(pcTaskTypeName);
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcSiteName);
	SAFE_MEM_free(pcMailSubject);
	SAFE_MEM_free(pcBodyMsg);
	SAFE_MEM_free(pcMailSubject);

	return iRetCode;  
}