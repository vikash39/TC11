/*******************************************************************************
*
* FILENAME : tiauto_custom_handlers.c
*
* DESCRIPTION :
*      This file serves as a container for TI Auto Custom Handlers. 
*
* PUBLIC FUNCTIONS :
*       int t1aAUTO_register_custom_handlers( int *decision, va_list args  );
*
*
* CHANGES :
*      REF NO   DATE            WHO             DETAIL
*              04/20/2007		Srikanth P		Initial Creation
*              12/17/2007       Arun M	        Modified for TIAUTO-check-deviation
               02/12/2008       Arun M          Modified for TIAUTO_demote_email
			   02/01/2009		Rajesh N		Registered TIAUTO-check-checkedout-remote-object handler
*			   01/13/2009       Garima D        Modified for TIAUTO-check-assembly-progression	
			   01/16/2009		Rajesh N		Registered TIAUTO-check-cro-items rule handler
*			   02/03/2009		Dipak Naik		Registered TIAUTO-verify-related-revisions rule handler	
*			   10/09/2009		Dipak Naik		Registered TIAUTO_RH_verify_status_progression_quick rule handler
*			   11/12/2009		Dipak Naik		Registered TIAUTO-AH-send-email-to-all action handler
*              10/02/2009       Nivedita        Registered TIAUTO-AH-block-sol-relation action handler
*                                               and TIAUTO-AH-block-aff-relation
*			   15/02/2010		Rajesh N		Registered TIAUTO-AH-check-non-doc-status action handler
*              18/02/2010       Nivedita        Added entry for TIAUTO_RH_check_ccr_form.
*			   24/02/2010		Rajesh N		Added entry for TIAUTO-AH-unset-conditional-task
*			   24/02/2010		Rajesh N		Merged the code for ER-5923-Workflow-for-Supplier-Requests
*              05/03/2010       Dipak Naik      removed the handler TIAUTO_RH_check_ccr_form.
*			   15/04/2010		Dipak Naik		Added the progresssion check handlers:
*												1) TIAUTO-AH-check-status-progression
*												2) TIAUTO-RH-check-status-progression-stacked-change
*              03/06/2010       Dipak Naik      Registered the TIAUTO-AH-check-blank-change action handler.
*			   01/10/2010		Dipak Naik		Registered TIAUTO-AH-notify-stacked-wait-user action handler
*			   13/06/2012		Mahesh BS		Registered TIAUTO-RH-check-mandatory-attributes rule handler
*
********************************************************************************/

/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_defines.h>

/*******************************************************************************
* PUBLIC FUNCTION DEFINITIONS
*******************************************************************************/

/*******************************************************************************
* NAME :            int t1aAUTO_register_custom_handlers( int *decision, va_list args  )
*
* DESCRIPTION :     Register all of TI AUTO action handlers here
*
* INPUTS :
*           PARAMETERS :
*  
*
* OUTPUTS :
*           PARAMETERS :
* 
*           RETURN : retcode 
*
* NOTES :           This function should call EPM_register_action_handler 
*                   once for each function to be registered.
*
*
*********************************************************************************/


int t1aAUTO_register_custom_handlers( int *decision, va_list args )
{
    int retcode = ITK_ok;
    
    *decision  = ALL_CUSTOMIZATIONS;

	// Action Handlers

    retcode =  EPM_register_action_handler("TIAUTO-validate-status-progression", 
                                         "", t1aAUTO_validate_status);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-validate-status-progression ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-verify-status-progression", 
                                         "", TIAUTO_AH_verify_status_progression);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-verify-status-progression ");

    retcode =  EPM_register_action_handler("TIAUTO-set-task-due-date", "",
                                            t1aAUTO_set_task_due_date);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-set-task-due-date ");

    retcode =  EPM_register_action_handler("TIAUTO-allow-form-changes", 
                                         "", t1aAUTO_allow_form_changes);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-allow-form-changes "); 

    retcode =  EPM_register_action_handler("TIAUTO-add-detailed-instructions", 
                                         "", t1aAUTO_add_detailed_instructions);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-add-detailed-instructions "); 

	retcode = EPM_register_action_handler("TIAUTO-demote-email", "", 
                                         t1aAUTO_demote_email);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-demote-email ");	
	
	retcode = EPM_register_action_handler("TIAUTO-AH-send-email-to-all", "", 
                                         t1aAUTO_send_email_toAll);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-send-email-to-all ");
	
	retcode = EPM_register_action_handler("TIAUTO-AH-set-rev-master-form-value", "", 
                                         tiauto_ah_set_rev_master_form_value);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-set-rev-master-form-value");

	retcode = EPM_register_action_handler("TIAUTO-AH-block-aff-relation","", 
                                         tiauto_ah_block_affitem_relation);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-block-aff-relation");
	
	retcode = EPM_register_action_handler("TIAUTO-AH-block-sol-relation","", 
                                         tiauto_ah_block_solitem_relation);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-block-sol-relation");
	
	retcode = EPM_register_action_handler("TIAUTO-AH-check-non-doc-status","", 
                                         tiauto_ah_check_non_doc_status);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-check-non-doc-status");
	
	retcode = EPM_register_action_handler("TIAUTO-AH-unset-conditional-task","", 
                                         tiauto_ah_unset_conditional_task);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-unset-conditional-task");

	retcode = EPM_register_action_handler("TIAUTO-AH-set-responsible-party","",t1aAUTO_set_responsible_party);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-set-responsible-party ");

		retcode = EPM_register_action_handler("TIAUTO-AH-set-supplier-info-attrs","",t1aAUTO_set_initiator_approval_date);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-set-supplier-info-attrs");

	retcode = EPM_register_action_handler("TIAUTO-AH-send-email","",t1aAUTO_send_email);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-send-email");

	retcode =  EPM_register_action_handler("TIAUTO-AH-check-status-progression","", TIAUTO_AH_check_status_progression);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-check-status-progression ");

	retcode = EPM_register_action_handler("TIAUTO-AH-check-blank-change","",TIAUTO_AH_check_blank_change);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-check-blank-change");

	retcode =  EPM_register_action_handler("TIAUTO-AH-notify-stacked-wait-user","", TIAUTO_AH_notify_stacked_wait_user);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-notify-stacked-wait-user ");

	retcode = EPM_register_action_handler("TIAUTO-AH-create-access-solution-item-rel","",tiauto_ah_create_access_solitem_rel);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-create-access-solution-item-rel");

	retcode = EPM_register_action_handler("TIAUTO-AH-create-access-affected-item-rel","",tiauto_ah_create_access_affecteditem_rel);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-create-access-affected-item-rel");
	
	retcode = EPM_register_action_handler( "TIAUTO-AH-CR-notify", "", TIAUTO_CR_notify );
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-CR-notify");

	retcode =  EPM_register_action_handler("TIAUTO-AH-send-targets-to-sites","", t1aAUTO_send_targets_to_sites);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-send-targets-to-sites");
	
	retcode =  EPM_register_action_handler("TIAUTO-AH-set-signoff-as-responsible-party","", t1aAUTO_set_signoff_as_responsible_party);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-signoff-as-responsible-party");

	retcode =  EPM_register_action_handler("TIAUTO-AH-check-doc-status","", TIAUTO_AH_check_doc_status);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-check-doc-status");

	retcode =  EPM_register_action_handler("TIAUTO-AH-set-attribute-value","", TIAUTO_set_attribute_value);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-attribute-value");

	retcode =  EPM_register_action_handler("TIAUTO-AH-attach-related-primary-object","", TIAUTO_ah_attach_related_primary_object);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-attach-related-primary-object");

	retcode =  EPM_register_action_handler("TIAUTO-AH-Create-ERP-Translation-Request","", TIAUTO_AH_create_erp_translation_request);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-Create-ERP-Translation-Request");

	retcode =  EPM_register_action_handler("TIAUTO-AH-Create-ToolNote-Item","", TAUTO_AH_Create_ToolNote_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-Create-ToolNote-Item");
	
	 retcode = EPM_register_action_handler("TIAUTO-AH-create-access-reference-item-rel","",tiauto_ah_create_access_referenceitem_rel);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-create-access-reference-item-rel");

	retcode = EPM_register_action_handler("TIAUTO-AH-block-prob-relation","",tiauto_ah_block_probitem_relation);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-block-prob-relation");

	retcode =  EPM_register_action_handler("TIAUTO-AH-create-mfgrelauthorisation","", TAUTO_AH_Create_MfgRelAuthorisation_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-mfgrelauthorisation");

	retcode =  EPM_register_action_handler("TIAUTO-AH-remove-parts-from-change-folder","", TIAUTO_AH_remove_parts_from_change_folder);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-mfgrelauthorization");

	retcode = EPM_register_action_handler("TIAUTO-AH-set-conditional-based-on-reviewer-list","", TIAUTO_AH_set_conditional_task_based_on_reviewer_list);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-set-conditional-based-on-reviewer-list");

	retcode = EPM_register_action_handler("TIAUTO-AH-attach-purchasedparts-form","",TIAUTO_AH_attach_purchasedparts_form);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-attach-purchasedparts-form");
	
	retcode =  EPM_register_action_handler("TIAUTO-AH-Create-CAEReport-Translation-Request","", TIAUTO_AH_create_cae_report_translation_request);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-Create-CAEReport-Translation-Request");

	retcode =  EPM_register_action_handler("TIAUTO-AH-allow-form-changes","", TIAUTO_AH_create_form_history);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-allow-form-changes");
	retcode =  EPM_register_action_handler("TIAUTO-AH-update-changed-form","", TIAUTO_AH_update_irm_with_change_info);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-update-irm-form");
	retcode =  EPM_register_action_handler("TIAUTO-AH-update-history-form-on-rejection","", TIAUTO_AH_update_history_form_on_rejection);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-update-history-form-on-rejection");
	
	retcode =  EPM_register_action_handler("TIAUTO-AH-remove-status-from-root-task","", TIAUTO_AH_remove_status_from_root_task);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-remove-status-from-root-task");

	retcode =  EPM_register_action_handler("TIAUTO-AH-create-baselinewatermark-translation-request","", TIAUTO_AH_create_baselinewatermark_translation_request);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-baselinewatermark-translation-request");

	retcode =  EPM_register_action_handler("TIAUTO-AH-set-additional-reviewers-as-resp-party","", t1aAUTO_AH_set_additional_reviewers_as_resp_party);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-additional-reviewers-as-resp-party");

	retcode =  EPM_register_action_handler("TIAUTO-AH-send-mandatory-screening-notification","", t1aAUTO_AH_send_mandatory_screening_notification);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-send-mandatory-screening-notification");

	retcode =  EPM_register_action_handler("TIAUTO-AH-set-optedin-user-as-resp-party","", t1aAUTO_AH_set_optedin_user_as_resp_party);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-optedin-user-as-resp-party");

	
	retcode =  EPM_register_action_handler("TIAUTO-AH-set-task-due-date", "",
                                            t1aAUTO_AH_set_task_due_date);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-task-due-date ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-block-drawing-relation", "",
                                            t1aAUTO_AH_block_drawing_relation);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-block-drawing-relation ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-block-summary-relation", "",
                                            t1aAUTO_AH_block_summary_relation);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-block-summary-relation ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-allow-drawing-relation", "",
                                            t1aAUTO_AH_allow_drawing_relation);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-allow-drawing-relation ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-allow-drawing-relation-on-approved", "",
                                            t1aAUTO_AH_allow_drawing_relation_on_approved);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-allow-drawing-relation-on-approved ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-allow-solution-relation-on-approved", "",
                                            t1aAUTO_AH_allow_solution_relation_on_approved);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-allow-solution-relation-on-approved ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-copy-and-attach-of-timing-form", "",
                                            t1aAUTO_AH_copy_and_attach_timing_form);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-copy-and-attach-of-timing-form ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-set-prototype-task-result", "",
                                            t1aAUTO_AH_set_prototype_task_result);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-prototype-task-result ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-add-child-components-to-target", "",
                                            t1aAUTO_AH_add_child_compoenents_to_target);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-add-child-components-to-target ");

	retcode = EPM_register_action_handler("TIAUTO-AH-notify-based-on-change-participants", "", 
                                         t1aAUTO_ah_notify_based_on_change_participants);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-notify-based-on-change-participants ");

	retcode = EPM_register_action_handler("TIAUTO-AH-check-mandatory-screening-need", "", 
											t1aAUTO_ah_check_mandatory_screening_need);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-check-mandatory-screening-need ");

	retcode = EPM_register_action_handler("TIAUTO-AH-update-standard-info-on-irm", "", 
											TIAUTO_AH_update_standard_info_on_irm);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler : TIAUTO-AH-update-standard-info-on-irm ");

	retcode =  EPM_register_action_handler("TIAUTO-AH-Create-Remote-Release-Translation-Request","", TIAUTO_AH_create_remote_release_translation_request);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-Create-Remote-Release-Translation-Request");

	retcode =  EPM_register_action_handler("TIAUTO-AH-create-summaryimage-item","", TAUTO_AH_Create_SummaryImage_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-summaryimage-item");

	retcode =  EPM_register_action_handler("TIAUTO-AH-update-affected-program-and-drawing-info","", TAUTO_AH_Update_Affected_Program_Info_On_PCI);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-update-affected-program-and-drawing-info");

	retcode =  EPM_register_action_handler("TIAUTO-AH-send-additional-notification","", t1aAUTO_AH_notify_to_additional_notifiers);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-send-additional-notification");

	retcode =  EPM_register_action_handler("TIAUTO-AH-remove-signoff-attachments","", t1aAUTO_AH_remove_signoff_attachments);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-remove-signoff-attachments");

	retcode =  EPM_register_action_handler("TIAUTO-AH-remove-items-from-project","", TIAUTO_AH_remove_items_from_project);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-remove-items-from-project");

	retcode =  EPM_register_action_handler("TIAUTO-AH-create-advchange-doc","", TIAUTO_AH_Create_ACD_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-advchange-doc");

	//PRP
	retcode =  EPM_register_action_handler("TIAUTO-AH-create-prorelauthorisation","", TAUTO_AH_Create_ProRelAuthorisation_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-prorelauthorisation");
		
    //Risk Assessment Document for CAP3
	retcode =  EPM_register_action_handler("TIAUTO-AH-create-RiskAssessment","", TAUTO_AH_Create_RiskAssessment_Item);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-create-RiskAssessment");

	retcode =  EPM_register_action_handler("TIAUTO-AH-set-resp-party","", t1aAUTO_AH_set_resp_party);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Action handler: TIAUTO-AH-set-resp-party");		
		
	// Rule Handlers

    retcode = EPM_register_rule_handler("TIAUTO-Check-Document", "", 
                                         t1aAUTO_check_document);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-Check-Document ");

    retcode = EPM_register_rule_handler("TIAUTO-check-target-object", "", 
                                         t1aAUTO_check_target_object);
    if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-check-target-object ");

	retcode = EPM_register_rule_handler("TIAUTO-check-deviation", "", 
                                         t1aAUTO_deviation_effectivity);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-check-deviation ");

	retcode = EPM_register_rule_handler("TIAUTO-check-generic-item-status", "", 
                                         t1aAUTO_ProE_integritycheck);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-check-generic-item-status ");

	retcode = EPM_register_rule_handler("TIAUTO-check-checkedout-remote-objects", "",
											t1aAUTO_check_checkedout_remote_objects);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-check-checkedout-remote-object");

	retcode = EPM_register_rule_handler("TIAUTO-check-assembly-status-progression", "", 
                                         t1aAUTO_check_assembly_progression);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-check-assembly-status-progression ");

	 retcode = EPM_register_rule_handler("TIAUTO-check-cro-items", "",
											t1aAUTO_check_cro_items);
	 if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler: TIAUTO-check-cro-items");

	retcode = EPM_register_rule_handler("TIAUTO-verify-related-revisions", "", 
                                         t1aAUTO_verify_related_revisions);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-verify-related-revisions ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-status-progression-stacked-change", "", 
                                         TIAUTO_RH_verify_status_progression_stacked_change);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO_RH_verify_status_progression_stacked_change ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-status-progression-quick", "", 
                                         TIAUTO_RH_verify_status_progression_quick);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-verify-status-progression-quick ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-check-status-progression-stacked-change", "", 
                                         TIAUTO_RH_check_status_progression_stacked_change);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-status-progression-stacked-change ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-check-based-on-condition", "", 
                                         TIAUTO_RH_check_based_on_condition);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-based-on-condition ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-action-performer-role", "", 
                                         TIAUTO_RH_check_action_performer_role);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-action-performer-role ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-conditional-task-result", "", 
                                         TIAUTO_RH_check_conditional_task_result);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-conditional-task-result ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-wait-for-parallel-path", "", 
                                         TIAUTO_RH_wait_for_parallel_path);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-wait-for-parallel-path ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-check-assignment-list", "", 
                                         TIAUTO_RH_check_assignment_list);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-assignment-list ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-checkedout-objects", "", 
                                         TIAUTO_RH_check_checkedout_objects);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-checkedout-objects ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-remote-objects", "", 
                                         TIAUTO_RH_check_remote_objects);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-remote-objects ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-mandatory-attributes", "", 
                                         TIAUTO_RH_check_mandatory_attributes);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-mandatory-attributes ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-related-objects", "", 
                                         TIAUTO_RH_verify_related_objects);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-verify-related-objects ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-valid-erp-plant", "", 
                                         TIAUTO_RH_check_valid_erp_plant);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-valid-erp-plant ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-product-impacted", "",
											 TIAUTO_RH_verify_product_impacted);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-verify-product-impacted ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-mra-dataset-creation", "",
											 TIAUTO_RH_check_mra_dataset_creation);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-mra-dataset-creation ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-caereport-dataset-creation", "",
											 TIAUTO_RH_check_caereport_dataset_creation);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-caereport-dataset-creation ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-component-MRA","",TIAUTO_RH_verify_component_MRA_generation);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-component-MRA");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-engineer-feasible-task-result", "", 
                                         TIAUTO_RH_check_engineer_feasible_task_result);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-engineer-feasible-task-result ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-targets-from-based-on-change", "", 
                                         TIAUTO_RH_check_targets_from_based_on_change);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-targets-from-based-on-change ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-targets-are-on-same-state", "", 
                                         TIAUTO_RH_check_targets_are_on_same_state);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-targets-are-on-same-state ");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-child-comp-are-on-same-state", "", 
                                         TIAUTO_RH_verify_child_comps_are_on_same_state);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-verify-child-comp-are-on-same-state ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-owning-group","",TIAUTO_RH_verify_owning_group);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-owning-group");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-masterdrawing-and-partfamily-attributes","",TIAUTO_RH_verify_masterdrawing_and_partfamily_attributes);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-masterdrawing-and-partfamily-attributes");


	retcode = EPM_register_rule_handler("TIAUTO-RH-check-reference-items","",TIAUTO_RH_check_reference_items);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-check-reference-items");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-change-form-mandatory-attributes", "", 
                                         TIAUTO_RH_check_change_form_mandatory_attributes);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-change-form-mandatory-attributes ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-changetiming-form-attribute-value", "", 
                                         TIAUTO_RH_check_changetiming_form_attribute_value);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-changetiming-form-attribute-value ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-references-from-based-on-change", "", 
                                         TIAUTO_RH_check_references_from_based_on_change);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-references-from-based-on-change ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-affected-plant", "", 
                                         TIAUTO_RH_check_plant_value_in_changetiming_and_pci);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-affected-plant ");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-mra-definition-attributes","",TIAUTO_RH_verify_mra_definition_attributes);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-mra-definition-attributes");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-parallel-path-tasks","",TIAUTO_RH_verify_parallel_path_tasks);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-parallel-path-tasks");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-design-work-required","",TIAUTO_RH_verify_designwork_required);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-design-work-required");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-items-for-project","",TIAUTO_RH_verify_items_for_project);
	if(retcode != ITK_ok)
    		printf("\n Error in Registering Rule handler : TIAUTO_RH_verify_items_for_project");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-items-notin-project","",TIAUTO_RH_verify_items_notin_project);
	if(retcode != ITK_ok)
    		printf("\n Error in Registering Rule handler : TIAUTO_RH_verify_items_notin_project");
	
	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-release-status-for-pci","",TIAUTO_RH_verify_release_status_for_pci);
	if(retcode != ITK_ok)
    		printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-release-status-for-pci");

	//PRP Workflow
	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-component-PRA","",TIAUTO_RH_verify_component_PRA_generation);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-component-PRA");

	retcode = EPM_register_rule_handler("TIAUTO-RH-verify-pra-definition-attributes","",TIAUTO_RH_verify_pra_definition_attributes);
	if(retcode != ITK_ok)
    	printf("\n Error in Registering Rule handler : TIAUTO-RH-verify-pra-definition-attributes");

	retcode = EPM_register_rule_handler("TIAUTO-RH-check-pra-dataset-creation", "",
											 TIAUTO_RH_check_pra_dataset_creation);
	if(retcode != ITK_ok)
		printf("\n Error in Registering Rule handler: TIAUTO-RH-check-pra-dataset-creation ");

    return retcode;
}
