/************************************************************************************************
FILE        :   tiauto_rh_verify_related_objects.c

DESCRIPTION :   

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
07 Jan, 2013    1.0        Dipak Naik       Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_related_objects(EPM_rule_message_t msg)
{
    int		iRetCode									= ITK_ok;
	int		iNumArgs									= 0;
	int     iNumAffected								= 0;
	int		i											= 0;
	int		iTypeNameCount								= 0;
	int		iCheck										= 0;

	EPM_decision_t decision								= EPM_go;

	char	*pcUserName									= NULL;
	char	*pcTaskTypeName								= NULL;

	char	acParentType[TCTYPE_name_size_c+1]			=	 "";
	char    acErrorString[TIAUTO_error_message_len+1]	=	 "";

	char	*pcArgValue									= NULL;
    char	*pcArgName									= NULL;
	char	*pcErrMsg									= NULL;
	char	*pcTargetObjectType							= NULL;
	char	*pcRelationName								= NULL;
	char	*pcSecObjectType							= NULL;
	char	*pcTemp										= NULL;
	char	*pcTemp1									= NULL;
	char	*pcPseudoFolderName							= NULL;
	char	*pcItemRevName								= NULL;
	char	*pcTaskResult								= NULL;
	char	**pcSecObjectTypes							= NULL;

    tag_t	tUser										= NULLTAG;
    tag_t	tTaskType									= NULLTAG;
	tag_t   tObjType									= NULLTAG;
	tag_t	tParentObjectType							= NULLTAG;
	tag_t   tTargetObject								= NULLTAG;
	tag_t	tRelation									= NULLTAG;

	tag_t   *ptSecObjects								= NULL;

	logical lValidationSuccess = false;

	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if(iRetCode == ITK_ok && pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMConditionTask") == 0) )
	{
		iRetCode = EPM_get_task_result (msg.task,&pcTaskResult);
		//get the conditional task result......if option is other than Approve then return EPM_go
		if(pcTaskResult != NULL && (tc_strcmp(pcTaskResult,"Approve") != 0) )
		{
			SAFE_MEM_free(pcTaskResult);
			SAFE_MEM_free(pcTaskTypeName);
			SAFE_MEM_free (pcUserName);
			decision = EPM_go;
			return decision;
		}
	}
	/* get the number of arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);
	if( (iNumArgs == 2) || (iNumArgs == 3))
	{
		for( i = 0;i < iNumArgs;i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if( ( iRetCode == ITK_ok ) && (pcArgName != NULL) && (pcArgValue != NULL) )
			{
			   
				if(tc_strcasecmp(pcArgName, "target_type") == 0)
				{
				    //Initialising memory for the comma separated query names.
			        pcTargetObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
                    tc_strcpy( pcTargetObjectType, pcArgValue);
					
				}
				else if(tc_strcasecmp(pcArgName, "relation_name") == 0)
				{
					pcRelationName = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcRelationName, pcArgValue);
				}				
				else if(tc_strcasecmp(pcArgName, "secondary_type") == 0)
				{
					pcSecObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcSecObjectType, pcArgValue);
				}
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
			else
			{						
				iRetCode = EPM_invalid_argument;			
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	//check the mandatory argument check
	if(iRetCode == ITK_ok && ((pcTargetObjectType ==NULL) || (pcRelationName == NULL)) )
	{
		iRetCode = EPM_invalid_argument_value;
	}

    if(iRetCode == 0)
    {
		iRetCode = get_target_object(msg.task,pcTargetObjectType,&tTargetObject);
		if(tTargetObject != NULLTAG)
		{
			if(pcSecObjectType != NULL)
			{
				pcSecObjectTypes = (char **)MEM_alloc(20* sizeof(char *));			
				pcTemp1 = (char *)MEM_alloc( ((int)tc_strlen(pcSecObjectType)) * sizeof(char));
				tc_strcpy(pcTemp1,pcSecObjectType);
				pcTemp = tc_strtok (pcTemp1,",");
				while(pcTemp != NULL && iRetCode == ITK_ok)
				{
					//to remove the forward and trailing space
					//remove_forward_AND_trailing_space(pcTemp);
					//validate the input argument value				
					iRetCode = TCTYPE_find_type (pcTemp,NULL,&tObjType);
					if(iRetCode == ITK_ok && tObjType != NULLTAG)
					{
						pcSecObjectTypes[iTypeNameCount] = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
						tc_strcpy(pcSecObjectTypes[iTypeNameCount],pcTemp);			
						iTypeNameCount++;					
						pcTemp = tc_strtok(NULL,",");
					}
					else
					{
						iRetCode = EPM_invalid_argument_value;
						TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"secondary_object\".");
						EMH_store_error_s1( EMH_severity_error, iRetCode, acErrorString) ;						
						TC_write_syslog(acErrorString);
						decision = EPM_nogo;
						break;
					}
				}	
			}

			if(iRetCode == ITK_ok && tTargetObject != NULLTAG && pcRelationName != NULL)
			{
				iRetCode = GRM_find_relation_type (pcRelationName,&tRelation);
				if(iRetCode == ITK_ok && tRelation != NULLTAG)
					iRetCode = TCTYPE_ask_display_name   (tRelation,&pcPseudoFolderName);
				if( iRetCode == ITK_ok && tRelation != NULLTAG) 
				{
					iRetCode = GRM_list_secondary_objects_only(tTargetObject,tRelation,&iNumAffected,&ptSecObjects);
					for(iCheck = 0; iCheck < iNumAffected && (iRetCode == ITK_ok) ; iCheck++ )
					{
						tc_strcpy(acParentType,"");
						/* get the object type */
						iRetCode = WSOM_ask_object_type (ptSecObjects[iCheck], acParentType);
						if( (iTypeNameCount > 0) && (pcSecObjectType != NULL) )
						{
							if (tc_strstr(pcSecObjectType,acParentType) != NULL )
							{
								lValidationSuccess = true;
								break;
							}
							else
							{
								tc_strcpy(acParentType,"");
								tObjType = NULLTAG;
								iRetCode = TCTYPE_ask_object_type (ptSecObjects[iCheck],&tObjType);
								if(tObjType != NULLTAG)
									iRetCode = TCTYPE_ask_parent_type (tObjType,&tParentObjectType);

								if(tParentObjectType != NULLTAG)
									iRetCode = TCTYPE_ask_name (tParentObjectType,acParentType);

								if(tc_strstr(pcSecObjectType,acParentType) != NULL )
								{
									lValidationSuccess = true;
									break;
								}
								else
								{
									lValidationSuccess = false;
								}
							}
						}
						else if(iTypeNameCount == 0)
						{
							lValidationSuccess = true;
							break;
						}
					}					
					SAFE_MEM_free(ptSecObjects);
				}
			}
			if(pcSecObjectTypes != NULL)
			{
				SAFE_MEM_free(pcSecObjectTypes);
			}
		}
		else if(tTargetObject == NULLTAG)
		{
			iRetCode = EPM_invalid_argument_value;
			TI_sprintf(acErrorString, "No target object of type \"%s\" found.",pcTargetObjectType);
			EMH_store_error_s1( EMH_severity_error, iRetCode, acErrorString) ;						
			TC_write_syslog(acErrorString);
			decision = EPM_nogo;
		}
		
	}
	/* if ITK error during the handler exceution */
    if( iRetCode != ITK_ok )
	{
		decision = EPM_nogo;
		EMH_ask_error_text(iRetCode, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
		
	}

	if( lValidationSuccess == false)
	{
		decision = EPM_nogo;
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
		iRetCode = TIAUTO_VERIFY_RELATED_REVISIONS_ERROR;
		/* Get the Item revision name */
		if(tTargetObject != NULLTAG)
			iRetCode =  tiauto_get_itemrev_name(tTargetObject, &pcItemRevName);

		if((iTypeNameCount > 0) && (pcSecObjectType != NULL) )
		{
			TI_sprintf( acErrorString, "\nTo fix this problem, Please add at least one item revision of type \"%s\" to the \"%s\" folder for the above item revisions.",pcSecObjectType,pcPseudoFolderName  );
			EMH_store_error_s1(EMH_severity_error, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString );
			TI_sprintf(acErrorString, "The item revision %s does not contain any item revisions of type \"%s\" in the \"%s\" folder. ", pcItemRevName,pcSecObjectType ,pcPseudoFolderName);
			EMH_store_error_s1(EMH_severity_error, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString );
		}
		else
		{
			TI_sprintf( acErrorString, "\nTo fix this problem, Please add at least one item revision to the \"%s\" folder for the above item revisions.",pcPseudoFolderName  );
			EMH_store_error_s1(EMH_severity_error, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString );
			TI_sprintf(acErrorString, "The item revision %s does not contain any item revisions in the \"%s\" folder. ", pcItemRevName,pcPseudoFolderName);
			EMH_store_error_s1(EMH_severity_error, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString );
		}
		
	}
	
	SAFE_MEM_free (ptSecObjects);
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);
	SAFE_MEM_free(pcPseudoFolderName);	

	return decision;
}
