/*********************************************************************************************************************
FILE        :   tiauto_rh_verify_items_notin_project.c
Details     :   This rule handler is used to check affected items of a change is not in any project

REVISION HISTORY :

Date              Revision        Who						Description
Feb 08, 2019      1.0			  Trisha				Initial Creation.

**************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
EPM_decision_t TIAUTO_RH_verify_items_notin_project(EPM_rule_message_t msg )
{
	int			iRetCode					= ITK_ok;
	int			iNumAffected				= 0;
	int			iLoopSecObjCnt				= 0;
	tag_t		*ptAffectedItems			= NULL;
	tag_t		tEngChangeRev				= NULLTAG;	
	logical		lisInProject				= false;
	char		*pcItemRevID				= NULL;
	tag_t		tSummRelation				= NULLTAG;
	int			iSummObjCount				= 0;
	tag_t		*ptSummObjs					= NULL;
	int			iLoopSummImag				= 0;

	char acItemId[ITEM_id_size_c+1]			= {'\0'};
	char acItemRevId[ITEM_id_size_c+1]		= {'\0'};
	char acItemName[ITEM_name_size_c+1]		= {'\0'};
	EPM_decision_t	decision				= EPM_go;	

	if (iRetCode == ITK_ok )
		iRetCode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
	if(tEngChangeRev!= NULLTAG && iRetCode==ITK_ok)
		TIAUTO_ITKCALL(iRetCode,CheckItemsProject(tEngChangeRev,&lisInProject));
	//changed
	if(lisInProject == true && iRetCode==ITK_ok)
	{
		char acItemId[ITEM_id_size_c+1]			= {'\0'};
		char acItemRevId[ITEM_id_size_c+1]		= {'\0'};
		char acItemName[ITEM_name_size_c+1]		= {'\0'};

		decision= EPM_nogo;
		TIAUTO_ITKCALL(iRetCode,tiauto_getItemRevDetails(tEngChangeRev,acItemId,acItemRevId,acItemName));
		pcItemRevID=(char *)MEM_alloc((tc_strlen(acItemId)+1) * sizeof(char) );  
		pcItemRevID = (char*) MEM_realloc ( pcItemRevID, (tc_strlen(acItemRevId)+1) * sizeof(char*));
		tc_strcpy(pcItemRevID,acItemId);
		tc_strcat(pcItemRevID,TIAUTO_FRONT_SLASH);
		tc_strcat(pcItemRevID,acItemRevId);
		//changed
		EMH_store_error_s1( EMH_severity_error,TIAUTO_ITEMS_IN_PROJ,pcItemRevID);
		SAFE_MEM_free(pcItemRevID);		
	}
	TIAUTO_ITKCALL(iRetCode,ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems));
	for(iLoopSecObjCnt =0; iLoopSecObjCnt < iNumAffected; iLoopSecObjCnt++)
	{
		tag_t		tCostFrmRel				= NULLTAG;
		int			iCostFrmCnt				= 0;
		tag_t		*ptCostFrm				= NULL;
		int			iLoopCostForm			= 0;
		
		lisInProject = false;
		TIAUTO_ITKCALL(iRetCode,CheckItemsProject(ptAffectedItems[iLoopSecObjCnt],&lisInProject));	
		//changed
		if(lisInProject == true && iRetCode==ITK_ok)
		{
			char acItemId[ITEM_id_size_c+1]			= {'\0'};
			char acItemRevId[ITEM_id_size_c+1]		= {'\0'};
			char acItemName[ITEM_name_size_c+1]		= {'\0'};
			decision= EPM_nogo;	
			TIAUTO_ITKCALL(iRetCode,tiauto_getItemRevDetails(ptAffectedItems[iLoopSecObjCnt],acItemId,acItemRevId,acItemName));
			pcItemRevID=(char *)MEM_alloc((tc_strlen(acItemId)+1) * sizeof(char) );  
			pcItemRevID = (char*) MEM_realloc ( pcItemRevID, (tc_strlen(acItemRevId)+1) * sizeof(char*));
			tc_strcpy(pcItemRevID,acItemId);
			tc_strcat(pcItemRevID,TIAUTO_FRONT_SLASH);
			tc_strcat(pcItemRevID,acItemRevId);
			//changed
			EMH_store_error_s1( EMH_severity_error,TIAUTO_ITEMS_IN_PROJ,pcItemRevID);
			SAFE_MEM_free(pcItemRevID);
		}
		TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_COST_FORM_REL,&tCostFrmRel));
		if( iRetCode == ITK_ok && tCostFrmRel != NULLTAG)
		{
			lisInProject = false;
			TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(ptAffectedItems[iLoopSecObjCnt],tCostFrmRel,&iCostFrmCnt,&ptCostFrm));
			for(iLoopCostForm =0; iLoopCostForm < iCostFrmCnt; iLoopCostForm++)
			{
				lisInProject = false;
				TIAUTO_ITKCALL(iRetCode,CheckItemsProject(ptCostFrm[iLoopCostForm],&lisInProject));
				//changed
				if(lisInProject == true && iRetCode==ITK_ok)
				{
					char acItemId[ITEM_id_size_c+1]			= {'\0'};
					char acItemRevId[ITEM_id_size_c+1]		= {'\0'};
					char acItemName[ITEM_name_size_c+1]		= {'\0'};

					decision= EPM_nogo;	
					TIAUTO_ITKCALL(iRetCode,tiauto_getItemRevDetails(ptAffectedItems[iLoopSecObjCnt],acItemId,acItemRevId,acItemName));
					pcItemRevID=(char *)MEM_alloc((tc_strlen(acItemId)+1) * sizeof(char) );  
					pcItemRevID = (char*) MEM_realloc ( pcItemRevID, (tc_strlen(acItemRevId)+1) * sizeof(char*));
					tc_strcpy(pcItemRevID,acItemId);
					tc_strcat(pcItemRevID,TIAUTO_FRONT_SLASH);
					tc_strcat(pcItemRevID,acItemRevId);
					EMH_store_error_s1( EMH_severity_error,TIAUTO_ITEMS_IN_PROJ,pcItemRevID);
					SAFE_MEM_free(pcItemRevID);
				}
			}

		}		
		
	}
	TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_SUMM_IMAG_REL,&tSummRelation));
	if( iRetCode == ITK_ok && tSummRelation != NULLTAG)
	{
		lisInProject = false;
		TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(tEngChangeRev,tSummRelation,&iSummObjCount,&ptSummObjs));
		for(iLoopSummImag =0; iLoopSummImag < iSummObjCount; iLoopSummImag++)
		{
			lisInProject = false;
			TIAUTO_ITKCALL(iRetCode,CheckItemsProject(ptSummObjs[iLoopSummImag],&lisInProject));
			//changed
			if(lisInProject == true && iRetCode==ITK_ok)
			{
				char acItemId[ITEM_id_size_c+1]			= {'\0'};
				char acItemRevId[ITEM_id_size_c+1]		= {'\0'};
				char acItemName[ITEM_name_size_c+1]		= {'\0'};

				decision= EPM_nogo;	
				TIAUTO_ITKCALL(iRetCode,tiauto_getItemRevDetails(ptSummObjs[iLoopSummImag],acItemId,acItemRevId,acItemName));
				pcItemRevID=(char *)MEM_alloc((tc_strlen(acItemId)+1) * sizeof(char) );  
				pcItemRevID = (char*) MEM_realloc ( pcItemRevID, (tc_strlen(acItemRevId)+1) * sizeof(char*));
				tc_strcpy(pcItemRevID,acItemId);
				tc_strcat(pcItemRevID,TIAUTO_FRONT_SLASH);
				tc_strcat(pcItemRevID,acItemRevId);//changed
				EMH_store_error_s1( EMH_severity_error,TIAUTO_ITEMS_IN_PROJ,pcItemRevID);
				SAFE_MEM_free(pcItemRevID);
			}	
		}
	}
	if ( iRetCode != ITK_ok )
	{
		char	*pcErrMsg				= NULL;		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(ptAffectedItems);
	return decision;
}
	
int	CheckItemsProject(tag_t	tItem,logical		*lisInProject)
{	
	int			iRetCode				= ITK_ok;
	char		*pcProjList				= NULL;
	char		*pcTemp1				= NULL;	
	char		*pcProjID				= NULL;		
	
	TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(tItem,TIAUTO_PROJ_LIST,&pcProjList));		
	pcTemp1 = (char *)MEM_alloc( ((int)tc_strlen(pcProjList)) * sizeof(char));
	tc_strcpy(pcTemp1,pcProjList);
	pcProjID = tc_strtok (pcTemp1,TIAUTO_COMMA);	
	while(pcProjID != NULL && iRetCode == ITK_ok)
	{							
		if((tc_strcmp(pcProjID,TIAUTO_PROJ_ID)==0) && iRetCode==ITK_ok)
		{
			*lisInProject = true;
			break;
		}
		pcProjID = tc_strtok (NULL,TIAUTO_COMMA);	
	}
	SAFE_MEM_free(pcProjList);
	SAFE_MEM_free(pcTemp1);
	//SAFE_MEM_free(pcProjID);
	return	iRetCode;
}	
		
