/*******************************************************************************************************************
File         : find_CCR_change_rev.c

Description  : These are functions related to the user query - "TI Change (CCR Form)"
			   This function will search for CAP change objects.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
23 Oct 2019		1.0			Chandra				Initial Creation  
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		TIAUTO_find_CCR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "TI Change Rev (CCR Form)" user query.
================================================================================================================*/
extern int find_CCR_change (const char* pcItemID,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,
			const char* pcOwningGroup, const char* pcOwningSite,const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcPricingGuidance,const char* pcSplCustCommerReq,
			const char* pcLaborEcoYrmax,const char* pcLaborEcoYrmin,const char* pcPackaging,const char* pcTypeofQuote,const char* pcBillCompType,const char* pcBillComp,const char* pcCustAuthorNum,const char* pcCustContName,
			const char* pcCustContEmail,const char* pcCustPhone,const char* pcEstNum, const char* pcVarEstNum, const char* pcCostofChangeCur,const char* pcToolCostmax,const char* pcToolCostmin,const char* pcCustPaidToolmax,
			const char* pcCustPaidToolmin,const char* pcPurExWorkCostmax,const char* pcPurExWorkCostmin,const char* pcPurDelDutyPaidCostmax,const char* pcPurDelDutyPaidCostmin,const char* pcLogisCostmax, 
			const char* pcLogisCostmin,const char* pcMfgLaborCostmax,const char* pcMfgLaborCostmin,const char* pcMatCostmax,const char* pcMatCostmin,const char* pcMfgVarCostmax,const char* pcMfgVarCostmin,
			const char* pcMfgScrapPermax,const char* pcMfgScrapPermin,const char* pcTotalVarCostmax,const char* pcTotalVarCostmin,const char* pcMfgSellingTransPricemax,const char* pcMfgSellingTransPricemin,
			const char* pcTIMarkupUnitCurrmax,const char* pcTIMarkupUnitCurrmin,const char* pcScreeningReq,const char* pcCustAppReq,const char* pcCustAppType,const char* pcRFQIssuemax, const char* pcRFQIssuemin, 
			const char* pcRFQCustDuemax,const char* pcRFQCustDuemin,const char* pcProtoDuemax,const char* pcProtoDuemin,const char* pcProtoQltSignmax, const char* pcProtoQltSignmin,const char* pcDesignValDuemax,
			const char* pcDesignValDuemin,const char* pcPPAPReq,const char* pcTarPPAPLevel, const char* pcCritPathItem,const char* pcCriPathItemPPAPmax,const char* pcCriPathItemPPAPmin,const char* pcPPAPBuildEvemax,
			const char* pcPPAPBuildEvemin,const char* pcProValSignmax,const char* pcProValSignmin,const char* pcRunRateSignmax, const char* pcRunRateSignmin, const char* pcPPAPSignmax, const char* pcPPAPSignmin, 
			const char* pcProSignmax, const char* pcProSignmin, const char* pcProdMatReqmax,const char* pcProdMatReqmin,const char* pcStartProdmax,const char* pcStartProdmin,const char* pcEndProdmax,const char* pcEndProdmin,					
			char* pcForm,
			int *iNumFound,tag_t **foundTags)
{
	int				iFail = ITK_ok;
	const char		*select_attr_list1[] = {"puid"};
	const char		*pcRelationTypeName = "IMAN_specification";
	const char		*pcItemType[] = {"EngChange","T8_TI_Change"};
	int				iRows		= 0;
	int				i			= 0;
	int				iCols		= 0;
	void			***paReport;
	tag_t			tChItem	= NULLTAG;
	date_t dCAD,dCBD,dMAD,dMBD,dRAD,dRBD,dRFQIssuemax,dRFQIssuemin,dRFQCustDuemax,dRFQCustDuemin,dProtoDuemax,dProtoDuemin,dProtoQltSignmax,dProtoQltSignmin,dDesignValDuemax,dDesignValDuemin,dCriPathItemPPAPmax,dCriPathItemPPAPmin,dPPAPBuildEvemax,dPPAPBuildEvemin,dProValSignmax,dProValSignmin,dRunRateSignmax,dRunRateSignmin,dPPAPSignmax,dPPAPSignmin,dProSignmax,dProSignmin,dProdMatReqmax,dProdMatReqmin,dStartProdmax,dStartProdmin,dEndProdmax,dEndProdmin = NULLDATE;
	int iLaborEcoYrmax = 0;
	int iLaborEcoYrmin = 0;
	double dToolCostmax            = 0;
	double dToolCostmin= 0;
	double dCustPaidToolmax= 0;
	double dCustPaidToolmin= 0;
	double dPurExWorkCostmax= 0;
	double dPurExWorkCostmin= 0;
	double dPurDelDutyPaidCostmax= 0;
	double dPurDelDutyPaidCostmin= 0;
	double dLogisCostmax= 0;
	double dLogisCostmin= 0;
	double dMfgLaborCostmax= 0;
	double dMfgLaborCostmin= 0;
	double dMatCostmax= 0;
	double dMatCostmin= 0;
	double dMfgVarCostmax= 0;
	double dMfgVarCostmin= 0;
	double dMfgScrapPermax= 0;
	double dMfgScrapPermin= 0;
	double dTotalVarCostmax= 0;
	double dTotalVarCostmin= 0;
	double dMfgSellingTransPricemax= 0;
	double dMfgSellingTransPricemin= 0;
	double dTIMarkupUnitCurrmax= 0;
	double dTIMarkupUnitCurrmin= 0;
	char	acFormClassName[64] = "";


	char	*pcFormAttr_PricingGuidance				= NULL;
	char	*pcFormAttr_SplCustCommerReq			= NULL;
	char	*pcFormAttr_LaborEcoYrmax				= NULL;
	char	*pcFormAttr_LaborEcoYrmin				= NULL;
	char	*pcFormAttr_Packaging					= NULL;
	char	*pcFormAttr_TypeofQuote					= NULL;
	char	*pcFormAttr_BillCompType				= NULL;
	char	*pcFormAttr_BillComp					= NULL;
	char	*pcFormAttr_CustAuthorNum				= NULL;
	char	*pcFormAttr_CustContName				= NULL;
	char	*pcFormAttr_CustContEmail				= NULL;
	char	*pcFormAttr_CustPhone					= NULL;
	char	*pcFormAttr_EstNum						= NULL; 
	char	*pcFormAttr_VarEstNum					= NULL; 
	char	*pcFormAttr_CostofChangeCur				= NULL;
	char	*pcFormAttr_ToolCostmax					= NULL;
	char	*pcFormAttr_ToolCostmin					= NULL;
	char	*pcFormAttr_CustPaidToolmax				= NULL;
	char	*pcFormAttr_CustPaidToolmin				= NULL;
	char	*pcFormAttr_PurExWorkCostmax			= NULL;
	char	*pcFormAttr_PurExWorkCostmin			= NULL;
	char	*pcFormAttr_PurDelDutyPaidCostmax		= NULL;
	char	*pcFormAttr_PurDelDutyPaidCostmin		= NULL;
	char	*pcFormAttr_LogisCostmax				= NULL; 
	char	*pcFormAttr_LogisCostmin				= NULL;
	char	*pcFormAttr_MfgLaborCostmax				= NULL;
	char	*pcFormAttr_MfgLaborCostmin				= NULL;
	char	*pcFormAttr_MatCostmax					= NULL;
	char	*pcFormAttr_MatCostmin					= NULL;
	char	*pcFormAttr_MfgVarCostmax				= NULL;
	char	*pcFormAttr_MfgVarCostmin				= NULL;
	char	*pcFormAttr_MfgScrapPermax				= NULL;
	char	*pcFormAttr_MfgScrapPermin				= NULL;
	char	*pcFormAttr_TotalVarCostmax				= NULL;
	char	*pcFormAttr_TotalVarCostmin				= NULL;
	char	*pcFormAttr_MfgSellingTransPricemax		= NULL;
	char	*pcFormAttr_MfgSellingTransPricemin		= NULL;
	char	*pcFormAttr_TIMarkupUnitCurrmax			= NULL;
	char	*pcFormAttr_TIMarkupUnitCurrmin			= NULL;
	char	*pcFormAttr_ScreeningReq				= NULL;
	char	*pcFormAttr_CustAppReq					= NULL;
	char	*pcFormAttr_CustAppType					= NULL;
	char	*pcFormAttr_RFQIssuemax					= NULL; 
	char	*pcFormAttr_RFQIssuemin					= NULL; 
	char	*pcFormAttr_RFQCustDuemax				= NULL;
	char	*pcFormAttr_RFQCustDuemin				= NULL;
	char	*pcFormAttr_ProtoDuemax					= NULL;
	char	*pcFormAttr_ProtoDuemin					= NULL;
	char	*pcFormAttr_ProtoQltSignmax				= NULL; 
	char	*pcFormAttr_ProtoQltSignmin				= NULL;
	char	*pcFormAttr_DesignValDuemax				= NULL;
	char	*pcFormAttr_DesignValDuemin				= NULL;
	char	*pcFormAttr_PPAPReq						= NULL;
	char	*pcFormAttr_TarPPAPLevel				= NULL;
	char	*pcFormAttr_CritPathItem				= NULL;
	char	*pcFormAttr_CriPathItemPPAPmax			= NULL;
	char	*pcFormAttr_CriPathItemPPAPmin			= NULL;
	char	*pcFormAttr_PPAPBuildEvemax				= NULL;
	char	*pcFormAttr_PPAPBuildEvemin				= NULL;
	char	*pcFormAttr_ProValSignmax				= NULL;
	char	*pcFormAttr_ProValSignmin				= NULL;
	char	*pcFormAttr_RunRateSignmax				= NULL; 
	char	*pcFormAttr_RunRateSignmin				= NULL; 
	char	*pcFormAttr_PPAPSignmax			        = NULL; 
	char	*pcFormAttr_PPAPSignmin					= NULL; 
	char	*pcFormAttr_ProSignmax					= NULL; 
	char	*pcFormAttr_ProSignmin					= NULL; 
	char	*pcFormAttr_ProdMatReqmax				= NULL;
	char	*pcFormAttr_ProdMatReqmin				= NULL;
	char	*pcFormAttr_StartProdmax				= NULL;
	char	*pcFormAttr_StartProdmin				= NULL;
	char	*pcFormAttr_EndProdmax					= NULL;
	char	*pcFormAttr_EndProdmin					= NULL;	

	if (tc_strcasecmp(pcForm,"ccr") == 0)
	{
		
		pcFormAttr_PricingGuidance						="t1a41pricingguidance";      
		pcFormAttr_SplCustCommerReq                     ="t1a41specialcustomercomm"; 
		pcFormAttr_LaborEcoYrmax						="t1a41laboreconomicyear"; 
		pcFormAttr_LaborEcoYrmin						="t1a41laboreconomicyear"; 
		pcFormAttr_Packaging							="t1a41packaging"; 
		pcFormAttr_TypeofQuote							="t1a41typeofquote"; 
		pcFormAttr_BillCompType							="t1a41billablecompanytype"; 
		pcFormAttr_BillComp								="t1a41billablecompany";
		pcFormAttr_CustAuthorNum						="t1a41customerauthorizati"; 
		pcFormAttr_CustContName							="t1a41customercontactname"; 
		pcFormAttr_CustContEmail						="t1a41customercontactemai"; 
		pcFormAttr_CustPhone							="t1a41customercontactphon"; 
		pcFormAttr_EstNum								="t1a41estimatenumber"; 
		pcFormAttr_VarEstNum							="t1a41varianceestimatenum"; 
		pcFormAttr_CostofChangeCur						="t1a41currency"; 
		pcFormAttr_ToolCostmax							="t1a41toolingcost"; 
		pcFormAttr_ToolCostmin							="t1a41toolingcost"; 
		pcFormAttr_CustPaidToolmax						="t1a41customerpaidtooling"; 
		pcFormAttr_CustPaidToolmin						="t1a41customerpaidtooling"; 
		pcFormAttr_PurExWorkCostmax						="t1a41purchexworkscost"; 
		pcFormAttr_PurExWorkCostmin                     ="t1a41purchexworkscost"; 
		pcFormAttr_PurDelDutyPaidCostmax                ="t1a41purchdelivereddutyp"; 
		pcFormAttr_PurDelDutyPaidCostmin                ="t1a41purchdelivereddutyp"; 
		pcFormAttr_LogisCostmax						    ="t1a41logisticscost"; 
		pcFormAttr_LogisCostmin							="t1a41logisticscost"; 
		pcFormAttr_MfgLaborCostmax                      ="t1a41mfglaborcost"; 
		pcFormAttr_MfgLaborCostmin                      ="t1a41mfglaborcost"; 
		pcFormAttr_MatCostmax							="t1a41materialscost"; 
		pcFormAttr_MatCostmin							="t1a41materialscost"; 
		pcFormAttr_MfgVarCostmax						="t1a41mfgvariableoverhead"; 
		pcFormAttr_MfgVarCostmin						="t1a41mfgvariableoverhead"; 
		pcFormAttr_MfgScrapPermax						="t1a41mfgscrappercentage"; 
		pcFormAttr_MfgScrapPermin						="t1a41mfgscrappercentage"; 
		pcFormAttr_TotalVarCostmax						="t1a41totalvariablecost"; 
		pcFormAttr_TotalVarCostmin						="t1a41totalvariablecost"; 
		pcFormAttr_MfgSellingTransPricemax              ="t1a41mfgsellingtransferp"; 
		pcFormAttr_MfgSellingTransPricemin              ="t1a41mfgsellingtransferp"; 
		pcFormAttr_TIMarkupUnitCurrmax                  ="t1a41timarkupunitsofcurr"; 
		pcFormAttr_TIMarkupUnitCurrmin					="t1a41timarkupunitsofcurr"; 
		pcFormAttr_ScreeningReq							="t1a41screeningrequired"; 
		pcFormAttr_CustAppReq							="t1a41customerapprovalreq"; 
		pcFormAttr_CustAppType							="t1a41customerapprovalreq"; 
		pcFormAttr_RFQIssuemax							="t1a41rfqissued"; 
		pcFormAttr_RFQIssuemin							="t1a41rfqissued"; 
		pcFormAttr_RFQCustDuemax						="t1a41rfqcustomerdue"; 
		pcFormAttr_RFQCustDuemin						="t1a41rfqcustomerdue"; 
		pcFormAttr_ProtoDuemax							="t1a41prototypedue"; 
		pcFormAttr_ProtoDuemin							="t1a41prototypedue"; 
		pcFormAttr_ProtoQltSignmax                      ="t1a41prototypequalitysig"; 
		pcFormAttr_ProtoQltSignmin						="t1a41prototypequalitysig"; 
		pcFormAttr_DesignValDuemax						="t1a41designvalidationdue"; 
		pcFormAttr_DesignValDuemin						="t1a41designvalidationdue"; 
		pcFormAttr_PPAPReq								="t1a41ppaprequired"; 
		pcFormAttr_TarPPAPLevel							="t1a41targetppaplevel"; 
		pcFormAttr_CritPathItem							="t1a41criticalpathitem";
		pcFormAttr_CriPathItemPPAPmax                   ="t1a41criticalpathitemppa"; 
		pcFormAttr_CriPathItemPPAPmin                   ="t1a41criticalpathitemppa"; 
		pcFormAttr_PPAPBuildEvemax                      ="t1a41ppapbuildevent"; 
		pcFormAttr_PPAPBuildEvemin                      ="t1a41ppapbuildevent"; 
		pcFormAttr_ProValSignmax                        ="t1a41processvalidationsi"; 
		pcFormAttr_ProValSignmin                        ="t1a41processvalidationsi"; 
		pcFormAttr_RunRateSignmax                       ="t1a41runatratesignoff"; 
		pcFormAttr_RunRateSignmin						="t1a41runatratesignoff"; 
		pcFormAttr_PPAPSignmax							="t1a41ppapsignoff"; 
		pcFormAttr_PPAPSignmin							="t1a41ppapsignoff"; 
		pcFormAttr_ProSignmax							="t1a41processsignoff"; 
		pcFormAttr_ProSignmin							="t1a41processsignoff"; 
		pcFormAttr_ProdMatReqmax						="t1a41productionmaterials"; 
		pcFormAttr_ProdMatReqmin						="t1a41productionmaterials"; 
		pcFormAttr_StartProdmax							="t1a41startofproduction"; 
		pcFormAttr_StartProdmin							="t1a41startofproduction"; 
		pcFormAttr_EndProdmax							="t1a41endofproduction"; 
		pcFormAttr_EndProdmin							="t1a41endofproduction"; 


		tc_strcpy(acFormClassName,"t1a41CCR");
	}
	if (tc_strcasecmp(pcForm,"ccr2") == 0)
	{
	    pcFormAttr_PricingGuidance						="t8_t1a191pricingguidance";      
		pcFormAttr_SplCustCommerReq                     ="t8_t1a191specialcustomercom";
		pcFormAttr_LaborEcoYrmax						="t8_t1a191laboreconomicyear";
		pcFormAttr_LaborEcoYrmin						="t8_t1a191laboreconomicyear";
		pcFormAttr_Packaging							="t8_t1a191packaging"; 
		pcFormAttr_TypeofQuote							="t8_t1a191typeofquote"; 
		pcFormAttr_BillCompType							="t8_t1a191billablecompanytyp"; 
		pcFormAttr_BillComp								="t8_t1a191billablecompany";
		pcFormAttr_CostofChangeCur						="t8_t1a191currency"; 
		pcFormAttr_ScreeningReq							="t8_t1a191screeningrequired"; 
		pcFormAttr_CustAppReq							="t8_t1a191customerapprovalre"; 
		
		tc_strcpy(acFormClassName,"T8_t1a191CCR2");
	}

	//Create the main query
	iFail = POM_enquiry_create ("Find_change");

	//select output attribute for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "Item", 1, select_attr_list1));
	
	//craete alias
	TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
	
	//start query expression for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));

	/*Filter for Eng Change items only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_7", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

	/*Filter for Secondary object Relation Type i,e(IMAN_specification) only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","ImanRelation","relation_type",POM_enquiry_equal,"imantype","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcRelationTypeName, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_9", "imantype","type_name",POM_enquiry_equal ,"aunique_value_id2" ));

	/*Filter for CCR changes only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));

	/*Item ID*/
	if (tc_strcmp(pcItemID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcItemID, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_11","Item", "item_id",POM_enquiry_like,"aunique_value_id3"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_11",POM_case_insensitive));
	}
	/*Name*/
	if (strcmp (pcName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1,&pcName, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change","auniqueExprId_12","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id4"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_12",POM_case_insensitive));
	}
	/*Created after date*/		
	if (strcmp (pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCAD, &dCAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id5", 1, &dCAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id5"));	
	}
	/*Created before date*/
	if (strcmp (pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCBD, &dCBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id6", 1, &dCBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_14","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id6"));
	}	
	/*Modified after date*/
	if (strcmp (pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMAD, &dMAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id7", 1, &dMAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id7"));
	}
	/*Modified before date*/
	if (strcmp (pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMBD, &dMBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id8", 1, &dMBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id8"));
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_17","Pom_application_object","owning_user",POM_enquiry_equal,"user","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcOwningUser, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", "user","os_username",POM_enquiry_like ,"aunique_value_id9" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_19","Pom_application_object","owning_group",POM_enquiry_equal,"pom_group","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcOwningGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", "pom_group","name",POM_enquiry_like ,"aunique_value_id10" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		/*If Owning site & Logged in site are same*/
		if (strcmp (pcOwningSite ,"Local") == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_21","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22","pom_object","owning_site",POM_enquiry_is_null, NULL  ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_21","pom_object","owning_site",POM_enquiry_equal, "pom_imc", "puid"  ));		
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcOwningSite, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", "pom_imc","name",POM_enquiry_like ,"aunique_value_id11" ));
		}
	}
	/*Released after date*/
	if (strcmp (pcRAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRAD, &dRAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id12", 1, &dRAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_23","WorkspaceObject","date_released",POM_enquiry_greater_than_or_eq,"aunique_value_id12"));
	}
	/*Released before date*/
	if (strcmp (pcRBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRBD, &dRBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id13", 1, &dRBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_24","WorkspaceObject","date_released",POM_enquiry_less_than_or_eq,"aunique_value_id13"));
	}
	/*Release status*/
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_25","itemrevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcReleaseStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_26", "ReleaseStatus", "name",POM_enquiry_like ,"aunique_value_id14" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_27","itemrevision","process_stage_list",POM_enquiry_equal,"epmtask","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_28","epmtask","task_template",POM_enquiry_equal,"epmtasktemplate","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcCurrentTask, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_29", "epmtasktemplate", "template_name",POM_enquiry_like ,"aunique_value_id15"));
	}
	/*Pricing Guidance*/
	if ( (strcmp (pcPricingGuidance ,"") != 0) && (pcFormAttr_PricingGuidance != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcPricingGuidance, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_30", acFormClassName, pcFormAttr_PricingGuidance,POM_enquiry_like ,"aunique_value_id16" ));
	}
	/*Special Customer Commercial Requirements */
	if ( (strcmp (pcSplCustCommerReq ,"") != 0) && (pcFormAttr_SplCustCommerReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id17", 1, &pcSplCustCommerReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_31", acFormClassName, pcFormAttr_SplCustCommerReq,POM_enquiry_like ,"aunique_value_id17" ));
	}
	/*Labor Economic Year max*/
	if ( (strcmp (pcLaborEcoYrmax ,"") != 0) && (pcFormAttr_LaborEcoYrmax != NULL) )
	{
		iLaborEcoYrmax = atoi(pcLaborEcoYrmax);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_int_value ("Find_change", "aunique_value_id18", 1, &iLaborEcoYrmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_32", acFormClassName, pcFormAttr_LaborEcoYrmax,POM_enquiry_less_than_or_eq ,"aunique_value_id18" ));
	}
	/*Labor Economic Year min*/
	if ( (strcmp (pcLaborEcoYrmin ,"") != 0) && (pcFormAttr_LaborEcoYrmin != NULL) )
	{
		iLaborEcoYrmin = atoi(pcLaborEcoYrmin);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_int_value ("Find_change", "aunique_value_id19", 1, &iLaborEcoYrmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_33", acFormClassName,pcFormAttr_LaborEcoYrmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id19" ));
	}
	/*Packaging*/
	if ( (strcmp (pcPackaging ,"") != 0) && (pcFormAttr_Packaging != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id20", 1, &pcPackaging, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_34", acFormClassName, pcFormAttr_Packaging,POM_enquiry_like ,"aunique_value_id20" ));
	}
	/*Type of Quote*/
	if ( (strcmp (pcTypeofQuote ,"") != 0) && (pcFormAttr_TypeofQuote != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id21", 1, &pcTypeofQuote, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_35", acFormClassName, pcFormAttr_TypeofQuote,POM_enquiry_like ,"aunique_value_id21" ));
	}
	/*Billable Company Type */
	if ( (strcmp (pcBillCompType ,"") != 0) && (pcFormAttr_BillCompType != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id22", 1, &pcBillCompType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_36", acFormClassName, pcFormAttr_BillCompType,POM_enquiry_like ,"aunique_value_id22" ));
	}
	/*Billable Company*/
	if ( (strcmp (pcBillComp ,"") != 0) && (pcFormAttr_BillComp != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id23", 1, &pcBillComp, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_37", acFormClassName, pcFormAttr_BillComp,POM_enquiry_like ,"aunique_value_id23" ));
	}
	/*Customer Authorization Number*/
	if ( (strcmp (pcCustAuthorNum ,"") != 0) && (pcFormAttr_CustAuthorNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id24", 1, &pcCustAuthorNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_38", acFormClassName, pcFormAttr_CustAuthorNum,POM_enquiry_like ,"aunique_value_id24" ));
	}
	/*Customer Contact Name */
	if ( (strcmp (pcCustContName ,"") != 0) && (pcFormAttr_CustContName != NULL) )
	{	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id25", 1, &pcCustContName, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_39", acFormClassName, pcFormAttr_CustContName,POM_enquiry_like ,"aunique_value_id25" ));
	}
	/*Customer Contact Email */
	if ( (strcmp (pcCustContEmail ,"") != 0) && (pcFormAttr_CustContEmail != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id26", 1, &pcCustContEmail, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_40", acFormClassName, pcFormAttr_CustContEmail,POM_enquiry_like ,"aunique_value_id26" ));
	}
	/*Customer Contact Phone */
	if ( (strcmp (pcCustPhone ,"") != 0) && (pcFormAttr_CustPhone != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id27", 1, &pcCustPhone, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_41", acFormClassName, pcFormAttr_CustPhone,POM_enquiry_like ,"aunique_value_id27" ));
	}
	/*Estimate Number */
	if ( (strcmp (pcEstNum ,"") != 0) && (pcFormAttr_EstNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id28", 1, &pcEstNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_42", acFormClassName, pcFormAttr_EstNum,POM_enquiry_like ,"aunique_value_id28" ));
	}
	/*Variance Estimate Number */
	if ( (strcmp (pcVarEstNum ,"") != 0) && (pcFormAttr_VarEstNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id29", 1, &pcVarEstNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_43", acFormClassName, pcFormAttr_VarEstNum,POM_enquiry_like ,"aunique_value_id29" ));
	}
	/*Cost of Change Currency */
	if ( (strcmp (pcCostofChangeCur ,"") != 0) && (pcFormAttr_CostofChangeCur != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id30", 1, &pcCostofChangeCur, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_44", acFormClassName, pcFormAttr_CostofChangeCur,POM_enquiry_like ,"aunique_value_id30" ));
	}
	/*Costof Change Tooling Cost max */
	if ( (strcmp (pcToolCostmax ,"") != 0) && (pcFormAttr_ToolCostmax != NULL) )
	{
	    dToolCostmax = atof(pcToolCostmax);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id31", 1, &dToolCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_45", acFormClassName, pcFormAttr_ToolCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id31" ));
	}
	/*Cost of Change Tooling Costmin*/
	if ( (strcmp (pcToolCostmin ,"") != 0) && (pcFormAttr_ToolCostmin != NULL) )
	{
	    dToolCostmin = atof(pcToolCostmin);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id32", 1, &dToolCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_46", acFormClassName, pcFormAttr_ToolCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id32" ));
	}
	/*Cost of Change Customer Paid Tooling max*/
	if ( (strcmp (pcCustPaidToolmax ,"") != 0) && (pcFormAttr_CustPaidToolmax != NULL) )
	{
	    dCustPaidToolmax = atof(pcCustPaidToolmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id33", 1, &dCustPaidToolmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_47", acFormClassName, pcFormAttr_CustPaidToolmax,POM_enquiry_less_than_or_eq ,"aunique_value_id33" ));
	}
	/*Cost of Change Customer Paid Tooling min*/
	if ((strcmp(pcCustPaidToolmin ,"") != 0) && (pcFormAttr_CustPaidToolmin != NULL) )
	{
	    dCustPaidToolmin = atof(pcCustPaidToolmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id34", 1, &dCustPaidToolmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_48", acFormClassName, pcFormAttr_CustPaidToolmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id34" ));
	}
	/*Cost of Change Purchased Parts ExWorks Costmax*/
	if ((strcmp (pcPurExWorkCostmax ,"") != 0) && (pcFormAttr_PurExWorkCostmax != NULL) )
	{
	    dPurExWorkCostmax = atof(pcPurExWorkCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id35", 1, &dPurExWorkCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_49",acFormClassName, pcFormAttr_PurExWorkCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id35" ));
	}
	/*Cost of Change Purchased Parts ExWorks Cost min*/
	if ((strcmp (pcPurExWorkCostmin ,"") != 0) && (pcFormAttr_PurExWorkCostmin != NULL) )
	{
	    dPurExWorkCostmin = atof(pcPurExWorkCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id36", 1, &dPurExWorkCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_50",acFormClassName, pcFormAttr_PurExWorkCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id36" ));
	}
	/*Cost of Change Purchased Parts Delivered Duty Paid Cost max*/
	if ( (strcmp (pcPurDelDutyPaidCostmax ,"") != 0) && (pcFormAttr_PurDelDutyPaidCostmax != NULL) )
	{
	    dPurDelDutyPaidCostmax = atof(pcPurDelDutyPaidCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id37", 1, &dPurDelDutyPaidCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_51", acFormClassName, pcFormAttr_PurDelDutyPaidCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id37" ));
	}
	/*Cost of Change Purchased Parts Delivered Duty Paid Cost min*/
	if ( (strcmp (pcPurDelDutyPaidCostmin ,"") != 0) && (pcFormAttr_PurDelDutyPaidCostmin != NULL) )
	{
	    dPurDelDutyPaidCostmin = atof(pcPurDelDutyPaidCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id38", 1, &dPurDelDutyPaidCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_52", acFormClassName, pcFormAttr_PurDelDutyPaidCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id38" ));
	}
	/*Cost of Change Logistics Cost max*/
	if ( (strcmp (pcLogisCostmax  ,"") != 0) && (pcFormAttr_LogisCostmax != NULL) )
	{
	    dLogisCostmax = atof(pcLogisCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id39", 1, &dLogisCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_53", acFormClassName, pcFormAttr_LogisCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id39" ));
	}
	/*Cost of Change Logistics Cost min*/
	if ( (strcmp (pcLogisCostmin ,"") != 0) && (pcFormAttr_LogisCostmin != NULL) )
	{
	    dLogisCostmin = atof(pcLogisCostmin);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id40", 1, &dLogisCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_54", acFormClassName, pcFormAttr_LogisCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id40" ));
	}
	/*Costof Change Manufactured Parts Labor Cost max*/
	if ( (strcmp (pcMfgLaborCostmax ,"") != 0) && (pcFormAttr_MfgLaborCostmax != NULL) )
	{
	    dMfgLaborCostmax = atof(pcMfgLaborCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id41", 1, &dMfgLaborCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_55", acFormClassName, pcFormAttr_MfgLaborCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id41" ));
	}
	/*Costof Change Manufactured Parts Labor Cost min*/
	if ( (strcmp (pcMfgLaborCostmin ,"") != 0) && (pcFormAttr_MfgLaborCostmin != NULL) )
	{
	    dMfgLaborCostmin = atof(pcMfgLaborCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id42", 1, &dMfgLaborCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_56", acFormClassName, pcFormAttr_MfgLaborCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id42" ));
	}
	/*Costof Change Materials Cost max*/
	if ( (strcmp (pcMatCostmax ,"") != 0) && (pcFormAttr_MatCostmax != NULL) )
	{
	    dMatCostmax = atof(pcMatCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id43", 1, &dMatCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_57", acFormClassName, pcFormAttr_MatCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id43" ));
	}
	/*Cost of Change Materials Cost min*/
	if ( (strcmp (pcMatCostmin ,"") != 0) && (pcFormAttr_MatCostmin != NULL) )
	{
	    dMatCostmin = atof(pcMatCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id44", 1, &dMatCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_58", acFormClassName, pcFormAttr_MatCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id44" ));
	}
	/*Cost of Change Manufactured Parts Variable Overhead Costmax*/
	if ( (strcmp (pcMfgVarCostmax ,"") != 0) && (pcFormAttr_MfgVarCostmax != NULL) )
	{
	    dMfgVarCostmax = atof(pcMfgVarCostmax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id45", 1, &dMfgVarCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_59", acFormClassName, pcFormAttr_MfgVarCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id45" ));
	}
	/*Cost of Change Manufactured Parts Variable Overhead Cost min*/
	if ( (strcmp (pcMfgVarCostmin ,"") != 0) && (pcFormAttr_MfgVarCostmin != NULL) )
	{
	    dMfgVarCostmin = atof(pcMfgVarCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id46", 1, &dMfgVarCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_60", acFormClassName, pcFormAttr_MfgVarCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id46" ));
	}
	/*Cost of Change Manufactured Parts Scrap Percentage max*/
	if ( (strcmp (pcMfgScrapPermax ,"") != 0) && (pcFormAttr_MfgScrapPermax != NULL) )
	{
	    dMfgScrapPermax = atof(pcMfgScrapPermax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id47", 1, &dMfgScrapPermax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_61", acFormClassName, pcFormAttr_MfgScrapPermax,POM_enquiry_less_than_or_eq ,"aunique_value_id47" ));
	}
	/*Cost of Change Manufactured Parts Scrap Percentagemin*/
	if ( (strcmp (pcMfgScrapPermin ,"") != 0) && (pcFormAttr_MfgScrapPermin != NULL) )
	{
	    dMfgScrapPermin = atof(pcMfgScrapPermin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id48", 1, &dMfgScrapPermin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_62", acFormClassName, pcFormAttr_MfgScrapPermin,POM_enquiry_greater_than_or_eq ,"aunique_value_id48" ));
	}
	/*Cost of Change Total Variable Cost max*/
	if ( (strcmp (pcTotalVarCostmax ,"") != 0) && (pcFormAttr_TotalVarCostmax != NULL) )
	{
	    dTotalVarCostmax = atof(pcTotalVarCostmax);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id49", 1, &dTotalVarCostmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_63", acFormClassName, pcFormAttr_TotalVarCostmax,POM_enquiry_less_than_or_eq ,"aunique_value_id49" ));
	}
	/*Cost of Change Total Variable Cost min*/
	if ( (strcmp (pcTotalVarCostmin ,"") != 0) && (pcFormAttr_TotalVarCostmin != NULL) )
	{
	    dTotalVarCostmin = atof(pcTotalVarCostmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id50", 1, &dTotalVarCostmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_64", acFormClassName, pcFormAttr_TotalVarCostmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id50" ));
	}
	/*Cost of Change Manufactured Parts Selling Transfer Price max*/
	if ( (strcmp (pcMfgSellingTransPricemax ,"") != 0) && (pcFormAttr_MfgSellingTransPricemax != NULL) )
	{
	    dMfgSellingTransPricemax = atof(pcMfgSellingTransPricemax);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id51", 1, &dMfgSellingTransPricemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_65", acFormClassName, pcFormAttr_MfgSellingTransPricemax,POM_enquiry_less_than_or_eq ,"aunique_value_id51" ));
	}
	/*Cost of Change Manufactured Parts Selling Transfer Pricemin*/
	if ( (strcmp (pcMfgSellingTransPricemin ,"") != 0) && (pcFormAttr_MfgSellingTransPricemin != NULL) )
	{
	    dMfgSellingTransPricemin = atof(pcMfgSellingTransPricemin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id52", 1, &dMfgSellingTransPricemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_66", acFormClassName, pcFormAttr_MfgSellingTransPricemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id52" ));
	}
	/*Cost of Change TIMarkup max*/
	if ( (strcmp (pcTIMarkupUnitCurrmax ,"") != 0) && (pcFormAttr_TIMarkupUnitCurrmax != NULL) )
	{
	    dTIMarkupUnitCurrmax = atof(pcTIMarkupUnitCurrmax);
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id53", 1, &dTIMarkupUnitCurrmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_67", acFormClassName, pcFormAttr_TIMarkupUnitCurrmax,POM_enquiry_less_than_or_eq ,"aunique_value_id53" ));
	}
	/*Cost of Change TIMarkup min*/ 
	if ( (strcmp (pcTIMarkupUnitCurrmin ,"") != 0) && (pcFormAttr_TIMarkupUnitCurrmin != NULL) )
	{
	    dTIMarkupUnitCurrmin = atof(pcTIMarkupUnitCurrmin);	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_double_value ("Find_change", "aunique_value_id54", 1, &dTIMarkupUnitCurrmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_68", acFormClassName, pcFormAttr_TIMarkupUnitCurrmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id54" ));
	}
	/*Screening Required*/
	if ( (strcmp (pcScreeningReq ,"") != 0) && (pcFormAttr_ScreeningReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id55", 1, &pcScreeningReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_69", acFormClassName, pcFormAttr_ScreeningReq,POM_enquiry_like ,"aunique_value_id55" ));
	}
	/*Customer Approval Required*/ 
	if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id56", 1, &pcCustAppReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_70", acFormClassName, pcFormAttr_CustAppReq,POM_enquiry_like ,"aunique_value_id56" ));
	}
	/*Customer Approval Type*/
	if ( (strcmp (pcCustAppType ,"") != 0) && (pcFormAttr_CustAppType != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id57", 1, &pcCustAppType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_71", acFormClassName, pcFormAttr_CustAppType,POM_enquiry_like ,"aunique_value_id57" ));
	}
	/*RFQIssuedmax date*/
	if ( (strcmp (pcRFQIssuemax ,"") != 0) && (pcFormAttr_RFQIssuemax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuemax, &dRFQIssuemax));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id58", 1, &dRFQIssuemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_72", acFormClassName, pcFormAttr_RFQIssuemax,POM_enquiry_less_than_or_eq ,"aunique_value_id58" ));
	}
	/*RFQ Issued min date*/ 
	if ( (strcmp (pcRFQIssuemin ,"") != 0) && (pcFormAttr_RFQIssuemin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuemin, &dRFQIssuemin));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id59", 1, &dRFQIssuemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_73", acFormClassName, pcFormAttr_RFQIssuemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id59" ));
	}
	/*RFQ Customer Duemax date*/
	if ( (strcmp (pcRFQCustDuemax ,"") != 0) && (pcFormAttr_RFQCustDuemax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQCustDuemax, &dRFQCustDuemax));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id60", 1, &dRFQCustDuemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_74", acFormClassName, pcFormAttr_RFQCustDuemax,POM_enquiry_less_than_or_eq ,"aunique_value_id60" ));
	}
	/*RFQ Customer Due min date*/
	if ( (strcmp (pcRFQCustDuemin ,"") != 0) && (pcFormAttr_RFQCustDuemin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQCustDuemin, &dRFQCustDuemin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id61", 1, &dRFQCustDuemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_75", acFormClassName, pcFormAttr_RFQCustDuemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id61" ));
	}
	/*Prototype Due max date*/ 
	if ( (strcmp (pcProtoDuemax ,"") != 0) && (pcFormAttr_ProtoDuemax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProtoDuemax, &dProtoDuemax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id62", 1, &dProtoDuemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_76", acFormClassName, pcFormAttr_ProtoDuemax,POM_enquiry_less_than_or_eq ,"aunique_value_id62" ));
	}
	/*Prototype Due min date*/
	if ( (strcmp (pcProtoDuemin ,"") != 0) && (pcFormAttr_ProtoDuemin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProtoDuemin, &dProtoDuemin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id63", 1, &dProtoDuemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_77", acFormClassName, pcFormAttr_ProtoDuemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id63" ));
	}
	/*Prototype Quality Signoff max date*/ 
	if ( (strcmp (pcProtoQltSignmax  ,"") != 0) && (pcFormAttr_ProtoQltSignmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProtoQltSignmax, &dProtoQltSignmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id64", 1, &dProtoQltSignmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_78", acFormClassName, pcFormAttr_ProtoQltSignmax,POM_enquiry_less_than_or_eq ,"aunique_value_id64" ));
	}
	/*Prototype Quality Signoff min date*/ 
	if ( (strcmp (pcProtoQltSignmin ,"") != 0) && (pcFormAttr_ProtoQltSignmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProtoQltSignmin, &dProtoQltSignmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id65", 1, &dProtoQltSignmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_79", acFormClassName, pcFormAttr_ProtoQltSignmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id65" ));
	}
	/*Design Validation Due max date*/ 
	if ( (strcmp (pcDesignValDuemax ,"") != 0) && (pcFormAttr_DesignValDuemax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcDesignValDuemax, &dDesignValDuemax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id66", 1, &dDesignValDuemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_80", acFormClassName, pcFormAttr_DesignValDuemax,POM_enquiry_less_than_or_eq ,"aunique_value_id66" ));
	}
	/*Design Validation Duemin date*/
	if ( (strcmp (pcDesignValDuemin ,"") != 0) && (pcFormAttr_DesignValDuemin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcDesignValDuemin, &dDesignValDuemin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id67", 1, &dDesignValDuemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_81", acFormClassName, pcFormAttr_DesignValDuemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id67" ));
	}
	/*PPAP Required*/ 
	if ( (strcmp (pcPPAPReq ,"") != 0) && (pcFormAttr_PPAPReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id68", 1, &pcPPAPReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_82", acFormClassName, pcFormAttr_PPAPReq,POM_enquiry_like ,"aunique_value_id68" ));
	}
	/*Target PPAP Level*/
	if ( (strcmp (pcTarPPAPLevel ,"") != 0) && (pcFormAttr_TarPPAPLevel != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id69", 1, &pcTarPPAPLevel, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_83", acFormClassName, pcFormAttr_TarPPAPLevel,POM_enquiry_like ,"aunique_value_id69" ));
	}
	/*Critical Path Item*/
	if ( (strcmp (pcCritPathItem ,"") != 0) && (pcFormAttr_CritPathItem != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id70", 1, &pcCritPathItem, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_84", acFormClassName, pcCritPathItem, POM_enquiry_like ,"aunique_value_id70" ));
	}
	/*Critical Path Item PPAP Signoff max date*/
	if ( (strcmp (pcCriPathItemPPAPmax ,"") != 0) && (pcFormAttr_CriPathItemPPAPmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCriPathItemPPAPmax, &dCriPathItemPPAPmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id71", 1, &dCriPathItemPPAPmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_85", acFormClassName, pcFormAttr_CriPathItemPPAPmax,POM_enquiry_less_than_or_eq ,"aunique_value_id71" ));
	}
	/*Critical Path ItemPPAP Signoff min date*/
	if ( (strcmp (pcCriPathItemPPAPmin ,"") != 0) && (pcFormAttr_CriPathItemPPAPmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCriPathItemPPAPmin, &dCriPathItemPPAPmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id72", 1, &dCriPathItemPPAPmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_86", acFormClassName, pcFormAttr_CriPathItemPPAPmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id72" ));
	}
	/*PPAP Build Event max date*/
	if ( (strcmp (pcPPAPBuildEvemax ,"") != 0) && (pcFormAttr_PPAPBuildEvemax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcPPAPBuildEvemax, &dPPAPBuildEvemax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id73", 1, &dPPAPBuildEvemax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_87", acFormClassName, pcFormAttr_PPAPBuildEvemax,POM_enquiry_less_than_or_eq ,"aunique_value_id73" ));
	}
	/*PPAP Build Event min date*/
	if ( (strcmp (pcPPAPBuildEvemin ,"") != 0) && (pcFormAttr_PPAPBuildEvemin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcPPAPBuildEvemin, &dPPAPBuildEvemin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id74", 1, &dPPAPBuildEvemin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_88", acFormClassName, pcFormAttr_PPAPBuildEvemin,POM_enquiry_greater_than_or_eq ,"aunique_value_id74" ));
	}
	/*Process Validation Signoff max date*/
	if ( (strcmp (pcProValSignmax ,"") != 0) && (pcFormAttr_ProValSignmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProValSignmax, &dProValSignmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id75", 1, &dProValSignmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_89", acFormClassName, pcFormAttr_ProValSignmax,POM_enquiry_less_than_or_eq ,"aunique_value_id75" ));
	}
	/*Process Validation Signoff min date*/ 
	if ( (strcmp (pcProValSignmin ,"") != 0) && (pcFormAttr_ProValSignmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProValSignmin, &dProValSignmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id76", 1, &dProValSignmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_90", acFormClassName, pcFormAttr_ProValSignmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id76" ));
	}
	/*RunatRate Signoff max date*/ 
	if ( (strcmp (pcRunRateSignmax ,"") != 0) && (pcFormAttr_RunRateSignmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRunRateSignmax, &dRunRateSignmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id77", 1, &dRunRateSignmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_91", acFormClassName, pcFormAttr_RunRateSignmax,POM_enquiry_less_than_or_eq ,"aunique_value_id77" ));
	}
	/*RunatRate Signoff min date*/ 
	if ( (strcmp (pcRunRateSignmin ,"") != 0) && (pcFormAttr_RunRateSignmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRunRateSignmin, &dRunRateSignmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id78", 1, &dRunRateSignmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_92", acFormClassName, pcFormAttr_RunRateSignmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id78" ));
	}
	/*PPAP Signoff max date*/ 
	if ( (strcmp (pcPPAPSignmax ,"") != 0) && (pcFormAttr_PPAPSignmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcPPAPSignmax, &dPPAPSignmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id79", 1, &dPPAPSignmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_93", acFormClassName, pcFormAttr_PPAPSignmax,POM_enquiry_less_than_or_eq ,"aunique_value_id79" ));
	}
	/*PPAP Signoff min date*/
	if ( (strcmp (pcPPAPSignmin ,"") != 0) && (pcFormAttr_PPAPSignmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcPPAPSignmin, &dPPAPSignmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id80", 1, &dPPAPSignmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_94", acFormClassName, pcFormAttr_PPAPSignmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id80" ));
	}
	/*Process Signoff max date*/ 
	if ( (strcmp (pcProSignmax ,"") != 0) && (pcFormAttr_ProSignmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProSignmax, &dProSignmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id81", 1, &dProSignmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_95", acFormClassName, pcFormAttr_ProSignmax,POM_enquiry_less_than_or_eq ,"aunique_value_id81" ));
	}
	/*Process Signoff min date*/
	if ( (strcmp (pcProSignmin ,"") != 0) && (pcFormAttr_ProSignmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProSignmin, &dProSignmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id82", 1, &dProSignmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_96", acFormClassName, pcFormAttr_ProSignmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id82" ));
	}
	/*Production Materials Required max date*/
	if ( (strcmp (pcProdMatReqmax ,"") != 0) && (pcFormAttr_ProdMatReqmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProdMatReqmax, &dProdMatReqmax));		
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id83", 1, &dProdMatReqmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_97", acFormClassName, pcFormAttr_ProdMatReqmax,POM_enquiry_less_than_or_eq ,"aunique_value_id83" ));
	}
	/*Production Materials Required min date*/
	if ( (strcmp (pcProdMatReqmin ,"") != 0) && (pcFormAttr_ProdMatReqmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcProdMatReqmin, &dProdMatReqmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id84", 1, &dProdMatReqmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_98", acFormClassName, pcFormAttr_ProdMatReqmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id84" ));
	}
	/*Start of Production max date*/
	if ( (strcmp (pcStartProdmax ,"") != 0) && (pcFormAttr_StartProdmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcStartProdmax, &dStartProdmax));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id85", 1, &dStartProdmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_99", acFormClassName, pcFormAttr_StartProdmax,POM_enquiry_less_than_or_eq ,"aunique_value_id85" ));
	}
	/*Start of Production min date*/ 
	if ( (strcmp (pcStartProdmin ,"") != 0) && (pcFormAttr_StartProdmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcStartProdmin, &dStartProdmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id86", 1, &dStartProdmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_100", acFormClassName, pcFormAttr_StartProdmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id86" ));
	}
	/*End of Production max date*/ 
	if ( (strcmp (pcEndProdmax ,"") != 0) && (pcFormAttr_EndProdmax != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcEndProdmax, &dEndProdmax));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id87", 1, &dEndProdmax, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_101", acFormClassName, pcFormAttr_EndProdmax,POM_enquiry_less_than_or_eq ,"aunique_value_id87" ));
	}
	/*End of Production min date*/
	if ( (strcmp (pcEndProdmin ,"") != 0) && (pcFormAttr_EndProdmin != NULL) )
	{
	    TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcEndProdmin, &dEndProdmin));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id88", 1, &dEndProdmin, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_102", acFormClassName, pcFormAttr_EndProdmin,POM_enquiry_greater_than_or_eq ,"aunique_value_id88" ));
	}

	//join the expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_103","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_104","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_3" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_105","auniqueExprId_104",POM_enquiry_and, "auniqueExprId_4" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_106","auniqueExprId_105",POM_enquiry_and, "auniqueExprId_5" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_107","auniqueExprId_106",POM_enquiry_and, "auniqueExprId_6" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_108","auniqueExprId_107",POM_enquiry_and, "auniqueExprId_7" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_109","auniqueExprId_108",POM_enquiry_and, "auniqueExprId_8" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_110","auniqueExprId_109",POM_enquiry_and, "auniqueExprId_9" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_111","auniqueExprId_110",POM_enquiry_and, "auniqueExprId_10" ));
	
	/*Item ID*/
	if (tc_strcmp(pcItemID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_11" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Name*/
	if (tc_strcmp(pcName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_113","auniqueExprId_112",POM_enquiry_and, "auniqueExprId_12" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_113","auniqueExprId_112",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created after date*/		
	if (tc_strcmp(pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_114","auniqueExprId_113",POM_enquiry_and, "auniqueExprId_13" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_114","auniqueExprId_113",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created before date*/
	if (tc_strcmp(pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_115","auniqueExprId_114",POM_enquiry_and, "auniqueExprId_14" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_115","auniqueExprId_114",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified after date*/
	if (tc_strcmp(pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_116","auniqueExprId_115",POM_enquiry_and, "auniqueExprId_15" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_116","auniqueExprId_115",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified before date*/
	if (tc_strcmp(pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_117","auniqueExprId_116",POM_enquiry_and, "auniqueExprId_16" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_117","auniqueExprId_116",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_118","auniqueExprId_117",POM_enquiry_and, "auniqueExprId_17" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_119","auniqueExprId_118",POM_enquiry_and, "auniqueExprId_18" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_119","auniqueExprId_117",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_120","auniqueExprId_119",POM_enquiry_and, "auniqueExprId_19" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_121","auniqueExprId_120",POM_enquiry_and, "auniqueExprId_20" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_121","auniqueExprId_119",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_122","auniqueExprId_121",POM_enquiry_and, "auniqueExprId_21" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_123","auniqueExprId_122",POM_enquiry_and, "auniqueExprId_22" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_123","auniqueExprId_121",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Released after date*/
	if (tc_strcmp(pcRAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_124","auniqueExprId_123",POM_enquiry_and, "auniqueExprId_23" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_124","auniqueExprId_123",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Released before date*/
	if (tc_strcmp(pcRBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_125","auniqueExprId_124",POM_enquiry_and, "auniqueExprId_24" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_125","auniqueExprId_124",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_126","auniqueExprId_125",POM_enquiry_and, "auniqueExprId_25" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_127","auniqueExprId_126",POM_enquiry_and, "auniqueExprId_26" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_127","auniqueExprId_125",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_128","auniqueExprId_127",POM_enquiry_and, "auniqueExprId_27" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_129","auniqueExprId_128",POM_enquiry_and, "auniqueExprId_28" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_130","auniqueExprId_129",POM_enquiry_and, "auniqueExprId_29" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_130","auniqueExprId_127",POM_enquiry_and, "auniqueExprId_1" ));
	}
	
	/*Pricing Guidance*/
	if ( (strcmp (pcPricingGuidance ,"") != 0) && (pcFormAttr_PricingGuidance != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_131","auniqueExprId_130",POM_enquiry_and, "auniqueExprId_30" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_131","auniqueExprId_130",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Special Customer Commercial Requirements */
	if ( (strcmp (pcSplCustCommerReq ,"") != 0) && (pcFormAttr_SplCustCommerReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_132","auniqueExprId_131",POM_enquiry_and, "auniqueExprId_31" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_132","auniqueExprId_131",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Labor Economic Year max*/
	if ( (strcmp (pcLaborEcoYrmax ,"") != 0) && (pcFormAttr_LaborEcoYrmax != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_133","auniqueExprId_132",POM_enquiry_and, "auniqueExprId_32" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_133","auniqueExprId_132",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Labor Economic Year min*/
	if ( (strcmp (pcLaborEcoYrmin ,"") != 0) && (pcLaborEcoYrmin != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_134","auniqueExprId_133",POM_enquiry_and, "auniqueExprId_33" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_134","auniqueExprId_133",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Packaging*/
	if ( (strcmp (pcPackaging ,"") != 0) && (pcFormAttr_Packaging != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_135","auniqueExprId_134",POM_enquiry_and, "auniqueExprId_34" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_135","auniqueExprId_134",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Type of Quote*/
	if ( (strcmp (pcTypeofQuote ,"") != 0) && (pcFormAttr_TypeofQuote != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_136","auniqueExprId_135",POM_enquiry_and, "auniqueExprId_35" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_136","auniqueExprId_135",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Billable Company Type */
	if ( (strcmp (pcBillCompType ,"") != 0) && (pcFormAttr_BillCompType != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_137","auniqueExprId_136",POM_enquiry_and, "auniqueExprId_36" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_137","auniqueExprId_136",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Billable Company */
	if ( (strcmp (pcBillComp ,"") != 0) && (pcFormAttr_BillComp != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_138","auniqueExprId_137",POM_enquiry_and, "auniqueExprId_37" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_138","auniqueExprId_137",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Authorization Number */
	if ( (strcmp (pcCustAuthorNum ,"") != 0) && (pcCustAuthorNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_139","auniqueExprId_138",POM_enquiry_and, "auniqueExprId_38" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_139","auniqueExprId_138",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Contact Name */
	if ( (strcmp (pcCustContName ,"") != 0) && (pcFormAttr_CustContName != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_140","auniqueExprId_139",POM_enquiry_and, "auniqueExprId_39" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_140","auniqueExprId_139",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Contact Email */
	if ( (strcmp (pcCustContEmail ,"") != 0) && (pcFormAttr_CustContEmail != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_141","auniqueExprId_140",POM_enquiry_and, "auniqueExprId_40" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_141","auniqueExprId_140",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Contact Phone */
	if ( (strcmp (pcCustPhone ,"") != 0) && (pcFormAttr_CustPhone != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_142","auniqueExprId_141",POM_enquiry_and, "auniqueExprId_41" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_142","auniqueExprId_141",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Estimate Number */
	if ( (strcmp (pcEstNum ,"") != 0) && (pcFormAttr_EstNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_143","auniqueExprId_142",POM_enquiry_and, "auniqueExprId_42" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_143","auniqueExprId_142",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Variance Estimate Number */
	if ( (strcmp (pcVarEstNum ,"") != 0) && (pcFormAttr_VarEstNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_144","auniqueExprId_143",POM_enquiry_and, "auniqueExprId_43" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_144","auniqueExprId_143",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Currency */
	if ( (strcmp (pcCostofChangeCur ,"") != 0) && (pcFormAttr_CostofChangeCur != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_145","auniqueExprId_144",POM_enquiry_and, "auniqueExprId_44" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_145","auniqueExprId_144",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Tooling Cost max */
	if ( (strcmp (pcToolCostmax ,"") != 0) && (pcFormAttr_ToolCostmax != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_146","auniqueExprId_145",POM_enquiry_and, "auniqueExprId_45" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_146","auniqueExprId_145",POM_enquiry_and, "auniqueExprId_1" ));
	}
	
	/*Cost of Change Tooling Cost min*/
	if ( (strcmp (pcToolCostmin ,"") != 0) && (pcFormAttr_ToolCostmin != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_147","auniqueExprId_146",POM_enquiry_and, "auniqueExprId_46" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_147","auniqueExprId_146",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Customer Paid Tooling max */
	if ( (strcmp (pcCustPaidToolmax,"") != 0) && (pcFormAttr_CustPaidToolmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_148","auniqueExprId_147",POM_enquiry_and, "auniqueExprId_47" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_148","auniqueExprId_147",POM_enquiry_and, "auniqueExprId_1" ));
	}

	/*Costof Change Customer Paid Tooling min*/
	if ((strcmp(pcCustPaidToolmin,"") != 0) && (pcFormAttr_CustPaidToolmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_149","auniqueExprId_148",POM_enquiry_and, "auniqueExprId_48" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_149","auniqueExprId_148",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Purchased Parts ExWorks Cost max*/		
	if ((strcmp(pcPurExWorkCostmax,"") != 0) && (pcFormAttr_PurExWorkCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_150","auniqueExprId_149",POM_enquiry_and, "auniqueExprId_49" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_150","auniqueExprId_149",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Purchased Parts ExWorks Costmin */		
	if ((strcmp(pcPurExWorkCostmin,"") != 0) && (pcFormAttr_PurExWorkCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_151","auniqueExprId_150",POM_enquiry_and, "auniqueExprId_50" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_151","auniqueExprId_150",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Purchased Parts Delivered Duty Paid Costmax  */		
	if ((strcmp(pcPurDelDutyPaidCostmax,"") != 0) && (pcFormAttr_PurDelDutyPaidCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_152","auniqueExprId_151",POM_enquiry_and, "auniqueExprId_51" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_152","auniqueExprId_151",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Purchased Parts Delivered Duty Paid Cost min  */		
	if ((strcmp(pcPurDelDutyPaidCostmin,"") != 0) && (pcFormAttr_PurDelDutyPaidCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_153","auniqueExprId_152",POM_enquiry_and, "auniqueExprId_52" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_153","auniqueExprId_152",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Logistics Cost max  */		
	if ((strcmp(pcLogisCostmax ,"") != 0) && (pcFormAttr_LogisCostmax != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_154","auniqueExprId_153",POM_enquiry_and, "auniqueExprId_53" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_154","auniqueExprId_153",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Logistics Cost min */		
	if ((strcmp(pcLogisCostmin,"") != 0) && (pcFormAttr_LogisCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_155","auniqueExprId_154",POM_enquiry_and, "auniqueExprId_54" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_155","auniqueExprId_154",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Manufactured Parts Labor Cost max  */		
	if ((strcmp(pcMfgLaborCostmax,"") != 0) && (pcFormAttr_MfgLaborCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_156","auniqueExprId_155",POM_enquiry_and, "auniqueExprId_55" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_156","auniqueExprId_155",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Manufactured Parts Labor Cost min */		
	if ((strcmp(pcMfgLaborCostmin,"") != 0) && (pcFormAttr_MfgLaborCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_157","auniqueExprId_156",POM_enquiry_and, "auniqueExprId_56" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_157","auniqueExprId_156",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Materials Cost max  */		
	if ((strcmp(pcMatCostmax,"") != 0) && (pcFormAttr_MatCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_158","auniqueExprId_157",POM_enquiry_and, "auniqueExprId_57" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_158","auniqueExprId_157",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Materials Costmin */		
	if ((strcmp(pcMatCostmin,"") != 0) && (pcFormAttr_MatCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_159","auniqueExprId_158",POM_enquiry_and, "auniqueExprId_58" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_159","auniqueExprId_158",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Manufactured Parts Variable Overhead Costmax */		
	if ((strcmp(pcMfgVarCostmax,"") != 0) && (pcFormAttr_MfgVarCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_160","auniqueExprId_159",POM_enquiry_and, "auniqueExprId_59" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_160","auniqueExprId_159",POM_enquiry_and, "auniqueExprId_1" ));
	}
		/*Cost of Change Manufactured Parts Variable Overhead Costmin */		
	if ((strcmp(pcMfgVarCostmin,"") != 0) && (pcFormAttr_MfgVarCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_161","auniqueExprId_160",POM_enquiry_and, "auniqueExprId_60" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_161","auniqueExprId_160",POM_enquiry_and, "auniqueExprId_1" ));
	}
		/*Cost of Change Manufactured Parts Scrap Percentage max  */		
	if ((strcmp(pcMfgScrapPermax,"") != 0) && (pcFormAttr_MfgScrapPermax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_162","auniqueExprId_161",POM_enquiry_and, "auniqueExprId_61" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_162","auniqueExprId_161",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Manufactured Parts Scrap Percentage min */		
	if ((strcmp(pcMfgScrapPermin,"") != 0) && (pcFormAttr_MfgScrapPermin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_163","auniqueExprId_162",POM_enquiry_and, "auniqueExprId_62" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_163","auniqueExprId_162",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Total Variable Cost max  */		
	if ((strcmp(pcTotalVarCostmax,"") != 0) && (pcFormAttr_TotalVarCostmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_164","auniqueExprId_163",POM_enquiry_and, "auniqueExprId_63" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_164","auniqueExprId_163",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Total Variable Cost min  */		
	if ((strcmp(pcTotalVarCostmin,"") != 0) && (pcFormAttr_TotalVarCostmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_165","auniqueExprId_164",POM_enquiry_and, "auniqueExprId_64" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_165","auniqueExprId_164",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Cost of Change Manufactured Parts Selling Transfer Price max */		
	if ((strcmp(pcMfgSellingTransPricemax,"") != 0) && (pcFormAttr_MfgSellingTransPricemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_166","auniqueExprId_165",POM_enquiry_and, "auniqueExprId_65" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_166","auniqueExprId_165",POM_enquiry_and, "auniqueExprId_1" ));
	}/*Cost of Change Manufactured Parts Selling Transfer Pricemin */		
	if ((strcmp(pcMfgSellingTransPricemin,"") != 0) && (pcFormAttr_MfgSellingTransPricemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_167","auniqueExprId_166",POM_enquiry_and, "auniqueExprId_66" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_167","auniqueExprId_166",POM_enquiry_and, "auniqueExprId_1" ));
	}
		/*Cost of Change TIMarkup max  */		
	if ((strcmp(pcTIMarkupUnitCurrmax,"") != 0) && (pcFormAttr_TIMarkupUnitCurrmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_168","auniqueExprId_167",POM_enquiry_and, "auniqueExprId_67" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_168","auniqueExprId_167",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*CostofChange TIMarkup min */		
	if ((strcmp(pcTIMarkupUnitCurrmin,"") != 0) && (pcFormAttr_TIMarkupUnitCurrmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_169","auniqueExprId_168",POM_enquiry_and, "auniqueExprId_68" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_169","auniqueExprId_168",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Screening Required  */		
	if ((strcmp(pcScreeningReq,"") != 0) && (pcFormAttr_ScreeningReq!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_170","auniqueExprId_169",POM_enquiry_and, "auniqueExprId_69" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_170","auniqueExprId_169",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Approval Required  */		
	if ((strcmp(pcCustAppReq,"") != 0) && (pcFormAttr_CustAppReq!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_171","auniqueExprId_170",POM_enquiry_and, "auniqueExprId_70" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_171","auniqueExprId_170",POM_enquiry_and, "auniqueExprId_1" ));
	}
		/*Customer Approval Type  */		
	if ((strcmp(pcCustAppType,"") != 0) && (pcFormAttr_CustAppType!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_172","auniqueExprId_171",POM_enquiry_and, "auniqueExprId_71" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_172","auniqueExprId_171",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Issued max  */		
	if ((strcmp(pcRFQIssuemax,"") != 0) && (pcFormAttr_RFQIssuemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_173","auniqueExprId_172",POM_enquiry_and, "auniqueExprId_72" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_173","auniqueExprId_172",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Issued min  */		
	if ((strcmp(pcRFQIssuemin,"") != 0) && (pcFormAttr_RFQIssuemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_174","auniqueExprId_173",POM_enquiry_and, "auniqueExprId_73" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_174","auniqueExprId_173",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Customer Due max  */		
	if ((strcmp(pcRFQCustDuemax,"") != 0) && (pcFormAttr_RFQCustDuemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_175","auniqueExprId_174",POM_enquiry_and, "auniqueExprId_74" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_175","auniqueExprId_174",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Customer Due min */		
	if ((strcmp(pcRFQCustDuemin,"") != 0) && (pcFormAttr_RFQCustDuemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_176","auniqueExprId_175",POM_enquiry_and, "auniqueExprId_75" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_176","auniqueExprId_175",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Prototype Due max  */		
	if ((strcmp(pcProtoDuemax,"") != 0) && (pcFormAttr_ProtoDuemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_177","auniqueExprId_176",POM_enquiry_and, "auniqueExprId_76" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_177","auniqueExprId_176",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Prototype Due min */		
	if ((strcmp(pcProtoDuemin,"") != 0) && (pcFormAttr_ProtoDuemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_178","auniqueExprId_177",POM_enquiry_and, "auniqueExprId_77" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_178","auniqueExprId_177",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Prototype Quality Signoff max  */		
	if ((strcmp(pcProtoQltSignmax ,"") != 0) && (pcFormAttr_ProtoQltSignmax != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_179","auniqueExprId_178",POM_enquiry_and, "auniqueExprId_78" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_179","auniqueExprId_178",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Prototype Quality Signoff min */		
	if ((strcmp(pcProtoQltSignmin,"") != 0) && (pcFormAttr_ProtoQltSignmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_180","auniqueExprId_179",POM_enquiry_and, "auniqueExprId_79" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_180","auniqueExprId_179",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Design Validation Due max  */		
	if ((strcmp(pcDesignValDuemax,"") != 0) && (pcFormAttr_DesignValDuemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_181","auniqueExprId_180",POM_enquiry_and, "auniqueExprId_80" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_181","auniqueExprId_180",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Design Validation Due min */		
	if ((strcmp(pcDesignValDuemin,"") != 0) && (pcFormAttr_DesignValDuemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_182","auniqueExprId_181",POM_enquiry_and, "auniqueExprId_81" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_182","auniqueExprId_181",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PPAP Required  */		
	if ((strcmp(pcPPAPReq,"") != 0) && (pcFormAttr_PPAPReq!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_183","auniqueExprId_182",POM_enquiry_and, "auniqueExprId_82" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_183","auniqueExprId_182",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Target PPAP Level  */		
	if ((strcmp(pcTarPPAPLevel,"") != 0) && (pcFormAttr_TarPPAPLevel!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_184","auniqueExprId_183",POM_enquiry_and, "auniqueExprId_83" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_184","auniqueExprId_183",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Critical Path Item */		
	if ((strcmp( pcCritPathItem,"") != 0) && ( pcFormAttr_CritPathItem!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_185","auniqueExprId_184",POM_enquiry_and, "auniqueExprId_84" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_185","auniqueExprId_184",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Critical Path Item PPAP Signoff max  */		
	if ((strcmp(pcCriPathItemPPAPmax,"") != 0) && (pcFormAttr_CriPathItemPPAPmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_186","auniqueExprId_185",POM_enquiry_and, "auniqueExprId_85" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_186","auniqueExprId_185",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Critical Path Item PPAP Signoff min  */		
	if ((strcmp(pcCriPathItemPPAPmin,"") != 0) && (pcFormAttr_CriPathItemPPAPmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_187","auniqueExprId_186",POM_enquiry_and, "auniqueExprId_86" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_187","auniqueExprId_186",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PPAP Build Event max  */		
	if ((strcmp(pcPPAPBuildEvemax,"") != 0) && (pcFormAttr_PPAPBuildEvemax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_188","auniqueExprId_187",POM_enquiry_and, "auniqueExprId_87" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_188","auniqueExprId_187",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PPAP Build Event min */		
	if ((strcmp(pcPPAPBuildEvemin,"") != 0) && (pcFormAttr_PPAPBuildEvemin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_189","auniqueExprId_188",POM_enquiry_and, "auniqueExprId_88" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_189","auniqueExprId_188",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Process Validation Signoff max  */		
	if ((strcmp(pcProValSignmax,"") != 0) && (pcFormAttr_ProValSignmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_190","auniqueExprId_189",POM_enquiry_and, "auniqueExprId_89" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_190","auniqueExprId_189",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Process Validation Signoff min */		
	if ((strcmp(pcProValSignmin,"") != 0) && (pcFormAttr_ProValSignmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_191","auniqueExprId_190",POM_enquiry_and, "auniqueExprId_90" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_191","auniqueExprId_190",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RunatRate Signoff max  */		
	if ((strcmp(pcRunRateSignmax ,"") != 0) && (pcFormAttr_RunRateSignmax != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_192","auniqueExprId_191",POM_enquiry_and, "auniqueExprId_91" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_192","auniqueExprId_191",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RunatRate Signoff min */		
	if ((strcmp(pcRunRateSignmin ,"") != 0) && (pcFormAttr_RunRateSignmin != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_193","auniqueExprId_192",POM_enquiry_and, "auniqueExprId_92" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_193","auniqueExprId_192",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PPAP Signoff max   */		
	if ((strcmp(pcPPAPSignmax,"") != 0) && (pcFormAttr_PPAPSignmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_194","auniqueExprId_193",POM_enquiry_and, "auniqueExprId_93" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_194","auniqueExprId_193",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PPAP Signoff max  */		
	if ((strcmp(pcPPAPSignmin,"") != 0) && (pcFormAttr_PPAPSignmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_195","auniqueExprId_194",POM_enquiry_and, "auniqueExprId_94" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_195","auniqueExprId_194",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Process Signoffmax  */		
	if ((strcmp(pcProSignmax,"") != 0) && (pcFormAttr_ProSignmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_196","auniqueExprId_195",POM_enquiry_and, "auniqueExprId_95" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_196","auniqueExprId_195",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Process Signoff min */		
	if ((strcmp(pcProSignmin,"") != 0) && (pcFormAttr_ProSignmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_197","auniqueExprId_196",POM_enquiry_and, "auniqueExprId_96" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_197","auniqueExprId_196",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Production Materials Required max  */		
	if ((strcmp(pcProdMatReqmax,"") != 0) && (pcFormAttr_ProdMatReqmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_198","auniqueExprId_197",POM_enquiry_and, "auniqueExprId_97" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_198","auniqueExprId_197",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Production Materials Required min */		
	if ((strcmp(pcProdMatReqmin,"") != 0) && (pcFormAttr_ProdMatReqmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_199","auniqueExprId_198",POM_enquiry_and, "auniqueExprId_98" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_199","auniqueExprId_198",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Start of Production max  */		
	if ((strcmp(pcStartProdmax,"") != 0) && (pcFormAttr_StartProdmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_200","auniqueExprId_199",POM_enquiry_and, "auniqueExprId_99" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_200","auniqueExprId_199",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Start of Production min */		
	if ((strcmp(pcStartProdmin,"") != 0) && (pcFormAttr_StartProdmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_201","auniqueExprId_200",POM_enquiry_and, "auniqueExprId_100" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_201","auniqueExprId_200",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*End of Production max  */		
	if ((strcmp(pcEndProdmax,"") != 0) && (pcFormAttr_EndProdmax!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_202","auniqueExprId_201",POM_enquiry_and, "auniqueExprId_101" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_202","auniqueExprId_201",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*End ofProduction min  */		
	if ((strcmp(pcEndProdmin,"") != 0) && (pcFormAttr_EndProdmin!= NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_203","auniqueExprId_202",POM_enquiry_and, "auniqueExprId_102" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_203","auniqueExprId_202",POM_enquiry_and, "auniqueExprId_1" ));
	}
	

	//set where expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_203" ));	
	
	//set distinct value
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
	//execute the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
	//delete the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
	//process result	
	if(iRows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(i=0;i<iRows;i++)
		{
			tChItem = NULLTAG;
			tChItem = *(tag_t *)paReport[i][0];
			(*foundTags)[i] = tChItem;
		}
		SAFE_MEM_free(paReport);
	}

	return iFail;
}

