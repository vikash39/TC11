/*******************************************************************************
File         : t1aAUTO_check_assembly_progression.c

Description  : This rule handler validates the release status of  child item rev of items
               in the affected items folder if it is equal to or higher than "Study Approved"
			   else and also verifies the child item rev is in the Change Process.               

Input        : None

Output       : None

Author       : Garima Dewangan,TCS

Revision History :
Date            Revision    Who              Description
Jan 13, 2009    1.0         Garima Dewangan  Initial Creation
Feb 15, 2009	1.1			Dipak Naik		 Added code to allow the item revision
											 with "Cad Release Status"
Mar 17, 2009    1.2         Garima Dewangan  Modified code to allow only OEM item revision
											 to "Cad Release Status" 
Jan, 25,2010    1.3         Nivedita Kamath  Modified code to add check for obsolete child item 
                                             revisions in assembly.
                                             
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

/* static function prototypes */
int check_item_for_assy_progression(tag_t	tItemRev,
								    tag_t	tEngChangeRev,
                                    STATUS_Struct_t StatusProgression,
								    TARGET_RELEASE_Struct_t StudyApprovedStatus,
									TIA_ErrorMessage **currErrMsg,
									TIA_ErrorMessage **progCheckFailureItems,
									TIA_ErrorMessage **croOEMFailureItems,
									TIA_ErrorMessage **ObsoleteFailureItems,
								    logical *lStatus);

/*=========================================================================
 *    Implementation of Rule Handler -  t1aAUTO_check_assembly_progression
===========================================================================*/
EPM_decision_t t1aAUTO_check_assembly_progression(EPM_rule_message_t message)
{
    int     iRetCode		= ITK_ok;
	int     iSts			= ITK_ok;
	int		iNumArgs		= 0;
    int     iNumAffected	= 0;
	int     iNumAttachments	= 0;
	int     indx			= 0;
	int     indxA			= 0;
	
	char    *pcClassName    = NULL;	
    char     szErrorString[TIAUTO_error_message_len+1] = "";
    char     objectTypeName[TCTYPE_name_size_c+1]	   = "";
	
	EPM_decision_t	decision = EPM_go;
    logical			lStatus	 = true;
	logical			lStatusA = true;	
	
    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t StudyApprovedStatus;

	tag_t   *ptAttachments   = NULL;
	tag_t   *ptAffectedItems = NULL;
	tag_t    tRootTask		 = NULLTAG;

	
	TIA_ErrorMessage *currErrMsg = NULL;
	TIA_ErrorMessage *progCheckFailureItems = NULL;
	TIA_ErrorMessage *croOEMFailureItems = NULL;
	TIA_ErrorMessage *ObsoleteFailureItems = NULL;
	
   
    iNumArgs = TC_number_of_arguments(message.arguments);
    if(iNumArgs != 0)
    {
        TI_sprintf(szErrorString, "No Arguments allowed to \"TIAUTO-check-assembly-progression\" handler.");        
        iRetCode = TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER; 
		tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
	}
    else
    {		
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		tiauto_get_status_progression_array (&StatusProgression);

		TI_sprintf(StudyApprovedStatus.szTargetReleaseStatus, STUDY_APPROVED);
		StudyApprovedStatus.iLevel = tiauto_status_progression_index (StudyApprovedStatus.szTargetReleaseStatus,
                                                                      StatusProgression);
		if (StudyApprovedStatus.iLevel == -1)
		{
			TI_sprintf(szErrorString, "%s Status is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.", STUDY_APPROVED);            
			iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
			tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
		}
		else
		{
			iRetCode = EPM_ask_root_task(message.task , &tRootTask);
			if (iRetCode == ITK_ok)
				iRetCode = EPM_ask_attachments(tRootTask,EPM_target_attachment,
											&iNumAttachments,&ptAttachments);
			if(iRetCode == ITK_ok)
			{
				for (indx = 0; indx < iNumAttachments ; indx++)
				{
					iSts = tiauto_get_object_name (ptAttachments[indx], objectTypeName);
					if( iSts != ITK_ok ) 
					{
						iRetCode = iSts;	
						TI_sprintf( szErrorString, "%d: failed while finding attachment item's type.", iRetCode);
						tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
					}
					else if(tc_strcasecmp (objectTypeName , CHANGE_REV)== 0 ) 
					{
						iRetCode = ECM_get_affected_items(ptAttachments[indx], &iNumAffected, &ptAffectedItems);
						if(iRetCode != ITK_ok)
						{
							TI_sprintf( szErrorString, "%d: failed while finding affected items.", iRetCode);
							tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
						}
						else
						{
							for (indxA = 0; indxA < iNumAffected ; indxA++)
							{
								iSts = tiauto_get_class_name_of_instance (ptAffectedItems[indxA], &pcClassName);
								if(iSts != ITK_ok) 
								{
									TI_sprintf( szErrorString, "%d: failed while getting affected items information.", iRetCode);									
									iRetCode = iSts;
									tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
								}
								else if(tc_strcasecmp (pcClassName , "ItemRevision")== 0 )
								{
									lStatusA = true;
									iSts = check_item_for_assy_progression(ptAffectedItems[indxA],
																		ptAttachments[indx], // Eng Change Rev 
																		StatusProgression,
																		StudyApprovedStatus,
																		&currErrMsg,
																		&progCheckFailureItems,
																		&croOEMFailureItems,
																		&ObsoleteFailureItems,
																		&lStatusA);
									if(iSts != ITK_ok)
										iRetCode = iSts;
									if(lStatusA == false)
										lStatus = false;
								}
							}
						}
						break;	// for first change item only
					}
				}
			}
			else
			{
				TI_sprintf( szErrorString, "%d: failed while getting the attachment items.", iRetCode);
				tiauto_writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
			}
		}
	}	

	if( ( iRetCode != ITK_ok ) || ( lStatus == false ) )
	{
		TIA_ErrorMessage *tempErrMsg = NULL; 
		decision = EPM_nogo;

		TC_write_syslog("\n*********************************************************************************");
        TC_write_syslog("****** BEGIN OF ASSEMBLY PROGRESSION FAILURE MESSAGES ******");
        TC_write_syslog("*********************************************************************************\n");
        
		if(currErrMsg)
		{			
			while(currErrMsg)
			{	           
				EMH_store_error_s1(EMH_severity_error, currErrMsg->iRetCode, currErrMsg->errMsg);
				TC_write_syslog(currErrMsg->errMsg);
				TC_write_syslog("\n");
				iRetCode = currErrMsg->iRetCode; 
				tempErrMsg = currErrMsg;
         		currErrMsg = currErrMsg->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
		}
		if(croOEMFailureItems) 
		{
			TC_write_syslog("Error: The following OEM Child Component Parts are not at a valid status(CRO).\n Please status these parts with CRO workflow.\n");
			while(croOEMFailureItems)
			{
				EMH_store_error_s1(EMH_severity_error, croOEMFailureItems->iRetCode, croOEMFailureItems->errMsg);
				TC_write_syslog(croOEMFailureItems->errMsg);
				TC_write_syslog("\n");
				iRetCode = croOEMFailureItems->iRetCode; 
				tempErrMsg = croOEMFailureItems;
         		croOEMFailureItems = croOEMFailureItems->next;
				free ( tempErrMsg );
				tempErrMsg = NULL; 
			}	
			EMH_store_error_s1(EMH_severity_error, iRetCode, "\n Error: The following OEM Child Component Parts are not at a valid status(CRO).\n Please status these parts with CRO workflow.");			
		}
		if(ObsoleteFailureItems)
		{
			TC_write_syslog("Error: The following Child Component Parts has an obsolete status which is not valid for use inside an assembly to be released. Please replace the obsolete component with a component that has a valid status.\n");
			while(ObsoleteFailureItems)
			{
				EMH_store_error_s1(EMH_severity_error, ObsoleteFailureItems->iRetCode, ObsoleteFailureItems->errMsg);
				TC_write_syslog(ObsoleteFailureItems->errMsg);
				TC_write_syslog("\n");
				iRetCode = ObsoleteFailureItems->iRetCode; 
				tempErrMsg = croOEMFailureItems;
         		ObsoleteFailureItems = ObsoleteFailureItems->next;
				free ( tempErrMsg );
				tempErrMsg = NULL; 
			}	
			EMH_store_error_s1(EMH_severity_error, iRetCode, "\n Error: The following Child Component Parts has an obsolete status which is not valid for use inside an assembly to be released. Please replace the obsolete component with a component that has a valid status.");			
		}
		if(progCheckFailureItems) 
		{
			TC_write_syslog("Error: The following Child Component Parts are not at a valid status.\n Please add these Item Revisions to the DAP change folders.\n");
			while(progCheckFailureItems)
			{
				EMH_store_error_s1(EMH_severity_error, progCheckFailureItems->iRetCode, progCheckFailureItems->errMsg);
				TC_write_syslog(progCheckFailureItems->errMsg);
				TC_write_syslog("\n");
				iRetCode = progCheckFailureItems->iRetCode; 
				tempErrMsg = progCheckFailureItems;
         		progCheckFailureItems = progCheckFailureItems->next;
				free ( tempErrMsg );
				tempErrMsg = NULL; 
			}	
			EMH_store_error_s1(EMH_severity_error, iRetCode, "\n Error: The following Child Component Parts are not at a valid status. \n Please add these Item Revisions to the DAP change folders.");			
		}

		TC_write_syslog("*********************************************************************************");
        TC_write_syslog("****** END OF ASSEMBLY PROGRESSION FAILURE ERROR MESSAGES ******");
        TC_write_syslog("*********************************************************************************\n\n");   	
	}
	
	SAFE_MEM_free (ptAffectedItems);
	SAFE_MEM_free (ptAttachments);
	SAFE_MEM_free (pcClassName);
	// SAFE_MEM_free (currErrMsg); will cause mem leak
	currErrMsg = NULL;
	croOEMFailureItems = NULL;
	// SAFE_MEM_free (progCheckFailureItems); will cause mem leak
	progCheckFailureItems = NULL;

	return decision;
}
								
/* recursive function to validate status of child item revision of item revisions in the change folders
  w.r.t to "Study Approved" status.
  If an item revision has a BVR get the child items and validate them.*/
int check_item_for_assy_progression(tag_t	tItemRev,
								    tag_t	tEngChangeRev,
                                    STATUS_Struct_t StatusProgression,
								    TARGET_RELEASE_Struct_t StudyApprovedStatus,
									TIA_ErrorMessage **currErrMsg,
									TIA_ErrorMessage **progCheckFailureItems,
									TIA_ErrorMessage **croOEMFailureItems,
                                    TIA_ErrorMessage **ObsoleteFailureItems,
								    logical *lStatus)
{		
    int     iRetCode		= ITK_ok;
	int     iSts			= ITK_ok;	
    int     iItemBvrCount	= 0;
    int     iNumOccs		= 0;
    int     iCount			= 0;

    tag_t   *ptItemRevBvrs	= NULL;	
    tag_t   *ptOccs			= NULL;

    tag_t   tChildItem		= NULLTAG;
	tag_t	tChildBomView	= NULLTAG;

	logical lIsPrecise		= false;
	logical lChildStatus	= true;
	logical lIsOEM			= false;

	char    *pcItemRevName  = NULL;

    char    szChildRelStatus[WSO_name_size_c+1] = "";
	char    szErrorString[TIAUTO_error_message_len+1]="";

	iSts = ITEM_rev_list_bom_view_revs (tItemRev, &iItemBvrCount, &ptItemRevBvrs);
	if( iSts != ITK_ok )
	{
		iRetCode = iSts;
		WSOM_ask_id_string(tItemRev, &pcItemRevName);
		TI_sprintf(szErrorString, "Error while getting %s Part's BOM.", pcItemRevName);
        tiauto_writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);            		
	}
	else if( iItemBvrCount > 0 ) 
	{
		iSts = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
		if( (lIsPrecise) && ( iSts == ITK_ok ) )
		{
			iSts = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
			if( iSts != ITK_ok )
				iRetCode = iSts;
			else if( iNumOccs > 0 ) 
			{				
				for (iCount = 0; iCount < iNumOccs ; iCount++)
				{
					iSts = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],
                                                    &tChildItem, &tChildBomView);
					if ( iSts == ITK_ok )
						iSts = tiauto_get_release_status(tChildItem, szChildRelStatus);
					if ( iSts == ITK_ok )
						iSts = tiauto_check_if_itemType_isOEM(tChildItem, &lIsOEM);							
					if ( iSts == ITK_ok )
					{						
						//if the child component revision has "Cad Release Only" status
						if (lIsOEM == true)
						{
							if(tc_strcasecmp (szChildRelStatus, CRO )==0)
							{
								// continue; // won't check the child items								
							}
							else
							{
								*lStatus = false;
								iSts = WSOM_ask_id_string(tChildItem, &pcItemRevName);							
								TI_sprintf(szErrorString, "    %s", pcItemRevName);												
								iRetCode = TIAUTO_CHILD_PART_INVALID_STATUS;
								tiauto_writeErrorMsgToStack(croOEMFailureItems, iRetCode, szErrorString);
								SAFE_MEM_free(pcItemRevName);
							}
						}
						else if(!tc_strcmp(szChildRelStatus,OBSOLETE))
						{
							*lStatus = false;
						    iSts = WSOM_ask_id_string(tChildItem, &pcItemRevName);
							TI_sprintf(szErrorString, "    %s", pcItemRevName);
							tiauto_writeErrorMsgToStack(ObsoleteFailureItems,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							SAFE_MEM_free(pcItemRevName);
													
						}
						// Verifying whether child component rev is at SAME or HIGHER status than "Study Approved"
						//  of Change process. If yes, accept the child component and continue to verify another child rev.
						else if ( tc_strcasecmp (szChildRelStatus, StudyApprovedStatus.szTargetReleaseStatus) == 0 ||
                             tiauto_status_progression_index (szChildRelStatus, StatusProgression) > StudyApprovedStatus.iLevel)
						{
							// continue;	// won't check the child items
						}
						// If not as above mentioned, verify if the child component rev is part of Affected OR Solution
						// Items folders of Change Process. If yes, accept and continue to verify another child rev.
						else if(tiauto_isComponent_partOf_affectedItems(tChildItem, tEngChangeRev))
						{
							// continue;	// won't check the child items
						}
						// The child component part rev is at INVALID Release status for the current change process.
						else
						{
							*lStatus = false;
							iSts = WSOM_ask_id_string(tChildItem, &pcItemRevName);							
							TI_sprintf(szErrorString, "    %s", pcItemRevName);												
							iRetCode = TIAUTO_CHILD_PART_INVALID_STATUS;
							tiauto_writeErrorMsgToStack(progCheckFailureItems, iRetCode, szErrorString);
							SAFE_MEM_free(pcItemRevName);
						}
						// Check the child componts of tChildItem
						lChildStatus = true;
						iSts = check_item_for_assy_progression(tChildItem, tEngChangeRev, 
															   StatusProgression, 
															   StudyApprovedStatus, 
															   currErrMsg,
															   progCheckFailureItems,
															   croOEMFailureItems,
															   ObsoleteFailureItems,
															   &lChildStatus);
						if( iSts != ITK_ok )
							iRetCode = iSts;
						if( lChildStatus == false )
							*lStatus = false;
					}
					else
					{
						iRetCode = iSts;
						TI_sprintf(szErrorString, "");
						if(tChildItem != NULLTAG )
						{
							WSOM_ask_id_string(tChildItem, &pcItemRevName);
							TI_sprintf(szErrorString, "Error while getting %s sub-components details from the BOM.", pcItemRevName);
						}
						else
						{
							WSOM_ask_id_string(tItemRev, &pcItemRevName);
							TI_sprintf(szErrorString, "Error while getting sub-components details from the %s Part's BOM.", pcItemRevName);
						}
						tiauto_writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
					}
				}
			}
		}
		else
		{
			*lStatus = false;
			WSOM_ask_id_string(tItemRev, &pcItemRevName);
            TI_sprintf(szErrorString, "%s Part does not have Precise BOM. So it is Invalid BOM.", pcItemRevName);                        
            iRetCode = TIAUTO_IMPRECISE_BVR_FOUND;			
			tiauto_writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
		}
	}

	SAFE_MEM_free (ptItemRevBvrs);
    SAFE_MEM_free (ptOccs);

	SAFE_MEM_free ( pcItemRevName );

	return  iRetCode;
}								
						
