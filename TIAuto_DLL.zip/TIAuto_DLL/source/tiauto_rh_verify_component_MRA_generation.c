/************************************************************************************************
FILE        :   tiauto_rh_verify_component_MRA_generation.c

DESCRIPTION :   

AUTHOR      :   Pradeep, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
07 Jan, 2013    1.0        Pradeep	         Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_component_MRA_generation(EPM_rule_message_t msg)
{
    int				 iRetCode									= ITK_ok;
	int				iNewAseemCount								= 0;
	int				iCompMRACount								= 0;
	int             iCompMRAIndx                                = 0;
	int             iNewAssyIndx                                = 0;

	char			*pcErrMsg									= NULL;
	char			*pcValidReleaseStatusList					= NULL;
	char		    acRootTaskName[WSO_name_size_c+1]			= "";
	char			szErrorString[TIAUTO_error_message_len+1]	= "";

	tag_t			tChangeRev									= NULLTAG;
	tag_t			tRootTask									= NULLTAG;
	tag_t           tChangeForm									= NULLTAG;
	tag_t			tSite										= NULLTAG;
	tag_t			tChildComp									= NULLTAG;	
	tag_t			tAssmComp									= NULLTAG;
	tag_t			*ptNewAssembly								= NULL;
	tag_t			*ptCompMRA									= NULL;

	boolean			bValidERPPlant								= false;
	boolean			bMfgRelToBeCreated							= false;
	boolean			bMRAFoundInNewAssy                          = false;
	boolean			bValidtoProceed								= false;

	char *pcParentItemrev = NULL;
	char *pcChildItemrev = NULL;

	EPM_decision_t decision = EPM_go;
	TIA_ErrorMessage *ErrMsgStack				= NULL;
		

	//get the root task
	iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	if( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0)
	{
		iRetCode = verify_Valid_ERP_Plant(msg.task,&bValidERPPlant,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else if( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 ||
		tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0)
	{
		iRetCode = verify_Valid_MRA_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else if(tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 || tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0)
	{
		iRetCode = verify_Valid_ACD_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else
	{
		return decision;
	}

	//if there are any ITK failure
	if ( iRetCode != ITK_ok && iRetCode != EPM_invalid_argument_value)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}

	//Conditional Task result decision
	//if ( bValidERPPlant == true && bMfgRelToBeCreated == true && iRetCode == ITK_ok)
	//if ( bMfgRelToBeCreated == true && iRetCode == ITK_ok)
	if ( iRetCode == ITK_ok && ( (bMfgRelToBeCreated == true && 
										( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0) ||
										( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) ) ||
				( ( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || 
				   tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0) && 
				   bValidERPPlant == true && bMfgRelToBeCreated == true ) ||  (bMfgRelToBeCreated == true && ( tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0  )) || (bMfgRelToBeCreated == true && ( tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0  )) ) )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//get the owning site
			iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
			//get the root task
			iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;

			if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
			{
				//get the root task name
				iRetCode = EPM_ask_name  ( tRootTask, acRootTaskName );
			}
			//read the change form and
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_120componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
	        else 
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP3",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else
				if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP2",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_PMR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0))
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PMR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TPR",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201newacdassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201componentacd",&iCompMRACount,&ptCompMRA);
				}
			}
			else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TER",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205newacdassembly",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205componentmra",&iCompMRACount,&ptCompMRA);
				}
			}
			for(iCompMRAIndx = 0;iCompMRAIndx<iCompMRACount && iRetCode == 0;iCompMRAIndx++)
			{
				bMRAFoundInNewAssy = false;
				tChildComp = ptCompMRA[iCompMRAIndx] ;
				tAssmComp = 0;
				for(iNewAssyIndx = 0;iNewAssyIndx<iNewAseemCount && iRetCode == 0;iNewAssyIndx++)
				{
					tAssmComp = ptNewAssembly[iNewAssyIndx];
					if(ptCompMRA[iCompMRAIndx] == ptNewAssembly[iNewAssyIndx])
					{
						bValidtoProceed = true;
						bMRAFoundInNewAssy = true;
						break;
					}
					if(bMRAFoundInNewAssy == false)
					{
						iRetCode = verify_ChildPart_in_ParentBOM(ptCompMRA[iCompMRAIndx], ptNewAssembly[iNewAssyIndx], &bMRAFoundInNewAssy);
						if (iRetCode == 0 && bMRAFoundInNewAssy == true)
						{
							bValidtoProceed= true;
							break;
						}
					}
				}
				if (bMRAFoundInNewAssy == true && ((tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 ) || (tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 )))
				{
					WSOM_ask_id_string(tAssmComp,&pcParentItemrev);
					WSOM_ask_id_string(tChildComp,&pcChildItemrev);
					TI_sprintf(szErrorString, "Item revision \"%s\" mentioned in the Component TRA field is part of the assembly \"%s\" mentioned in the New Top Level Assembly field.\n" , 
													pcChildItemrev,pcParentItemrev);
					tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED ,
															szErrorString);

					SAFE_MEM_free(pcParentItemrev);
					SAFE_MEM_free(pcChildItemrev);
				}
				else if (bMRAFoundInNewAssy == true)
				{
					WSOM_ask_id_string(tAssmComp,&pcParentItemrev);
					WSOM_ask_id_string(tChildComp,&pcChildItemrev);
					TI_sprintf(szErrorString, "Item revision \"%s\" mentioned in the Component MRA field is part of the assembly \"%s\" mentioned in the New Top Level Assembly field.\n" , 
													pcChildItemrev,pcParentItemrev);
					tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED ,
															szErrorString);

					SAFE_MEM_free(pcParentItemrev);
					SAFE_MEM_free(pcChildItemrev);
				}
			}
		}
	}
	if (iRetCode == 0 && bValidtoProceed == true)
	{
		iRetCode = TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED;
		decision = EPM_nogo;
		//TI_sprintf(szErrorString, "%s","One of the component MRA found in New Assembly");
		//EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
		//TC_write_syslog(szErrorString);
	}
	if(ErrMsgStack != NULL)
	{				
		TIA_ErrorMessage *tempErrMsg = NULL;

		if( (tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0) || (tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0) ||  (tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0))
		{
			TI_sprintf(szErrorString,"\nThe above mentioned item revisions in the Components MRA field are part of the assemblies mentioned in the New Top Level Assembly of CAP form. Please remove these item revisions from the Components MRA field to proceed. \n");
		}
		else if( (tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0) || (tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0))
		{
			TI_sprintf(szErrorString,"\nThe above mentioned item revisions in the Components TRA field are part of the assemblies mentioned in the New TRA Assembly of TPR/TER form. Please remove these item revisions from the Components TRA field to proceed. \n");
		}
		else
		{
			TI_sprintf(szErrorString,"\nThe above mentioned item revisions in the Components MRA field are part of the assemblies mentioned in the New Top Level Assembly of PMR form. Please remove these item revisions from the Components MRA field to proceed. \n");
		}
		TC_write_syslog(szErrorString);
        EMH_store_error_s1(EMH_severity_error,TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED,szErrorString);
		tempErrMsg = ErrMsgStack;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
		free( ErrMsgStack );
		ErrMsgStack = NULL;
		
	}

	SAFE_MEM_free (ptNewAssembly);
	SAFE_MEM_free (ptCompMRA);
	
	return decision;
}
