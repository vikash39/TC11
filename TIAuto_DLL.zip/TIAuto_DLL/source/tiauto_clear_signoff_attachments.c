/*******************************************************************************
FILE        :   tiauto_check_blank_change.c

DESCRIPTION :   This C file Implements the "TAUTO_check_blank_change"
				server exit which will be used to check the blank change (i.e. no item revs
				in the Affected and solution items folder of the change revision)

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
June 01, 2010    1.0        Dipak Naik		 Initial Creation

*******************************************************************************/
/* includes */
#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>



int TAUTO_clear_signoff_attachments(void *return_value)
{
    int		iFail							= ITK_ok;
	int		iCount					= 0;
	int		iArgumentCount				= 0;
	tag_t	tTask						= NULLTAG;
	tag_t	tECRev						= NULLTAG;
	tag_t	tTaskTemplate				= NULLTAG;
	tag_t	tHandler					= NULLTAG;
	tag_t	*ptAffectedItems			= NULL;
	char	**pcArguments				= NULL;
	int				iLoop				= 0;
	int				iNumArgs			= 0;
	int				iAllTasks			= 0;
	int				iAllSubTasks		= 0;
	int				iLoopAllTasks		= 0;
	int				iLoopAllSubTasks	= 0;
	int				iNumAttachs			= 0;

	tag_t           tRootTaskTag        = NULLTAG;
	tag_t			*ptAllTaskTags		= NULL;
	tag_t			*ptAllSubTaskTags	= NULL;
	tag_t			*ptAttachsTagList	= NULL;//to be freed

	char			*pcTaskTypeName						        = NULL;
	char			*pcSubTaskTypeName							= NULL;
	char		    *pcValue									= NULL;
    char		    *pcFlag										= NULL;
	char			*pcTaskName									= NULL;
	char			*pcRevTaskName								= NULL;
	EPM_state_t State;
	/* get the task tag */
	iFail = USERARG_get_tag_argument(&tTask);
	iFail = USERARG_get_string_argument(&pcTaskName);
	if( iFail == ITK_ok && tTask != NULLTAG)
	{
		/* get the task template */
		iFail = AOM_ask_value_tag  ( tTask,"task_template" ,&tTaskTemplate);
		if(iFail == ITK_ok && tTaskTemplate != NULLTAG)
			iFail = EPM_find_handler(tTaskTemplate,EPM_action_handler_type,EPM_complete_action,"TIAUTO-AH-remove-signoff-attachments",&tHandler);
		if(iFail == ITK_ok && tHandler!= NULLTAG)
		{
			/* get the task arguments */
			
			iFail = EPM_ask_handler_arguments(tHandler, &iArgumentCount, &pcArguments);
			
		}
	}
	if(iFail == ITK_ok && tTask != NULLTAG && pcTaskName != NULL)
	{
		//get the tag of the root task
		iFail =  EPM_ask_root_task( tTask, &tRootTaskTag);
		if(iFail == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iFail = EPM_ask_sub_tasks(tRootTaskTag,&iAllTasks,&ptAllTaskTags);
			for(iLoopAllTasks =0 ; iLoopAllTasks < iAllTasks; iLoopAllTasks++)
			{
				iFail = AOM_ask_value_string(ptAllTaskTags[iLoopAllTasks], "task_type", &pcTaskTypeName);
				iFail = EPM_ask_name2(ptAllTaskTags[iLoopAllTasks],&pcRevTaskName);

				
				if( (iFail == ITK_ok) && (tc_strcmp(pcTaskTypeName,"EPMReviewTask") == 0) && (tc_strcmp(pcRevTaskName,pcTaskName)==0))
				{
					iFail = EPM_ask_state(ptAllTaskTags[iLoopAllTasks],&State);
					iFail = EPM_ask_sub_tasks(ptAllTaskTags[iLoopAllTasks],&iAllSubTasks,&ptAllSubTaskTags);
					for(iLoopAllSubTasks =0 ; iLoopAllSubTasks < iAllSubTasks; iLoopAllSubTasks++)
					{	
						iFail = AOM_ask_value_string(ptAllSubTaskTags[iLoopAllSubTasks], "task_type", &pcSubTaskTypeName);
						if((State==EPM_pending) && (tc_strcmp(pcSubTaskTypeName,"EPMSelectSignoffTask")==0) && (iFail == ITK_ok))
						{
							//get signoff attachments
							iFail = EPM_ask_attachments(ptAllSubTaskTags[iLoopAllSubTasks], EPM_signoff_attachment, &iNumAttachs, &ptAttachsTagList);
							if ((iFail == ITK_ok) && (iNumAttachs != 0))
							{
								//remove signoff attachments
								iFail = EPM_remove_attachments(ptAllSubTaskTags[iLoopAllSubTasks], iNumAttachs, ptAttachsTagList);
								
							}
							return iFail;
						}
					}
				}
				
			}
		}	
	}
	

    return iFail;
}