/*******************************************************************************
*
* FILENAME : tiauto_server_exits.c
*
* DESCRIPTION :
*      This file serves as a container for TI Auto server exits.
*
* FUNCTIONS :
*       int t1aAUTO_register_server_exits( int *decision, va_list args  );
*
*
Revision History :
Date            Revision    Who              Description
June 01, 2010    1.0        Dipak Naik		 Initial Creation
Nov 21, 2019    1.1			Shruthi			 Modified TAUTO_Create_Item create input arguments.

********************************************************************************/

/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
#include <tiauto_defines.h>

/*******************************************************************************
* PUBLIC FUNCTION DEFINITIONS
*******************************************************************************/

/*******************************************************************************
* NAME :            int t1aAUTO_register_server_exits( int *decision, va_list args  )
*
* DESCRIPTION :     Register all of TI AUTO server exits here
*
*********************************************************************************/

#include <tiauto_server_exits.h>
#include <server_exits/user_server_exits.h>

int t1aAUTO_register_server_exits( int *decision, va_list args )
{

    int iSts = ITK_ok;
	int TAUTO_check_blank_change_input_args[] = { USERARG_TAG_TYPE };
	int TAUTO_set_status_on_object_args[] = { USERARG_TAG_TYPE,USERARG_STRING_TYPE };
	int TAUTO_AssignmentList_info_to_Audit_input_args[] = {USERARG_TAG_TYPE, USERARG_STRING_TYPE };
	int TAUTO_Create_Item_input_args[] = {USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_STRING_TYPE,
										  USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_TAG_TYPE,USERARG_TAG_TYPE};
	int TAUTO_Create_Item_input_args1[] = {USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_STRING_TYPE,
										  USERARG_STRING_TYPE,USERARG_STRING_TYPE,USERARG_TAG_TYPE,USERARG_TAG_TYPE};

	int TAUTO_ERP_Add_Rev_Status_to_Sec_args[] = {USERARG_TAG_TYPE,USERARG_TAG_TYPE,USERARG_INT_TYPE};
	int TAUTO_ERP_Change_Attribute_Value_args[] = {USERARG_TAG_TYPE, USERARG_STRING_TYPE, USERARG_STRING_TYPE};
	int TAUTO_clear_signoff_attachments_input_args[] = {USERARG_TAG_TYPE, USERARG_STRING_TYPE };
	int TIAUTO_get_approval_report_data_args[] = {USERARG_STRING_TYPE, USERARG_STRING_TYPE};
	

	*decision  = ALL_CUSTOMIZATIONS;

	iSts = USERSERVICE_register_method("TAUTO_check_blank_change", TAUTO_check_blank_change,
										1, TAUTO_check_blank_change_input_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_AssignmentList_info_to_Audit", TAUTO_AssignmentList_info_to_Audit,
										2, TAUTO_AssignmentList_info_to_Audit_input_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_Create_Data_Migration_Item", TAUTO_Create_Data_Migration_Item,
										8, TAUTO_Create_Item_input_args,
										USERARG_TAG_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_ERP_Add_Rev_Status_to_Secondary", TAUTO_Add_Rev_Status_to_Secondary,
											3, TAUTO_ERP_Add_Rev_Status_to_Sec_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_ERP_Change_Attribute_Value", TAUTO_ERP_Change_Attribute_Value,
										3, TAUTO_ERP_Change_Attribute_Value_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_Create_Item", TAUTO_Create_Item,
										9, TAUTO_Create_Item_input_args1,
										USERARG_TAG_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_set_status_on_object", TAUTO_set_status_on_object,
										2, TAUTO_set_status_on_object_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TAUTO_clear_signoff_attachments", TAUTO_clear_signoff_attachments,
										2, TAUTO_clear_signoff_attachments_input_args,
										USERARG_VOID_TYPE);

	iSts = USERSERVICE_register_method("TIAUTO_get_approval_report_data", TIAUTO_get_approval_report_data,
										2, TIAUTO_get_approval_report_data_args,
										USERARG_STRING_TYPE + USERARG_ARRAY_TYPE);

    return iSts;
}


