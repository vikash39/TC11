
/*******************************************************************************
FILE        :   tiauto_rh_check_action_performer_role.c
Details     :   This is a dummy rule handler. This is used to check whether a
				perticular task is assigned to user that matches with the role
				and group name mentioned in the handler argument during apply
				assignment

REVISION HISTORY :

Date              Revision        Who						Description
Sept  2, 2011     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_engineer_feasible_task_result(EPM_rule_message_t msg)
{
	//variable 
	int				iRetcode				= ITK_ok;
	int				iNumAttachments			= 0;
	int				iNumArgs				= 0;
	int				iLoopArg				= 0;
	tag_t			tRootTaskTag			= NULLTAG;
	tag_t			tJob					= NULLTAG;
	tag_t			*ptAttachments			= NULL;
	tag_t			ptRelationType			= NULLTAG;
	char			*pcTaskType				= NULL;
	char			*pcArgName				= NULL;
	char			*pcArgValue				= NULL;
	char			*pcGroup				= NULL;
	char			*pcRole					= NULL;
	char			*pcFormType				= NULL;
	char			*pcAttribute			= NULL;
	char			*pcObjectType			= NULL;
	char			*pcValue				= NULL;
	char			*pcOption				= NULL;
	char			*pcErrMsg				= NULL;
	char			*pcInputErrorMessage	= NULL;


	EPM_decision_t decision = EPM_nogo;

	if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		iRetcode = EPM_ask_job( msg.task, &tJob );
		//iRetcode =  EPM_ask_name2(msg.task,&pcTaskName);	
		iRetcode =  AOM_ask_value_string(msg.task,"task_type",&pcTaskType);
			
		iNumArgs = TC_number_of_arguments(msg.arguments);
		if(iNumArgs>=3)
		{
			for( iLoopArg = 0;iLoopArg < iNumArgs;iLoopArg++)
			{
				iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
				//if(tc_strcasecmp(pcArgName, "group") == 0)
				//{
				//    //get the task name.
			 //       pcGroup = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
			//		 tc_strcpy( pcGroup, pcArgValue);
				//	
				//}
				//else if(tc_strcasecmp(pcArgName, "role") == 0)
				//{
				//    //conditional task result.
			 //       pcRole = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
    //                tc_strcpy( pcRole, pcArgValue);
				//	
				//}
				if(tc_strcasecmp(pcArgName, "source_type") == 0)
				{
					//error message
					pcFormType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcFormType, pcArgValue);
				}
				else if(tc_strcasecmp(pcArgName, "attribute") == 0)
				{
					//error message
					pcAttribute = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcAttribute, pcArgValue);
				}
				else if(tc_strcasecmp(pcArgName, "value") == 0)
				{
					//error message
					pcValue = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcValue, pcArgValue);
				}
				else if(tc_strcasecmp(pcArgName, "option") == 0)
				{
					//error message
					pcOption = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcOption, pcArgValue);
				}
				else if(tc_strcasecmp(pcArgName, "error_message") == 0)
				{
					//error message
					pcInputErrorMessage = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcInputErrorMessage, pcArgValue);
				}
				else
				{						
					iRetcode = EPM_invalid_argument;			
				}
			}
		}
		else
		{						
			iRetcode = EPM_invalid_argument;			
		}

		if (iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			int		iLoopAtt			=0;

			iRetcode = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment,&iNumAttachments,&ptAttachments);
		
			for(iLoopAtt=0; iLoopAtt < iNumAttachments;iLoopAtt++)
			{
				int			iSecObjCount			= 0;
				tag_t		*ptSecObjTags			= NULL;	
				char		*pcSecObjType			= NULL;
				char		*pcSecAttrValue			= NULL;

				iRetcode = AOM_ask_value_string(ptAttachments[iLoopAtt],"object_type",&pcObjectType);
				if((tc_strcmp(pcObjectType,"T8_TI_ChangeRevision")==0) && (iRetcode == ITK_ok))
				{
					int		iLoopSecObj				=0;

					iRetcode = GRM_find_relation_type	(REL_IMAN_SPEC,&ptRelationType);
					iRetcode = GRM_list_secondary_objects_only	(ptAttachments[iLoopAtt],ptRelationType,&iSecObjCount,&ptSecObjTags);
					for(iLoopSecObj =0; iLoopSecObj < iSecObjCount; iLoopSecObj++)
					{
						iRetcode = AOM_ask_value_string(ptSecObjTags[iLoopSecObj],"object_type",&pcSecObjType);
													
						if((tc_strcmp(pcTaskType,"EPMConditionTask")==0) && (iRetcode == ITK_ok))
						{
							char		*pcResult		= NULL;
							if((tc_strcmp(pcSecObjType,pcFormType) == 0)  && (iRetcode == ITK_ok))
							{
								iRetcode = EPM_get_task_result	(msg.task,&pcResult);
								iRetcode = AOM_ask_value_string(ptSecObjTags[iLoopSecObj],ATTR_IS_PROD_IMPACTED,&pcSecAttrValue);						
								if((tc_strcmp(pcSecAttrValue,pcValue) ==0) && (tc_strstr(pcResult,pcOption)!=NULL)  && (iRetcode == ITK_ok))
								{
									decision= EPM_nogo;
									TC_write_syslog(pcInputErrorMessage);
									EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_COND_OPTION, pcInputErrorMessage) ;
									return decision;
								}

								/*else if((tc_strstr(pcResult,pcValue) != NULL) && (iRetcode == ITK_ok))
								{
									decision= EPM_nogo;
									/*TC_write_syslog(pcInputErrorMessage);
									TI_sprintf (szErrorString,"Engineer Group cannot optout from the workflow");
									TC_write_syslog (szErrorString);
									EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;	
									TC_write_syslog(pcInputErrorMessage);
									EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_COND_OPTION, pcInputErrorMessage) ;
									return decision;
								}*/
									
							}
							SAFE_MEM_free(pcResult);
						}

						else if( iRetcode == ITK_ok )
						{
							decision = EPM_go;												
						}

					}
						
				}
				else if( iRetcode == ITK_ok )
				{
					decision = EPM_go;
												
				}
				SAFE_MEM_free(ptSecObjTags);	
				SAFE_MEM_free(pcSecObjType);
				SAFE_MEM_free(pcSecAttrValue);
			}
								
		}
			
	}
	else if ( iRetcode != ITK_ok )
	{				
		decision = EPM_nogo;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
		
	SAFE_MEM_free(ptAttachments);
	SAFE_MEM_free(pcTaskType);
	SAFE_MEM_free(pcGroup);
	SAFE_MEM_free(pcRole);
	SAFE_MEM_free(pcFormType);
	SAFE_MEM_free(pcAttribute);
	SAFE_MEM_free(pcObjectType);
	SAFE_MEM_free(pcValue);
	SAFE_MEM_free(pcErrMsg);
	SAFE_MEM_free(pcInputErrorMessage);
	SAFE_MEM_free(pcOption);
	return decision;
}