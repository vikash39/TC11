/*******************************************************************************
FILE        :   tiauto_ah_check_status_progression.c

DESCRIPTION :   This file contains the implementation for
                "TIAUTO-AH-check-status-progression" Custom Action Handler.
                This handler validates release status of the of the all item revisions
                for correct status progression. The handler decision will be decided based on 
				the handler argument and the progression result.
				
				This handler should be added to a conditional task.
                
AUTHOR      :   Dipak Naik, TCS

REVISION HISTORY :

Date              Revision      Who                  Description
April 14, 2010    1.0           Dipak Naik		     Initial Creation
August 10,2010	  1.1			Dipak Naik			 Modified the code to run the progression check
													 for PMR workflow
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <tiauto_progression_check_utils.h>

int executeProgressionCheck(tag_t tmsgTask, tag_t tECRev,char *pcReportDecision,
							char *pcFailDecision,char *pcEndOfWarningMsg, 
							char *szTaskNameToSendMailToOwner,char	*pcTargetReleaseStatus,
							char *pcProgressionCheckList,int iAssemblyCheckLevel, logical *lTaskResult);										
/*==================================================================
*    Implementation of ACTION Handler -  TIAUTO_AH_check_status_progression
====================================================================*/
extern int TIAUTO_AH_check_status_progression (EPM_action_message_t msg )
{
    int             iRetCode				= ITK_ok;
    int             iNumArgs				= 0; 
	int				iAssemblyProgCheckLevel	= -1;
    int				i						= 0;

	char			*szTaskNameToSendMailToOwner			 = NULL;
	char			*pcReportDecision						 = NULL;
	char			*pcFailDecision							 = NULL;
	char			*pcEndOfWarningMsg						 = NULL;
	char			*pcTargetReleaseStatus					 = NULL;
	char			*pcProgressionCheckList					 = NULL; //The value can be "ALL", ItemRev, Backward, Assembly, Generic
	char		    *pcValue								 = NULL;
    char		    *pcFlag									 = NULL;
	char			*pcErrMsg								 = NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";

	tag_t			tChangeRev		= NULLTAG;

	logical			lTaskResult		= true;

    iNumArgs = TC_number_of_arguments(msg.arguments);
  
    if (iNumArgs > 0)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 && pcValue != NULL)
				{
					if( (tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
					{
						pcReportDecision = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcReportDecision, pcValue);
					}	
					else
						iRetCode = EPM_invalid_argument;
				}
				else if( tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 && pcValue != NULL)
				{
					if( (tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
						( tc_strcasecmp(pcValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
					{
						pcFailDecision = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcFailDecision, pcValue);
					}	
					else
						iRetCode = EPM_invalid_argument;
				}				
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 && pcValue != NULL)
				{
					//The value of the argument "notification" will have the task name,
					//we need to send an email to the owner of that task 
					szTaskNameToSendMailToOwner = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( szTaskNameToSendMailToOwner, pcValue);					
				}
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 && pcValue != NULL)
				{
					pcEndOfWarningMsg = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcEndOfWarningMsg, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 && pcValue != NULL)
				{
					pcTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcTargetReleaseStatus, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 && pcValue != NULL)
				{
					pcProgressionCheckList = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcProgressionCheckList, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER7) == 0 && pcValue != NULL)
				{
					if(tc_strcasecmp(pcValue,"All") == 0)
					{
						iAssemblyProgCheckLevel = -1;
					}
					else
					{
						iAssemblyProgCheckLevel = atoi(pcValue);
					}
				}
				else
					iRetCode = EPM_invalid_argument;
			
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-check-status-progression\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;					
				}
			}
        	else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-check-status-progression\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;				
			}
		}
	}	
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }	

	//to check whether mandatory attributes are parsed or not
    if( (iRetCode == ITK_ok) && ((pcReportDecision == NULL) || (pcFailDecision == NULL)
								  || (pcEndOfWarningMsg == NULL) ) )
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}

	if( iRetCode == ITK_ok )
    {
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//Call the static function to execute the handler to do the Progression Check
			iRetCode = executeProgressionCheck( msg.task,tChangeRev,pcReportDecision,pcFailDecision,
				                                pcEndOfWarningMsg,szTaskNameToSendMailToOwner, 
												pcTargetReleaseStatus,pcProgressionCheckList,
												iAssemblyProgCheckLevel,&lTaskResult);
		}
	}
	//if there are any ITK failure
	if ( iRetCode != ITK_ok && iRetCode != EPM_invalid_argument_value)
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	//Conditional Task result decision
	if ( lTaskResult == true && iRetCode == ITK_ok)	
	{
		// When status is valid, set to true to continue the process.
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_TRUE);
	}
	if(lTaskResult == false || iRetCode != ITK_ok)
	{
		// When status is invalid, set to false - for demoting the task to application engineer.					
		iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
	}
		
	SAFE_MEM_free (pcValue);
	SAFE_MEM_free (pcFlag);	
	SAFE_MEM_free (pcReportDecision)
	SAFE_MEM_free (pcFailDecision);
	SAFE_MEM_free (pcEndOfWarningMsg);
	SAFE_MEM_free (szTaskNameToSendMailToOwner);
	SAFE_MEM_free (pcTargetReleaseStatus);
	SAFE_MEM_free (pcProgressionCheckList);

    return iRetCode;
}
																			
int executeProgressionCheck( tag_t tmsgTask, tag_t tECRev,char *pcReportDecision,
							 char *pcFailDecision, char *pcEndOfWarningMsg, 
							 char *szTaskNameToSendMailToOwner,char	*pcTargetReleaseStatus,
							 char *pcProgressionCheckList,int iAssemblyProgCheckLevel,
							 logical *lTaskResult )
{
	int			iRetCode									= ITK_ok;
    int			iNumAffected								= 0;	
    int			indx										= 0;	
	int			iError										= 0;	 
	int			iPopulateErrMsgInStack						= 1;			// for this handler, we need the error message.	
	int			iPopulateWarningMsgInStack					= 1;			// for this handler, we need the warning message.
    int			iTargetArgCount								= 0;
	int         iFileOpenErrCode                            = 0;
	
	char		szErrorString[TIAUTO_error_message_len+1]	= "";
	char		caChnId[ITEM_id_size_c+1]					= {'\0'};
	char		caChnRevId[ITEM_id_size_c+1]				= {'\0'};
	char		caChnName[ITEM_name_size_c+1]				= {'\0'};
	char		caCurrentTaskName[WSO_name_size_c+1]		= {'\0'};
	char		acRootTaskName[WSO_name_size_c+1]			= {'\0'};
	char		*pcClassName								= NULL;
    char		*pcMsgName									= NULL;
    char		*pcComments									= NULL;
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	char		*pcFormClassName							= NULL;
	char		*pcFormTypeName								= NULL;
	char		*pcAttributeName							= NULL;
	char		**pcTargetArgsTemp							= NULL;
	char		*pcTemp										= NULL;

	tag_t		*ptAffectedItems							= NULL;
	tag_t		tUser										= NULLTAG;
	tag_t		tRootTask									= NULLTAG;
	tag_t		tAttribute									= NULLTAG;
	tag_t		tFormType									= NULLTAG;

	txt_t		the_text_server								= NULL;

	logical     lIsErrorPresent								= false;
	logical		lIsWarningPresent							= false;
	logical     lIsWriteToAuditFile							= false;
	logical     lIsItemRevProgCheckRequired					= false;
	logical     lIsBackwardProgCheckRequired				= false;
	logical     lIsAssemblyProgCheckRequired				= false;
	logical     lIsGenericProgCheckRequired					= false;

	FILE		*fMailBodyFile								= NULL;

    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

	TIA_ErrorMessage *backwordProgErrMsgStack		= NULL;
	TIA_ErrorMessage *itemRevProgErrMsgStack		= NULL;
	TIA_ErrorMessage *assemblyProgWarningMsgStack	= NULL;
	TIA_ErrorMessage *assemblyProgErrMsgStack		= NULL;
	TIA_ErrorMessage *genericProgWarningMsgStack	= NULL;
	TIA_ErrorMessage *genericProgErrMsgStack		= NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectErrMsgStack = NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectWarningMsgStack = NULL;


	tiauto_initialize_status_progression_stuct(&StatusProgression); 
	iRetCode = tiauto_get_status_progression_array (&StatusProgression);
	//get the root task
	if (iRetCode == ITK_ok )
		iRetCode = EPM_ask_root_task(tmsgTask , &tRootTask);
	//get the root task name
	if (iRetCode == ITK_ok  && tRootTask != NULLTAG)
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );

    if (iRetCode == ITK_ok )
    {
		if(pcTargetReleaseStatus == NULL)
		{
			//In case if this argument value is null then the target status will be read from
			//the ERC form. (In case of old CR and CRB, this argument is not parsed. so the value will be read
			//				  from the ECR form)
			iRetCode = tiauto_get_target_release_status(tECRev, TargetReleaseStatus.szTargetReleaseStatus);
		}
		else
		{
			pcTargetArgsTemp = (char **)malloc(10* sizeof(char *));
			//In case of CR/CRB/PMR worflow the argument value willl be
			// Form:<Form type name>:<form attribute name that contaions the target status name>
			pcTemp = tc_strtok (pcTargetReleaseStatus,":");
			//to remove the forward and trailing space
			remove_forward_AND_trailing_space(pcTemp);
			if(tc_strcmp(pcTemp,"Form") == 0)
			{
				while(pcTemp != NULL)
				{
					//to remove the forward and trailing space
					remove_forward_AND_trailing_space(pcTemp);
										
					pcTargetArgsTemp[iTargetArgCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcTargetArgsTemp[iTargetArgCount],pcTemp);			
					iTargetArgCount++;					
					pcTemp = tc_strtok(NULL,":");
				}
			}
			//In case of CR/CRB/PMR worflow
			if(iTargetArgCount == 3)
			{
				//form class name i.e. "Form"
				pcFormClassName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[0])+1);
				tc_strcpy(pcFormClassName,pcTargetArgsTemp[0]);
				//form type name
				pcFormTypeName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[1])+1);
				tc_strcpy(pcFormTypeName,pcTargetArgsTemp[1]);
				//form attribute name
				pcAttributeName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[2])+1);
				tc_strcpy(pcAttributeName,pcTargetArgsTemp[2]);
				
				if(pcTargetArgsTemp != NULL)
				{
					free(pcTargetArgsTemp);
					pcTargetArgsTemp = NULL;
				} 
				//check the argument values are correct or not i.e. form type and attribute name
				iRetCode = TCTYPE_find_type (pcFormTypeName,"Form",&tFormType);
				if(iRetCode == ITK_ok && tFormType != NULLTAG)
				{
					iRetCode = TCTYPE_ask_property_by_name (tFormType,pcAttributeName,&tAttribute);
					if(iRetCode == ITK_ok && tAttribute == NULLTAG)
					{
						iRetCode = EPM_invalid_argument_value;
						TI_sprintf(szErrorString, "Invalid argument value parsed to the argument \"%s\".",ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
						TC_write_syslog(szErrorString);
					}
				}
				else if(iRetCode == ITK_ok && tFormType == NULLTAG)
				{
					iRetCode = EPM_invalid_argument_value;
					TI_sprintf(szErrorString, "Invalid argument value parsed to the argument \"%s\".",ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
					TC_write_syslog(szErrorString);
				}
				//get the target release status from the given form
				if(iRetCode == ITK_ok)
					iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tECRev,pcFormTypeName, pcAttributeName,
																		TargetReleaseStatus.szTargetReleaseStatus);
			}
			//In case of DAP, the target status will be "Study Approved"
			else if(iTargetArgCount == 0)
			{	
				//check the argument values are correct or not i.e. status type
				tFormType = NULLTAG;
				iRetCode = CR_find_status_type  (pcTargetReleaseStatus,&tFormType);
				if(iRetCode == ITK_ok && tFormType != NULLTAG)
				{
					/*if(tc_strcmp(pcTargetReleaseStatus,"Standard - Preliminary") == 0)
					{
						tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus, "T8_Standard - Preliminary");
					}
					else if(tc_strcmp(pcTargetReleaseStatus,"Standard - Released") == 0)
					{
						tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus, "T8_Standard - Released");
					}
					else*/
						tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus, pcTargetReleaseStatus);
				}
				else if(iRetCode == ITK_ok && tFormType == NULLTAG)
				{
					iRetCode = EPM_invalid_argument_value;
					TI_sprintf(szErrorString, "Invalid argument value parsed to the argument \"%s\".",ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
					TC_write_syslog(szErrorString);
				}
			}
			else
			{
				iRetCode = EPM_invalid_argument_value;
				TI_sprintf(szErrorString, "Invalid argument value parsed to the argument \"%s\".",ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
				TC_write_syslog(szErrorString);				
			}
			if(pcFormClassName != NULL)
			{
				free(pcFormClassName);
				pcFormClassName = NULL;
			}
			if(pcFormTypeName != NULL)
			{
				free(pcFormTypeName);
				pcFormTypeName = NULL;
			}
			if(pcAttributeName != NULL)
			{
				free(pcAttributeName);
				pcAttributeName = NULL;
			}
			if(iRetCode != ITK_ok)
			{				 
				return iRetCode;
			}
		}
		if(iRetCode == ITK_ok)
		{
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			if (TargetReleaseStatus.iLevel == -1)
			{
				TI_sprintf(szErrorString,"%s", TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT);
				iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
				EMH_store_error_s1( EMH_severity_error, iRetCode, 
					                TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT) ;
				TC_write_syslog(szErrorString);
			}
		}
		else
		{
			TI_sprintf(szErrorString, "Failed to verify Target Release Status with the site Preference \"TI_Progression_Path\". \n");
			EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;	
			TC_write_syslog(szErrorString);
		}
	}

	if(iRetCode == ITK_ok && pcProgressionCheckList == NULL)
	{
		lIsItemRevProgCheckRequired	= true;
		lIsBackwardProgCheckRequired = true;
		lIsAssemblyProgCheckRequired = true;
		lIsGenericProgCheckRequired	= true;
	}
	else if(iRetCode == ITK_ok)
	{
		if(tc_strstr(pcProgressionCheckList,"All") != NULL)
		{
			lIsItemRevProgCheckRequired	= true;
			lIsBackwardProgCheckRequired = true;
			lIsAssemblyProgCheckRequired = true;
			lIsGenericProgCheckRequired	= true;
		}
		if(tc_strstr(pcProgressionCheckList,"ItemRev") != NULL)
		{
			lIsItemRevProgCheckRequired	= true;
		}
		if(tc_strstr(pcProgressionCheckList,"Backward") != NULL)
		{			
			lIsBackwardProgCheckRequired = true;
		}
		if(tc_strstr(pcProgressionCheckList,"Assembly") != NULL)
		{
			lIsAssemblyProgCheckRequired = true;
		}
		if(tc_strstr(pcProgressionCheckList,"Generic") != NULL)
		{
			lIsGenericProgCheckRequired	= true;
		}
	}
	//get all the item revisions present in the "Affected and Solution Items" folder
	if (iRetCode == ITK_ok)
	{
		iRetCode = ECM_get_affected_items(tECRev, &iNumAffected, &ptAffectedItems);
	}
	
	for (indx = 0; (indx < iNumAffected) && (iRetCode == ITK_ok); indx++)
	{	
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pcClassName);
		if((iRetCode == ITK_ok) && (tc_strcasecmp (pcClassName , "Dataset")!= 0 )&& (tc_strcasecmp (pcClassName , "ItemRevision")!= 0 ))
		{
			tag_t tTargetType = NULLTAG;
			tag_t	tParentType					= NULLTAG;
			TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType));
			if(tTargetType != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));

			if(tParentType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pcClassName));
			}					
			
		}

		if((iRetCode == ITK_ok)  &&( (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
        {
			if(lIsBackwardProgCheckRequired == true)
			{
				//Backward progression check 	 
				iRetCode = ti_check_for_backward_progression ( ptAffectedItems[indx],ptAffectedItems,iNumAffected, StatusProgression, 
															   TargetReleaseStatus, iPopulateErrMsgInStack,
																&iError, &backwordProgErrMsgStack );
			}
		
			if ( iRetCode == ITK_ok && lIsItemRevProgCheckRequired == true)
			{
				//item revision progression
				iRetCode = ti_check_for_item_revision_progression ( ptAffectedItems[indx], StatusProgression, 
															   TargetReleaseStatus, iPopulateErrMsgInStack, 
															   &iError, &itemRevProgErrMsgStack );
							
			}
			if ( iRetCode == ITK_ok && lIsAssemblyProgCheckRequired == true)
			{
				//assembly progression
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					iRetCode = ti_check_for_assembly_progression_pci( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															  StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														      iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															  acRootTaskName, iAssemblyProgCheckLevel,&iError, 
														      &assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
				}
				else
					iRetCode = ti_check_for_assembly_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															  StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														      iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															  acRootTaskName, iAssemblyProgCheckLevel,&iError, 
														      &assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
							
			}
			if ( iRetCode == ITK_ok && lIsGenericProgCheckRequired == true)
			{
				//generic progression
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					iRetCode = ti_check_for_generic_progression_pci( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														     StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														     iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															 acRootTaskName,&iError, 
														     &genericProgWarningMsgStack, &genericProgErrMsgStack);
				}
				else
					iRetCode = ti_check_for_generic_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														     StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														     iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															 acRootTaskName,&iError, 
														     &genericProgWarningMsgStack, &genericProgErrMsgStack);
			
			}
			
			if ( iRetCode == ITK_ok )
			{
				
				//Master Drawing Reference linked object status check
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					/*iRetCode = ti_Verify_MasterDrawingReferenceLinkedObjectStatus_pci( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression, TargetReleaseStatus,
																				iPopulateErrMsgInStack,&iError,
																				&masterDrawingReferenceObjectErrMsgStack);*/
				}
				else
				{
					iRetCode = ti_Verify_MasterDrawingReferenceLinkedObjectStatus( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression, TargetReleaseStatus,
						                                                            iPopulateWarningMsgInStack, iPopulateErrMsgInStack,&iError, &masterDrawingReferenceObjectWarningMsgStack,
																				    &masterDrawingReferenceObjectErrMsgStack,pcEndOfWarningMsg,0);
				}
			}
		}
	}	
    
	if(iRetCode == ITK_ok )
	{
		if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
			(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL) || (masterDrawingReferenceObjectErrMsgStack != NULL))
		{
			lIsErrorPresent = true;
		}
		if((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) || (masterDrawingReferenceObjectWarningMsgStack != NULL))
		{
			lIsWarningPresent = true;
		}
	}
	//for sending mail
	if(iRetCode == ITK_ok && lIsErrorPresent == false)
	{	
		//if there are no progression error and some stacked warning message are present then send e-mail
		if((szTaskNameToSendMailToOwner != NULL) && ((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) ||(masterDrawingReferenceObjectWarningMsgStack != NULL)))
		{
			TIA_ErrorMessage *tempErrMsg = NULL;				
			if(iRetCode == ITK_ok && tRootTask != NULLTAG)
				iRetCode = tiauto_getUser(tRootTask,szTaskNameToSendMailToOwner,&tUser);
			if(iRetCode == ITK_ok && tUser != NULLTAG)
			{
				iRetCode = EPM_get_user_email_addr  (  tUser,&pcEmailId )  ;
			}				
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				/* Initialize TextServer here */
				//the_text_server = txt_ctor( "iman_text.xml" );
				//pcMsgName = "User_Comments";
				//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
				//txt_destructor(the_text_server);
			}
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
				iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
			}
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				//start of body of the e-mail
				iRetCode = tiauto_getItemRevDetails(tECRev, caChnId, caChnRevId, caChnName);
				if(iRetCode == ITK_ok)
					iRetCode = EPM_ask_name(tmsgTask, caCurrentTaskName);
				if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"10_80") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
										TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS,
										TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
										TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS);
				}
				if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"13_8") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
										TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS,
										TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
										TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CRBYPASS1);
				}
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"2_153") != NULL) )
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
										TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CR,
										TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
										TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CR);
				}
				else if( (iRetCode == ITK_ok) && ( (tc_strstr(caCurrentTaskName,"10_193") != NULL) ||
						(tc_strstr(caCurrentTaskName,"13_150") != NULL)) )
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"2_481") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"6_210") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"9_60") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) && ( (tc_strstr(caCurrentTaskName,"14_30") != NULL) || 
													(tc_strstr(caCurrentTaskName,"22_30") != NULL) || 
													(tc_strstr(caCurrentTaskName,"26_30") != NULL)))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"15_1") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CAP,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CAP);
				}
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"19_1") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP);
				}
				//adding CAP3 changes
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"28_1") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_NEW_CAP);
				}
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"23_7") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_TPR,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_TPR);
				}
				else if( (iRetCode == ITK_ok) && (tc_strstr(caCurrentTaskName,"25_7") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_TER,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_TER);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"15_230") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"19_400") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"28_400") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"23_180") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				else if( (iRetCode == ITK_ok) &&(tc_strstr(caCurrentTaskName,"25_100") != NULL))
				{
					fprintf(fMailBodyFile,"\n%s \"%s\"%s %s\n",TIAUTO_BODY_OF_EMAIL_TEXT1,caCurrentTaskName, 
										TIAUTO_BODY_OF_EMAIL_TEXT5,TIAUTO_BODY_OF_EMAIL_TEXT4);
				}
				if(iRetCode == ITK_ok)
				{
					fprintf(fMailBodyFile,"\n\nWARNING MESSAGES:\n");
					tempErrMsg = assemblyProgWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
					tempErrMsg = genericProgWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
				    tempErrMsg = masterDrawingReferenceObjectWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
				}            
				//end of body of the e-mail
			}
			if(fMailBodyFile != NULL &&  tUser != NULLTAG)
			{
				fclose(fMailBodyFile);
			}	
			//subject of the e-mail
			TI_sprintf(szErrorString, "WARNING : %s/%s-%s(%s)",caChnId, caChnRevId, caChnName, 
					                                szTaskNameToSendMailToOwner);
			//send the mail
			if(pcEmailId != NULL)
				iRetCode = tiauto_sendEMail(szErrorString, pcEmailId, pcMailBodyFileName);
		}		
	}	
	//decision to write the progression failure message to audit file or not
	if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
		 (assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL)||
		 (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) || (masterDrawingReferenceObjectErrMsgStack != NULL) || (masterDrawingReferenceObjectWarningMsgStack != NULL))
	{
		
		if(	tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{
			tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
			assemblyProgWarningMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
			genericProgWarningMsgStack = NULL;
			tiauto_clearErrorMsgStack(masterDrawingReferenceObjectWarningMsgStack);
			genericProgWarningMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
			backwordProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
			itemRevProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
			assemblyProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgErrMsgStack);
			genericProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(masterDrawingReferenceObjectErrMsgStack);
			masterDrawingReferenceObjectErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(masterDrawingReferenceObjectErrMsgStack);
			masterDrawingReferenceObjectErrMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if( lIsWarningPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if( lIsErrorPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if( ( lIsWarningPresent == true) && (lIsErrorPresent == true) )
			{
				lIsWriteToAuditFile = true;
			}
			else
			{
				lIsWriteToAuditFile = false;
			}
		}
		// Writing failure reason in the workflow Audit File
		if(lIsWriteToAuditFile == true)
		{
			ti_writeErrorsMsgToAuditFile(tmsgTask,backwordProgErrMsgStack,itemRevProgErrMsgStack,
									assemblyProgErrMsgStack,genericProgErrMsgStack,
									assemblyProgWarningMsgStack,genericProgWarningMsgStack,masterDrawingReferenceObjectWarningMsgStack,masterDrawingReferenceObjectErrMsgStack);
		}
	}
	else if ( (backwordProgErrMsgStack == NULL) && (itemRevProgErrMsgStack == NULL) &&
		 (assemblyProgErrMsgStack == NULL) && (genericProgErrMsgStack == NULL)&&
		 (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) && (masterDrawingReferenceObjectErrMsgStack == NULL ) && (masterDrawingReferenceObjectWarningMsgStack == NULL))
	{
		ti_writeSuccessMsgToAuditFile( tmsgTask);
			EMH_clear_errors();
	}
   
	//to take the task decision: TRUE/FALSE
	if(iRetCode == ITK_ok )
	{
		if(	tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{			
			if(lIsErrorPresent == true)
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			if(lIsWarningPresent == true)
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if(lIsErrorPresent == true && lIsWarningPresent == false  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if(lIsErrorPresent == false && lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			if(lIsErrorPresent == true || lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if(lIsErrorPresent == true && lIsWarningPresent == true  )
			{
				*lTaskResult = false;
			}
			else
				*lTaskResult = true;
		}		
	}
	
	//free up allocated memory
    SAFE_MEM_free (StatusProgression.StatusArray);
	SAFE_MEM_free(ptAffectedItems);
	SAFE_MEM_free(pcClassName);
	//SAFE_MEM_free(pcMsgName);
	SAFE_MEM_free(pcComments);
	SAFE_MEM_free(pcEmailId);
	tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
	backwordProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
	itemRevProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
	assemblyProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgErrMsgStack);
	genericProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
	assemblyProgWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
	genericProgWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(masterDrawingReferenceObjectErrMsgStack);
	masterDrawingReferenceObjectErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(masterDrawingReferenceObjectWarningMsgStack);
	masterDrawingReferenceObjectWarningMsgStack = NULL;
	remove(pcMailBodyFileName);
	
	return iRetCode;
}

