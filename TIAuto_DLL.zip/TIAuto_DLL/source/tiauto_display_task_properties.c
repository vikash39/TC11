/*******************************************************************************
File         : tiauto_display_task_properties.c

Description  :	 code to display the runtime properties 
				"Active Task", "Responsible Party","Task Start Date"
  
Input        : None
                        
Output       : None

Author       : Nivedita Kamath,TCS

Revision History :
Date            Revision    Who					Description
Aug 13, 2010    1.0         Nivedita Kamath      Initial Creation

*******************************************************************************/


#include <tiauto_runtime_properties.h>
#include <tiauto_defines.h>
#include <sa/tcfile_cache.h>
//----------------------------------------------------------------------------
// TIAUTO_display_task_properties()
// \param  METHOD_message_t* m /*I*/
//   va_list args			/*<O>*/
// \return int
// \note Displays the runtime properties "Active Task", "Responsible Party","Task Start Date"
//-----------------------------------------------------------------------------
int TIAUTO_display_task_properties(METHOD_message_t* m, va_list args)
{

	int iFail = ITK_ok;
	char acTypename[TCTYPE_name_size_c+1];
	tag_t tTypeTag = NULLTAG;
	tag_t tNewPropTagCT = NULLTAG;
	tag_t tNewPropTagRP = NULLTAG;
    tag_t tNewPropTagSD = NULLTAG;
	METHOD_id_t method;	
	char  *pcErrMsg	= NULL;
	char acActiveTaskProp[20] = {'\0'};
	char acRespPartyProp[25] = {'\0'};
	char acTaskStartDateProp[20] = {'\0'};
	tTypeTag  = va_arg( args,tag_t);

    iFail = TCTYPE_ask_name(tTypeTag,acTypename);
    //for Active task runtime property
	//
	if(iFail == ITK_ok)
		if( tc_strcmp( acTypename, "T8_TI_ChangeRevision" )== 0)
			tc_strcpy( acActiveTaskProp, "t8_activetask");	
		else if( tc_strcmp(acTypename , "EngChange Revision") == 0)
			tc_strcpy( acActiveTaskProp, "Active Task");	

	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,acActiveTaskProp,PROP_string,
												  256,&tNewPropTagCT);

	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTagCT,"Active Task");

    //the "PROPDESC_set_protection" is obsoleted in TC8 and the 
	//Protection should be set in the Business Modeler IDE
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTagCT, PROP_read);
	

	
  	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
											  acActiveTaskProp,
                                              PROP_ask_value_string_msg,
                                              Set_prop_value_ActiveTask, 0,
                                              &method );

	//for Responsible party runtime property
	if(iFail == ITK_ok)
		if( tc_strcmp( acTypename, "T8_TI_ChangeRevision" )== 0)
			tc_strcpy( acRespPartyProp, "t8_responsibleparty");
		else if( tc_strcmp(acTypename , "EngChange Revision") == 0)
			tc_strcpy( acRespPartyProp, "Responsible Party");

	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,/*"Responsible Party"*/acRespPartyProp,PROP_string,
		                                      512,&tNewPropTagRP);

	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTagRP,"Responsible Party");

	//the "PROPDESC_set_protection" is obsoleted in TC8 and the 
	//Protection should be set in the Business Modeler IDE
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTagCT, PROP_read);
	


	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             /*"Responsible Party",*/
											  acRespPartyProp,
                                              PROP_ask_value_string_msg,
                                              Set_prop_value_ResponsiblePrty, 0,
                                              &method );
	//for Task Start Date runtime property

	if(iFail == ITK_ok)
		if( tc_strcmp( acTypename, "T8_TI_ChangeRevision" )== 0)
			tc_strcpy( acTaskStartDateProp, "t8_taskstartdate");
		else if( tc_strcmp(acTypename , "EngChange Revision") == 0)
			tc_strcpy( acTaskStartDateProp, "Task Start Date");

	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,acTaskStartDateProp,PROP_string,
		                                      256,&tNewPropTagSD);

	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTagSD,"Task Start Date");

	//the "PROPDESC_set_protection" is obsoleted in TC8 and the 
	//Protection should be set in the Business Modeler IDE
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTagCT, PROP_read);
	

	
  	/*if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             acTaskStartDateProp,
                                              PROP_ask_value_string_msg,
                                              Set_prop_value_TaskStartDate, 0,
                                              &method );*/
	if ( iFail != ITK_ok )
	{		
		EMH_ask_error_text (iFail, &pcErrMsg);
		TC_write_syslog("Error in the method : TIAUTO_display_task_properties ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return(iFail);
}

char *trimwhitespace(char *str) 
{ 
  char *end; 
 
  // Trim leading space 
  while(isspace(*str)) str++; 
 
  if(*str == 0)  // All spaces? 
    return str; 
 
  // Trim trailing space 
  end = str + strlen(str) - 1; 
  while(end > str && isspace(*end)) end--; 
 
  // Write new null terminator 
  *(end+1) = 0; 
 
  return str; 
} 
void formatDate(char *pcDate)
{
	int yy  = 0, mm  = 0, dd = 0, hr = 0, min = 0;
	time_t mTime ;
	struct tm time_struct = {0, 0, 0, 0, 0, 0, 0, 0, 0};
	char buffer [50];
	
	sscanf_s(pcDate, "%d-%d-%d %d:%d", &yy, &mm, &dd, &hr, &min );
	time_struct.tm_year = yy-1900;
	time_struct.tm_mon = mm-1;
	time_struct.tm_mday = dd;
	time_struct.tm_hour = hr;
	time_struct.tm_min = min;
	mTime = mktime(&time_struct);
	strftime (buffer,50,"%d-%b-%Y %H:%M",&time_struct);	
	tc_strcpy(pcDate, buffer);
		
}

int findStartDateFromAuditFile(tag_t tTask, char** pcStartDate)
{
	int			iFail = ITK_ok;
	int			iFlag = 0;
	char		text_line_temp[SS_MAXLLEN] ;
	char		text_line[SS_MAXLLEN] ;
	char 		*pcTaskName = NULL;
	tag_t		tJob = NULLTAG;
	tag_t		tAuditFile = NULLTAG;
	IMF_file_t  tFileDescriptor = NULL;	
	char *pcAction = NULL;
	char *pcTaskNameAuditFile = NULL;
	int i = 0, j = 0, k = 0;	
	
	*pcStartDate = (char*)MEM_alloc((int)(sizeof(char)*30));
	iFail = AOM_ask_value_string( tTask, "object_name", &pcTaskName);
	if(!iFail && pcTaskName != NULL)
		iFail = EPM_ask_job(tTask, &tJob);
	if(!iFail && tJob != NULLTAG)
		iFail = EPM_ask_audit_file(tJob, &tAuditFile);	
	if(!iFail && tAuditFile != NULLTAG)
		iFail = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
	if(!iFail && tFileDescriptor != NULL)
		iFail = IMF_open_file(tFileDescriptor,  SS_RDONLY );
	while(iFail == ITK_ok)
	{
		iFail = IMF_read_file_line( tFileDescriptor, text_line_temp );
		if( iFail == ITK_ok )
		{
			if( strlen(text_line_temp) > 0 )
			{
				if( ( (text_line_temp[0] >= 'A') && (text_line_temp[0] <= 'Z') ) || ( (text_line_temp[0] >= 'a') && (text_line_temp[0] <= 'z') ) )
				{
					pcAction = (char *)MEM_alloc ((6)*sizeof(char));					
					for( i = 0;  (i < 5) && (text_line_temp[i] != '\0'); i++)
					{
						*(pcAction + i) = *(text_line_temp + i);
					}
					*(pcAction + i) ='\0';					
					pcAction = trimwhitespace(pcAction);					
					if(tc_strcasecmp(pcAction, "Start") == 0)
					{
						k = 0;
						pcTaskNameAuditFile = (char *)MEM_alloc ((30)*sizeof(char));
						for( j=17; (j<42) && (text_line_temp[j] != '\0'); j++)
						{
							*(pcTaskNameAuditFile + k++) = *(text_line_temp + j);
						}
						*(pcTaskNameAuditFile + k) ='\0';
						pcTaskNameAuditFile = trimwhitespace(pcTaskNameAuditFile);	
						if(strstr(pcTaskName,pcTaskNameAuditFile ) != NULL)
						{
							iFlag = 1;
							tc_strcpy(text_line, text_line_temp);
						}	
						SAFE_MEM_free(pcTaskNameAuditFile);
					}
					SAFE_MEM_free(pcAction);
				}
			}
		}
	}
	SAFE_MEM_free(pcTaskName);
	if(iFlag == 1)
	{
		iFail = ITK_ok;
		k = 0;
		for(i=43 ;i<59; i++)
		{			
			*(*pcStartDate + k++) = text_line[i];
		}
		*(*pcStartDate + k) = '\0';
	}
	if(tFileDescriptor != NULL)
		IMF_close_file(tFileDescriptor);
	return iFail;
}
//----------------------------------------------------------------------------
// getActiveTaskList()
// \param	tag_t			tEcRev					/*I*/
//			tag_t*			ptTaskList				/*<O>*/
//			int*			iNumAlltasks			/*<O>*/
// \return int
// \note gets the user names of all sign-off users (for sign-offs which are yet to be completed )
// as a semi-colon seperated string
//-----------------------------------------------------------------------------
int getActiveTaskList(tag_t tEcRev,tag_t *ptTaskList,int *iNumAlltasks)
{
	int iFail = ITK_ok;
	int     iNumCurrTask = 0;
	int		iNumTasks = 0;
	int     i = 0;
	tag_t tRootTask = NULLTAG;
    tag_t*	ptCurrTaskList = NULL;	
	
	char *pcTaskTypeName = NULL;
	char  *pcErrMsg	= NULL;

    //Get the process stage list.
	iFail = AOM_ask_value_tags(tEcRev,"process_stage_list", &iNumCurrTask, &ptCurrTaskList );
		
	if(iNumCurrTask >0 &&  iFail == ITK_ok)
	{
		iFail = EPM_ask_root_task(ptCurrTaskList[0], &tRootTask);
		for(i = 0; i<iNumCurrTask && iFail == ITK_ok; i++ )
		{
			if( ptCurrTaskList[i] == tRootTask)
				continue;
			else
			{
				iFail = AOM_ask_value_string( ptCurrTaskList[i], "task_type", &pcTaskTypeName);
				// exclude select signoff/perform signoff, because the corresponding review task is already included in the list
				if(iFail == ITK_ok && (tc_strcmp(pcTaskTypeName, "EPMSelectSignoffTask") && tc_strcmp(pcTaskTypeName, "EPMPerformSignoffTask")))
				{
					ptTaskList[iNumTasks] = ptCurrTaskList[i];
					iNumTasks++;
				}
				SAFE_MEM_free (pcTaskTypeName);
			}
		}
	}
	*iNumAlltasks = iNumTasks;
	if ( iFail != ITK_ok )
	{		
		EMH_ask_error_text (iFail, &pcErrMsg);
		TC_write_syslog("Error in the method : getActiveTaskList ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return iFail;
}
//-----------------------------------------------------------------
//Set_prop_value_ActiveTask 
//						METHOD_message_t *  message
//						va_list  args
//return int
//notes:  set the runtime property "Active Task" value.
//------------------------------------------------------------------------------
int  Set_prop_value_ActiveTask( METHOD_message_t *  message, va_list  args )
{
	int ifail = ITK_ok;
	int i = 0;
	int iNumTasks = 0;

	tag_t prop_tag = va_arg(args, tag_t);
	char **value = va_arg(args, char**);

    char  pcValue[1024] = "";
	char  *pcTaskName = NULL;
	char  *pcTaskTypeName = NULL;
	char  *pcErrMsg	= NULL;

	tag_t objTag = NULLTAG;
	tag_t atTasksArray[100];
	// Logic
	// a new method "getActiveTaskList" to return the active task tags in a array of tags (excluding the root task)
	// for loop to iterate thru the tag list
	// get the task name
	// add seperaters
	// append the taskname and get the final string

	//Get the EngChange Rev tag
	METHOD_PROP_MESSAGE_OBJECT(message, objTag)
	ifail = getActiveTaskList(objTag,atTasksArray,&iNumTasks);
	if(iNumTasks > 0)
	{
		tc_strcpy(pcValue,"");
		for(i = 0 ;i<iNumTasks && ifail == ITK_ok;i++)
		{
			if( ifail == ITK_ok && atTasksArray[i] != NULLTAG )
				ifail = AOM_ask_name(atTasksArray[i],&pcTaskName);
			if( ifail == ITK_ok )
				ifail = AOM_ask_value_string( atTasksArray[i], "task_type", &pcTaskTypeName);
			if(ifail == ITK_ok && ((tc_strcmp(pcTaskTypeName, "EPMReviewTask") == 0)|| (tc_strcmp(pcTaskTypeName, "EPMAcknowledgeTask") == 0)))
			{
				tc_strcat(pcValue,"[");
				tc_strcat(pcValue,pcTaskName);
				tc_strcat(pcValue,"]");
				if( i != (iNumTasks-1) )
					tc_strcat(pcValue,";");	
			}
			else
			{
				tc_strcat(pcValue,pcTaskName);
				if( i != (iNumTasks-1) )
					tc_strcat(pcValue,";");	
			}
			SAFE_MEM_free (pcTaskTypeName);
		}
	}
		
	if(tc_strcmp(pcValue,"") != 0)
	{
		*value = MEM_alloc ((int) tc_strlen(pcValue)+1 );	
		tc_strcpy(*value,pcValue);
	}
	
	SAFE_MEM_free(pcTaskName);	
	if ( ifail != ITK_ok )
	{		
		EMH_ask_error_text (ifail, &pcErrMsg);
		TC_write_syslog("Error in the method : Set_prop_value_ActiveTask ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return ifail;
}


//----------------------------------------------------------------------------
// getSignoffUsers()
// \param  tag_t		 tSignoff					/*I*/
//		   char**		 pcSignOffusers				/*<OF>*/
// \return int
// \note gets the user names of all sign-off users (for sign-offs which are yet to be completed )
// as a semi-colon seperated string
//-----------------------------------------------------------------------------
int getSignoffUsers(tag_t tSignoff,char **pcSignOffusers)
{
	int iSts = ITK_ok;
	int iSubTaskCnt = 0;
	int isubTaskIndx = 0;
	int iAttchIndx=0;
	int iNumAttachs = 0;
	int iNoDecisionMadeIndex = 0;
	int iNoDecisionCnt = 0;
	tag_t	*ptSubTasks = NULL;
	tag_t   *ptAttachsTagList = NULL;
	tag_t  tResponsible = NULLTAG;
	tag_t tGroupMember = NULLTAG;
	tag_t tUserTag     = NULLTAG;
	char *pcUserId = NULL;
	char  *pcErrMsg	= NULL;

	// get the sub tasks of the review task
	iSts = EPM_ask_sub_tasks( tSignoff, &iSubTaskCnt, &ptSubTasks );
	if( iSts == ITK_ok && ptSubTasks != NULL )
	{
		for( isubTaskIndx; isubTaskIndx < iSubTaskCnt && iSts == ITK_ok; isubTaskIndx++  )
		{
			char* pcSubTaskType = NULL;
			iSts = AOM_ask_value_string( ptSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
			// check if sub-task is the select sign-off task
			if( iSts == ITK_ok && pcSubTaskType != NULL && 
				(tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
			{	
				// get the signoff attachments from the select-signoff task
				if( iSts == ITK_ok && ptSubTasks[isubTaskIndx] != NULLTAG)
				{
					iSts = EPM_ask_attachments (ptSubTasks[isubTaskIndx], EPM_signoff_attachment , &iNumAttachs, &ptAttachsTagList);
				}
				//If the attachemnts are zero it means the sign off selection is not yet done
				//hence get the responsible party of the review task.
				*pcSignOffusers = malloc(((iNumAttachs+1)*129)*sizeof(char));
				tc_strcpy(*pcSignOffusers,"");
				// if there is no sign-off attachment, then get the responsible party
				if(iNumAttachs == 0)
				{
					iSts = EPM_ask_responsible_party(tSignoff,&tResponsible);
					if(iSts == ITK_ok && tResponsible!= NULLTAG)
					{
						iSts = AOM_ask_name(tResponsible,&pcUserId);
						tc_strcat(*pcSignOffusers,pcUserId);
                    }
				}
				// if there is sign-off attachment, then get the user name from the sign-off attachment
				else if(iNumAttachs >0)
				{
					// get the no.of sign-off for which decision is already made
					iNoDecisionCnt = 0;
					for(iAttchIndx=0; iAttchIndx < iNumAttachs && iSts == ITK_ok; iAttchIndx++)
					{
						if( iSts == ITK_ok && ptAttachsTagList != NULL)
						{
							int iSignOffDecision = -1;
							iSts = AOM_ask_value_int(ptAttachsTagList[iAttchIndx], "decision", &iSignOffDecision);
							if( iSts == ITK_ok && iSignOffDecision == CR_no_decision)
							{
								iNoDecisionCnt++;
							}
						}
					}
					iNoDecisionMadeIndex = 0;
					for(iAttchIndx=0; iAttchIndx < iNumAttachs && iSts == ITK_ok; iAttchIndx++)
					{
						if( iSts == ITK_ok && ptAttachsTagList != NULL)
						{
							int iSignOffDecision = -1;
							iSts = AOM_ask_value_int(ptAttachsTagList[iAttchIndx], "decision", &iSignOffDecision);
							// if sign-off decision is not yet made, then include the user names in the o/p list
							// else ignore the user name
							if( iSts == ITK_ok && iSignOffDecision == CR_no_decision)
							{
								iNoDecisionMadeIndex++;
								iSts = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
								if( iSts == ITK_ok && tGroupMember != NULLTAG)
									iSts = AOM_ask_value_tag(tGroupMember, "user", &tUserTag);
								if( iSts == ITK_ok && tUserTag != NULLTAG )
									iSts = AOM_ask_value_string( tUserTag, "user_name", &pcUserId );
								if( iSts == ITK_ok)
								{
									tc_strcat(*pcSignOffusers,pcUserId);
									if(iNoDecisionMadeIndex < iNoDecisionCnt )
										tc_strcat(*pcSignOffusers,";");
								}
							}
						}
					}
				}				
			}
		}	
	}
	SAFE_MEM_free(pcUserId);
	SAFE_MEM_free(ptAttachsTagList);
	SAFE_MEM_free(ptSubTasks);
	if ( iSts != ITK_ok )
	{		
		EMH_ask_error_text (iSts, &pcErrMsg);
		TC_write_syslog("Error in the method : getSignoffUsers ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return iSts;

}


//------------------------------------------------------------------------------
//Set_prop_valueResponsiblePrty
//						METHOD_message_t *  message
//						va_list  args
//return int
//notes:  set the runtime property "Responsible Party" value.
//------------------------------------------------------------------------------
int  Set_prop_value_ResponsiblePrty( METHOD_message_t *  message, va_list  args )
{
	int ifail = ITK_ok;
	int i     = 0;
	int iNumTasks = 0;
	
	tag_t prop_tag = va_arg(args, tag_t);
	char **value = va_arg(args, char**);

    char  pcFinalUserList[7200] = "";
	char  *pcTaskTypeName = NULL;
	char  *pcSignoffusers  = NULL;
	char *pcResp = NULL;
	char  *pcErrMsg	= NULL;
	tag_t objTag = NULLTAG;
	tag_t tResponsible = NULLTAG;
	tag_t atTasksArray[100];

	// get the EC rev
	METHOD_PROP_MESSAGE_OBJECT(message, objTag)
	// call the method to get the active task excluding root task
	ifail = getActiveTaskList(objTag,atTasksArray,&iNumTasks);
	// for loop for the active task list
	for(i = 0 ;i<iNumTasks && ifail == ITK_ok ;i++)
	{
		// check if task is Review/acknowledge
		ifail = AOM_ask_value_string( atTasksArray[i], "task_type", &pcTaskTypeName);
		if(ifail == ITK_ok && ((tc_strcmp(pcTaskTypeName, "EPMReviewTask") == 0)|| (tc_strcmp(pcTaskTypeName, "EPMAcknowledgeTask") == 0)))
		{
			ifail = getSignoffUsers(atTasksArray[i],&pcSignoffusers);
			tc_strcat(pcFinalUserList,"[");	
			tc_strcat(pcFinalUserList,pcSignoffusers);
			tc_strcat(pcFinalUserList,"]");	
			if( i != (iNumTasks-1) )
				tc_strcat(pcFinalUserList,";");	
		}
		else 
		{
			ifail = EPM_ask_responsible_party(atTasksArray[i],&tResponsible);
			if(ifail == ITK_ok && tResponsible!= NULLTAG)
			{
				ifail = AOM_ask_name(tResponsible,&pcResp);
				tc_strcat(pcFinalUserList,pcResp);
				if( i != (iNumTasks-1) )
					tc_strcat(pcFinalUserList,";");	
			}
		}
		SAFE_MEM_free (pcTaskTypeName);
		SAFE_MEM_free(pcResp);
		if( pcSignoffusers != NULL )
		{
			free(pcSignoffusers);
			pcSignoffusers = NULL;
		}

	}
	// set the final string to the runtime property
	if(tc_strcmp(pcFinalUserList,"") != 0)
	{
		*value = MEM_alloc ( (int)tc_strlen(pcFinalUserList)+1 );	
		tc_strcpy(*value,pcFinalUserList);
	}
	if ( ifail != ITK_ok )
	{		
		EMH_ask_error_text (ifail, &pcErrMsg);
		TC_write_syslog("Error in the method : Set_prop_value_ResponsiblePrty ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return ifail;
}

//-----------------------------------------------------------------
//Set_prop_value_TaskStartDate 
//						METHOD_message_t*	message
//						va_list				args
//return int
//notes:  set the runtime property "Task Start Date" value.
//------------------------------------------------------------------------------
//int  Set_prop_value_TaskStartDate( METHOD_message_t*  message, va_list  args )
//{
//	int ifail = ITK_ok;
//	int i = 0;
//	int iNumTasks = 0;
//
//	tag_t prop_tag = va_arg(args, tag_t);
//	char **value = va_arg(args, char**);
//
//    char  pcValue[256] = "";
//	char  *pcDate = NULL;
//	char  *pcTaskTypeName = NULL;
//	tag_t objTag = NULLTAG;
//	tag_t atTasksArray[100];
//	char  *pcErrMsg	= NULL;
//	//Get the EngChange Rev tag
//	METHOD_PROP_MESSAGE_OBJECT(message, objTag)
//	// get the active task list
//	ifail = getActiveTaskList(objTag,atTasksArray,&iNumTasks);
//	if(iNumTasks > 0)
//	{
//		tc_strcpy(pcValue,"");
//		for(i = 0 ; i<iNumTasks && ifail == ITK_ok; i++)
//		{
//			//get the last modified date of the task
//			if( ifail == ITK_ok && atTasksArray[i] != NULLTAG )
//				ifail = findStartDateFromAuditFile(atTasksArray[i],&pcDate );
//			if (ifail != ITK_ok || pcDate == NULL || tc_strlen(pcDate) <= 0 )
//				ifail = AOM_UIF_ask_value(atTasksArray[i],"last_mod_date",&pcDate);
//			else
//				formatDate(pcDate);
//			if( ifail == ITK_ok )
//				ifail = AOM_ask_value_string( atTasksArray[i], "task_type", &pcTaskTypeName);
//			if(ifail == ITK_ok && ((tc_strcmp(pcTaskTypeName, "EPMReviewTask") == 0)|| (tc_strcmp(pcTaskTypeName, "EPMAcknowledgeTask") == 0)))
//			{
//				tc_strcat(pcValue,"[");	
//				tc_strcat(pcValue,pcDate);
//				tc_strcat(pcValue,"]");	
//				if( i != (iNumTasks-1) )
//					tc_strcat(pcValue,";");
//			}
//			else
//			{
//				tc_strcat(pcValue,pcDate);
//				if( i != (iNumTasks-1) )
//					tc_strcat(pcValue,";");
//			}
//			SAFE_MEM_free (pcTaskTypeName);
//			SAFE_MEM_free(pcDate);	
//		}
//	}
//	if(tc_strcmp(pcValue,"") != 0)
//	{
//		*value = MEM_alloc ( (int)tc_strlen(pcValue)+1 );	
//		tc_strcpy(*value,pcValue);
//	}	
//	if ( ifail != ITK_ok )
//	{		
//		EMH_ask_error_text (ifail, &pcErrMsg);
//		TC_write_syslog("Error in the method : Set_prop_value_TaskStartDate ");
//		TC_write_syslog(pcErrMsg);
//		SAFE_MEM_free (pcErrMsg);
//	}
//	return ifail;
//}




