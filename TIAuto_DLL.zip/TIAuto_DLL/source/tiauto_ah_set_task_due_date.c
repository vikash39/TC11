/*******************************************************************************
File         : TIAUTO_AH_set_task_due_date.c

Description  : To set due date for a specific task
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 08, 2016    1.0        Kantesh		   Initial Creation
/*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

#define DATE_size_c                  20

void DatePlusDays( struct tm* date, int days );

int taskDueDateCalculation(char* taskStartDate, int days, char	taskDueDate[DATE_size_c])
{
	int				iRetCode			= ITK_ok;	
	char			strDate[BUFSIZ+1],
					strYear[BUFSIZ+1],
					strMonth[BUFSIZ+1],
					strDay[BUFSIZ+1],
					strhour[BUFSIZ+1],
					strmin[BUFSIZ+1];
	struct tm		tmTaskStartedTime;
	logical         date_is_valid;
		
	tc_strcpy(strDate, taskStartDate);

	if(tc_strcasecmp(strDate, "") != 0)
	{
		tc_strcpy(strDay, tc_strtok(strDate, "-"));
		tc_strcpy(strMonth, tc_strtok(NULL, "-"));
		tc_strcpy(strYear, tc_strtok(NULL, " "));
		tc_strcpy(strhour, tc_strtok(NULL, ":"));
		tc_strcpy(strmin, tc_strtok(NULL, " "));
	}	

	tmTaskStartedTime.tm_mday=atoi(strDay);
	tmTaskStartedTime.tm_mon=(atoi(strMonth)-1);
	tmTaskStartedTime.tm_year=(atoi(strYear)- 1900);
	tmTaskStartedTime.tm_hour=atoi(strhour);
	tmTaskStartedTime.tm_min=atoi(strmin);
	tmTaskStartedTime.tm_sec=0;
	tmTaskStartedTime.tm_isdst=0;
	tmTaskStartedTime.tm_wday=0;
	tmTaskStartedTime.tm_yday=0;

	DatePlusDays( &tmTaskStartedTime, days ) ; 
	strftime(taskDueDate,DATE_size_c,"%d-%b-%Y %H:%M", &tmTaskStartedTime);

	return iRetCode;
}

void DatePlusDays( struct tm* date, int days )
{
    const time_t ONE_DAY = 24 * 60 * 60 ;

    time_t date_seconds = mktime( date ) + (days * ONE_DAY) ;

    *date = *localtime( &date_seconds );
}

extern int t1aAUTO_AH_set_task_due_date(EPM_action_message_t msg)
{
	int	    iRetCode							= ITK_ok;
	int		value								= 0;
	date_t	dTaskDueDate						= NULLDATE;

	char	taskStartDate[DATE_size_c+1]		= "";
	char	taskDueDate[DATE_size_c+1]			= "";

	time_t now = time(NULL);
	strftime(taskStartDate, DATE_size_c, "%d-%m-%Y %H:%M", localtime(&now));

	
	iRetCode = PREF_ask_int_value("TI_set_task_due_date", 0, &value);
	if(iRetCode == ITK_ok && value != 0)
	{
		iRetCode = taskDueDateCalculation(taskStartDate,value,taskDueDate);
	
		if(iRetCode == ITK_ok && taskDueDate != NULL)
		{
			iRetCode = ITK_string_to_date(taskDueDate, &dTaskDueDate);
		
			if(iRetCode == ITK_ok)
			{
				iRetCode = EPM_set_task_due_date(msg.task, dTaskDueDate);
			}
		}
	}						
	return iRetCode;
}