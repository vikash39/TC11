/*******************************************************************************
FILE        :   tiauto_check_cro_items.c

DESCRIPTION :   This file contains the implementation for 
                "TIAUTO-check-cro-items" Custom Rule Handler. This rule handler validates the
				item revisions in the �Affected Items� and the �Solutions Items� folders of the
				target change revision. It validates the item revision by checking the type of 
				the item revision. The valid list of item revision type is read from the LOV in
				Teamcenter database. If the item revision does not belong to any of the type name
				mentioned in LOV, then the rule handler throws appropriate error message to the user.
				Incase of multiple error message all the error message will be consolidated and 
				displayed in a single error dialog. 

AUTHOR      :   Rajesh Natesan, TCS

Revision History :
Date            Revision    Who              Description
Jan 16, 2009    1.0        Rajesh Natesan  Initial Creation
Mar 17, 2009    1.1		   Dipak  Naik	   Modified the code.

*******************************************************************************/
/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


EPM_decision_t t1aAUTO_check_cro_items(EPM_rule_message_t msg)
{
    int		iFail							= ITK_ok;
	int		indx							= 0;
	int		iNumArgs						= 0;
	int		iNumAttachments					= 0;
	int		iAttachmentIndex				= 0;
	int		iNumAffected					= 0;
	int		iAffCntr						= 0;

    logical	lIsValidItemrevType				= false;
	logical	lValidationFailed				= false;

	tag_t   tRootTask						= NULLTAG;
	tag_t   tEngChangeRev					= NULLTAG;

	tag_t*	ptAttachments					= NULL;
	tag_t*	ptAffectedItems					= NULL;
	tag_t   tObjectType						= NULLTAG;
	tag_t	tParentType						= NULLTAG; 


	char	acErrorString[512]				= "";
	char	acTargetType[WSO_name_size_c+1]	= "";
	char	acItemRevType[WSO_name_size_c+1]= "";
	char	acParentType[TCTYPE_name_size_c+1] = "";


    char*	pcArgName						= NULL;
	char*	pcLOVName						= NULL;
	char*	pcClassName						= NULL;
	char*	pcErrMsg						= NULL;
	char*	pcItemRevName					= NULL;
	char*	pcTargetTypeName				= NULL;
	char*	pcArgValue						= NULL;

    STRING_Array_Struct_t stLovValues;
	TIA_ErrorMessage *pstCurrErrMsg = NULL;

    EPM_decision_t decision = EPM_nogo;

	stLovValues.iCount = 0;
	stLovValues.ValueArray = NULL;

	/* get the arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);

	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,"EngChange Revision");

	/* validate the handler arguments */
    if ( iNumArgs == 1 ||  iNumArgs == 2)
	{
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iFail = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if ( iFail == ITK_ok ) 
			{
		
				if( iFail == ITK_ok && tc_strcmp(pcArgName, CHECK_CRO_LOV_ARG_NAME ) == 0)
				{
					pcLOVName = (char*) MEM_alloc(tc_strlen(pcArgValue) * sizeof(char));
					tc_strcpy(pcLOVName,pcArgValue);
					/* get the LOV mentioned in the argument and its values */
					iFail = tiauto_get_lov_values( pcLOVName, &stLovValues  );
				}
				else if( iFail == ITK_ok && tc_strcmp(pcArgName, "target_type" ) == 0)
				{
					tc_strcpy( pcTargetTypeName, pcArgValue);
				}
				/* if the argument mentioned is not "lov" */
				else
					iFail = EPM_invalid_argument;
			}
		}
	}
	
	/* if argument is not mentioned in the rule handler */
	else if ( iNumArgs < 1 )
		iFail = EPM_missing_req_arg;

	/* if more than one argument mentioned in the rule handler */
	else if( iNumArgs > 1 )
		iFail = EPM_wrong_number_of_arguments;

	/* get the root task */
	if( iFail == ITK_ok )
		iFail = EPM_ask_root_task(msg.task , &tRootTask);

	/* get the target attachment */
	if (iFail == ITK_ok)
		iFail = EPM_ask_attachments(tRootTask,EPM_target_attachment, &iNumAttachments,&ptAttachments);

	for (iAttachmentIndex = 0; iAttachmentIndex < iNumAttachments && (iFail == ITK_ok); iAttachmentIndex++)
	{
		if (iFail == ITK_ok && ptAttachments[iAttachmentIndex] != NULLTAG )
				iFail = WSOM_ask_object_type(ptAttachments[iAttachmentIndex], acTargetType);   
		if(tc_strcasecmp( acTargetType , pcTargetTypeName)== 0 && (iFail == ITK_ok) )
		{
			tEngChangeRev = ptAttachments[iAttachmentIndex];

			/* get the objects in the solution and the affected items folder */
			iFail = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);

			for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iFail == ITK_ok) ; iAffCntr++)
			{
				/* get the classname of the objects inside affected
						and solution items folder*/
				if (iFail == ITK_ok && ptAffectedItems[iAffCntr] != NULLTAG )
					iFail = tiauto_get_class_name_of_instance (ptAffectedItems[iAffCntr], &pcClassName);

				//getting parent class if the class name is not ITEMREVISION
				if(iFail==ITK_ok && (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)!= 0))
				{
					
					tag_t			tTargetType						= NULLTAG;
					tag_t			tParentType						= NULLTAG;

					if(iFail == ITK_ok)
					{
						TIAUTO_ITKCALL(iFail,TCTYPE_ask_object_type(ptAffectedItems[iAffCntr],&tTargetType));
					}
					if(tTargetType != NULLTAG)
					{
						TIAUTO_ITKCALL(iFail,TCTYPE_ask_parent_type(tTargetType,&tParentType));
					}
					if(tParentType != NULLTAG)
					{
						SAFE_MEM_free(pcClassName);
						TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tParentType, &pcClassName));
					}	
				}

				/* check if the classname of the object inside affected and 
						solution items folder is ItemRevision */
				if((iFail == ITK_ok)  && (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcasecmp (pcClassName ,TIAUTO_TI_DOCUMENTREVISION)== 0))
				{
					/* get the object type */
					iFail = TCTYPE_ask_object_type(ptAffectedItems[iAffCntr], &tObjectType );
					/* get the parent type tag*/
					if (iFail == ITK_ok)
						iFail = TCTYPE_ask_parent_type(tObjectType, &tParentType);
					/* get the parent type name*/
					if (iFail == ITK_ok)
						iFail = TCTYPE_ask_name(tParentType, acParentType);
					/* validate the item revision */
					if((tc_strcasecmp (acParentType , ITEM_REV)== 0) &&(iFail == ITK_ok ))
					{
						iFail = WSOM_ask_object_type( ptAffectedItems[iAffCntr], acItemRevType );
						if (iFail == ITK_ok)
							tiauto_is_value_available_in_list(stLovValues,acItemRevType, &lIsValidItemrevType );
					}
					else if((tc_strcasecmp (acParentType , OEM_REV)== 0) && (iFail == ITK_ok ))
					{
						iFail = WSOM_ask_object_type( ptAffectedItems[iAffCntr], acItemRevType );
						tiauto_is_value_available_in_list(stLovValues,acParentType, &lIsValidItemrevType );
					}
					else if(iFail == ITK_ok )
					{
						iFail = WSOM_ask_object_type( ptAffectedItems[iAffCntr], acItemRevType );
						if (iFail == ITK_ok)
							tiauto_is_value_available_in_list(stLovValues,acItemRevType, &lIsValidItemrevType );
					}
					if( iFail == ITK_ok )
						iFail = tiauto_get_itemrev_name( ptAffectedItems[iAffCntr], &pcItemRevName );

					/* if its not valid item revision type */
					if( iFail == ITK_ok  && lIsValidItemrevType == false)
					{
								lValidationFailed = true;
								TI_sprintf( acErrorString, "Error: The type %s of item revision %s is not allowed in this workflow", acItemRevType, pcItemRevName   );									
								tiauto_writeErrorMsgToStack(&pstCurrErrMsg, TIAUTO_CHECK_CRO_ITEMS_ERROR, acErrorString);
					}
				}
				SAFE_MEM_free(pcClassName);
				SAFE_MEM_free(pcItemRevName);
			}
			/* only the first target change revision should be processed */
			break;
		}
	}

	/* if ITK error during the handler exceution */
    if(iFail != ITK_ok )
	{
		decision = EPM_nogo;
		if( iFail == TIAUTO_SPECIFIED_LOV_NOT_FOUND )
		{
			TI_sprintf (acErrorString," LOV \"%s\" mentioned in the rule handler is not found in Teamcenter. \n Please contact system administrator to fix the problem.", pcLOVName);
			TC_write_syslog (acErrorString);
			EMH_store_error_s1(EMH_severity_error, TIAUTO_SPECIFIED_LOV_NOT_FOUND, acErrorString);
		}
		else
		{
			EMH_ask_error_text(iFail, &pcErrMsg );
			EMH_store_error_s1(EMH_severity_error,iFail,pcErrMsg);
			SAFE_MEM_free (pcErrMsg);
		}
	}
	/* if successfully executed and validation did not fail */
    else
        decision = EPM_go;
	
	/* if the validation failed */
	if( lValidationFailed == true )
	{
		decision = EPM_nogo;
		iFail = TIAUTO_CHECK_CRO_ITEMS_ERROR;
		TI_sprintf( acErrorString, "To fix this problem, Please remove all the item revisions which are not allowed from the Affected and Solutions items folder"  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_CHECK_CRO_ITEMS_ERROR, acErrorString );
		while(pstCurrErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, pstCurrErrMsg->iRetCode, pstCurrErrMsg->errMsg);
			TC_write_syslog(pstCurrErrMsg->errMsg);
			TC_write_syslog("\n");
         	pstCurrErrMsg = pstCurrErrMsg->next;
		}
	}

	SAFE_MEM_free (pcArgName);
    SAFE_MEM_free (pcLOVName);
	SAFE_MEM_free (stLovValues.ValueArray);
	SAFE_MEM_free (ptAttachments);
	SAFE_MEM_free (ptAffectedItems);
    return decision;
}
