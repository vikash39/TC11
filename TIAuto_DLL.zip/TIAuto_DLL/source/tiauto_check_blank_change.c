/*******************************************************************************
FILE        :   tiauto_check_blank_change.c

DESCRIPTION :   This C file Implements the "TAUTO_check_blank_change"
				server exit which will be used to check the blank change (i.e. no item revs
				in the Affected and solution items folder of the change revision)

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
June 01, 2010    1.0        Dipak Naik		 Initial Creation

*******************************************************************************/
/* includes */
#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>



int TAUTO_check_blank_change(void *return_value)
{
    int		iFail							= ITK_ok;
	int		iNumAffected					= 0;
	tag_t	tTask						= NULLTAG;
	tag_t	tECRev						= NULLTAG;
	tag_t	tTaskTemplate				= NULLTAG;
	tag_t	tHandler					= NULLTAG;
	tag_t	*ptAffectedItems			= NULL;
	
	/* get the task tag */
	iFail = USERARG_get_tag_argument(&tTask);
	if( iFail == ITK_ok && tTask != NULLTAG)
	{
		/* get the task template */
		iFail = AOM_ask_value_tag  ( tTask,"task_template" ,&tTaskTemplate);
		if(iFail == ITK_ok && tTaskTemplate != NULLTAG)
			iFail = EPM_find_handler(tTaskTemplate,EPM_action_handler_type,EPM_complete_action,"TIAUTO-AH-check-blank-change",&tHandler);
		if(iFail == ITK_ok && tHandler!= NULLTAG)
		{
			/* get the change revision */
			iFail = tiauto_get_change_item_rev (tTask, &tECRev);
			/* get the affected and solution item revs of the change revision*/
			if (iFail == ITK_ok && tECRev != NULLTAG)
			{
				iFail = ECM_get_affected_items(tECRev, &iNumAffected, &ptAffectedItems);
				/* If there are no item revisions in the Affected and Solution items folder
					of the change revision, then return the error code */
				if (iFail == ITK_ok && iNumAffected == 0)
				{
					iFail = TIAUTO_BLANK_CHANGE;
					EMH_store_error_s1(EMH_severity_error,TIAUTO_BLANK_CHANGE,"");
				}
			}
		}
	}
	
	SAFE_MEM_free(ptAffectedItems);

    return iFail;
}