/*******************************************************************************
File         : tiauto_ah_create_toolnote_item.c

Description  : This will create the tool note item and will ceate the ets request
				to update the ToolNote mapping file and generate the PDF for same.

Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                 Description
*******************************************************************************
26-Mar-2013    1.0        Dipak Naik			Initial Creation
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TAUTO_AH_Create_ToolNote_Item(EPM_action_message_t msg)
{
	int			iFail = ITK_ok;
		
	return iFail;
}
