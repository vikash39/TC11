/*******************************************************************************
File         : tiauto_ah_attach_related_primary_object.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------
Feb 06, 2013    1.0         Dipak Naik		Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TIAUTO_ah_attach_related_primary_object(EPM_action_message_t msg)
{
	int		iRetCode									= ITK_ok;
	int		iNumArgs									= 0;
	int     iNumAffected								= 0;
	int		i											= 0;
	int		iTypeNameCount								= 0;
	int		iCheck										= 0;
	int		iAttachmnetType								= EPM_target_attachment;
	int		iNumAttachments								= 0;

	char	acParentType[TCTYPE_name_size_c+1]			=	 "";
	char    acErrorString[TIAUTO_error_message_len+1]	=	 "";
	char	caTargetClass[TCTYPE_class_name_size_c+1]   = "";
	char			caObjectType[WSO_name_size_c+1]				= "";	

	char	*pcArgValue									= NULL;
    char	*pcArgName									= NULL;
	char	*pcErrMsg									= NULL;
	char	*pcTargetObjectType							= NULL;
	char	*pcRelationName								= NULL;
	char	*pcPrimaryObjectType						= NULL;
	char	*pcTemp										= NULL;
	char	*pcTemp1									= NULL;
	char	**pcPrimaryObjectTypes						= NULL;

    tag_t	tCurrentTask								= NULLTAG;
    tag_t	tRootTask									= NULLTAG;
	tag_t   tObjType									= NULLTAG;
	tag_t	tParentObjectType							= NULLTAG;
	tag_t   tTargetObject								= NULLTAG;
	tag_t	tRelation									= NULLTAG;
	tag_t	tTargetType									= NULLTAG;

	tag_t   *ptPrimaryObjects							= NULL;
	tag_t	*ptAttachments								= NULL;

	tCurrentTask = msg.task;
	iRetCode = EPM_ask_root_task(tCurrentTask,&tRootTask);
	/* get the number of arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);
	if( (iNumArgs == 2) || (iNumArgs == 3))
	{
		for( i = 0;i < iNumArgs;i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if( ( iRetCode == ITK_ok ) && (pcArgName != NULL) && (pcArgValue != NULL) )
			{
			   
				if(tc_strcasecmp(pcArgName, "target_type") == 0)
				{
				    //Initialising memory for the comma separated query names.
			        pcTargetObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
                    tc_strcpy( pcTargetObjectType, pcArgValue);
					
				}
				else if(tc_strcasecmp(pcArgName, "relation_name") == 0)
				{
					pcRelationName = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcRelationName, pcArgValue);
				}				
				else if(tc_strcasecmp(pcArgName, "primary_type") == 0)
				{
					pcPrimaryObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcPrimaryObjectType, pcArgValue);
				}
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
			else
			{						
				iRetCode = EPM_invalid_argument;			
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	//check the mandatory argument check
	if(iRetCode == ITK_ok && ((pcTargetObjectType ==NULL) || (pcRelationName == NULL)) )
	{
		iRetCode = EPM_invalid_argument_value;
	}

    if(iRetCode == 0)
    {
		iRetCode = get_target_object(msg.task,pcTargetObjectType,&tTargetObject);
		if(tTargetObject != NULLTAG)
		{
			if(pcPrimaryObjectType != NULL)
			{
				pcPrimaryObjectTypes = (char **)MEM_alloc(20* sizeof(char *));			
				pcTemp1 = (char *)MEM_alloc( ((int)tc_strlen(pcPrimaryObjectType)) * sizeof(char));
				tc_strcpy(pcTemp1,pcPrimaryObjectType);
				pcTemp = tc_strtok (pcTemp1,",");
				while(pcTemp != NULL && iRetCode == ITK_ok)
				{
					//to remove the forward and trailing space
					//remove_forward_AND_trailing_space(pcTemp);
					//validate the input argument value				
					iRetCode = TCTYPE_find_type (pcTemp,NULL,&tObjType);
					if(iRetCode == ITK_ok && tObjType != NULLTAG)
					{
						pcPrimaryObjectTypes[iTypeNameCount] = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
						tc_strcpy(pcPrimaryObjectTypes[iTypeNameCount],pcTemp);			
						iTypeNameCount++;					
						pcTemp = tc_strtok(NULL,",");
					}
					else
					{
						iRetCode = EPM_invalid_argument_value;
						TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"primary_object\".");
						EMH_store_error_s1( EMH_severity_error, iRetCode, acErrorString) ;						
						TC_write_syslog(acErrorString);
						break;
					}
				}	
			}

			if(iRetCode == ITK_ok && tTargetObject != NULLTAG && pcRelationName != NULL)
			{
				iRetCode = GRM_find_relation_type (pcRelationName,&tRelation);
				if( iRetCode == ITK_ok && tRelation != NULLTAG) 
				{
					//if there are multiple objects of same type in the target
					iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iNumAttachments, &ptAttachments);
					for(i =0;i< iNumAttachments; i++)
					{
						tTargetObject = ptAttachments[i];
						iRetCode = TCTYPE_ask_object_type(tTargetObject,&tTargetType);
						if(tTargetType != NULLTAG)
							iRetCode = TCTYPE_ask_class_name(tTargetType, caTargetClass);
						             			
						if (iRetCode == ITK_ok && ( (tc_strcmp (caTargetClass, "ItemRevision") == 0) ||
													(tc_strcmp (caTargetClass, "Form") == 0) ||
													(tc_strcmp (caTargetClass, "T8_TI_CAE_ResultRevision") == 0) ||
													(tc_strcmp (caTargetClass, "CAEResultRevision") == 0) ||
													(tc_strcmp (caTargetClass, "Dataset") == 0)) )
						{
							iRetCode = WSOM_ask_object_type(tTargetObject, caObjectType);
							if (iRetCode == ITK_ok && tc_strcmp (caObjectType, CHANGE_REV) == 0 )
							{					
								continue;
							}
						}
						/*else
						{
							continue;
						}*/

						iRetCode = GRM_list_primary_objects_only (tTargetObject,tRelation,&iNumAffected,&ptPrimaryObjects);
						for(iCheck = 0; iCheck < iNumAffected && (iRetCode == ITK_ok) ; iCheck++ )
						{
							tc_strcpy(acParentType,"");
							/* get the object type */
							iRetCode = WSOM_ask_object_type (ptPrimaryObjects[iCheck], acParentType);
							if( (iTypeNameCount > 0) && (pcPrimaryObjectType != NULL) )
							{
								if (tc_strstr(pcPrimaryObjectType,acParentType) != NULL )
								{
									//Add to the target
									iRetCode = EPM_add_attachments (tRootTask,1,&(ptPrimaryObjects[iCheck]),&iAttachmnetType);
									if(iRetCode == 33019)
									{
										iRetCode = 0;
									}
								}
								else
								{
									tc_strcpy(acParentType,"");
									tObjType = NULLTAG;
									iRetCode = TCTYPE_ask_object_type (ptPrimaryObjects[iCheck],&tObjType);
									if(tObjType != NULLTAG)
										iRetCode = TCTYPE_ask_parent_type (tObjType,&tParentObjectType);

									if(tParentObjectType != NULLTAG)
										iRetCode = TCTYPE_ask_name (tParentObjectType,acParentType);

									if(tc_strstr(pcPrimaryObjectType,acParentType) != NULL )
									{
										//add to the target
										iRetCode = EPM_add_attachments (tRootTask,1,&(ptPrimaryObjects[iCheck]),&iAttachmnetType);
										if(iRetCode == 33019)
										{
											iRetCode = 0;
										}
									}
								}
							}
						}					
						SAFE_MEM_free(ptPrimaryObjects);
					}
				}
			}
			if(pcPrimaryObjectTypes != NULL)
			{
				SAFE_MEM_free(pcPrimaryObjectTypes);
			}
		}		
	}
	/* if ITK error during the handler exceution */
    if( iRetCode != ITK_ok )
	{
		EMH_ask_error_text(iRetCode, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
		
	}
	
	return iRetCode;  
}