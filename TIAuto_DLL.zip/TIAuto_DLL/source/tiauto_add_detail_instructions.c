/*******************************************************************************
*
* FILENAME : tiauto_add_detail_instructions.c
*
* DESCRIPTION :
*      This file contains the implementation for "TIAUTO-add-detailed-instructions" Custom Action Handler. 
*
*
*
* CHANGES :
*      REF NO   DATE            WHO             DETAIL
*              09/21/2007		Srikanth P		Initial Creation for TIAUTO-create-instructions-form
*              10/22/2007       Srikanth P      Added error code function (to write to audit log)
*
********************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>


static void writeErrorsToAuditFile (tag_t tMsgTask,     char    *pszErrorStr);
static logical if_form_already_exists(EPM_action_message_t  msg);
static int parse_add_form_arguments(EPM_action_message_t  msg,
                                    char    **pszFormName);
/*=====================================================================================
*    Implementation of Action Handler -  TIAUTO-add-detailed-instructions
=====================================================================================*/

/********************************************************************************************
* NAME :            extern int t1aAUTO_add_detailed_instructions(EPM_action_message_t msg)
*
* DESCRIPTION :     This handler adds detailed instructions form for the task where it
*                   is configured. It reads the name of the detailed instructions form
*                   (supplied as argument to this handler) and adds the form as local reference
*                   to the task. 
*                   
*          
*
* INPUTS : msg
*         
* OUTPUTS : 
*
* RETURN : iRetCode (ITK_ok ) 
*
*
***********************************************************************************************/
extern int t1aAUTO_add_detailed_instructions(EPM_action_message_t msg)
{
    int     iRetCode = ITK_ok;
    char    *pszFormName = NULL;
    tag_t   tQueryTag = NULLTAG;
    char    *pszQueryName = TIAUTO_DETAILED_INSTRUCTIONS_QRY_NAME;
    int     iEntryCount  = 2;  
    int     iInstructionsFormCount = 0;
    tag_t   *tDetailedInstructionsForms = NULL;
    char    *pcEntries[] = {"Type", "Name"};
    char    *pcValues[] = {"", ""};
    int     iAttachmentType = EPM_reference_attachment;
    char    szErrorString[TIAUTO_error_message_len+1]="";
    char    szTaskName[WSO_name_size_c+1];
    char    *pszErrorStr = NULL;

    iRetCode = parse_add_form_arguments(msg, &pszFormName);
    
    pcValues[0] = TI_DETAILED_INSTRUCTIONS_FORM;
    pcValues[1] = pszFormName;

    // Find the query tag for the Qurery "__t1a_Get_Detailed_Instructions"
	if(iRetCode == ITK_ok )
		iRetCode = QRY_find (pszQueryName, &tQueryTag);

    if(iRetCode == ITK_ok && tQueryTag == NULLTAG)
    {    
        TI_sprintf(szErrorString, "Query, \"%s\", is not found in the TCE database. Please inform TCE administrator.\n",
	        pszQueryName);
        TC_write_syslog(szErrorString);
        iRetCode = TIAUTO_DETAIL_INSTRUCTIONS_QRY_NOT_FOUND;
    }
    
    // Execute the query with default form type "TI_DetailedInstructions" and name of the form
    if(iRetCode == ITK_ok && tQueryTag != NULLTAG)
	    iRetCode = QRY_execute (tQueryTag, iEntryCount, pcEntries, pcValues,
                                &iInstructionsFormCount, &tDetailedInstructionsForms);

    if (iRetCode == ITK_ok) 
    {
        if (iInstructionsFormCount > 0 && tDetailedInstructionsForms[0] != NULLTAG)
        {
            if ( !if_form_already_exists(msg) )
                iRetCode = EPM_add_attachments( msg.task, 1, &tDetailedInstructionsForms[0], &iAttachmentType);
        }
        else if (iInstructionsFormCount == 0 )
        {
            iRetCode = EPM_ask_name(msg.task, szTaskName);
            TI_sprintf(szErrorString, "Specified Detailed Instructions for Task: %s are not found in database.",szTaskName); 
            TC_write_syslog(szErrorString);
            iRetCode = TIAUTO_DETAIL_INSTRUCTIONS_NOT_FOUND;
        }
    }
    if(iRetCode != ITK_ok )
    {
        if (iRetCode <= EMH_USER_error_base)
        {
            iRetCode = EMH_ask_error_text(iRetCode, &pszErrorStr);
            writeErrorsToAuditFile (msg.task, pszErrorStr);
        }
        else
        {
            writeErrorsToAuditFile (msg.task, szErrorString);
        }
        iRetCode = ITK_ok;
    }

    // Cleaning up Memory.
    SAFE_MEM_free (tDetailedInstructionsForms);
    SAFE_MEM_free (pszFormName);
    SAFE_MEM_free (pszErrorStr);
    
    if(iRetCode == ITK_ok )
    {
        iRetCode = EMH_clear_errors();
    }
    return iRetCode;
}

/**************************************************************************************
* NAME :            static int parse_add_form_arguments(EPM_action_message_t msg,   
                                                        char    **pszFormName )
*
* DESCRIPTION :     This static function parses the action handler arguments and returns
*                   from name.
*
* INPUTS :  msg
*         
* OUTPUTS : pszFormName (detail instructions form)
* 
* RETURN : iRetCode (ITK_ok or error code ) 
*
*
**************************************************************************************/
static int  parse_add_form_arguments(EPM_action_message_t  msg,
                                     char  **pszFormName)
{
    int     iRetCode = ITK_ok ;
    int     indx = 0, arg_cnt = 0;
    char    *value  = NULL;
    char    *flag   = NULL;
    
    arg_cnt = TC_number_of_arguments( msg.arguments );

    if ( arg_cnt < 1 )
        iRetCode = EPM_missing_req_arg;
    else if ( arg_cnt > 1)
       iRetCode = EPM_wrong_number_of_arguments;
    else
    {
        for ( indx = 0; indx < arg_cnt && iRetCode == ITK_ok; indx++)
        {
            iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &flag, &value );
            if ( iRetCode == ITK_ok ) 
            {
                if (tc_strcasecmp(flag, "name") == 0 && value != NULL)
                {
                    *pszFormName = (char*) MEM_alloc((int)( tc_strlen(value) + 1) * sizeof(char));
                    tc_strcpy(*pszFormName, value);

                }
                else
                   iRetCode = EPM_invalid_argument;
            }
        }
    }
    
    // Memory clean up
    SAFE_MEM_free (flag);
    SAFE_MEM_free (value);
    return iRetCode;
}
/* This function verifies - if the given task is already has a detail instruction
   form (as a local reference) or not*/
static logical if_form_already_exists(EPM_action_message_t  msg) 
{
    int     indx = 0;
    int     iRetCode = 0;
    int     iRefAttachmentsCount = 0;
    logical formExists = false;
    char    szTypeName[TCTYPE_name_size_c+1] = "";
    tag_t   *tReferenceAttachments = NULL;

    iRetCode = EPM_ask_attachments( msg.task, EPM_reference_attachment,
                                    &iRefAttachmentsCount, &tReferenceAttachments );
    
    for ( indx = 0; indx < iRefAttachmentsCount && iRetCode == ITK_ok; indx++)
    {
        iRetCode = tiauto_get_object_name (tReferenceAttachments[indx], szTypeName);
        if(tc_strcasecmp( szTypeName , "TI_DetailedInstructions")== 0 && (iRetCode == ITK_ok) )
        {
            formExists = true;
            break;
        }
    }

    // Cleaning up Memory 
    SAFE_MEM_free (tReferenceAttachments);
    return  formExists;
}
/* This function writes error message to audit file of worklfow */
static void writeErrorsToAuditFile(tag_t tMsgTask,      char    *pszErrorStr)
{
    tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
    IMF_file_t  tFileDescriptor = NULL;
    int         iRetCode = 0;
    char        szTaskName[WSO_name_size_c+1];
    char        szErrorHeadingStr[WSO_desc_size_c] ="";
    
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_name( tMsgTask, szTaskName);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_job( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);

    if (iRetCode == ITK_ok)
    {
        TI_sprintf (szErrorHeadingStr, "\n*****ERROR MESSAGE while adding DETAILED INSTRUCTIONS for Task: %s *****\n",szTaskName);
        iRetCode = IMF_write_file_line(tFileDescriptor, szErrorHeadingStr);
        TC_write_syslog(szErrorHeadingStr);
        iRetCode = IMF_write_file_line(tFileDescriptor, pszErrorStr);
        iRetCode = IMF_write_file_line(tFileDescriptor, "\n\n");
        TC_write_syslog(pszErrorStr);
        TC_write_syslog("\n\n");
    } 
    if (iRetCode == ITK_ok)
        iRetCode = IMF_close_file(tFileDescriptor);

    EMH_clear_errors(); 
}

/*----------------------------------------------------------------------------*/
