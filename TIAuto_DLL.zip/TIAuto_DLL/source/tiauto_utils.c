/******************************************************************************
*
* FILENAME : tiauto_utils.c
*
* DESCRIPTION :
*       This file contains the implementation utility functions
*
*
*
* NOTES :
*
*
*
 CHANGES :
*	REF NO   DATE			WHO		DETAIL
*
*		06/20/2007		Srikanth P	Initial Creation
*       06/07/2007      Srikanth P  Merged with Rajesh code - t1aAUTO_check_document
*       07/17/2007      Srikanth P  Added - tiauto_get_change_item_rev
*		27/01/2009		Garima		Added - tiauto_isComponent_partOf_affectedItems &
*									tiauto_writeErrorMsgToStack
*		02/04/2009		Rajesh N	Added 2 new re-usable methods - tiauto_is_value_available_in_list &
*									tiauto_get_lov_values
*		11/02/2009      Dipak Naik	Added - tiauto_get_related_objects
*		17/03/2009		Garima		Added 2 new re-usable methods - tiauto_check_if_itemType_isOEM &
*									tiauto_clearErrorMsgStack
*		14/04/2009		Garima		Added 2 new re-usable methods -
*									tiauto_checkIf_affected_isA_proEInstance_getGenericPart &
*									tiauto_search_changeProcess_for_itemRev_getDetails
*		24/04/2009		Dipak Naik	Added - tiauto_getUser,tiauto_sendEMail & tiauto_getItemRevDetails
*		31/03/2010      Dipak Naik	Modified "tiauto_search_changeProcess_for_itemRev_getDetails" to search
									the ITRs only in CR and CRB process
*		15/04/2010		Dipak Naik	Added - tiauto_get_stacked_DAP_changeProcess_Details
*		10/08/2010		Dipak Naik	Added - tiauto_get_Form_attribute_value_of_ItemRev
*											remove_forward_AND_trailing_space
*									Modified - tiauto_search_changeProcess_for_itemRev_getDetails
											   and tiauto_get_stacked_DAP_changeProcess_Details
											   to include the PMR and CN workflows during the progression check
Nov 23,2018		 1.5		Jugunu          Updated for ER 9759 CAP3
********************************************************************************/
#include <tiauto_defines.h>
#include <tiauto_utils.h>

/*=====================================================================================
*    Implementation of "tiauto_get_release_status" -  To get release status
*          of a given workspace object.
=====================================================================================*/
extern int  tiauto_get_release_status (tag_t tWSObj, char *pszReleaseStatus)
{
    int		nStatuses = 0;
    tag_t	*ptStatusList;
    int     iRetCode = ITK_ok;

    tc_strcpy(pszReleaseStatus,""); // Initializing to NONE
    iRetCode = WSOM_ask_release_status_list ( tWSObj, &nStatuses, &ptStatusList );

    if ( (iRetCode == ITK_ok) && (nStatuses != 0))
	{
        iRetCode = CR_ask_release_status_type ( ptStatusList[nStatuses-1], pszReleaseStatus );
	}

    SAFE_MEM_free (ptStatusList);
    return iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_get_target_release_status" - To read Target Release
*          status from ECR form of  a given change item revision.
=====================================================================================*/
extern int  tiauto_get_target_release_status (tag_t  tEngChangeRev, char *szTargetReleaseStatus)
{
    int     iRetCode = ITK_ok;
    tag_t   tForm = NULLTAG;
    char    *pszReleaseStatus = NULL;

	iRetCode = tiauto_getFormAttachedToObject(tEngChangeRev, ECR_FORM, &tForm );
    // Get the Target Release Status from ECR Form
	if(iRetCode == ITK_ok &&  tForm != NULLTAG)
	{
		iRetCode = AOM_ask_value_string(tForm, TARGET_REL_STATE, &pszReleaseStatus);
        if( iRetCode == ITK_ok)
        {
            if (pszReleaseStatus!= NULL)
            {
                tc_strcpy(szTargetReleaseStatus, pszReleaseStatus);
                // there should be only one ECR form under Change Item rev.
            }
            else
            {
                TC_write_syslog("Error : The ECR form doesn't have target release status.\n");
                EMH_store_error_s1( EMH_severity_error, TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS, "Error: The ECR form  doesn't have target release status.");
                iRetCode = TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS;
                // there should be only one ECR form under Change Item rev.
            }
        }

    }
    SAFE_MEM_free (pszReleaseStatus);

    return iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_get_object_name" - To get object name from given
*          object.
=====================================================================================*/
extern int  tiauto_get_object_name (tag_t   tObject, char    *pszTypeName)
{
    int     iRetCode = ITK_ok;
    tag_t   tType = NULLTAG;

    tc_strcpy(pszTypeName,"");
    iRetCode = TCTYPE_ask_object_type (tObject, &tType);
    if (iRetCode == ITK_ok)
        iRetCode = TCTYPE_ask_name(tType, pszTypeName);

    return iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_initialize_status_progression_stuct" - Initializing
*       STATUS_Struct_t variable values to default values".
=====================================================================================*/
 extern void tiauto_initialize_status_progression_stuct(STATUS_Struct_t    *StatusProgression)
{
    StatusProgression->iCount = 0;
    StatusProgression->StatusArray = NULL;
}
/*=====================================================================================
*    Implementation of "tiauto_get_status_progression_array" - To get status
*       progression array values from site preference called "TI_Progression_Path".
=====================================================================================*/
extern int  tiauto_get_status_progression_array( STATUS_Struct_t    *StatusProgression)
{
    int     iCount = 0;
    int     iRetCode = ITK_ok;
    char    szErrorString[TIAUTO_error_message_len+1]="";
    char    **pszProgressionPath  = NULL;
    TC_preference_search_scope_t tScope;

    // get the progression path from preference variable.
    iRetCode = PREF_ask_search_scope( &tScope );
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );
    if (iRetCode == ITK_ok)
    {
        iRetCode = PREF_ask_char_values(PROGRESSION_PATH, &iCount, &pszProgressionPath);
        if (iRetCode != ITK_ok)
        {
            TI_sprintf(szErrorString, "Could not find \"TI_Progression_Path\" Preference in the system. Please update your site preferences.\n");
            TC_write_syslog(szErrorString);
            EMH_store_error_s1( EMH_severity_error, TIAUTO_PROGRESSION_PATH_NOT_FOUND, szErrorString);
            iRetCode = TIAUTO_PROGRESSION_PATH_NOT_FOUND;
        }
    }
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( tScope );

    if (iCount!= 0)
    {
        StatusProgression->iCount = iCount;
        StatusProgression->StatusArray = pszProgressionPath;
    }
    return iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_status_progression_index" - To get progression
*          index from status progression array ".
=====================================================================================*/
extern int  tiauto_status_progression_index (char   *pszReleaseStatus,
                                             STATUS_Struct_t    StatusProgression)
{
    int     indx = 0;
    int     iStatusIndex = -1; // do not change this default value without proper testing,
                               // this function is used in different places

    for ( indx = 0; indx < StatusProgression.iCount; indx++ )
    {
        if ( tc_strcasecmp (pszReleaseStatus, StatusProgression.StatusArray[indx]) == 0 )
        {
            iStatusIndex = indx;
            break;
        }
    }
    return iStatusIndex;
}
/*=====================================================================================
*    Implementation of "tiauto_check_if_affected_is_an_assembly" - To find out
*         whether affected or solution item is an assembly part of component part.
=====================================================================================*/
extern int  tiauto_check_if_affected_is_an_assembly(tag_t tObject, logical* lIsAnAssembly)
{
	int     iRetCode = ITK_ok;
	int     iBVRCount = 0;
	tag_t*	ptBVRs = NULL;

	// Find out BVR count for affected item. If BVR count is greater than zero,
    // then  affected or solution item is an assembly.

	iRetCode = ITEM_rev_list_bom_view_revs(tObject,
					&iBVRCount, &ptBVRs);
	if ( iBVRCount > 0 )
		*lIsAnAssembly = true;
	else
		*lIsAnAssembly = false;

    SAFE_MEM_free (ptBVRs);
	return  iRetCode;
}


/*=====================================================================================
*    Implementation of "tiauto_checkIf_affected_isA_proEInstance_getGenericPart" - To find out
*         whether affected or solution item is an ProE Instance Part.
*	 And get the Generic Part for the ProE Instance Part.
=====================================================================================*/
extern int  tiauto_checkIf_affected_isA_proEInstance_getGenericPart(
												tag_t     tItem,
												logical  *lProE,
												tag_t    *genericItemRevTag,
												char	 *pcGenItemDisplayName )
{
    int			iRetCode		= ITK_ok;
	int			iSts			= ITK_ok;
	int			iAttrNumArg		= 0;
	int			secObjCount		= 0;

    int			j				= 0;

	tag_t		tClassDSTag		= NULLTAG;
	tag_t		relationType	=  NULLTAG;

	tag_t		datasettype		=  NULLTAG;
	tag_t		dataset			=  NULLTAG;
	tag_t		*tvalues		= NULL;

	char		datasetTypeName[AE_datasettype_name_size_c+1]	= "";
	char		*value											= NULL;
	char		*propName										= "IPEM_master_dependency";
	char		*pcItemId										= NULL;
	char		*pcRevId										= NULL;

	GRM_relation_t *secondaryList								= 0;

    *lProE = false;
	*genericItemRevTag = NULLTAG;

	iRetCode = GRM_find_relation_type  (  "IMAN_specification", &relationType );
	if( iRetCode == ITK_ok )
		iRetCode =  GRM_list_secondary_objects  (  tItem , relationType,
											   &secObjCount, &secondaryList );
	if( iRetCode == ITK_ok )
	for(j =0 ; j < secObjCount ;j++)
	{
		iSts = POM_class_of_instance(secondaryList[j].secondary,&tClassDSTag );
		if(iSts == ITK_ok)
			iSts = POM_name_of_class( tClassDSTag , &value );
		if( ( iSts == ITK_ok )	&&
			( value != NULL )	&&
			( tc_strcasecmp( value , "Dataset" ) == 0 ) )
		{
			iSts =  AE_ask_dataset_datasettype( secondaryList[j].secondary, &datasettype );
			if(iSts==ITK_ok)
				iSts =  AE_ask_datasettype_name( datasettype , datasetTypeName );
			if(   ( iSts == ITK_ok ) &&
				  ( datasetTypeName != NULL ) &&
				( ( tc_strcmp("ProPrt" , datasetTypeName) == 0 ) ||
				  ( tc_strcmp("ProAsm" , datasetTypeName) == 0 )   )  )
			{
				dataset = secondaryList[j].secondary;
				SAFE_MEM_free ( value );
				break;
			}
		}
		SAFE_MEM_free ( value );
		if(iSts != ITK_ok )
			iRetCode = iSts;
	}
	if( (iRetCode == ITK_ok ) && (dataset != NULLTAG) )
	{
		iRetCode = AOM_UIF_ask_value(  dataset, propName, &value );
		//if( value != NULL )
			//value= tc_strtok ( value , "-");
		if( value != NULL )
			TI_sprintf(pcGenItemDisplayName, "%s", value);
		if( ( iRetCode == ITK_ok )	&& ( value != NULL ) && ( (int)tc_strlen(value) > 0 ) )
		{
			*lProE = true; // generic part
			//to get the actual value tag of the display ID
			iRetCode = AOM_ask_value_tags(dataset,propName,&iAttrNumArg,&tvalues);
			if( (iRetCode == ITK_ok) && (tvalues != NULL) && (tvalues[0] != NULLTAG) )
			{
				//to get the Item ID
				iRetCode = AOM_ask_value_string(tvalues[0],"item_id",&pcItemId);
				//to get the Revision ID
				if( iRetCode == ITK_ok )
					iRetCode = AOM_ask_value_string(tvalues[0],"item_revision_id",&pcRevId);
				//to get the tag of the item revision
				if( ( iRetCode == ITK_ok ) && ( pcItemId != NULL )  && ( pcRevId != NULL )  )
					iRetCode = ITEM_find_rev(pcItemId,pcRevId,genericItemRevTag);

				SAFE_MEM_free (pcItemId);
				SAFE_MEM_free (pcRevId);
			}
			SAFE_MEM_free (tvalues);
		}
		SAFE_MEM_free (value);
	}
	SAFE_MEM_free ( secondaryList );
    return iRetCode;
}

/*=====================================================================================
//! tiauto_check_if_ItemType_isOEM()
//! \param  tag_t  objTag,	//<I>
//!			logical  &isOEM	//<O>
//! \return int
//! \note Checks if the Items parent type is _OEM
//!		  and updates bool to True. Default is false.
//!		  Returns retcode.
=====================================================================================*/
extern int tiauto_check_if_itemType_isOEM(tag_t		objTag,	/*<I>*/
										  logical	*isOEM	/*<O>*/
										 )
{
	int iRetCode = ITK_ok;
	tag_t typeTag = NULLTAG;
	tag_t parentTypeTag = NULLTAG;
	char  parentTypeName[TCTYPE_name_size_c+1] = "";
	char  typeName[TCTYPE_name_size_c+1] = "";

	*isOEM = false;

	iRetCode = TCTYPE_ask_object_type(objTag, &typeTag);
	if(iRetCode == ITK_ok)
		iRetCode = TCTYPE_ask_name(typeTag,  typeName);
	if(iRetCode == ITK_ok)
		iRetCode = TCTYPE_ask_parent_type(typeTag, &parentTypeTag);
	if(iRetCode == ITK_ok)
		iRetCode = TCTYPE_ask_name(parentTypeTag,  parentTypeName);

	if( ( iRetCode == ITK_ok ) &&
	  (	( tc_strcmp(typeName,OEM_REV) == 0 ) ||
		( tc_strcmp(parentTypeName,OEM_REV) == 0 ) ) )
		*isOEM = true;

	return iRetCode;
}

/*=====================================================================================
*    Implementation of "tiauto_get_task_attachments" - To get attachments (of given type)
*          from  given task (using EPM_action_message_t) ".
=====================================================================================*/
extern int tiauto_get_task_attachments (EPM_action_message_t msg,
                                        int        iAttachmentType,
                                        int        *iNumAttachments,
                                        tag_t      **ptAttachments)
{
    int     iRetCode = ITK_ok;
    tag_t   tRootTask = NULLTAG;

    iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask, iAttachmentType,
                                      iNumAttachments, ptAttachments);
    return  iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_get_change_item_rev" - To get chnage item rev from
*    target attachments of a given task.
=====================================================================================*/
/*extern int tiauto_get_change_item_rev (EPM_rule_message_t msg,
                                       tag_t    *tEngChangeRev) */
extern int tiauto_get_change_item_rev (tag_t    msgTask,
                                       tag_t    *tEngChangeRev)
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumAttachments = 0;
    tag_t   tRootTask = NULLTAG;
    tag_t   *ptAttachments = NULL;
    char    pszObject[WSO_name_size_c+1]="";

    iRetCode = EPM_ask_root_task(msgTask , &tRootTask);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
                                       &iNumAttachments, &ptAttachments);

    for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
    {
        iRetCode = WSOM_ask_object_type(ptAttachments[indx], pszObject);
        if( DEBUG_PRINT ) printf("\n WSO type - tiauto_get_change_item_rev : %s\n", pszObject);
        if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 ) || (tc_strcmp (pszObject, NEWCHANGE_REV) == 0 ) ) )
        {
            *tEngChangeRev = ptAttachments[indx];
            break;  // there should be only one change rev in target objects.
        }
    }
    /* TBDiscussed with Dan */
    /* if (*tEngChangeRev == NULLTAG)
    {
        TC_write_syslog("There is NO Change Item Rev attached to this Change Process.\n");
        EMH_store_error_s1(EMH_severity_error, TIAUTO_CHANGE_REV_NOT_FOUND, "There is NO Change Item Rev attached to this Change Process.\n");
        iRetCode = TIAUTO_CHANGE_REV_NOT_FOUND;
    }
    */
    SAFE_MEM_free (ptAttachments);
    return  iRetCode;
}

extern int tiauto_get_newchange_item_rev (tag_t    msgTask,
                                       tag_t    *tEngChangeRev)
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumAttachments = 0;
    tag_t   tRootTask = NULLTAG;
    tag_t   *ptAttachments = NULL;
    char    pszObject[WSO_name_size_c+1]="";

    iRetCode = EPM_ask_root_task(msgTask , &tRootTask);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
                                       &iNumAttachments, &ptAttachments);

    for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
    {
        iRetCode = WSOM_ask_object_type(ptAttachments[indx], pszObject);
        if( DEBUG_PRINT ) printf("\n WSO type - tiauto_get_change_item_rev : %s\n", pszObject);
        if (iRetCode == ITK_ok && tc_strcmp (pszObject, NEWCHANGE_REV) == 0 )
        {
            *tEngChangeRev = ptAttachments[indx];
            break;  // there should be only one change rev in target objects.
        }
    }
    /* TBDiscussed with Dan */
    /* if (*tEngChangeRev == NULLTAG)
    {
        TC_write_syslog("There is NO Change Item Rev attached to this Change Process.\n");
        EMH_store_error_s1(EMH_severity_error, TIAUTO_CHANGE_REV_NOT_FOUND, "There is NO Change Item Rev attached to this Change Process.\n");
        iRetCode = TIAUTO_CHANGE_REV_NOT_FOUND;
    }
    */
    SAFE_MEM_free (ptAttachments);
    return  iRetCode;
}
/*=====================================================================================
*    Implementation of "tiauto_get_class_name_of_instance" - To get class name of given
*          instance.
=====================================================================================*/
extern int  tiauto_get_class_name_of_instance(tag_t tInstance, char    **pszClassName)
{
    int     iRetCode = ITK_ok;
    tag_t   tClass = NULLTAG;

    iRetCode = POM_class_of_instance(tInstance, &tClass );
    if( tClass != NULLTAG && iRetCode == ITK_ok)
        iRetCode = POM_name_of_class( tClass , pszClassName );

    return  iRetCode;

}
/* verifies whether the given component part is added to the change folders (solution/affected items) */
extern logical tiauto_isComponent_partOf_affectedItems(tag_t    tItemRev, tag_t    tEngChangeRev)
{
    int     iRetCode = ITK_ok;
    int     iCount = 0;
    int     iNumAffected = 0;
    tag_t   *ptAffectedItems = NULL;
    logical lAffected = false;

    iRetCode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);
    for (iCount = 0; iCount < iNumAffected && (iRetCode == ITK_ok); iCount++)
    {
        if (tItemRev == ptAffectedItems[iCount])
        {
            lAffected = true;
            break;
        }
    }

    SAFE_MEM_free (ptAffectedItems);
    return lAffected;
}

/*=====================================================================================
*    Implementation of "tiauto_search_changeProcess_for_itemRev_getDetails" -
*	 To find out if the given item revision is a Target Item of CR/CRB change process.
*	 If so get the Target Release Status and ProcessId/Rev of the change process.
=====================================================================================*/
extern int  tiauto_search_changeProcess_for_itemRev_getDetails (tag_t      itemRevTag,
														 STATUS_Struct_t	StatusProgression,
														 char     **pcOtherTargetReleaseStatus,
														 char     **pcOtherProcessName)
{
	int          iRetCode		= ITK_ok;
	int			 iNoOfRefs		= 0;
	int			*piNoOfLevels	= NULL;
	tag_t		*ptReferencers	= NULL;
	tag_t		 tTypeTag		= NULLTAG;
	char		 type_class[TCTYPE_class_name_size_c+1] = "";
	int			 iNumAttachments= 0;
    tag_t		*ptAttachments	= NULL;
    char		 pszObject[WSO_name_size_c+1] = "";
	tag_t		 tJob			= NULLTAG;
	tag_t		 tRootTask		= NULLTAG;
	tag_t	     tEngChngRev	= NULLTAG;
	tag_t		 tRelTag		= NULLTAG;
	int			 iSecObjCnt		= 0;
	tag_t		*ptSecObj		= NULL;
	tag_t		 tSpecType		= NULLTAG;
	int			 i				= 0;
	int			 j				= 0;
	char		 cClassName[TCTYPE_class_name_size_c+1] = "";
	char		*pcValue		= NULL;
	char		acRootTaskName[WSO_name_size_c+1] = "";
	char		caReleaseStatus[WSO_name_size_c+1] = "" ;
	// 1. Get Process Attached to item_rev_tag
		// No Process - > szCurrentTargetReleaseStatus = ""
	// Get Process's Target Release Status szCurrentTargetReleaseStatus
	//iRetCode = WSOM_where_referenced(itemRevTag, 1,&iNoOfRefs, &piNoOfLevels,
	//									  &ptReferencers, &RelationNames );
	iRetCode = CR_ask_job(itemRevTag, &iNoOfRefs, &ptReferencers);

	for(i=0; (i < iNoOfRefs) && ( iRetCode == ITK_ok ); i++)
	{
		iRetCode = TCTYPE_ask_object_type(ptReferencers[i],&tTypeTag);
		if(iRetCode == ITK_ok)
			iRetCode = TCTYPE_ask_class_name (tTypeTag, type_class);
		if( ( iRetCode == ITK_ok ) && (tc_strcmp(type_class,"EPMJob") == 0) )
		{
			//tProcess = ptReferencers[i];
			tJob = ptReferencers[i];
			tEngChngRev = NULLTAG;
			if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
			{
				//iRetCode = EPM_ask_job( tProcess, &tJob);
				//if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
					iRetCode = EPM_ask_root_task (tJob, &tRootTask) ;
				if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
				{
					//get the root task name
					iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
					//get the targeted change revision
					if( iRetCode == ITK_ok )
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
					for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
					{
						iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
						if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 ) ||  (tc_strcmp (pszObject, NEWCHANGE_REV) == 0 )) )
						{
							tEngChngRev = ptAttachments[j];
							break;  // there should be only one change rev in target objects.
						}
					}
					//check if the root task name is CR/CRB process
					if(( iRetCode == ITK_ok ) && ( (tc_strcmp(acRootTaskName,"2_00 CR - Change Request")==0)||
												   (tc_strcmp(acRootTaskName,"10_00 CRB - CR Bypass")==0)||
												   (tc_strcmp(acRootTaskName,"13_00 CRB - CR Bypass")==0) ) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							if( tiauto_isComponent_partOf_affectedItems(itemRevTag, tEngChngRev) == true )
							{
								// Get the TI_ECR form of the Change Item and get the "t1a40targetreleasestate" value.
								iRetCode = GRM_find_relation_type("IMAN_specification", &tRelTag);
								iRetCode = GRM_list_secondary_objects_only(tEngChngRev,tRelTag,&iSecObjCnt,&ptSecObj);
								for(j = 0;( j < iSecObjCnt ) && ( iRetCode == ITK_ok ); j++)
								{
									iRetCode = TCTYPE_ask_object_type(ptSecObj[j],&tSpecType);
									if( (iRetCode == ITK_ok) && (tSpecType != NULLTAG) )
									{
										iRetCode = TCTYPE_ask_class_name(tSpecType,cClassName);
										if( (iRetCode == ITK_ok) && (cClassName != NULL) )
										{
											if( tc_strcmp(cClassName,"Form") == 0 )
											{
												iRetCode = AOM_ask_value_string(ptSecObj[j], "object_type", &pcValue );
												if( (iRetCode == ITK_ok) && (pcValue != NULL) )
												{
													if(tc_strcmp(pcValue,"TI_ECR") == 0)
													{
														iRetCode = AOM_ask_value_string( ptSecObj[j], "t1a40targetreleasestate", &pcValue);
														if( (iRetCode == ITK_ok) && (pcValue != NULL) )
														{
															if( *pcOtherTargetReleaseStatus == NULL )
															{
																iRetCode = AOM_ask_value_string( ptSecObj[j], "t1a40targetreleasestate", pcOtherTargetReleaseStatus);
																iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
															}
															else if (tiauto_status_progression_index(pcValue, StatusProgression) > tiauto_status_progression_index(*pcOtherTargetReleaseStatus, StatusProgression))
															{
																iRetCode = AOM_ask_value_string( ptSecObj[j], "t1a40targetreleasestate", pcOtherTargetReleaseStatus);
																iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
															}
														}
														break;
													}
												}
											}
										}
									}
								}
							}
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"TI_PMR",
														"t1a84targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && ((tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release")==0) || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_PMR",
														"t8_193targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"SRP - Standards Release Process")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_StandardForm",
														"t8_189targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP",
														"t8_t1a120targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP2",
														"t8_t1a190targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					//adding CAP3 changes
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"CAP - Change Approval Process")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP3",
														"t8_t1a190targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"TPR - Technology Primary Release")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_TPR",
														"t8_t1a201targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"TER - Technology Emergency Release")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_TER",
														"t8_t1a205targetreleasestate",caReleaseStatus);
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(caReleaseStatus) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,caReleaseStatus);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);

						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"9_00 CRO - CAD Release Only")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(CRO) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,CRO);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"CRO - CAD Release Only")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(CRO) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,CRO);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(PRODUCTION_LAUNCHED) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,PRODUCTION_LAUNCHED);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"3_00 CN - Prototype Release")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(PROTOTYPE) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,PROTOTYPE);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"4_00 CN - Production Release")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(PRODUCTION_RELEASED) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,PRODUCTION_RELEASED);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
					else if( ( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"5_00 CN - Production Launch")==0) )
					{
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							*pcOtherTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(PRODUCTION_LAUNCHED) + 1) * sizeof(char));
							tc_strcpy( *pcOtherTargetReleaseStatus,PRODUCTION_LAUNCHED);
							if(iRetCode == ITK_ok)
								iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}
				}
			}
		}
	}
	SAFE_MEM_free ( piNoOfLevels );
	SAFE_MEM_free ( ptReferencers );
	/*for(i=0; i< iNoOfRefs; i++)
		SAFE_MEM_free( RelationNames[i] );
	RelationNames = NULL;*/
	SAFE_MEM_free ( ptAttachments );
	SAFE_MEM_free ( ptSecObj );
	SAFE_MEM_free ( pcValue );

	return iRetCode;
}


extern void tiauto_writeErrorMsgToStack(TIA_ErrorMessage **currErrMsg, int iFail, char* sError)
{
	TIA_ErrorMessage *temp;
    logical isPresent = false;
	temp = *currErrMsg;

	if( (*currErrMsg == NULL) || (temp == NULL) )
	{
		*currErrMsg=malloc(sizeof(TIA_ErrorMessage));
		temp = *currErrMsg;
		TI_sprintf(temp->errMsg, "");
	}
	else
	{
		for(;;)
		{
			if( tc_strcmp(temp->errMsg, sError) == 0 )
			{
				isPresent = true;
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_ErrorMessage));
			temp=temp->next;
			TI_sprintf(temp->errMsg, "");
		}
	}
	if ( isPresent == false )
	{
		temp->iRetCode = iFail;
		TI_sprintf(temp->errMsg,"%s",sError);
		temp->next  = NULL;
	}
	//free ( temp );
	temp = NULL;
}

// for freeing error stack memory
extern void tiauto_clearErrorMsgStack(TIA_ErrorMessage *currErrMsg)
{
	TIA_ErrorMessage *tempErrMsg = NULL;
	while(currErrMsg != NULL)
	{
		tempErrMsg = currErrMsg->next;
		free (currErrMsg);
		currErrMsg = tempErrMsg;
		tempErrMsg = NULL;
	}
	return;
}

/* START : added by Rajesh N on 02/04/2009 for check cro items rule handler */

/*=====================================================================================
*    Implementation of "tiauto_get_lov_values" - To get list of all values from a LOV
*    which holds string values.
*		Inputs args : pcLovName - Name of the LOV
*		Output args	: pstLovValues - Structure having list of values, and the number of values
*
=====================================================================================*/

extern  int tiauto_get_lov_values (char  *pcLovName,
                                   STRING_Array_Struct_t    *pstLovValues)
{
    int     indx = 0;
    int     iFail = ITK_ok;
    int     iNumLOVs = 0;
    int     iNumValues = 0;

    tag_t   *ptLOVs = NULL;

    PROP_value_type_t   value_type = PROP_untyped;

    char    **pcValues = NULL;

    iFail = LOV_find (pcLovName, &iNumLOVs, &ptLOVs);

    if (iFail == ITK_ok && iNumLOVs > 0)
    {
        for (indx = 0; indx < iNumLOVs && iFail == ITK_ok; indx++)
        {
            iFail = LOV_ask_value_type (ptLOVs[indx], &value_type);
            if (iFail == ITK_ok && value_type == PROP_string)
            {
                iFail = LOV_ask_values_string (ptLOVs[indx], &iNumValues, &pcValues);
                pstLovValues->iCount = iNumValues;
				pstLovValues->ValueArray = pcValues;
				//There should be only one LOV of given type
				break;
            }
        }
    }
    else
        iFail = TIAUTO_SPECIFIED_LOV_NOT_FOUND;
    SAFE_MEM_free (ptLOVs);
    return iFail;
}


/*=====================================================================================
*    Implementation of "tiauto_is_value_available_in_list" - To check whether a given string value
* 	 is available in the list of values.
*		Input Arg : stLovValues - List of values where check should be performed
*		Input Arg : pcValueToCheck - value to look for in the list of values
*		Output Arg :	result - result of the check (true/false)
=====================================================================================*/


 extern  void  tiauto_is_value_available_in_list(STRING_Array_Struct_t stLovValues, char* pcValueToCheck, logical* result)
 {
	int iIndex			= 0;
	logical isAvailable	    = false;
	char buffer_ca[1024]  = "";
	*result = false;
	for( iIndex = 0; iIndex < stLovValues.iCount; iIndex++)
	{
		TI_sprintf(buffer_ca,"%s",stLovValues.ValueArray[iIndex]);
		if( tc_strcasecmp((stLovValues.ValueArray[iIndex]),pcValueToCheck ) == 0 )
		{
			isAvailable = true;
			*result = isAvailable;
			break;
		}
	}
 }

/*=====================================================================================
*    Implementation of "tiauto_get_itemrev_name" - To get the item revision name in the
*		format <item id>/<rev id>
*		Input Arg : tItemRevTag - Tag of the item revision
*		Output Arg : pcItemRevName : item revision name string
=====================================================================================*/

 extern  int  tiauto_get_itemrev_name(tag_t tItemRevTag, char** pcItemRevName )
 {
	int     iFail							= ITK_ok;

	tag_t	tItem							= NULLTAG;

	char	acItemId[ITEM_id_size_c+1]		= "";
	char	acRevId[ITEM_id_size_c+1]		= "";
	char	acItemRevName[256]				= "";

	/* get item tag */
	iFail = ITEM_ask_item_of_rev(tItemRevTag, &tItem);

	/* get item id string */
	if(iFail == ITK_ok && tItem != NULLTAG)
		iFail = ITEM_ask_id(tItem, acItemId);

	/* get item rev id string */
	if( iFail == ITK_ok)
		iFail = ITEM_ask_rev_id(tItemRevTag,acRevId );

	if(iFail ==ITK_ok)
	{
		tc_strcat(acItemRevName,acItemId);
		tc_strcat(acItemRevName,"/");
		tc_strcat(acItemRevName,acRevId);
		*pcItemRevName=MEM_alloc(sizeof(acItemRevName));
		tc_strcpy(*pcItemRevName, acItemRevName);
	}
	return iFail;
 }

 /* END :  added by Rajesh N on 02/04/2009 for check cro items rule handler */


/*=====================================================================================
*   tiauto_get_related_objects()
*\param				char acRelationName[TCTYPE_name_size_c+1],
*					tag_t tItemRevTag,
*					int *piObjCount,
*					tag_t	**ptAttachs
*\return int
* Description:
*			To get all the objects attached to the item revision with the specified relation.
=====================================================================================*/
extern  int  tiauto_get_related_objects( char acRelationName[TCTYPE_name_size_c+1],	/*<I>*/
										 tag_t tItemRevTag,								/*<I>*/
										 int *piObjCount,								/*<O>*/
										 tag_t	**ptAttachs )							/*<O>*/
{
	int		iRetCode		=  ITK_ok;
	tag_t	tRelation		=  NULLTAG;

	iRetCode =  GRM_find_relation_type( acRelationName, &tRelation );
	if( iRetCode == ITK_ok)
		iRetCode =  GRM_list_secondary_objects_only( tItemRevTag, tRelation, piObjCount, ptAttachs );

	return iRetCode;
}

//*=====================================================================================
//*   tiauto_getUser()
//*\param				tag_t tRootTask,		/*<I>*/
//*					char *pcTaskName,			/*<I>*/
//*					tag_t *tResponsibleParty	/*<O>*/
//*
//*\return int
//* Description:
//*			To get the tag of the assigned user for the given task.
//*=====================================================================================
extern int tiauto_getUser(	tag_t tRootTask,			/*<I>*/
							char *pcTaskName ,			/*<I>*/
							tag_t *tResponsibleParty	/*<O>*/
						  )
{
	int iFail=ITK_ok;
	tag_t   tSubTask = NULLTAG;

	iFail = EPM_ask_sub_task  (  tRootTask, pcTaskName,&tSubTask);
	if( (iFail == ITK_ok) && (tSubTask != NULLTAG))
		iFail = EPM_ask_responsible_party( tSubTask,tResponsibleParty);

	return iFail;
}


//*=====================================================================================
//*   tiauto_sendEMail()
//*\param				const char *subject,		/*<I>*/
//*					const char *receiverList,		/*<I>*/
//*					const char *pcMailBodyFileName	/*<I>*/
//*
//*\return int
//* Description:
//*			This function will send the mail through OS mail facility
//*=====================================================================================

extern int tiauto_sendEMail(	const char *subject,				/* <I> */
								const char *pcreceiverList,			/* <I> */
								const char *pcMailBodyFileName      /* <I> */
							)

{
    int iRetCode = ITK_ok;

    char caMailDetails[BUFSIZ +1];

    /* 4399740: Allow special characters in recipient field */

    TC_preference_search_scope_t old_scope = TC_preference_site;
    int iPrefCount = 0;
    char *pcServerName = NULL;
    char *pcCharset = NULL;
    int imark, ifail;

    char *pcToListFileName = NULL;
    FILE *fToListFile = NULL;
	int iFileOpenErrCode = 0;

    //mail_attributes_t attrs;

    /*
     *  <vlm 8/17/98> Use the mail gateway code to send the mail for NT.
     *  PR # 693685
     */
    caMailDetails[0] = '\0';
#if defined(WNT)
    tc_strcpy(caMailDetails, "%TC_BIN%\\tc_mail_smtp ");
#else
    tc_strcpy(caMailDetails, "$TC_BIN/tc_mail_smtp ");
#endif


    /* PR#5182626: Open a temp file for writing email address for -to_list_file= */
    pcToListFileName = USER_new_file_name("to_email_addresses","TEXT","dat",1);
    iFileOpenErrCode = fopen_s(&fToListFile, pcToListFileName , "w" );

    if (fToListFile == NULL)
    {
        iRetCode = CR_cannot_open_file;
    }
    else
    {
        /* write all email addresses from receiver List into new file */

            if( pcreceiverList != 0 )
                fprintf( fToListFile , "%s\n", pcreceiverList);

            /*The memory is being freed in CR_notify function, do not free it here */
            /* MEM_free(address); */


            tc_strcat( caMailDetails, " -to_list_file=\"" );
            tc_strcat( caMailDetails, pcToListFileName );
            tc_strcat( caMailDetails, "\" " );

        fclose(fToListFile);
    }

    tc_strcat(caMailDetails, " -subject=");
    tc_strcat(caMailDetails, "\"");
    tc_strcat(caMailDetails, subject);
    tc_strcat(caMailDetails, "\" ");

    //PR#1319397 : If user has email address set in his/her "Person" record
    //             that email address should appear in "From" field.
    {
       tag_t tsender_tag = NULLTAG;
       tag_t tsender_person = NULLTAG;
       char *pcthe_sender_name = 0;
       char *pcthe_sender_email_addr = 0;

       // get the current user name and user tag.
       ifail = POM_get_user(&pcthe_sender_name,&tsender_tag);
       if( ifail == ITK_ok )
       {
           // get the email address for current user.
           //ifail = EPM_get_user_email_addr( the_sender_tag,&the_sender_email_addr);
           //PR#5154023 : Issue where some SMTP servers cannot handle a "from" field which
           //             does not have a fully qualified email address. So, if the email
           //             address is explicitly spec'd in Person record then use it otherwise
           //             leave it blank (don't use the os name)
           ifail = SA_ask_user_person( tsender_tag, &tsender_person );
           if ( ifail == ITK_ok )
           {
               ifail = SA_ask_person_attr( tsender_person, "PA9", &pcthe_sender_email_addr );
               if((ifail == ITK_ok) && (pcthe_sender_email_addr != 0) )
               {
                  tc_strcat(caMailDetails," -user=\"");
                  tc_strcat(caMailDetails,pcthe_sender_email_addr);
                  tc_strcat(caMailDetails,"\" ");
               }
           }
        }

        MEM_free(pcthe_sender_name);
        MEM_free(pcthe_sender_email_addr) ;
    }

    EMH_set_protect_mark( &imark );

    /* check if any preferences are defined to specify the Mail server */
    ifail = PREF_initialize();
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_search_scope(&old_scope);
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_set_search_scope( TC_preference_site );
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_value_count( "Mail_server_name", &iPrefCount );
    }

    if((ifail == ITK_ok) && iPrefCount != 0 )
    {
        if(PREF_ask_char_value("Mail_server_name", 0, &pcServerName ) == ITK_ok )
        {
            if (tc_strcmp (pcServerName, "your mail server machine") == 0)
            {
            TC_write_syslog ("File %s; Line # %d; Please set your Mail_server_name preference in your site preference file"
                              ,__FILE__, __LINE__);
            }
            tc_strcat(caMailDetails, "-server=" );
            tc_strcat(caMailDetails, "\"" );
            tc_strcat(caMailDetails, pcServerName );
            tc_strcat(caMailDetails, "\" " );
        }

        if( pcServerName != NULL )
        {
            MEM_free(pcServerName);
        }
    }

    iPrefCount = 0;
    if(ifail == ITK_ok)
    {
		PREF_ask_value_count("Mail_server_charset", &iPrefCount);
    }

    if( (ifail == ITK_ok) && iPrefCount != 0 )
    {
        if( PREF_ask_char_value( "Mail_server_charset", 0, &pcCharset ) == ITK_ok )
        {
            tc_strcat( caMailDetails, "-charset=" );
            tc_strcat( caMailDetails, "\"" );
            tc_strcat( caMailDetails, pcCharset );
            tc_strcat( caMailDetails, "\" " );
        }
        else
        {
            tc_strcat( caMailDetails, "-charset=" );
            tc_strcat( caMailDetails, "\"ISO-8859-1\" " );
        }
        if( pcCharset != NULL )
        {
            MEM_free( pcCharset );
        }
    }
    else
    {
        tc_strcat( caMailDetails, "-charset=" );
        tc_strcat( caMailDetails, "\"ISO-8859-1\" " );
    }

    PREF_set_search_scope(old_scope);

    EMH_clear_errors();
    EMH_clear_protect_mark(imark);

    tc_strcat(caMailDetails, "-body=");
    tc_strcat(caMailDetails, pcMailBodyFileName);
    tc_strcat(caMailDetails, " ");

    system( caMailDetails );

	//Close the temporary file
	if(fToListFile != NULL)
		fclose(fToListFile);
	// delete temporary file here
    remove(pcToListFileName );


    return(iRetCode);
}


extern int tiauto_sendEMailFromPLMAdmin(	const char *subject,				/* <I> */
								const char *pcreceiverList,			/* <I> */
								const char *pcMailBodyFileName      /* <I> */
							)

{
    int iRetCode = ITK_ok;

    char caMailDetails[BUFSIZ +1];

    /* 4399740: Allow special characters in recipient field */

    TC_preference_search_scope_t old_scope = TC_preference_site;
    int iPrefCount = 0;
    char *pcServerName = NULL;
    char *pcCharset = NULL;
    int imark, ifail;

    char *pcToListFileName = NULL;
    FILE *fToListFile = NULL;
	int iFileOpenErrCode = 0;

    //mail_attributes_t attrs;

    /*
     *  <vlm 8/17/98> Use the mail gateway code to send the mail for NT.
     *  PR # 693685
     */
    caMailDetails[0] = '\0';
#if defined(WNT)
    tc_strcpy(caMailDetails, "%TC_BIN%\\tc_mail_smtp ");
#else
    tc_strcpy(caMailDetails, "$TC_BIN/tc_mail_smtp ");
#endif


    /* PR#5182626: Open a temp file for writing email address for -to_list_file= */
    pcToListFileName = USER_new_file_name("to_email_addresses","TEXT","dat",1);
    iFileOpenErrCode = fopen_s(&fToListFile, pcToListFileName , "w" );

    if (fToListFile == NULL)
    {
        iRetCode = CR_cannot_open_file;
    }
    else
    {
        /* write all email addresses from receiver List into new file */

            if( pcreceiverList != 0 )
                fprintf( fToListFile , "%s\n", pcreceiverList);

            /*The memory is being freed in CR_notify function, do not free it here */
            /* MEM_free(address); */


            tc_strcat( caMailDetails, " -to_list_file=\"" );
            tc_strcat( caMailDetails, pcToListFileName );
            tc_strcat( caMailDetails, "\" " );

        fclose(fToListFile);
    }

    tc_strcat(caMailDetails, " -subject=");
    tc_strcat(caMailDetails, "\"");
    tc_strcat(caMailDetails, subject);
    tc_strcat(caMailDetails, "\" ");

    //PR#1319397 : If user has email address set in his/her "Person" record
    //             that email address should appear in "From" field.
    {
       tag_t tsender_tag = NULLTAG;
       tag_t tsender_person = NULLTAG;
       char *pcthe_sender_name = 0;
       char *pcthe_sender_email_addr = 0;

       // get the current user name and user tag.
       ifail = POM_get_user(&pcthe_sender_name,&tsender_tag);
       if( ifail == ITK_ok )
       {
           // get the email address for current user.
           //ifail = EPM_get_user_email_addr( the_sender_tag,&the_sender_email_addr);
           //PR#5154023 : Issue where some SMTP servers cannot handle a "from" field which
           //             does not have a fully qualified email address. So, if the email
           //             address is explicitly spec'd in Person record then use it otherwise
           //             leave it blank (don't use the os name)
           ifail = SA_ask_user_person( tsender_tag, &tsender_person );
           if ( ifail == ITK_ok )
           {
               ifail = SA_ask_person_attr( tsender_person, "PA9", &pcthe_sender_email_addr );
               if((ifail == ITK_ok) && (pcthe_sender_email_addr != 0) )
               {
                  tc_strcat(caMailDetails," -user=\"");
                  tc_strcat(caMailDetails,pcthe_sender_email_addr);
                  tc_strcat(caMailDetails,"\" ");
               }
           }
        }

        MEM_free(pcthe_sender_name);
        MEM_free(pcthe_sender_email_addr) ;
    }

    EMH_set_protect_mark( &imark );

    /* check if any preferences are defined to specify the Mail server */
    ifail = PREF_initialize();
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_search_scope(&old_scope);
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_set_search_scope( TC_preference_site );
    }
    if(ifail == ITK_ok)
    {
        ifail = PREF_ask_value_count( "Mail_server_name", &iPrefCount );
    }

    if((ifail == ITK_ok) && iPrefCount != 0 )
    {
        if(PREF_ask_char_value("Mail_server_name", 0, &pcServerName ) == ITK_ok )
        {
            if (tc_strcmp (pcServerName, "your mail server machine") == 0)
            {
            TC_write_syslog ("File %s; Line # %d; Please set your Mail_server_name preference in your site preference file"
                              ,__FILE__, __LINE__);
            }
            tc_strcat(caMailDetails, "-server=" );
            tc_strcat(caMailDetails, "\"" );
            tc_strcat(caMailDetails, pcServerName );
            tc_strcat(caMailDetails, "\" " );
        }

        if( pcServerName != NULL )
        {
            MEM_free(pcServerName);
        }
    }

    iPrefCount = 0;
    if(ifail == ITK_ok)
    {
		PREF_ask_value_count("Mail_server_charset", &iPrefCount);
    }

    if( (ifail == ITK_ok) && iPrefCount != 0 )
    {
        if( PREF_ask_char_value( "Mail_server_charset", 0, &pcCharset ) == ITK_ok )
        {
            tc_strcat( caMailDetails, "-charset=" );
            tc_strcat( caMailDetails, "\"" );
            tc_strcat( caMailDetails, pcCharset );
            tc_strcat( caMailDetails, "\" " );
        }
        else
        {
            tc_strcat( caMailDetails, "-charset=" );
            tc_strcat( caMailDetails, "\"ISO-8859-1\" " );
        }
        if( pcCharset != NULL )
        {
            MEM_free( pcCharset );
        }
    }
    else
    {
        tc_strcat( caMailDetails, "-charset=" );
        tc_strcat( caMailDetails, "\"ISO-8859-1\" " );
    }

    PREF_set_search_scope(old_scope);

    EMH_clear_errors();
    EMH_clear_protect_mark(imark);

    tc_strcat(caMailDetails, "-body=");
    tc_strcat(caMailDetails, pcMailBodyFileName);
    tc_strcat(caMailDetails, " ");

	//
	tc_strcat( caMailDetails, "-user=" );
    tc_strcat( caMailDetails, "\"plmadmin@tiauto.com\" " );

    system( caMailDetails );

	//Close the temporary file
	if(fToListFile != NULL)
		fclose(fToListFile);
	// delete temporary file here
    remove(pcToListFileName );


    return(iRetCode);
}

//*=====================================================================================
//*   tiauto_getItemRevDetails()
//*\param			tag_t tItemRev,				/*<I>*/
//*					char *pcItemId,				/*<O>*/
//*					char *pcRevId,				/*<)>*/
//*					char *pcName				/*<O>*/
//*
//*\return int
//* Description:
//*			To get the item Id, revision Id and the revision name.
//*=====================================================================================
extern int tiauto_getItemRevDetails(tag_t tItemRev, char *pcItemId,
					 char *pcRevId, char *pcName)
{
	int iRetCode   = ITK_ok;
	tag_t tItem = NULLTAG;

	iRetCode = ITEM_ask_item_of_rev(tItemRev, &tItem);

	if(iRetCode == ITK_ok && tItem != NULLTAG)
		iRetCode = ITEM_ask_id(tItem, pcItemId);

	if(iRetCode == ITK_ok && tItemRev != NULLTAG)
		iRetCode = ITEM_ask_rev_id (tItemRev, pcRevId);

	if(iRetCode == ITK_ok && tItemRev != NULLTAG)
		iRetCode = ITEM_ask_rev_name(tItemRev, pcName);

	return iRetCode;
}


/*=====================================================================================
* tiauto_getFormAttachedToObject()
* Param:				tag_t		tObj,			<I>
*						char		*szFormType,	<I>
*						tag_t		*tForm			<O>
*return: int
*note:		To get the tag of the
*			specified form type under the given object.
=====================================================================================*/
extern int  tiauto_getFormAttachedToObject(tag_t  tObj, char *szFormType, tag_t *tForm )
{
    int     indx = 0, iCount = 0;
    int     iRetCode = ITK_ok;
    tag_t   tRelationType = NULLTAG;
    tag_t   *ptSecondaryObjects = NULL;
    char    szObjectType[WSO_name_size_c+1]="";

	*tForm = NULLTAG;

    iRetCode = GRM_find_relation_type( TC_specification_rtype, &tRelationType );
    if(iRetCode == ITK_ok)
        iRetCode = GRM_list_secondary_objects_only (tObj, tRelationType,
                                                   &iCount, &ptSecondaryObjects);

    for (indx = 0; indx < iCount && iRetCode == ITK_ok; indx++)
    {
        iRetCode = WSOM_ask_object_type (ptSecondaryObjects[indx], szObjectType);
        if( DEBUG_PRINT ) printf("\n WSO type - tiauto_getFormAttachedToObject: %s\n", szObjectType);
        if(tc_strcasecmp (szObjectType , szFormType)== 0 && (iRetCode == ITK_ok) )
        {
			*tForm = ptSecondaryObjects[indx];
			break;
		}
	}
	SAFE_MEM_free(ptSecondaryObjects);
	return iRetCode;
}


/*=====================================================================================
*    Implementation of "tiauto_get_target_release_sts_quick_progression" - To read Target Release
*          status from TargetStatus form of  a given change item revision.
=====================================================================================*/
extern int  tiauto_get_target_release_sts_quick_progression(tag_t  tEngChangeRev,char *pcFormType,
															char *szTargetReleaseStatus)
{
    int     iRetCode = ITK_ok;
    tag_t   tForm = NULLTAG;
    char    *pszReleaseStatus = NULL;

    char            szErrorString[TIAUTO_error_message_len+1]	= "";
    char			caFolderName[WSO_name_size_c+1]				= "";

	iRetCode = tiauto_getFormAttachedToFolder(tEngChangeRev, pcFormType, &tForm );
    // Get the Target Release Status from TargetStatus Form
	if(iRetCode == ITK_ok &&  tForm != NULLTAG)
	{
		iRetCode = AOM_ask_value_string(tForm, "t1a84targetreleasestate", &pszReleaseStatus);
        if( iRetCode == ITK_ok)
        {
            if (pszReleaseStatus == NULL || tc_strcmp(pszReleaseStatus,"") == 0 )
            {
				iRetCode = WSOM_ask_name  (  tForm, caFolderName );
				TI_sprintf(szErrorString, "Error : The attribute \"Target Release State\" of the form \"%s\" is not filled. Please fill the \"%s\" form before initiating the workflow.",
										caFolderName,caFolderName);
                TC_write_syslog(szErrorString);
                EMH_store_error_s1( EMH_severity_error, TIAUTO_TARGETSTATUS_FORM_NO_TARGET_REL_STATUS, szErrorString);
                iRetCode = TIAUTO_TARGETSTATUS_FORM_NO_TARGET_REL_STATUS;

            }
            else if(iRetCode == ITK_ok)
            {
				tc_strcpy(szTargetReleaseStatus, pszReleaseStatus);
            }
        }

    }
	else if(iRetCode == ITK_ok &&  tForm == NULLTAG)
	{
		iRetCode = WSOM_ask_name  ( tEngChangeRev, caFolderName );
		TI_sprintf(szErrorString,"Error : The form of type \"TI_TargetStatus\" doesn't exist in the folder \"%s\". Please create a form of type \"TI_TargetStatus\" in the folder \"%s\" and fill the form before initiating the workflow.",caFolderName,caFolderName);
		TC_write_syslog(szErrorString);
        EMH_store_error_s1( EMH_severity_error, TIAUTO_TARGETSTATUS_FORM_NOT_FOUND,szErrorString );
        iRetCode = TIAUTO_TARGETSTATUS_FORM_NOT_FOUND;
	}
    SAFE_MEM_free (pszReleaseStatus);

    return iRetCode;
}

/*=====================================================================================
*    Implementation of "tiauto_get_target_folder" - To get chnage item rev from
*    target attachments of a given task.
=====================================================================================*/
extern int tiauto_get_target_folder (tag_t    msgTask,
                                       tag_t    *tFolder)
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumAttachments = 0;
    tag_t   tRootTask = NULLTAG;
    tag_t   *ptAttachments = NULL;
    char    pszObject[WSO_name_size_c+1]="";

    iRetCode = EPM_ask_root_task(msgTask , &tRootTask);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
                                       &iNumAttachments, &ptAttachments);

    for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
    {
        iRetCode = WSOM_ask_object_type(ptAttachments[indx], pszObject);

        if (iRetCode == ITK_ok && tc_strcmp (pszObject, FOLDER) == 0 )
        {
            *tFolder = ptAttachments[indx];
            break;
        }
    }
    SAFE_MEM_free (ptAttachments);
    return  iRetCode;
}
/*=====================================================================================
* tiauto_getFormAttachedToFolder()
* Param:				tag_t		tObj,			<I>
*						char		*szFormType,	<I>
*						tag_t		*tForm			<O>
*return: int
*note:		To get the tag of the
*			specified form type under the given object.
=====================================================================================*/
extern int  tiauto_getFormAttachedToFolder(tag_t  tObj, char *szFormType, tag_t *tForm )
{
    int     indx = 0, iCount = 0;
    int     iRetCode = ITK_ok;
    tag_t   *ptSecondaryObjects = NULL;
    char    szObjectType[WSO_name_size_c+1]="";
	FL_sort_criteria_t tSort =  FL_fsc_by_type ;
	*tForm = NULLTAG;

    iRetCode = FL_ask_references(tObj,tSort,&iCount, &ptSecondaryObjects);

    for (indx = 0; indx < iCount && (iRetCode == ITK_ok); indx++)
    {
        iRetCode = WSOM_ask_object_type (ptSecondaryObjects[indx], szObjectType);

        if(tc_strcasecmp (szObjectType , szFormType)== 0 && (iRetCode == ITK_ok) )
        {
			*tForm = ptSecondaryObjects[indx];
			break;
		}
	}
	SAFE_MEM_free(ptSecondaryObjects);
	return iRetCode;
}

/*=====================================================================================
*    Implementation of "tiauto_get_stacked_DAP_changeProcess_Details" -
*	 To find out if the given item revision is a Target Item of DAP change process.
*	 If so get the Target Release Status and ProcessId/Rev of the change process.
=====================================================================================*/
extern int  tiauto_get_stacked_DAP_changeProcess_Details ( tag_t      itemRevTag,
													       char     **pcOtherProcessName)
{
	int          iRetCode		= ITK_ok;
	int			 iNoOfRefs		= 0;
	int			 i				= 0;
	int			 j				= 0;
	int			 iNumAttachments= 0;
	char		 type_class[TCTYPE_class_name_size_c+1] = "";
	tag_t		 tTypeTag		= NULLTAG;
	tag_t		 tJob			= NULLTAG;
	tag_t		 tRootTask		= NULLTAG;
	tag_t	     tEngChngRev	= NULLTAG;
	tag_t		 *ptReferencers = NULL;
    tag_t		 *ptAttachments	= NULL;
    char		 pszObject[WSO_name_size_c+1] = "";
	char		 acRootTaskName[WSO_name_size_c+1] = "";
	char		 caReleaseStatus[WSO_name_size_c+1] = "" ;

	iRetCode = CR_ask_job(itemRevTag, &iNoOfRefs, &ptReferencers);

	for(i=0; (i < iNoOfRefs) && ( iRetCode == ITK_ok ); i++)
	{
		iRetCode = TCTYPE_ask_object_type(ptReferencers[i],&tTypeTag);
		if(iRetCode == ITK_ok)
			iRetCode = TCTYPE_ask_class_name (tTypeTag, type_class);
		if( ( iRetCode == ITK_ok ) && (tc_strcmp(type_class,"EPMJob") == 0) )
		{
			tJob = ptReferencers[i];
			tEngChngRev = NULLTAG;
			if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
			{
				iRetCode = EPM_ask_root_task (tJob, &tRootTask) ;
				if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
				{
					//get the root task name
					iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
					//check if the root task name is DAP process
					if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"6_00 DAP - Design Approval")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && (( tc_strcmp (pszObject, CHANGE_REV) == 0 ) || (tc_strcmp (pszObject, NEWCHANGE_REV))))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ((tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV))))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"TI_PMR",
														"t1a84targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP",
														"t8_t1a120targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP2",
														"t8_t1a190targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					//adding CAP3 changes
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"CAP - Change Approval Process")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_CAP3",
														"t8_t1a190targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && ((tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release")==0) || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_PMR",
														"t8_193targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							tc_strcpy(caReleaseStatus,PRODUCTION_LAUNCHED);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					else if(( iRetCode == ITK_ok ) && (tc_strcmp(acRootTaskName,"SRP - Standards Release Process")==0) )
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
														&iNumAttachments, &ptAttachments);
						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
						{
							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);
							if (iRetCode == ITK_ok && ( (tc_strcmp (pszObject, CHANGE_REV) == 0 )|| (tc_strcmp (pszObject, NEWCHANGE_REV) )))
							{
								tEngChngRev = ptAttachments[j];
								break;  // there should be only one change rev in target objects.
							}
						}
						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
						{
							iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(tEngChngRev,"T8_TI_StandardForm",
														"t8_189targetreleasestate",caReleaseStatus);
							if(tc_strcmp(caReleaseStatus,STUDY_APPROVED) != 0)
							{
								tEngChngRev = NULLTAG;
							}
						}
					}
					if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
					{
						if( tiauto_isComponent_partOf_affectedItems(itemRevTag, tEngChngRev) == true )
						{
							iRetCode = WSOM_ask_id_string(tEngChngRev, pcOtherProcessName);
						}
					}

				}
			}
		}
	}
	SAFE_MEM_free (ptReferencers);
	SAFE_MEM_free ( ptAttachments );

	return iRetCode;
}


/*=====================================================================================
*    Implementation of "tiauto_get_Form_attribute_value_of_ItemRev" - To read the value
*          of the given attribute of the given form that is attached to the given
*		   item revision with iman_specification relation.
=====================================================================================*/
extern int  tiauto_get_Form_attribute_value_of_ItemRev( tag_t  tEngChangeRev,   /* <I> */
														char *pcFormType,		/* <I> */
														char *pcAttributeName,  /* <I> */
														char *pcAttributeValue) /* <O> */
{
    int     iRetCode = ITK_ok;
    tag_t   tForm = NULLTAG;
    char    *pszReleaseStatus = NULL;
	//char	*pcChangeRevId = NULL;
	//char    szErrorString[TIAUTO_error_message_len+1]	= "";
	//get the form attached to the change revision
	iRetCode = tiauto_getFormAttachedToObject(tEngChangeRev, pcFormType, &tForm );
    // Get the attribute value of the Form
	if(iRetCode == ITK_ok &&  tForm != NULLTAG)
	{
		iRetCode = AOM_ask_value_string(tForm, pcAttributeName, &pszReleaseStatus);
        if( iRetCode == ITK_ok)
        {
            if (pszReleaseStatus!= NULL)
            {
                tc_strcpy(pcAttributeValue, pszReleaseStatus);
            }
            /*else
            {
                TI_sprintf(szErrorString,"Error: The attribute \"%s\" of the \"%s\" form is not filled.",pcAttributeName,pcFormType);
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS, szErrorString);
                iRetCode = TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS;
            }*/
        }
       SAFE_MEM_free (pszReleaseStatus);
    }
	/*else if(iRetCode == ITK_ok &&  tForm == NULLTAG)
	{
		iRetCode = WSOM_ask_id_string  ( tEngChangeRev, &pcChangeRevId );
		TI_sprintf(szErrorString,"Error: The form of type \"%s\" doesn't exist under the \"%s\".",pcFormType,pcChangeRevId);
		TC_write_syslog(szErrorString);
		EMH_store_error_s1( EMH_severity_error, TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS, szErrorString);
        iRetCode = TIAUTO_ECR_FORM_NO_TARGET_REL_STATUS;
		SAFE_MEM_free(pcChangeRevId);
	}*/

    return iRetCode;
}

//to remove the forward and trailing space
void remove_forward_AND_trailing_space(char *pcValue)
{
	int iLen = 0;
	char *p1 = pcValue;
    char *p2 = pcValue;
	//to remove the forward space
	p1 = pcValue;
	while(*p1 != NULL)
	{
		if(isspace(*p1))
		{
			++p1;
		}
		else
		{
			tc_strcpy(pcValue,p1);
			break;
		}
	}
	//to remove the trailing space

	p2 = pcValue ;
	while(p2 != NULL)
	{
		iLen =(int)tc_strlen(pcValue);
		if(isspace(p2[iLen-1]))
		{
			p2[iLen-1] = NULL;
		}
		else
		{
			tc_strcpy(pcValue,p2);
			break;
		}
	}

}
//parse the string by using comma(,) separator and put into sub string into the structure
extern int tiauto_get_values_from_comma_separated_string (char  *pszValue, STATUS_Struct_t    *AllowedStatus)
{
    int     iRetCode = ITK_ok;
    int     iNumStatus = 0;
    char    *pszLocalStr = NULL;
    char    *buffer = NULL;
    char    **pszStatuses = NULL;

    pszLocalStr = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pszValue)+1));
    tc_strcpy(pszLocalStr, pszValue);
    if ( pszLocalStr != NULL )
    {
        buffer = NULL;
        buffer = tc_strtok( pszLocalStr , ",");
        while ( buffer !=NULL)
        {
            if (pszStatuses == NULL)
            {
                pszStatuses = (char**) MEM_alloc ( sizeof (char *) );
            }
            else
            {
                pszStatuses = (char**) MEM_realloc ( pszStatuses, (iNumStatus+1) * sizeof(char*));
            }
            pszStatuses[iNumStatus] = (char*) MEM_alloc(( sizeof (char)*WSO_name_size_c) + 1);
            tc_strcpy(pszStatuses[iNumStatus],buffer);
            iNumStatus++;
            buffer = tc_strtok( NULL , "," );
        }
        AllowedStatus->iCount = iNumStatus;
        AllowedStatus->StatusArray = pszStatuses;
    }

    if ( pszLocalStr)
	{
		MEM_free (pszLocalStr);
	}

    return  iRetCode;
}

/*=====================================================================================
*   tiauto_Store_wsom_tags()
*\param				TIA_UniqueWSOMObjects	**TaskNamesPerUserList, <O>
*					int						*iNumTags		<O>
*					tag_t					tWsomtag,		<I>
*\return void
* Description:
*			To store all the tasks per user(unique).
=====================================================================================*/
void tiauto_Store_wsom_tags(TIA_UniqueWSOMObjects **TagsList,int *iNumTags, tag_t tWsomtag)
{

	TIA_UniqueWSOMObjects *temp;
    logical isPresent = false;
	temp = *TagsList;

	if( (*TagsList == NULL) || (temp == NULL) )
	{
		*TagsList=malloc(sizeof(TIA_UniqueWSOMObjects));
		temp = *TagsList;
	}
	else
	{
		for(;;)
		{
			if( temp->tUniqueWSOMObjects == tWsomtag )
			{
				isPresent = true;
					break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_UniqueWSOMObjects));
			temp=temp->next;

		}
	}
	if ( isPresent == false )
	{
		temp->tUniqueWSOMObjects = tWsomtag;
		(*iNumTags) ++;
		temp->next  = NULL;
	}

	temp = NULL;
}

// for freeing error stack memory
extern void tiauto_clearTagStack(TIA_UniqueWSOMObjects *UniqueObjs)
{
	TIA_UniqueWSOMObjects *tempObjs = NULL;
	while(UniqueObjs != NULL)
	{
		tempObjs = UniqueObjs->next;
		free (UniqueObjs);
		UniqueObjs = tempObjs;
		tempObjs = NULL;
	}
	return;
}
//TI_sprintf
extern void TI_sprintf(char* buffer, char* format, ... )
{
	int len = 0;
	va_list args;
	va_start( args, format );
	len = _vscprintf( format, args ) + 1;
	vsprintf_s( buffer, len, format, args);
}

//parse the string by using any delimiter separator and put into sub string into the structure
extern int tiauto_get_values_from_any_delimiter_string (char *pszDelim,char  *pszValue, STATUS_Struct_t    *AllowedStatus)
{
    int     iRetCode = ITK_ok;
    int     iNumStatus = 0;
    char    *pszLocalStr = NULL;
    char    *buffer = NULL;
    char    **pszStatuses = NULL;

    pszLocalStr = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pszValue)+1));
    tc_strcpy(pszLocalStr, pszValue);
    if ( pszLocalStr != NULL )
    {
        buffer = NULL;
        buffer = tc_strtok( pszLocalStr , ",");
        while ( buffer !=NULL)
        {
            if (pszStatuses == NULL)
            {
                pszStatuses = (char**) MEM_alloc ( sizeof (char *) );
            }
            else
            {
                pszStatuses = (char**) MEM_realloc ( pszStatuses, (iNumStatus+1) * sizeof(char*));
            }
            pszStatuses[iNumStatus] = (char*) MEM_alloc(( sizeof (char)*WSO_name_size_c) + 1);
            tc_strcpy(pszStatuses[iNumStatus],buffer);
            iNumStatus++;
            buffer = tc_strtok( NULL , "," );
        }
        AllowedStatus->iCount = iNumStatus;
        AllowedStatus->StatusArray = pszStatuses;
    }

    if ( pszLocalStr)
	{
		MEM_free (pszLocalStr);
	}

    return  iRetCode;
}

logical  tiauto_writeErrorItemsToStack(TIA_ErrorItems **currErrMsg, char* sError)
{
	TIA_ErrorItems *temp;
	logical isPresent = false;
	temp = *currErrMsg;

	if( (*currErrMsg == NULL) || (temp == NULL) )
	{
		*currErrMsg=malloc(sizeof(TIA_ErrorItems));
		temp = *currErrMsg;
		TI_sprintf(temp->szErrorItems, "");
	}
	else
	{
		for(;;)
		{
			if( tc_strcmp(temp->szErrorItems, sError) == 0 )
			{
				isPresent = true;
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_ErrorItems));
			temp=temp->next;
			TI_sprintf(temp->szErrorItems, "");
		}
	}
	if ( isPresent == false )
	{
		TI_sprintf(temp->szErrorItems,"%s",sError);
		temp->next  = NULL;

	}
	//free ( temp );
	temp = NULL;
	return isPresent;
}

/*=====================================================================================
//! tiauto_check_if_itemType_isDOC()
//! \param  tag_t  objTag,	//<I>
//!			logical  &lIsDOC	//<O>
//! \return int
//! \note Checks if the Item Rev's parent type is TI_Document Revision
//!		  and updates bool to True. Default is false.
//!		  Returns retcode.
=====================================================================================*/
extern int tiauto_check_if_itemType_isDOC(tag_t		objTag,	/*<I>*/
										  logical	*lIsDOC	/*<O>*/
										 )
{
	int iRetCode = ITK_ok;
	tag_t tTypeTag = NULLTAG;
	tag_t tParentTypeTag = NULLTAG;
	char  acParentTypeName[TCTYPE_name_size_c+1] = "";
	char  acTypeName[TCTYPE_name_size_c+1] = "";

	*lIsDOC = false;

	iRetCode = TCTYPE_ask_object_type(objTag, &tTypeTag);
	if(iRetCode == ITK_ok && tTypeTag != NULLTAG)
		iRetCode = TCTYPE_ask_name(tTypeTag,  acTypeName);
	if(iRetCode == ITK_ok && tTypeTag != NULLTAG)
		iRetCode = TCTYPE_ask_parent_type(tTypeTag, &tParentTypeTag);
	if(iRetCode == ITK_ok && tParentTypeTag != NULLTAG)
		iRetCode = TCTYPE_ask_name(tParentTypeTag,  acParentTypeName);

	if( ( iRetCode == ITK_ok ) &&
	  (	( tc_strcmp(acTypeName,DOCUMENT_REV) == 0 ) ||
		( tc_strcmp(acParentTypeName,DOCUMENT_REV) == 0 ) ) )
	{
		*lIsDOC = true;
	}

	return iRetCode;
}

/*******************************************************************************************
*	check_related_revision_folder()
*	\param				tag_t	tItemRev,
*						TIA_ErrorMessage **currErrMsg
*	\return int
*   Description:
*       This function will check the Related Revisions folder whether it contains any item
*		revision or not.If the Related Revisions folder does not have any item revision, then
*		an error message will be added to the error list and returns retCode.
********************************************************************************************/
extern int check_related_revision_folder(	tag_t	tItemRev,				/*<I>*/
											TIA_ErrorMessage **currErrMsg	/*<O>*/
										 )
{
	int		iRetCode									= ITK_ok;
	int		iObjCount									= 0 ;
	int		iCount										= 0 ;

	logical  lfound										= false;

	tag_t	*ptAttachs									= NULL;

	char	*pcItemRevName								= NULL;
	char	*pcClassName								= NULL;

	char    acErrorString[TIAUTO_error_message_len+1]	= "";

	/* Get all the objects present in related revision folder */
	iRetCode =  tiauto_get_related_objects("TI_DocProdRevisions",tItemRev,&iObjCount ,&ptAttachs);
	if(	iRetCode == ITK_ok)
	{
		for( iCount=0; iCount<iObjCount;iCount++)
		{
			/* Get the class name */
			iRetCode = tiauto_get_class_name_of_instance (ptAttachs[iCount], &pcClassName);
			if((tc_strcasecmp (pcClassName , "ItemRevision")== 0) && (iRetCode == ITK_ok))
				lfound=true;
		}
	}
	if( (lfound == false) && (iRetCode == ITK_ok) )
	{
		/* Get the Item revision name */
		iRetCode =  tiauto_get_itemrev_name(tItemRev, &pcItemRevName);
		if(	iRetCode == ITK_ok)
		{
			TI_sprintf(acErrorString, "The item revision %s does not contain any item revisions in the Related Revision folder. ", pcItemRevName);
			tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_VERIFY_RELATED_REVISIONS_ERROR , acErrorString);
		}
	}
	SAFE_MEM_free(ptAttachs);
	SAFE_MEM_free(pcClassName);
	SAFE_MEM_free(pcItemRevName);
	return iRetCode;
}

/*******************************************************************************************
*	Validate_IRM_form_mandatory_Attributes()
*	\param				int iNumAffected,
*						tag_t *ptItemRevList
*						TIA_ErrorMessage **errMsgStack_
*
*	\return int
*   Description:
*       This function will check the mandatory attributes of the item reviaion master forms
*		for the revisions in the list and if it finds any unfilled mandatory attribute, then
*		an error message will be added to the error list and returns retCode.
********************************************************************************************/

int Validate_IRM_form_mandatory_Attributes(int iNumAffected, tag_t *ptItemRevList, TIA_ErrorMessage **errMsgStack_)
{
	int				inx = 0;
	int				iny = 0;
	int				iNumProp = 0;
	int				iNumForm = 0;
	int				iRetCode = ITK_ok;
	char			acTypeName[TCTYPE_name_size_c+1]="";
	char			**ptProp_names = NULL;
	char			*pcPropReq = NULL;
	char			acItem_id[ITEM_id_size_c+1]="";
	char			acRev_id[ITEM_id_size_c+1]="";
    char			acTempError[TIAUTO_error_message_len+1]= "";
	tag_t			tType = NULLTAG;
	tag_t			tItem = NULLTAG;
	tag_t			tRelType = NULLTAG;
	tag_t			*ptForms = NULL;
	logical			lPropEmpty = true;
	char			*pcErrorProps = NULL;
	char			*temp = NULL;
	char			*pszClassName = NULL;
	int				indx= 0;
	char			*pcAttrDisplayName = NULL;
	//Get Item revision master forms of affected and solution items folder
	iRetCode = GRM_find_relation_type ( "IMAN_master_form",&tRelType);
	for(indx=0; indx<iNumAffected; indx++)
	{
		tag_t tTargetType = NULLTAG;
		tag_t tParentType = NULLTAG;
		iRetCode = tiauto_get_class_name_of_instance (ptItemRevList[indx], &pszClassName);
		if(tc_strcasecmp (pszClassName , "ItemRevision")!= 0 && (iRetCode == ITK_ok) )
		{
			//get the classname of the object
			if (iRetCode == ITK_ok && ptItemRevList[indx] != NULLTAG )
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptItemRevList[indx],&tTargetType));
			}
		
			if(tTargetType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
				if(tParentType != NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pszClassName));
				}
				
			}
		}
		if((iRetCode == ITK_ok)  &&( (tc_strcasecmp (pszClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pszClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
		{
			SAFE_MEM_free(pszClassName);
			if(iRetCode == ITK_ok )
				iRetCode = GRM_list_secondary_objects_only (ptItemRevList[indx],tRelType,&iNumForm, &ptForms);
			for (inx = 0; inx < iNumForm && (iRetCode == ITK_ok); inx++)
			{
				iRetCode = TCTYPE_ask_object_type  (ptForms[inx],&tType);
				if(iRetCode == ITK_ok )
					iRetCode = TCTYPE_ask_name  (tType,acTypeName);
				if(iRetCode == ITK_ok )
					iRetCode = AOM_ask_prop_names(ptForms[inx],&iNumProp,&ptProp_names);
				//Check Required Item revision master form property filled or not
				for(iny = 0; iny < iNumProp && (iRetCode == ITK_ok); iny++)
				{
					iRetCode = CONSTANTS_get_property_constant_value( PROPERTY_CONST_REQUIRED,acTypeName,ptProp_names[iny], &pcPropReq);
					if(iRetCode == ITK_ok && tc_strcasecmp(pcPropReq,"true")== 0 )
					{
						iRetCode = AOM_is_null_empty(ptForms[inx],  ptProp_names[iny],true,&lPropEmpty);
						if(iRetCode == ITK_ok && lPropEmpty==true)
						{
							iRetCode = ITEM_ask_item_of_rev  (ptItemRevList[indx],&tItem);
							if(iRetCode == ITK_ok)
								iRetCode = ITEM_ask_id  (tItem,acItem_id);
							if(iRetCode == ITK_ok)
								iRetCode = ITEM_ask_rev_id  (ptItemRevList[indx],acRev_id);
							if(iRetCode == ITK_ok)
								iRetCode = AOM_UIF_ask_name  ( ptForms[inx], ptProp_names[iny],  &pcAttrDisplayName ) ;
							if(iRetCode == ITK_ok)
							{
								if(pcErrorProps != NULL)
								{
									temp = (char*)MEM_alloc(( (int)tc_strlen(pcErrorProps) + 1) * sizeof(char));
									tc_strcpy(temp, pcErrorProps);
									pcErrorProps = 	(char*)MEM_alloc(( (int)tc_strlen(pcAttrDisplayName)+ (int)tc_strlen(pcErrorProps)+ 3) * sizeof(char));
									tc_strcpy( pcErrorProps, temp);
									tc_strcat( pcErrorProps, ", ");
									tc_strcat(pcErrorProps, pcAttrDisplayName);
								}
								else
								{
									pcErrorProps = 	(char*)MEM_alloc(( (int)tc_strlen(pcAttrDisplayName) + 1) * sizeof(char));
									tc_strcpy(pcErrorProps,pcAttrDisplayName);
								}
								SAFE_MEM_free(pcAttrDisplayName);
							}
						}
					}
					SAFE_MEM_free(pcPropReq);
				}
				if(pcErrorProps != NULL)
				{
					acTempError[0]='\0';
					TI_sprintf( acTempError,"Mandatory attributes \"%s\" of Item Revision Master Form \"%s/%s\" are not filled.",pcErrorProps,acItem_id,acRev_id);
					tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY, acTempError);
					SAFE_MEM_free(pcErrorProps);
				}
				SAFE_MEM_free(ptProp_names);
			}
			SAFE_MEM_free(ptForms);
		}
	}
	return iRetCode;
}

 //to get the target object tag based on the input object type
int get_target_object(tag_t tTask,char *pcTargetTypeName,tag_t *tTargetObject)
{
	int		iFail					= ITK_ok;
	int iNumAttachments= 0;
	int indx = 0;
	tag_t	tRootTask				= NULLTAG;
	tag_t	*ptAttachments = NULL;
	char    pszObject[WSO_name_size_c+1]="";

	iFail = EPM_ask_root_task(tTask , &tRootTask);
	if (iFail == ITK_ok && tRootTask != NULLTAG)
	{
		iFail = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments,&ptAttachments);
	}
	for (indx = 0; indx < iNumAttachments && (iFail == ITK_ok); indx++)
    {
        iFail = WSOM_ask_object_type(ptAttachments[indx], pszObject);
        if (iFail == ITK_ok && tc_strcmp (pszObject, pcTargetTypeName) == 0 )
        {
            *tTargetObject = ptAttachments[indx];
            break;
        }
    }

	return iFail;
}

int verify_MfgReleaseAuthorisation_Creation_Additional_Condition( tag_t tItemRev,
																  tag_t tEngChgRev,
																  char *pcTargetReleaseStatus,
																  STATUS_Struct_t	*StatusProgression,
																  TARGET_RELEASE_Struct_t *TargetReleaseStatus,
																  boolean bIsComponentMRA,
																  int iNewAseemCount,
																  tag_t *ptNewAssembly,
																  boolean *bIsValid)
{
	int iFail = ITK_ok;
	int iCount = 0;
	int iRefItemRevs = 0;
	int iITRMCount = 0;
	tag_t tRelationType = NULLTAG;
	tag_t *ptRefItemRevs = NULL;
	tag_t *ptITRMAttach = NULL;
	logical lIsAffected = false;
    char    szReleaseStatus[WSO_name_size_c+1]		  = "";
	char *pcERPIntValue = NULL;
	boolean bIsFoundInNewAssmb = false;

	*bIsValid = false;

	lIsAffected = tiauto_isComponent_partOf_affectedItems(tItemRev,tEngChgRev);
	if(lIsAffected == true)
	{
		*bIsValid = true;
	}
	else if(lIsAffected == false)
	{
		char    pszObjType[WSO_name_size_c+1]="";
		iFail = WSOM_ask_object_type(tEngChgRev, pszObjType);

		if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
		{
			tag_t tRelTemp = NULLTAG;
			iFail = GRM_find_relation_type ("CMReferences",&tRelTemp);
			if(iFail == ITK_ok && tRelTemp!=NULLTAG)
			{
				iFail = GRM_list_secondary_objects_only(tEngChgRev,tRelTemp,&iRefItemRevs,&ptRefItemRevs);
			}
		}
		else
			iFail = ECM_get_contents (tEngChgRev,"reference_items",&iRefItemRevs,&ptRefItemRevs);

		//verify in Ref. folder
		for (iCount = 0; iCount < iRefItemRevs && (iFail == ITK_ok); iCount++)
		{
			if (tItemRev == ptRefItemRevs[iCount])
			{
				//get the release status
				iFail = tiauto_get_release_status( tItemRev, szReleaseStatus );
				if(tiauto_status_progression_index (szReleaseStatus, *StatusProgression) >=  TargetReleaseStatus->iLevel )
				{
					*bIsValid = true;
					/*iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
					if(tRelationType != NULLTAG)
						iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType,&iITRMCount,&ptITRMAttach);
					if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
					{
						//get the Master Drawing and Rev value from the item rev master form
						iFail = AOM_UIF_ask_value (ptITRMAttach[0],"t8_1erpintegration",&pcERPIntValue);
						if(tc_strstr(pcERPIntValue,"NA - BPCS 8.2 - Auburn Hills") == NULL)
						{
							*bIsValid = true;
						}
					}*/
				}
				break;
			}
		}
		SAFE_MEM_free(ptRefItemRevs);
		
		if(lIsAffected == false)
		{
			char    pszObjType[WSO_name_size_c+1]="";			

			iFail = WSOM_ask_object_type(tEngChgRev, pszObjType);
			if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
			{
				tag_t tRelTemp = NULLTAG;
				iFail = GRM_find_relation_type ("CMHasProblemItem",&tRelTemp);
				if(iFail == ITK_ok && tRelTemp!=NULLTAG)
				{
					iFail = GRM_list_secondary_objects_only(tEngChgRev,tRelTemp,&iRefItemRevs,&ptRefItemRevs);
				}
			}

			//verify in Ref. folder
			for (iCount = 0; iCount < iRefItemRevs && (iFail == ITK_ok); iCount++)
			{
				if (tItemRev == ptRefItemRevs[iCount])
				{
					//get the release status
					iFail = tiauto_get_release_status( tItemRev, szReleaseStatus );
					if(tiauto_status_progression_index (szReleaseStatus, *StatusProgression) >=  TargetReleaseStatus->iLevel )
					{
						*bIsValid = true;
						/*iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
						if(tRelationType != NULLTAG)
							iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType,&iITRMCount,&ptITRMAttach);
						if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
						{
							//get the Master Drawing and Rev value from the item rev master form
							iFail = AOM_UIF_ask_value (ptITRMAttach[0],"t8_1erpintegration",&pcERPIntValue);
							if(tc_strstr(pcERPIntValue,"NA - BPCS 8.2 - Auburn Hills") == NULL)
							{
								*bIsValid = true;
							}
						}*/
					}
					break;
				}
			}
			SAFE_MEM_free(ptRefItemRevs);
		}
	}

	if( ((*bIsValid) == true ) && (bIsComponentMRA == true) )
	{
		//verify in the New Top Assembly List
		for (iCount = 0; iCount < iNewAseemCount && (iFail == ITK_ok); iCount++)
		{
			if(ptNewAssembly[iCount] == tItemRev)
			{
				*bIsValid = false;
				bIsFoundInNewAssmb = true;
				break;
			}
		}
		//verify the child components of the assembly
		if(bIsFoundInNewAssmb == false)
		{
			for (iCount = 0; iCount < iNewAseemCount && (iFail == ITK_ok); iCount++)
			{
				iFail = verify_ChildPart_in_ParentBOM(tItemRev,ptNewAssembly[iCount],&bIsFoundInNewAssmb);
				if(bIsFoundInNewAssmb == true)
				{
					*bIsValid = false;
					break;
				}
			}
		}
	}

	return iFail;
}

int verify_MfgReleaseAuthorisation_Creation_Condition(tag_t tItemRev,char *pcTargetStatus,char *pcValidStatusList,
													  boolean *bMfgRelAuth)
{
	int   iRetCode									= ITK_ok;
	int iITRMCount = 0;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
	char *pcReleasebByChange = NULL;
	char *pcChangeId = NULL;
	char *pcChangeRevId = NULL;
	char *pcTemp = NULL;
	tag_t tRelTag = NULLTAG;
	tag_t tChange = NULLTAG;
	tag_t tChangeRev = NULLTAG;
	tag_t tOwningStite = NULLTAG;
	tag_t *ptITRMAttach = NULL;

	*bMfgRelAuth = false;
	iRetCode = tiauto_get_release_status(tItemRev,szReleaseStatus);
	if( (tc_strcmp(pcTargetStatus,szReleaseStatus) == 0) ||
		((tc_strcmp(pcTargetStatus,"Production Launched") == 0) && (tc_strcmp(szReleaseStatus,"Production Released") == 0) ) )
	{
		*bMfgRelAuth = true;
		/*iRetCode = GRM_find_relation_type("IMAN_master_form", &tRelTag);
		if(tRelTag != NULLTAG)
			iRetCode = GRM_list_secondary_objects_only(tItemRev,tRelTag,&iITRMCount,&ptITRMAttach);
		if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
		{
			/*iRetCode = AOM_ask_value_string(ptITRMAttach[0],"t1a1releasedbychange",&pcReleasebByChange);
			if(pcReleasebByChange != NULL && tc_strcmp(pcReleasebByChange,"")!=0)
			{
				pcTemp = tc_strtok (pcReleasebByChange,"/");
				if(pcTemp != NULL )
				{
					pcChangeId = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcChangeId,pcTemp);
				}
				pcTemp = tc_strtok(NULL,"/");

				if(pcTemp != NULL )
				{
					pcChangeRevId = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcChangeRevId,pcTemp);
				}
				if(pcChangeId != NULL)
					iRetCode = ITEM_find_item(pcChangeId, &tChange) ;

				if(iRetCode == ITK_ok && tChange != NULLTAG)
					iRetCode = ITEM_find_revision (tChange,pcChangeRevId,&tChangeRev);

				if(iRetCode == ITK_ok && tChangeRev != NULLTAG)
					iRetCode = AOM_ask_value_tag (tChangeRev,"owning_site",&tOwningStite);

				if(tChange != NULLTAG && tChangeRev != NULLTAG && tOwningStite != NULLTAG)
				{
					*bMfgRelAuth = true;
				}
				else
					*bMfgRelAuth = false;
			}
			else
			{
				*bMfgRelAuth = true;
			}
		}*/
	}
	else
	{
		*bMfgRelAuth = true;
	}

	return iRetCode;
}

int verify_Valid_ERP_Plant(tag_t tTask,boolean *bValid,boolean *bMfgRelToBeCreated,char **pcValidReleaseStatusList)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				indx1										= 0;
	int				iNumLOVs = 0;
	int				iNumLOVValues = 0;
	int				iCount = 0;
	int				iSite = 0;
	int				iSiteID = 0;
	int				iNewAseemCount = 0;
	int				iOldAseemCount = 0;
	int				iCompMRACount = 0;

	char			**pcLOVValues				= NULL;
	char			**pcLOVValue				= NULL;
	char			*pcTemp1					= NULL;
	char			*pcTemp						= NULL;
	char			*pcFacilityName				= NULL;
	char			*pcAffectedProgramName		= NULL;
	char			*pcTIDivisionname			= NULL;
	char			*pcTargetReleaseStatus		= NULL;
	char			**pcAffectedProgramNames	= NULL;

	char			acSiteName[SA_site_size_c+1]	  = {'\0'};
	char		    acRootTaskName[WSO_name_size_c+1] = "";

	tag_t			tChangeRev								= NULLTAG;
	tag_t			tRootTask								= NULLTAG;
	tag_t           tChangeForm								= NULLTAG;
	tag_t			tSite									= NULLTAG;
	tag_t			*ptLOVs = NULL;
	tag_t			*ptNewAssembly = NULL;
	tag_t			*ptOldAssembly = NULL;
	tag_t			*ptCompMRA = NULL;
	boolean bValidERPPlant = false;
	boolean bValidMRACondition = false;
	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

	*bValid = false;
	*bMfgRelToBeCreated = false;

	iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	iRetCode = tiauto_get_change_item_rev (tTask, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		iRetCode = tiauto_get_status_progression_array (&StatusProgression);

		tSite = NULLTAG;
		//get the owning site
		iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
		//get the root task
		iRetCode = EPM_ask_root_task (tTask, &tRootTask) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}
		//read the change form and
		if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_120tiplant",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a120affectedprograms",&pcAffectedProgramName);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a120tidivision",&pcTIDivisionname);
				if(pcTIDivisionname == NULL || tc_strcmp(pcTIDivisionname,"") == 0)
				{					
					iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_120productgroup",&pcTIDivisionname);
				}
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a120targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_120componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP2",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedplants",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedprograms",&pcAffectedProgramName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a190targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		//adding CAP3 changes
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP3",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedplants",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedprograms",&pcAffectedProgramName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a190targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_PMR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_84tiplant",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t1a84affectedprogram",&pcAffectedProgramName);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a84tidivision",&pcTIDivisionname);
				if(pcTIDivisionname == NULL || tc_strcmp(pcTIDivisionname,"") == 0)
				{					
					iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_84productgroup",&pcTIDivisionname);
				}
				iRetCode = AOM_ask_value_string(tChangeForm,"t1a84targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84oldtoplevelassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PMR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193tiplant",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193affectedprogram",&pcAffectedProgramName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_193targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193oldtoplevelassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		if(pcTargetReleaseStatus != NULL)
		{
			tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,pcTargetReleaseStatus);
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
		}
	}
	//read the LOV T8_t1aERPPLMFacilityCodeMapping
	iRetCode = LOV_find("T8_t1aERPPLMFacilityCodeMapping",&iNumLOVs,&ptLOVs);
	if(iNumLOVs > 0 && ptLOVs[0] != NULLTAG)
	{
		 iRetCode = LOV_ask_values_string(ptLOVs[0],&iNumLOVValues,&pcLOVValues);
		 for(indx = 0; indx <iNumLOVValues; indx++)
		 {
			// if(pcFacilityName != NULL && tc_strstr(pcFacilityName,pcLOVValues[indx]) != NULL)
			  if(pcTIDivisionname != NULL && tc_strstr(pcLOVValues[indx],pcTIDivisionname) != NULL)
			 {
				pcLOVValue = (char **)MEM_alloc(20* sizeof(char *));
				pcTemp1 = (char *)MEM_alloc( ((int)tc_strlen(pcLOVValues[indx])) * sizeof(char));
				tc_strcpy(pcTemp1,pcLOVValues[indx]);
				pcTemp = tc_strtok (pcTemp1,":");
				iCount = 0;
				while(pcTemp != NULL && iRetCode == ITK_ok)
				{
					if(pcTemp != NULL)
					{
						pcLOVValue[iCount] = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
						tc_strcpy(pcLOVValue[iCount],pcTemp);
					}
					else
					{
						pcLOVValue[iCount] = (char *)MEM_alloc((int)tc_strlen("")+1);
						tc_strcpy(pcLOVValue[iCount],"");
					}

					iCount++;
					pcTemp = tc_strtok(NULL,":");

				}
				if(iCount > 0)
				{
					if( (tc_strstr(pcFacilityName,pcLOVValue[0]) != NULL) &&
						(tc_strstr(pcLOVValue[5],pcTIDivisionname) != NULL) &&
						(tc_strcasecmp(pcLOVValue[4],acSiteName) == 0) )
					{
						iCount = 0;
						pcAffectedProgramNames = (char **)MEM_alloc(20* sizeof(char *));
						tc_strcpy(pcTemp1,pcAffectedProgramName);
						pcTemp = tc_strtok (pcTemp1,",");
						while(pcTemp != NULL && iRetCode == ITK_ok)
						{
							if(pcTemp != NULL)
							{
								remove_forward_AND_trailing_space(pcTemp);
								pcAffectedProgramNames[iCount] = (char *)MEM_alloc((int)tc_strlen(pcTemp)+1);
								tc_strcpy(pcAffectedProgramNames[iCount],pcTemp);
							}
							else
							{
								pcAffectedProgramNames[iCount] = (char *)MEM_alloc((int)tc_strlen("")+1);
								tc_strcpy(pcAffectedProgramNames[iCount],"");
							}

							iCount++;
							pcTemp = tc_strtok(NULL,",");

						}
						for(indx1 = 0; indx1 <iCount; indx1++)
						{
							if( (pcLOVValue[6] == NULL) || (tc_strcmp(pcLOVValue[6],"") == 0) )
							{
								bValidERPPlant = false;
								break;
							}
							else if( (tc_strcasecmp(pcLOVValue[6],"All") == 0) ||
								     (tc_strstr(pcLOVValue[6],pcAffectedProgramNames[indx1]) != NULL ) )
							{
								bValidERPPlant = true;
								break;
							}
						}
						if(bValidERPPlant == true)
						{
							*pcValidReleaseStatusList = (char *)MEM_alloc((int)tc_strlen(pcLOVValue[7])+1);
							tc_strcpy(*pcValidReleaseStatusList,pcLOVValue[7]);
							if(tc_strstr(pcLOVValue[7],pcTargetReleaseStatus) != NULL)
							{
								for(indx1 = 0;indx1<iNewAseemCount;indx1++)
								{
									iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptNewAssembly[indx1],pcTargetReleaseStatus,pcLOVValue[7],bMfgRelToBeCreated);
									if(*bMfgRelToBeCreated == true)
									{
										*bMfgRelToBeCreated = false;
										bValidMRACondition = false;
										iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptNewAssembly[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
																	  false, iNewAseemCount,ptNewAssembly,&bValidMRACondition);
										if(bValidMRACondition == true)
										{
											*bMfgRelToBeCreated = true;
											break;
										}
									}
								}
								if(*bMfgRelToBeCreated == false)
								{
									for(indx1 = 0;indx1<iCompMRACount;indx1++)
									{
										iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptCompMRA[indx1],pcTargetReleaseStatus,pcLOVValue[7],bMfgRelToBeCreated);
										if(*bMfgRelToBeCreated == true)
										{
											*bMfgRelToBeCreated = false;
											bValidMRACondition = false;
											iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptCompMRA[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
																	  true, iNewAseemCount,ptNewAssembly,&bValidMRACondition );

											if(bValidMRACondition == true)
											{
												*bMfgRelToBeCreated = true;
												break;
											}
										}
									}
								}
							}
							break;
						}
					}
				}
			 }
		 }
	}

	*bValid = bValidERPPlant;
	return iRetCode;
}


int verify_Valid_MRA_Condition(tag_t tTask,boolean *bMfgRelToBeCreated,char **pcValidReleaseStatusList)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				indx1										= 0;
//	int				iNumLOVs = 0;
//	int				iNumLOVValues = 0;
//	int				iCount = 0;
	int				iSite = 0;
	int				iSiteID = 0;
	int				iNewAseemCount = 0;
	int				iOldAseemCount = 0;
	int				iCompMRACount = 0;

//	char			**pcLOVValues				= NULL;
//	char			**pcLOVValue				= NULL;
//	char			*pcTemp1					= NULL;
//	char			*pcTemp						= NULL;
	//char			*pcFacilityName				= NULL;
//	char			*pcAffectedProgramName		= NULL;
//	char			*pcTIDivisionname			= NULL;
	char			*pcTargetReleaseStatus		= NULL;
//	char			**pcAffectedProgramNames	= NULL;

	char			acSiteName[SA_site_size_c+1]	  = {'\0'};
	char		    acRootTaskName[WSO_name_size_c+1] = "";

	tag_t			tChangeRev								= NULLTAG;
	tag_t			tRootTask								= NULLTAG;
	tag_t           tChangeForm								= NULLTAG;
	tag_t			tSite									= NULLTAG;
//	tag_t			*ptLOVs = NULL;
	tag_t			*ptNewAssembly = NULL;
	tag_t			*ptOldAssembly = NULL;
	tag_t			*ptCompMRA = NULL;
//	boolean bValidERPPlant = false;
	boolean bValidMRACondition = false;
	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;
	TC_preference_search_scope_t tScope;
	char **pReleaseStatusList = NULL;
	int iRelStatCount = 0;
	
	*bMfgRelToBeCreated = false;

	iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	//get the site name mentioned in the preference
	iRetCode = PREF_ask_search_scope( &tScope );
	if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );
    if (iRetCode == ITK_ok)
    {
        iRetCode = PREF_ask_char_values("TI_MRA_Valid_ReleaseStatus_List", &iRelStatCount, &pReleaseStatusList);
        if (iRetCode != ITK_ok)
        {
			iRetCode = 0;
			return 0;
        }
		
    }
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( tScope );

	iRetCode = tiauto_get_change_item_rev (tTask, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		iRetCode = tiauto_get_status_progression_array (&StatusProgression);

		tSite = NULLTAG;
		//get the owning site
		iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
		//get the root task
		iRetCode = EPM_ask_root_task (tTask, &tRootTask) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}
		//read the change form and
		if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				/*iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_120tiplant",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a120affectedprograms",&pcAffectedProgramName);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a120tidivision",&pcTIDivisionname);
				if(pcTIDivisionname == NULL || tc_strcmp(pcTIDivisionname,"") == 0)
				{					
					iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_120productgroup",&pcTIDivisionname);
				}*/
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a120targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a120oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_120componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP2",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedplants",&pcFacilityName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedprograms",&pcAffectedProgramName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a190targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		//adding CAP3 changes
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP3",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedplants",&pcFacilityName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190affectedprograms",&pcAffectedProgramName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_t1a190productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a190targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190newtoplevassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a190componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_PMR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				/*iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_84tiplant",&pcFacilityName);
				iRetCode = AOM_UIF_ask_value(tChangeForm,"t1a84affectedprogram",&pcAffectedProgramName);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a84tidivision",&pcTIDivisionname);
				if(pcTIDivisionname == NULL || tc_strcmp(pcTIDivisionname,"") == 0)
				{					
					iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_84productgroup",&pcTIDivisionname);
				}*/
				iRetCode = AOM_ask_value_string(tChangeForm,"t1a84targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84oldtoplevelassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_84componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PMR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193tiplant",&pcFacilityName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193affectedprogram",&pcAffectedProgramName);
				//iRetCode = AOM_ask_value_string(tChangeForm,"t8_193productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_193targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193newtoplevelassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193oldtoplevelassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_193componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		
		if(pcTargetReleaseStatus != NULL)
		{
			tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,pcTargetReleaseStatus);
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
		}
	}
	for(indx = 0;indx<iRelStatCount;indx++)
	{
		if(tc_strstr(pReleaseStatusList[indx],pcTargetReleaseStatus) != NULL)
		{
			bValidMRACondition = true;
			break;
		}
	}

	if(bValidMRACondition == false)
	{
		*bMfgRelToBeCreated = false;
		return 0;
	}

	for(indx1 = 0;indx1<iNewAseemCount;indx1++)
	{
		iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptNewAssembly[indx1],pcTargetReleaseStatus,"All",bMfgRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
		if(*bMfgRelToBeCreated == true)
		{
			*bMfgRelToBeCreated = false;
			bValidMRACondition = false;
			iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptNewAssembly[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											false, iNewAseemCount,ptNewAssembly,&bValidMRACondition);
			if(bValidMRACondition == true)
			{
				*bMfgRelToBeCreated = true;
				break;
			}
		}
	}
	if(*bMfgRelToBeCreated == false)
	{
		for(indx1 = 0;indx1<iCompMRACount;indx1++)
		{
			iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptCompMRA[indx1],pcTargetReleaseStatus,"All",bMfgRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
			if(*bMfgRelToBeCreated == true)
			{
				*bMfgRelToBeCreated = false;
				bValidMRACondition = false;
				iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptCompMRA[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											true, iNewAseemCount,ptNewAssembly,&bValidMRACondition );

				if(bValidMRACondition == true)
				{
					*bMfgRelToBeCreated = true;
					break;
				}
			}
		}
	}
							
	
	return iRetCode;
}

int verify_ChildPart_in_ParentBOM(tag_t tChildPart,tag_t tParent,boolean *bFound)
{
	int iRetCode = ITK_ok;
	int iItemRevBvrCount = 0;
	int iNumOccs = 0;
	int iCount = 0;
	int iNoAlternates = 0;

	tag_t tChildItem = NULLTAG;
	tag_t tChildBomView = NULLTAG;
	tag_t tAlternate = NULLTAG;

	tag_t *ptItemRevBvrs = NULL;
	tag_t *ptOccs = NULL;
	tag_t *ptAltItems = NULL;
	tag_t *pAltViews = NULL;

	logical lHasAlternates = false;

	iRetCode = ITEM_rev_list_bom_view_revs ( tParent, &iItemRevBvrCount, &ptItemRevBvrs);
	if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
	{
		iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
		// If the BVR does not have any child component, no need to proceed further
		for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
		{
			tChildItem = NULLTAG;
			tAlternate = NULLTAG;
			lHasAlternates = false;

			iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],&tChildItem, &tChildBomView);
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				if(tChildItem == tChildPart)
				{
					*bFound = true;
					break;
				}
				//iRetCode = PS_ask_has_alternates  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates ); //Deprecated This will be obsoleted. Use PS_ask_has_substitutes
				iRetCode = PS_ask_has_substitutes  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates );
				if(lHasAlternates == true)
				{
					//iRetCode = PS_list_alternates (ptItemRevBvrs[0], ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews); //Deprecated This will be obsoleted. Use PS_list_substitutes
					iRetCode = PS_list_substitutes (ptItemRevBvrs[0], ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews);
					for (iCount = 0; (iCount < iNoAlternates) && (iRetCode == ITK_ok) ;iCount++)
					{
						tAlternate = ptAltItems[iCount];
						if( tAlternate != NULLTAG && tChildItem != tAlternate)
						{
							iRetCode = verify_ChildPart_in_ParentBOM(tChildPart, tChildItem, bFound);
							if(*bFound == true)
							{
								break;
							}
						}
					}
				}
				if(*bFound == true)
				{
					break;
				}
				iRetCode = verify_ChildPart_in_ParentBOM(tChildPart,tChildItem,bFound);
				if(*bFound == true)
				{
					break;
				}
			}
		}
	}
	return iRetCode;
}


/*=====================================================================================
*    Implementation of "tiauto_checkIf_affected_isA_SWConfig_getDoument" - To find out
*         whether affected or solution item is an SolidWork Config .
*	 And get the Document for the SolidWorks Configuration.
=====================================================================================*/
extern int  tiauto_checkIf_affected_isA_SWConfig_getDocument(
												tag_t     tItem,
												logical  *lIsSW,
												tag_t    *documentItemRevTag,
												char	 *pcDocItemDisplayName )
{
    int			iRetCode		= ITK_ok;
	int			iSts			= ITK_ok;
	int			iAttrNumArg		= 0;
	int			secObjCount		= 0;

    int			j				= 0;

	tag_t		tClassDSTag		= NULLTAG;
	tag_t		relationType	= NULLTAG;

	tag_t		datasettype		= NULLTAG;
	tag_t		dataset			= NULLTAG;
	tag_t		*tvalues		= NULL;

	char		datasetTypeName[AE_datasettype_name_size_c+1]	= "";
	char		*value											= NULL;
	char		*propName										= "SWIM_master_dependency";
	char		*pcItemId										= NULL;
	char		*pcRevId										= NULL;

	GRM_relation_t *secondaryList								= 0;

    *lIsSW = false;
	*documentItemRevTag = NULLTAG;

	iRetCode = GRM_find_relation_type  (  "IMAN_specification", &relationType );
	if( iRetCode == ITK_ok )
		iRetCode =  GRM_list_secondary_objects  (  tItem , relationType,
											   &secObjCount, &secondaryList );
	if( iRetCode == ITK_ok )
	for(j =0 ; j < secObjCount ;j++)
	{
		iSts = POM_class_of_instance(secondaryList[j].secondary,&tClassDSTag );
		if(iSts == ITK_ok)
			iSts = POM_name_of_class( tClassDSTag , &value );
		if( ( iSts == ITK_ok )	&&
			( value != NULL )	&&
			( tc_strcasecmp( value , "Dataset" ) == 0 ) )
		{
			iSts =  AE_ask_dataset_datasettype( secondaryList[j].secondary, &datasettype );
			if(iSts==ITK_ok)
				iSts =  AE_ask_datasettype_name( datasettype , datasetTypeName );
			if(   ( iSts == ITK_ok ) &&
				  ( datasetTypeName != NULL ) &&
				( ( tc_strcmp("SWPrt" , datasetTypeName) == 0 ) ||
				  ( tc_strcmp("SWAsm" , datasetTypeName) == 0 )   )  )
			{
				dataset = secondaryList[j].secondary;
				SAFE_MEM_free ( value );
				break;
			}
		}
		SAFE_MEM_free ( value );
		if(iSts != ITK_ok )
			iRetCode = iSts;
	}
	if( (iRetCode == ITK_ok ) && (dataset != NULLTAG) )
	{
		iRetCode = AOM_UIF_ask_value(  dataset, propName, &value );
		//if( value != NULL )
			//value= tc_strtok ( value , "-");
		if( value != NULL )
			TI_sprintf(pcDocItemDisplayName, "%s", value);
		if( ( iRetCode == ITK_ok )	&& ( value != NULL ) && ( (int)tc_strlen(value) > 0 ) )
		{
			*lIsSW = true; // document
			//to get the actual value tag of the display ID
			iRetCode = AOM_ask_value_tags(dataset,propName,&iAttrNumArg,&tvalues);
			if( (iRetCode == ITK_ok) && (tvalues != NULL) && (tvalues[0] != NULLTAG) )
			{
				//to get the Item ID
				iRetCode = AOM_ask_value_string(tvalues[0],"item_id",&pcItemId);
				//to get the Revision ID
				if( iRetCode == ITK_ok )
					iRetCode = AOM_ask_value_string(tvalues[0],"item_revision_id",&pcRevId);
				//to get the tag of the item revision
				if( ( iRetCode == ITK_ok ) && ( pcItemId != NULL )  && ( pcRevId != NULL )  )
					iRetCode = ITEM_find_rev(pcItemId,pcRevId,documentItemRevTag);

				SAFE_MEM_free (pcItemId);
				SAFE_MEM_free (pcRevId);
			}
			SAFE_MEM_free (tvalues);
		}
		SAFE_MEM_free (value);
	}
	SAFE_MEM_free ( secondaryList );
    return iRetCode;
}

/*******************************************************************************************
*	check_document_related_revision_folder()
*	\param				tag_t	tDocRev,
*						TIA_ErrorMessage **currWarMsg
*	\return int
*   Description:
*       This function will check the Related Revisions folder whether it contains any document
*		revision or not.If the Related Revisions folder does not have any item revision, then
*		a warning message will displayed and returns retCode.
********************************************************************************************/
extern int check_document_related_revision_folder(	tag_t	tDocRev,				/*<I>*/
											TIA_ErrorMessage **currWarMsg	/*<O>*/
										 )
{
	int		iRetCode									= ITK_ok;
	int		iObjCount									= 0 ;
	int		iCount										= 0 ;

	logical  lfound										= false;

	tag_t	*ptAttachs									= NULL;

	char	*pcDocRevName								= NULL;
	char	*pcClassName								= NULL;

	char    acErrString[TIAUTO_error_message_len+1]		= "";

	/* Get all the objects present in related revision folder */
	iRetCode =  tiauto_get_related_objects("TI_DocProdRevisions",tDocRev,&iObjCount ,&ptAttachs);
	if(	iRetCode == ITK_ok)
	{
		for( iCount=0; iCount<iObjCount;iCount++)
		{
			tag_t	tTargetType					= NULLTAG;
			tag_t	tParentType					= NULLTAG;
			/* Get the class name */
			iRetCode = tiauto_get_class_name_of_instance (ptAttachs[iCount], &pcClassName);
			if((tc_strcasecmp (pcClassName , "ItemRevision")!= 0) && (iRetCode == ITK_ok))
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAttachs[iCount],&tTargetType));				

				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
				if(tParentType != NULLTAG)
				{
					SAFE_MEM_free(pcClassName);
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pcClassName));
				}
			}
			if((iRetCode == ITK_ok)  &&( (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
				lfound=true;
		}
	}
	if( (lfound == false) && (iRetCode == ITK_ok) )
	{
		/* Get the Item revision name */
		iRetCode =  tiauto_get_itemrev_name(tDocRev, &pcDocRevName);
		if(	iRetCode == ITK_ok)
		{
			TI_sprintf(acErrString, "The document revision %s does not contain any revisions in the Related Revision folder. ", pcDocRevName);
			tiauto_writeErrorMsgToStack(currWarMsg, TIAUTO_VERIFY_RELATED_REVISIONS_WARNING , acErrString);
		}
	}
	SAFE_MEM_free(ptAttachs);
	SAFE_MEM_free(pcClassName);
	SAFE_MEM_free(pcDocRevName);
	return iRetCode;
}
//-----------------------------------------------------------------------------
// RemoveTrailingBlanks()
// \param   string							pcValue,						/*<I>*/
// \return string
// removes the trailing space from the input string
//-----------------------------------------------------------------------------
void RemoveTrailingBlanks(char *pcValue)
{
	int			iLen					=	0;
	char		*p1						=	pcValue;
    char		*p2						=	pcValue;

	//to remove the forward space
	p1 = pcValue;
	while(*p1 != NULL)
	{
		if(isspace(*p1))
		{
			++p1;
		}
		else
		{
			tc_strcpy(pcValue,p1);
			break;
		}
	}
	//to remove the trailing space
	p2 = pcValue ;
	while(p2 != NULL)
	{
		iLen = (int)tc_strlen(pcValue);
		if(iLen==0)
		{
			pcValue = NULL;
			break;
		}
		if(isspace(p2[iLen-1]))
		{
			p2[iLen-1] = NULL;
		}
		else
		{
			tc_strcpy(pcValue,p2);
			break;
		}
	}

}


//============================================================================================================
/* File must be open with 'b' in the mode parameter to fopen() */
long fsize(FILE* binaryStream)
{
  long ofs, ofs2;
  int result;

  if (fseek(binaryStream, 0, SEEK_SET) != 0 ||
      fgetc(binaryStream) == EOF)
    return 0;

  ofs = 1;

  while ((result = fseek(binaryStream, ofs, SEEK_SET)) == 0 &&
         (result = (fgetc(binaryStream) == EOF)) == 0 &&
         ofs <= LONG_MAX / 4 + 1)
    ofs *= 2;

  /* If the last seek failed, back up to the last successfully seekable offset */
  if (result != 0)
    ofs /= 2;

  for (ofs2 = ofs / 2; ofs2 != 0; ofs2 /= 2)
    if (fseek(binaryStream, ofs + ofs2, SEEK_SET) == 0 &&
        fgetc(binaryStream) != EOF)
      ofs += ofs2;

  /* Return -1 for files longer than LONG_MAX */
  if (ofs == LONG_MAX)
    return -1;

  return ofs + 1;
}

/* File must be open with 'b' in the mode parameter to fopen() */
/* Set file position to size of file before reading last line of file */
char* fgetsr(char* buf, int n, FILE* binaryStream)
{
  long fpos;
  int cpos;
  int first = 1;

  if (n <= 1 || (fpos = ftell(binaryStream)) == -1 || fpos == 0)
    return NULL;

  cpos = n - 1;
  buf[cpos] = '\0';

  for (;;)
  {
    int c;

    if (fseek(binaryStream, --fpos, SEEK_SET) != 0 ||
        (c = fgetc(binaryStream)) == EOF)
      return NULL;

    if (c == '\n' && first == 0) /* accept at most one '\n' */
      break;
    first = 0;

    if (c != '\r') /* ignore DOS/Windows '\r' */
    {
      unsigned char ch = c;
      if (cpos == 0)
      {
        memmove(buf + 1, buf, n - 2);
        ++cpos;
      }
      memcpy(buf + --cpos, &ch, 1);
    }

    if (fpos == 0)
    {
      fseek(binaryStream, 0, SEEK_SET);
      break;
    }
  }

  memmove(buf, buf + cpos, n - cpos);

  return buf;
}


//-----------------------------------------------------------------------------
// GetTaskNameDateAndUserInfo()
// \param   char*							sInput,						/*<I>*/
//			string							sActionName					/*<O>*/
//			string							sTaskName					/*<O>*/
//			string							sDateNTime					/*<O>*/
//			string							sUserName					/*<O>*/
//			string							sSurrUserName				/*<O>*/
// \return void
// This method is to parse a single line in the audit file
//-----------------------------------------------------------------------------
int GetTaskNameDateAndUserInfo(char   acInput[SS_MAXLLEN],
							   char** pctempActionName,
							   char** pctempTaskName,
							   char** pctempDateNTime,
							   char** pctempUserName,
							   char** pctempSurrUserName)
{
	char acBuffer[200] = "";
	int i = 0;
	int j = 0;
	char *pcTemp1 = NULL;
	/*char *str = NULL;
	str = malloc(sizeof (char*(acbuffer));*/
	if( tc_strcmp(acInput,"") == 0 )
		return 0;
	if( tc_strlen(acInput) > 0 )
	{
		if( ( (acInput[0] >= 'A') && (acInput[0] <= 'Z') ) || ( (acInput[0] >= 'a') && (acInput[0] <= 'z') ) )
		{
			// Action Name
			for( i = 0,j = 0;  (i < 17) && (acInput[i] != '\0'); i++, j++)
			{
				acBuffer[j] = acInput[i];
			}
			if (tc_strcmp(acBuffer, "") !=0)
			{
				RemoveTrailingBlanks(acBuffer);
				//tc_strcpy(pcTemp1, acBuffer);
				//if (pcTemp1 != NULL)
				if (tc_strcmp(acBuffer, "") != 0)
				{
					*pctempActionName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(acBuffer)+1));
					tc_strcpy(*pctempActionName, acBuffer);
					pcTemp1 = NULL;
					//memset(&acBuffer[0], 0, sizeof(acBuffer));  //Clearing the acBuffer array
					tc_strcpy(acBuffer,"");
				}
			}

			// Task Name
			for( i = 17,j = 0; (i < 43) && (acInput[i] != '\0'); i++, j++)
			{
				acBuffer[j] = acInput[i];
			}
			if (tc_strcmp(acBuffer, "") !=0)
			{
				RemoveTrailingBlanks(acBuffer);
				/*tc_strcpy(pcTemp1, acBuffer);
				if (pcTemp1 != NULL)*/
				if (tc_strcmp(acBuffer, "") != 0)
				{
					*pctempTaskName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(acBuffer)+1));
					tc_strcpy(*pctempTaskName, acBuffer);
					pcTemp1 = NULL;
					//memset(&acBuffer[0], 0, sizeof(acBuffer));
					tc_strcpy(acBuffer,"");
				}
			}

			// Date
			for( i = 43,j = 0; (i < 63) && (acInput[i] != '\0'); i++, j++)
			{
				acBuffer[j] = acInput[i];
			}
			if (tc_strcmp(acBuffer, "") !=0)
			{
				RemoveTrailingBlanks(acBuffer);
				//tc_strcpy(pcTemp1, acBuffer);
				//if (pcTemp1 != NULL)
				if (tc_strcmp(acBuffer, "") != 0)
				{
					*pctempDateNTime = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(acBuffer)+1));
					tc_strcpy(*pctempDateNTime, acBuffer);
					//pcTemp1 = NULL;
					//memset(&acBuffer[0], 0, sizeof(acBuffer));
					tc_strcpy(acBuffer,"");
				}
			}

			// User Name
			for( i = 64,j = 0; (i < 96 ) && (acInput[i] != '\0' ); i++, j++)
			{
				acBuffer[j] = acInput[i];
			}
			if (tc_strcmp(acBuffer, "") !=0)
			{
				RemoveTrailingBlanks(acBuffer);
				//tc_strcpy(pcTemp1, acBuffer);
				//if (pcTemp1 != NULL)
				if (tc_strcmp(acBuffer, "") != 0)
				{
					//getUserNameFromUserId(sBuffer, sUserName);
					*pctempUserName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(acBuffer)+1));
					tc_strcpy(*pctempUserName, acBuffer);
					//pcTemp1 = NULL;
					//memset(&acBuffer[0], 0, sizeof(acBuffer));
					tc_strcpy(acBuffer,"");
				}
			}

			// Surrogate User Name
			for( i = 97,j = 0; (acInput[i] != ' ' ); i++, j++)
			{
				acBuffer[j] = acInput[i];
			}
			if (tc_strcmp(acBuffer, "") !=0)
			{
				RemoveTrailingBlanks(acBuffer);
				//tc_strcpy(pcTemp1, acBuffer);
				//if (pcTemp1 != NULL)
				if (tc_strcmp(acBuffer, "") != 0)
				{
					*pctempSurrUserName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(acBuffer)+1));
					tc_strcpy(*pctempSurrUserName, acBuffer);
					//pcTemp1 = NULL;
					//memset(&acBuffer[0], 0, sizeof(acBuffer));
					tc_strcpy(acBuffer,"");
				}
			}
		}
	}
	return 0;
}



int parseWorkflowAuditInfoFromDatabase( tag_t tRoot,char **pcComment, char **pcRespName, char **pcRespGroup,char **pcRespRole, char **pcRejected_Task)
{
	int			iRetcode			= ITK_ok;
	int			row					= 0;
	int			column				= 0;
	const char	*select_attr_list[]	= {"object_name","object_type","fnd0EventTypeName", "task_result","task_state", "comments",
										"fnd0GroupName", "fnd0RoleName", "fnd0UserId", "responsible_partyDisp","fnd0signoffcomments",
										"fnd0signoffuserID","fnd0signoffgroupname", "fnd0signoffrolename"};
	const char	*select_attr_list1[]	= {"lsd"};

	int			iRows				= 0;
	int			iCols				= 0;
	int iSubTasksCount = 0;
	int inx = 0;
	void		***Values;
	int iCnt = 0;
	char * 	jobName = NULL;
//	char * sDate = NULL;
	logical isAutomatedTask = false;
	//date_t date = NULLDATE;
//	tag_t tRootTaskTag = NULLTAG;
	tag_t *ptSubTasksTags = NULL;
	char *pcSubTaskName = NULL;
	char *ret = NULL;
//	EPM_state_t tSubTaskState;
//	tag_t tSubTaskType = NULLTAG;
	tag_t tTemplate = NULLTAG;
//	char * pcSubTaskTypeName = NULL;
	char *pcHandlerName = NULL;
	int iCntActionHandlers = 0;
	tag_t *ptActionHandlers = NULL;
//	char *pcTaskName = NULL;
	tag_t tHandler = NULLTAG;
	logical isFound = false;
	tag_t tUser = NULLTAG;
	tag_t tPerson = NULLTAG;
	//get the job name
	iRetcode = AOM_ask_value_string(tRoot, "job_name", &jobName);

	//Create the main query
	iRetcode = POM_enquiry_create ("find_workflow_audit");

	//select output attribute for main query
	iRetcode = POM_enquiry_add_select_attrs ("find_workflow_audit", "Fnd0WorkflowAudit", 11, select_attr_list);
	iRetcode = POM_enquiry_add_select_attrs ("find_workflow_audit", "Fnd0WorkflowAudit", 1, select_attr_list1);
	//iRetcode = POM_en

	//start query expression for main query
	iRetcode = POM_enquiry_set_string_value ("find_workflow_audit", "aunique_value_id1", 1, &jobName , POM_enquiry_bind_value );
	iRetcode = POM_enquiry_set_attr_expr ("find_workflow_audit", "auniqueExprId_1","Fnd0WorkflowAudit", "job_name", POM_enquiry_equal, "aunique_value_id1" );

	/* Set the where condition so we only get back matching rows: */
	iRetcode = POM_enquiry_set_where_expr ("find_workflow_audit", "auniqueExprId_1");
	/*set the order by clause.*/
	iRetcode = POM_enquiry_add_order_attr ( "find_workflow_audit","Fnd0WorkflowAudit","lsd",POM_enquiry_desc_order);
	/* Now execute the query: */
	iRetcode = POM_enquiry_execute ("find_workflow_audit", &iRows, &iCols, &Values);

	//process result
	if(iRows > 0)
	{
		for(row = 0; row < iRows; row++)
		{
			//date = *(date_t *)Values[row][14];

			//ITK_date_to_string(date, &sDate);
			//printf("%s\t", sDate);

			//date = NULLDATE;
			isAutomatedTask = false;
			isFound = false;
			tUser = NULLTAG;
			tPerson = NULLTAG;


			if( (tc_strcmp((char *)Values[row][1],"ECMPrepareECOTask")==0 ) ||
				(tc_strcmp((char *)Values[row][1],"EPMDoTask")== 0 ) ||
				(tc_strcmp((char *)Values[row][1],"ECMChecklistTask")== 0) ||
				(tc_strcmp((char *)Values[row][1],"EPMConditionTask")==0 ) ||
				(tc_strcmp((char *)Values[row][1],"EPMPerformSignoffTask")==0 ) )
			{
				isAutomatedTask = false;
				if(tc_strcmp((char *)Values[row][1],"EPMConditionTask")==0 )
				{
					iRetcode = EPM_ask_sub_tasks(tRoot,&iSubTasksCount,&ptSubTasksTags);
					if(iRetcode == ITK_ok && iSubTasksCount > 0)
					{
						for(inx= 0;inx<iSubTasksCount;inx++)
						{
							iRetcode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
							if(iRetcode == ITK_ok)
								ret = tc_strstr(pcSubTaskName, (char *)Values[row][0]);
							if (ret != NULL)
							{
								iRetcode = AOM_ask_value_tag ( ptSubTasksTags[inx],"task_template" ,&tTemplate);
								//iRetcode = EPM_find_handler(tTemplate,EPM_action_handler_type,EPM_complete_action,cHandlerName,&tHandler);
								iRetcode = EPM_ask_action_handlers(tTemplate,EPM_start_action,&iCntActionHandlers,&ptActionHandlers);
								for(iCnt = 0; iCnt < iCntActionHandlers ; iCnt++)
								{
									iRetcode = AOM_ask_name(ptActionHandlers[iCnt],&pcHandlerName);
									if( iRetcode == ITK_ok && (tc_strcmp(pcHandlerName,"set-condition") == 0 ||
																tc_strcmp(pcHandlerName,"TIAUTO-AH-verify-status-progression") == 0 ||
																tc_strcmp(pcHandlerName,"TIAUTO-AH-check-status-progression") == 0 ||
																tc_strcmp(pcHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 )
										)
									{
										isAutomatedTask = true;
										break;
									}
								}
								SAFE_MEM_free( ptActionHandlers);
								if( isAutomatedTask == false)
								{
									iRetcode = EPM_find_handler(tTemplate,EPM_rule_handler_type,EPM_start_action,"TIAUTO-RH-check-mra-dataset-creation",&tHandler);
									if(iRetcode == ITK_ok && tHandler !=NULLTAG )
									{
										isAutomatedTask = true;
										break;
									}
								}
								break;
							}
							SAFE_MEM_free(pcSubTaskName);
						}
					}
					SAFE_MEM_free( ptSubTasksTags);
					if(isAutomatedTask == true)
					{
						continue;
					}
				}

				if ( (tc_strcmp((char *)Values[row][2],"__Complete") == 0) || (tc_strcmp((char *)Values[row][2],"__Reject") == 0) ||
					 (tc_strcmp((char *)Values[row][2],"__Demote") == 0) || (tc_strcmp((char *)Values[row][2],"__Complete") == 0))
				{
					for(column = row +1; column < iRows; column++)
					{
						if( (tc_strcmp((char *)Values[column][1],"ECMPrepareECOTask")==0 ) ||
							(tc_strcmp((char *)Values[column][1],"EPMDoTask")== 0 ) ||
							(tc_strcmp((char *)Values[column][1],"ECMChecklistTask")== 0) ||
							(tc_strcmp((char *)Values[column][1],"EPMConditionTask")==0 ) ||
							(tc_strcmp((char *)Values[column][1],"EPMPerformSignoffTask")==0 ) )
						{
						}
						else
						{
							continue;
						}
						if  (tc_strcmp((char *)Values[column][2],"__Reject") == 0)
						{
							if (tc_strcmp((char *)Values[column][0],((char *)Values[row][0])) == 0)
							{
								isFound = true;
								*pcRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][0])+1));
								tc_strcpy(*pcRejected_Task, (char *)Values[column][0]);

								*pcComment = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][10])+1));
									tc_strcpy(*pcComment, (char *)Values[column][10]);

								*pcRespGroup = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][12])+1));
								tc_strcpy(*pcRespGroup, (char *)Values[column][6]);

								*pcRespRole = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][13])+1));
								tc_strcpy(*pcRespRole, (char *)Values[column][7]);

								iRetcode = SA_find_user((char *)Values[column][11], &tUser);	
								if(tUser != NULLTAG)
									iRetcode = SA_ask_user_person( tUser, &tPerson );
								if(tPerson != NULLTAG)
									iRetcode = SA_ask_person_name2(tPerson,pcRespName);

								if(pcRespName == NULL)
								{
									*pcRespName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][11])+1));
									tc_strcpy(*pcRespName, (char *)Values[column][11]);
								}

								break;
							}
							else
							{
								break;
							}
						}
						if  (tc_strcmp((char *)Values[column][2],"__Complete") == 0)
						{
							if (tc_strcmp((char *)Values[column][0],((char *)Values[row][0])) == 0)
							{
								isFound = true;
								*pcRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][0])+1));
								tc_strcpy(*pcRejected_Task, (char *)Values[column][0]);

								*pcComment = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][5])+1));
									tc_strcpy(*pcComment, (char *)Values[column][5]);

								*pcRespGroup = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][6])+1));
								tc_strcpy(*pcRespGroup, (char *)Values[column][6]);

								*pcRespRole = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][7])+1));
								tc_strcpy(*pcRespRole, (char *)Values[column][7]);

								iRetcode = SA_find_user((char *)Values[column][8], &tUser);	
								if(tUser != NULLTAG)
									iRetcode = SA_ask_user_person( tUser, &tPerson );
								if(tPerson != NULLTAG)
									iRetcode = SA_ask_person_name2(tPerson,pcRespName);

								if(pcRespName == NULL)
								{
									*pcRespName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][8])+1));
									tc_strcpy(*pcRespName, (char *)Values[column][8]);
								}

								break;
							}
							else
							{
								break;
							}
						}
						if  (tc_strcmp((char *)Values[column][2],"__Start") == 0)
						{
							if ( (tc_strcmp((char *)Values[column][0],(char *)Values[row][0]) ) == 0)
							{
								isFound = true;
								*pcRejected_Task = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[row][0])+1));
								tc_strcpy(*pcRejected_Task, (char *)Values[row][0]);

								*pcComment = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[row][5])+1));
									tc_strcpy(*pcComment, (char *)Values[row][5]);

								/*if(tc_strcmp((char *)Values[column][1],"EPMPerformSignoffTask")==0 )
								{
									*pcRespGroup = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][12])+1));
									tc_strcpy(*pcRespGroup, (char *)Values[column][6]);

									*pcRespRole = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][13])+1));
									tc_strcpy(*pcRespRole, (char *)Values[column][7]);

									*pcRespName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[column][11])+1));
									tc_strcpy(*pcRespName, (char *)Values[column][9]);
								}
								else
								{*/
									*pcRespGroup = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[row][6])+1));
									tc_strcpy(*pcRespGroup, (char *)Values[row][6]);

									*pcRespRole = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[row][7])+1));
									tc_strcpy(*pcRespRole, (char *)Values[row][7]);

									iRetcode = SA_find_user((char *)Values[row][8], &tUser);	
									if(tUser != NULLTAG)
										iRetcode = SA_ask_user_person( tUser, &tPerson );
									if(tPerson != NULLTAG)
										iRetcode = SA_ask_person_name2(tPerson,pcRespName);

									if(pcRespName == NULL)
									{
										*pcRespName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen((char *)Values[row][8])+1));
										tc_strcpy(*pcRespName, (char *)Values[row][8]);
									}
								//}

								break;
							}
							else
							{
								break;
							}
						}
					}
				}

			}
			if(isFound == true)
			{
				break;
			}
		}

	}

	SAFE_MEM_free(jobName);
	SAFE_MEM_free(Values);
	/*Delete the query*/
	iRetcode = POM_enquiry_delete ( "find_workflow_audit" );

	return iRetcode;
}


/*=====================================================================================
*   tiauto_Store_ChangeAttrs()
*\param				TIA_UniqueWSOMObjects	**TaskNamesPerUserList, <O>
*					int						*iNumTags		<O>
*					tag_t					tWsomtag,		<I>
*\return void				
* Description:
*			To store all the tasks per user(unique).
=====================================================================================*/
extern void tiauto_Store_ChangeAttrs(TIA_ChangeAttrs **currErrMsg,int *iNumTags, const char* pcAttr)
{

	TIA_ChangeAttrs *temp;
    logical isPresent = false;
	temp = *currErrMsg;

	if( (*currErrMsg == NULL) || (temp == NULL) )
	{
		*currErrMsg=malloc(sizeof(TIA_ChangeAttrs));
		temp = *currErrMsg;
		TI_sprintf(temp->acChangeAttrs, "");
	}
	else
	{	
		for(;;)
		{
			if( tc_strcmp(temp->acChangeAttrs, pcAttr) == 0 )
			{
				isPresent = true;
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else 
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_ChangeAttrs));
			temp=temp->next;
			TI_sprintf(temp->acChangeAttrs, "");
		}
	}
	if ( isPresent == false )
	{
		TI_sprintf(temp->acChangeAttrs,"%s",pcAttr);
		(*iNumTags) ++;
		temp->next  = NULL;
	}	
	//free ( temp );
	temp = NULL;
}

int verify_Valid_ACD_Condition(tag_t tTask,boolean *bMfgRelToBeCreated,char **pcValidReleaseStatusList)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				indx1										= 0;
//	int				iNumLOVs = 0;
//	int				iNumLOVValues = 0;
//	int				iCount = 0;
	int				iSite = 0;
	int				iSiteID = 0;
	int				iNewAseemCount = 0;
	int				iOldAseemCount = 0;
	int				iCompMRACount = 0;

//	char			**pcLOVValues				= NULL;
//	char			**pcLOVValue				= NULL;
//	char			*pcTemp1					= NULL;
//	char			*pcTemp						= NULL;
	//char			*pcFacilityName				= NULL;
//	char			*pcAffectedProgramName		= NULL;
//	char			*pcTIDivisionname			= NULL;
	char			*pcTargetReleaseStatus		= NULL;
//	char			**pcAffectedProgramNames	= NULL;

	char			acSiteName[SA_site_size_c+1]	  = {'\0'};
	char		    acRootTaskName[WSO_name_size_c+1] = "";

	tag_t			tChangeRev								= NULLTAG;
	tag_t			tRootTask								= NULLTAG;
	tag_t           tChangeForm								= NULLTAG;
	tag_t			tSite									= NULLTAG;
//	tag_t			*ptLOVs = NULL;
	tag_t			*ptNewAssembly = NULL;
	tag_t			*ptOldAssembly = NULL;
	tag_t			*ptCompMRA = NULL;
//	boolean bValidERPPlant = false;
	boolean bValidMRACondition = false;
	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;
	TC_preference_search_scope_t tScope;
	char **pReleaseStatusList = NULL;
	int iRelStatCount = 0;
	
	*bMfgRelToBeCreated = false;

	iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	//get the site name mentioned in the preference
	iRetCode = PREF_ask_search_scope( &tScope );
	if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );
    if (iRetCode == ITK_ok)
    {
        iRetCode = PREF_ask_char_values("TI_ACD_Valid_ReleaseStatus_List", &iRelStatCount, &pReleaseStatusList);
        if (iRetCode != ITK_ok)
        {
			iRetCode = 0;
			return 0;
        }
		
    }
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( tScope );

	iRetCode = tiauto_get_change_item_rev (tTask, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		iRetCode = tiauto_get_status_progression_array (&StatusProgression);

		tSite = NULLTAG;
		//get the owning site
		iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
		//get the root task
		iRetCode = EPM_ask_root_task (tTask, &tRootTask) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}
		//read the change form and
		if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TPR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193tiplant",&pcFacilityName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193affectedprogram",&pcAffectedProgramName);
				//iRetCode = AOM_ask_value_string(tChangeForm,"t8_193productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a201targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201newacdassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201componentacd",&iCompMRACount,&ptCompMRA);
			}
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TER",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193tiplant",&pcFacilityName);
				//iRetCode = AOM_UIF_ask_value(tChangeForm,"t8_193affectedprogram",&pcAffectedProgramName);
				//iRetCode = AOM_ask_value_string(tChangeForm,"t8_193productgroup",&pcTIDivisionname);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a205targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205newacdassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205componentmra",&iCompMRACount,&ptCompMRA);
			}
		}
		if(pcTargetReleaseStatus != NULL)
		{
			tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,pcTargetReleaseStatus);
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
		}
	}
	for(indx = 0;indx<iRelStatCount;indx++)
	{
		if(tc_strstr(pReleaseStatusList[indx],pcTargetReleaseStatus) != NULL)
		{
			bValidMRACondition = true;
			break;
		}
	}

	if(bValidMRACondition == false)
	{
		*bMfgRelToBeCreated = false;
		return 0;
	}

	for(indx1 = 0;indx1<iNewAseemCount;indx1++)
	{
		iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptNewAssembly[indx1],pcTargetReleaseStatus,"All",bMfgRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
		if(*bMfgRelToBeCreated == true)
		{
			*bMfgRelToBeCreated = false;
			bValidMRACondition = false;
			iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptNewAssembly[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											false, iNewAseemCount,ptNewAssembly,&bValidMRACondition);
			if(bValidMRACondition == true)
			{
				*bMfgRelToBeCreated = true;
				break;
			}
		}
	}
	if(*bMfgRelToBeCreated == false)
	{
		for(indx1 = 0;indx1<iCompMRACount;indx1++)
		{
			iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptCompMRA[indx1],pcTargetReleaseStatus,"All",bMfgRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
			if(*bMfgRelToBeCreated == true)
			{
				*bMfgRelToBeCreated = false;
				bValidMRACondition = false;
				iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptCompMRA[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											true, iNewAseemCount,ptNewAssembly,&bValidMRACondition );

				if(bValidMRACondition == true)
				{
					*bMfgRelToBeCreated = true;
					break;
				}
			}
		}
	}
							
	
	return iRetCode;
}

//PRP
int verify_Valid_PRA_Condition(tag_t tTask,boolean *bProRelToBeCreated,char **pcValidReleaseStatusList)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				indx1										= 0;

	int				iSite = 0;
	int				iSiteID = 0;
	int				iNewAseemCount = 0;
	int				iOldAseemCount = 0;
	int				iCompPRACount = 0;

	char			*pcTargetReleaseStatus		= NULL;

	char			acSiteName[SA_site_size_c+1]	  = {'\0'};
	char		    acRootTaskName[WSO_name_size_c+1] = "";

	tag_t			tChangeRev								= NULLTAG;
	tag_t			tRootTask								= NULLTAG;
	tag_t           tChangeForm								= NULLTAG;
	tag_t			tSite									= NULLTAG;
//	tag_t			*ptLOVs = NULL;
	tag_t			*ptNewAssembly = NULL;
	tag_t			*ptOldAssembly = NULL;
	tag_t			*ptCompPRA = NULL;
//	boolean bValidERPPlant = false;
	boolean bValidPRACondition = false;
	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;
	TC_preference_search_scope_t tScope;
	char **pReleaseStatusList = NULL;
	int iRelStatCount = 0;
	
	*bProRelToBeCreated = false;

	iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	//get the site name mentioned in the preference
	iRetCode = PREF_ask_search_scope( &tScope );
	if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );
    if (iRetCode == ITK_ok)
    {
        iRetCode = PREF_ask_char_values("TI_PRA_Valid_ReleaseStatus_List", &iRelStatCount, &pReleaseStatusList);
        if (iRetCode != ITK_ok)
        {
			iRetCode = 0;
			return 0;
        }
		
    }
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( tScope );

	iRetCode = tiauto_get_change_item_rev (tTask, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		iRetCode = tiauto_get_status_progression_array (&StatusProgression);

		tSite = NULLTAG;
		//get the owning site
		iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
		//get the root task
		iRetCode = EPM_ask_root_task (tTask, &tRootTask) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}
		//read the change form and
		
		if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PRP",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a206targetreleasestate",&pcTargetReleaseStatus);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a206newtoplevelassem",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a206oldtoplevelassem",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a206componentpra",&iCompPRACount,&ptCompPRA);
			}
		}
		
		if(pcTargetReleaseStatus != NULL)
		{
			tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,pcTargetReleaseStatus);
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
		}
	}
	for(indx = 0;indx<iRelStatCount;indx++)
	{
		if(tc_strstr(pReleaseStatusList[indx],pcTargetReleaseStatus) != NULL)
		{
			bValidPRACondition = true;
			break;
		}
	}

	if(bValidPRACondition == false)
	{
		*bProRelToBeCreated = false;
		return 0;
	}

	for(indx1 = 0;indx1<iNewAseemCount;indx1++)
	{
		iRetCode = verify_ProReleaseAuthorisation_Creation_Condition(ptNewAssembly[indx1],pcTargetReleaseStatus,"All",bProRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
		if(*bProRelToBeCreated == true)
		{
			*bProRelToBeCreated = false;
			bValidPRACondition = false;
			iRetCode = verify_ProReleaseAuthorisation_Creation_Additional_Condition(ptNewAssembly[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											false, iNewAseemCount,ptNewAssembly,&bValidPRACondition);
			if(bValidPRACondition == true)
			{
				*bProRelToBeCreated = true;
				break;
			}
		}
	}
	if(*bProRelToBeCreated == false)
	{
		for(indx1 = 0;indx1<iCompPRACount;indx1++)
		{
			iRetCode = verify_ProReleaseAuthorisation_Creation_Condition(ptCompPRA[indx1],pcTargetReleaseStatus,"All",bProRelToBeCreated);//pcLOVValue[7],bMfgRelToBeCreated);
			if(*bProRelToBeCreated == true)
			{
				*bProRelToBeCreated = false;
				bValidPRACondition = false;
				iRetCode = verify_ProReleaseAuthorisation_Creation_Additional_Condition(ptCompPRA[indx1],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,
											true, iNewAseemCount,ptNewAssembly,&bValidPRACondition );

				if(bValidPRACondition == true)
				{
					*bProRelToBeCreated = true;
					break;
				}
			}
		}
	}
							
	
	return iRetCode;
}


int verify_ProReleaseAuthorisation_Creation_Condition(tag_t tItemRev,char *pcTargetStatus,char *pcValidStatusList,
													  boolean *bProRelAuth)
{
	int   iRetCode									= ITK_ok;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
	
	*bProRelAuth = false;
	iRetCode = tiauto_get_release_status(tItemRev,szReleaseStatus);
	if( (tc_strcmp(pcTargetStatus,szReleaseStatus) == 0) )
	{
		*bProRelAuth = true;
		
	}
	else
	{
		*bProRelAuth = true;
	}

	return iRetCode;
}


int verify_ProReleaseAuthorisation_Creation_Additional_Condition( tag_t tItemRev,
																  tag_t tEngChgRev,
																  char *pcTargetReleaseStatus,
																  STATUS_Struct_t	*StatusProgression,
																  TARGET_RELEASE_Struct_t *TargetReleaseStatus,
																  boolean bIsComponentPRA,
																  int iNewAseemCount,
																  tag_t *ptNewAssembly,
																  boolean *bIsValid)
{
	int iFail = ITK_ok;
	int iCount = 0;
	int iRefItemRevs = 0;
	int iITRMCount = 0;
	tag_t tRelationType = NULLTAG;
	tag_t *ptRefItemRevs = NULL;
	tag_t *ptITRMAttach = NULL;
	logical lIsAffected = false;
    char    szReleaseStatus[WSO_name_size_c+1]		  = "";
	char *pcERPIntValue = NULL;
	boolean bIsFoundInNewAssmb = false;

	*bIsValid = false;

	lIsAffected = tiauto_isComponent_partOf_affectedItems(tItemRev,tEngChgRev);
	if(lIsAffected == true)
	{
		*bIsValid = true;
	}
	else if(lIsAffected == false)
	{
		char    pszObjType[WSO_name_size_c+1]="";
		iFail = WSOM_ask_object_type(tEngChgRev, pszObjType);

		if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
		{
			tag_t tRelTemp = NULLTAG;
			iFail = GRM_find_relation_type ("CMReferences",&tRelTemp);
			if(iFail == ITK_ok && tRelTemp!=NULLTAG)
			{
				iFail = GRM_list_secondary_objects_only(tEngChgRev,tRelTemp,&iRefItemRevs,&ptRefItemRevs);
			}
		}
		else
			iFail = ECM_get_contents (tEngChgRev,"reference_items",&iRefItemRevs,&ptRefItemRevs);

		//verify in Ref. folder
		for (iCount = 0; iCount < iRefItemRevs && (iFail == ITK_ok); iCount++)
		{
			if (tItemRev == ptRefItemRevs[iCount])
			{
				//get the release status
				iFail = tiauto_get_release_status( tItemRev, szReleaseStatus );
				if(tiauto_status_progression_index (szReleaseStatus, *StatusProgression) >=  TargetReleaseStatus->iLevel )
				{
					*bIsValid = true;
					/*iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
					if(tRelationType != NULLTAG)
						iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType,&iITRMCount,&ptITRMAttach);
					if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
					{
						//get the Master Drawing and Rev value from the item rev master form
						iFail = AOM_UIF_ask_value (ptITRMAttach[0],"t8_1erpintegration",&pcERPIntValue);
						if(tc_strstr(pcERPIntValue,"NA - BPCS 8.2 - Auburn Hills") == NULL)
						{
							*bIsValid = true;
						}
					}*/
				}
				break;
			}
		}
		SAFE_MEM_free(ptRefItemRevs);
		
		if(lIsAffected == false)
		{
			char    pszObjType[WSO_name_size_c+1]="";			

			iFail = WSOM_ask_object_type(tEngChgRev, pszObjType);
			if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
			{
				tag_t tRelTemp = NULLTAG;
				iFail = GRM_find_relation_type ("CMHasProblemItem",&tRelTemp);
				if(iFail == ITK_ok && tRelTemp!=NULLTAG)
				{
					iFail = GRM_list_secondary_objects_only(tEngChgRev,tRelTemp,&iRefItemRevs,&ptRefItemRevs);
				}
			}

			//verify in Ref. folder
			for (iCount = 0; iCount < iRefItemRevs && (iFail == ITK_ok); iCount++)
			{
				if (tItemRev == ptRefItemRevs[iCount])
				{
					//get the release status
					iFail = tiauto_get_release_status( tItemRev, szReleaseStatus );
					if(tiauto_status_progression_index (szReleaseStatus, *StatusProgression) >=  TargetReleaseStatus->iLevel )
					{
						*bIsValid = true;
						/*iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
						if(tRelationType != NULLTAG)
							iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType,&iITRMCount,&ptITRMAttach);
						if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
						{
							//get the Master Drawing and Rev value from the item rev master form
							iFail = AOM_UIF_ask_value (ptITRMAttach[0],"t8_1erpintegration",&pcERPIntValue);
							if(tc_strstr(pcERPIntValue,"NA - BPCS 8.2 - Auburn Hills") == NULL)
							{
								*bIsValid = true;
							}
						}*/
					}
					break;
				}
			}
			SAFE_MEM_free(ptRefItemRevs);
		}
	}

	if( ((*bIsValid) == true ) && (bIsComponentPRA == true) )
	{
		//verify in the New Top Assembly List
		for (iCount = 0; iCount < iNewAseemCount && (iFail == ITK_ok); iCount++)
		{
			if(ptNewAssembly[iCount] == tItemRev)
			{
				*bIsValid = false;
				bIsFoundInNewAssmb = true;
				break;
			}
		}
		//verify the child components of the assembly
		if(bIsFoundInNewAssmb == false)
		{
			for (iCount = 0; iCount < iNewAseemCount && (iFail == ITK_ok); iCount++)
			{
				iFail = verify_ChildPart_in_ParentBOM(tItemRev,ptNewAssembly[iCount],&bIsFoundInNewAssmb);
				if(bIsFoundInNewAssmb == true)
				{
					*bIsValid = false;
					break;
				}
			}
		}
	}

	return iFail;
}