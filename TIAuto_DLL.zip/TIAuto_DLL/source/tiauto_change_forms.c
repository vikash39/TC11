
/*******************************************************************************
File         : tiauto_change_forms.c

Description  : This Action handler will create a copy of the statussed forms in the change folder 
               and creates a relation between old and new form..The corresponding properties of the new form
               is modified so that it is a true copy of the old form.The status of the old form is released
               and made it editable for modfication by user..

Input        : None
                        
Output       : None

Author       : Arun Kumar,TCS

Revision History :
Date            Revision    Who              Description
June 29, 2007    1.0         Arun Kumar  Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


static  int create_a_copy_of_form(tag_t     tForm);
static int  remove_existing_form_status (int    num_forms,
                                        tag_t   *change_forms);

int t1aSetStatus (tag_t object_t, tag_t status_t, date_t release_time);

static  int create_a_copy_of_statussed_forms (tag_t     task_tag,
                                              int  num_attachments,
                                              tag_t   *attachment_tags,
                                              int       num_forms,
                                              tag_t     *change_forms);

static int  update_history_form_properties(tag_t tForm, tag_t tNewform);


static int getForms(char **arg_forms,int num_formType, tag_t   *Attach_forms,int num_attach,tag_t   **change_forms,int *num_forms);

static int getArgs(EPM_action_message_t msg,char*** arg_forms,int *num_formType);

extern void  print_err_msg( int status );

/* This function will write the error message to syslog*/
extern void  print_err_msg( int status )
{
    char *err_text = NULL;
    EMH_store_error( EMH_severity_error, status );
    EMH_ask_error_text (status, &err_text );
    printf( "Error %d: %s\n", status, err_text );
    TC_write_syslog  ( "Error : %s\n", err_text);
    MEM_free(err_text);
}
//********************************************************************************************************************

/*==================================================================
*    Implementation of Action Handler -  t1aAUTO_allow_form_changes
====================================================================*/


extern int t1aAUTO_allow_form_changes(EPM_action_message_t msg)
{

    int     iRetCode = ITK_ok;
    /*int     indx = 0;
    int     num_attachments = 0;
    int     num_forms = 0;
    int     num_attach = 0;
    int     num_formType = 0;

    tag_t   *attachment_tags = NULL;
    tag_t   *Attach_forms = NULL;
    tag_t   *change_forms = NULL; 
    tag_t   job_tag = NULLTAG;
    tag_t   root_task_tag = NULLTAG;
    tag_t   relation_type = NULLTAG;

    char    type_name[TCTYPE_name_size_c+1];
    char **arg_forms = NULL;


   
    iRetCode = GRM_find_relation_type (TIAUTO_HISTORY_FORM_REL_TYPE, &relation_type);
    
    if (iRetCode == ITK_ok)
        iRetCode = tiauto_get_task_attachments (msg, EPM_target_attachment,
                                        &num_attachments, &attachment_tags);

    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_job (msg.task, &job_tag);
    if (iRetCode == ITK_ok ) 
        iRetCode = EPM_ask_root_task (job_tag , &root_task_tag);
     
    for (indx = 0; indx < num_attachments && (iRetCode == ITK_ok); indx++)
    {   
        iRetCode = tiauto_get_object_name (attachment_tags[indx], type_name);
        
            if(tc_strcasecmp( type_name , "EngChange Revision")== 0 && (iRetCode == ITK_ok) )
            {
                iRetCode = ECM_get_contents(attachment_tags[indx], "t1achanged_forms", &num_attach, &Attach_forms);
              
                //getting the handler args
                if (iRetCode == ITK_ok)
                iRetCode = getArgs( msg, &arg_forms,&num_formType);  
                 
                //This function will get the statused forms for handler processing.
                if (iRetCode == ITK_ok)
                    iRetCode = getForms(arg_forms,num_formType,Attach_forms,num_attach,&change_forms,&num_forms);

                if (iRetCode == ITK_ok)
                    iRetCode = create_a_copy_of_statussed_forms (msg.task,num_attachments,attachment_tags, num_forms, change_forms);

                if (iRetCode == ITK_ok)
                    iRetCode = remove_existing_form_status (num_forms, change_forms); 
                    
            }
    }
    // clean up the memory allocation

    if ( attachment_tags )   MEM_free ( attachment_tags);
    if ( change_forms ) 	 MEM_free ( change_forms);
    if ( arg_forms ) 	 MEM_free ( arg_forms);
    if ( Attach_forms ) 	 MEM_free ( Attach_forms);
    

   if(iRetCode != ITK_ok)
    {
           print_err_msg(iRetCode);
           iRetCode = ITK_ok;
    }
	*/
    return iRetCode;
}
//********************************************************************************************************************
/* This function will get the released forms and get a copy*/
static  int create_a_copy_of_statussed_forms (tag_t     task_tag,
                                              int  num_attachments,
                                              tag_t   *attachment_tags,
                                              int       num_forms, 
                                              tag_t     *change_forms)
{


    int     iRetCode = ITK_ok;
    int     indx = 0;
    int     status_count = 0;
    int     attachment_type = EPM_target_attachment;

    tag_t   *status_list= NULL;
     
    char *err_text = NULL;


    for (indx = 0; indx < num_forms && (iRetCode == ITK_ok); indx++)
    {   
          //check whether the form is statussed.
        iRetCode = WSOM_ask_release_status_list(change_forms[indx], &status_count, &status_list);
        if ( status_count >= 1 && iRetCode == ITK_ok )
        {   
            //adding the forms as target  to get access..If the form is already a target leave it.
             if (EPM__ask_if_target(change_forms[indx], attachment_tags, num_attachments) != IS_A_TARGET)
                 iRetCode = EPM_add_attachments (task_tag, 1, &change_forms[indx], &attachment_type);
             

                if(iRetCode != ITK_ok)
                {
                EMH_ask_error_text( iRetCode, &err_text );
                printf ("for error <%6d> err_text < %s> \n", iRetCode, err_text );
                printf("\n retcode of EPM_add_attachments : %d", iRetCode);
                }
               
            if (iRetCode == ITK_ok)
               iRetCode = create_a_copy_of_form (change_forms[indx]);

           //removing the form from the target.
            if (iRetCode == ITK_ok)
               iRetCode = EPM_remove_attachments(task_tag, 1, &change_forms[indx]);
        }
    }

    if ( status_list )      MEM_free ( status_list);
    if ( err_text )      MEM_free ( err_text);

    if(iRetCode != ITK_ok)
    {
          print_err_msg(iRetCode);
           iRetCode = ITK_ok;
    }
    
    return iRetCode;
}
//*******************************************************************************************************************
/* This function will create a copy of the input form*/

static  int create_a_copy_of_form(tag_t tForm)
{
        int     iRetCode = ITK_ok;

        tag_t   tNewform = NULLTAG;
        tag_t   tRelationtype = NULLTAG;
        tag_t   tRelation = NULLTAG;        
      

        iRetCode = GRM_find_relation_type (TIAUTO_HISTORY_FORM_REL_TYPE, &tRelationtype);

        if (iRetCode == ITK_ok)
            iRetCode = WSOM_copy(tForm, NULL, &tNewform);
        if (iRetCode == ITK_ok)
            iRetCode = AOM_save (tNewform);
        if (iRetCode == ITK_ok)
            iRetCode = AOM_refresh (tNewform, true);

        //update the properties of the forms.
        if (iRetCode == ITK_ok)
            iRetCode = update_history_form_properties(tForm, tNewform);

        if (iRetCode == ITK_ok)
        iRetCode = AOM_refresh (tForm, true);
        
        // creating the relation between old form and new form
        if (iRetCode == ITK_ok)
            iRetCode = GRM_create_relation( tForm, tNewform, tRelationtype,
                                            NULLTAG, &tRelation);
        if (iRetCode == ITK_ok)
            iRetCode =  GRM_save_relation(tRelation);

        if (iRetCode == ITK_ok)
            iRetCode = AOM_save(tForm);
        
        if (iRetCode == ITK_ok)
            iRetCode = AOM_refresh( tForm , false);

        if(iRetCode != ITK_ok)
        {
             print_err_msg(iRetCode);
            iRetCode = ITK_ok;
        }
     
        return iRetCode;
}
//*************************************************************************************************
/* This function will update the properties of the input form*/
static int  update_history_form_properties(tag_t tForm, 
                                           tag_t tNewform)
{
        int     iRetCode = ITK_ok;
       
        char    *pcClassName = NULL;
        char    *err_text = NULL;

        tag_t   tRelStatAttrId = NULLTAG;
        tag_t   tRelDateAttrId = NULLTAG;
        tag_t   tModDateAttrId = NULLTAG;
        tag_t   tCreaDateAttrId = NULLTAG;
        tag_t   *ptReleaseStat = NULL;
        tag_t   tClass = NULLTAG;
        tag_t   tOwner = NULLTAG;
        tag_t   tOwningGrp = NULLTAG;
        tag_t   tOwnerAttrId = NULLTAG;
        tag_t   tOwnerId = NULLTAG; 

        date_t  tReleasedDate = NULLDATE;
        date_t  tModifiedDate = NULLDATE;
        date_t  tCreatedDate = NULLDATE;

        logical check_null_rel = false;
        logical check_empty_rel = false;
        logical check_null_mod = false;
        logical check_empty_mod = false;
        logical check_null_cre = false;
        logical check_empty_cre = false;
        logical *check_null_stat = NULL;
        logical *check_empty_stat = NULL;
        logical verdict = false;
        logical check_null_owner= false;
        logical  check_empty_owner= false;             

        iRetCode = POM_class_of_instance (tForm, &tClass);
          
          //  reading the attribute is from form

            if (iRetCode == ITK_ok)
                iRetCode = POM_name_of_class (tClass, &pcClassName);
                 
            if (iRetCode == ITK_ok)
                iRetCode = POM_attr_id_of_attr ("release_status_list", pcClassName, &tRelStatAttrId);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_attr_id_of_attr ("date_released", pcClassName, &tRelDateAttrId);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_attr_id_of_attr ("last_mod_date", pcClassName, &tModDateAttrId);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_attr_id_of_attr ("creation_date", pcClassName, &tCreaDateAttrId);

            if (iRetCode == ITK_ok)
                iRetCode = POM_attr_id_of_attr ("owning_user", pcClassName, &tOwnerAttrId);
           
            iRetCode = POM_is_loaded(tForm, &verdict);

            iRetCode = POM_attr_id_of_attr ("creation_date", pcClassName, &tCreaDateAttrId);
         
            // getting the released date,modified date,release status from the old form
            if (verdict == TRUE && iRetCode == ITK_ok)
            {
                iRetCode = POM_unload_instances(1, &tForm);
            }

            iRetCode=POM_load_instances_any_class(1, &tForm, POM_no_lock);

           if ( iRetCode == ITK_ok )
		        iRetCode = POM_ask_attr_date(tForm, tRelDateAttrId, &tReleasedDate, &check_null_rel, &check_empty_rel);
         
	        if ( iRetCode == ITK_ok )
		        iRetCode = POM_ask_attr_date(tForm, tCreaDateAttrId, &tCreatedDate, &check_null_cre, &check_empty_cre);

	        if ( iRetCode == ITK_ok )
		        iRetCode = POM_ask_attr_tags(tForm, tRelStatAttrId, 0, 1, &ptReleaseStat, &check_null_stat, &check_empty_stat);

            if ( iRetCode == ITK_ok )
		        iRetCode = POM_ask_attr_date(tForm, tModDateAttrId, &tModifiedDate, &check_null_mod, &check_empty_mod);
           

            if ( iRetCode == ITK_ok )
                iRetCode = POM_ask_owner(tForm, &tOwner, &tOwningGrp);
            
            iRetCode=POM_load_instances_any_class(1, &tNewform, POM_no_lock);
            if(iRetCode != ITK_ok)
                {
                EMH_ask_error_text( iRetCode, &err_text );
                printf ("for error <%6d> err_text < %s> \n", iRetCode, err_text );
                printf("\n retcode of EPM_add_attachments : %d", iRetCode);
                }
          

            if ( iRetCode == ITK_ok )
		        iRetCode = POM_ask_attr_tag(tNewform, tOwnerAttrId, &tOwnerId, &check_null_owner, &check_empty_owner);
                  

            iRetCode = POM_is_loaded(tForm, &verdict);

            if (verdict == TRUE && iRetCode == ITK_ok)
            {
                iRetCode=POM_unload_instances(1, &tForm);
            }
          //setting the owner of the old form as task owner
            iRetCode = POM_load_instances_any_class(1, &tForm, POM_modify_lock);

            if(iRetCode != ITK_ok)
            {
            EMH_ask_error_text( iRetCode, &err_text );
            printf ("for error <%6d> err_text < %s> \n", iRetCode, err_text );
            printf("\n retcode of EPM_add_attachments : %d", iRetCode);
            }

            if ( iRetCode == ITK_ok )
                iRetCode = POM_set_attr_date(1, &tForm, tCreaDateAttrId, tModifiedDate);
           
            //   iRetCode = POM_set_owning_user(tForm, tNOwner);
            if ( iRetCode == ITK_ok )  
            iRetCode=POM_set_attr_tag(1, &tForm, tOwnerAttrId, tOwnerId);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_save_instances(1, &tForm, FALSE);
           
             if ( iRetCode == ITK_ok )
            iRetCode = POM_refresh_instances_any_class(1, &tForm, POM_no_lock);

            //end of code added by Arun
           if ( iRetCode == ITK_ok )
            iRetCode = POM_is_loaded(tNewform, &verdict);

            if (verdict == TRUE && iRetCode == ITK_ok)
            {
                iRetCode=POM_unload_instances(1, &tNewform);
            }
            //Modifying the values of the new form

            iRetCode = POM_load_instances_any_class(1, &tNewform, POM_modify_lock);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_set_attr_date(1, &tNewform, tCreaDateAttrId, tCreatedDate);

            if ( iRetCode == ITK_ok )
                    iRetCode=POM_set_attr_date(1, &tNewform, tModDateAttrId, tModifiedDate);

            if ( iRetCode == ITK_ok )
                iRetCode = POM_set_owning_user(tNewform, tOwner);

                   
            if ( iRetCode == ITK_ok )
                iRetCode = POM_save_instances(1, &tNewform, FALSE);
                  
            if ( iRetCode == ITK_ok )
                iRetCode = POM_refresh_instances_any_class(1, &tNewform, POM_no_lock);

            //setting the release status and relaese date

            if (iRetCode == ITK_ok)
                iRetCode = t1aSetStatus(tNewform, ptReleaseStat[0], tReleasedDate);

            if(iRetCode != ITK_ok)
            {
                  print_err_msg(iRetCode);
                 iRetCode = ITK_ok;
            }
            if ( err_text )      MEM_free ( err_text);  
            if ( pcClassName )      MEM_free ( pcClassName);  
        return  iRetCode;

}
//***************************************************************************************************************
/* This function will remove the status from the input form*/
static int  remove_existing_form_status (int    num_forms,
                                        tag_t   *change_forms)
{
        int     iRetCode = ITK_ok;
        int     indx = 0;
        int     *att_types = NULL;

        char    *cProcess = "Remove Status";
        char    *pcProcessDesc = "Process template for removing existing status";
        char    *pcProcessName ="test";

        tag_t   tProcessTemplate = NULLTAG;
        tag_t   tNewProcess = NULLTAG;
       
              
                  
        att_types = (int*) MEM_alloc (sizeof(int) * (1 + num_forms));

        for ( indx = 0; indx < num_forms; indx++ )
            att_types[indx]  = EPM_target_attachment;

        iRetCode = EPM_find_process_template (cProcess, &tProcessTemplate);

        if( DEBUG_PRINT ) printf("\n retcode of findng template : %d", iRetCode);
         // Removing the status of the form using quick release process.

        if (iRetCode == ITK_ok)
            iRetCode = EPM_create_process (pcProcessName, pcProcessDesc, tProcessTemplate, num_forms,
                                        change_forms, att_types, &tNewProcess);

        if( DEBUG_PRINT ) printf("\n retcode of remove_existing_form_status process : %d", iRetCode);

        if (att_types)      MEM_free (att_types);

        if(iRetCode != ITK_ok)
        {
            print_err_msg(iRetCode);
           iRetCode = ITK_ok;
        }
        return  iRetCode;

}
//**************************************************************************************************************
/* This function will set the release status on the input form*/
int t1aSetStatus (tag_t object_t,
                  tag_t status_t,
                  date_t release_time)

{
    
        int            status = ITK_ok;
        int            relattlen=0;

        char           *classid_s = NULL;

        logical        verdict = FALSE;

        tag_t          object_relID = NULLTAG;
        tag_t          object_reldateID = NULLTAG;
        tag_t          object_classID = NULLTAG;

        char *error_text = NULL;
        error_text = (char *)MEM_alloc(100);

        status = POM_class_of_instance(object_t, &object_classID);
      
        
        if ( status == ITK_ok )
        status = POM_name_of_class(object_classID,&classid_s);
     
                                      
        if ( status == ITK_ok )
        status = POM_attr_id_of_attr("release_status_list",
                                    classid_s,
                                    &object_relID);
      
        if ( status == ITK_ok )
        status = POM_attr_id_of_attr("date_released",
                                    classid_s,
                                    &object_reldateID);
     
        if ( status == ITK_ok )
        status = POM_is_loaded(object_t, &verdict);
      

        if (verdict == TRUE)
        {
        status=POM_unload_instances(1, &object_t);
          
        }
        if ( status == ITK_ok )
        status=POM_load_instances_any_class(1, &object_t, POM_modify_lock);

     
        if ( status == ITK_ok )
        status=POM_length_of_attr(object_t, object_relID, &relattlen);
      // setting the release status
        if ( status == ITK_ok )
        status=POM_set_attr_tags(1, &object_t, object_relID, 0, 1, &status_t);

        // setting the release date
        if ( status == ITK_ok )
        status=POM_set_attr_date(1,&object_t,object_reldateID,release_time);
      

        if ( status == ITK_ok )
        status=POM_save_instances(1, &object_t, FALSE);
      
        if ( status == ITK_ok )
        status=POM_refresh_instances_any_class(1, &object_t, POM_no_lock) ;
      
        if(status != ITK_ok)
        {
            print_err_msg(status);
           status = ITK_ok;
             
        }
        if ( error_text )   MEM_free (error_text);
       
        return status;
}

//******************************************************************************************************************
/* This function will get the input args for the handler*/
static int getArgs(EPM_action_message_t msg, char*** arg_forms, int *num_formType)

{
  
        int     indx = 0; 
        int     retcode = ITK_ok;
        int     num_args = 0;
        int     num_TformType = 0;

        char*   buffer = NULL;
        char*   arg_string  = NULL;
        char*   str = NULL;
        char**  allwd_forms = NULL;
        char    szErrorString[TIAUTO_error_message_len+1]="";
 

           num_args = TC_number_of_arguments(msg.arguments);
           for (indx = 0; (indx < num_args) && (retcode == ITK_ok) ; indx++ )
           {
               arg_string = TC_next_argument( msg.arguments );

               // getting the arguments from the handler..get the type of forms and storing in an array
                //  for further filtering of the forms in change form folders
               if ( retcode == ITK_ok )
               {
                   str = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(arg_string)+1));
                   tc_strcpy(str,"");
                   if (tc_strncasecmp(arg_string, TIAUTO_ALLOWED_FORMS, tc_strlen(TIAUTO_ALLOWED_FORMS)) == 0)
                   {
                       tc_strcpy(str,(const char*)&arg_string[tc_strlen(TIAUTO_ALLOWED_FORMS)+1]);
                       if ( str != NULL )
                       {
                           buffer = NULL;
                           buffer = tc_strtok( str , ",");
                           while ( buffer !=NULL)
                           {
                               if (allwd_forms == NULL)
                               {
                                   allwd_forms = ( char ** ) MEM_alloc ( sizeof (char *) );
                               }
                               else
                               {
                                   allwd_forms = (char**) MEM_realloc ( allwd_forms, ((num_TformType)+1) * sizeof(char*));
                               }
                               allwd_forms[num_TformType] = (char*) MEM_alloc(( sizeof (char)*ITEM_type_size_c) + 1);
                               tc_strcpy(allwd_forms[num_TformType],buffer);
                               num_TformType++;
                               buffer = tc_strtok( NULL , "," );
                           }
                       }
                   }
                   else
                   {   
                       TI_sprintf(szErrorString, "The argument to the handler is invalid "); 
                       TC_write_syslog(szErrorString);
                       retcode = EPM_invalid_argument;
                       EMH_store_error( EMH_severity_error, retcode );
                   }

                   if ( str ) MEM_free (str);
               } // if retcode - for arg_string
           
           } //for loop for num_args

           *arg_forms = allwd_forms;
           *num_formType = num_TformType;
           
        if (retcode)  print_err_msg(retcode);

        if(retcode != ITK_ok)
        {   
            print_err_msg(retcode);
            retcode = ITK_ok;
            printf("error in the function get Args");
        }
   
return  retcode;
}
//********************************************************************************************************************
/* This function will get the required forms for taking the copy */
static int getForms(char    **arg_forms,    int     num_formType, 
                    tag_t   *Attach_forms,  int     num_attach,
                    tag_t   **change_forms, int     *num_forms)

{
    
    int  j=0;
    int  i=0;
    int  iRetCode = ITK_ok;
    int  num_valid = 0;

    tag_t   newclassid = NULLTAG;
    tag_t   tType = NULLTAG;
    tag_t  *superclass = NULL;

    char    type_name[TCTYPE_name_size_c+1];
    char * Class = NULL;
    char *class_names = NULL;
    char *error_text = NULL;
    
   
    int* n_id = NULL;
     n_id = (int*) MEM_alloc (sizeof(int) * (1 + 1));
     error_text = (char *)MEM_alloc(100);
    
     *change_forms = NULL;
     
    //Each form from the change forms folders is compared with argument value of the handler for filtering
    for(i=0;i<num_attach;i++)
    {
         iRetCode =  TCTYPE_ask_object_type(Attach_forms[i],&tType);

         if(iRetCode == ITK_ok)
         iRetCode = TCTYPE_ask_name(tType,type_name);

         if(iRetCode == ITK_ok)
         iRetCode = FORMTYPE_ask_def_class_name(tType,&Class);

         if(iRetCode == ITK_ok)
          iRetCode = POM_class_id_of_class(Class,&newclassid);

          if(iRetCode == ITK_ok)
          iRetCode = POM_superclasses_of_class(newclassid, n_id,&superclass);

         if(iRetCode == ITK_ok)
          iRetCode = POM_name_of_class(superclass[0],&class_names);

           //Comparing the forms to get the forms of type as mentioned by the handler args
             //  and storing in an array for further processing by create copy function

           for(j=0; j<num_formType; j++)
           {
                if((tc_strcasecmp( type_name ,arg_forms[j])== 0) ||(tc_strcasecmp(class_names,arg_forms[j])== 0))
                {
                    if (*change_forms == NULL)
                    {
                        
                        *change_forms = ( tag_t* ) MEM_alloc ( sizeof (tag_t) );
                    }
                    else
                    {
                       
                         *change_forms = (tag_t*) MEM_realloc ( *change_forms, (num_valid+1) * sizeof(tag_t));
                    }
              
                   (*change_forms)[num_valid] = Attach_forms[i];
                             
                    num_valid++;
                    break;
                }
                


            }
    }
       
    *num_forms = num_valid;
  
   if ( superclass ) MEM_free (superclass);
   if ( Class ) MEM_free (Class);
   
    if(iRetCode != ITK_ok)
    {    
         print_err_msg(iRetCode);
        iRetCode = ITK_ok;

    }
    if ( error_text ) MEM_free (error_text);
   

return  iRetCode;

}
//************************************************************************************************************************

