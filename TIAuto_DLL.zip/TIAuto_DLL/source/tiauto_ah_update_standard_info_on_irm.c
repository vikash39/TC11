/************************************************************************************************************
File         : tiauto_ah_update_standard_info_on_irm.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
13 Jun, 2016    1.0        Dipak			 Initial Creation
25 Jan 2017		1.1		   Shilpa			ER#9144 - Documents Revisions has been converted to primary
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

//-----------------------------------------------------------------------------------------------------------------
//! Process_and_set_value()
//! \param  tag_t	tItemRev					/*<I>*/ 
//!			char	*pcChangeRevID				/*<I>*/
//!			int		iCntCustAuthNo				/*<I>*/
//!			char	**pcCustAuthNo				/*<I>*/
//!			int		iNoofCustName				/*<I>*/
//!			char	**pcCustomerName			/*<I>*/
//! \return int
//! \note	Sets the "released by change", "customer release no" and "custome name" attribute value of the IRM form
//!			of the item revision.
//!		  Returns retcode.
//-----------------------------------------------------------------------------------------------------------------
int Process_and_set__standard_info_value(tag_t tItemRev,int iNoOfTIDivision,char **pcTIDivision,int iNoOfProductGroup,char **pcProductGroup,
										 int iNoOfEngCenter,char **pcEngCenter,int iNoOfStandardRegion,char **pcStandardRegion)
{
	int             iRetCode						= ITK_ok;
	int				iObjCount						= 0;
	char			acObjectType[WSO_name_size_c+1]	= "";
	tag_t			*ptItemRevMasterForm			= NULL;
	logical			lIsModifiable					= false;	

	iRetCode = WSOM_ask_object_type(tItemRev, acObjectType);
	if (iRetCode == ITK_ok)
	{
		//get the item revision master form
		iRetCode = tiauto_get_related_objects( "IMAN_master_form",tItemRev,&iObjCount,&ptItemRevMasterForm);
	}
	if (iRetCode == ITK_ok && ptItemRevMasterForm != NULL)
	{
		lIsModifiable = false;
		iRetCode = AOM_ask_if_modifiable (ptItemRevMasterForm[0],&lIsModifiable);
	}
	if (iRetCode == ITK_ok && lIsModifiable == true)
	{
		iRetCode = AOM_refresh(ptItemRevMasterForm[0], true);
		
		//set the TI Division				
		iRetCode = AOM_set_value_strings (ptItemRevMasterForm[0],"t8_tidivision",iNoOfTIDivision,pcTIDivision);
		//set the product Group
		iRetCode = AOM_set_value_strings (ptItemRevMasterForm[0],"t8_productgroup",iNoOfProductGroup,pcProductGroup);
		//set the Standard Region
		iRetCode = AOM_set_value_strings(ptItemRevMasterForm[0],"t8_standardsregion",iNoOfStandardRegion,pcStandardRegion);
		//set the Engineering Center
		iRetCode = AOM_set_value_strings(ptItemRevMasterForm[0],"t8_tiengcenter",iNoOfEngCenter,pcEngCenter);

		if(iRetCode == ITK_ok)
				iRetCode = AOM_save(ptItemRevMasterForm[0]);
		if(iRetCode == ITK_ok)
			iRetCode = AOM_refresh(ptItemRevMasterForm[0],false);
	}
	SAFE_MEM_free(ptItemRevMasterForm);
	return iRetCode;
}
extern int TIAUTO_AH_update_standard_info_on_irm(EPM_action_message_t msg)
{
	int		iRetCode						= ITK_ok;
	
	int				iNumArgs						= 0;
	int				indx										= 0;
	int				iNumAttachments								= 0;
	
	
	int				iNoOfTIDivision = 0;
	int				iNoOfProductGroup = 0;
	int				iNoOfEngCenter = 0;
	int				iNoOfStandardRegion = 0;

	char	*pcChangeRevStr					= NULL;
	char	*pcTargetTypeName				= NULL;
	char*	pcArgName						= NULL;
	char	*pcArgValue						= NULL;
	char	**pcTIDivision = NULL;
	char	**pcProductGroup = NULL;
	char	**pcEngCenter = NULL;
	char	**pcStandardRegion = NULL;
	char	caObjectType[WSO_name_size_c+1]	= "";
	char	caTargetClass[TCTYPE_class_name_size_c+1] = "";	

	tag_t	tChangeRev						= NULLTAG;
	
	tag_t	tRootTask									= NULLTAG;
	tag_t	tTargetType									= NULLTAG;
	tag_t   tCCRForm									= NULLTAG;
	tag_t	*ptAttachments								= NULL;
	tag_t	*ptChangeFolderSecObjs			= NULL;

	/* get the arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);

	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,"T8_TI_ChangeRevision");

	/* validate the handler arguments */
    if ( iNumArgs == 1)
	{
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if ( iRetCode == ITK_ok ) 
			{
				if( iRetCode == ITK_ok && tc_strcmp(pcArgName, "target_type" ) == 0)
				{
					tc_strcpy( pcTargetTypeName, pcArgValue);
				}
				/* if the argument mentioned is not "lov" */
				else
					iRetCode = EPM_invalid_argument;
			}
		}
	}

	iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		//get the change rev string
		iRetCode = tiauto_get_itemrev_name(tChangeRev,&pcChangeRevStr);
		
		iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
		//get the contents od the change forms folder under change revision
		if (iRetCode == ITK_ok && tRootTask != NULLTAG)
			{
				//get all target attachments
				iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
													&iNumAttachments, &ptAttachments);
			}
			if(iRetCode == ITK_ok && iNumAttachments > 0)
			{
				//from the targets get the Changerev-id
				//iRetCode = tiauto_get_itemrev_name(tChangeRev,&pcChangeRevID);
				//check the PMR for existance as the PMR process can be initiated on the
				//CR, CRB and DAP approved process. DAP, CR and CRB are also having the TI_CCR form.
				//So if both CCR and PMR for present, the PMR form will be considered.
				if (iRetCode == ITK_ok)
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_StandardForm",&tCCRForm);
				if (iRetCode == ITK_ok && tCCRForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_strings (tCCRForm,"t8_189tidivision",&iNoOfTIDivision,&pcTIDivision);
					iRetCode = AOM_ask_value_strings (tCCRForm,"t8_189productgroup",&iNoOfProductGroup,&pcProductGroup);
					iRetCode = AOM_ask_value_strings (tCCRForm,"t8_189engineeringcenter",&iNoOfEngCenter,&pcEngCenter);
					iRetCode = AOM_ask_value_strings (tCCRForm,"t8_189standardregion",&iNoOfStandardRegion,&pcStandardRegion);
				}
			}
			for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
            {
				char	*pcTargetClass			= NULL;
				if(iRetCode == ITK_ok)
				{
					iRetCode = TCTYPE_ask_object_type(ptAttachments[indx],&tTargetType);
				}
				if(iRetCode == ITK_ok && tTargetType != NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tTargetType, &pcTargetClass));
					
					if ((tc_strcmp (pcTargetClass, TIAUTO_ITEMREVISION) != 0) || (tc_strcmp (pcTargetClass, TIAUTO_FORM) != 0))
					{
						tag_t	tParentType									= NULLTAG;

						TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
						if(tParentType != NULLTAG)
						{
							SAFE_MEM_free(pcTargetClass);
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType,&pcTargetClass));
						}
						
					}
				}               			
				// check if the classname of the targeted object pseudo folder is ItemRevision or Document Revision
				if (iRetCode == ITK_ok && ((tc_strcmp (pcTargetClass,TIAUTO_ITEMREVISION) == 0) || (tc_strcmp (pcTargetClass, TIAUTO_TI_DOCUMENTREVISION) == 0)))				
				{
					iRetCode = WSOM_ask_object_type(ptAttachments[indx], caObjectType);
					if (iRetCode == ITK_ok && ( (tc_strcmp (caObjectType, CHANGE_REV) == 0 ) || (tc_strcmp (caObjectType, NEWCHANGE_REV) == 0 ) ))
		            {					
						continue;
					}
					else if(iRetCode == ITK_ok)
					{
						//process the item revision					
						iRetCode = Process_and_set__standard_info_value( ptAttachments[indx],iNoOfTIDivision,pcTIDivision,iNoOfProductGroup,pcProductGroup,
														iNoOfEngCenter,pcEngCenter,
														  iNoOfStandardRegion,pcStandardRegion);
					}
				}
				SAFE_MEM_free(pcTargetClass);
			}
	
		SAFE_MEM_free(ptChangeFolderSecObjs);
		SAFE_MEM_free(pcChangeRevStr);
		return iRetCode;
	}
		
}