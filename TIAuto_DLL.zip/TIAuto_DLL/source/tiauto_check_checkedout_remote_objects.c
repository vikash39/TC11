/**********************************************************************************************************
File         : tiauto_check_checkedout_remote_objects.c

Description  : This rule handler looks for checked out and remote item revisions and 
				other Teamcenter objects such as Datasets, Forms etc� that are related 
				the items revisions with specification relationship in the �Affected Items� 
				and the �Solution Items� folder of the target change object. If there are 
				checked out and/or remote objects then this rule handler will provide 
				appropriate error message to the user.  If there are more than one 
				checked out object and/or remote objects, then the identity of all 
				such objects will be mentioned in the single error message.
  
Input        : None
                        
Output       : None

Author       : Rajesh Natesan,TCS

Revision History :
Date            Revision    Who					Description
Jan 02, 2008    1.0         Rajesh Natesan      Initial Creation
Jul 14, 2010	1.1			Dipak Naik			Modified the code to print the checked-out user name and
												the date on which the object is checked out
Aug 20, 2010	1.2			Dipak Naik			Modified the code to validate the objects present in the
												pseudo folder of the targeted change revision based on the
												relation name mentioned in the handler argument
Feb 11, 2011	1.3			Rajesh N			Modified the code for ER6299
Aug 10, 2011	1.4			Dipak Naik			Added the code to validate the change forms attached to the
												targeted change revision with IMAN_specification
Jun 21, 2012    1.5			Dipak Naik			Added the enhancement as per the ER#6731
Feb 24, 2017	1.6			Shilpa				Modified code for ER#9169
Mar 22, 2017	1.6			Shilpa				Modified code for ER#9169
Jun	30, 2017    1.7         Ramesh				Modified code for ER#9368
*****************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <stdio.h>
#include <res/res_itk.h>
#include <tiauto_defines.h>

int Validate_Targeted_Objects(int iNumAffected,tag_t *ptAffectedObjects,char *pcFolderName,
							  logical *lValidationFailed,TIA_ErrorMessage **pstCurrErrMsg);
int Is_Object_Checked_out(tag_t tObject,logical *lIsCheckedOut,char **pcCheckedOutUserName,char **pcCheckedOutDate);
int Is_BVR_Checked_Out( tag_t tItemRev,logical *lIsCheckedOut,char **pcCheckedOutUserName,
					    char **pcCheckedOutDate,char **pcBVRName);
int Validate_Change_Forms(tag_t	tTask,tag_t	tEngChangeRev,char	*pcCurrTaskName,int iChangeFormCount,tag_t *ptChangeForms,
							  logical *lChangeFormValFailed,TIA_ErrorMessage **pstCurrErrMsg);
//---------------------------------------------------------------------------------------------------
//Main method for the rule handler "TIAUTO-check-checkedout-remote-objects"
//---------------------------------------------------------------------------------------------------
EPM_decision_t t1aAUTO_check_checkedout_remote_objects(EPM_rule_message_t message)
{
    int		iFail					= ITK_ok;
	int		iNumAffected			= 0;
	int		iAttchCntr				= 0;
	int		iNumArgs				= 0;
	int		iRelNameCount			= 0;
	int		iChangeFormCount		= 0;
	int		i						= 0;

	tag_t	tRelation				= NULLTAG;	
	tag_t	tEngChangeRev			= NULLTAG;	
	tag_t	*ptAffectedObjects		= NULL;
	tag_t	*ptChangeForms			= NULL;
    tag_t	tUser					= NULLTAG;
	tag_t	tGroup					= NULLTAG;
    tag_t	tTaskType				= NULLTAG;
	tag_t	tDescriptor = NULLTAG;

	char	*pcUserName				= NULL;
	char	*pcGroupName			= NULL;
	char	*pcTargetObjectType		= NULL;
	char	*pcTaskTypeName			= NULL;
	char	acErrorString[512]		= "";	
	char	*pcValue				= NULL;
    char	*pcFlag					= NULL;
	char	*pcRelation				= NULL;
	char	*pcPseudoFolderName		= NULL;
	char	*pcErrMsg				= NULL;
	char	*pcTemp					= NULL;
	char	**pcRelationNames		= NULL;
	char    pszObjType[WSO_name_size_c+1]="";
	
	logical	lValidationFailed		= false;
	logical	lChangeFormValFailed	= false;

	TIA_ErrorMessage *pstCurrErrMsg = NULL;
	TIA_ErrorMessage *tempErrMsg	= NULL;

	EPM_decision_t decision = EPM_go;

	if(message.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user    	
	iFail = POM_get_user (&pcUserName, &tUser);

	if(iFail == ITK_ok)
	{
		iFail = SA_ask_user_login_group(tUser,&tGroup);
		iFail = SA_ask_group_name2	(tGroup,&pcGroupName);

		if(tc_strcmp(pcGroupName,"dba") == 0)
		{
			decision = EPM_go;
			return decision;
		}
	}
	
	if(iFail == ITK_ok && (message.task != NULLTAG) )
	{
		iFail = TCTYPE_ask_object_type(message.task,&tTaskType);
	}
	if(iFail == ITK_ok && tTaskType != NULLTAG)
	{
		iFail = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}	
	
	iNumArgs = TC_number_of_arguments(message.arguments);
  
    if (iNumArgs == 1 || iNumArgs == 2)
	{
		for( i = 0;i < iNumArgs;i++)
		{
			iFail = ITK_ask_argument_named_value(TC_next_argument(message.arguments), &pcFlag, &pcValue );
			if ( iFail == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag, ARG_NAME_REMOTE_AND_CHECK_CHECKEDOUT_HANDLER) == 0 && pcValue != NULL)
				{
					pcRelation = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcRelation, pcValue);
				}
				else if( tc_strcasecmp(pcFlag, "target_type") == 0 && pcValue != NULL)
				{
					pcTargetObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTargetObjectType, pcValue);
				}
				else
				{
					iFail = EPM_invalid_argument;
				}
			}
		}
	}
	else if(iNumArgs > 1)
	{
		iFail = EPM_invalid_argument;
	}
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcValue);
	//get the targeted change revision
	if (iFail == ITK_ok )
		iFail = tiauto_get_change_item_rev (message.task, &tEngChangeRev);
	
	if (iFail == ITK_ok && tEngChangeRev != NULLTAG)
	{
		if(pcRelation == NULL)
		{
			//if no argument value parsed to the handler, then copy the default value 
			//i.e get the content from the Affected and solution item folder
			pcRelation = (char *)MEM_alloc(100);
			iFail = WSOM_ask_object_type(tEngChangeRev, pszObjType);
			if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
			{
				tc_strcpy(pcRelation,"CMHasImpactedItem,CMHasSolutionItem,T8_CMTIDrawingItems");

			}
			//tc_strcpy(pcRelation,"EC_affected_item_rel,EC_solution_item_rel");
			else
				tc_strcpy(pcRelation,"affected_items,solution_items");
		}
					
		if(pcRelation != NULL)
		{				
			tc_strcpy(pszObjType,pcTargetObjectType);

			pcRelationNames = (char **)malloc(10* sizeof(char *));			
			pcTemp = tc_strtok (pcRelation,",");
			//to remove the forward and trailing space
			//remove_forward_AND_trailing_space(pcTemp);
			while(pcTemp != NULL && iFail == ITK_ok)
			{
				//to remove the forward and trailing space
				//remove_forward_AND_trailing_space(pcTemp);
				//validate the input argument value				
				iFail = AOM_ask_descriptor (tEngChangeRev,pcTemp,&tRelation);
				if(iFail == ITK_ok && tRelation != NULLTAG)
				{
					pcRelationNames[iRelNameCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcRelationNames[iRelNameCount],pcTemp);			
					iRelNameCount++;					
					pcTemp = tc_strtok(NULL,",");
				}
				else
				{
					iFail = EPM_invalid_argument_value;
					TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"%s\".",ARG_NAME_REMOTE_AND_CHECK_CHECKEDOUT_HANDLER);
					EMH_store_error_s1( EMH_severity_error, iFail, acErrorString) ;						
					TC_write_syslog(acErrorString);
					decision = EPM_nogo;
					break;
				}
			}
		}	
		//Validate the change forms that are attached to the change revision with IMAN_specification
		//checked-out or not
		if (iFail == ITK_ok && tEngChangeRev != NULLTAG)
		{
			lChangeFormValFailed = false;
			tRelation = NULLTAG;

			iFail = GRM_find_relation_type ("IMAN_specification",&tRelation);
			//get the change forms
			if (iFail == ITK_ok && tRelation != NULLTAG)
				iFail = GRM_list_secondary_objects_only(tEngChangeRev,tRelation,&iChangeFormCount,&ptChangeForms);
			if(iFail == ITK_ok && iChangeFormCount > 0)
			{
				char		*pcCurrTaskName			= NULL;
				tag_t		tTask					= NULLTAG;
				tTask=message.task;
				iFail = EPM_ask_name2(message.task,&pcCurrTaskName);

				iFail = Validate_Change_Forms(tTask,tEngChangeRev,pcCurrTaskName,iChangeFormCount,ptChangeForms,&lChangeFormValFailed,&pstCurrErrMsg);
			}
			tRelation = NULLTAG;
			SAFE_MEM_free(ptChangeForms);
		}
		//get all the objects present in the pseudo folder of the targeted change revision based on relation	
		for(iAttchCntr = 0; (iAttchCntr < iRelNameCount) && (iFail == ITK_ok); iAttchCntr++)
		{
			tRelation = NULLTAG;
			iNumAffected = 0;
			tDescriptor = NULLTAG;
			
			if(iFail == ITK_ok)
			{
				iFail = AOM_ask_descriptor (tEngChangeRev,pcRelationNames[iAttchCntr],&tDescriptor);
				if(tDescriptor != NULLTAG)
					iFail = PROPDESC_ask_display_name  (tDescriptor,&pcPseudoFolderName);
			}
			if( iFail == ITK_ok) 
			{
				
				if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
				{
					tag_t tRelTemp = NULLTAG;
					iFail = GRM_find_relation_type (pcRelationNames[iAttchCntr],&tRelTemp);
					if(iFail == ITK_ok && tRelTemp!=NULLTAG)
					{
						iFail = GRM_list_secondary_objects_only(tEngChangeRev,tRelTemp,&iNumAffected,&ptAffectedObjects);
					}
				}
				else				
					iFail = ECM_get_contents  (tEngChangeRev,pcRelationNames[iAttchCntr],&iNumAffected, &ptAffectedObjects);
			}
			if(iFail == ITK_ok && iNumAffected > 0)
			{
				iFail = Validate_Targeted_Objects(iNumAffected,ptAffectedObjects,pcPseudoFolderName,&lValidationFailed,&pstCurrErrMsg);
			}
			SAFE_MEM_free(ptAffectedObjects);
			SAFE_MEM_free(pcPseudoFolderName);
		}					
		
	}
	
	if(pcRelation != NULL)
	{
		SAFE_MEM_free(pcRelation);
	}
	if(pcRelationNames != NULL)
	{
		free(pcRelationNames);
		pcRelation = NULL;
	}
	
	if( iFail != ITK_ok && iFail != EPM_invalid_argument_value)
	{
		decision = EPM_nogo;
		EMH_ask_error_text(iFail, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iFail,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}

	/* if the validation failed */
	if( iFail == ITK_ok && ((lValidationFailed == true) || (lChangeFormValFailed == true)) )
	{
		decision = EPM_nogo;			
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iFail = EPM_set_decision (message.task,tUser,CR_no_decision,"",false);
		}
		iFail = TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR;
		TI_sprintf( acErrorString, "\nIf the object is checked out, please check-in the object before completing the task. \nIf the object is a remote object, please fix it before completing the task. "  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString );
		
		tempErrMsg = pstCurrErrMsg;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
		tiauto_clearErrorMsgStack(pstCurrErrMsg);
	}
	
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);

	return decision;
}

//-----------------------------------------------------------------------------------------------------
// This method checks whether any objects present in the pseudo folder including their secondary objects
// are checked out and remote object. If either any object or their secondary object is checked out/
// remote object, then error message will be displayed
//-----------------------------------------------------------------------------------------------------
int Validate_Targeted_Objects( int		iNumAffected,				/*<I>*/
							   tag_t	*ptAffectedObjects,			/*<I>*/
							   char		*pcFolderName,				/*<I>*/
							   logical	*lValidationFailed,			/*<O>*/
							   TIA_ErrorMessage **pstCurrErrMsg)	/*<O>*/
{
	int		iFail						= ITK_ok;
	int		iAffCntr					= 0;
	int		iRevCount					= 0;
	int		iRevIndx					= 0;
	int		iSecCntr					= 0;
	int		ObjFound					= 0;

	tag_t	tOwningSite					= NULLTAG;
	tag_t	tItem						= NULLTAG;
	tag_t	*ptRevList					= NULL;
	GRM_relation_t *ptSecondaryList		= NULL;
	char  RelationType[TCTYPE_name_size_c+1]; 

	char	*pcClassName				= NULL;
	char	*pcCheckedOutUserName		= NULL;
	char	*pcCheckedOutDate			= NULL;
	char	*pcObjName					= NULL;	
	char	*pcSecObjClassName			= NULL;
	char	acItemId[ITEM_id_size_c+1]	= "";
	char	acRevId[ITEM_id_size_c+1]	= "";
	char	acErrorString[512]			= "";
	
	logical lCheckedOut					= false;
		
	//*lValidationFailed = false;
	for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iFail == ITK_ok) ; iAffCntr++)
	{
		tag_t	tTargetType					= NULLTAG;

		lCheckedOut = false;
		tOwningSite = NULLTAG;
		pcCheckedOutUserName = NULL;
		pcCheckedOutDate = NULL;
		//get the classname of the object
		if (iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG )
		{
			TIAUTO_ITKCALL(iFail,TCTYPE_ask_object_type(ptAffectedObjects[iAffCntr],&tTargetType));
		}
		
		if(tTargetType != NULLTAG)
		{
			//getting parent class if the class name is NOT ITEM or ITEMREVISION			
			TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tTargetType, &pcClassName));
		}
		if ((tc_strcmp (pcClassName,TIAUTO_ITEM) != 0) || (tc_strcmp (pcClassName,TIAUTO_ITEMREVISION) != 0))
		{
			tag_t	tParentType					= NULLTAG;

			TIAUTO_ITKCALL(iFail,TCTYPE_ask_parent_type(tTargetType,&tParentType));
			if(tParentType != NULLTAG)
			{
				SAFE_MEM_free(pcClassName);
				TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tParentType, &pcClassName));
			}
						
		}
		
		//check if the classname of the targeted object pseudo folder is Item or Document
		if((iFail == ITK_ok)  && ((tc_strcasecmp (pcClassName , TIAUTO_ITEM)== 0) || (tc_strcasecmp (pcClassName , TIAUTO_TI_DOCUMENT)== 0)))
		{
			tc_strcpy(acItemId,"");
			// get item id string 
			if(iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG)
				iFail = ITEM_ask_id(ptAffectedObjects[iAffCntr], acItemId);			
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Object_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			//if object is checked out, store the error message in the error stack
			if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The item \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",acItemId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}
			// check if the item is remote
			if( iFail == ITK_ok)
				iFail = AOM_ask_value_tag( ptAffectedObjects[iAffCntr], "owning_site", &tOwningSite);
			//if object is remote, store the error message in the error stack
			if(iFail == ITK_ok && tOwningSite != NULLTAG)
			{
				TI_sprintf(acErrorString, "The item \"%s\" present in the \"%s\" folder is a remote object.",acItemId, pcFolderName); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
			}
			//if item is not a remote object, check all the revisions
			else if(iFail == ITK_ok && tOwningSite == NULLTAG)
			{
				iRevCount = 0;
				//check all the revs of the item
				iFail = ITEM_list_all_revs (ptAffectedObjects[iAffCntr],&iRevCount,&ptRevList);
				for(iRevIndx =0; iRevIndx < iRevCount && (iFail == ITK_ok);iRevIndx++)
				{
					tc_strcpy(acRevId,"");
					lCheckedOut = false;
					tOwningSite = NULLTAG;
					pcObjName = NULL;
					// get item rev id string 
					if( iFail == ITK_ok)
						iFail = ITEM_ask_rev_id(ptRevList[iRevIndx],acRevId );
					// check if item is checked out
					if(iFail == ITK_ok)
						iFail = Is_Object_Checked_out(ptRevList[iRevIndx],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
					if( iFail == ITK_ok && lCheckedOut == true )
					{
						TI_sprintf(acErrorString, "The item revision \"%s/%s\" of item \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",acItemId,acRevId,acItemId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
						*lValidationFailed = true;
						lCheckedOut = false;
						free(pcCheckedOutUserName);
						pcCheckedOutUserName = NULL;
						SAFE_MEM_free(pcCheckedOutDate);
					}	
					// check if the item revision is remote
					if( iFail == ITK_ok)
						iFail = AOM_ask_value_tag( ptRevList[iRevIndx], "owning_site", &tOwningSite);
					//if item revision is a remote object, store the error message in the error stack
					if(iFail == ITK_ok && tOwningSite != NULLTAG)
					{
						TI_sprintf(acErrorString, "The item revision \"%s/%s\" of item \"%s\" present in the \"%s\" folder is a remote object.",acItemId,acRevId,acItemId, pcFolderName); 
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
						*lValidationFailed = true;
					}
					//if item revision is not a remote object, check all the secondary objects
					else if(iFail == ITK_ok && tOwningSite == NULLTAG)
					{
						//check the BVR
						iFail = Is_BVR_Checked_Out(ptRevList[iRevIndx],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate,&pcObjName);
						if( iFail == ITK_ok && lCheckedOut == true )
						{
							TI_sprintf(acErrorString, "The BVR \"%s\" attached to the item revision \"%s/%s\" of item \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",pcObjName,acItemId,acRevId,acItemId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
							tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
							*lValidationFailed = true;
							lCheckedOut = false;
							free(pcCheckedOutUserName);
							pcCheckedOutUserName = NULL;
							SAFE_MEM_free(pcCheckedOutDate);
							SAFE_MEM_free(pcObjName);
						} 

						//check the secondary objects
						iFail =GRM_list_secondary_objects( ptRevList[iRevIndx], NULLTAG,
							                               &ObjFound,&ptSecondaryList);
						for( iSecCntr = 0; (iFail == ITK_ok) && (iSecCntr < ObjFound) ; iSecCntr++ )
						{
							lCheckedOut = false;
							tOwningSite = NULLTAG;
							pcObjName = NULL;
							pcSecObjClassName = NULL;
							pcCheckedOutUserName = NULL;
							pcCheckedOutDate = NULL;

							//check whether secondary object is in the related revision folder IMAN_based_on or IMAN_UG_wave_geometry
					        iFail=TCTYPE_ask_name( ptSecondaryList[iSecCntr].relation_type,RelationType);
					        if ((iFail == ITK_ok)&& ((tc_strcmp(RelationType,"TI_DocProdRevisions")==0) ||
													 (tc_strcmp(RelationType,"IMAN_based_on")==0) || (tc_strcmp(RelationType,"IMAN_UG_wave_geometry")==0) ) )
							{
								continue;
							}
							//get the secondary object name
							iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName);
							// get the class name of the secondary object
							if( iFail == ITK_ok)
								iFail = tiauto_get_class_name_of_instance (ptSecondaryList[iSecCntr].secondary, &pcSecObjClassName);
							// check if secondary object is checked out
							if( iFail == ITK_ok && ptSecondaryList[iSecCntr].secondary != NULLTAG )
								iFail = Is_Object_Checked_out( ptSecondaryList[iSecCntr].secondary, &lCheckedOut,&pcCheckedOutUserName ,&pcCheckedOutDate);
							if( iFail == ITK_ok && lCheckedOut == true )
							{
								TI_sprintf(acErrorString, "The %s \"%s\" attached to the item revision \"%s/%s\" of item \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",
														pcSecObjClassName,pcObjName, acItemId, acRevId,acItemId,pcFolderName,pcCheckedOutUserName ,pcCheckedOutDate); 
								tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
								*lValidationFailed = true;
								free (pcCheckedOutUserName);
								pcCheckedOutUserName = NULL;
								SAFE_MEM_free(pcCheckedOutDate);
							}
							// check if the secondary object is remote
							if( iFail == ITK_ok)
								iFail = AOM_ask_value_tag( ptSecondaryList[iSecCntr].secondary, "owning_site", &tOwningSite);
							if(iFail == ITK_ok && tOwningSite != NULLTAG)
							{
								TI_sprintf(acErrorString, "The %s \"%s\" attached to the item revision \"%s/%s\" of item \"%s\" present in the \"%s\" folder is a remote object.",
														pcSecObjClassName,pcObjName, acItemId, acRevId,acItemId,pcFolderName); 
								tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
								*lValidationFailed = true;
							}
							SAFE_MEM_free(pcObjName);
							SAFE_MEM_free(pcSecObjClassName);
						}						
						SAFE_MEM_free(ptSecondaryList);
					}
				}
				SAFE_MEM_free(ptRevList);	
			}
		}
		// check if the classname of the targeted object pseudo folder is ItemRevision or Document Revision
		else if((iFail == ITK_ok)  &&( (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))		
		{	
			// get item tag
			iFail = ITEM_ask_item_of_rev(ptAffectedObjects[iAffCntr], &tItem);
			// get item id string 
			if(iFail == ITK_ok && tItem != NULLTAG)
				iFail = ITEM_ask_id(tItem, acItemId);
			// get item rev id string 
			if( iFail == ITK_ok)
				iFail = ITEM_ask_rev_id(ptAffectedObjects[iAffCntr],acRevId );
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Object_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The item revision \"%s/%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",acItemId,acRevId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
				lCheckedOut = false;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}	
			// check if the item revision is remote
			if( iFail == ITK_ok)
				iFail = AOM_ask_value_tag( ptAffectedObjects[iAffCntr], "owning_site", &tOwningSite);
			if(iFail == ITK_ok && tOwningSite != NULLTAG)
			{
				TI_sprintf(acErrorString, "The item revision \"%s/%s\" present in the \"%s\" folder is a remote object.",acItemId,acRevId, pcFolderName); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
			}
			else if(iFail == ITK_ok && tOwningSite == NULLTAG)
			{

				//check the BVR
				iFail = Is_BVR_Checked_Out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate,&pcObjName);
				if( iFail == ITK_ok && lCheckedOut == true )
				{
					TI_sprintf(acErrorString, "The BVR \"%s\" attached to the item revision \"%s/%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",pcObjName,acItemId,acRevId,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
					*lValidationFailed = true;
					lCheckedOut = false;
					free(pcCheckedOutUserName);
					pcCheckedOutUserName = NULL;
					SAFE_MEM_free(pcCheckedOutDate);
					SAFE_MEM_free(pcObjName);
				}
				//check the secondary objects
				iFail =GRM_list_secondary_objects( ptAffectedObjects[iAffCntr], NULLTAG,
							                               &ObjFound,&ptSecondaryList);
				for( iSecCntr = 0; (iFail == ITK_ok) && (iSecCntr < ObjFound) ; iSecCntr++ )
				{
					lCheckedOut = false;
					tOwningSite = NULLTAG;
					pcObjName = NULL;
					pcSecObjClassName = NULL;
					pcCheckedOutUserName = NULL;
					pcCheckedOutDate = NULL;

					//check whether secondary object is in the related revision folder
					iFail=TCTYPE_ask_name( ptSecondaryList[iSecCntr].relation_type,RelationType);
					if ((iFail == ITK_ok)&&((tc_strcmp(RelationType,"TI_DocProdRevisions")==0) ||
										    (tc_strcmp(RelationType,"IMAN_based_on")==0) || (tc_strcmp(RelationType,"IMAN_UG_wave_geometry")==0) ) )
					{
						continue;
					}
					//get the secondary object name
					iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName);
					// get the class name of the secondary object
					if( iFail == ITK_ok)
						iFail = tiauto_get_class_name_of_instance (ptSecondaryList[iSecCntr].secondary, &pcSecObjClassName);					
					// check if secondary object is checked out
					if( iFail == ITK_ok && ptSecondaryList[iSecCntr].secondary != NULLTAG )
						iFail = Is_Object_Checked_out( ptSecondaryList[iSecCntr].secondary, &lCheckedOut,&pcCheckedOutUserName ,&pcCheckedOutDate);
					if( iFail == ITK_ok && lCheckedOut == true )
					{
						TI_sprintf(acErrorString, "The %s \"%s\" attached to the item revision \"%s/%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",
												pcSecObjClassName,pcObjName, acItemId, acRevId,pcFolderName,pcCheckedOutUserName ,pcCheckedOutDate); 
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
						*lValidationFailed = true;
						free(pcCheckedOutUserName);
						pcCheckedOutUserName = NULL;
						SAFE_MEM_free(pcCheckedOutDate);
					}
					// check if the secondary object is remote
					if( iFail == ITK_ok)
						iFail = AOM_ask_value_tag( ptSecondaryList[iSecCntr].secondary, "owning_site", &tOwningSite);
					if(iFail == ITK_ok && tOwningSite != NULLTAG)
					{
						TI_sprintf(acErrorString, "The %s \"%s\" attached to the item revision \"%s/%s\" present in the \"%s\" folder is a remote object.",
												pcSecObjClassName,pcObjName, acItemId, acRevId,pcFolderName); 
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
						*lValidationFailed = true;
					}
					SAFE_MEM_free(pcObjName);
					SAFE_MEM_free(pcSecObjClassName);
				}						
				SAFE_MEM_free(ptSecondaryList);
			}					
		}
		// check if the classname of the targeted object pseudo folder is Form		
		else if((iFail == ITK_ok)  && (tc_strcasecmp (pcClassName , "Form")== 0) )
		{
			//get form name 
			if(iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG)
				iFail = AOM_ask_name(ptAffectedObjects[iAffCntr],&pcObjName); 
			
			// check if item is checked out
			if(iFail == ITK_ok)
				iFail = Is_Object_Checked_out(ptAffectedObjects[iAffCntr],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);
			if( iFail == ITK_ok && lCheckedOut == false )
			{
			}
			else if( iFail == ITK_ok && lCheckedOut == true )
			{
				TI_sprintf(acErrorString, "The Form \"%s\" present in the \"%s\" folder is checked out by \"%s\" on \"%s\".",pcObjName,pcFolderName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
				free(pcCheckedOutUserName);
				pcCheckedOutUserName = NULL;
				SAFE_MEM_free(pcCheckedOutDate);
			}	
			// check if the form is remote
			if( iFail == ITK_ok)
				iFail = AOM_ask_value_tag( ptAffectedObjects[iAffCntr], "owning_site", &tOwningSite);
			if( iFail == ITK_ok && tOwningSite != NULLTAG)
			{
				TI_sprintf(acErrorString, "The form \"%s\" present in the \"%s\" folder is a remote object.",pcObjName, pcFolderName); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lValidationFailed = true;
			}
			SAFE_MEM_free(pcObjName);
		}
		SAFE_MEM_free(pcClassName);
	}

	return iFail;
}
//-----------------------------------------------------------------------------------------------------
// This method checks whether any objects is checked-out or not. If the object is checked-out, then
// a true flag along with the checked-out user name and the date on which the object is  
// checked out will be returned
//-----------------------------------------------------------------------------------------------------
int Is_Object_Checked_out(tag_t		tObject,					/*<I>*/
						  logical	*lIsCheckedOut,				/*<O>*/
						  char		**pcCheckedOutUserName,		/*<O>*/
						  char		**pcCheckedOutDate)			/*<O>*/
{
	int		iFail							= ITK_ok;
	tag_t	tCheckedOutUser					= NULLTAG;
	tag_t	tCheckedOutGroup				= NULLTAG;
	char	acOSUserName[SA_name_size_c+1]	= "";

	*lIsCheckedOut = false;
	// check if item revision is checked out
	if ( iFail == ITK_ok && tObject != NULLTAG)
		iFail = RES_is_checked_out( tObject, lIsCheckedOut );
	if( iFail == ITK_ok && *lIsCheckedOut == true)
	{
		iFail = RES_who_checked_object_out (tObject,&tCheckedOutUser,&tCheckedOutGroup);
		if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
		{
			iFail = SA_ask_user_person_name (  tCheckedOutUser, acOSUserName );
			if ( iFail == ITK_ok)
			{
				*pcCheckedOutUserName = (char *)malloc((int)tc_strlen(acOSUserName)+1);
				tc_strcpy(*pcCheckedOutUserName,acOSUserName);
			}
		}
		if ( iFail == ITK_ok)
		{
			iFail = AOM_UIF_ask_value  (tObject,"checked_out_date",pcCheckedOutDate);
		}
	}
	return iFail;
}
//----------------------------------------------------------------------------------------------------------
// This method checks whether the BVR of the item revision is checked out or not. If the BVR is checked out,
// then a true flag along with the checked-out user name, the date on which the object is checked out and the 
// BVR name will be returned.
//-----------------------------------------------------------------------------------------------------------
int Is_BVR_Checked_Out( tag_t		tItemRev,					/*<I>*/
					    logical		*lIsCheckedOut,				/*<O>*/
					    char		**pcCheckedOutUserName,		/*<O>*/
						char		**pcCheckedOutDate,			/*<O>*/
						char		**pcBVRName)				/*<O>*/
{	
	int		iFail			= ITK_ok;
	int		iItemBvrCount	= 0;
	tag_t	*ptItemRevBvrs	= NULL;

	*lIsCheckedOut = false;
	//Check if the item revision has any BomViews.
	iFail = ITEM_rev_list_bom_view_revs (tItemRev, &iItemBvrCount, &ptItemRevBvrs);
	if( iFail == ITK_ok && iItemBvrCount > 0 )
	{
		// check BVR is checked out or not
		iFail = Is_Object_Checked_out( ptItemRevBvrs[0], lIsCheckedOut,pcCheckedOutUserName ,pcCheckedOutDate);
		if( iFail == ITK_ok && *lIsCheckedOut == true )
		{
			// get the BVR name
			iFail = AOM_ask_name(ptItemRevBvrs[0],pcBVRName); 
		}
	}
	SAFE_MEM_free(ptItemRevBvrs);
	return iFail;
}

//----------------------------------------------------------------------------------------------------------
// This method checks whether change forms under the change revision with IMAN_specification relation is 
// checked out or not. If the change form is checked out, then a true flag along with the checked-out user
// name, the date on which the object is checked out and the form name will be returned.
//-----------------------------------------------------------------------------------------------------------
int Validate_Change_Forms(tag_t	tTask,tag_t	tEngChangeRev,char *pcCurrTaskName,int iChangeFormCount,tag_t *ptChangeForms, logical *lChangeFormValFailed,TIA_ErrorMessage **pstCurrErrMsg)
{
	int		iFail = ITK_ok;
	int		iCount = 0;
	logical lCheckedOut					= false;
	char	*pcCheckedOutUserName		= NULL;
	char	*pcCheckedOutDate			= NULL;
	char	*pcObjName					= NULL;	
	char	acErrorString[512]			= "";

	*lChangeFormValFailed = false;
	for(iCount = 0; (iCount < iChangeFormCount) && (iFail == ITK_ok); iCount++)
	{
		lCheckedOut = false;
		pcObjName = NULL;
		pcCheckedOutUserName = NULL;
		pcCheckedOutDate = NULL;
		iFail = Is_Object_Checked_out(ptChangeForms[iCount],&lCheckedOut,&pcCheckedOutUserName,&pcCheckedOutDate);

		if( iFail == ITK_ok && lCheckedOut == true)
		{			
			tag_t		tRespParty			= NULLTAG;
			logical		lChngFormFound		= false;
			char		*pcRespParty		= NULL;
			char	*pcTaskResult			= NULL;
					
			if(iFail==ITK_ok && tTask!=NULLTAG)
			{
				TIAUTO_ITKCALL(iFail,EPM_ask_responsible_party(tTask,&tRespParty));
				TIAUTO_ITKCALL(iFail,EPM_get_task_result(tTask,&pcTaskResult));
			}
			if(iFail==ITK_ok && tRespParty!=NULLTAG)
				TIAUTO_ITKCALL(iFail,SA_ask_user_person_name2(tRespParty,&pcRespParty));
			
			if(iFail==ITK_ok && ((tc_strcmp(pcRespParty,pcCheckedOutUserName)==0) ))
			{
				lChngFormFound = false;
				SAFE_MEM_free(pcRespParty);
			}
			else if((tc_strstr(pcTaskResult,"Reject")!= NULL) || (tc_strstr(pcTaskResult,"Rework")!=NULL) || (tc_strstr(pcTaskResult,"Demote")!=NULL))
			{
				lChngFormFound = false;
			}
			else if(iFail==ITK_ok)
			{
				int			iTaskCount			= 0;
				int			iLoopTasks			= 0;
				tag_t		*ptTaskTags			= NULL;

				TIAUTO_ITKCALL(iFail,AOM_ask_value_tags(tEngChangeRev,TIAUTO_PROCESS_STAGE_LIST,&iTaskCount,&ptTaskTags));
				for(iLoopTasks =0; iLoopTasks < iTaskCount; iLoopTasks++)
				{
					char	*pcTaskName				= NULL;
					
					tag_t	tRootTaskTag			= NULLTAG;

					tRespParty = NULLTAG;
					
					if(iFail==ITK_ok && ptTaskTags[iLoopTasks]!=NULLTAG)
					{
						TIAUTO_ITKCALL(iFail,EPM_ask_root_task(ptTaskTags[iLoopTasks], &tRootTaskTag));
						TIAUTO_ITKCALL(iFail,EPM_ask_name2(ptTaskTags[iLoopTasks],&pcTaskName));
						TIAUTO_ITKCALL(iFail,EPM_ask_responsible_party(ptTaskTags[iLoopTasks],&tRespParty));
						
					}
					if(iFail==ITK_ok && tRespParty!=NULLTAG)
					{
						TIAUTO_ITKCALL(iFail,SA_ask_user_person_name2(tRespParty,&pcRespParty));
					}
					
					if(iFail== ITK_ok && ((tc_strcmp(pcTaskName,pcCurrTaskName)!= 0) && (tc_strcmp(pcRespParty,pcCheckedOutUserName)==0) && (tRootTaskTag!=ptTaskTags[iLoopTasks])))
					{
						int			iTarCount			= 0;
						int			iLoopTarObj			= 0;
						tag_t		*ptTarObj			= NULL;							
						
						TIAUTO_ITKCALL(iFail,EPM_ask_attachments(tRootTaskTag,EPM_target_attachment,&iTarCount,&ptTarObj));
						for(iLoopTarObj =0; iLoopTarObj < iTarCount; iLoopTarObj++)
						{
							if(iFail==ITK_ok && (ptTarObj[iLoopTarObj] == ptChangeForms[iCount]))
							{
								lChngFormFound = true;
								break;
							}
							
						}
						SAFE_MEM_free(ptTarObj);
					}							
					SAFE_MEM_free(pcTaskName);							
					SAFE_MEM_free(pcRespParty);
					SAFE_MEM_free(pcTaskResult);
				}
				SAFE_MEM_free(ptTaskTags);
			}
			if(iFail == ITK_ok && lChngFormFound == false)
			{
				iFail = AOM_ask_name(ptChangeForms[iCount],&pcObjName);
				TI_sprintf(acErrorString, "The Form \"%s\" present under the targeted change revision is checked out by \"%s\" on \"%s\".",pcObjName, pcCheckedOutUserName,pcCheckedOutDate); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_CHECKEDOUT_REMOTEOBJECT_ERROR, acErrorString);
				*lChangeFormValFailed = true;
				lCheckedOut = false;				
				pcCheckedOutUserName = NULL;				
				pcObjName = NULL;
			}
			
			SAFE_MEM_free(pcRespParty);
		}
	}
	SAFE_MEM_free(pcCheckedOutDate);
	SAFE_MEM_free(pcObjName);
	free(pcCheckedOutUserName);
	return iFail;
}