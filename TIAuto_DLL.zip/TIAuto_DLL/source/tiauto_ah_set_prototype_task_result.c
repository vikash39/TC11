/*******************************************************************************
File         : tiauto_ah_set_prototype_task_result.c

Description  : If all the items in the solution items and drawing items folder are at Prototype status, then set the conditional task result as true.

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 6, 2016    1.0        Shilpa      		Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int t1aAUTO_AH_set_prototype_task_result(EPM_action_message_t msg)
{
	int				iRetcode							= ITK_ok;
	int				iTargetCount						= 0;
	int				iSecObjCount						= 0;
	int				iDrwCnt								= 0;
	tag_t			tRootTaskTag						= NULLTAG;	
	tag_t			*ptTargetAtt						= NULL;
	tag_t			*ptSecObjTags						= NULL;
	tag_t			*ptDrwObjTags						= NULL;
	char            pszObjectType[WSO_name_size_c+1]	= "";
	tag_t			tRelTag								= NULLTAG;
	tag_t			tRelationTag						= NULLTAG;
	
	if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the change revision details
		if(iRetcode == ITK_ok && tRootTaskTag!= NULLTAG)
		{
			int		iLoopTargetCnt			= 0;
			
			iRetcode =  EPM_ask_attachments	(tRootTaskTag, EPM_target_attachment,&iTargetCount,&ptTargetAtt);
			for(iLoopTargetCnt =0; iLoopTargetCnt < iTargetCount; iLoopTargetCnt++)
			{
				iRetcode = WSOM_ask_object_type(ptTargetAtt[iLoopTargetCnt], pszObjectType);
				if((strcmp(pszObjectType,NEWCHANGE_REV)==0)  && (iRetcode == ITK_ok))
				{
					int				iLoopSecObjCount			= 0;
					int				iLoopDrwCount				= 0;
					char			*pcReleaseStatusName		= NULL;
					logical			lisPrototypeStatus			= false;
					logical			lisDrwPrototypeStatus		= false;
					tag_t			*ptReleaseStatuses			= NULL;
					iRetcode = GRM_find_relation_type("CMHasSolutionItem", &tRelTag);
					iRetcode = GRM_list_secondary_objects_only	(ptTargetAtt[iLoopTargetCnt],tRelTag,&iSecObjCount,&ptSecObjTags);
					iRetcode = GRM_find_relation_type("T8_CMTIDrawingItems", &tRelationTag);
					iRetcode = GRM_list_secondary_objects_only	(ptTargetAtt[iLoopTargetCnt],tRelationTag,&iDrwCnt,&ptDrwObjTags);
					for(iLoopSecObjCount =0; iLoopSecObjCount < iSecObjCount; iLoopSecObjCount++)
					{
						int			iRelStatusCount				= 0;
						int			iLoopRelStatusCnt			= 0;
												
						iRetcode = AOM_ask_value_tags(ptSecObjTags[iLoopSecObjCount],"release_status_list",&iRelStatusCount,&ptReleaseStatuses);
						for(iLoopRelStatusCnt =0 ; iLoopRelStatusCnt < iRelStatusCount; iLoopRelStatusCnt++)
						{
							iRetcode = AOM_ask_value_string(ptReleaseStatuses[iLoopRelStatusCnt],"object_name",&pcReleaseStatusName);
							if((strcmp(pcReleaseStatusName,"Prototype") ==0) && (iRetcode == ITK_ok))
							{
								lisPrototypeStatus = true;
								break;
							}
							
						}
						if(lisPrototypeStatus== true && iRetcode == ITK_ok )
						{
							break;
						}
					
												
					}
					if(	lisPrototypeStatus ==false && iRetcode == ITK_ok )
					{
						for(iLoopDrwCount =0; iLoopDrwCount < iDrwCnt; iLoopDrwCount++)
						{
							int			iRelStatusCount				= 0;
							int			iLoopRelStatusCnt			= 0;
														
							iRetcode = AOM_ask_value_tags(ptDrwObjTags[iLoopDrwCount],"release_status_list",&iRelStatusCount,&ptReleaseStatuses);
							for(iLoopRelStatusCnt =0 ; iLoopRelStatusCnt < iRelStatusCount; iLoopRelStatusCnt++)
							{
								
								iRetcode = AOM_ask_value_string(ptReleaseStatuses[iLoopRelStatusCnt],"object_name",&pcReleaseStatusName);
								if((strcmp(pcReleaseStatusName,"Prototype") ==0) && (iRetcode == ITK_ok))
								{
									lisDrwPrototypeStatus = true;
									break;
								}
								
							}
							if(lisDrwPrototypeStatus== true && iRetcode == ITK_ok )
							{
								break;
							}
							
						}
					}
					
					if((lisPrototypeStatus == true || lisDrwPrototypeStatus == true) && iRetcode == ITK_ok )
					{
						iRetcode = EPM_set_condition_task_result( msg.task,EPM_RESULT_TRUE);
					}
					
					else if(iRetcode == ITK_ok )
					{
						iRetcode = EPM_set_condition_task_result( msg.task,EPM_RESULT_FALSE);
					}
					SAFE_MEM_free(pcReleaseStatusName);
					SAFE_MEM_free(ptReleaseStatuses);
				}
			}
		}
	}
	
	else if ( iRetcode != ITK_ok )
	{
		char			*pcErrMsg			= NULL;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(ptTargetAtt);
	SAFE_MEM_free(ptSecObjTags);
	SAFE_MEM_free(ptDrwObjTags);
		
	return iRetcode;
}
		