/************************************************************************************************************
File         : tiauto_ah_create_erp_translation_request.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
Mar 6, 2013    1.0        Dipak Naik      Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <time.h>

//main function of the handler "TIAUTO-AH-Create-ERP-Translation-Request"
extern int TIAUTO_AH_create_erp_translation_request(EPM_action_message_t msg)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				iNumAffected								= 0;
	int				iSite										= 0;
	int				iSiteID										= 0;
	int				iCount										= 0;
	
	char			**pcCustomerName							= NULL;
	char			*pcErrMsg									= NULL;
	char			caObjectType[WSO_name_size_c+1]				= "";	
	char			acSiteName[SA_site_size_c+1]				= {'\0'};
	char			*pcValidReleaseStatusList					= NULL;
	char    **pszProgressionPath  = NULL; 
    TC_preference_search_scope_t tScope;
	
	tag_t			tChangeRev								= NULLTAG;
	tag_t			tUser									= NULLTAG;
	tag_t			tGroup									= NULLTAG;
	tag_t           tRequest								= NULLTAG;
	tag_t			tSite									= NULLTAG;
	tag_t			*ptAffectedItems						= NULL;

	boolean bValidERPPlant			= false;
	boolean bMfgRelAuthToBeCreated	= false;
	
	//Get the Current Site Name
	if( iRetCode == ITK_ok )
		iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	//get the site name mentioned in the preference
	iRetCode = PREF_ask_search_scope( &tScope );
	if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );
    if (iRetCode == ITK_ok)
    {
        iRetCode = PREF_ask_char_values("T8_TI_BPCS_82_ERP_Integration", &iCount, &pszProgressionPath);
        if (iRetCode != ITK_ok)
        {
			iRetCode = 0;
			return 0;
        }
		
    }
    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( tScope );

	if (iRetCode == ITK_ok )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//iRetCode = verify_Valid_ERP_Plant(msg.task,&bValidERPPlant,&bMfgRelAuthToBeCreated,&pcValidReleaseStatusList);
			if(iCount > 0 && pszProgressionPath != NULL)
			{
				for(indx = 0;indx<iCount;indx++)
				{
					//if(tc_strstr(acSiteName,"North America") != NULL)
					if(tc_strstr(pszProgressionPath[indx],acSiteName) != NULL)
					{
						bValidERPPlant = true;
						break;
					}
				}
			}

			if(bValidERPPlant == true)
			{
				iRetCode = ECM_get_affected_items(tChangeRev, &iNumAffected, &ptAffectedItems);
				for(indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++ )
				{
					tc_strcpy(caObjectType,"");
					/* get the object type */
					iRetCode = WSOM_ask_object_type (ptAffectedItems[indx], caObjectType);
					if( (tc_strcmp(caObjectType,"TI_Product Revision") == 0) ||
						(tc_strcmp(caObjectType,"TI_Material Revision") == 0) ||
						(tc_strcmp(caObjectType,"TI_Prg_Variant Revision") == 0) )
					{
						iRetCode = DISPATCHER_create_request  ( "TI-ERP", "plmtoerp",3,0 ,0 ,0, 1,&tChangeRev ,NULL,0  ,NULL,"PLM_Export",0,NULL,NULL,&tRequest);
						iRetCode = SA_find_user ("erpintegration",&tUser);
						if(tUser != NULLTAG)
						{
							iRetCode = SA_ask_user_login_group(tUser,&tGroup); 
							iRetCode = AOM_set_ownership (tRequest,tUser,tGroup);
						}
						//iRetCode = AOM_save(tRequest);
						iRetCode = AOM_refresh (tRequest,false);
						break;
					}
				}
				if(iNumAffected == 0)
				{
					char    pszObjType[WSO_name_size_c+1]="";
					iRetCode = WSOM_ask_object_type(tChangeRev, pszObjType);

					if (iRetCode == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
					{
						tag_t tRelTemp = NULLTAG;
						iRetCode = GRM_find_relation_type ("T8_CMTIChangedForms",&tRelTemp);
						if(iRetCode == ITK_ok && tRelTemp!=NULLTAG)
						{
							iRetCode = GRM_list_secondary_objects_only(tChangeRev,tRelTemp,&iNumAffected,&ptAffectedItems);
						}
					}
					else
						iRetCode = ECM_get_contents(tChangeRev, "t1achanged_forms",  &iNumAffected, &ptAffectedItems);

					for(indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++ )
					{
						tc_strcpy(caObjectType,"");
						/* get the object type */
						iRetCode = WSOM_ask_object_type (ptAffectedItems[indx], caObjectType);
						if( tc_strcmp(caObjectType,"TI_Product Revision Master") == 0)
						{
							iRetCode = DISPATCHER_create_request  ( "TI-ERP", "plmtoerp",3,0 ,0 ,0, 1,&tChangeRev ,NULL,0  ,NULL,"PLM_Export",0,NULL,NULL,&tRequest);
							iRetCode = SA_find_user ("erpintegration",&tUser);
							if(tUser != NULLTAG)
							{
								iRetCode = SA_ask_user_login_group(tUser,&tGroup); 
								iRetCode = AOM_set_ownership (tRequest,tUser,tGroup);
							}
							//iRetCode = AOM_save(tRequest);
							iRetCode = AOM_refresh (tRequest,false);
							break;
						}
					}
				}
				
				SAFE_MEM_free(ptAffectedItems);
			}
		}
	}
	if (iRetCode != ITK_ok ) 
	{
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcCustomerName);
	return iRetCode;
}
