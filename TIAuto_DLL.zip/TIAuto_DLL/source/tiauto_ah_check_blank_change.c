/*******************************************************************************
File         : tiauto_ah_check_blank_change.c

Description  : This handler is configured for checking the blank change.
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
June 02, 2010    1.0        Dipak Naik    Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int TIAUTO_AH_check_blank_change(EPM_action_message_t msg)
{
   int iRetcode = ITK_ok;
	
	return iRetcode;  
}