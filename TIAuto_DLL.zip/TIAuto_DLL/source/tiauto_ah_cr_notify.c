/*******************************************************************************
File         : tiauto_ah_cr_notify.c

Description  : This action handler sends mails with the sign-off decision of the current task to the
				next task.
Sample Mail  :
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
May 24, 2010    1.0        Dipak Naik      Initial Creation
Jan 21, 2011	1.1		   Dipak Naik	   Modified the code to send the next task's
										   instruction instead of current task's 
										   instruction and the subject of the mail
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

#define INIT_LIST_SIZE           (16)
#define MAX_OS_NAME_SIZE         (64)
#define SIZE_OF_DATE_STRING      (11)
#define DECISION_TYPE_ERROR      "Invalid type of decision"
#define DECISION_TYPE_ERROR_CODE (4)
#define REALLOC_ERROR            "Error reallocating array"
#define DUE_DATE_FORMAT          "%s %s\n"
#define HEADER_FORMAT            "%s %s\n"
#define TARGET_STR_FORMAT        "%s\n"
#define REPORT_FORMAT            "                   %-32s %-32s\n"

#define REPORT_SEPARATOR         "\t=================================================\n"
#define REPORT_SEPARATOR2        "------------------------------------------------------------------------------------\n"

#define NO_ATTH_MSG_FORMAT       "\t\t%s\n"
#define NO_REFERENCE_MSG         "No reference objects found"
#define RELEASE_LEV_STR          "\nRelease Level:"
#define REL_REC_FORMAT           "%-23.21s%-13.11s%-15.13s%s\n"
#define REL_HEADER_STR           REL_REC_FORMAT,"Reviewer","Decision","Date","Comments"
#define APPROVE_STR              "Approve"
#define REJECT_STR               "Reject"
#define NO_DECISION              "None"
#define USER_CONTENT_FORMAT      "\n\t%s\n"

#define USER_CLASS_NAME          "User"
#define GROUP_CLASS_NAME         "Group"
#define GROUPMEMBER_CLASS_NAME   "GroupMember"
#define RESOURCEPOOL_CLASS_NAME  "ResourcePool"
#define DLIST_CLASS_NAME         "DistributionList"
#define ALIST_CLASS_NAME         "AliasList"
#define REVIEWER_FLAG_STRING     "reviewer"
#define LEVEL_FLAG_STRING        "level"
#define REVIEW_SUBJECT           " Please review the following job "
#define PROGRESS_SUBJECT         " Release progress report "
#define LEVEL_SUBJECT            " Release level report "
#define MAIL_SUBJECT            " Please perform the following task"
#define REJECTION_SUBJECT        " Job rejected "

#define CURRENT_USER              "$USER"

#define RESOURCE_POOL_ALL         "$RESOURCE_POOL_ALL"
#define RESOURCE_POOL_NONE        "$RESOURCE_POOL_NONE"
#define RESOURCE_POOL_SUBSCRIBED  "$RESOURCE_POOL_SUBSCRIBED"

#define DECISION_SIZE            (8)
#define DATE_STR_SIZE            (10)

#define ERROR_MSG                "bad value in cr_action_handlers.c"

/* <jiho>following three items are defined in epmtask.hxx too.
 *  They are here just for an IRM build. They will be moved to epmtask.h later.
 */
#define EPMREVIEWTASK_TYPE_NAME "EPMReviewTask"
#define EPMSELECTSIGNOFFTASK_TYPE_NAME "EPMSelectSignoffTask"
#define EPMPERFORMSIGNOFFTASK_TYPE_NAME "EPMPerformSignoffTask"


/* <KARIM> Two file-global variables I am adding to support AliasList as a recipient for
 * for CR_notify. I tried to avoid using global variable, but it was ending up lots
 * of rework.
 */
static char **address_list;


enum report { progress,
              rejection,
              review,
              level
              };
typedef enum report report_e;

struct __mail_attributes_s
{
    char *  subject;
    char *  contents;
	char *  nextTaskName;
	tag_t  tNextTask;
    report_e report_type;
    logical url;
    logical rich_url;
    logical dhtml_url;
    logical html_url;
    
};

typedef struct __mail_attributes_s mail_attributes_t;

const char* URLServer_preference = "WEB_default_site_server";

#define FLAG_RICH  "rich"
#define FLAG_DHTML "dhtml"
#define FLAG_HTML  "html"

static int askURLTypes(mail_attributes_t attrs,int *add_portal_url,
                       int *add_html_url,int *add_dhtml_url);

static int get_formated_date_string(date_t the_date, char date_string[SIZE_OF_DATE_STRING+1]);

static int print_target_attachment_name_and_type( tag_t wso_object,FILE **mail_file );

static int get_notify_arguments( EPM_action_message_t msg,     /* <I> */
                                 counted_tag_list_t *recipient,     /* <OF> */
                                 counted_list_t *mail_addresses,     /* <OF> */
                                 mail_attributes_t * attrs      /* <O> */
                                );

static int write_report( tag_t task_tag,                            /* <I> */
                        int levels,                            /* <I> */
                        FILE *mail_file,                       /* <I> */
                        char *user_content,                    /* <I> */
                        report_e report_type,                   /* <I> */
                        mail_attributes_t *attrs               /* <I> */
                        );

static int write_header( tag_t job,                           /* <I> */
                         tag_t the_task,                      /* <I> */
                        const char *current_release_level,    /* <I> */
                        FILE *file,                           /* <I> */
                        mail_attributes_t *attrs               /* <I> */
                        );


static int write_release_level( tag_t job,                    /* <I> */
                               const char *rel_lev_name,      /* <I> */
                               FILE *file                     /* <I> */
                               );


static int mail_send_os_mail( const char *subject,              /* <I> */
                              counted_list_t receiverList,      /* <I> */
                              const char *mail_file_name        /* <I> */
                            );


static int ask_os_address( const char *normal_value,          /* <I>  */
                          tag_t task,                         /* <I>  */
                          counted_tag_list_t *recipients,     /* <OF> */
                          counted_list_t *mail_addresses      /* <OF> */
                          );

static int process_dlist_recipient( tag_t dlist,              /* <I> */
                                   counted_tag_list_t *recipients    /* <OF> */
                                   );

static int process_aliaslist_recipient( tag_t alist,                /* <I> */
                                   counted_tag_list_t *recipients,   /* <OF> */
                                   counted_list_t *mail_addresses   /* <OF> */
                                   );

static int process_role_recipient( char *value,              /* <I> */
                                  counted_tag_list_t *recipients    /* <OF> */
                                  );

static int process_group_recipient( tag_t group_tag,         /* <I> */
                                   counted_tag_list_t *recipients   /* <OF> */
                                   );

static int process_groupmember_recipient( tag_t groupmember_tag,     /* <I> */
                                   counted_tag_list_t *recipients    /* <OF> */
                                   );

static int add_recipients_for_token( tag_t task,                     /* <I> */
                                     const char* token,              /* <I> */
                                     counted_tag_list_t *recipients  /* <OF> */
                                   );

static logical isResourcePoolArg(const char *value);



static int get_property (tag_t task_tag, char *prop_name, tag_t *value);

static int add_resource_pool_recipients_as_per_preference( 
    tag_t task, 
    counted_tag_list_t *recipients
);

static void release_string_array( int count,  char **list  );

static logical is_report_type_supported_for_action(report_e report_type, EPM_action_t the_action);

/*---------------------------------------------------------------------------*/

extern int TIAUTO_CR_notify( EPM_action_message_t msg )
     /*
      *  description: this action handler will notify specified recipients
      *         by sending formatted reports through the os mail
      *
      *
      */
{
    int rcode              = ITK_ok;
    int imailFileOpen      = 0;
    FILE *mail_file        = NULL;
    char *mail_file_name   = NULL;
    tag_t job          = null_tag;
    counted_tag_list_t recipients;         /* call MEM_free */
    
    counted_list_t     mail_addresses;     /* call MEM_free */
    counted_list_t     final_mail_list;    /* call MEM_free */
    
    char subject[BUFSIZ +1];
    char *user_subject     = NULL;    /* free this */
    char *user_contents    = NULL;    /* free this */
 

    mail_attributes_t attrs;

    /* initialize mail attributes here...*/
    attrs.subject  = 0;
    attrs.contents = 0;
	attrs.nextTaskName = 0;
	attrs.tNextTask = 0;
    attrs.report_type = (report_e) review;
    attrs.url      = 0;
    attrs.rich_url = 0;
    attrs.dhtml_url= 0;
    attrs.html_url = 0;

    /* start of initialization tasks */

    subject[0] = '\0';
    recipients.count = 0;
    mail_addresses.count = 0;

    final_mail_list.count = 0;
    final_mail_list.list = 0;

    /* Initialize global variables for AliasList */
    address_list = NULL;

    recipients.list = (tag_t *)MEM_alloc( INIT_LIST_SIZE * (sizeof(tag_t)) );
    mail_addresses.list = (char **)MEM_alloc( INIT_LIST_SIZE * sizeof(char*) );
    
    if ( (recipients.list == NULL) || (mail_addresses.list == NULL) )
    {
        rcode = SS_NOMEM;
    }

    if ( rcode == ITK_ok )
    {
        mail_file_name = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
        imailFileOpen = fopen_s(&mail_file,mail_file_name, "w" );
        if ( mail_file == NULL )
        {
            rcode = CR_cannot_open_file;
        }
    }

    if ( rcode == ITK_ok )
    {
        rcode = EPM_ask_job( msg.task, &job );
    }

    if ( rcode == ITK_ok )
    {
        rcode = get_notify_arguments( msg,&recipients, &mail_addresses,&attrs);
    }
    
    /* This function will find if the report type and action are compatible.*/
    if( is_report_type_supported_for_action(attrs.report_type,msg.action) == false )
    {
         // PR# 5350473 fix: cleanup before return
         if ( mail_file != NULL )
         {
             fclose( mail_file );
         }
         SAFE_SM_FREE( recipients.list );
         release_string_array( mail_addresses.count,  mail_addresses.list  );
         remove(mail_file_name);
         free(mail_file_name);

         return rcode;
    }
    
    /* start of mainline */

    if ( rcode == ITK_ok )
    {
		if(attrs.nextTaskName != NULL)
		{
			tc_strcpy( subject, MAIL_SUBJECT);
		}
		else
		{
			switch ( attrs.report_type )
			{
			case review:
				tc_strcpy( subject, REVIEW_SUBJECT );
				break;
			case progress:
				tc_strcpy( subject, PROGRESS_SUBJECT );
				break;
			case level:
				tc_strcpy( subject, LEVEL_SUBJECT );
				break;
			case rejection:
				tc_strcpy( subject, REJECTION_SUBJECT );
				break;
			default:
				rcode = EPM_invalid_argument;
			}

			if ( attrs.subject != NULL )
			{
				tc_strcat( subject, attrs.subject );
			}
		}
         
        /* Add process name and task name to subject */
        if(rcode == ITK_ok)
        {
             char process_name[WSO_name_size_c + 1];
             char task_name[WSO_name_size_c + 1];
        
             process_name[0] = 0;
             task_name[0]    = 0;
        
             /* 1. get process name from job tag */
             rcode = WSOM_ask_name( job, process_name );

             if( (rcode == ITK_ok) && (process_name[0] !=0 ) )   
             {
                  /* 2. get task name from task tag */
                  rcode =  WSOM_ask_name( msg.task , task_name );
             }

             /* 3. append process_name ( task_name ) to subject */
             if( (rcode == ITK_ok) && (task_name[0] != 0) )
             {
                  tc_strcat(subject," : ");
                  tc_strcat(subject,process_name);
                  tc_strcat(subject," (");
				  if ( attrs.subject != NULL )
				  {
					tc_strcat( subject, attrs.subject );
				  }
				  else
				  {
					tc_strcat(subject,task_name);
				  }
                  tc_strcat(subject," )");
             }        
         }    
    }
    if ( rcode == ITK_ok )
    {
        rcode = write_report( msg.task, level, mail_file, attrs.contents, attrs.report_type, &attrs );
    }

    /*  loop throught the recipient list and send mail one at a time
     *  to avoid bouncing mail due to a bad address
     */

    if ( mail_file != NULL )
    {
        fclose( mail_file );
    }

    /* remove deuplicate users */
    EPM_remove_duplicate_tags( &(recipients.count), &(recipients.list));

    /* get list of mail address */
    EPM_get_mailing_list( recipients.count,recipients.list, &mail_addresses);

    /* remove duplicate nailing addresses */
    EPM_remove_duplicate_strings( mail_addresses.count , mail_addresses.list,
                                  &(final_mail_list.count),&(final_mail_list.list));

    /* send mail to all users listed in recipients list */
    rcode = mail_send_os_mail( subject,
                               final_mail_list,
                               mail_file_name
                             );

    /* start of finalization */
    SAFE_SM_FREE( user_subject );
    SAFE_SM_FREE( user_contents );
    SAFE_SM_FREE( recipients.list );

    release_string_array( mail_addresses.count,  mail_addresses.list  );
    release_string_array( final_mail_list.count, final_mail_list.list );

    remove(mail_file_name);
    //free(mail_file_name);

    return ( rcode );
}


/*---------------------------------------------------------------------------*/
static int write_header( tag_t job,                              /* <I> */
                         tag_t the_task,                          /* <I> */
                         const char *current_release_level,      /* <I> */
                         FILE *mail_file,                         /* <I> */
                         mail_attributes_t *attrs                  /* <I> */
                       )
/*
 *  description: this function will get the job name, current release level,
 *               target attachments, and reference attachments and write the
 *               the header information to a file
 *
 */
{
    int rcode = ITK_ok;
    int target_count = 0;
    int reference_count = 0;
    int ctr;
    char process_name[WSO_name_size_c + 1];
    tag_t *target_objects = NULL;
    tag_t *reference_objects = NULL;
    tag_t root_task = NULLTAG;

    txt_t the_text_server = 0;
    char *msg_name = 0;
    
    /* -- used by Due Date -- */
    date_t the_due_date;


    /* Initialize TextServer here */
    the_text_server = txt_ctor( "tc_text.xml" );

    /* -- Due Date -- */

    /* initialize due date */
    the_due_date.day   = 0;
    the_due_date.month = 0;
    the_due_date.year  = 0;
    
    if( (rcode = EPM_ask_task_due_date(the_task,&the_due_date)) == ITK_ok )
    {
        char *sz_due_date         = 0;
        char *sz_due_date_not_set = 0;

        char date_string[SIZE_OF_DATE_STRING+1];
   
        msg_name = "Due_Date";
        sz_due_date         = txt_noSubText(the_text_server,msg_name,true);

        msg_name = "Due_Date_Not_Set";
        sz_due_date_not_set = txt_noSubText(the_text_server,msg_name,true);
   
        rcode = get_formated_date_string(the_due_date,date_string);
  
        /* if day,month and year all are found then set the due date,
         * else set as "None"
         */
        if( (rcode == ITK_ok) && (date_string[0] != 0) )
        {
            fprintf( mail_file,DUE_DATE_FORMAT,sz_due_date,date_string);
        }
        else
        {
            fprintf( mail_file,HEADER_FORMAT,sz_due_date,sz_due_date_not_set); 
        }
   
        TC_free_text(sz_due_date); 
        TC_free_text(sz_due_date_not_set); 
    }

    /* -- Process Name : --*/
    if ( rcode == ITK_ok )
    {
        if ( ((rcode = WSOM_ask_name( job, process_name )) == ITK_ok) && (process_name != 0) )
        {
            char *sz_process_name = 0;
       
            msg_name = "Process_Name";
            sz_process_name = txt_noSubText(the_text_server,msg_name,(int)true);
 
            fprintf( mail_file, HEADER_FORMAT, sz_process_name, process_name );
            TC_free_text(sz_process_name);
        } 

        /*fprintf( mail_file, HEADER_FORMAT, "current release level",
                   current_release_level
                );
        */
   
        /*fprintf( mail_file, TARGET_STR_FORMAT,"target:" );
        fprintf( mail_file, REPORT_FORMAT, "name","type" );
        fprintf( mail_file, REPORT_SEPARATOR );
        */
    }

    /* -- Current Task -- */
    if( rcode == ITK_ok )
    {
        char current_task_name[WSO_name_size_c + 1];

        current_task_name[ 0 ] = 0;
    
        if( ((rcode = EPM_ask_name(the_task,(char*)(&current_task_name))) == ITK_ok) && (current_task_name[0] != 0))
        {
             char *sz_current_task = 0;
        
             msg_name = "Current_Task";
             sz_current_task = txt_noSubText(the_text_server,msg_name,(int)true);
             if(attrs->nextTaskName != NULL)
			 {
				fprintf( mail_file, HEADER_FORMAT, sz_current_task, attrs->nextTaskName );
			 }
			 else
			 {
				 fprintf( mail_file, HEADER_FORMAT, sz_current_task, current_task_name );
			 }
             TC_free_text(sz_current_task);
        }
    }

    /* -- add an extra line -- */ 
    fprintf( mail_file,"\n");

    /* -- Add URLs -- */
    if( rcode == ITK_ok )
    {
        int add_portal_url = false;
        int add_html_url   = false;
        int add_dhtml_url  = false;

        char *url_string = 0;

        askURLTypes(*attrs,&add_portal_url,&add_html_url,&add_dhtml_url);

        if ( attrs->url == true || add_portal_url == true || 
                 add_html_url == true || add_dhtml_url == true )
        {
             TC_preference_search_scope_t oldScope;
             int serverCount = 0;
        
             PREF_ask_search_scope( &oldScope );
             PREF_set_search_scope( TC_preference_site );

             rcode = PREF_ask_value_count( URLServer_preference, &serverCount);
             if( serverCount > 0 )
             {
                    char *sz_instuctions_for_link = 0;
          
                    msg_name = "Instructions_For_Link";
                    sz_instuctions_for_link = txt_noSubText(the_text_server,msg_name,(int)true);

                    fprintf( mail_file, "%s\n",sz_instuctions_for_link);

                    if( add_portal_url == true )
                    {
                        rcode = TC_tag_to_url ( job, PORTAL, &url_string);
                        if ( rcode == ITK_ok && url_string != NULL )
                        {
                            char *sz_portal_app_name = 0;
             
                            msg_name = "Portal_App_Name"; 
                            sz_portal_app_name = txt_noSubText(the_text_server,msg_name,(int)true);

                            fprintf( mail_file, "%s %s\n",sz_portal_app_name,url_string);
                            TC_free_text(sz_portal_app_name);
                            MEM_free (url_string);
                        }
                     } // --end : add_portal_url

                    if( add_html_url == true )
                    {
                        rcode = TC_tag_to_url ( job, HTML, &url_string);
                        if ( rcode == ITK_ok && url_string != NULL )
                        {
                            char *sz_html_app_name = 0;
             
                            msg_name = "HTML_App_Name"; 
                            sz_html_app_name = txt_noSubText(the_text_server,msg_name,(int)true);

                            fprintf( mail_file, "%s %s\n",sz_html_app_name,url_string);
                            TC_free_text(sz_html_app_name);
                            MEM_free (url_string);
                        }
                    } // --end : add_html_url
                    
                    if( add_dhtml_url == true )
                    {
                        rcode = TC_tag_to_url ( job, DHTML,  &url_string);
                        if ( rcode == ITK_ok && url_string != NULL )
                        {
                            char *sz_dhtml_app_name = 0;
             
                            msg_name = "DHTML_App_Name";
                            sz_dhtml_app_name = txt_noSubText(the_text_server,msg_name,(int)true);
             
                            fprintf( mail_file, "%s %s\n",sz_dhtml_app_name,url_string);
                            TC_free_text(sz_dhtml_app_name);
                            MEM_free (url_string);
                        }
                    } // --end : add_dhtml_url
                }
                
                fprintf( mail_file, "\n");

                rcode = PREF_set_search_scope( oldScope );
            }

    }

    /* -- Add Comments -- */
    if( rcode == ITK_ok )
    {
        char *comments = 0;
   
        /* if comments are not supplied as argument to handler...*/
        char *no_comments_found = 0;
   
        msg_name = "User_Comments";
        comments = txt_noSubText(the_text_server,msg_name,(int)true);
        
        /* print comments here if supplied as argument to handler.. */
        if( attrs->contents != 0 )
        {
            fprintf(mail_file, "%s %s\n\n",comments,attrs->contents);
        }
        else
        {
            char *app_name = 0;
            char no_comments_msg[64]; 
            
            msg_name = "No_Comment";
            app_name = (char *)TC_getenv( "TC_APPLICATION" );
       
            if( msg_name != 0)
            {
                tc_strcpy(no_comments_msg,msg_name);
                if(app_name != 0)
                {
                    tc_strcat(no_comments_msg,app_name);
                }
            }
 
            no_comments_found = txt_noSubText(the_text_server,(char*)no_comments_msg,(int)true);

            fprintf(mail_file, "%s %s\n\n",comments,no_comments_found);
 
        }

        TC_free_text(comments);
        TC_free_text(no_comments_found);
    }
    
    /* -- Task Description -- */
    if( rcode == ITK_ok )
    {
        char description[WSO_desc_size_c + 1];
        char *desc_string =  0;
   
        msg_name = "Task_Desc";
        desc_string =  txt_noSubText(the_text_server,msg_name,(int)true);
        
        description[ 0 ] = 0;
		if(attrs->tNextTask != NULLTAG)
		{
			tag_t tTaskType = NULLTAG;
			char *pcTaskTypeName = NULL;
			char *pcSubTaskType = NULL;
			rcode = TCTYPE_ask_object_type(attrs->tNextTask,&tTaskType);
						
			if(rcode == ITK_ok && tTaskType != NULLTAG)
			{
				rcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
			}
			if( (tc_strcmp(pcTaskTypeName,"EPMReviewTask")==0) ||
				(tc_strcmp(pcTaskTypeName,"EPMAcknowledgeTask")==0) )
			{
				int iSubTaskCnt = 0;
				int isubTaskIndx = 0;
				tag_t *ptReviewSubTasks = NULL;
				//for review and acknowledge task					
				rcode = EPM_ask_sub_tasks( attrs->tNextTask, &iSubTaskCnt, &ptReviewSubTasks );
				if( rcode == ITK_ok && ptReviewSubTasks != NULL )
				{
					for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && rcode == ITK_ok; isubTaskIndx++  )
					{
						
						rcode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
						if( rcode == ITK_ok && pcSubTaskType != NULL && 
							(tc_strcmp(pcSubTaskType, "EPMPerformSignoffTask") == 0) )
						{
							rcode = EPM_ask_description(ptReviewSubTasks[isubTaskIndx],(char*)description);
							break;
						}
						MEM_free(pcSubTaskType);
					}
					MEM_free(ptReviewSubTasks);
				}				
			}
			else
			{
				rcode = EPM_ask_description(attrs->tNextTask,(char*)description);
			}
			
			if(pcTaskTypeName != NULL)
			{
				MEM_free(pcTaskTypeName);
			}
		}
		else
		{
			rcode = EPM_ask_description(the_task,(char*)description);
		}
   
        if ( (rcode == ITK_ok) && (description[0] != 0) )
        {
             fprintf(mail_file, "%s %s\n\n",desc_string,description);
        }
        else
        {
             fprintf(mail_file, "%s %s\n\n", desc_string,"None");
        }

        TC_free_text(desc_string);
    }

    /* -- Attachmetns -- */
    
    if ( rcode == ITK_ok )
    {
        rcode = EPM_ask_root_task( job, &root_task );
    }

    if( rcode == ITK_ok && root_task != NULLTAG)
    {
        rcode = EPM_ask_attachments( root_task, EPM_target_attachment,
                                     &target_count, &target_objects 
                                    );
    }

    if ( rcode == ITK_ok && root_task != NULLTAG)
    {
        rcode = EPM_ask_attachments( root_task, EPM_reference_attachment,
                                     &reference_count, &reference_objects );
    }

    /* write Attachemts    Name    Type */ 
    if(rcode == ITK_ok )
    {
         /* print Attachement     Name        Type */
         {
             char * sz_attachment_title_1 =  0;
        
             msg_name = "Attachment_Title_1";
             sz_attachment_title_1 =  txt_noSubText(the_text_server,msg_name,(int)true);
    
             fprintf( mail_file,"%s\n",sz_attachment_title_1);
             TC_free_text(sz_attachment_title_1);
         }
    
         /* print ------------     ---------------------------- ---------------------*/
        {
             char * sz_attachment_title_2 =  0;
        
             msg_name = "Attachment_Title_2";
             sz_attachment_title_2 =  txt_noSubText(the_text_server,msg_name,(int)true);
    
             fprintf( mail_file, "%s\n",sz_attachment_title_2);
             TC_free_text(sz_attachment_title_2);
        }
    
        /* print Target : */
        {
             char * sz_target_attachment =  0;
        
             msg_name = "Target_Attachment";
             sz_target_attachment =  txt_noSubText(the_text_server,msg_name,(int)true);
    
             fprintf( mail_file, "    %s\n",sz_target_attachment);
             TC_free_text(sz_target_attachment);
         }
    }

    /* write target object names and objects types */
    for ( ctr = 0; ctr < target_count && rcode == ITK_ok; ctr++ )
    {
       rcode = print_target_attachment_name_and_type(target_objects[ctr],&mail_file);
    }

    if( rcode == ITK_ok )
    {
         /* print Reference : */
         char * sz_reference_attachment =  0;
    
         msg_name = "Reference_Attachment";
         sz_reference_attachment =  txt_noSubText(the_text_server,msg_name,(int)true);
    
         fprintf( mail_file, "    %s\n",sz_reference_attachment);
         TC_free_text(sz_reference_attachment);
    }

    /* write reference object names and objects types*/
    for ( ctr = 0; ctr < reference_count && rcode == ITK_ok; ctr++ )
    {
         rcode = print_target_attachment_name_and_type(reference_objects[ctr],&mail_file);
    }

    /* write attachment end line.. */
    if(rcode == ITK_ok )
    {
         /* print ----------------------------------------------------------------------- */
         char * sz_attachment_title_3 =  0;
    
         msg_name = "Attachment_Title_3";
         sz_attachment_title_3 =  txt_noSubText(the_text_server,msg_name,(int)true);
    
         fprintf( mail_file, "%s\n",sz_attachment_title_3);
         TC_free_text(sz_attachment_title_3);
    }

    /* release text server object here...*/
    txt_destructor(the_text_server);

    return ( rcode );
}

/*---------------------------------------------------------------------------*/
static int write_release_level( tag_t job,                   /* <I> */
                               const char *rel_lev_name,      /* <I> */
                               FILE *mail_file                /* <I> */
                               )
/*
 *  description: this function will get all the decision data for the given
 *               release level and write them out to a file.
 *
 *
 */
{
    int rcode = ITK_ok;
    int reviewer_ctr = 0;
    int ctr;
    tag_t *groupmembers = NULL;
    char user_name[SA_user_size_c +1];
    CR_signoff_decision_t decision = CR_no_decision;
    char comments[CR_comment_size_c + 1];
    char date_string[SIZE_OF_DATE_STRING +1];
    char decision_str[DECISION_SIZE +1];
    date_t decision_date = NULLDATE;
    tag_t user_tag;
    tag_t classId;
    char *class_name;
    char *prop_name = 0;

    fprintf( mail_file, HEADER_FORMAT, RELEASE_LEV_STR, rel_lev_name );
    fprintf( mail_file, REL_HEADER_STR );
    fprintf( mail_file, REPORT_SEPARATOR2 );



    rcode = CR_ask_reviewers( job, rel_lev_name, &reviewer_ctr,
                              &groupmembers
                              );


    for ( ctr = 0; rcode == ITK_ok && ctr < reviewer_ctr; ctr++ )
    {
        /* 4655853: When the reviewer is a resourcepool, then use the rp tag,
           else use the user tag from the groupmember tag to get the decision
         */
        if ((rcode = POM_class_of_instance( groupmembers[ctr], &classId )) != POM_ok)
        {
            return rcode;
        }
        if ( (rcode = POM_name_of_class (classId, &class_name)) != POM_ok)
        {
            return rcode;
        }

        user_tag = NULLTAG;

        if (tc_strcmp(class_name, GROUPMEMBER_CLASS_NAME) == 0)
        {
            rcode = SA_ask_groupmember_user( groupmembers[ctr], &user_tag );
            if ( rcode == ITK_ok )
            {
                rcode = SA_ask_user_identifier( user_tag, user_name );
            }
        }
        else if (tc_strcmp(class_name, RESOURCEPOOL_CLASS_NAME) == 0)
        {        
            if ( (rcode = EPM_get_resource_pool_name(groupmembers[ctr], &prop_name )) == ITK_ok 
                && prop_name != 0)
            {
                tc_strcpy(user_name, prop_name);
            }

            user_tag = groupmembers[ctr];
        }
        if ( rcode == ITK_ok && user_tag != NULLTAG)
        {
            rcode = CR_ask_decision( job, rel_lev_name, user_tag,
                                     &decision, comments, &decision_date
                                     );
        }

        if ( rcode == ITK_ok )
        {
            date_string[0] = 0;
       
            rcode = get_formated_date_string(decision_date,date_string);
            
            switch ( decision )
            {
              case CR_approve_decision:
                tc_strcpy( decision_str, APPROVE_STR );
                break;
              case CR_reject_decision:
                tc_strcpy( decision_str, REJECT_STR );
                break;
              case CR_no_decision:
                tc_strcpy( decision_str, NO_DECISION );
                break;
              default:
                rcode = CR_invalid_decision;
            }

            fprintf( mail_file, REL_REC_FORMAT, user_name, decision_str,
                    date_string, comments
                    );
        }
    }

    return ( rcode );
}

/*---------------------------------------------------------------------------*/

static int write_report( tag_t task_tag,              /* <I> */
                           int levels,              /* <I> */
                           FILE *mail_file,         /* <I> */
                           char *user_content,      /* <I> */
                           report_e report_type,     /* <I> */
            mail_attributes_t *attrs   /* <I> */
                        )
/*
 *  description: this function will call cr_write_header and call
 *               the function cr_write_release_level once or up to the
 *               number of release levels depending on what the value of
 *               levels is passed.
 *
 *
 */
{
    int rcode = ITK_ok;
    int release_lev_ctr = 0;
    int ctr;
    char current_release_level[WSO_name_size_c + 1];
    tag_t job = NULL_TAG;
    tag_t* review_tasks = 0;
    char review_task_name[WSO_name_size_c+1];

    rcode = EPM_ask_job( task_tag, &job );
    if( rcode!=ITK_ok )
        return rcode;

    rcode = EPM_ask_review_task_name( task_tag, current_release_level );

    if ( rcode == ITK_ok )
    {
        rcode = write_header( job, task_tag , current_release_level, mail_file ,attrs);
    }

    if ( rcode == ITK_ok )
    {
        if ( report_type == level )
        {
            rcode = write_release_level( job, current_release_level,
                                            mail_file
                                            );
        }
        else if ( report_type == rejection || report_type == progress )
        {
            /***
            rcode = CR_ask_release_levels( job, &release_lev_ctr,
                                           &release_levels
                                           );
            ***/
            rcode = EPM_get_type_tasks( job, eEPMReviewTask, &release_lev_ctr, &review_tasks );
        }
    }


    for ( ctr = 0; rcode == ITK_ok && ctr < release_lev_ctr &&
         report_type != review ; ctr++
         )
    {
        rcode = EPM_ask_name( review_tasks[ctr], review_task_name );

        if( rcode==ITK_ok )
        {
            rcode = write_release_level( job, review_task_name,
                                        mail_file
                                        );
        }
    }

    MEM_free( review_tasks );
    return ( rcode );
}


/*---------------------------------------------------------------------------*/

static int get_notify_arguments( EPM_action_message_t msg,         /* <I> */
                                   counted_tag_list_t *recipients,     /* <OF> */
                                   counted_list_t *mail_addresses,     /* <OF> */
                                   mail_attributes_t * attrs       /* <O> */ 
                                   )
/*
 *  description: this function will parse the arguments passed to the
 *               handler and return the recipients in an array of strings,
 *               the user-specified subject in a string and the user
 *               specified content in a string.
 */
{
    int rcode = ITK_ok;
    int arg_cnt;
    int cntr;
    char *arg = NULL;
    char *flag = NULL;         /* MEM_free this */
    char *value = NULL;        /* MEM_free this */
    char *normal_value = NULL; /* MEM_free this */
    const char *SEP_DEFAULT = ",";
    char * sep = NULL; 
    int pref_count = 0;
    TC_preference_search_scope_t old_scope;
	
	int iCurrentTaskFlag = 1;
	int iOtherTaskFlag = 0;
	tag_t tRootTask = NULLTAG;
	char *pcTaskName = NULL;
	tag_t tSubTask = NULLTAG;
	char *pcRecipientValue = NULL;
	counted_tag_list_t tempList;
    /* store the $RESOURCE_POOL_ARG and process it as last argument*/
    //char szResourcePoolArg[ MAX_RES_POOL_ARG_SIZE ];
    logical res_pool_found = false;
    char szResourcePoolArg[ 60 ];
    szResourcePoolArg[0] = 0;   

	tempList.count = 0;
	tempList.list = (tag_t *)MEM_alloc( INIT_LIST_SIZE * (sizeof(tag_t)) );

    arg_cnt = TC_number_of_arguments( msg.arguments );

    if ( arg_cnt <= 0 )
    {
        rcode = EPM_missing_req_arg;
    }

    if ( rcode == ITK_ok )
    {
        rcode = EPM_setup_parser( msg.task );
    }
    
    rcode = PREF_initialize();
    if( rcode == ITK_ok )
    {
        rcode = PREF_ask_search_scope( &old_scope);
    }
    if( rcode == ITK_ok )
    {
        rcode = PREF_set_search_scope( TC_preference_site );
    }
    if( rcode == ITK_ok )
    {
        rcode = PREF_ask_value_count( "EPM_ARG_target_user_group_list_separator", &pref_count );
    }

    if( (rcode == ITK_ok) && pref_count != 0 )
    {
        rcode = PREF_ask_char_value( "EPM_ARG_target_user_group_list_separator", 0, &sep ); 
    }
    if (rcode == ITK_ok && (0 == sep || (0 != sep && tc_strlen(sep) < 1 ) ))
    {
        sep = (char *) MEM_alloc((int)tc_strlen(SEP_DEFAULT) + 1);
        tc_strcpy(sep, SEP_DEFAULT);
    }

    /* loop through the arguments and extract the options */

    for ( cntr = 1; cntr <= arg_cnt && rcode == ITK_ok; cntr++ )
    {
        arg = TC_next_argument( msg.arguments );

        rcode = ITK_ask_argument_named_value( (const char*)arg,
                                              &flag, &value
                                              );
        if ( rcode == ITK_ok )
        {
            if (value)
            {
                rcode = EPM_substitute_keyword( value, &normal_value );
            }
            else
            {
            TC_write_syslog ("File %s; Line # %d; given null value for %s", __FILE__, __LINE__, flag);
                value = (char*)MEM_alloc ((int) tc_strlen ( ERROR_MSG ) + 1 );
                tc_strcpy ( value, ERROR_MSG );
            }
        }
        if ( rcode == ITK_ok )
        {
			if (tc_strcmp( "sendMailTo",flag ) == 0)
			{
				if (tc_strcmp( "currentTask",value ) == 0)
				{
					iCurrentTaskFlag = 1;
					iOtherTaskFlag = 0;
				}
				else if (tc_strcmp( "otherTask",value ) == 0)
				{
					iCurrentTaskFlag = 0;
					iOtherTaskFlag =1;
				}
				else if (tc_strcmp( "both",value ) == 0)
				{
					iCurrentTaskFlag = 1;
					iOtherTaskFlag = 1;
				}
				else 
				{
					 rcode = EPM_invalid_argument_value ;
				}
			}
			else if (tc_strcmp( "taskName",flag ) == 0)
			{
				if( value!= NULL)
				{
					pcTaskName = (char*) MEM_alloc(( (int)tc_strlen(value) + 1) * sizeof(char));
					tc_strcpy( pcTaskName, value);
					
					attrs->nextTaskName = (char *) MEM_alloc((int) tc_strlen( value ) + 1 );
					if ( attrs->nextTaskName != NULL )
					{
						tc_strcpy( attrs->nextTaskName, value );
					}
				}
			}
            else if ( tc_strcmp( "recipient", flag ) == 0 )
            { 
				pcRecipientValue = (char*) MEM_alloc(((int) tc_strlen(value) + 1) * sizeof(char));
				tc_strcpy( pcRecipientValue, value);
            }
            else if ( tc_strcmp( "subject", flag ) == 0 )
            {
                /* subject switch detected */

                attrs->subject = (char *) MEM_alloc( (int)tc_strlen( normal_value )
                                                    + 1 );
                if ( attrs->subject != NULL )
                {
                    tc_strcpy( attrs->subject, normal_value );
                }
                else
                {
                    rcode = SS_NOMEM;
                }
            }
            else if ( tc_strcmp( "report", flag ) == 0 )
            {
                /* report switch detected */
                if ( tc_strcmp( normal_value, "progress" ) == 0 )
                {
                    attrs->report_type = progress;
                }
                else if ( tc_strcmp( normal_value, "level" ) == 0 )
                {
                    attrs->report_type = level;
                }
                else if ( tc_strcmp( normal_value, "review" ) == 0 )
                {
                    attrs->report_type = review;
                }
                else if ( tc_strcmp( normal_value, "rejection" ) == 0 )
                {
                    attrs->report_type = rejection;
                }
                else
                {
                    rcode = EPM_invalid_argument;
                }
            }
            else if ( tc_strcmp( "comments", flag ) == 0 )
            {
                /* comments switch detected */
                attrs->contents = (char *) MEM_alloc((int) tc_strlen( normal_value )
                                                    + 2 );
                if ( attrs->contents != NULL )
                {
                    tc_strcpy( attrs->contents, normal_value );
                }
                else
                {
                    rcode = SS_NOMEM;
                }
            }
            else if ( tc_strcmp ("url", flag) == 0 )
            {
                attrs->url = true;

                if( normal_value != 0 )
                {  
                    if ( tc_strcmp(FLAG_RICH, normal_value) == 0 )
                    {
                        attrs->rich_url = true;
                    }
                    else if ( tc_strcmp(FLAG_DHTML, normal_value) == 0 )
                    {
                        attrs->dhtml_url = true;
                    }
                    else if ( tc_strcmp(FLAG_HTML , normal_value ) == 0 )
                    {
                        attrs->html_url = true;
                    }
                }
                else
                {
                    /* ahujak : value will be NULL when "-url" does not have any value */   
                    attrs->rich_url  = true;
                    attrs->dhtml_url = true;
                    attrs->html_url  = true;
                }
            } /* --end URL */
            else
            {
                TC_write_syslog ("File: %s; Line # %d; CR_notify -- given bad argument %s\n", __FILE__, __LINE__, flag);
                rcode = EPM_invalid_argument;
            }
        }

        SAFE_SM_FREE( flag );
        SAFE_SM_FREE( value );
        SAFE_SM_FREE( normal_value );

    }/* end of for loop */

    
	//generate the recipient list by the "-recipient", "-sendMailTo" and "-taskName" argument value 
	if(rcode == ITK_ok)
	{
		if(iCurrentTaskFlag == 1)
		{
			/* recipient switch detected */
            char *data_type = NULL;
            char *add_value = NULL;

            char ** receipt_values = NULL;
            int receipt_count     = 0;
            int ii = 0; 

            EPM__parse_string( pcRecipientValue, sep , &receipt_count, &receipt_values );
            
            for(ii = 0 ; ii < receipt_count ; ii++ )
            {
                EPM__ask_data_type_and_value( receipt_values[ii], &data_type, &add_value );
                
                /* if value is $RESOURCE_POOL_ARG then store it, this will be processed as last argument.*/
                if( (res_pool_found == false ) && (res_pool_found = isResourcePoolArg(receipt_values[ii])) == true )
                {
                    tc_strcpy(szResourcePoolArg,receipt_values[ii]);
    
                    /* EPM__ask_data_type_and_value() returns error code "33020" EPM_invalid_argument.
                    * this error is not stored on ERROR stack, just ignore the error 
                    */ 
                    if( rcode == EPM_invalid_argument )
                    {
                        rcode = ITK_ok;  
                    }
        
                    continue;
                }
                if( tc_strcmp( data_type , ALIST_CLASS_NAME ) == 0 ) 
                {
                    /* Process AliasList and store individual user names */
                    tag_t alist = NULLTAG;

                    rcode = MAIL_find_alias_list( (const char *)add_value, &alist );
                    if ( rcode == ITK_ok )
                    {
                        if ( alist != null_tag )
                        {
                            rcode = process_aliaslist_recipient(alist,recipients,mail_addresses );
                        }
                        else
                        {
                            rcode = WSOUIF_object_not_found;
                        }
                    }
                }
                else
                {
                    /*<jiho> April 16, 2001 pass original value to ask_os_address()*/
                    /* call to ask_os_address will convert any Token to the users mail addresses
                    * but it will not convert Resource Pool assignments, that�s taken care in another
                    * call later on
                    */

                    rcode = ask_os_address( (const char *)receipt_values[ii], msg.task, recipients,mail_addresses );
                }
                SAFE_SM_FREE( data_type );
                SAFE_SM_FREE( add_value );
            }
            for (ii = 0; ii < receipt_count; ii++)
            {
                SAFE_SM_FREE(receipt_values[ii]);   
            }
            SAFE_SM_FREE(receipt_values);
			/* if no recipient argument resulted in mail addresses then the default behavior is 
			* to notify the tasks reviewers
			*/
			if ( (rcode == ITK_ok) && (recipients!= 0 && recipients->count == 0 ) )
			{
				rcode = add_recipients_for_token( msg.task, "$REVIEWERS" ,recipients );
			}
			/* check to see if any $RESOURCE_POOL_ARG was supplied as recipient*/
			if( szResourcePoolArg[0] != 0)
			{
				/* If a resource pool token was used then convert the Resource Pool 
				* Assignments to users mail addresses, taking into account the other    
				* Token�s used in the handler argument list
				*/

				rcode = add_recipients_for_token(msg.task,(const char*)szResourcePoolArg,recipients); 
			} 
			/* if $RESOURCE_POOL_ARG was not supplied,add the recipients based on preference value */
			else
			{
				/* no resource pool token used then convert ResourcePool assignments
				* to mail addresses based on site preference setting and other token�s
				* used in the handler argument list
				*/

				rcode = add_resource_pool_recipients_as_per_preference(msg.task,recipients);
			}

		}
		if(iOtherTaskFlag == 1 && pcTaskName != NULL)
		{ 
			tc_strcpy(szResourcePoolArg, "");

			rcode = EPM_ask_root_task(msg.task , &tRootTask);
			if(rcode == ITK_ok && tRootTask != NULLTAG && pcTaskName != NULL)
			{
				rcode = EPM_ask_sub_task  (  tRootTask, pcTaskName,&tSubTask);
			}
			if(rcode == ITK_ok && tSubTask != NULLTAG)
			{				
				/* recipient switch detected */
                char *data_type = NULL;
                char *add_value = NULL;

                char ** receipt_values = NULL;
                int receipt_count     = 0;
                int ii = 0; 
                EPM__parse_string( pcRecipientValue, sep , &receipt_count, &receipt_values );
                
				attrs->tNextTask = tSubTask;

                for(ii = 0 ; ii < receipt_count ; ii++ )
                {
                    EPM__ask_data_type_and_value( receipt_values[ii], &data_type, &add_value );
                    
                    /* if value is $RESOURCE_POOL_ARG then store it, this will be processed as last argument.*/
                    if( (res_pool_found == false ) && (res_pool_found = isResourcePoolArg(receipt_values[ii])) == true )
                    {
                        tc_strcpy(szResourcePoolArg,receipt_values[ii]);
        
                        /* EPM__ask_data_type_and_value() returns error code "33020" EPM_invalid_argument.
                        * this error is not stored on ERROR stack, just ignore the error 
                        */ 
                        if( rcode == EPM_invalid_argument )
                        {
                            rcode = ITK_ok;  
                        }
            
                        continue;
                    }
                    if( tc_strcmp( data_type , ALIST_CLASS_NAME ) == 0 ) 
                    {
                        /* Process AliasList and store individual user names */
                        tag_t alist = NULLTAG;
    
                        rcode = MAIL_find_alias_list( (const char *)add_value, &alist );
                        if ( rcode == ITK_ok )
                        {
                            if ( alist != null_tag )
                            {
                                rcode = process_aliaslist_recipient(alist,&tempList,mail_addresses );
                            }
                            else
                            {
                                rcode = WSOUIF_object_not_found;
                            }
                        }
                    }
                    else
                    {
                        /*<jiho> April 16, 2001 pass original value to ask_os_address()*/
                        /* call to ask_os_address will convert any Token to the users mail addresses
                        * but it will not convert Resource Pool assignments, that�s taken care in another
                        * call later on
                        */

                        rcode = ask_os_address( (const char *)receipt_values[ii], tSubTask, &tempList,mail_addresses );
                    }
                    SAFE_SM_FREE( data_type );
                    SAFE_SM_FREE( add_value );
                }
                for (ii = 0; ii < receipt_count; ii++)
                {
                    SAFE_SM_FREE(receipt_values[ii]);   
                }
                SAFE_SM_FREE(receipt_values);
				
				if ( (rcode == ITK_ok) && (tempList.count != 0 ) )
				{
					for (ii = 0; ii < tempList.count; ii++)
					{
						rcode = EPM__add_to_tag_list (tempList.list[ii],recipients);
					}
				}

				if ( (rcode == ITK_ok) && (tempList.count == 0 ) )
				{
					rcode = add_recipients_for_token( tSubTask, "$REVIEWERS" ,recipients );
				}
			}	
			SAFE_SM_FREE( pcRecipientValue );
			SAFE_SM_FREE( pcTaskName );
			SAFE_SM_FREE( tempList.list );

			/* check to see if any $RESOURCE_POOL_ARG was supplied as recipient*/
			if( szResourcePoolArg[0] != 0)
			{
				/* If a resource pool token was used then convert the Resource Pool 
				* Assignments to users mail addresses, taking into account the other    
				* Token�s used in the handler argument list
				*/
				if(tSubTask != NULLTAG)
				{
					rcode = add_recipients_for_token(tSubTask,(const char*)szResourcePoolArg,recipients); 
				}
			} 
			/* if $RESOURCE_POOL_ARG was not supplied,add the recipients based on preference value */
			else
			{
				/* no resource pool token used then convert ResourcePool assignments
				* to mail addresses based on site preference setting and other token�s
				* used in the handler argument list
				*/
				if(tSubTask != NULLTAG)
				{
					rcode = add_resource_pool_recipients_as_per_preference(tSubTask,recipients);
				}
			}

		}
	}

   
    MEM_free(sep);
    sep = 0;
    return ( rcode );
}

/*---------------------------------------------------------------------------*/
static int mail_send_os_mail( const char *subject,              /* <I> */
                              counted_list_t receiverList,      /* <I> */
                              const char *mail_file_name        /* <I> */
                     )
/*
 *  description: this function will send the mail through OS mail facility
*/
{

    int rcode = ITK_ok;
    int inx   = 0;
    char system_comm[BUFSIZ +1];
	int iFileOpen = 0;

    /* 4399740: Allow special characters in recipient field */

    TC_preference_search_scope_t old_scope = TC_preference_site;
    int pref_count = 0;
    char *server_name = NULL;
    char *charset = NULL;
    int mark, ifail;

    char *toListFileName = NULL;
    FILE *toListFile = NULL;
    char * address = NULL;
    mail_attributes_t attrs;
    
    /*
     *  <vlm 8/17/98> Use the mail gateway code to send the mail for NT.
     *  PR # 693685
     */
    system_comm[0] = '\0';
#if defined(WNT)
    tc_strcpy(system_comm, "%TC_BIN%\\tc_mail_smtp ");
#else
    tc_strcpy(system_comm, "$TC_BIN/tc_mail_smtp ");
#endif
     
    
    /* PR#5182626: Open a temp file for writing email address for -to_list_file= */
    toListFileName = USER_new_file_name("to_email_addresses","TEXT","dat",1);
    iFileOpen = fopen_s(&toListFile,toListFileName , "w" );


    if (toListFile == NULL)
    {
        rcode = CR_cannot_open_file;
    }
    else
    {
        /* write all email addresses from receiverList into new file */
        for (inx=0; inx<receiverList.count; ++inx)
        {
            address = receiverList.list[inx];
   
            if( address != 0 )
                fprintf( toListFile , "%s\n", address);

            /* ahujak : The memory is being freed in CR_notify function, do not free it here */
            /* MEM_free(address); */
        }

        if (receiverList.count > 0)
        {
            tc_strcat( system_comm, " -to_list_file=\"" );
            tc_strcat( system_comm, toListFileName );
            tc_strcat( system_comm, "\" " );
        }
        fclose(toListFile);
    }
    
    tc_strcat(system_comm, " -subject=");
    tc_strcat(system_comm, "\"");
    tc_strcat(system_comm, subject);
    tc_strcat(system_comm, "\" ");

    //PR#1319397 : If user has email address set in his/her "Person" record
    //             that email address should appear in "From" field.
    { 
       tag_t the_sender_tag = NULLTAG;
       tag_t the_sender_person = NULLTAG;
       char *the_sender_name = 0;
       char *the_sender_email_addr = 0;

       // get the current user name and user tag.
       ifail = POM_get_user(&the_sender_name,&the_sender_tag);
       if( ifail == ITK_ok )
       {
           // get the email address for current user.
           //ifail = EPM_get_user_email_addr( the_sender_tag,&the_sender_email_addr);
           //PR#5154023 : Issue where some SMTP servers cannot handle a "from" field which
           //             does not have a fully qualified email address. So, if the email
           //             address is explicitly spec'd in Person record then use it otherwise
           //             leave it blank (don't use the os name)
           ifail = SA_ask_user_person( the_sender_tag, &the_sender_person );
           if ( ifail == ITK_ok )
           {
               ifail = SA_ask_person_email_address( the_sender_person, &the_sender_email_addr );
               if((ifail == ITK_ok) && (the_sender_email_addr != 0) )
               {
                  tc_strcat(system_comm," -user=\"");
                  tc_strcat(system_comm,the_sender_email_addr);
                  tc_strcat(system_comm,"\" ");
               }
           }
        }
    
        MEM_free(the_sender_name);
        MEM_free(the_sender_email_addr) ;
    }

    EMH_set_protect_mark( &mark );

    /* check if any preferences are defined to specify the Mail server */
    ifail = PREF_initialize();
    if( ifail == ITK_ok )
    {
        ifail = PREF_ask_search_scope( &old_scope);
    }
    if( ifail == ITK_ok )
    {
        ifail = PREF_set_search_scope( TC_preference_site );
    }
    if( ifail == ITK_ok )
    {
        ifail = PREF_ask_value_count( "Mail_server_name", &pref_count );
    }

    if( (ifail == ITK_ok) && pref_count != 0 )
    {
        if( PREF_ask_char_value( "Mail_server_name", 0, &server_name ) == ITK_ok )
        {
            if (tc_strcmp (server_name, "your mail server machine") == 0)
            {
            TC_write_syslog ("File %s; Line # %d; Please set your Mail_server_name preference in your site preference file"
                              ,__FILE__, __LINE__);
                /* bash on just in case he really did mean that mail server name - not that I believe it */
            }
            tc_strcat(system_comm, "-server=" );
            tc_strcat(system_comm, "\"" );
            tc_strcat(system_comm, server_name );
            tc_strcat(system_comm, "\" " );
        }

        if( server_name != NULL )
        {
            MEM_free(server_name);
        }
    }

    pref_count = 0;
    if( ifail == ITK_ok )
    {
        PREF_ask_value_count( "Mail_server_charset", &pref_count );
    }
    if( (ifail == ITK_ok) && pref_count != 0 )
    {
        if( PREF_ask_char_value( "Mail_server_charset", 0, &charset ) == ITK_ok )
        {
            tc_strcat( system_comm, "-charset=" );
            tc_strcat( system_comm, "\"" );
            tc_strcat( system_comm, charset );
            tc_strcat( system_comm, "\" " );
        }
        else
        {
            tc_strcat( system_comm, "-charset=" );
            tc_strcat( system_comm, "\"ISO-8859-1\" " );
        }
        if( charset != NULL )
        {
            MEM_free( charset );
        }
    }
    else
    {
        tc_strcat( system_comm, "-charset=" );
        tc_strcat( system_comm, "\"ISO-8859-1\" " );
    }

    PREF_set_search_scope( old_scope );

    EMH_clear_errors();
    EMH_clear_protect_mark( mark );

    tc_strcat( system_comm, "-body=" );
    tc_strcat( system_comm, mail_file_name );
    tc_strcat( system_comm, " " );

    system( system_comm );

    /* delete temporary file here */
    remove( toListFileName );

    return( rcode );
}




/*---------------------------------------------------------------------------*/
/*
 *  description: this function will take a string value that can
 *               contain the data_type:value pair and resolve that into
 *               the os_address.
 */
static int ask_os_address( const char *value,             /* <I>  */
                   tag_t task,                            /* <I> */
                   counted_tag_list_t *recipients,        /* <OF> */
                   counted_list_t     *mail_addresses     /* <OF> */   
                   )
{
    int rcode = ITK_ok;
    char *data_type = NULL;                  /* MEM_free this */
    char *data_value = NULL;                 /* MEM_free this */
    char *normal_value = NULL;               /* MEM_free this */
    tag_t user_tag = null_tag;
    tag_t dlist = null_tag;
    tag_t value_tag = null_tag;

    /*<jiho> PR4169141 April 16, 2001 */
    if( value==NULL )
        return EPM_invalid_argument;

    if( value[0] == '$' )
    {
        int   count = 0;
        tag_t *resp_tags = 0;
        int   inx = 0;
   
        /* ahujak : call EPM_ask_recipients_for_token() here */
        rcode = EPM_ask_recipients_for_token(task,value,&count,&resp_tags);

        for( inx = 0;((inx < count) && ( rcode == ITK_ok)); inx++ )
        {
             if ( rcode == ITK_ok )
             {
                  rcode = EPM__add_to_tag_list( resp_tags[inx], recipients );
             }

        }

        MEM_free(resp_tags);
        resp_tags = 0;

        return rcode;
               
    }
    else
    {
        rcode = EPM_substitute_keyword( value, &normal_value );
        if( rcode!=ITK_ok )
            return rcode;

        rcode = EPM__ask_data_type_and_value( normal_value, &data_type,
            &data_value);
    }

    if ( rcode == ITK_ok )
    {
        if ( tc_strcmp( data_type, "OS" ) == 0 )
        {
            /* <Vilas> <19-July-2005
             * Remove const char* typecast for data_value
             */
            EPM_add_to_list(mail_addresses, data_value );
        }
        else if ( tc_strcmp( data_type, "Group" ) == 0 )
        {
            /* do the group thing */
            int nGroups;
            tag_t * groupTags;
            rcode = POM_find_h_groups( data_value, NULLTAG, &nGroups, &groupTags );
            if ( rcode == ITK_ok && nGroups > 0 )
            {
                int inx;
                for ( inx = 0; inx < nGroups; inx ++ )
                {
                    rcode = process_group_recipient( groupTags[inx], recipients );
                }
                MEM_free ( groupTags );
            }
        }
        else if ( tc_strcmp( data_type, "Role" ) == 0 )
        {
            /* do the role thing */
            if ( tc_strcmp( data_value, "$REVIEWERS" ) == 0 )
            {
                rcode = add_recipients_for_token( task, data_value,recipients );
            }
            else
            {
                rcode = process_role_recipient( data_value, recipients );
            }
        }
        else if(tc_strcmp( data_type, "RoleInGroup" ) == 0)
        {
            char ** strings = 0;
            int num_strings = 0; 
            char * groupName = 0;
            char * roleName  = 0; 
            tag_t * member_tags = 0;
            int num_of_members = 0;
            int ii = 0;
            EPM__parse_string((char*) data_value ,"::", &num_strings, &strings );
            if(num_strings == 2) 
            {
                groupName = strings[0];
                roleName  = strings[1];
                rcode = SA_find_groupmember_by_rolename(roleName, groupName, 0,  &num_of_members, &member_tags ); 
            }
            if (ITK_ok == rcode && num_of_members > 0)
            {
                int cntr = 0;
                for (cntr = 0; rcode == ITK_ok && cntr < num_of_members; cntr++)
                {
                    tag_t user_tag = NULLTAG;
                    rcode = SA_ask_groupmember_user(member_tags[cntr], &user_tag);
                
                    if (ITK_ok == rcode)
                    {
                         rcode = EPM__add_to_tag_list( user_tag , recipients );
                    }
                    else
                    {
                         rcode = SA_finding_user;
                    }
                }
            }
            MEM_free(member_tags);
            member_tags = 0;
            for (ii = 0; ii < num_strings; ii++)
            {
                MEM_free(strings[ii]);
                strings[ii] = 0;
            }
            MEM_free(strings);
            strings = 0;
        }
        else if ( tc_strcmp( data_type, DLIST_CLASS_NAME ) == 0 )
        {
            /* do the dl thing */
            rcode = MAIL_find_distribution_list( (const char *)data_value, &dlist );
            if ( rcode == ITK_ok )
            {
                if ( dlist != null_tag )
                {
                    rcode = process_dlist_recipient( dlist, recipients );
                }
                else
                {
                    rcode = WSOUIF_object_not_found;
                }
            }
            if ( rcode == WSOUIF_object_not_found )
            {   
                tag_t alist = NULLTAG;
    
                rcode = MAIL_find_alias_list( (const char *)data_value, &alist );
                if ( rcode == ITK_ok )
                {
                    if ( alist != null_tag )
                    {
                        rcode = process_aliaslist_recipient(alist,recipients, mail_addresses );
                    }
                    else
                    {
                        rcode = WSOUIF_object_not_found;
                    }
                }
            }
        }
        else if ( tc_strcmp( data_type, "User" ) == 0 )
        {
            /* do the user thing */
            rcode = SA_find_user( (const char *)data_value, &user_tag );
    
            if ( rcode == ITK_ok )
            {
                if ( user_tag != null_tag )
                {
                    rcode = EPM__add_to_tag_list( user_tag, recipients );
                }
                else
                {
                    rcode = SA_finding_user;
                }
            }
        }
        else if ( tc_strcmp( data_type, "Owner" ) == 0 )
        {
            rcode = get_property (task, "owning_user", &value_tag);
            if ( rcode == ITK_ok )
            {
                if ( value_tag != null_tag )
                {
                    rcode = EPM__add_to_tag_list( value_tag, recipients );
                }
                else
                {
                    rcode = SA_finding_user;
                }
            }
        }
        else if ( tc_strcmp( data_type, "Responsible_Party" ) == 0 )
        {
            rcode = get_property (task, "responsible_party", &value_tag);
            if ( rcode == ITK_ok )
            {
                if ( value_tag != null_tag )
                {
                    rcode = EPM__add_to_tag_list( value_tag, recipients );
                }
                else
                {
                    rcode = SA_finding_user;
                }
            }
        }
        else
        {
            rcode = EPM_invalid_argument;
        }
    }

    SAFE_SM_FREE( data_type );
    SAFE_SM_FREE( data_value );
    SAFE_SM_FREE( normal_value );

    return ( rcode );
}

/*---------------------------------------------------------------------------*/
static int process_group_recipient( tag_t group_tag,
                                    counted_tag_list_t *recipients
                                  )
     /* Description:
      *         This function takes a group name and loads the os_address array
      *         with the os addresses of each user in the specified group
      *
      */
{
    int rcode               = ITK_ok;
    int num_of_members      = 0;
    int cntr                = 0;
    tag_t user_tag          = null_tag;
    tag_t *groupmember_tag  = NULL;

    rcode = SA_find_groupmembers_by_group( group_tag,
                                           &num_of_members,
                                           &groupmember_tag
                                           );

    for ( cntr = 0; rcode == ITK_ok && cntr < num_of_members;
         cntr++
         )
    {
        rcode = SA_ask_groupmember_user( groupmember_tag[cntr],
                                         &user_tag
                                         );
        if ( rcode == ITK_ok )
        {
            rcode = EPM__add_to_tag_list( user_tag , recipients );
        }
    }

    SAFE_SM_FREE( groupmember_tag );

    return ( rcode );
}




/*---------------------------------------------------------------------------*/

static int process_groupmember_recipient( tag_t groupmember_tag,
                            counted_tag_list_t *recipients
                            )
     /* Description:
      *         This function takes a groupmember tag and loads the os_address array
      *         with the os address of the corresponding user.
      */
{
    int rcode        = ITK_ok;
    tag_t user_tag   = null_tag;

    rcode = SA_ask_groupmember_user( groupmember_tag,
                                     &user_tag
                                   );
    if ( rcode == ITK_ok )
    {
         rcode = EPM__add_to_tag_list( user_tag , recipients );
    }

    return ( rcode );
}

/*---------------------------------------------------------------------------*/
static int process_role_recipient( char *role_name,
                           counted_tag_list_t *recipients
                           )
     /* Description:
      *         This function takes a role name and loads the os_address array
      *         with the os addresses of each user in the specified role
      *
      */
{
    int rcode               = ITK_ok;
    int cntr                = 0;
    int num_of_groupmembers = 0;
    tag_t *groupmember_list = NULL;
    tag_t user_tag          = null_tag;


    rcode = SA_find_groupmember_by_rolename( role_name, NULL, NULL,
                                             &num_of_groupmembers,
                                             &groupmember_list
                                             );

    for ( cntr = 0; rcode == ITK_ok && cntr < num_of_groupmembers;
         cntr++
         )
    {
        rcode = SA_ask_groupmember_user( groupmember_list[cntr],
                                         &user_tag
                                         );
        if ( rcode == ITK_ok )
        {
            rcode = EPM__add_to_tag_list( user_tag, recipients );
        }
    }

    SAFE_SM_FREE( groupmember_list );

    return ( rcode );
}

/*---------------------------------------------------------------------------*/
static int process_aliaslist_recipient( tag_t alist,                 /* <I> */
                                        counted_tag_list_t *recipients, 
                                        counted_list_t * mail_addresses   /* <OF> */
                                      )
/*
 * Description:
 *         This function takes an alias list name, the alias list may contain
 *         AliasList names, TC user names, OS user names and Email IDs. 
 *         This function will create a list of Email IDs/OS names given an alias
 *         list.
 *
 * Parameters:
 *         alist <O>
 */
{
    int rcode = ITK_ok;
    int add_count = 0;
    char **tmp_add = NULL;

    rcode = MAIL_ask_alias_list_members( alist , &add_count , &tmp_add );
    
    if( rcode == ITK_ok )
    {
        int inx          = 0;


        for( inx = 0; inx < add_count ; inx++ )
        {

            // Check to see if this is an embedded alias list. If it is, then
            // recursively process it. If it isn't then add the name to the
            // recipient list.

            tag_t alist = NULLTAG;
            rcode = MAIL_find_alias_list( (const char *)tmp_add[inx], &alist );
            if (rcode== ITK_ok  &&  alist!=NULLTAG )
            {
                rcode = process_aliaslist_recipient(alist,recipients,mail_addresses);
            }
            else
            {
                // ahujak : The tmp_add could be a TC user, if its TCUser then
                // get the email id for TC user,
                // else assume it to be an OS user.
                tag_t the_user = NULLTAG;
                
                // lets see if tmp_add is a TC user...
                if( ((rcode = SA_find_user(tmp_add[inx],&the_user)) == ITK_ok)
                      && (the_user != NULLTAG) 
                  )
                {
                    rcode = EPM__add_to_tag_list( the_user,recipients );
                }
                
                // if not assume it to be an OS user/external Email ID..
                if( (the_user == NULLTAG) )
                {
                    rcode = EPM_add_to_list( mail_addresses, tmp_add[inx] );
                }
            }
            MEM_free( tmp_add[inx] );
        }
        SAFE_SM_FREE( tmp_add );
    }

    return rcode;

}

/*---------------------------------------------------------------------------*/
static int process_dlist_recipient( tag_t dlist,                  /* <I> */
                                   counted_tag_list_t *recipients        /* <OF> */
                                   )
     /* Description:
      *         This function takes a distribution list name and loads
      *         the os_address array with the os addresses of each user
      *         in the specified distribution list
      *
      */
{
    int rcode = ITK_ok;
    int members_count;
    int ictr;
    tag_t *members = NULL;
    tag_t class_id_of_inst = null_tag;
    static tag_t user_class_id = null_tag;
    static tag_t group_class_id = null_tag;
    static tag_t groupmember_class_id = null_tag;
    static tag_t dlist_class_id = null_tag;

    if ( user_class_id == null_tag )
    {
        rcode = POM_class_id_of_class( USER_CLASS_NAME, &user_class_id );
    }

    if ( (rcode == ITK_ok) && (group_class_id == null_tag) )
    {
        rcode = POM_class_id_of_class( GROUP_CLASS_NAME, &group_class_id );
    }

    if ( (rcode == ITK_ok) && (dlist_class_id == null_tag) )
    {
        rcode = POM_class_id_of_class( DLIST_CLASS_NAME, &dlist_class_id );
    }

    if ( (rcode == ITK_ok) && (groupmember_class_id == null_tag) )
    {
        rcode = POM_class_id_of_class( GROUPMEMBER_CLASS_NAME, &groupmember_class_id );
    }

    rcode = MAIL_ask_dist_list_members( dlist, &members_count, &members );

    for ( ictr = 0; (rcode == ITK_ok) && (ictr < members_count); ictr++ )
    {
        rcode = POM_class_of_instance( members[ictr], &class_id_of_inst );

        if ( (rcode == ITK_ok) && (class_id_of_inst != null_tag) )
        {
            char *class_name = NULL;
            rcode = POM_name_of_class( class_id_of_inst , &class_name );
            if ( class_id_of_inst == user_class_id )
            {
                rcode = EPM__add_to_tag_list( members[ictr], recipients );
            }
            else if ( class_id_of_inst == group_class_id )
            {
                rcode = process_group_recipient( members[ictr], recipients );
            }
            else if ( class_id_of_inst == groupmember_class_id )
            {
                /* <KARIM>I am adding groupmember loop to supprt Group member
                 * objects in the Distribution list.
                 */
                rcode = process_groupmember_recipient( members[ictr], recipients );
            }
            else if ( class_id_of_inst == dlist_class_id )
            {
                rcode = process_dlist_recipient( members[ictr], recipients );
            }
            else
            {
                rcode = POM_invalid_class_id;
            }
        }
    }

    SAFE_SM_FREE( members );

    return ( rcode );
}


/* This function returns the value corresponding to the property name */
static int get_property (tag_t task_tag, char *prop_name, tag_t *value)
{
    int retcode = ITK_ok;
    tag_t prop_tag = NULLTAG;
    retcode = PROP_ask_property_by_name( task_tag, prop_name, &prop_tag );
    if (retcode == ITK_ok && prop_tag != NULLTAG)
    {
        *value = NULLTAG;
        retcode = PROP_ask_value_tag( prop_tag, value );
    }
    return retcode;
}

/* ---------------------------------------------------------------- */

static char * get_address(const char *name, mail_attributes_t *attrs)
{
    tag_t user_tag   = NULLTAG;
    tag_t person_tag = NULLTAG;
    
    char * emailAddress = NULL;

    /* -- get user from name -- */
    
    int ifail = SA_find_user(name, &user_tag);

    if ( (ifail == ITK_ok) && (user_tag != NULLTAG) )
    {
        /* -- get person from user_tag -- */
        ifail = SA_ask_user_person( user_tag, &person_tag );
          
        /* get person's email address from person tag ..*/
   
        if( (ifail == ITK_ok) && (person_tag != NULLTAG) )
        {
             char *attribute_value = NULL; 
        
             ifail = SA_ask_person_email_address( person_tag, &attribute_value );

             if( (ifail == ITK_ok) && (attribute_value != NULL) )
             {
                  emailAddress = attribute_value;
                  return emailAddress;
             }
        }
   
        /* if you have come here, it means you did not get email address for person so get the os_user_name */
        
       {/* this is a dummy scope */
            char os_user_name[SA_name_size_c + 1];

            os_user_name[0] =0;
           
            ifail = SA_ask_os_user_name( user_tag, (char*)os_user_name);

            if( (ifail == ITK_ok) && (os_user_name[0] != 0) )
            {
                 emailAddress = (char*) MEM_alloc( sizeof(char) * ((int)tc_strlen(os_user_name)+1) );
                 tc_strcpy(emailAddress,os_user_name);
                 return emailAddress;
            }
        }
    }

    if ( user_tag == NULLTAG )
    {
        emailAddress = (char *)MEM_alloc(sizeof(char) * (int)tc_strlen(name) + 1 );
        tc_strcpy(emailAddress, name);
    }

    return emailAddress;
}

/* ----------------------------------------------------------------- */
static int askURLTypes(mail_attributes_t attrs,int *add_portal_url,
                       int *add_html_url,int *add_dhtml_url)
{
    //
    int rcode = ITK_ok;

    //If handler has url arg
    //Use url arg for urls to build(don't even bother asking for pref value)
    if( attrs.url == true )
    {
        if( attrs.rich_url == true )
        {
            *add_portal_url = true;
        }
        if( attrs.dhtml_url == true )
        {
            *add_dhtml_url   = true;
        }
        if( attrs.html_url == true )
        {
            *add_html_url  = true;
        }
   
        return rcode;
    }

    //Else if (url_pref set)
   //Use pref values for urls to build    
    {
    int        formatCount = 0;
    const char *Url_FormatPreference = "EPM_notify_url_format";
    char       **url_names = 0; // ahujak : I am not sure if we should free this
                                //          memory
    
    int theMarkpoint = 0;
    
    TC_preference_search_scope_t oldScope;
    PREF_ask_search_scope( &oldScope );
    PREF_set_search_scope( TC_preference_site );

    EMH_set_protect_mark( &theMarkpoint );

    rcode = PREF_ask_char_values(Url_FormatPreference, &formatCount, &url_names);

    if( rcode != ITK_ok )
    {
        rcode = ITK_ok;
        EMH_clear_errors();   
    }

    EMH_clear_protect_mark( theMarkpoint );
    
    PREF_set_search_scope( oldScope );

    if( (formatCount > 0) && (url_names != 0) )
    {
        int inx;

        for(inx = 0; inx< formatCount; inx++ )
        {
            if( ( (url_names)[inx] != 0 ) )
            {

                if( tc_strcmp( ((url_names)[inx]), FLAG_RICH ) == 0 )
                {
                     *add_portal_url = true;
                     continue;
                }
                if( tc_strcmp( ((url_names)[inx]), FLAG_HTML ) == 0 )
                {
                     *add_html_url = true;
                     continue;
                }
                if( tc_strcmp( ((url_names)[inx]), FLAG_DHTML ) == 0 )
                {
                     *add_dhtml_url = true;
                     continue;
                }
             }
         }
        
        MEM_free(url_names);
        
        return rcode;
    }
    }
    
    //Else
    //   Add dhtml url and portal url (default)
    *add_dhtml_url = true;
    *add_portal_url = true;
    return rcode;

}

/*----------------------------------------------------------------------------------*/

static int get_formated_date_string(date_t the_date, char date_string[SIZE_OF_DATE_STRING+1])
{
    int rcode = ITK_ok;
    
    char *the_day   = 0;    /* MEM_free(the_day) must be called */
    char *the_month = 0;    /* MEM_free(the_month) must be called */
    char *the_year  = 0;    /* MEM_free(the_year) must be called */

    char *the_month_names[] = {"Jan","Feb","Mar","Apr","May","Jun",
                                   "Jul","Aug","Sep","Oct","Nov","Dec"};

    /* initialize date_string */
    date_string[0] = 0;
               
    /* -- get Day -- */
    if( the_date.day != 0)
    {
        rcode = DATE_date_to_string(the_date,"%d",&the_day);
    }
   
    /* -- get Month -- */
    if( (rcode == ITK_ok) && ( (the_date.month >= 0) && (the_date.month < 12) ) )
    {
        char month_msg_name[32] = "Month_";
        txt_t the_txt_server = 0;

        the_txt_server = txt_ctor("tc_text.xml");
    
        if(the_txt_server !=0 )
        {    
            tc_strcat( month_msg_name , the_month_names[ the_date.month ] );
            the_month = txt_noSubText(the_txt_server,(char*)month_msg_name,true);
        }
         
        txt_destructor(the_txt_server);
 
    }

    /* -- get Year -- */
    if((rcode == ITK_ok) && (the_date.year != 0))
    {
        rcode = DATE_date_to_string(the_date,"%Y",&the_year); 
    }

    if( (rcode == ITK_ok) && ( the_day !=0 ) &&( the_month !=0 ) && ( the_year !=0 ))
    {
        TI_sprintf(date_string,"%.2s-%.3s-%.4s",the_day,the_month,the_year);

        MEM_free(the_day); 
        MEM_free(the_month); 
        MEM_free(the_year); 
    }

    return rcode; 
}

/*
 * ahujak :
 * This function will print target name and target type to mailFile,
 *  target Item should be printed as "item_id-item_name" eg : "000015-myItem"
 *  and ItemRevision should appear as "item_id/item_rev_id-item_name" eg "000015/D-myNewItem"
 */

static int print_target_attachment_name_and_type( tag_t wso_object,FILE **mail_file )
{

   int rcode = ITK_ok;

   char target_name[WSO_name_size_c + 1];
   char target_type[WSO_name_size_c + 1];

   target_name[0] = 0;
   target_type[0] = 0;
   
   rcode = WSOM_ask_name( wso_object , target_name );

   if ( (rcode == ITK_ok) && (target_name[0] != 0) )
   {
       rcode = WSOM_ask_object_type( wso_object, target_type );
   }
                     
   if( (rcode == ITK_ok) && (target_type[0] != 0) )
   {
       /* ahujak : if its an ItemRevision or Item the add Id with the name.*/
       if( tc_strcmp( target_type,"ItemRevision") == 0 )
       {
           // find the Item for ItemRevision.
           tag_t the_item = 0; 
                            
           char item_id[ ITEM_id_size_c+1 ];
           char item_rev_id[ ITEM_id_size_c +1 ];
           char the_target_name[ ITEM_id_size_c + ITEM_name_size_c + ITEM_id_size_c +1 ];
                            
           item_id[0] = 0;
           item_rev_id[0] =0;
           the_target_name[0] = 0;
             
           rcode = ITEM_ask_item_of_rev( wso_object , &the_item );
             
           // find the Item_Id for the Item. 
           if( (rcode == ITK_ok) && (the_item != 0) )
           {
               rcode = ITEM_ask_id( the_item , (char*)item_id ); 
           }
          
           // find the Item_revision_id for ItemRevision
           if( rcode == ITK_ok )
           {
               rcode = ITEM_ask_rev_id( wso_object , (char*)item_rev_id);
           }                
         
           // add all strings to create ItemRevision Name.
           if( (rcode == ITK_ok) && (item_id[0] != 0) && (item_rev_id[0] != 0))
           {
               tc_strcpy(the_target_name,item_id);
               tc_strcat(the_target_name,"/");
               tc_strcat(the_target_name,item_rev_id);
               tc_strcat(the_target_name,"-");
           }
             
           tc_strcat(the_target_name,target_name);
             
           fprintf(*mail_file, "                   %-32s %-32s\n",the_target_name,target_type);
       }
       else if( tc_strcmp( target_type,"Item") == 0 )
       {
           char item_id[ ITEM_id_size_c+1 ];
           char the_target_name[ ITEM_id_size_c + ITEM_name_size_c + 1 ];
            
           item_id[0] = 0;
           the_target_name[0] = 0;
             
           // find Item_Id for Item
           rcode = ITEM_ask_id( wso_object , (char*)item_id ); 
             
           // add "Item_Id" and Item_Name
           if( (rcode == ITK_ok) && (item_id[0] != 0) )
           {
               tc_strcpy(the_target_name,item_id);
               tc_strcat(the_target_name,"-");
           }
                            
           tc_strcat(the_target_name,target_name);
             
           fprintf(*mail_file, "                   %-32s %-32s\n",the_target_name,target_type);
            
       } 
       else
       {
           fprintf(*mail_file, "                   %-32s %-32s\n",target_name,target_type);
       }
   }

   return ITK_ok;
}

/*-------------------------------------------------------------------*/
/* This function will read the value of preference 
 * and select the recipients from resource pool depending upon the value of preference.
 */
int add_resource_pool_recipients_as_per_preference ( tag_t task, counted_tag_list_t *recipients)
{
    int errorCode = ITK_ok;

    int    res_count = 0;
    tag_t  *res_tags = 0;     /* needs MEM_free() */

    /* get the resource pool recipients if not already added using $RESOURCE_POOL_XYZ*/
    errorCode = EPM_add_resource_pool_recipients_for_preference(task,&res_count,&res_tags);
       
    if((errorCode == ITK_ok) && (res_tags != 0))
    {
        int inx = 0;       

        for( inx = 0;((inx < res_count) && ( errorCode == ITK_ok)); inx++ )
        {
            if ( errorCode == ITK_ok )
            {
                errorCode = EPM__add_to_tag_list( res_tags[inx], recipients  );
            }

        } /* for */

       MEM_free(res_tags);
       res_tags = 0;

    } /* if (res_tags != 0) */
   
    return errorCode;
}

/*-------------------------------------------------------------------------------------*/

int add_recipients_for_token(tag_t task,const char* token,counted_tag_list_t *recipients)
{
    int rcode = ITK_ok;
    
    int   count = 0;
    tag_t *resp_tags = 0;
    int   inx = 0;
   
    /* ahujak : call EPM_ask_recipients_for_token() here */
    rcode = EPM_ask_recipients_for_token(task,token,&count,&resp_tags);

    for( inx = 0;((inx < count) && ( rcode == ITK_ok)); inx++ )
    {
        if ( rcode == ITK_ok )
        {
             rcode = EPM__add_to_tag_list( resp_tags[inx], recipients );
        }
    }

    MEM_free(resp_tags);

    return rcode;
}

/*-----------------------------------------------------------------------------------*/

logical isResourcePoolArg(const char *value)
{
    logical bResPoolFound = false;

    if( value != 0)
    {
        if(tc_strcmp(value,RESOURCE_POOL_ALL) == 0)
        {
             bResPoolFound = true;
        }
        else if(tc_strcmp(value,RESOURCE_POOL_NONE) == 0)
        {
             bResPoolFound = true;
        }
        else if(tc_strcmp(value,RESOURCE_POOL_SUBSCRIBED) == 0)
        {
             bResPoolFound = true;
        }
    }    

    return bResPoolFound;
}

void release_string_array( int count,  char **list  )
{
    int inx;

    if( list == 0 )
    {
         return;
    }
     
    for(inx = 0; inx < count ; inx++ )
    {
         SAFE_SM_FREE( list[inx] );
    }

    SAFE_SM_FREE(list);
    
    list = 0;
}
/*----------------------------------------------------------------------------------------------------*
 * This function will analyze the compatibility between report generation type and task action        *
 *                                                                                                    *
 *  Return Value : This funtion must return false ONLY when the report type in NOT AT ALL compatible  *
 *                 with the task action. In all other cases it must return true.                      *
 *----------------------------------------------------------------------------------------------------*/
static logical is_report_type_supported_for_action(report_e report_type,EPM_action_t the_action)
{
    logical ret_value = true;
     
    /********************************
     * If the report type is progess 
     ********************************/
    if( report_type == progress )
    {
        ret_value = false;
  
        /****************************
         * Then the action should be
         ****************************/
          
        /****************************
         * either EPM_approve_action
         ****************************/
        if( the_action == EPM_approve_action )
        {
            ret_value = true;
        }
        /***********************
         * or EPM_reject_action
         ***********************/
        else if( the_action == EPM_reject_action )
        {
            ret_value = true;
        }
        /**********************
         * or EPM_start_action
         **********************/
        else if( the_action == EPM_start_action )
        {
            ret_value = true;
        }
        /*************************
         * or EPM_complete_action
         *************************/
        else if( the_action == EPM_complete_action )  
        {
            ret_value = true;
        }
  
    } /* end "progress" */
    /* 4663872: if the report_type is rejection and the action is not
       EPM_reject_action or EPM_undo, don't send out a mail
     */
    /**********************************
     * If the report type is rejection
     * ********************************/
    else if( report_type == rejection )
    {
        ret_value = false;

        /****************************
         * Then the action should be
         ****************************/
 
        /****************************
         * either EPM_reject_action
         ****************************/
        if(the_action == EPM_reject_action)
        {
            ret_value = true;
        }
        /********************
         * or EPM_undo_action
         *********************/
        else if( the_action == EPM_undo_action )
        {
            ret_value = true;
        }

    } /* end rejection */
    

     return ret_value;
}
















