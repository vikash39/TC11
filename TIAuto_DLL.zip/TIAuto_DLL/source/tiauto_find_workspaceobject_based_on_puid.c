/*******************************************************************************************************************
File         : find_WorkSpaceObject.c

Description  : These are functions related to the user query - "TIWorkspaceObject"
			   This function will search for all Workspace objects based on puid.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
7 Jun 2017		1.0			Shilpa				Initial Creation   
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		TIAUTO_Find_WorkspaceObjectQuery (const char* pcobjpuid,int *iNumFound,tag_t **ptfoundTags /*<OF num_found> 

*return int	

pcobjpuid-puid from query input (I)
inum_found- number of result from pom query(O)
ptfoundTags - tags returned from pom query(O)

* Description:
*			Implementation of logic for the "Find Objects Based On UIDs" user query.
================================================================================================================*/
extern int TIAUTO_Find_WorkspaceObjectQuery (const char* pcobjpuid,int *iNumFound,tag_t **ptfoundTags)
{
	int				iFail					= ITK_ok;
	const char		*select_attr_list1[]	= {"puid"};
	int				iRows					= 0;
	int				iLoopRows				= 0;
	int				iCols					= 0;
	void			***paReport;
	tag_t			tChItem					= NULLTAG;	
	tag_t			tObject					= NULLTAG;	
	
	TIAUTO_ITKCALL(iFail,POM_string_to_tag(pcobjpuid,&tObject));	

	if(iFail==ITK_ok)
	{
		//Create the main query
		TIAUTO_ITKCALL(iFail,POM_enquiry_create (TIAUTO_WORKSPACE_OBJECT_ENQ));
	}
	if(iFail==ITK_ok)
	{
		//select output attribute for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs (TIAUTO_WORKSPACE_OBJECT_ENQ, "WorkspaceObject", 1, select_attr_list1));
	}
	/*Object Tag*/
	if (tObject!= NULLTAG && iFail==ITK_ok) 
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_tag_value (TIAUTO_WORKSPACE_OBJECT_ENQ, "aunique_value_id1", 1, &tObject, POM_enquiry_bind_value ));		
	}
	if(iFail==ITK_ok)
	{
		//comparing puid with the input from query
		TIAUTO_ITKCALL(iFail,POM_enquiry_set_attr_expr (TIAUTO_WORKSPACE_OBJECT_ENQ,"auniqueExprId_1", "WorkspaceObject","puid",POM_enquiry_equal,"aunique_value_id1"));
	}
	if(iFail==ITK_ok)
	{
		//set where expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr (TIAUTO_WORKSPACE_OBJECT_ENQ,"auniqueExprId_1" ));
	}
	if(iFail==ITK_ok)
	{
		//set distinct value
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct(TIAUTO_WORKSPACE_OBJECT_ENQ, true));
	}
	if(iFail==ITK_ok)
	{
		//execute the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute (TIAUTO_WORKSPACE_OBJECT_ENQ,&iRows,&iCols,&paReport));
	}
	if(iFail==ITK_ok)
	{
		//delete the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete (TIAUTO_WORKSPACE_OBJECT_ENQ));
	}
	//process result	
	if(iRows > 0 && iFail==ITK_ok)
	{
		//allocate memory
		*ptfoundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(iLoopRows=0;iLoopRows<iRows;iLoopRows++)
		{			
			tChItem = NULLTAG;
			tChItem = *(tag_t *)paReport[iLoopRows][0];
			(*ptfoundTags)[iLoopRows] = tChItem;
		}
		SAFE_MEM_free(paReport);
	}

	if ( iFail != ITK_ok )
	{	
		char	*pcErrMsg			= NULL;
		EMH_ask_error_text (iFail, &pcErrMsg);
		TC_write_syslog(pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}

	return iFail;
}