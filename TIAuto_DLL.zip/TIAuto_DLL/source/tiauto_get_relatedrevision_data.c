
/*******************************************************************************
File         : tiauto_get_relatedrevision_data.c

Description  :	 

Input        : None

Output       : None

Author       : 

Revision History :
Date            Revision    Who					Description
Jun 11, 2019    1.0        Jugunu Vasu     Initial Creation

*******************************************************************************/

#include <tiauto_runtime_properties.h>
#include <tiauto_defines.h>
#include <sa/tcfile_cache.h>




extern int  Set_Property_3DData( METHOD_message_t *  message, va_list  args )
{
	int iRetCode = ITK_ok;
	int iCountUGParMaster =0;
	int iCountSec =0;
	int iCountSecUG =0;
	int iTotalPDFCnt =0;
	int iSecRuntime = 0;
	int iCountItemRev =0;

	tag_t tTypeTag = NULLTAG;
	tag_t objItemRevTag = NULLTAG;	
	tag_t tSpecificationRelation = NULLTAG;
	//tag_t tDrawingRelation = NULLTAG;	
	tag_t *ptSecUGPartMaster = NULL;
	tag_t *ptSecItemRev = NULL;


	tag_t prop_tag = va_arg(args, tag_t);
	int     *count = va_arg(args, int*);
	tag_t  **tags = va_arg(args, tag_t**);
	tag_t  tListPdf[50] ;//fixed size....	

	tag_t tDocProdRelation = NULLTAG;


	METHOD_PROP_MESSAGE_OBJECT(message, objItemRevTag);

	TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_REL_DocProd,&tDocProdRelation));
	//Get the relation Specificatin.
	TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (REL_IMAN_SPEC,&tSpecificationRelation)); 

	if( tDocProdRelation!= NULL)
	{
		TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(objItemRevTag,tDocProdRelation,&iCountItemRev,&ptSecItemRev));
		for( iCountSec =0; iCountSec<iCountItemRev ; iCountSec++)
		{
			char *cTypeClass =NULL;
			TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptSecItemRev[iCountSec],&tTypeTag));
			if(iRetCode == ITK_ok)   iRetCode = TCTYPE_ask_name2 (tTypeTag, &cTypeClass);	

			if( ( iRetCode == ITK_ok ) &&( (tc_strcasecmp(cTypeClass,ALTREP_REV) == 0) || (tc_strcasecmp(cTypeClass,ALTTOOL_REV) == 0) || (tc_strcasecmp(cTypeClass,ALTCONSTRUCT_REV) == 0) ))
			{
				TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(ptSecItemRev[iCountSec],tSpecificationRelation,&iCountUGParMaster,&ptSecUGPartMaster));
				for(iCountSecUG = 0; iCountSecUG <iCountUGParMaster; iCountSecUG++)
				{					
					tag_t tTypepdfTag = NULL;
					char *cName =NULL;
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptSecUGPartMaster[iCountSecUG],&tTypepdfTag));
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_name2(tTypepdfTag, &cName));

					if(( iRetCode == ITK_ok ) &&( ( (tc_strcasecmp(cName,TIAUTO_UGMASTER) == 0) || (tc_strcasecmp(cName,TIAUTO_CATPART) == 0) || (tc_strcasecmp(cName,TIAUTO_CATPRODUCT) == 0) || (tc_strcasecmp(cName,TIAUTO_CATIA) == 0) || 
						(tc_strcasecmp(cName,TIAUTO_IDEASPART) == 0) || (tc_strcasecmp(cName,TIAUTO_IDEASASSEBMLY) == 0) || (tc_strcasecmp(cName,TIAUTO_PROPRT) == 0) || (tc_strcasecmp(cName,TIAUTO_PROASM) == 0) 
						|| (tc_strcasecmp(cName,TIAUTO_SWPRT) == 0) || (tc_strcasecmp(cName,TIAUTO_SWASM) == 0) || (tc_strcasecmp(cName,TIAUTO_AIPART) == 0) || (tc_strcasecmp(cName,TIAUTO_AIASSEMBLY) == 0) || 
						(tc_strcasecmp(cName,TIAUTO_ACADDWG) == 0) || (tc_strcasecmp(cName,TIAUTO_AIDRAWING) == 0) || (tc_strcasecmp(cName,TIAUTO_CATDRAWING) == 0) || (tc_strcasecmp(cName,TIAUTO_IDEASDRW) == 0) 
						|| (tc_strcasecmp(cName,TIAUTO_PRODRW) == 0) || (tc_strcasecmp(cName,TIAUTO_UGPART) == 0) || (tc_strcasecmp(cName,TIAUTO_CATIA2D) == 0) || (tc_strcasecmp(cName,TIAUTO_SWDRW ) == 0)
						|| (tc_strcasecmp(cName,TIAUTO_DWG ) == 0) || (tc_strcasecmp(cName,TIAUTO_DXF ) == 0) || (tc_strcasecmp(cName,TIAUTO_CADKEY ) == 0))))
					{	
						{
							tListPdf[iTotalPDFCnt] = ptSecUGPartMaster[iCountSecUG];
							iTotalPDFCnt = iTotalPDFCnt + 1;

						}

					}


					if(cName != NULL)
					{
						MEM_free(cName);
					}

				}
				if(ptSecUGPartMaster != NULL)
				{
					MEM_free(ptSecUGPartMaster);
				}

			}

			if(cTypeClass != NULL)
			{
				MEM_free(cTypeClass);
			}


		}
		if(ptSecItemRev != NULL)
		{
			MEM_free(ptSecItemRev);
		}



	}

	*count = iTotalPDFCnt;
	//set the final string to the runtime property
	if(tListPdf != NULL)
	{
		*tags =(tag_t*) MEM_alloc(iTotalPDFCnt * sizeof(tag_t));

		for (iSecRuntime = 0; iSecRuntime < iTotalPDFCnt; iSecRuntime++)
		{
			(*tags)[iSecRuntime] = tListPdf[iSecRuntime];
		}
	}
	return(iRetCode);
}
