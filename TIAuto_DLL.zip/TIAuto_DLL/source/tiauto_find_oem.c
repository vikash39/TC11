/*******************************************************************************************************************
File         : find_OEM.c

Description  : These are functions related to the user query - "TI OEM Part"
			   This function will search for Change objects.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
13 Apr 2017		1.0			Kantesh				Initial Creation   
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		find_OEM(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the " TI OEM Parts" user query.
================================================================================================================*/
extern int find_OEM (const char* pcItemID,const char* pcName,const char* pcObjType,const char* pcProgramType,
					 const char* pcLaunchModelYear,const char* pcReleasedByChange,const char* pcCustomerName,
					 const char* pcCustomerReleaseNo,const char* pcOwningUser,const char* pcOwningGroup,
					 const char* pcOwningSite,const char* pcLastModUser,const char* pcCreatedAfter,
					 const char* pcCreatedBefore,const char* pcModifiedAfter,const char* pcModifiedBefore,
					 const char* pcReleasedAfter,const char* pcReleasedBefore,const char* pcReleaseStatus,
					 const char* pcCurrentTask,int *iNumFound,tag_t **foundTags)
{
	int				iFail 									= ITK_ok;
	int				iRows									= 0;
	int				index									= 0;
	int				iCols									= 0;
	tag_t			tOEMItem								= NULLTAG;
	const char		*select_attr_list1[] 					= {"puid"};
	const char		*pcRelationTypeName 					= IMAN_MASTER_FORM;
	const char		*pcItemType 							= _OEM;
	char 			*pcForm									= NULL;
	char  			*pcFormAttr_Program						= NULL;
	char  			*pcFormAttr_LaunchModelYear				= NULL;
	char  			*pcFormAttr_ReleasedByChange			= NULL;
	char  			*pcFormAttr_CustomerName				= NULL;
	char  			*pcFormAttr_CustomerReleaseNo			= NULL;
	date_t 			dCAD,dCBD,dMAD,dMBD,dRBD, dRAD 			= NULLDATE;
	void			***paReport;

	//copying revision master form attribute names
	if(pcForm == NULL)
	{
		pcForm = (char *)MEM_alloc(((int)tc_strlen(T1A2OEMREVMASTER) + 1)* sizeof(char));
		tc_strcpy(pcForm,T1A2OEMREVMASTER);
	}
	if(pcFormAttr_Program == NULL)
	{
		pcFormAttr_Program = (char *)MEM_alloc(((int)tc_strlen(T1A2PROGRAMARRAY) + 1)* sizeof(char));
		tc_strcpy(pcFormAttr_Program,T1A2PROGRAMARRAY);
	}
	if(pcFormAttr_LaunchModelYear == NULL)
	{
		pcFormAttr_LaunchModelYear = (char *)MEM_alloc(((int)tc_strlen(T1A2LAUNCHMODELYEAR) + 1)* sizeof(char));
		tc_strcpy(pcFormAttr_LaunchModelYear,T1A2LAUNCHMODELYEAR);
	}
	if(pcFormAttr_ReleasedByChange == NULL)
	{
		pcFormAttr_ReleasedByChange = (char *)MEM_alloc(((int)tc_strlen(T1A2RELEASEDBYCHANGE) + 1)* sizeof(char));
		tc_strcpy(pcFormAttr_ReleasedByChange,T1A2RELEASEDBYCHANGE);
	}
	if(pcFormAttr_CustomerName == NULL)
	{
		pcFormAttr_CustomerName = (char *)MEM_alloc(((int)tc_strlen(T1A2CUSTOMERNAME) + 1)* sizeof(char));
		tc_strcpy(pcFormAttr_CustomerName,T1A2CUSTOMERNAME);
	}
	if(pcFormAttr_CustomerReleaseNo == NULL)
	{
		pcFormAttr_CustomerReleaseNo = (char *)MEM_alloc(((int)tc_strlen(T1A2CUSTOMERRELEASENO) + 1)* sizeof(char));
		tc_strcpy(pcFormAttr_CustomerReleaseNo,T1A2CUSTOMERRELEASENO);
	}
	
	//Create the main query
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create ("Find_OEM"));
	}

	//select output attribute for main query
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_OEM", "Item", 1, select_attr_list1));
	}
	
	//create alias	
	if(iFail == 0)
	{	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "user", 1, "user_alias"));
	}
	if(iFail == 0)
	{		
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "ImanType", 1, "ImanType_alias1"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "ImanType", 1, "ImanType_alias2"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "ImanType", 1, "ImanType_alias3"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "WorkspaceObject", 1, "WorkspaceObject_alias1"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "WorkspaceObject", 1, "WorkspaceObject_alias2"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_OEM", "WorkspaceObject", 1, "WorkspaceObject_alias3"));
    }
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value   ("Find_OEM", "aunique_value_id1", 1, &pcRelationTypeName,POM_enquiry_bind_value));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value   ("Find_OEM", "aunique_value_id2", 1, &pcItemType,POM_enquiry_bind_value));
	}
	
	//start query expression for main query
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_2","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_4","ImanRelation","relation_type",POM_enquiry_equal,"ImanType_alias1","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_5","Item","puid",POM_enquiry_equal,"WorkspaceObject_alias1","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_6","ImanType_alias1","type_name", POM_enquiry_equal, "aunique_value_id1"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_7","Item","puid",POM_enquiry_equal,"WorkspaceObject_alias2","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_8","WorkspaceObject_alias2","object_type",POM_enquiry_equal,"ImanType_alias2","type_name"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_9","ImanType_alias2","parent_type",POM_enquiry_equal,"ImanType_alias3","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_10","ImanType_alias3","type_name", POM_enquiry_equal, "aunique_value_id2"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_11","Item","puid",POM_enquiry_equal,"Pom_application_object","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_12","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_13","POM_object","owning_site",POM_enquiry_is_null ,NULL ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_14","itemrevision","puid",POM_enquiry_equal,"WorkspaceObject_alias3","puid"));
	}
	
	/*Launch Model Year*/
	if ( (pcLaunchModelYear != NULL) && (pcFormAttr_LaunchModelYear != NULL) && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id3", 1, &pcLaunchModelYear, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_31","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_32", pcForm, "t1a2launchmodelyear",POM_enquiry_like ,"aunique_value_id3" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_32",POM_case_insensitive));
		}
	}
	
	/*Released By Change*/
	if ( (pcReleasedByChange != NULL) && (pcFormAttr_ReleasedByChange != NULL) && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id4", 1, &pcReleasedByChange, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_33","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_34", pcForm, "t1a2releasedbychange",POM_enquiry_like ,"aunique_value_id4" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_34",POM_case_insensitive));
		}
	}

	/*Program Array*/
	if ( (pcProgramType != NULL) && (pcFormAttr_Program != NULL) && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id5", 1, &pcProgramType, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_35","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_36", pcForm, "t1a2programarray",POM_enquiry_like ,"aunique_value_id5" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_36",POM_case_insensitive));
		}
	}

	/*Customer Name*/
	if ( (pcCustomerName != NULL) && (pcFormAttr_CustomerName != NULL) && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id6", 1, &pcCustomerName, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_37","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_38",pcForm, "t1a2customername",POM_enquiry_like ,"aunique_value_id6" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_38",POM_case_insensitive));
		}
	}

	/*Customer Release No*/
	if ( (pcCustomerReleaseNo != NULL) && (pcFormAttr_CustomerReleaseNo != NULL) && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id7", 1, &pcCustomerReleaseNo, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_39","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_40", pcForm, "t1a2customerreleaseno",POM_enquiry_like ,"aunique_value_id7" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_40",POM_case_insensitive));
		}
	}

	/*Item ID*/
	if(pcItemID != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id8", 1, &pcItemID, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_41","Item", "item_id",POM_enquiry_like,"aunique_value_id8"));	
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_41",POM_case_insensitive));
		}
	}

	/*Object Name*/
	if (pcName != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id9", 1,&pcName, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM","auniqueExprId_42","WorkspaceObject_alias1","object_name",POM_enquiry_like,"aunique_value_id9"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_42",POM_case_insensitive));
		}
	}

	/*Object Type*/
	if (pcObjType != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id10", 1,&pcObjType, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM","auniqueExprId_43","WorkspaceObject_alias2","object_type",POM_enquiry_like,"aunique_value_id10"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_OEM","auniqueExprId_43",POM_case_insensitive));
		}
	}

	/*Owning Group*/
	if (pcOwningGroup != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id11", 1, &pcOwningGroup, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_44","Pom_application_object","owning_group",POM_enquiry_equal,"pom_group","puid"));	
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_45", "pom_group","name",POM_enquiry_like ,"aunique_value_id11" ));
		}
	}

	/*Owning site*/
	if (pcOwningSite != NULL && iFail == 0)
	{
		/*If Owning site & Logged in site are same*/
		if (tc_strcmp(pcOwningSite ,LOCAL) == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_46","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
			if(iFail == 0)
			{
				TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_47","pom_object","owning_site",POM_enquiry_is_null, NULL  ));
			}
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id12", 1, &pcOwningSite, POM_enquiry_bind_value ));
			if(iFail == 0)
			{
				TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_46","pom_object","owning_site",POM_enquiry_equal, "pom_imc", "puid"  ));
			}
			if(iFail == 0)
			{				
					TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_47", "pom_imc","name",POM_enquiry_like ,"aunique_value_id12" ));
			}
		}
	}

	/*Owning user*/
	if (pcOwningUser != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id13", 1, &pcOwningUser, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_48","Pom_application_object","owning_user",POM_enquiry_equal,"user","puid"));	
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_49", "user","os_username",POM_enquiry_like ,"aunique_value_id13" ));
		}
	}

	/*Last modified user*/
	if (pcLastModUser != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id14", 1, &pcLastModUser, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_50","Pom_application_object","last_mod_user",POM_enquiry_equal,"user_alias","puid"));
		}
		if(iFail == 0)
		{			
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_51", "user_alias","os_username",POM_enquiry_like ,"aunique_value_id14" ));	
		}
	}

	/*Release status*/
	if (pcReleaseStatus != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id15", 1, &pcReleaseStatus, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_52","itemrevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));	
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_53", "ReleaseStatus", "name",POM_enquiry_like ,"aunique_value_id15" ));
		}
	}

	/*Current task*/
	if (pcCurrentTask != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_OEM", "aunique_value_id16", 1, &pcCurrentTask, POM_enquiry_bind_value ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_54","itemrevision","process_stage_list",POM_enquiry_equal,"epmtask","puid"));	
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_OEM", "auniqueExprId_55","epmtask","task_template",POM_enquiry_equal,"epmtasktemplate","puid"));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_56", "epmtasktemplate", "template_name",POM_enquiry_like ,"aunique_value_id16"));
		}
	}

	/*Created after date*/		
	if (pcCreatedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCreatedAfter, &dCAD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id17", 1, &dCAD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_57","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id17"));	
		}
	}

	/*Created before date*/
	if (pcCreatedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCreatedBefore, &dCBD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id18", 1, &dCBD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_58","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id18"));
		}	
	}

	/*Modified after date*/
	if (pcModifiedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcModifiedAfter, &dMAD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id19", 1, &dMAD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_59","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id19"));
		}
	}

	/*Modified before date*/
	if (pcModifiedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcModifiedBefore, &dMBD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id20", 1, &dMBD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_60","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id20"));
		}
	}

	/*Released after date*/
	if (pcReleasedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcReleasedAfter, &dRAD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id21", 1, &dRAD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_61","WorkspaceObject_alias3","date_released",POM_enquiry_greater_than_or_eq,"aunique_value_id21"));
		}
	}

	/*Released before date*/
	if (pcReleasedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcReleasedBefore, &dRBD));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_OEM", "aunique_value_id22", 1, &dRBD, POM_enquiry_bind_value ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_OEM", "auniqueExprId_62","WorkspaceObject_alias3","date_released",POM_enquiry_less_than_or_eq,"aunique_value_id22"));
		}
	}


	//join the expression
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_63","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_3" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_4" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_5" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_6" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_7" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_8" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_9" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_10" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and, "auniqueExprId_11" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_12" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_13" ));
	}
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_14" ));
	}
	
	/*Launch Model Year*/
	if (pcLaunchModelYear != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_81","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_31" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_82","auniqueExprId_81",POM_enquiry_and, "auniqueExprId_32" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_82","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Released By Change*/
	if (pcReleasedByChange != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_83","auniqueExprId_82",POM_enquiry_and, "auniqueExprId_33" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_84","auniqueExprId_83",POM_enquiry_and, "auniqueExprId_34" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_84","auniqueExprId_82",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Program Array*/
	if (pcProgramType != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_85","auniqueExprId_84",POM_enquiry_and, "auniqueExprId_35" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_86","auniqueExprId_85",POM_enquiry_and, "auniqueExprId_36" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_86","auniqueExprId_84",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Customer Name*/
	if (pcCustomerName != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_87","auniqueExprId_86",POM_enquiry_and, "auniqueExprId_37" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_88","auniqueExprId_87",POM_enquiry_and, "auniqueExprId_38" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_88","auniqueExprId_86",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Customer Release No*/
	if (pcCustomerReleaseNo != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_89","auniqueExprId_88",POM_enquiry_and, "auniqueExprId_39" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_90","auniqueExprId_89",POM_enquiry_and, "auniqueExprId_40" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_90","auniqueExprId_88",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Item ID*/
	if (pcItemID != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_91","auniqueExprId_90",POM_enquiry_and, "auniqueExprId_41" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_91","auniqueExprId_90",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Object Name*/
	if (pcName != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_92","auniqueExprId_91",POM_enquiry_and, "auniqueExprId_42" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_92","auniqueExprId_91",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Object Type*/
	if (pcObjType != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_93","auniqueExprId_92",POM_enquiry_and, "auniqueExprId_43" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_93","auniqueExprId_92",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	
	/*Owning Group*/
	if (pcOwningGroup != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_94","auniqueExprId_93",POM_enquiry_and, "auniqueExprId_44" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_95","auniqueExprId_94",POM_enquiry_and, "auniqueExprId_45" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_95","auniqueExprId_93",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Owning site*/
	if (pcOwningSite != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_96","auniqueExprId_95",POM_enquiry_and, "auniqueExprId_46" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_97","auniqueExprId_96",POM_enquiry_and, "auniqueExprId_47" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_97","auniqueExprId_95",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Owning user*/
	if (pcOwningUser != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_98","auniqueExprId_97",POM_enquiry_and, "auniqueExprId_48" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_99","auniqueExprId_98",POM_enquiry_and, "auniqueExprId_49" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_99","auniqueExprId_97",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Last modified user*/
	if (pcLastModUser != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_100","auniqueExprId_99",POM_enquiry_and, "auniqueExprId_50" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_101","auniqueExprId_100",POM_enquiry_and, "auniqueExprId_51" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_101","auniqueExprId_99",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Release status*/
	if (pcReleaseStatus != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_102","auniqueExprId_101",POM_enquiry_and, "auniqueExprId_52" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_103","auniqueExprId_102",POM_enquiry_and, "auniqueExprId_53" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_103","auniqueExprId_101",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Current task*/
	if (pcCurrentTask != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_104","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_54" ));
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_105","auniqueExprId_104",POM_enquiry_and, "auniqueExprId_55" ));
		}
		if(iFail == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_106","auniqueExprId_105",POM_enquiry_and, "auniqueExprId_56" ));
		}
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_106","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Created after date*/		
	if (pcCreatedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_107","auniqueExprId_106",POM_enquiry_and, "auniqueExprId_57" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_107","auniqueExprId_106",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Created before date*/
	if (pcCreatedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_108","auniqueExprId_107",POM_enquiry_and, "auniqueExprId_58" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_108","auniqueExprId_107",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	

	/*Modified after date*/
	if (pcModifiedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_109","auniqueExprId_108",POM_enquiry_and, "auniqueExprId_59" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_109","auniqueExprId_108",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Modified before date*/
	if (pcModifiedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_110","auniqueExprId_109",POM_enquiry_and, "auniqueExprId_60" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_110","auniqueExprId_109",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Released after date*/
	if (pcReleasedAfter != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_111","auniqueExprId_110",POM_enquiry_and, "auniqueExprId_61" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_111","auniqueExprId_110",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	/*Released before date*/
	if(pcReleasedBefore != NULL && iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_62" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_OEM","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}

	//set where expression
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_OEM","auniqueExprId_112" ));
	}
	
	//set distinct value
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_OEM", true));
	}
	
	//execute the query
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_OEM",&iRows,&iCols,&paReport));
	}
	
	//process result	
	if(iRows > 0 && iFail == 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(index = 0;index < iRows;index++)
		{
			tOEMItem = NULLTAG;
			tOEMItem = *(tag_t *)paReport[index][0];
			(*foundTags)[index] = tOEMItem;
		}
		SAFE_MEM_free(paReport);
	}

	//delete the query
	if(iFail == 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_OEM" ));
	}

	//to free the memory
	SAFE_MEM_free(pcForm);
	SAFE_MEM_free(pcFormAttr_Program);
	SAFE_MEM_free(pcFormAttr_LaunchModelYear);
	SAFE_MEM_free(pcFormAttr_ReleasedByChange);
	SAFE_MEM_free(pcFormAttr_CustomerName);
	SAFE_MEM_free(pcFormAttr_CustomerReleaseNo);
	
	return iFail;
}