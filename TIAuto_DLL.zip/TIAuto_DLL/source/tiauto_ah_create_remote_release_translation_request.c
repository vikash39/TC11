/************************************************************************************************************
File         : tiauto_ah_create_erp_translation_request.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
Mar 6, 2013    1.0        Dipak Naik      Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <time.h>



int check_status_of_Alternates_remote(		tag_t						_tParentBVR,
									tag_t						_tOccurrence,
									tag_t						_tPreferredChild,
									STATUS_Struct_t				_StatusProgression, 
									TARGET_RELEASE_Struct_t		_TargetReleaseStatus,logical *isFound)
{
	int iRetCode = ITK_ok;
	int iCount = 0;
	int iNoAlternates = 0; 
	tag_t tAlternate = NULLTAG;
	tag_t *ptAltItems = NULL;  
	tag_t *pAltViews = NULL;
	int		iQuickProgFlag			= 0;
	int		iFound					= 0; 
	int		iSiteIid				= 0; 
	int		iTotal					= 0;
	    
	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= ""; 
	
	logical lIsOEM				= false;
	
	if(*isFound == true)
		return 0;

	//iRetCode = PS_list_alternates (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews); //Deprecated This will be obsoleted. Use PS_list_substitutes 
	iRetCode = PS_list_substitutes (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews);
	if(iRetCode == ITK_ok && iNoAlternates > 0)
	{
		for (iCount = 0; (iCount < iNoAlternates) && (iRetCode == ITK_ok) ;iCount++)
		{
			tAlternate = ptAltItems[iCount];
			if( tAlternate != NULLTAG && _tPreferredChild != tAlternate)
			{
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					//get the target release status of the child component
					iRetCode = tiauto_get_release_status(tAlternate, szChildRelStatus);
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = WSOM_ask_id_string( tAlternate, &szChildItemRev);
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = AOM_ask_value_tag( tAlternate, "owning_site", &tOwningSite);
					if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
					{
						if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
						{
							*isFound = true;
							break;
						}
					}

				}
				if ( iRetCode == ITK_ok && *isFound == false)
				{
					iRetCode = tiauto_verify_remote_child_components( tAlternate,
																_StatusProgression, _TargetReleaseStatus,isFound);
												 
				}
			}
		}
	}

	
	SAFE_MEM_free(ptAltItems);
	SAFE_MEM_free(pAltViews);
	SAFE_MEM_free(szChildItemRev);

	return iRetCode;
}

int tiauto_verify_remote_child_components(tag_t _tItemRev,
												STATUS_Struct_t				_StatusProgression, 
												TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
												logical *isFound)
{
	int		iRetCode				= 0;	
    int		iCount					= 0;
    int		iItemRevBvrCount		= 0;
    int		iNumOccs				= 0;
	int		iFound					= 0; 
	int		iSiteIid				= 0; 
	int		iQuickProgFlag			= 0;
	int		iTotal					= 0;

    tag_t   *ptItemRevBvrs			= NULL;    
    tag_t   *ptOccs					= NULL;
    tag_t   tChildItem				= NULLTAG;
	tag_t	tChildBomView			= NULLTAG;
	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	*szItemRevInChangeId						= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= ""; 
	
    logical lIsPrecise			= false;
	logical lIsOEM				= false;
	logical lHasAlternates		= false;

	if(*isFound == true)
		return 0;
	
		
    
	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
	if ( iRetCode == ITK_ok)
		iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);
	if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
	{
		//As per existing implementation, there is only one BVR in the system, So always take the 1st one
		iRetCode = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
		if ( (iRetCode == ITK_ok) && (lIsPrecise == false) )
		{
				
		}
	}
	    
	//If the item doesn't have a precise BOM, we need not proceed further
	if ( (iRetCode == ITK_ok)  && iItemRevBvrCount > 0 )
	{
		iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
		// If the BVR does not have any child component, no need to proceed further
		for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
		{
			tChildItem = NULLTAG;
			tChildBomView = NULLTAG;
			tc_strcpy ( szChildRelStatus, "" );
			szChildItemRev = NULL;
			lHasAlternates = false;

			iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],
													&tChildItem, &tChildBomView);							
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				//get the target release status of the child component
				iRetCode = tiauto_get_release_status(tChildItem, szChildRelStatus);
			}
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				iRetCode = WSOM_ask_id_string( tChildItem, &szChildItemRev);
			}
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				iRetCode = AOM_ask_value_tag( tChildItem, "owning_site", &tOwningSite);
				if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
				{					
					//3.Verifying whether child component rev is at SAME or HIGHER status than 
					//target release status of Change process. 
					//If yes, accept the child component and continue to verify another child rev.
					if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
					{
						*isFound = true;
						break;
					}
							
				}
			}

			//check the status of the Alternates
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				//iRetCode = PS_ask_has_alternates  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates ); //Deprecated This will be obsoleted. Use PS_ask_has_substitutes 
				iRetCode = PS_ask_has_substitutes  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates );
				if ( iRetCode == ITK_ok && lHasAlternates == true)
				{
					iRetCode = check_status_of_Alternates_remote(	ptItemRevBvrs[0], ptOccs[iCount],
																	tChildItem,
																  _StatusProgression, _TargetReleaseStatus,isFound);
				}
			}
			//if the "iLevel", call this recursive function again.
			//for the recursive function the "iLevel" value will be "iLevel - 1"
			if(iRetCode == ITK_ok && tChildItem != NULLTAG  )
			{
				iRetCode = tiauto_verify_remote_child_components( tChildItem, 
															_StatusProgression, _TargetReleaseStatus,isFound);					
			}
		}        
	}
	
	
	

    return iRetCode;
}

//main function of the handler "TIAUTO-AH-Create-ERP-Translation-Request"
extern int TIAUTO_AH_create_remote_release_translation_request(EPM_action_message_t msg)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				iNumAffected								= 0;
	int				iSite										= 0;
	int				iSiteID										= 0;
	int				iCount										= 0;
	
	char			**pcCustomerName							= NULL;
	char			*pcErrMsg									= NULL;
	char			caObjectType[WSO_name_size_c+1]				= "";	
	char			acSiteName[SA_site_size_c+1]				= {'\0'};
	char			*pcValidReleaseStatusList					= NULL;
	char    **pszProgressionPath  = NULL; 
    TC_preference_search_scope_t tScope;
	
	tag_t			tChangeRev								= NULLTAG;
	tag_t			tUser									= NULLTAG;
	tag_t			tGroup									= NULLTAG;
	tag_t           tRequest								= NULLTAG;
	tag_t			tSite									= NULLTAG;
	tag_t			*ptAffectedItems						= NULL;

	boolean bValidERPPlant			= false;
	boolean bMfgRelAuthToBeCreated	= false;
	logical isFound = false;

	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

	tiauto_initialize_status_progression_stuct(&StatusProgression); 
	iRetCode = tiauto_get_status_progression_array (&StatusProgression);

	tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus, PRODUCTION_LAUNCHED);
	if(iRetCode == ITK_ok)
	{
		TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			
	}
	
	//Get the Current Site Name
	if( iRetCode == ITK_ok )
		iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	//get the site name mentioned in the preference
	if (iRetCode == ITK_ok )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
				iRetCode = ECM_get_affected_items(tChangeRev, &iNumAffected, &ptAffectedItems);
				for(indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++ )
				{
					iRetCode = tiauto_verify_remote_child_components(ptAffectedItems[indx],StatusProgression,TargetReleaseStatus ,&isFound);
					if( isFound == true )
					{
						iRetCode = DISPATCHER_create_request  ( "TIAUTO", "remote_release",3,0 ,0 ,0, 1,&tChangeRev ,NULL,0  ,NULL,"PLM_Remote_Release_Data",0,NULL,NULL,&tRequest);
						/*iRetCode = SA_find_user ("erpintegration",&tUser);
						if(tUser != NULLTAG)
						{
							iRetCode = SA_ask_user_login_group(tUser,&tGroup); 
							iRetCode = AOM_set_ownership (tRequest,tUser,tGroup);
						}
						//iRetCode = AOM_save(tRequest);
						iRetCode = AOM_refresh (tRequest,false);*/
						break;
					}
				}
				
				SAFE_MEM_free(ptAffectedItems);
			
		}
	}
	if (iRetCode != ITK_ok ) 
	{
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcCustomerName);
	return iRetCode;
}
