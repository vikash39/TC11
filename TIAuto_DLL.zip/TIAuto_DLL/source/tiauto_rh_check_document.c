/*******************************************************************************
File         : tiauto_rh_check_document.c

Description  : This rule handler validates the documents present in the affected
               items and solution items change folders. The handler must not all
               ow the workflow to progress unless every product revision associa
               ted to it through the TI_DocProdRevisions relationship meets one 
               of the following criteria:
           
              �	The product revision�s latest release state matches or is higher
                than the target release state of the workflow process through wh
                ich the document revision is being released.
              �	All associated product revision�s latest release state are past 
                the target release state of the document revision (i.e. the targ
                et release state is Pre-Production and product revision is at Pr
                oduction Released or Production Launched or the target release s
                tate is Pre-Prototype and the product revision is at Prototype).
              �	The product revision is included in the solution or affected fol
                der of the change and is therefore being released to the target 
                release status.

Input        : None
                        
Output       : None

Author       : Rajesh Sadhwani, UGS

Revision History :
Date            Revision    Who              Description
May 29, 2007    1.0         Rajesh Sadhwani  Initial Creation
Dec 08, 2008    1.1         Srikanth         Commented the business rule implementation.

*******************************************************************************/

/* tiauto Includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_defines.h>

EPM_decision_t t1aAUTO_check_document(EPM_rule_message_t message)
{
    /****** Commenting rule handler code and returning always EPM_go(to make handler to PASS) as per decision taken by TI Auot PLM team on 
        21st November 2008. Customer decided to remove this business rule all together from change processes/workflows, but we need to
        modify all the workflows to remove handler configuration. Instead of removing handler from workflows, it was decided to comment
        the code and make always PASS the rule as a quick fix which takes less time. Also in the future, if TI Automotive interested in
        re-using the rule/code, if will be helpful if we keep the commented code. See the below commented code for earlier implementation  ****/

    return EPM_go;
}

#if 0
int check_documents(tag_t tEngChangeRev, char * pszTargetReleaseState);

EPM_decision_t t1aAUTO_check_document(EPM_rule_message_t message)
{
  int iStatus              = ITK_ok;

  int i                     = 0;
  int j                     = 0;
  int nArgs                 = 0;
  int iTargetCount          = 0;  
  int iNoAttachs            = 0;
  int inx                   = 0;
  
  char szObjectType[WSO_name_size_c + 1]           = {0};  
  char szInputFormType[WSO_name_size_c + 1]        = {0};
  char szFormAttribute[WSO_name_size_c + 1]        = {0};
  char szTargetReleaseState[WSO_name_size_c + 1]   = {0};
  char szErrorString[512]                          = {0};

  char *pszTargetReleaseState = NULL;

  tag_t tForm                   = NULLTAG;
  tag_t tRoot                   = NULLTAG;
  tag_t tEngChangeRev           = NULLTAG;
  tag_t tSpecificationRelation  = NULLTAG;

  tag_t *ptTargetObjects    = NULL; 
  tag_t *ptAttachments = NULL;

  TC_write_syslog("ENTER -> t1aAUTO_check_document.\n");

  // Check the arguments.

  nArgs = TC_number_of_arguments(message.arguments);

  if( DEBUG_PRINT ) TC_write_syslog("nArgs = %d\n", nArgs);

  if(nArgs < 1)
  {        
    if( DEBUG_PRINT ) TC_write_syslog("Please provide the valid argument to the handler.\n");
    EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_OF_ARGS_ERROR, INCORRECT_ARGS_MSG) ;
    iStatus = TIAUTO_CHECK_DOCUMENT_NO_OF_ARGS_ERROR;
  }
  else
  {
    char *flag  = NULL;	     
    char *value = NULL;
    char *arg   = NULL;

    for(i = 0; i < nArgs; i++)
    {
      arg = TC_next_argument(message.arguments);

      if( DEBUG_PRINT ) TC_write_syslog("arg = [%s]\n", arg);

      TIAUTO_ITKCALL( iStatus, ITK_ask_argument_named_value(arg, &flag, &value) );
      if ( (iStatus == ITK_ok) && (flag != NULL) && (value != NULL) )
      {
        if ( tc_strcmp(flag, "status") == 0 )
        {
          tc_strcpy(szTargetReleaseState, value);
          if( DEBUG_PRINT ) TC_write_syslog("%d Argument to the handler, szTargetReleaseState = [%s]\n", i, szTargetReleaseState);          
        }      
        else if ( tc_strcmp(flag, "type") == 0 )
        {
          tc_strcpy(szInputFormType, value);
          if( DEBUG_PRINT ) TC_write_syslog("%d Argument to the handler, szInputFormType = [%s]\n", i, szInputFormType);
        }
        else if ( tc_strcmp(flag, "attribute") == 0 )
        {
          tc_strcpy(szFormAttribute, value);
          if( DEBUG_PRINT ) TC_write_syslog("%d Argument to the handler, szFormAttribute = [%s]\n", i, szFormAttribute);          
        }
      }
      SAFE_MEM_free(flag);
      SAFE_MEM_free(value);
    }

    // Check that the handler arguments are either the target release status or the form type and attribute to pick the target release status from, e.g., ECR form has attribute t1a40targetreleasestate.
    if ( 
         (tc_strlen(szTargetReleaseState) == 0) && 
         ( (tc_strlen(szInputFormType) == 0) || (tc_strlen(szFormAttribute) == 0 ) )
       )
    {
      TC_write_syslog("Please provide either the \"status\" argument or \"type\" and \"attribute\" arguments to the handler for getting the target release state.\n");
      EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_OF_ARGS_ERROR, INCORRECT_ARGS_MSG) ;
      iStatus = TIAUTO_CHECK_DOCUMENT_NO_OF_ARGS_ERROR;
    }
    else
    {
      // Check the attachments
      TIAUTO_ITKCALL(iStatus, EPM_ask_root_task(message.task, &tRoot));
      if( DEBUG_PRINT ) TC_write_syslog("tRoot = %d\n", tRoot);

      TIAUTO_ITKCALL(iStatus, EPM_ask_attachments(tRoot, EPM_target_attachment, &iTargetCount, &ptTargetObjects));

      for(j=0; j < iTargetCount; j++)
      {
        TIAUTO_ITKCALL(iStatus, WSOM_ask_object_type(ptTargetObjects[j], szObjectType ));
        if( DEBUG_PRINT ) TC_write_syslog("szObjectType = [%s]\n", szObjectType );        

        if ( tc_strcmp(szObjectType, CHANGE_REV) == 0 )
        {
          tEngChangeRev = ptTargetObjects[j];
          TC_write_syslog("tEngChangeRev = %d\n", tEngChangeRev);
          break;
        }
      }

      if (NULLTAG == tEngChangeRev)
      {
        if( DEBUG_PRINT ) TC_write_syslog("No object of \"%s\" type is found.\n", CHANGE_REV);
        EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_ENG_CHANGE_REV_ERROR, "No change item revision found.\n") ;        
        iStatus = TIAUTO_CHECK_DOCUMENT_NO_ENG_CHANGE_REV_ERROR;
      }
      else
      {
        if ( tc_strlen(szTargetReleaseState) == 0 )
        {
          // Find the target release state from the form attached.

          /* get all the specification attachements of EC*/          
          TIAUTO_ITKCALL(iStatus, GRM_find_relation_type( "IMAN_specification", &tSpecificationRelation ) );
          TIAUTO_ITKCALL(iStatus, GRM_list_secondary_objects_only( tEngChangeRev, tSpecificationRelation, &iNoAttachs, &ptAttachments ) );

          if( DEBUG_PRINT ) TC_write_syslog("iNoAttachs = [%d]\n", iNoAttachs);

          if( iNoAttachs ==  0 )
          {
            if( DEBUG_PRINT ) TC_write_syslog("Engineering Change Rev doesn't have any specification attachements.\n");
            EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_SPEC_ERROR, "Engineering Change Rev doesn't have any specification attachements.");
            iStatus = TIAUTO_CHECK_DOCUMENT_NO_SPEC_ERROR;
          }
          else
          {
            for ( inx = 0; ( (iStatus == ITK_ok) && (inx < iNoAttachs) ); inx++ )
            {
              TIAUTO_ITKCALL(iStatus, WSOM_ask_object_type(ptAttachments[inx], szObjectType ));
              if( DEBUG_PRINT ) TC_write_syslog("szObjectType = [%s]\n", szObjectType );

              if( (iStatus == ITK_ok) && (tc_strcmp(szObjectType, szInputFormType ) == 0) )
              {
                tForm = ptAttachments[inx];
              
                /* get the value of the source attribute */
                TIAUTO_ITKCALL(iStatus, AOM_ask_value_string( tForm, szFormAttribute, &pszTargetReleaseState ));
                if( DEBUG_PRINT ) TC_write_syslog("pszTargetReleaseState = [%s]\n", pszTargetReleaseState );

                if (iStatus == ITK_ok)
                {
                  if (pszTargetReleaseState != NULL)
                  {
                    tc_strcpy(szTargetReleaseState, pszTargetReleaseState);
                    SAFE_MEM_free(pszTargetReleaseState);
                    break;
                  }
                  else
                  {
                    if( DEBUG_PRINT ) TC_write_syslog("The specified form type %s doesn't contain target release status.\n", szInputFormType);
                    EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_ATTRIBUTE_ERROR, "The specified form type doesn't contain target release status.");
                    iStatus = TIAUTO_CHECK_DOCUMENT_NO_ATTRIBUTE_ERROR;
                  }                  
                }
              }
            } // end of for loop

            if ( (iStatus == ITK_ok) && (inx == iNoAttachs) )
            {
              // No form of required type was found.
              TI_sprintf( szErrorString, "Engineering Change Rev doesn't have contain any form of type %s.", szInputFormType );
              if( DEBUG_PRINT ) TC_write_syslog(szErrorString);
              EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_NO_FORM_ERROR, szErrorString);
              iStatus = TIAUTO_CHECK_DOCUMENT_NO_FORM_ERROR;
            }            
          }
          SAFE_MEM_free(ptAttachments);
        } // if ( tc_strlen(szTargetReleaseState) == 0 )
        
        if ( (iStatus == ITK_ok) && (tc_strlen(szTargetReleaseState) != 0) )
        {
          // We have the target release state at this point. Now validate the documents.
          TIAUTO_ITKCALL(iStatus, check_documents(tEngChangeRev, szTargetReleaseState));
        }      
      }
      SAFE_MEM_free(ptTargetObjects);
    }
  }
  TC_write_syslog("Exit <- t1aAUTO_check_document\n");

  if (iStatus == ITK_ok)
    return EPM_go;
  else
    return EPM_nogo;
}

/*
*   Description:
*       This function will check the product revisions associated with the docum
*       ent to check if they are getting released alongwith or if they are at th
*       e same or higher release state as compared to target release state.
*
* revisions
*  rev     date            who                   reason for change
*  1.0     Jun 07, 2007    Rajesh Sadhwani       initial release
*/


int check_documents(tag_t tEngChangeRev, char * pszTargetReleaseState)
{
  int iStatus            = ITK_ok;
  int i                  = 0;
  int j                  = 0;  
  int k                  = 0;
  int m                  = 0;  
  int iCount             = 0;
  int iNoAffectedItems   = 0;
  int iDocProdAttachs    = 0;
  int iNoStatus          = 0;
  
  int iTargetReleaseStateLevel  = -1;        // Assume no target release status in the beginning.
  int iProductReleaseStateLevel = -1;       // Assume no release status of the product rev.

  char szParentType[TCTYPE_name_size_c+1] = {0};
  char szErrorString[512]                   = {0};
  
  char *pszLatestStatus  = NULL;
  char *pszDocumentId    = NULL;
  char *pszDocProdRevId  = NULL;


  char **pszProgressionPath  = NULL;
  
  tag_t tObjectType      = NULLTAG;
  tag_t tParentType      = NULLTAG;
  tag_t tDocumentRev     = NULLTAG;
  tag_t tDocProdRev      = NULLTAG;
  tag_t tDocProdRelation = NULLTAG;

  tag_t * tAffectedItems = NULL;
  tag_t * tStatusList    = NULL;
  tag_t *pDocProdAttachs = NULL;

  // get the progression path from preference variable.

  TC_preference_search_scope_t oldScope;
  
  iStatus = PREF_ask_search_scope( &oldScope );
  iStatus = PREF_set_search_scope( TC_preference_site );
  iStatus = PREF_ask_char_values(PROGRESSION_PATH, &iCount, &pszProgressionPath);
  iStatus = PREF_set_search_scope( oldScope );

  for ( i = 0; i < iCount; i++ )
  {
    if ( tc_strcmp(pszTargetReleaseState, pszProgressionPath[i]) == 0 )
    {
      iTargetReleaseStateLevel = i;
      break;
    }
  }

  /* get all the TI_DocProdRevisions attachements of EC*/
  TIAUTO_ITKCALL(iStatus, ECM_get_affected_items( tEngChangeRev, &iNoAffectedItems, &tAffectedItems ) );
  if( DEBUG_PRINT ) TC_write_syslog("iNoAffectedItems = [%d]\n", iNoAffectedItems);

  for ( i = 0; ( (iStatus == ITK_ok) && (i < iNoAffectedItems) ); i++ )
  {
    TIAUTO_ITKCALL(iStatus, TCTYPE_ask_object_type(tAffectedItems[i], &tObjectType )); 
    TIAUTO_ITKCALL(iStatus, TCTYPE_ask_parent_type(tObjectType, &tParentType)); 
    TIAUTO_ITKCALL(iStatus, TCTYPE_ask_name(tParentType, szParentType));

    if( DEBUG_PRINT ) TC_write_syslog("szParentType = [%s]\n", szParentType );

    if( tc_strcmp(szParentType, DOCUMENT_REV) == 0 )
    {
      tDocumentRev = tAffectedItems[i];   

      // Check the conditions for each document.     
      TIAUTO_ITKCALL(iStatus, GRM_find_relation_type( "TI_DocProdRevisions", &tDocProdRelation ) );
      TIAUTO_ITKCALL(iStatus, GRM_list_secondary_objects_only( tDocumentRev, tDocProdRelation, &iDocProdAttachs, &pDocProdAttachs ) );

      if( DEBUG_PRINT ) TC_write_syslog("iDocProdAttachs = [%d]\n", iDocProdAttachs);

      if( iDocProdAttachs !=  0 ) // This document revision is referenced by some product revisions.
      {
        for ( j = 0; ( (iStatus == ITK_ok) && (j < iDocProdAttachs) ); j++ )
        {
          // check if each of the product revisions is a target or has a higher release state.
          tDocProdRev = pDocProdAttachs[j];
          for ( k = 0; k < iNoAffectedItems; k++ )
          {
            if (tDocProdRev == tAffectedItems[k])
            {
              // DocProdRev is being released in the current workflow process.
              break;
            }
          }
          // If k = iNoAffectedItems, this means that the DocProdRev was not the target, so check for the progression path.
          if (k == iNoAffectedItems)
          {
            iProductReleaseStateLevel = -1; // Resetting the release status level to -1.
            TIAUTO_ITKCALL( iStatus, WSOM_ask_release_status_list (tDocProdRev, &iNoStatus, &tStatusList) );
            if (tStatusList != NULL)
            {
              TIAUTO_ITKCALL( iStatus, AOM_ask_value_string(tStatusList[0], "name", &pszLatestStatus) );

              if (pszLatestStatus != NULL)
              {
                for ( m=0; m < iCount; m++)
                {
                  if ( tc_strcmp(pszLatestStatus, pszProgressionPath[m]) == 0 )
                  {
                    iProductReleaseStateLevel = m;
                    break;                
                  }
                }
                SAFE_MEM_free(pszLatestStatus);
              }
              SAFE_MEM_free(tStatusList);
            }           
            
            // Check if the current product rev is released to the same or higher level when compared to the document.
            if (iProductReleaseStateLevel < iTargetReleaseStateLevel)
            {
              TIAUTO_ITKCALL( iStatus, WSOM_ask_object_id_string (tDocumentRev, &pszDocumentId) );
              TIAUTO_ITKCALL( iStatus, WSOM_ask_object_id_string (tDocProdRev, &pszDocProdRevId) );

              TI_sprintf( szErrorString, "You are trying to release the document %s. This document contains a product rev %s that is released to a lower state than the target release state %s and is not getting released alongwith the document.", pszDocumentId, pszDocProdRevId, pszTargetReleaseState );

              EMH_store_error_s1( EMH_severity_error, TIAUTO_CHECK_DOCUMENT_INVALID_DOCUMENT_ERROR, szErrorString);
              
              iStatus = TIAUTO_CHECK_DOCUMENT_INVALID_DOCUMENT_ERROR;

              SAFE_MEM_free(pszDocumentId);
              SAFE_MEM_free(pszDocProdRevId);
              break;
            }
          }
        }  // for looping through TI_DocProdRevisions attachments of each document rev.
      }  // if( iDocProdAttachs !=  0 )

      SAFE_MEM_free(pDocProdAttachs);

    }  // if( tc_strcmp(szParentTypeName, DOCUMENT_REV) == 0 )
  }  // for looping through the affected items of the change.

  SAFE_MEM_free(tAffectedItems);
  
  /* This doesn't work. May be it's not meant to be freed.
  for ( i=0; i<iCount; i++)
  {
    MEM_free(pszProgressionPath[i]);
    pszProgressionPath[i] = NULL;
  }
  */
  SAFE_MEM_free(pszProgressionPath);

  return iStatus;
}
#endif 


