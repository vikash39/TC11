/*******************************************************************************
File         : tiauto_ah_set_attribute_value.c

Description  :

Input        : None

Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Nov 11, 2012    1.0         Manik      	     Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

#define ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER1 "SOURCE"
#define ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER2 "TARGET"


logical validateObject( char *pcObjectType)
{
	int iFail = 0;
	tag_t tObjectType = NULLTAG;

	remove_forward_AND_trailing_space(pcObjectType);
	iFail = TCTYPE_find_type  ( pcObjectType, NULL, &tObjectType  );
	return ((tObjectType == NULLTAG)? false:true);
}

int TI_GetTarget_Atts(tag_t tRootTaskTag,char *pcObjectType,tag_t *tObject)
{
	int               iRetCode                          =  ITK_ok;
	int               iAttachmentCnt                    = 0;
	int               i                                 = 0;
	tag_t             tTypeTag                          = NULLTAG;
	tag_t             *ptAttachments                    = NULL;
	char              acObjType[TCTYPE_name_size_c+1] = "";

	iRetCode = EPM_ask_attachments(tRootTaskTag,EPM_target_attachment,&iAttachmentCnt,&ptAttachments);
	if(iRetCode == ITK_ok)
	{
		for(i = 0; i< iAttachmentCnt;i++)
		{
			iRetCode = TCTYPE_ask_object_type(ptAttachments[i],&tTypeTag);
			if(iRetCode == ITK_ok && tTypeTag != NULLTAG)
				iRetCode = TCTYPE_ask_name(tTypeTag,acObjType);
			if(iRetCode == ITK_ok && !tc_strcmp(acObjType, pcObjectType ))
			{
                *tObject = ptAttachments[i];
				break;
			}
		}
	}
	SAFE_MEM_free(ptAttachments);
	return iRetCode;
}

extern int TIAUTO_set_attribute_value(EPM_action_message_t msg)
{

	char *pcFlag = NULL;	
	char *pcValue = NULL;	
	char **pcSourceArgs = NULL;	
	char **pcTargetArgs = NULL;	
	char szErrorString[TIAUTO_error_message_len+1]	= "";
	char *pcPropValue = NULL;
	char **pcPropNames = NULL;	
	char *pcSourcePropType = NULL;
	char *pcTemp = NULL;
	char *pcTargetPropType = NULL;
	logical validate = false;
	int iSourceArgCount = 0;
	int iTargetArgCount = 0;
	int iNumArgs = 0, i = 0, iCount = 0;
	int iRetCode = 0;
	tag_t tSourceObject = NULLTAG;
	tag_t tTargetObject = NULLTAG;
	tag_t tRootTaskTag = NULLTAG;
	PROP_value_type_t  sourcePropType;
	PROP_value_type_t  targetPropType;

	iNumArgs = TC_number_of_arguments(msg.arguments);
	if (iNumArgs == 2)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER1) == 0 && pcValue != NULL)
				{
					pcSourceArgs = (char **)malloc(3* sizeof(char *));
					pcTemp = tc_strtok (pcValue,":");
					remove_forward_AND_trailing_space(pcTemp);
					if(pcTemp != NULL && tc_strlen(pcTemp) > 0 )
					{
						while(pcTemp != NULL)
						{
							remove_forward_AND_trailing_space(pcTemp);
							pcSourceArgs[iSourceArgCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
							tc_strcpy(pcSourceArgs[iSourceArgCount],pcTemp);
							iSourceArgCount++;
							pcTemp = tc_strtok(NULL,":");
						}
					}
					SAFE_MEM_free(pcTemp);
					if(iSourceArgCount != 2)
					{
						iRetCode = EPM_invalid_argument_value;
						TI_sprintf(szErrorString,  "%s.",ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER1);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
						TC_write_syslog(szErrorString);
					}
				}
				else if (tc_strcasecmp(pcFlag,ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER2) == 0 && pcValue != NULL)
				{					
					pcTargetArgs = (char **)malloc(3* sizeof(char *));
					pcTemp = tc_strtok (pcValue,":");
					remove_forward_AND_trailing_space(pcTemp);
					if(pcTemp != NULL && tc_strlen(pcTemp) > 0 )
					{
						while(pcTemp != NULL)
						{
							remove_forward_AND_trailing_space(pcTemp);
							pcTargetArgs[iTargetArgCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
							tc_strcpy(pcTargetArgs[iTargetArgCount],pcTemp);
							iTargetArgCount++;
							pcTemp = tc_strtok(NULL,":");
						}
					}
					if(iTargetArgCount != 2)
					{
						iRetCode = EPM_invalid_argument_value;
						TI_sprintf(szErrorString,  "%s.",ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER2);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
						TC_write_syslog(szErrorString);
					}
				}
				else if((tc_strcasecmp(pcFlag,ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER1) == 0 || tc_strcasecmp(pcFlag,ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER2) == 0) && pcValue == NULL )
				{
					iRetCode = EPM_invalid_argument_value;
					TI_sprintf(szErrorString,  "%s.",pcFlag);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					TC_write_syslog(szErrorString);
				}
				else
				{
					//wrong argument to the handler
					iRetCode = EPM_invalid_argument;
					TI_sprintf(szErrorString, "-\"%s\".",pcFlag);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					TC_write_syslog(szErrorString);
				}
				SAFE_MEM_free(pcFlag);
				SAFE_MEM_free(pcValue);
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
    }

	if(iRetCode == ITK_ok )
	{
		if(!validateObject(pcSourceArgs[0]))
		{
				iRetCode = EPM_invalid_argument_value;
				TI_sprintf(szErrorString, "%s.",ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER1);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				TC_write_syslog(szErrorString);
		}
		if(!validateObject(pcTargetArgs[0]))
		{
				iRetCode = EPM_invalid_argument_value;
				TI_sprintf(szErrorString, "%s.",ARG_NAME_SET_ATTRIBUTE_ACTION_HANDLER2);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				TC_write_syslog(szErrorString);
		}
		if(iRetCode == ITK_ok)
			iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			//Get the target attachment.
			iRetCode = TI_GetTarget_Atts(tRootTaskTag,pcSourceArgs[0], &tSourceObject);
			if(iRetCode != ITK_ok || tSourceObject == NULLTAG)
			{				
				iRetCode = TIAUTO_OBJECT_NOT_FOUND_IN_TARGET;
				TI_sprintf(szErrorString, "Unable to find Source object \"%s\" in the workflow target attachments.",pcSourceArgs[0]);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				TC_write_syslog(szErrorString);
			}
			//Get the target attachment.
			iRetCode = TI_GetTarget_Atts(tRootTaskTag,pcTargetArgs[0], &tTargetObject);
			if(iRetCode != ITK_ok || tTargetObject == NULLTAG)
			{				
				iRetCode = TIAUTO_OBJECT_NOT_FOUND_IN_TARGET;
				TI_sprintf(szErrorString, "Unable to find Target object \"%s\" in the workflow target attachments.",pcTargetArgs[0]);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				TC_write_syslog(szErrorString);
			}
			if(iRetCode == ITK_ok)
			{
				validate = false;
				iRetCode = AOM_ask_prop_names(tSourceObject, &iCount, &pcPropNames);
				if(iRetCode == ITK_ok && pcPropNames != NULL)
				{					
					for(i = 0; i<iCount; i++)
					{
						if(tc_strcasecmp(pcPropNames[i] , pcSourceArgs[1]) == 0)
						{
							validate = true;
							break;
						}
					}
					SAFE_MEM_free(pcPropNames);
					if(!validate)
					{
						iRetCode = PROP_not_found;
						TI_sprintf(szErrorString, " \"%s\".",pcSourceArgs[1]);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
						TC_write_syslog(szErrorString);
					}
				}								
				validate = false;
				if(iRetCode == ITK_ok)
					iRetCode = AOM_ask_prop_names(tTargetObject, &iCount, &pcPropNames);
				if(iRetCode == ITK_ok && pcPropNames != NULL)
				{					
					for(i = 0; i<iCount; i++)
					{
						if(tc_strcasecmp(pcPropNames[i] , pcTargetArgs[1]) == 0)
						{
							validate = true;
							break;
						}
					}
					SAFE_MEM_free(pcPropNames);
					if(!validate)
					{						
						iRetCode = PROP_not_found;
						TI_sprintf(szErrorString, " \"%s\".",pcTargetArgs[1]);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
						TC_write_syslog(szErrorString);
					}
				}				
				validate = false;
				if(iRetCode == ITK_ok)
				{
					iRetCode = AOM_ask_value_type ( tSourceObject, pcSourceArgs[1], &sourcePropType, &pcSourcePropType ) ;
					iRetCode = AOM_ask_value_type ( tTargetObject, pcTargetArgs[1], &targetPropType, &pcTargetPropType ) ;
					if(tc_strcmp(pcSourcePropType, pcTargetPropType) == 0)
					{
					validate = true;
					}
					SAFE_MEM_free(pcSourcePropType);
					SAFE_MEM_free(pcTargetPropType);
					if(validate)
					{								
						iRetCode = AOM_UIF_ask_value  ( tSourceObject, pcSourceArgs[1], &pcPropValue ) ;
						iRetCode = AOM_refresh(tTargetObject, true);
						iRetCode = AOM_UIF_set_value  ( tTargetObject, pcTargetArgs[1], pcPropValue);
						iRetCode = AOM_save (tTargetObject);
						iRetCode = AOM_unlock (tTargetObject);
						SAFE_MEM_free(pcPropValue);
					}
				}
			}
		}
	}
	free(pcSourceArgs[0]);
	free(pcSourceArgs[1]);
	free(pcSourceArgs);
	free(pcTargetArgs[0]);
	free(pcTargetArgs[1]);
	free(pcTargetArgs);
	return iRetCode; 
}

