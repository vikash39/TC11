/*****************************************************************************************************************
FILE        :   tiauto_check_target_object.c

DESCRIPTION :   This file contains the implementation for 
                "TIAUTO-RH-check-reference-items" Custom Rule Handler. This handler
                validates release status of the item revisions present in the Reference Items folder 
				of the change revision.

              

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
June 29, 2016    1.0        Dipak Naik		 Initial Creation
*****************************************************************************************************************/
/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <lov/lov.h>

static  int check_status_of_reference_irs(tag_t   tEngChangeRev,TIA_ErrorMessage **currErrMsg);


//static int get_target_object(tag_t tTask,char *pcTargetTypeName,tag_t *tTargetObject);
/*==============================================================================
*    Implementation of RULE Handler -  t1aAUTO_check_target_object
===============================================================================*/
EPM_decision_t TIAUTO_RH_check_reference_items(EPM_rule_message_t msg)
{
    int					iRetCode									= ITK_ok;

    tag_t				tEngChangeRev								= NULLTAG;
    tag_t				tUser										= NULLTAG;
    tag_t				tTaskType									= NULLTAG;
	
	char				*pcUserName									= NULL;
	char				*pcTaskTypeName								= NULL;
	char				*pcTargetTypeName							= NULL;
    char				acErrorString[TIAUTO_error_message_len+1]	= "";
    EPM_decision_t		decision									= EPM_nogo;
	TIA_ErrorMessage	*currErrMsg									= NULL;
	TIA_ErrorMessage	*tempErrMsg									= NULL;
	
	
	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user    	
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}
    
	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,NEWCHANGE_REV);//"EngChange Revision");
	
	  
      
    /* NOW we got list of allowed statuses, so validate status of the objects(item revisions)
       to be attached to change process as targets. */
    if (iRetCode == ITK_ok) 
    {
		if(pcTargetTypeName != NULL && (tc_strcmp(NEWCHANGE_REV,pcTargetTypeName) == 0))
		{
			iRetCode = tiauto_get_newchange_item_rev (msg.task, &tEngChangeRev);
			// If there is no change item rev, just ignore further processing & exit.
			if (tEngChangeRev != NULLTAG) 
			{
				if (iRetCode == ITK_ok) 
					iRetCode = check_status_of_reference_irs (tEngChangeRev, &currErrMsg);
			}
		}
    }
    if(iRetCode != ITK_ok)
        decision = EPM_nogo;
    else
        decision = EPM_go;
	if( currErrMsg != NULL)
	{
		decision = EPM_nogo;	
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
		TI_sprintf( acErrorString, "To fix this problem, Please remove the above item revisions from the change folder."  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_ITEM_REV_INVALID_STATUS , acErrorString );
		
		while(currErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, currErrMsg->iRetCode, currErrMsg->errMsg);
			TC_write_syslog(currErrMsg->errMsg);
			TC_write_syslog("\n");

			tempErrMsg = currErrMsg;
         	currErrMsg = currErrMsg->next;
			free ( tempErrMsg ); // Free memory 
			tempErrMsg = NULL;
		}
		 
	}
    // free up allocated memory
   
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);
	//SAFE_MEM_free (currErrMsg);
    return decision;
}
/* Validating the status of item revisions in the affected and solution items folder */
static  int check_status_of_reference_irs(tag_t   tEngChangeRev,
										 TIA_ErrorMessage **currErrMsg )
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumAffected = 0;
    tag_t   *ptAffectedItems = NULL;
    char    *pszClassName = NULL;
    char    *pszAffectedItemRevObjectID = NULL;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]=""; 
	char    acObjectType[WSO_name_size_c+1]  = "";
	logical lIsDoc = false;
	tag_t tRelation = NULLTAG;

	iRetCode = GRM_find_relation_type ("CMReferences",&tRelation);
			//get the change forms
	if (iRetCode == ITK_ok && tRelation != NULLTAG)
		iRetCode = GRM_list_secondary_objects_only(tEngChangeRev,tRelation,&iNumAffected,&ptAffectedItems);
			
     
    for (indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++)
    {
		tc_strcpy(acObjectType,"");
        iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		//getting parent class if the class name is NOT ITEMREVISION
		if(iRetCode==ITK_ok && (tc_strcasecmp (pszClassName ,TIAUTO_ITEMREVISION)!= 0))
		{
					
			tag_t			tTargetType						= NULLTAG;
			tag_t			tParentType						= NULLTAG;

			if(iRetCode == ITK_ok)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType));
			}
			if(tTargetType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
			}
			if(tParentType != NULLTAG)
			{
				SAFE_MEM_free(pszClassName);
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pszClassName));
			}	
		}
		//check if the classname of the reference items is Item Revision or Document Revision
        if(((tc_strcasecmp (pszClassName,TIAUTO_ITEMREVISION)== 0) || (tc_strcasecmp (pszClassName,TIAUTO_TI_DOCUMENTREVISION)== 0)) && (iRetCode == ITK_ok) )        
        {
            iRetCode = tiauto_get_release_status (ptAffectedItems[indx], szReleaseStatus);
            if (iRetCode == ITK_ok)
            {
				lIsDoc = false;
				iRetCode = tiauto_check_if_itemType_isDOC(ptAffectedItems[indx],&lIsDoc);
									
                iRetCode = WSOM_ask_object_id_string(ptAffectedItems[indx], &pszAffectedItemRevObjectID);
                if( (lIsDoc == true) && (tc_strcmp (szReleaseStatus,"") == 0 ))
				{
					TI_sprintf(szErrorString, "Error: Document Revision - '%s' is at WIP status, which is invalid for this change process.",
                            pszAffectedItemRevObjectID); 
					tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
				}
				else if(tc_strcasecmp (szReleaseStatus,"") == 0 )
                {
                    TI_sprintf(szErrorString, "Error: Item Revision - '%s' does not have valid release status for this change process.",
                            pszAffectedItemRevObjectID); 
					tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
                }
                else if( (tc_strcasecmp (szReleaseStatus,"Study Rejected") == 0 ) || (tc_strcasecmp (szReleaseStatus,"Obsolete") == 0 )
							|| (tc_strcasecmp (szReleaseStatus,"In Process") == 0 ) )
                { 		
					TI_sprintf(szErrorString, "Error: Item Revision - '%s' is at \"%s\" status, which is invalid for this change process.",
						pszAffectedItemRevObjectID, szReleaseStatus);
					tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
							
				} 
            }
        } 
    }
	
    SAFE_MEM_free ( pszClassName );
    SAFE_MEM_free ( ptAffectedItems );
    return iRetCode;
}
