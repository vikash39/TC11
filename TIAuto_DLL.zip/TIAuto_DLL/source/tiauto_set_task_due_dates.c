/*******************************************************************************
*
* FILENAME : tiauto_set_task_due_dates.c
*
* DESCRIPTION :
*      This file contains the implementation for "TIAUTO-set-task-due-date" Custom Action Handler. 
*
*
*
* CHANGES :
*      REF NO   DATE            WHO             DETAIL
*              06/05/2007		Srikanth P		Initial Creation for TIAUTO-set-task-due-date
*              07/08/2007		Srikanth P		Added more comments and error handling code.
*
********************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>

static int parse_task_duedate_arguments(EPM_action_message_t msg,   
                                        char    **att_name,
                                        char    **form_type );



/*=====================================================================================
*    Implementation of Action Handler -  t1aAUTO_set_task_due_date
=====================================================================================*/

/************************************************************************************
* NAME :            extern int t1aAUTO_set_task_due_date(EPM_action_message_t msg)
*
* DESCRIPTION :     This handler sets the task due date as per the date values from CCR
*                   or CN Production Launch forms. If there is no date set on CCR/CN forms, 
*                   this handler does not any due date for the task. It also sets  responsible
*                   party as late recipient so that when the task past due date, responsible 
*                   party will be notified by task monitor.
*
* INPUTS :
*         
*  
* OUTPUTS :
*           PARAMETERS :
* 
*           RETURN : retcode (ITK_ok or error code ) 
*
*
*****************************************************************************/
extern int t1aAUTO_set_task_due_date(EPM_action_message_t msg)
{
    int     retcode = ITK_ok;
    int     indx = 0, result = 0;
    char    *att_name = NULL;
    char    *form_type = NULL;
    int     count = 0;
    tag_t   relation_type = NULLTAG;
    tag_t   resp_party_tag = NULLTAG;
    tag_t   *secondary_object_tags = NULL;
    tag_t   tEngChangeRev = NULLTAG;
    char    type_name[TCTYPE_name_size_c+1] = "";
    date_t  due_date = NULLDATE;
    char    szErrorString[TIAUTO_error_message_len+1]="";

    retcode = parse_task_duedate_arguments (msg, &att_name, &form_type);

    if (retcode == ITK_ok) 
    {
        retcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
        // If there is no change item rev, just ignore further processing & exit.
        if (tEngChangeRev != NULLTAG && retcode == ITK_ok) 
        {
            retcode = GRM_find_relation_type( TC_specification_rtype, &relation_type );
            if(retcode == ITK_ok)
                retcode = GRM_list_secondary_objects_only(tEngChangeRev, relation_type, 
                                                          &count, &secondary_object_tags);
        }
    }
    for (indx = 0; indx < count && retcode == ITK_ok; indx++)
    {
        retcode = tiauto_get_object_name (secondary_object_tags[indx], type_name);
        if(tc_strcasecmp( type_name , form_type)== 0 && (retcode == ITK_ok) )
        {
            retcode = AOM_ask_value_date(secondary_object_tags[indx], att_name, &due_date);
            if( retcode == ITK_ok)
                retcode = POM_compare_dates (due_date, NULLDATE, &result);
            else
            {
                TI_sprintf( szErrorString, "Could not read %s attribute from %s Form. Please verify the form and date attribute values.", form_type, att_name);
                TC_write_syslog(szErrorString);
                EMH_store_error_s1( EMH_severity_error, TIAUTO_FORM_DATE_ATTRIBUTE_READ_ERROR, szErrorString);
                retcode = TIAUTO_FORM_DATE_ATTRIBUTE_READ_ERROR;
                break; // There should be only one form of given type should be under given change item rev.

            }
            if( result != 0 && retcode == ITK_ok )
            {
                retcode = EPM_set_task_due_date(msg.task, due_date);
                if(retcode == ITK_ok)
                    retcode = EPM_ask_responsible_party (msg.task, &resp_party_tag);
                if(retcode == ITK_ok)
                    retcode = EPM_set_late_task_recipients (msg.task, 1, &resp_party_tag);
            
                break; // There should be only one form of given type should be under given change item rev.
            }
        }

    }
    
    // Cleaning up Memory.
    SAFE_MEM_free (att_name);
    SAFE_MEM_free (form_type);
    SAFE_MEM_free (secondary_object_tags);
    
    return retcode;
}

/**************************************************************************************
* NAME :            static int parse_task_duedate_arguments(EPM_action_message_t msg,   
                                                            char    **att_name,
                                                            char    **form_type )
*
* DESCRIPTION :     This static function parses the action handler arguments and returns
*                   from type and date attribute.
*
* INPUTS :  msg
*         
*  
* OUTPUTS : att_name, form_type
* 
*           RETURN : retcode (ITK_ok or error code ) 
*
*
**************************************************************************************/
static int parse_task_duedate_arguments(EPM_action_message_t msg,   
                                        char    **att_name,
                                        char    **form_type )
{
    int     retcode = ITK_ok ;
    int     indx = 0, arg_cnt = 0;
    char    *value  = NULL;
    char    *flag   = NULL;
    
    arg_cnt = TC_number_of_arguments( msg.arguments );

    if ( arg_cnt <= 1 )
        retcode = EPM_missing_req_arg;
    else if ( arg_cnt > 2 )
       retcode = EPM_wrong_number_of_arguments;
    else
    {
        for ( indx = 0; indx < arg_cnt && retcode == ITK_ok; indx++)
        {
            retcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &flag, &value );
            if ( retcode == ITK_ok ) 
            {
                if (tc_strcasecmp(flag, TIAUTO_ATTRIBUTE_NAME) == 0)
                {
                    if ( value != NULL )
                    {
                        *att_name = (char*) MEM_alloc((int)( tc_strlen(value) + 1) * sizeof(char));
                        tc_strcpy(*att_name, value);
                    }
                }
                else if (tc_strcasecmp(flag, TIAUTO_FORM_TYPE) == 0)
                {
                    if ( value != NULL )
                    {
                        *form_type = (char*) MEM_alloc((int)( tc_strlen(value) + 1) * sizeof(char));
                        tc_strcpy(*form_type, value);
                    }
                }
                else
                    retcode = EPM_invalid_argument;
            }
        }
    }
        
    // Memory clean up
    SAFE_MEM_free (flag);
    SAFE_MEM_free (value);

    return retcode;
}




