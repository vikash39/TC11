/*******************************************************************************
FILE        :   tiauto_rh_check_status_progression_stacked_change.c

DESCRIPTION :   This file contains the implementation for
                "TIAUTO-RH-check-status-progression-stacked-change" Custom Rule Handler.

                This handler validates release status of the of the all item revisions
                for correct status progression. Each progression failure item revision is 
				validated to check if the item revision is associated to any parallel on-going 
				process with same/higher target release status. There are four different types of
                status progression checks are added in this handler. 
				The handler decision will be decided based on the handler argument and the 
				progression result.                

REVISION HISTORY :

Date              Revision        Who                    Description
April 15, 2010     1.0           Dipak Naik			    Initial Creation.
August 10,2010	   1.1			 Dipak Naik				Modified the code to run the progression check
														for PMR workflow
*******************************************************************************/

/* includes */

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <tiauto_progression_check_utils.h>

// static function prototypes
static int executeProgressionCheckRule(tag_t tmsgTask, tag_t _tECRev,	char *pcReportDecision,char *pcFailDecision, 
								 char *pcTaskNameToSendMailToOwner,char *pcEndOfWarningMsg, char *pcTargetReleaseStatus,							 
							     char *pcProgressionCheckList,int iAssemblyProgCheckLevel, EPM_decision_t *decision);

EPM_decision_t TIAUTO_RH_check_status_progression_stacked_change( EPM_rule_message_t msg )
{
	int iRetCode = ITK_ok;
	int iNumArgs = 0;
	int iSkipCheck = 0;
	int i = 0;
	int iAssemblyProgCheckLevel  = -1;
	tag_t tECRev = NULLTAG;
	
	char			*pcArgName					= NULL;
	char			*pcArgValue					= NULL;
	char			*pcErrMsg					= NULL;
	char			*pcEndOfWarningMsg			= NULL;
	char			*pcReportDecision			= NULL;
	char			*pcFailDecision				= NULL;
	char			*pcTargetReleaseStatus		= NULL;
	char			*pcProgressionCheckList		= NULL; //The value can be "ALL", ItemRev, Backward, Assembly, Generic
	char			*pcTaskNameToSendMailToOwner = NULL;

	EPM_decision_t decision = EPM_nogo;

	iNumArgs = TC_number_of_arguments(msg.arguments);

	if (iNumArgs > 0)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if ( iRetCode == ITK_ok )
			{		
				if( ( iRetCode == ITK_ok ) && (pcArgName != NULL) && (pcArgValue != NULL) )
				{				
					if(tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_RULE_HANDLER) == 0)
					{
						if( tc_strcasecmp(pcArgValue, "Yes") == 0 )
						{
							iSkipCheck = 1;
						}
						else if( tc_strcasecmp(pcArgValue, "No") == 0 )
						{
							iSkipCheck = 0;
						}
						else
						{
							iRetCode = EPM_invalid_argument;
						}
					}
					else if( tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 && pcArgValue != NULL)
					{
						if( (tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
						{
							pcReportDecision = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
							tc_strcpy( pcReportDecision, pcArgValue);
						}	
						else
							iRetCode = EPM_invalid_argument;
					}
					else if( tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 && pcArgValue != NULL)
					{
						if( (tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 ) ||
							( tc_strcasecmp(pcArgValue, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 ) )
						{
							pcFailDecision = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
							tc_strcpy( pcFailDecision, pcArgValue);
						}	
						else
							iRetCode = EPM_invalid_argument;
					}
					else if (tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 && pcArgValue != NULL)
					{
						//The value of the argument "notification" will have the task name,
						//we need to send an email to the owner of that task 
						pcTaskNameToSendMailToOwner = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
						tc_strcpy( pcTaskNameToSendMailToOwner, pcArgValue);					
					}
					else if (tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 && pcArgValue != NULL)
					{
						pcEndOfWarningMsg = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
						tc_strcpy( pcEndOfWarningMsg, pcArgValue);
					}
					else if (tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 && pcArgValue != NULL)
					{
						pcTargetReleaseStatus = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
						tc_strcpy( pcTargetReleaseStatus, pcArgValue);
					}
					else if (tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 && pcArgValue != NULL)
					{
						pcProgressionCheckList = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
						tc_strcpy( pcProgressionCheckList, pcArgValue);
					}
					else if (tc_strcasecmp(pcArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER7) == 0 && pcArgValue != NULL)
					{
						if(tc_strcasecmp(pcArgValue,"All") == 0)
						{
							iAssemblyProgCheckLevel = -1;
						}
						else
						{
							iAssemblyProgCheckLevel = atoi(pcArgValue);
						}
					}
					else
					{
						iRetCode = EPM_invalid_argument;
					}
				}			
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	//to check whether mandatory attributes are parsed or not
    if( (iRetCode == ITK_ok) && ((pcFailDecision == NULL)|| (pcEndOfWarningMsg == NULL) ) )
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}

	if ( iRetCode == ITK_ok )
	{
		//If iSkipCheck is 1, then exit from this handler with EPM_go
		if ( iSkipCheck == 1 )
		{
			decision = EPM_go;
		}
		else if(iSkipCheck == 0)
		{			
			iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
			if ( (iRetCode == ITK_ok) && (tECRev != NULLTAG) )
			{
				//Call the static function to execute the handler to do the Progression Check
				 iRetCode = executeProgressionCheckRule(msg.task,tECRev,pcReportDecision,pcFailDecision,
														pcTaskNameToSendMailToOwner,pcEndOfWarningMsg, 
														pcTargetReleaseStatus,pcProgressionCheckList,
														iAssemblyProgCheckLevel,&decision);
			}
		}
	}	

	if ( iRetCode != ITK_ok && iRetCode != EPM_invalid_argument_value)
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}

	SAFE_MEM_free (pcArgName);
	SAFE_MEM_free (pcArgValue);
	SAFE_MEM_free (pcReportDecision);
	SAFE_MEM_free (pcFailDecision);
	SAFE_MEM_free (pcEndOfWarningMsg);
	SAFE_MEM_free (pcTargetReleaseStatus);
	SAFE_MEM_free (pcProgressionCheckList);
	SAFE_MEM_free(pcTaskNameToSendMailToOwner);

	return decision;
}


 int executeProgressionCheckRule(tag_t tmsgTask, tag_t _tECRev,	char *pcReportDecision,char *pcFailDecision, 
								 char *pcTaskNameToSendMailToOwner, char *pcEndOfWarningMsg, 
								 char	*pcTargetReleaseStatus,char *pcProgressionCheckList,							 
							     int iAssemblyProgCheckLevel, EPM_decision_t *decision )
{
    int iRetCode = ITK_ok;
    int indx = 0;
	int iNumAffected = 0;
	int iError = 0;
	int	iPopulateErrMsgInStack = 1;			
	int	iPopulateWarningMsgInStack = 1;	
	int	iTargetArgCount	= 0;
	int iFileOpenErrCode = 0;

	logical     lIsItemRevProgCheckRequired					= false;
	logical     lIsBackwardProgCheckRequired				= false;
	logical     lIsAssemblyProgCheckRequired				= false;
	logical     lIsGenericProgCheckRequired					= false;
	logical     lIsErrorPresent								= false;
	logical		lIsWarningPresent							= false;
	logical     lIsWriteToAuditFile							= false;
	
	tag_t		tAttribute									= NULLTAG;
	tag_t		tFormType									= NULLTAG;
	tag_t		tRootTask									= NULLTAG;
	tag_t		tUser										= NULLTAG;
	tag_t		*ptAffectedItems = NULL;
	char		acChnId[ITEM_id_size_c+1]					= {'\0'};
	char		acChnRevId[ITEM_id_size_c+1]				= {'\0'};
	char		acChnName[ITEM_name_size_c+1]				= {'\0'};
	char		acCurrentTaskName[WSO_name_size_c+1]		= {'\0'};
	char		acRootTaskName[WSO_name_size_c+1]			= {'\0'};
    char        szErrorString[TIAUTO_error_message_len+1]	= "";
	char		*pszClassName								= NULL;   
    char		*pcComments									= NULL;
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	char		*pcFormClassName							= NULL;
	char		*pcFormTypeName								= NULL;
	char		*pcAttributeName							= NULL;
	char		**pcTargetArgsTemp							= NULL;
	char		*pcTemp										= NULL;

	FILE		*fMailBodyFile								= NULL;
	//txt_t		the_text_server								= NULL;

    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;	

	TIA_ErrorMessage *backwordProgErrMsgStack = NULL;
	TIA_ErrorMessage *itemRevProgErrMsgStack = NULL;
	TIA_ErrorMessage *assemblyProgWarningMsgStack = NULL;
	TIA_ErrorMessage *assemblyProgErrMsgStack = NULL;
	TIA_ErrorMessage *genericProgWarningMsgStack = NULL;
	TIA_ErrorMessage *genericProgErrMsgStack = NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectErrMsgStack = NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectWarningMsgStack = NULL;

	*decision = EPM_nogo;
	if(pcProgressionCheckList == NULL)
	{
		lIsItemRevProgCheckRequired	= true;
		lIsBackwardProgCheckRequired = true;
		lIsAssemblyProgCheckRequired = true;
		lIsGenericProgCheckRequired	= true;
	}
	else if(iRetCode == ITK_ok)
	{
		if(strstr(pcProgressionCheckList,"All") != NULL)
		{
			lIsItemRevProgCheckRequired	= true;
			lIsBackwardProgCheckRequired = true;
			lIsAssemblyProgCheckRequired = true;
			lIsGenericProgCheckRequired	= true;
		}
		if(strstr(pcProgressionCheckList,"ItemRev") != NULL)
		{
			lIsItemRevProgCheckRequired	= true;
		}
		if(strstr(pcProgressionCheckList,"Backward") != NULL)
		{			
			lIsBackwardProgCheckRequired = true;
		}
		if(strstr(pcProgressionCheckList,"Assembly") != NULL)
		{
			lIsAssemblyProgCheckRequired = true;
		}
		if(strstr(pcProgressionCheckList,"Generic") != NULL)
		{
			lIsGenericProgCheckRequired	= true;
		}
	}
	
	tiauto_initialize_status_progression_stuct(&StatusProgression);
    iRetCode = tiauto_get_status_progression_array (&StatusProgression);

    if (iRetCode == ITK_ok)
    { 	
		if(pcTargetReleaseStatus == NULL)
		{
			//In case if this argument value is null then the target status will be read from
			//the ERC form. (In case of old CR and CRB, this argument is not parsed. so the value will be read
			//				  from the ECR form)
			iRetCode = tiauto_get_target_release_status( _tECRev, TargetReleaseStatus.szTargetReleaseStatus);
		}
		else
		{
			pcTargetArgsTemp = (char **)malloc(10* sizeof(char *));
			//In case of CR/CRB/PMR worflow the argument value willl be
			// Form:<Form type name>:<form attribute name that contaions the target status name>
			pcTemp = tc_strtok (pcTargetReleaseStatus,":");
			//to remove the forward and trailing space
			remove_forward_AND_trailing_space(pcTemp);
			if(tc_strcmp(pcTemp,"Form") == 0)
			{
				while(pcTemp != NULL)
				{
					//to remove the forward and trailing space
					remove_forward_AND_trailing_space(pcTemp);
										
					pcTargetArgsTemp[iTargetArgCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcTargetArgsTemp[iTargetArgCount],pcTemp);			
					iTargetArgCount++;					
					pcTemp = tc_strtok(NULL,":");
				}
			}
			//In case of CR/CRB/PMR worflow
			if(iTargetArgCount == 3)
			{
				//form class name i.e. "Form"
				pcFormClassName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[0])+1);
				tc_strcpy(pcFormClassName,pcTargetArgsTemp[0]);
				//form type name
				pcFormTypeName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[1])+1);
				tc_strcpy(pcFormTypeName,pcTargetArgsTemp[1]);
				//form attribute name
				pcAttributeName = (char *)malloc((int)tc_strlen(pcTargetArgsTemp[2])+1);
				tc_strcpy(pcAttributeName,pcTargetArgsTemp[2]);
				
				if(pcTargetArgsTemp != NULL)
				{
					free(pcTargetArgsTemp);
					pcTargetArgsTemp = NULL;
				} 
				//check the argument values are correct or not i.e. form type and attribute name
				iRetCode = TCTYPE_find_type (pcFormTypeName,"Form",&tFormType);
				if(iRetCode == ITK_ok && tFormType != NULLTAG)
				{
					iRetCode = TCTYPE_ask_property_by_name (tFormType,pcAttributeName,&tAttribute);
					if(iRetCode == 38015 || tAttribute == NULLTAG)
					{
						iRetCode = EPM_invalid_argument_value;
						EMH_store_error_s1( EMH_severity_error, EPM_invalid_argument_value, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) ;
					}
				}
				else if(iRetCode == ITK_ok && tFormType == NULLTAG)
				{
					iRetCode = EPM_invalid_argument_value;
					EMH_store_error_s1( EMH_severity_error, EPM_invalid_argument_value, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) ;
				}
				//get the target release status from the given form
				if(iRetCode == ITK_ok)
					iRetCode = tiauto_get_Form_attribute_value_of_ItemRev(_tECRev,pcFormTypeName, pcAttributeName,
																		TargetReleaseStatus.szTargetReleaseStatus);
			}
			//In case of DAP, the target status will be "Study Approved"
			else if(iTargetArgCount == 0)
			{	
				//check the argument values are correct or not i.e. status type
				tFormType = NULLTAG;
				iRetCode = CR_find_status_type  (pcTargetReleaseStatus,&tFormType);
				if(iRetCode == ITK_ok && tFormType != NULLTAG)
				{
					tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus, pcTargetReleaseStatus);
				}
				else if(iRetCode == ITK_ok && tFormType == NULLTAG)
				{
					iRetCode = EPM_invalid_argument_value;
					EMH_store_error_s1( EMH_severity_error, EPM_invalid_argument_value, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) ;
				}
			}
			else
			{
				iRetCode = EPM_invalid_argument_value;
				EMH_store_error_s1( EMH_severity_error, EPM_invalid_argument_value, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER5) ;				
			}
			if(pcFormClassName != NULL)
			{
				free(pcFormClassName);
				pcFormClassName = NULL;
			}
			if(pcFormTypeName != NULL)
			{
				free(pcFormTypeName);
				pcFormTypeName = NULL;
			}
			if(pcAttributeName != NULL)
			{
				free(pcAttributeName);
				pcAttributeName = NULL;
			}
			if(iRetCode != ITK_ok)
			{				 
				return iRetCode;
			}
		}

		if(iRetCode == ITK_ok)
		{
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			if (TargetReleaseStatus.iLevel == -1)
			{
				TI_sprintf(szErrorString, "%s",TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT);
				iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
				EMH_store_error_s1( EMH_severity_error, iRetCode, 
					                szErrorString) ;
				TC_write_syslog(szErrorString);
			}
		}
		else
		{
			TI_sprintf(szErrorString, "Failed to verify Target Release Status with the site Preference \"TI_Progression_Path\".");
			EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
			TC_write_syslog(szErrorString);
		}
	}

	if (iRetCode == ITK_ok)
    {
		iRetCode = ECM_get_affected_items(_tECRev, &iNumAffected, &ptAffectedItems);
	}
	//get the root task
	if (iRetCode == ITK_ok )
		iRetCode = EPM_ask_root_task(tmsgTask , &tRootTask);
	//get the root task name
	if (iRetCode == ITK_ok  && tRootTask != NULLTAG)
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );

	for (indx = 0; (indx < iNumAffected) && (iRetCode == ITK_ok); indx++)
	{	
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		
		if((iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "Dataset")!= 0 )&& (tc_strcasecmp (pszClassName , "ItemRevision")!= 0 ))
		{
			tag_t tTargetType = NULLTAG;
			tag_t	tParentType					= NULLTAG;
			TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType));
			if(tTargetType != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));

			if(tParentType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pszClassName));
			}					
			
		}

		if((iRetCode == ITK_ok)  &&( (tc_strcasecmp (pszClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pszClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
        {
			if(lIsBackwardProgCheckRequired == true)
			{
				//Backward progression check 	 
				iRetCode = ti_check_for_backward_progression ( ptAffectedItems[indx],ptAffectedItems, iNumAffected, StatusProgression, 
															   TargetReleaseStatus, iPopulateErrMsgInStack,
																&iError, &backwordProgErrMsgStack );
			}
		
			if ( iRetCode == ITK_ok && lIsItemRevProgCheckRequired == true)
			{
				//item revision progression
				iRetCode = ti_check_for_item_revision_progression ( ptAffectedItems[indx], StatusProgression, 
															   TargetReleaseStatus, iPopulateErrMsgInStack, 
															   &iError, &itemRevProgErrMsgStack );
							
			}
			if ( iRetCode == ITK_ok && lIsAssemblyProgCheckRequired == true)
			{
				//assembly progression
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					iRetCode = ti_check_for_assembly_progression_pci( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															  StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														      iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															  acRootTaskName,iAssemblyProgCheckLevel, &iError, 
														      &assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
				}
				else
					iRetCode = ti_check_for_assembly_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															  StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														      iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															  acRootTaskName,iAssemblyProgCheckLevel, &iError, 
														      &assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
							
			}
			if ( iRetCode == ITK_ok && lIsGenericProgCheckRequired == true)
			{
				//generic progression
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					iRetCode = ti_check_for_generic_progression_pci( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														     StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														     iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															 acRootTaskName,&iError, 
														     &genericProgWarningMsgStack, &genericProgErrMsgStack);
				}
				else
					iRetCode = ti_check_for_generic_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														     StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														     iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															 acRootTaskName,&iError, 
														     &genericProgWarningMsgStack, &genericProgErrMsgStack);
			
			}
			if ( iRetCode == ITK_ok )
			{
				//Master Drawing Reference linked object status check
				if(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation") == 0)
				{
					/*iRetCode = ti_Verify_MasterDrawingReferenceLinkedObjectStatus_pci( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression, TargetReleaseStatus,
																				iPopulateErrMsgInStack,&iError,
																				&masterDrawingReferenceObjectErrMsgStack);*/
				}
				else
				{
					iRetCode = ti_Verify_MasterDrawingReferenceLinkedObjectStatus( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression,
						                                                           TargetReleaseStatus,iPopulateWarningMsgInStack, iPopulateErrMsgInStack, &iError,
																				   &masterDrawingReferenceObjectWarningMsgStack, &masterDrawingReferenceObjectErrMsgStack,pcEndOfWarningMsg,0);
				}
			}
		}
	}
	if(iRetCode == ITK_ok )
	{
		if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
			(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL) || (masterDrawingReferenceObjectErrMsgStack != NULL))
		{
			lIsErrorPresent = true;
		}
		if((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL)|| (masterDrawingReferenceObjectWarningMsgStack != NULL))
		{
			lIsWarningPresent = true;
		}
	}

	//to take the task decision: ERM_go or EPM_nogo
	if(iRetCode == ITK_ok )
	{
		if(	tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{			
			if(lIsErrorPresent == true)
			{
				*decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			if(lIsWarningPresent == true)
			{
				*decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if(lIsWarningPresent == false && lIsErrorPresent == true  )
			{
				*decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if(lIsErrorPresent == false && lIsWarningPresent == true  )
			{
				*decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			if(lIsErrorPresent == true || lIsWarningPresent == true  )
			{
				*decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}
		else if(tc_strcasecmp(pcFailDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if(lIsErrorPresent == true && lIsWarningPresent == true  )
			{
				 *decision = EPM_nogo;
			}
			else
			{
				*decision = EPM_go;
			}
		}		
	}
	if( (iRetCode == ITK_ok) && (*decision == EPM_nogo )&& 
		(lIsErrorPresent == false) && (lIsWarningPresent == false) )
	{
		*decision = EPM_go;
	}
	//for sending mail
	if(iRetCode == ITK_ok && lIsErrorPresent == false && (*decision == EPM_go ))
	{	
		
		if( (pcTaskNameToSendMailToOwner != NULL) &&
			((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) || (masterDrawingReferenceObjectWarningMsgStack != NULL)) )
		{
			TIA_ErrorMessage *tempErrMsg = NULL;				
			if(iRetCode == ITK_ok && tRootTask != NULLTAG)
			{				
				iRetCode = tiauto_getUser(tRootTask,pcTaskNameToSendMailToOwner,&tUser);
			}
			if(iRetCode == ITK_ok && tUser != NULLTAG)
			{
				iRetCode = EPM_get_user_email_addr  (  tUser,&pcEmailId )  ;
			}				
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				/* Initialize TextServer here */
				//the_text_server = txt_ctor( "iman_text.xml" );
				//pcMsgName = "User_Comments";
				//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
				/* release text server object here...*/
				//txt_destructor(the_text_server);
			}
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
				iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
			}
			if(iRetCode == ITK_ok &&  tUser != NULLTAG)
			{
				//start of e-mail body
				iRetCode = tiauto_getItemRevDetails(_tECRev, acChnId, acChnRevId, acChnName);
				if(iRetCode == ITK_ok)
					iRetCode = EPM_ask_name(tmsgTask, acCurrentTaskName);
				
				if( iRetCode == ITK_ok) 
				{
					if(tc_strcasecmp(acRootTaskName,"6_00 DAP - Design Approval")==0)
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,acCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_DAP,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_DAP);
					}
					else if(tc_strcasecmp(acRootTaskName,"9_00 CRO - Cad Release Only")==0)
					{
						fprintf(fMailBodyFile,"\n%s \"%s\"%s \"%s\" %s %s\n\n%s \"%s\".\n",
											TIAUTO_BODY_OF_EMAIL_TEXT1,acCurrentTaskName, 
											TIAUTO_BODY_OF_EMAIL_TEXT2,TIAUTO_BODY_OF_EMAIL_TASK_CRO,
											TIAUTO_BODY_OF_EMAIL_TEXT3,TIAUTO_BODY_OF_EMAIL_TEXT4,
											TIAUTO_BODY_OF_EMAIL_TEXT6,TIAUTO_BODY_OF_EMAIL_TASK_CRO);
					}
				}
				if(iRetCode == ITK_ok)
				{
					fprintf(fMailBodyFile,"\n\nWARNING MESSAGES:\n");
					tempErrMsg = assemblyProgWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
					tempErrMsg = genericProgWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
					tempErrMsg = masterDrawingReferenceObjectWarningMsgStack;
					while(tempErrMsg != NULL)
					{
						fprintf(fMailBodyFile," %s\n\n", tempErrMsg->errMsg );
						tempErrMsg = tempErrMsg->next;
					}
				}   
				//end of e-mail body
			}
			if(fMailBodyFile != NULL &&  tUser != NULLTAG)
			{
				fclose(fMailBodyFile);
			}
			//mail subject
			TI_sprintf(szErrorString, "WARNING : %s/%s-%s(%s)",acChnId, acChnRevId, acChnName, 
				                                acCurrentTaskName);
			//send mail
			if(pcEmailId != NULL)
				iRetCode = tiauto_sendEMail(szErrorString, pcEmailId, pcMailBodyFileName);
		}		
	}
	//to take decision  whether to write to the audit file or not
	if( (iRetCode == ITK_ok) && (*decision == EPM_go ) && (pcReportDecision != NULL) &&
		( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
		  (assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL)||
		  (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) || (masterDrawingReferenceObjectErrMsgStack != NULL) || (masterDrawingReferenceObjectWarningMsgStack != NULL)) )
	{
		
		if(	tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER1) == 0 )
		{
			tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
			assemblyProgWarningMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
			genericProgWarningMsgStack = NULL;
			tiauto_clearErrorMsgStack(masterDrawingReferenceObjectWarningMsgStack);
			genericProgWarningMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER2) == 0 )
		{
			tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
			backwordProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
			itemRevProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
			assemblyProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(genericProgErrMsgStack);
			genericProgErrMsgStack = NULL;
			tiauto_clearErrorMsgStack(masterDrawingReferenceObjectErrMsgStack);
			masterDrawingReferenceObjectErrMsgStack = NULL;
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER3) == 0 )
		{
			if( lIsWarningPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 )
		{
			if( lIsErrorPresent == true )
			{
				lIsWriteToAuditFile = false;
			}
			else
				lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER5) == 0 )
		{
			lIsWriteToAuditFile = true;
		}
		else if(tc_strcasecmp(pcReportDecision, ARG_VALUE_PROGRESSION_CHECK_ACTION_HANDLER6) == 0 )
		{
			if( ( lIsWarningPresent == true) && (lIsErrorPresent == true) )
			{
				lIsWriteToAuditFile = true;
			}
			else
			{
				lIsWriteToAuditFile = false;
			}
		}
		// Writing progression failure reasons in the workflow Audit File
		if(lIsWriteToAuditFile == true)
		{
			ti_writeErrorsMsgToAuditFile(tmsgTask,backwordProgErrMsgStack,itemRevProgErrMsgStack,
											      assemblyProgErrMsgStack,genericProgErrMsgStack,
									              assemblyProgWarningMsgStack,genericProgWarningMsgStack,
												  masterDrawingReferenceObjectWarningMsgStack,masterDrawingReferenceObjectErrMsgStack);
		}
	}
	else if ((*decision == EPM_go ) && (backwordProgErrMsgStack == NULL) && (itemRevProgErrMsgStack == NULL) &&
		 (assemblyProgErrMsgStack == NULL) && (genericProgErrMsgStack == NULL)&&
		 (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) && (masterDrawingReferenceObjectErrMsgStack != NULL) && (masterDrawingReferenceObjectWarningMsgStack != NULL))
	{
		ti_writeSuccessMsgToAuditFile( tmsgTask);
			EMH_clear_errors();
	}
	//for displaying the error and warning message
	if ((iRetCode == ITK_ok) && (*decision == EPM_nogo ) )
	{
		//if any of these warning messages are there, print them and wait		
		if(lIsWarningPresent == true)
		{
			if(genericProgWarningMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;
				while( genericProgWarningMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, genericProgWarningMsgStack->iRetCode, 
										genericProgWarningMsgStack->errMsg );
					TC_write_syslog(genericProgWarningMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = genericProgWarningMsgStack;
         			genericProgWarningMsgStack = genericProgWarningMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				genericProgWarningMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of Generic Progression WARNING******* ");
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_WARNING,szErrorString);
			}
			if(assemblyProgWarningMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;
				while( assemblyProgWarningMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, assemblyProgWarningMsgStack->iRetCode, 
										assemblyProgWarningMsgStack->errMsg );
					TC_write_syslog(assemblyProgWarningMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = assemblyProgWarningMsgStack;
         			assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				assemblyProgWarningMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of Assembly Progression WARNING******* ");
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ASSEMBLY_WARNING,szErrorString);
			}
			if(masterDrawingReferenceObjectWarningMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;

				TI_sprintf(szErrorString,"\n\nPlease add the Master Drawing revision to current change folder or remove it from the Master Drawing refernce of Product Revision Master Form");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);

				while( masterDrawingReferenceObjectWarningMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, masterDrawingReferenceObjectWarningMsgStack->iRetCode, 
										masterDrawingReferenceObjectWarningMsgStack->errMsg );
					TC_write_syslog(masterDrawingReferenceObjectWarningMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = masterDrawingReferenceObjectWarningMsgStack;
         			masterDrawingReferenceObjectWarningMsgStack = masterDrawingReferenceObjectWarningMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				masterDrawingReferenceObjectWarningMsgStack = NULL;

				TI_sprintf(szErrorString,"\n********Start of Master Drawing Reference linked Item Revision status check WARNING********");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);
			}
			TI_sprintf(szErrorString,"\n\n************************WARNING MESSAGES*********************** ");
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_WARNING,szErrorString);
		}
		if(lIsErrorPresent == true)
		{	
			if(genericProgErrMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;
				while( genericProgErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, genericProgErrMsgStack->iRetCode, 
										genericProgErrMsgStack->errMsg );
					TC_write_syslog(genericProgErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = genericProgErrMsgStack;
         			genericProgErrMsgStack = genericProgErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				genericProgErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of Generic Progression ERROR*******");
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_ERROR,szErrorString);
			}
			if(assemblyProgErrMsgStack != NULL)
			{				
				TIA_ErrorMessage *tempErrMsg = NULL;
				while( assemblyProgErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, assemblyProgErrMsgStack->iRetCode, 
										assemblyProgErrMsgStack->errMsg );
					TC_write_syslog(assemblyProgErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = assemblyProgErrMsgStack;
         			assemblyProgErrMsgStack = assemblyProgErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				assemblyProgErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of Assembly Progression ERROR********");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ASSEMBLY_ERROR,szErrorString);
			}			
			if(itemRevProgErrMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;
				while( itemRevProgErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, itemRevProgErrMsgStack->iRetCode, 
										itemRevProgErrMsgStack->errMsg );
					TC_write_syslog(itemRevProgErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = itemRevProgErrMsgStack;
         			itemRevProgErrMsgStack = itemRevProgErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				itemRevProgErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of ItemRev Progression ERROR********");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);
			}		
			if(backwordProgErrMsgStack != NULL)
			{				
				TIA_ErrorMessage *tempErrMsg = NULL;				
				while( backwordProgErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, backwordProgErrMsgStack->iRetCode, 
										backwordProgErrMsgStack->errMsg );
					TC_write_syslog(backwordProgErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = backwordProgErrMsgStack;
         			backwordProgErrMsgStack = backwordProgErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				backwordProgErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Start of Backward Progression ERROR*********");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_BACKWARD_ERROR,szErrorString);
			}
			if(masterDrawingReferenceObjectErrMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;

				TI_sprintf(szErrorString,"\n\nPlease add the Master Drawing revision to current change folder or remove it from the Master Drawing refernce of Product Revision Master Form");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);

				while( masterDrawingReferenceObjectErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, masterDrawingReferenceObjectErrMsgStack->iRetCode, 
										masterDrawingReferenceObjectErrMsgStack->errMsg );
					TC_write_syslog(masterDrawingReferenceObjectErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = masterDrawingReferenceObjectErrMsgStack;
         			masterDrawingReferenceObjectErrMsgStack = masterDrawingReferenceObjectErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				masterDrawingReferenceObjectErrMsgStack = NULL;

				TI_sprintf(szErrorString,"\n********Start of Master Drawing Reference linked Item Revision status check ERROR********");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);
			}
			TI_sprintf(szErrorString,"************************ERROR MESSAGES*********************** ");
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_WARNING,szErrorString);
		}

	}	

	//free up allocated memory
    SAFE_MEM_free (StatusProgression.StatusArray);
	SAFE_MEM_free(ptAffectedItems);
	SAFE_MEM_free(pcComments);
	SAFE_MEM_free(pcEmailId);
	tiauto_clearErrorMsgStack(backwordProgErrMsgStack);	
	backwordProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(itemRevProgErrMsgStack);
	itemRevProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgErrMsgStack);
	assemblyProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgErrMsgStack);
	genericProgErrMsgStack = NULL;
	tiauto_clearErrorMsgStack(assemblyProgWarningMsgStack);
	assemblyProgWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(genericProgWarningMsgStack);
	genericProgWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(masterDrawingReferenceObjectWarningMsgStack);
	masterDrawingReferenceObjectWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(masterDrawingReferenceObjectErrMsgStack);
	masterDrawingReferenceObjectErrMsgStack = NULL;
	remove(pcMailBodyFileName);
	
    return iRetCode;
}
																	
