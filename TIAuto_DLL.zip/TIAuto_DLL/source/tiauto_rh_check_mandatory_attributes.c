/***********************************************************************************************************************************************
FILE        :   TIAUTO_check_mandatry_attribute_state.c
Details     :   This handler perform check weather all the mandatory atriutes of affected programs Item revision master forms are filled or not.

REVISION HISTORY :
------------------------------------------------------------------------------------------------------------------------------------
Date              Revision        Who						Description
------------------------------------------------------------------------------------------------------------------------------------
June  13, 2012     1.0			  Mahesh BS					Initial Creation.
Aug	  23, 2012	   1.0			  Dipak Naik				Modfied to work for the reform-signoff task as well
************************************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

static int Validate_IR_Master_form_mandatory_Attributes(tag_t	tItemRev,EPM_decision_t *decision)
{
	int				inx = 0;
	int				iny = 0;
	int				iNumProp = 0;
	int				iNumForm = 0;
	int				iRetCode = ITK_ok;
	char			acTypeName[TCTYPE_name_size_c+1]="";
	char			**ptProp_names = NULL;
	char			*pcPropReq = NULL;
	char			acItem_id[ITEM_id_size_c+1]=""; 
	char			acRev_id[ITEM_id_size_c+1]=""; 
    char			acTempError[TIAUTO_error_message_len+1]= "";
	tag_t			tType = NULL_TAG;
	tag_t			tItem = NULL_TAG;
	tag_t			tRelType = NULL_TAG;
	tag_t			*ptForms = NULL;
	logical			lPropEmpty = true;
	char			*pcAttrDisplayName = NULL;
	//Get Item revision master forms of affected and solution items folder
	iRetCode = GRM_find_relation_type ( "IMAN_master_form",&tRelType);
	if(iRetCode == ITK_ok )
		iRetCode = GRM_list_secondary_objects_only (tItemRev,tRelType,&iNumForm, &ptForms);
	for (inx = 0; inx < iNumForm && (iRetCode == ITK_ok); inx++)
	{
		iRetCode = TCTYPE_ask_object_type  (ptForms[inx],&tType);
		if(iRetCode == ITK_ok )
			iRetCode = TCTYPE_ask_name  (tType,acTypeName);  
		if(iRetCode == ITK_ok )
			iRetCode = AOM_ask_prop_names(ptForms[inx],&iNumProp,&ptProp_names); 									
		//Check Required Item revision master form property filled or not 
		for(iny = 0; iny < iNumProp && (iRetCode == ITK_ok); iny++)
		{
			iRetCode = CONSTANTS_get_property_constant_value( PROPERTY_CONST_REQUIRED,acTypeName,ptProp_names[iny], &pcPropReq); 
			if(iRetCode == ITK_ok && tc_strcasecmp(pcPropReq,"true")== 0 )
			{
				iRetCode = AOM_is_null_empty(ptForms[inx],  ptProp_names[iny],true,&lPropEmpty);
				if(iRetCode == ITK_ok && lPropEmpty==true)
				{
					iRetCode = ITEM_ask_item_of_rev  (tItemRev,&tItem);
					if(iRetCode == ITK_ok)
						iRetCode = ITEM_ask_id  (tItem,acItem_id); 
					if(iRetCode == ITK_ok)
						iRetCode = ITEM_ask_rev_id  (tItemRev,acRev_id); 
					if(iRetCode == ITK_ok)
						iRetCode = AOM_UIF_ask_name  ( ptForms[inx], ptProp_names[iny],  &pcAttrDisplayName ) ;
					if(iRetCode == ITK_ok && pcAttrDisplayName != NULL)
					{
						*decision = EPM_nogo;
						acTempError[0]='\0';
						TI_sprintf( acTempError,"Fill the property \"%s\" value of Item Revision Master Form \"%s/%s\"\n",pcAttrDisplayName,acItem_id,acRev_id);
						EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY,acTempError);																							
					}
					SAFE_MEM_free(pcAttrDisplayName);
				}
			}
			SAFE_MEM_free(pcPropReq);
		}
		SAFE_MEM_free(ptProp_names);
	}
	SAFE_MEM_free(ptForms);
	return iRetCode;
}
//main method
EPM_decision_t TIAUTO_RH_check_mandatory_attributes(EPM_rule_message_t msg)
{
	int				iArg = 0;
	int				iAttach = 0;
	int				iOption = 0;
	int				iRevIndx = 0;
	int				iNumArgs = 0;
	int				iAffCntr = 0;
	int				iRevCount = 0;
	int				iAttchCntr = 0;
	int				iNumAffected = 0;
	int				iRelNameCount = 0;
    int				iRetCode = ITK_ok;
	int				iNumAttachments = 0;
    char			*pcFlag = NULL;
	char			*pcTemp = NULL;
	char			*pcValue = NULL;
	char			*szErrMsg = NULL;
	char			*pcTarget = NULL;
	char			*pcRelation = NULL;
	char			*pcClassName = NULL;
	char			*pcTaskTypeName = NULL;
	char			*pcUserName = NULL;
	char			acErrorString[512] = "";
	char			*pcPseudoFolderName	= NULL;	
	char			**pcRelationNames = NULL;
	tag_t			*ptRevList = NULL;
	tag_t			tRelation = NULL_TAG;
	tag_t			tUser = NULL_TAG;
	tag_t			tTaskType = NULLTAG;
	tag_t			tRootTask = NULLTAG;
	tag_t			*ptAttachments = NULL;
	tag_t			tEngChangeRev = NULL_TAG;	
	tag_t			*ptAffectedObjects = NULL;
	EPM_decision_t	decision = EPM_go;	
	tag_t tDescriptor = NULLTAG;
	
	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask);	
		if ( iRetCode==ITK_ok && tRootTask!=NULLTAG )
		{
			//get input arguments
			iNumArgs = TC_number_of_arguments(msg.arguments);
			if(iNumArgs>0)
			{
				for(iArg = 0; (iArg < iNumArgs) && (iRetCode==ITK_ok) ; iArg++)
				{
					iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue);
					if(iRetCode == ITK_ok)
					{					
						if( tc_strcasecmp(pcFlag, "target") == 0 && pcValue != NULL)
						{
							pcTarget = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
							tc_strcpy( pcTarget, pcValue);
							if( (tc_strcmp(pcTarget,CHANGE_REV)==0) || (tc_strcmp(pcTarget,NEWCHANGE_REV)==0) )
							{
								iOption=1;
							}
							else if(tc_strcmp(pcTarget,"Item Revision")==0)
							{
								iOption=2;
							}
							else
							{
								iRetCode = EPM_invalid_argument_value;
							}
						}
						else if( tc_strcasecmp(pcFlag, "folder") == 0) 
						{
							if(pcValue != NULL)
							{
								pcRelation = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
								tc_strcpy( pcRelation, pcValue);
							}
							else
							{
								iRetCode = EPM_invalid_argument_value;
							}
						}
						else
						{
							iRetCode = EPM_invalid_argument;
						}
					}
					SAFE_MEM_free(pcFlag);
					SAFE_MEM_free(pcValue);
				}
			}
			else
			{
				iRetCode = EPM_invalid_argument;
			}
			//get the targeted object
			if(iRetCode == ITK_ok)
			{
				if(iOption==1)
				{
					//get the targeted change revision
					iRetCode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
					if(iRetCode == ITK_ok && tEngChangeRev && pcRelation != NULL)
					{
						pcRelationNames = (char **)malloc(10* sizeof(char *));			
						pcTemp = tc_strtok (pcRelation,",");
						while(pcTemp != NULL && iRetCode == ITK_ok)
						{
							//validate the input argument value				
							iRetCode = AOM_ask_descriptor (tEngChangeRev,pcTemp,&tRelation);
							if(iRetCode == ITK_ok && tRelation != NULLTAG)
							{
								pcRelationNames[iRelNameCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
								tc_strcpy(pcRelationNames[iRelNameCount],pcTemp);			
								iRelNameCount++;					
								pcTemp = tc_strtok(NULL,",");
							}
							else
							{
								iRetCode = EPM_invalid_argument_value;
								TI_sprintf(acErrorString, "Invalid argument value parsed to the argument \"folder\".");
								EMH_store_error_s1( EMH_severity_error, iRetCode, acErrorString) ;						
								TC_write_syslog(acErrorString);
								decision = EPM_nogo;
								break;
							}
						}
						//get all the objects present in the pseudo folder of the targeted change revision based on relation
						for(iAttchCntr = 0; (iAttchCntr < iRelNameCount) && (iRetCode == ITK_ok); iAttchCntr++)
						{
							tRelation = NULLTAG;
							iNumAffected = 0;
							//iRetCode = PROPDESC_ask_display_name_by_name  (pcRelationNames[iAttchCntr],&pcPseudoFolderName);
							tDescriptor = NULLTAG;
								iRetCode = AOM_ask_descriptor (tEngChangeRev,pcRelationNames[iAttchCntr],&tDescriptor);
								if(tDescriptor != NULLTAG)
									iRetCode = PROPDESC_ask_display_name  (tDescriptor,&pcPseudoFolderName);

							if( iRetCode == ITK_ok) 
							{
								char    pszObjType[WSO_name_size_c+1]="";
								iRetCode = WSOM_ask_object_type(tEngChangeRev, pszObjType);

								if (iRetCode == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
								{
									tag_t tRelTemp = NULLTAG;
									iRetCode = GRM_find_relation_type (pcRelationNames[iAttchCntr],&tRelTemp);
									if(iRetCode == ITK_ok && tRelTemp!=NULLTAG)
									{
										iRetCode = GRM_list_secondary_objects_only(tEngChangeRev,tRelTemp,&iNumAffected,&ptAffectedObjects);
									}
								}
								else
								iRetCode = ECM_get_contents  (tEngChangeRev,pcRelationNames[iAttchCntr],&iNumAffected, &ptAffectedObjects);
								if(iRetCode == ITK_ok && iNumAffected > 0)
								{
									//iRetCode = Validate_Targeted_Objects(iNumAffected,ptAffectedObjects,pcPseudoFolderName,&lValidationFailed,&pstCurrErrMsg);
									for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iRetCode == ITK_ok) ; iAffCntr++)
									{
										iRetCode = tiauto_get_class_name_of_instance (ptAffectedObjects[iAffCntr], &pcClassName);
										//getting parent class if the class name is NOT ITEM or ITEMREVISION
										if ((tc_strcmp (pcClassName,TIAUTO_ITEM) != 0) || (tc_strcmp (pcClassName,TIAUTO_ITEMREVISION) != 0))
										{
											tag_t	tTargetType					= NULLTAG;
											if(iRetCode == ITK_ok)
											{
												TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedObjects[iAffCntr],&tTargetType));
											}
											if(tTargetType != NULLTAG)
											{
												tag_t	tParentType					= NULLTAG;

												TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
												if(tParentType != NULLTAG)
												{
													SAFE_MEM_free(pcClassName);
													TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pcClassName));
												}
											}
						
										}
										if(iRetCode == ITK_ok)
										{
											if((tc_strcasecmp(pcClassName, TIAUTO_ITEM)== 0) || (tc_strcasecmp(pcClassName,TIAUTO_TI_DOCUMENT)== 0))
											{
												iRetCode = ITEM_list_all_revs (ptAffectedObjects[iAffCntr],&iRevCount,&ptRevList);
												if(iRetCode == ITK_ok && iRevCount>0)
												{
													for(iRevIndx =0; iRevIndx < iRevCount && (iRetCode == ITK_ok);iRevIndx++)
													{
														iRetCode = Validate_IR_Master_form_mandatory_Attributes(ptRevList[iRevIndx], &decision);
													}
												}												
												SAFE_MEM_free(ptRevList);												
											}
											else if((tc_strcasecmp(pcClassName, TIAUTO_ITEMREVISION)== 0) || (tc_strcasecmp(pcClassName,TIAUTO_TI_DOCUMENTREVISION)== 0))
											{
												iRetCode = Validate_IR_Master_form_mandatory_Attributes(ptAffectedObjects[iAffCntr], &decision);
											}
										}
										SAFE_MEM_free(pcClassName);
									}
								}
							}
							SAFE_MEM_free(ptAffectedObjects);
							SAFE_MEM_free(pcPseudoFolderName);
						}
					}
				}
				else if(iOption==2)
				{
					//get the targeted Item revision
					iRetCode = EPM_ask_root_task (msg.task, &tRootTask);
					if(iRetCode == ITK_ok)
					{
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments, &ptAttachments);
						for (iAttach = 0; iAttach < iNumAttachments && (iRetCode == ITK_ok); iAttach++)
						{
							iRetCode = tiauto_get_class_name_of_instance (ptAttachments[iAttach], &pcClassName);
							if(iRetCode == ITK_ok)
							{
								//getting parent class if the class name is NOT ITEMREVISION
								if(tc_strcasecmp(pcClassName, TIAUTO_ITEMREVISION)!= 0)
								{
									tag_t			tTargetType						= NULLTAG;
									tag_t			tParentType						= NULLTAG;

									if(iRetCode == ITK_ok)
									{
										TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAttachments[iAttach],&tTargetType));
									}
									if(tTargetType != NULLTAG)
									{
										TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
									}
									if(tParentType != NULLTAG)
									{
										SAFE_MEM_free(pcClassName);
										TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pcClassName));
									}	
								}
								//check if the classname of the target items is Item Revision or Document Revision
								if((tc_strcasecmp(pcClassName,TIAUTO_ITEMREVISION)== 0) || (tc_strcasecmp(pcClassName,TIAUTO_TI_DOCUMENTREVISION)== 0))
								{
									iRetCode = Validate_IR_Master_form_mandatory_Attributes(ptAttachments[iAttach], &decision);
								}
							}
							SAFE_MEM_free(pcClassName);
						}
						SAFE_MEM_free (ptAttachments);
					}
				}
				else
				{
					iRetCode = EPM_invalid_argument_value;
				}
			}			
		}  
	}

	if (iRetCode != ITK_ok)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &szErrMsg);
		TC_write_syslog(szErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg);		
		SAFE_MEM_free (szErrMsg);
	}
	if(decision==EPM_nogo)
	{
		iRetCode=TIAUTO_NOT_FILLED_REQUIRED_PROPERTY;
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
	}
	
	
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);

	return decision;
}