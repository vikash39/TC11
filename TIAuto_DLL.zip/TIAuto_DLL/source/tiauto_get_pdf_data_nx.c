
/*******************************************************************************
File         : tiauto_get_pdf_data_nx.c

Description  :	 
  
Input        : None
                        
Output       : None

Author       : 

Revision History :
Date            Revision    Who					Description
Jun 11, 2019    1.0        Jugunu Vasu     Initial Creation

*******************************************************************************/

#include <tiauto_runtime_properties.h>
#include <tiauto_defines.h>
#include <sa/tcfile_cache.h>



extern int TIAUTO_Get2D_PDF(METHOD_message_t* m, va_list args)
{
	int iRetCode = ITK_ok;
	char acTypename[TCTYPE_name_size_c+1];
	char  *pcErrMsg	= NULL;
	char acActiveTaskProp[20] = {'\0'};		
	char acActiveTaskProp1[20] = {'\0'};		
	tag_t tTypeTag = NULLTAG;	
	tag_t tNewPropTagCT = NULLTAG;
	tag_t tNewPropDataSetTagCT = NULLTAG;
	
	METHOD_id_t method;	
	METHOD_id_t method_h;	
	//Check the Item Type.TI Product, TI Alt Rep, TI Tool, TI Alt Tool TI CAD, TI CAD Construct etc.
	

	tTypeTag  = va_arg( args,tag_t);
	iRetCode = TCTYPE_ask_name(tTypeTag,acTypename);	


	if( iRetCode == ITK_ok)
	{
		tc_strcpy( acActiveTaskProp, "t8_3dDatasets");	
				iRetCode = TCTYPE_add_runtime_array_property(tTypeTag,acActiveTaskProp, PROP_untyped_reference,100,-1,&tNewPropTagCT);
				iRetCode =	PROPDESC_set_display_name(tNewPropTagCT,"3D Datasets");
				if(iRetCode == ITK_ok)
				{
					
					iRetCode = METHOD_register_prop_method((const char*)acTypename,
											  acActiveTaskProp,
                                              PROP_ask_value_tags_msg,
                                              Set_Property_3DData, 0,
                                              &method );
				
			    }

	}


	if( iRetCode == ITK_ok)
	{		    
				tc_strcpy( acActiveTaskProp, "t8_2dwgdatasets");	
				iRetCode = TCTYPE_add_runtime_array_property(tTypeTag,acActiveTaskProp, PROP_untyped_reference,100,-1,&tNewPropTagCT);
				iRetCode =	PROPDESC_set_display_name(tNewPropTagCT,"2D Drawing Datasets");
				if(iRetCode == ITK_ok)
				{
					
					iRetCode = METHOD_register_prop_method((const char*)acTypename,
											  acActiveTaskProp,
                                              PROP_ask_value_tags_msg,
                                              Set_Property_2DDrawing, 0,
                                              &method );
				
			    }
	 }

	
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog("Error in the method : TIAUTO_Get2D_PDF ");
		TC_write_syslog(pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}
	return(iRetCode);
}
extern int  Set_Property_2DDrawing( METHOD_message_t *  message, va_list  args )
{
	int iRetCode = ITK_ok;
	int iCountUGParMaster =0;
	int iCountSec =0;
	int iPDFDrawingCount =0;
	int iPDFCount =0;
	int isecPDFCnt =0;   
	int iTotalPDFCnt =0;
	int iSecRuntime = 0;


	tag_t tTypeTag = NULLTAG;
	tag_t objItemRevTag = NULLTAG;
	tag_t tRenderingRelation = NULLTAG;
	tag_t tSpecificationRelation = NULLTAG;
	tag_t tDrawingRelation = NULLTAG;	
	tag_t *ptSecUGPartMaster = NULL;
	tag_t *ptSecPDF = NULL;
	tag_t *ptSecDrawingPDF =NULL;

    tag_t prop_tag = va_arg(args, tag_t);
    int     *count = va_arg(args, int*);
    tag_t  **tags = va_arg(args, tag_t**);
	tag_t  tListPdf[50] ;//fixed size....	
	
	METHOD_PROP_MESSAGE_OBJECT(message, objItemRevTag);

	if(objItemRevTag != NULL)
	 {
	
		//Get the relation Specificatin.
		TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (REL_IMAN_SPEC,&tSpecificationRelation)); 
		//Get the relation  Rendering
		TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_REL_RENDERING,&tRenderingRelation));
		//Get the relation  Drawing
	    TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_REL_DRAWING,&tDrawingRelation));
		if(tSpecificationRelation != NULL)
		{
			//Get the UGPart /UGMaster
			TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(objItemRevTag,tSpecificationRelation,&iCountUGParMaster,&ptSecUGPartMaster));
			
			for(iCountSec =0; iCountSec<iCountUGParMaster; iCountSec++)
			{			
				char *cTypeClass =NULL;
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptSecUGPartMaster[iCountSec],&tTypeTag));
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_name2 (tTypeTag, &cTypeClass));					
					//iRetCode = TCTYPE_ask_class_name (tTypeTag, acTypeClass);

				if( ( iRetCode == ITK_ok ) &&( (tc_strcasecmp(cTypeClass,TIAUTO_UGPART) == 0) ||(tc_strcasecmp(cTypeClass,TIAUTO_UGMASTER) == 0) ))
				{
					// Read the PDF .Remdering relation				
					TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(ptSecUGPartMaster[iCountSec],tRenderingRelation,&iPDFCount,&ptSecPDF));
					// Read the PDF .Drawing relation			
					TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(ptSecUGPartMaster[iCountSec],tDrawingRelation,&iPDFDrawingCount,&ptSecDrawingPDF));
											
					if(ptSecPDF  != NULL)
					{	
						tag_t tTypepdfTag = NULL;
						char acTypePDFClass[TCTYPE_class_name_size_c+1]	= "";
						
						// Allocate Memory.					
						for(isecPDFCnt=0; isecPDFCnt<iPDFCount; isecPDFCnt++)
						{
							char *cName = NULL;
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptSecPDF[isecPDFCnt],&tTypepdfTag));						
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_name2(tTypepdfTag, &cName));
							if( ( iRetCode == ITK_ok ) &&( (tc_strcasecmp(cName,TIAUTO_ADOBE) == 0) ||(tc_strcasecmp(cName,TIAUTO_PDF) == 0) ))
							{
								iTotalPDFCnt = iTotalPDFCnt + 1;
								tListPdf[iTotalPDFCnt - 1] = ptSecPDF[isecPDFCnt];
							}	
							if( cName != NULL)
							{
								MEM_free(cName);
								cName = NULL;
							}
						}
						if(ptSecPDF != NULL)
						{
							MEM_free(ptSecPDF);
							ptSecPDF = NULL;
						}
					}


					if( ptSecDrawingPDF != NULL)
					{
						tag_t tTypepdfTag = NULL;
						// Allocate Memory.					
						for(isecPDFCnt=0; isecPDFCnt<iPDFDrawingCount; isecPDFCnt++)
						{
							char *cName = NULL;
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptSecDrawingPDF[isecPDFCnt],&tTypepdfTag));
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_name2(tTypepdfTag, &cName));						
							if( ( iRetCode == ITK_ok ) &&( (tc_strcasecmp(cName,TIAUTO_ADOBE) == 0) ||(tc_strcasecmp(cName,TIAUTO_PDF) == 0) ))
							{
								iTotalPDFCnt = iTotalPDFCnt + 1;
								tListPdf[iTotalPDFCnt - 1] = ptSecDrawingPDF[isecPDFCnt];
							}
							if( cName != NULL)
							{
								MEM_free(cName);
								cName = NULL;
							}
					    }
						if(ptSecDrawingPDF != NULL)
						{
							MEM_free(ptSecDrawingPDF);
							ptSecDrawingPDF = NULL;
						}
					}
				}

				if(cTypeClass != NULL)
				{
					MEM_free(cTypeClass);
					cTypeClass = NULL;
				}
		  }
	 }
	 *count = iTotalPDFCnt;
	//set the final string to the runtime property
	if(tListPdf != NULL)
	{
		
		*tags =(tag_t*) MEM_alloc(iTotalPDFCnt * sizeof(tag_t));	
		for (iSecRuntime = 0; iSecRuntime < iTotalPDFCnt; iSecRuntime++)
		{
		 (*tags)[iSecRuntime] = tListPdf[iSecRuntime];
		}
	}
	return(iRetCode);
	}

}