/*******************************************************************************
File         : tiauto_ah_remove_signoff_attachments.c

Description  : Removes the Signoff attachments of review task after demoting.
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
24/08/2016		  1.0	  Kantesh			Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int t1aAUTO_AH_remove_signoff_attachments(EPM_action_message_t msg)
{
	int				iRetCode			= ITK_ok;
	int				iLoop				= 0;
	int				iNumArgs			= 0;
	int				iAllTasks			= 0;
	int				iAllSubTasks		= 0;
	int				iLoopAllTasks		= 0;
	int				iLoopAllSubTasks	= 0;
	int				iNumAttachs			= 0;

	tag_t           tRootTaskTag        = NULLTAG;
	tag_t			*ptAllTaskTags		= NULL;
	tag_t			*ptAllSubTaskTags	= NULL;
	tag_t			*ptAttachsTagList	= NULL;//to be freed

	char			*pcTaskTypeName						        = NULL;
	char			*pcSubTaskTypeName							= NULL;
	char		    *pcValue									= NULL;
    char		    *pcFlag										= NULL;
	char			*pcTaskName									= NULL;
	char			*pcRevTaskName								= NULL;
    char            szErrorString[TIAUTO_error_message_len+1]	= "";    

	EPM_state_t State;
	
	return iRetCode;

	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(iLoop = 0; iLoop < iNumArgs; iLoop++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,"task_name") == 0 && pcValue != NULL)
				{
					pcTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTaskName, pcValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-remove-signoff-attachments\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					
				}
			}
			else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-remove-signoff-attachments\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }

	if(iRetCode == ITK_ok && pcTaskName != NULL)
	{
		//get the tag of the root task
		iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetCode = EPM_ask_sub_tasks(tRootTaskTag,&iAllTasks,&ptAllTaskTags);
			for(iLoopAllTasks =0 ; iLoopAllTasks < iAllTasks; iLoopAllTasks++)
			{
				iRetCode = AOM_ask_value_string(ptAllTaskTags[iLoopAllTasks], "task_type", &pcTaskTypeName);
				iRetCode = EPM_ask_name2(ptAllTaskTags[iLoopAllTasks],&pcRevTaskName);
				if( (iRetCode == ITK_ok) && (tc_strcmp(pcTaskTypeName,"EPMReviewTask") == 0) && (tc_strcmp(pcRevTaskName,pcTaskName)==0))
				{
					iRetCode = EPM_ask_state(ptAllTaskTags[iLoopAllTasks],&State);
					iRetCode = EPM_ask_sub_tasks(ptAllTaskTags[iLoopAllTasks],&iAllSubTasks,&ptAllSubTaskTags);
					for(iLoopAllSubTasks =0 ; iLoopAllSubTasks < iAllSubTasks; iLoopAllSubTasks++)
					{	
						iRetCode = AOM_ask_value_string(ptAllSubTaskTags[iLoopAllSubTasks], "task_type", &pcSubTaskTypeName);
						if((State==EPM_pending) && (tc_strcmp(pcSubTaskTypeName,"EPMSelectSignoffTask")==0) && (iRetCode == ITK_ok))
						{
							//get signoff attachments
							iRetCode = EPM_ask_attachments(ptAllSubTaskTags[iLoopAllSubTasks], EPM_signoff_attachment, &iNumAttachs, &ptAttachsTagList);
							if ((iRetCode == ITK_ok) && (iNumAttachs != 0))
							{
								//remove signoff attachments
								iRetCode = EPM_remove_attachments(ptAllSubTaskTags[iLoopAllSubTasks], iNumAttachs, ptAttachsTagList);
								break;
							}
						}
					}
				}
			}
		}	
	}
	SAFE_MEM_free(pcTaskTypeName);
	SAFE_MEM_free(ptAllTaskTags);
	SAFE_MEM_free(ptAllSubTaskTags);
	SAFE_MEM_free(ptAttachsTagList);
	SAFE_MEM_free(pcTaskName);
	SAFE_MEM_free(pcSubTaskTypeName);
	SAFE_MEM_free(pcRevTaskName);
	return iRetCode;  
}