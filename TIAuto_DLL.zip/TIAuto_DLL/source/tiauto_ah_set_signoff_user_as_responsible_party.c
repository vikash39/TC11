/*******************************************************************************
File         : tiauto_ah_set_signoff_user_as_responsible_party.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date			  Revision		Who              Description
*******************************************************************************
21st Dec, 2011		1.0        Dipak Naik      Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


extern int t1aAUTO_set_signoff_as_responsible_party(EPM_action_message_t msg)
{
	int				iRetCode			= ITK_ok;
	int				iNumArgs			= 0;
	int             iAttachmentCnt      = 0;
	int             i                   = 0;

	tag_t           tRootTaskTag        = NULLTAG;
	tag_t           tTaskType           = NULLTAG;
	tag_t           tReposibleParty     = NULLTAG;
	tag_t           tSubTask            = NULLTAG;
	tag_t           tGroupMember        = NULLTAG;
	tag_t           *ptAttachments      = NULL;

	char		    *pcValue									= NULL;
    char		    *pcFlag										= NULL;
	char			*pcTaskName									= NULL;
	char			*pcErrMsg									= NULL;
	char            *pcTaskTypeName								= NULL;
    char            szErrorString[TIAUTO_error_message_len+1]	= ""; 
	
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,"task_name") == 0 && pcValue != NULL)
				{
					pcTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTaskName, pcValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-set-signoff-as-responsible-party\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;					
				}
			}
			else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-set-signoff-as-responsible-party\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;				
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }

	if(iRetCode == ITK_ok && pcTaskName != NULL)
	{
		//get the tag of the root task
		iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//check whether the task name mentioned in the argument exists or not
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetCode = EPM_ask_sub_task  (  tRootTaskTag, pcTaskName,&tSubTask);
		}		
		//get the task type
		if(iRetCode == ITK_ok)
			iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
		//get the task type name
		if(iRetCode == ITK_ok && tTaskType != NULLTAG)
			iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
		//if select-signoff task
		if(iRetCode == ITK_ok && (tc_strcmp(pcTaskTypeName, "EPMSelectSignoffTask") == 0) )
		{
			iRetCode = EPM_ask_attachments(msg.task,EPM_signoff_attachment,&iAttachmentCnt,&ptAttachments);
		}
		//process the signoff attachment to get the select-signoff user
		if(iRetCode == ITK_ok && iAttachmentCnt > 0)
		{
			//get the user from the 1st user selected in the select signoff
			iRetCode = AOM_ask_value_tag( ptAttachments[0], "group_member", &tGroupMember );
			if( iRetCode == ITK_ok && tGroupMember != NULLTAG)
			{
				tReposibleParty = NULLTAG;
				iRetCode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
			}			
			//set the responsible party on the mentioned task
			if(iRetCode == ITK_ok && tReposibleParty != NULLTAG)
			{
				iRetCode = EPM_assign_responsible_party(tSubTask,tReposibleParty);
			}
		}
		SAFE_MEM_free(pcTaskTypeName);
		SAFE_MEM_free(ptAttachments);
	}
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	
	SAFE_MEM_free(pcValue);
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcTaskName);
    SAFE_MEM_free(ptAttachments);
	
	return iRetCode;  
}


