/*******************************************************************************
*
* FILENAME : tiauto_bom_property_methods.c
*
* DESCRIPTION : To show the runtime property "Launch Model Year" and "Program" 
*				in the bomline.
*				Set the quantity field in the BOMLine uneditable if the "Unit of Measure" 
*				attribute of the Item is blank else the quanity field will be editable.
*
* FUNCTIONS :
*       int TIAUTO_BOMLine_property_method( int *decision, va_list args  );
*
*
* CHANGES :
*      REF NO		DATE            WHO             DETAIL
*         001     08/24/2009		Rajesh N		Initial Creation
*		  002	  09/03/2009		Dipak Naik		Added the code to show the attributes 
*													"Launch Model Year" and "Program" present
													in Item revision master form
													of _OEM sub-types in the BOMLine as a 
													run-time property.
*		 003	01/19/2011			Dipak Naik		Added the code to show the attributes
													"Program" present in Item revision master form
													of _OEM sub-types in the BOMLine as a 
													run-time property.
*        004   10/10/2011           Nivedita        Added the function "set_bl_quantity_prop_desc"
                                                    to make the "Quantity" field non modifiable when
													Unit of measure is "each".

********************************************************************************/

/*******************************************************************************
* INCLUDE FILES
*******************************************************************************/
#include <tiauto_runtime_properties.h>
#include <tiauto_defines.h>
#include <bom/bom_attr.h>
#include <bom/bom.h>

//------------------------------------------------------------------------------
//Ask_prop_value_from_ItemRev_Master_Form 
//						METHOD_message_t *  message
//						va_list  args
//return int
//notes:  ask the runtime property "Launch Model Year" and "Program" value.
//------------------------------------------------------------------------------
int  Ask_prop_value_from_ItemRev_Master_Form( METHOD_message_t *  message, va_list  args )
{
	int ifail						= ITK_ok;
	int iSecObjCount				= 0;
	int iBLRevAttrID				= 0;
	int iMode						= 0;

	tag_t prop_tag = va_arg(args, tag_t);
	char **value = va_arg(args, char**);	
	//BOMLine tag
	tag_t tBLTag = message->object_tag;

	char	caTypeClass[TCTYPE_class_name_size_c+1]	= "";
	char	caTypeName[TCTYPE_name_size_c+1]			= "";
	char	*pcValue									= NULL;
	tag_t	tItemRevTag									= NULLTAG;
	tag_t	tParentType									= NULLTAG;
	tag_t	tObjType									= NULLTAG;
	tag_t	trelationType								= NULLTAG;
	GRM_relation_t *secondaryList						= 0;
																		
	if(ifail == ITK_ok)
	{
		ifail = BOM_line_look_up_attribute("bl_revision",&iBLRevAttrID);
	}
	if(ifail == ITK_ok)
	{
		ifail = BOM_line_ask_attribute_mode(iBLRevAttrID,&iMode);
	}

	if(iMode == BOM_attribute_mode_tag && ifail == ITK_ok)
	{		
		ifail = BOM_line_ask_attribute_tag(tBLTag,iBLRevAttrID,&tItemRevTag);		
	}
    
	if(ifail == ITK_ok && tItemRevTag != NULLTAG)
	{
		ifail = TCTYPE_ask_object_type(tItemRevTag,&tObjType);
		if(ifail == ITK_ok && tObjType != NULLTAG)
			ifail = TCTYPE_ask_class_name  (  tObjType, caTypeClass );
		if( ifail == ITK_ok && caTypeClass != NULL )
		{
			if(tc_strcmp(caTypeClass, "ItemRevision") == 0)
			{
				ifail =TCTYPE_ask_parent_type  (  tObjType, &tParentType);
				if(ifail == ITK_ok )
					ifail =TCTYPE_ask_name (tParentType, caTypeName) ;
				if(tc_strcmp(caTypeName, "_OEM Revision") == 0)
				{
					ifail = GRM_find_relation_type  (  "IMAN_master_form", &trelationType );
					if(ifail == ITK_ok && trelationType != NULLTAG)
						ifail = GRM_list_secondary_objects  (   tItemRevTag , trelationType,
																&iSecObjCount, &secondaryList );
					if( ifail == ITK_ok && iSecObjCount > 0)
					{
						if(tc_strcmp(message->prop_name, "Program") == 0)
						{
							ifail =AOM_UIF_ask_value  (  secondaryList[0].secondary,  "t1a2program",
																		&pcValue); 
						}
						else if(tc_strcmp(message->prop_name, "Launch Model Year") == 0)
						{
							ifail =AOM_UIF_ask_value  (  secondaryList[0].secondary,  "t1a2launchmodelyear",
																		&pcValue);
						}
						else if(tc_strcmp(message->prop_name, "Programs") == 0)
						{
							ifail =AOM_UIF_ask_value  (  secondaryList[0].secondary,  "t1a2programarray",
																		&pcValue);
						}
					}						
				}
			}
		}
	}
	if(pcValue != NULL)
	{
		*value = MEM_alloc ( (int)tc_strlen(pcValue)+1 );	
		tc_strcpy(*value,pcValue);
	}
		
	return ifail;
}


//------------------------------------------------------------------------------
//Set_prop_value_from_ItemRev_Master_Form 
//						METHOD_message_t *  message
//						va_list  args
//return int
//notes:  set the value for "Launch Model Year" and "Program".
//------------------------------------------------------------------------------
int  Set_prop_value_from_ItemRev_Master_Form( METHOD_message_t *  message, va_list  args )
{
	int ifail			= ITK_ok;
	int iSecObjCount	= 0;
	int iBLRevAttrID	= 0;
	int iMode			= 0;

	tag_t prop_tag = va_arg(args, tag_t);
	char *pcValue = va_arg(args, char*);
	//BOMLine tag
	tag_t tBLTag = message->object_tag;

	char	caTypeClass[TCTYPE_class_name_size_c+1]	= "";
	char	caTypeName[TCTYPE_name_size_c+1]			= "";
	tag_t	tItemRevTag									= NULLTAG;
	tag_t	tParentType									= NULLTAG;
	tag_t	tObjType									= NULLTAG;
	tag_t	trelationType								= NULLTAG;
	GRM_relation_t *secondaryList						= 0;

	if(ifail == ITK_ok)
	{
		ifail = BOM_line_look_up_attribute("bl_revision",&iBLRevAttrID);
	}
	if(ifail == ITK_ok)
	{
		ifail = BOM_line_ask_attribute_mode(iBLRevAttrID,&iMode);
	}

	if(iMode == BOM_attribute_mode_tag && ifail == ITK_ok)
	{		
		ifail = BOM_line_ask_attribute_tag(tBLTag,iBLRevAttrID,&tItemRevTag);		
	}
    
	if(ifail == ITK_ok && tItemRevTag != NULLTAG)
	{
		ifail = TCTYPE_ask_object_type(tItemRevTag,&tObjType);
		if(ifail == ITK_ok && tObjType != NULLTAG)
			ifail = TCTYPE_ask_class_name  (  tObjType, caTypeClass );
		if( ifail == ITK_ok && caTypeClass != NULL )
		{
			if(tc_strcmp(caTypeClass, "ItemRevision") == 0)
			{
				ifail =TCTYPE_ask_parent_type  (  tObjType, &tParentType);
				if(ifail == ITK_ok )
					ifail =TCTYPE_ask_name (tParentType, caTypeName) ;
				if(tc_strcmp(caTypeName, "_OEM Revision") == 0)
				{
					ifail = GRM_find_relation_type  (  "IMAN_master_form", &trelationType );
					if(ifail == ITK_ok && trelationType != NULLTAG)
					ifail = GRM_list_secondary_objects  (  tItemRevTag , trelationType,
														&iSecObjCount, &secondaryList );
					
					if( ifail == ITK_ok && iSecObjCount > 0)
					{
						ifail = AOM_refresh(secondaryList[0].secondary,true);
						if(ifail == ITK_ok && tc_strcmp(message->prop_name, "Program") == 0)
						{
							ifail =AOM_set_value_string   (  secondaryList[0].secondary,  "t1a2program",
																		pcValue); 
						}
						else if(ifail == ITK_ok && tc_strcmp(message->prop_name, "Launch Model Year") == 0)
						{							
							ifail =AOM_set_value_string   (  secondaryList[0].secondary,  "t1a2launchmodelyear",
																		pcValue);
						}
						else if(ifail == ITK_ok && tc_strcmp(message->prop_name, "Programs") == 0)
						{							
							ifail =AOM_UIF_set_value   (  secondaryList[0].secondary,  "t1a2programarray",
																		pcValue);
						}
						if( ifail == ITK_ok)
							ifail = AOM_save(secondaryList[0].secondary);
					}
					SAFE_MEM_free(secondaryList);
				}
			}
		}
	}
	
		
	return ifail;
}

//------------------------------------------------------------------------------
//Set_prop_value 
//		METHOD_message_t *  message
//		va_list  args
//return int
//notes:  make the bl_quantity attribute Read-Only if UOM is "Each"
//------------------------------------------------------------------------------
int  set_bl_quantity_prop_desc( METHOD_message_t *  message, va_list  args )
{
	int	ifail = ITK_ok;

	tag_t prop_tag = va_arg(args, tag_t);
	char *value = va_arg(args, char*);

	tag_t tBLTag = message->object_tag;
	char* pcValue = value;
	tag_t tPropBLTag = NULLTAG;	
	char* pcQtyValue = NULL;
	char* pcQtyTemp  = NULL;
	char* pcUOMUnitValue = NULL;	
	
	if(ifail == ITK_ok && tBLTag != NULLTAG )
	{
		ifail = AOM_ask_descriptor(tBLTag,"bl_quantity",&tPropBLTag );

		if( ifail == ITK_ok && tPropBLTag != NULLTAG )
			ifail = AOM_ask_value_string(tBLTag,"bl_item_uom_tag",&pcUOMUnitValue );
		if( ifail == ITK_ok && tPropBLTag != NULLTAG )
			ifail = AOM_UIF_ask_value (tBLTag,"bl_quantity",&pcQtyValue );
		
		if( ifail == ITK_ok && pcUOMUnitValue != NULL && tc_strcmp(pcUOMUnitValue,"each")==0 )
		{
		       if(tc_strcmp(value,"1") != 0 || tc_strcmp(value,"") != 0)
			  {
				ifail = TIAUTO_QUANTITY_NON_EDITABLE;
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUANTITY_NON_EDITABLE,"Quantity is not modifiable for this BOMLine as Unit of Measure value is each");				
			  }
		   
		}
	}	
	SAFE_MEM_free(pcQtyValue);
	SAFE_MEM_free(pcUOMUnitValue);
	return ifail;
}

//----------------------------------------------------------------------------- 
// TIAUTO_BOMLine_property_method()
// \param  METHOD_message_t* m /*I*/
//   va_list args			/*<O>*/
// \return int
// \note To register the method for BOMLine quantity attribute
//-----------------------------------------------------------------------------
int TIAUTO_BOMLine_property_method(METHOD_message_t* m, va_list args)
{
	int iFail = ITK_ok;
	char acTypename[TCTYPE_name_size_c+1];
	char acPropName[32] = {'\0'};
	tag_t tTypeTag = NULLTAG;
	tag_t tNewPropTag = NULLTAG;
	METHOD_id_t method;
	

	tTypeTag  = va_arg( args,tag_t);

	iFail = TCTYPE_ask_name(tTypeTag,acTypename);
	tc_strcpy(acPropName,m->prop_name);
  	
	// commented on 7-Feb-12 due to issue in proe manager
	/*if(iFail == ITK_ok)
		iFail = METHOD_find_prop_method ("BOMLine", "bl_quantity", PROP_set_value_string_msg, &method);
	if (method.id != NULLTAG)
    {
        iFail = METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) set_bl_quantity_prop_desc, NULL);
    }*/

	//creation of runtime property "Program"
	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,"Program",PROP_string,
		                                      256,&tNewPropTag);
	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTag,"Program");
	//the "PROPDESC_set_protection" is obsoleted in TC8 and the 
	//Protection should be set in the Business Modeler IDE
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTagCT, PROP_read);
	

  	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Program",
                                              PROP_ask_value_string_msg,
                                              Ask_prop_value_from_ItemRev_Master_Form,
                                               0,&method );
	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Program",
                                              PROP_set_value_string_msg,
                                              Set_prop_value_from_ItemRev_Master_Form, 
                                               0,&method );
	//creation of runtime property "Launch Model Year"
	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,"Launch Model Year",PROP_string,
		                                      256,&tNewPropTag);
	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTag,"Launch Model Year");
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTag, PROP_write);

  	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Launch Model Year",
                                              PROP_ask_value_string_msg,
                                              Ask_prop_value_from_ItemRev_Master_Form, 0,
                                              &method );
	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Launch Model Year",
                                              PROP_set_value_string_msg,
                                              Set_prop_value_from_ItemRev_Master_Form, 0,
                                              &method );

	//creation of runtime property "Programs"
	if(iFail == ITK_ok)
		iFail = TCTYPE_add_runtime_property(tTypeTag,"Programs",PROP_string,
		                                      256,&tNewPropTag);
	if(iFail == ITK_ok)
		iFail =	PROPDESC_set_display_name(tNewPropTag,"Programs");
	//if(iFail == ITK_ok)
	//	iFail = PROPDESC_set_protection( tNewPropTag, PROP_write);

  	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Programs",
                                              PROP_ask_value_string_msg,
                                              Ask_prop_value_from_ItemRev_Master_Form, 0,
                                              &method );
	if(iFail == ITK_ok)
		iFail = METHOD_register_prop_method((const char*)acTypename,
                                             "Programs",
                                              PROP_set_value_string_msg,
                                              Set_prop_value_from_ItemRev_Master_Form, 0,
                                              &method );

	return(iFail);
}


