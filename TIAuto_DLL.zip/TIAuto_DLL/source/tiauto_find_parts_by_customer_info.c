#include <tiauto_find_parts_by_customer_info.h>

extern int find_parts_by_customer_info(const char* pcKeyword_ProgramName,const char* pcKeyword_CustomerName,const char* pcKeyword_CompanyType,
									   const char* pcKeyword_CBD,const char* pcKeyword_CAD, const char* pcKeyword_MBD, const char* pcKeyword_MAD,
									   int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
    date_t aDate,bDate,cDate,dDate;

	/*create a query*/
		ifail = POM_enquiry_create ("findpartsbycustinfo");

	//initialise the outputs
		ifail = POM_enquiry_add_select_attrs ( "findpartsbycustinfo", "ItemRevision", 1, select_attr_list1);

	//set join expression
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_1","ItemRevision","items_tag",POM_enquiry_equal,"Item","puid");
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_2","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");	
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_4","Form","data_file",POM_enquiry_equal,"t1a4Prg_VariantRevMaster","puid");
		
	//set join expression for dates, objectname and objecttype
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_5","ItemRevision","puid",POM_enquiry_equal,"WorkSpaceObject","puid"); 
		ifail = POM_enquiry_set_join_expr ("findpartsbycustinfo","auniqueExprId_6","WorkSpaceObject", "puid", POM_enquiry_equal, "Pom_application_object", "puid");

	//join the expression
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_7","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_8","auniqueExprId_7",POM_enquiry_and,"auniqueExprId_3");
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_9","auniqueExprId_8",POM_enquiry_and,"auniqueExprId_4");
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_5");
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_6");

//=======================================================================
     //setting all the keyword to uniquevalueID
//=======================================================================

		if (strcmp (pcKeyword_ProgramName ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartsbycustinfo", "aunique_value_id1", 1,&pcKeyword_ProgramName, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo","auniqueExprId_12","t1a4Prg_VariantRevMaster","t1a4programname",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartsbycustinfo","auniqueExprId_12",POM_case_insensitive);
	  }

	 if (strcmp (pcKeyword_CustomerName ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartsbycustinfo", "aunique_value_id2", 1,&pcKeyword_CustomerName, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo","auniqueExprId_13","t1a4Prg_VariantRevMaster","t1a4tocompany",POM_enquiry_like,"aunique_value_id2");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findsubstituteitems","auniqueExprId_13",POM_case_insensitive);
	 }

	 if (strcmp (pcKeyword_CompanyType ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartsbycustinfo", "aunique_value_id3", 1,&pcKeyword_CompanyType, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo","auniqueExprId_14","t1a4Prg_VariantRevMaster","t1a4tocompanytype",POM_enquiry_like,"aunique_value_id3");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartsbycustinfo","auniqueExprId_14",POM_case_insensitive);
	  }

	 if (strcmp (pcKeyword_CAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(pcKeyword_CAD, &aDate);

		ifail = POM_enquiry_set_date_value ("findpartsbycustinfo", "aunique_value_id4", 1, &aDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo", "auniqueExprId_15","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id4");
	  }

	 if (strcmp (pcKeyword_CBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(pcKeyword_CBD, &bDate);
		 
		ifail = POM_enquiry_set_date_value ("findpartsbycustinfo", "aunique_value_id5", 1, &bDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo", "auniqueExprId_16","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id5");	

	 }

	 if (strcmp (pcKeyword_MAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(pcKeyword_MAD, &cDate);

		ifail = POM_enquiry_set_date_value ("findpartsbycustinfo", "aunique_value_id6", 1, &cDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo", "auniqueExprId_17","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id6");	
	  }

	 if (strcmp (pcKeyword_MBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(pcKeyword_MBD, &dDate);

		ifail = POM_enquiry_set_date_value ("findpartsbycustinfo", "aunique_value_id7", 1, &dDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartsbycustinfo", "auniqueExprId_18","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id7");
	  }
//===============================================================================================
                                          //join the main expression 
//===============================================================================================
	 if (strcmp (pcKeyword_ProgramName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_19","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_12");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_19","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_CustomerName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_20","auniqueExprId_19",POM_enquiry_and,"auniqueExprId_13");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_20","auniqueExprId_19",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_CompanyType ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_21","auniqueExprId_20",POM_enquiry_and,"auniqueExprId_14");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_21","auniqueExprId_20",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_CAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_22","auniqueExprId_21",POM_enquiry_and,"auniqueExprId_15");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_22","auniqueExprId_21",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_CBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_23","auniqueExprId_22",POM_enquiry_and,"auniqueExprId_16");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_23","auniqueExprId_22",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_MAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_24","auniqueExprId_23",POM_enquiry_and,"auniqueExprId_17");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_24","auniqueExprId_23",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (pcKeyword_MBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_25","auniqueExprId_24",POM_enquiry_and,"auniqueExprId_18");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartsbycustinfo","auniqueExprId_25","auniqueExprId_24",POM_enquiry_and,"auniqueExprId_1");
	}

	//set where expression
	ifail = POM_enquiry_set_where_expr("findpartsbycustinfo","auniqueExprId_25");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("findpartsbycustinfo", true);
	//execute the wuery
	ifail = POM_enquiry_execute ("findpartsbycustinfo",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("findpartsbycustinfo");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}	

	return ifail;
	
}
		

