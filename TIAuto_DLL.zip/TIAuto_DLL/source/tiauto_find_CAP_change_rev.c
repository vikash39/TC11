/*******************************************************************************************************************
File         : find_CAP_change_rev.c

Description  : These are functions related to the user query - "TI Change Rev (CAP Form)"
			   This function will search for CAP change rev objects.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
01 Jul 2016		1.0			Pradeep				Initial Creation  
Nov 23 2018		1.1		    Jugunu              Updated for ER 9759 CAP3
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		TIAUTO_find_CAP_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "TI Change Rev (CAP Form)" user query.
================================================================================================================*/
extern int find_CAP_change_rev (const char* pcItemID,const char* pcRev,const char* pcName,const char* pcCAD,const char* pcCBD,const char* pcMAD,
								const char* pcMBD,const char* pcRAD,const char* pcRBD,const char* pcOwningUser,const char* pcOwningGroup, 
								const char* pcOwningSite,const char* pcLastModUser,const char* pcReleaseStatus,const char* pcCurrentTask,
								const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPgms,const char* pcAffPlant,const char* pcTIChangeDesc,
								const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,const char* pcCustTrackingNum,
								const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcImpAfter,const char* pcImpBefore,
								char* pcForm,
								int *iNumFound,tag_t **foundTags)
{
	int				iFail = ITK_ok;
	const char		*select_attr_list1[] = {"puid"};
	const char		*pcRelationTypeName = "IMAN_specification";
	const char		*pcItemType[] = {"EngChange Revision","T8_TI_ChangeRevision"};
	int				iRows		= 0;
	int				i			= 0;
	int				iCols		= 0;
	void			***paReport;
	tag_t			tChItem	= NULLTAG;
	date_t dCAD,dCBD,dMAD,dMBD,dRAD,dRBD,dImpAfter,dImpBefore=NULLDATE;

	char	acFormClassName[64] = "";

	char	*pcFormAttr_Div							= NULL;
	char	*pcFormAttr_ProductGroup				= NULL;
	char	*pcFormAttr_AffPgms						= NULL;
	char	*pcFormAttr_AffPlant					= NULL;
	char	*pcFormAttr_ChangeDesc					= NULL;
	char	*pcFormAttr_ChangeDriver				= NULL;
	char	*pcFormAttr_TargetReleaseStatus			= NULL;
	char	*pcFormAttr_ReqGroup					= NULL;
	char	*pcFormAttr_CustTrackingNum				= NULL;
	char	*pcFormAttr_SuppTrackingNum				= NULL;
	char	*pcFormAttr_IsProdImpacted				= NULL;
	char	*pcFormAttr_ImpDate						= NULL;

	if (tc_strcasecmp(pcForm,"cap") == 0)
	{
		pcFormAttr_Div								= "t8_120tidivisions";
		pcFormAttr_ProductGroup						= "t8_120productgroup";
		pcFormAttr_AffPgms							= "t8_t1a120affectedprograms";
		pcFormAttr_AffPlant							= "t8_120tiplant";
		pcFormAttr_ChangeDesc						= "t8_t1a120changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a120changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a120targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a120requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a120custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a120suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a120isproductimacted";		
		pcFormAttr_ImpDate							= "t8_t1a120sugchangeimpldate";	

		tc_strcpy(acFormClassName,"t8_t1a120cap");
	}
	if (tc_strcasecmp(pcForm,"cap2") == 0)
	{
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		//pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_ImpDate						= "t8_t1a120sugchangeimpldate";	

		tc_strcpy(acFormClassName,"T8_t1a190CAP2");
	}
	//adding CAP3 changes
	if (tc_strcasecmp(pcForm,"cap3") == 0)
	{
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		//pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_ImpDate						= "t8_t1a120sugchangeimpldate";	

		tc_strcpy(acFormClassName,"T8_t1a190CAP3");
	}

	//Create the main query
	iFail = POM_enquiry_create ("Find_change");

	//select output attribute for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "ItemRevision", 1, select_attr_list1));
	
	//craete alias
	TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
	
	//start query expression for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","itemrevision","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));

	/*Filter for EngChange items only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_7", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

	/*Filter for Secondary object Relation Type i,e(IMAN_specification) only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","ImanRelation","relation_type",POM_enquiry_equal,"imantype","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcRelationTypeName, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_9", "imantype","type_name",POM_enquiry_equal ,"aunique_value_id2" ));

	/*Item ID*/
	if (tc_strcmp(pcItemID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcItemID, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_10","Item", "item_id",POM_enquiry_like,"aunique_value_id3"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_10",POM_case_insensitive));
	}
	/*Name*/
	if (strcmp (pcName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1,&pcName, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change","auniqueExprId_11","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id4"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_11",POM_case_insensitive));
	}
	/*Created after date*/		
	if (strcmp (pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCAD, &dCAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id5", 1, &dCAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_12","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id5"));	
	}
	/*Created before date*/
	if (strcmp (pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCBD, &dCBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id6", 1, &dCBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id6"));
	}	
	/*Modified after date*/
	if (strcmp (pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMAD, &dMAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id7", 1, &dMAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_14","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id7"));
	}
	/*Modified before date*/
	if (strcmp (pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMBD, &dMBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id8", 1, &dMBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id8"));
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_16","Pom_application_object","owning_user",POM_enquiry_equal,"user","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcOwningUser, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_17", "user","os_username",POM_enquiry_like ,"aunique_value_id9" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_18","Pom_application_object","owning_group",POM_enquiry_equal,"pom_group","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcOwningGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_19", "pom_group","name",POM_enquiry_like ,"aunique_value_id10" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		/*If Owning site & Logged in site are same*/
		if (strcmp (pcOwningSite ,"Local") == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_20","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21","pom_object","owning_site",POM_enquiry_is_null, NULL  ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_20","pom_object","owning_site",POM_enquiry_equal, "pom_imc", "puid"  ));		
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcOwningSite, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21", "pom_imc","name",POM_enquiry_like ,"aunique_value_id11" ));
		}
	}
	/*last modified user*/
	if (strcmp (pcLastModUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_22","Pom_application_object","last_mod_user",POM_enquiry_equal,"user_alias","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id12", 1, &pcLastModUser, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_23", "user_alias","os_username",POM_enquiry_like ,"aunique_value_id12" ));	
	}
	/*Release status*/
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_24","itemrevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id13", 1, &pcReleaseStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_25", "ReleaseStatus", "name",POM_enquiry_like ,"aunique_value_id13" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_26","itemrevision","process_stage_list",POM_enquiry_equal,"epmtask","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_27","epmtask","task_template",POM_enquiry_equal,"epmtasktemplate","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcCurrentTask, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_28", "epmtasktemplate", "template_name",POM_enquiry_like ,"aunique_value_id14"));
	}
	/*TI Division*/
	if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_29","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcTIDiv, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_30", acFormClassName, pcFormAttr_Div,POM_enquiry_like ,"aunique_value_id15" ));
	}
	/*Product Group*/
	if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_31","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcProductGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_32", acFormClassName, pcFormAttr_ProductGroup,POM_enquiry_like ,"aunique_value_id16" ));
	}
	/*Affected Program*/
	if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
	{
		//create pseudo class alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acFormClassName, pcFormAttr_AffPgms,"class_affected")); 

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_33","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_34",acFormClassName,"puid",POM_enquiry_equal,"class_affected","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id17", 1, &pcAffPgms, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_35", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id17" ));
	}
	/*Affected Plant*/
	if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
	{
		//create pseudo class alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acFormClassName, pcFormAttr_AffPlant,"class_plant")); 

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_36","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_37",acFormClassName,"puid",POM_enquiry_equal,"class_plant","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcAffPlant, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_38", "class_plant","pval",POM_enquiry_equal ,"aunique_value_id18" ));
	}
	/*TI Change Description*/
	if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_39","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id19", 1, &pcTIChangeDesc, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_40", acFormClassName, pcFormAttr_ChangeDesc,POM_enquiry_like ,"aunique_value_id19" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_40",POM_case_insensitive));
	}
	/*Change Driver*/
	if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
	{	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_41","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id20", 1, &pcChangeDriver, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_42", acFormClassName, pcFormAttr_ChangeDriver,POM_enquiry_like ,"aunique_value_id20" ));
	}
	/*Target Release Status*/
	if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_43","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id21", 1, &pcTargetReleaseStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_44", acFormClassName, pcFormAttr_TargetReleaseStatus,POM_enquiry_like ,"aunique_value_id21" ));
	}
	/*Requesting Group*/
	if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_45","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id22", 1, &pcReqGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_46", acFormClassName, pcFormAttr_ReqGroup,POM_enquiry_like ,"aunique_value_id22" ));
	}

	/*Customer Tracking Number*/
	if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_47","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id23", 1, &pcCustTrackingNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_48", acFormClassName, pcFormAttr_CustTrackingNum,POM_enquiry_like ,"aunique_value_id23" ));
	}
	/*Supplier Tracking Number*/
	if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_49","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id24", 1, &pcSuppTrackingNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_50", acFormClassName, pcFormAttr_SuppTrackingNum,POM_enquiry_like ,"aunique_value_id24" ));
	}
	/*Is Product Impacted*/
	if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_51","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id25", 1, &pcIsProdImpacted, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_52", acFormClassName, pcFormAttr_IsProdImpacted,POM_enquiry_like ,"aunique_value_id25" ));
	}
	/*Suggested Change Implementation Date After*/
	if ( (strcmp (pcImpAfter ,"") != 0) && (pcFormAttr_ImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcImpAfter, &dImpAfter));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_53","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id26", 1, &dImpAfter, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_54", acFormClassName, pcFormAttr_ImpDate,POM_enquiry_greater_than_or_eq ,"aunique_value_id26" ));
	}
	
	/*Suggested Change Implementation Date Before*/
	if ( (strcmp (pcImpBefore ,"") != 0) && (pcFormAttr_ImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcImpBefore, &dImpBefore));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_55","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id27", 1, &dImpBefore, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_56", acFormClassName, pcFormAttr_ImpDate,POM_enquiry_less_than_or_eq ,"aunique_value_id27" ));
	}
	/*Change Rev*/
	if (tc_strcmp(pcRev ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id28", 1, &pcRev, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_200","ItemRevision", "item_revision_id",POM_enquiry_like,"aunique_value_id28"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_200",POM_case_insensitive));
	}
	/*Released after date*/
	if (strcmp (pcRAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRAD, &dRAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id29", 1, &dRAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_201","WorkspaceObject","date_released",POM_enquiry_greater_than_or_eq,"aunique_value_id29"));
	}
	/*Released before date*/
	if (strcmp (pcRBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRBD, &dRBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id30", 1, &dRBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_202","WorkspaceObject","date_released",POM_enquiry_less_than_or_eq,"aunique_value_id30"));
	}
	/*Filter for only CAP changes*/
	if (strcmp (acFormClassName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_203","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
	}

	//join the expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_3" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_4" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_5" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_6" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_7" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_8" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_9" ));
	
	/*Item ID*/
	if (tc_strcmp(pcItemID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_10" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Name*/
	if (tc_strcmp(pcName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_11" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created after date*/		
	if (tc_strcmp(pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_12" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created before date*/
	if (tc_strcmp(pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_13" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified after date*/
	if (tc_strcmp(pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_14" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified before date*/
	if (tc_strcmp(pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_15" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_16" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and, "auniqueExprId_17" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_72","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_18" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_19" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_74","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_20" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_21" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*last modified user*/
	if (strcmp (pcLastModUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_22" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and, "auniqueExprId_23" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Release status*/
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_79","auniqueExprId_78",POM_enquiry_and, "auniqueExprId_24" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_80","auniqueExprId_79",POM_enquiry_and, "auniqueExprId_25" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_80","auniqueExprId_78",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_81","auniqueExprId_80",POM_enquiry_and, "auniqueExprId_26" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_82","auniqueExprId_81",POM_enquiry_and, "auniqueExprId_27" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_83","auniqueExprId_82",POM_enquiry_and, "auniqueExprId_28" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_83","auniqueExprId_80",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*TI Division*/
	if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_84","auniqueExprId_83",POM_enquiry_and, "auniqueExprId_29" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_85","auniqueExprId_84",POM_enquiry_and, "auniqueExprId_30" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_85","auniqueExprId_83",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Product Group*/
	if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_86","auniqueExprId_85",POM_enquiry_and, "auniqueExprId_31" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_87","auniqueExprId_86",POM_enquiry_and, "auniqueExprId_32" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_87","auniqueExprId_85",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Affected Programs*/
	if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_88","auniqueExprId_87",POM_enquiry_and, "auniqueExprId_33" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_89","auniqueExprId_88",POM_enquiry_and, "auniqueExprId_34" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_90","auniqueExprId_89",POM_enquiry_and, "auniqueExprId_35" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_90","auniqueExprId_87",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Affected Plant*/
	if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_91","auniqueExprId_90",POM_enquiry_and, "auniqueExprId_36" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_92","auniqueExprId_91",POM_enquiry_and, "auniqueExprId_37" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_93","auniqueExprId_92",POM_enquiry_and, "auniqueExprId_38" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_93","auniqueExprId_90",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*TI Change Description*/
	if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_94","auniqueExprId_93",POM_enquiry_and, "auniqueExprId_39" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_95","auniqueExprId_94",POM_enquiry_and, "auniqueExprId_40" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_95","auniqueExprId_93",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Change Driver*/
	if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_96","auniqueExprId_95",POM_enquiry_and, "auniqueExprId_41" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_97","auniqueExprId_96",POM_enquiry_and, "auniqueExprId_42" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_97","auniqueExprId_95",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Target Release Status*/
	if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_98","auniqueExprId_97",POM_enquiry_and, "auniqueExprId_43" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_99","auniqueExprId_98",POM_enquiry_and, "auniqueExprId_44" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_99","auniqueExprId_97",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Requesting Group*/
	if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_100","auniqueExprId_99",POM_enquiry_and, "auniqueExprId_45" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_101","auniqueExprId_100",POM_enquiry_and, "auniqueExprId_46" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_101","auniqueExprId_99",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Tracking Number*/
	if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_102","auniqueExprId_101",POM_enquiry_and, "auniqueExprId_47" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_103","auniqueExprId_102",POM_enquiry_and, "auniqueExprId_48" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_103","auniqueExprId_101",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Supplier Tracking Number*/
	if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_104","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_49" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_105","auniqueExprId_104",POM_enquiry_and, "auniqueExprId_50" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_105","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Is Product Impacted*/
	if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_106","auniqueExprId_105",POM_enquiry_and, "auniqueExprId_51" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_107","auniqueExprId_106",POM_enquiry_and, "auniqueExprId_52" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_107","auniqueExprId_105",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Suggested Change Implementation Date After*/
	if ( (strcmp (pcImpAfter ,"") != 0) && (pcFormAttr_ImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_108","auniqueExprId_107",POM_enquiry_and, "auniqueExprId_53" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_109","auniqueExprId_108",POM_enquiry_and, "auniqueExprId_54" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_109","auniqueExprId_107",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Suggested Change Implementation Date Before*/
	if ( (strcmp (pcImpBefore ,"") != 0) && (pcFormAttr_ImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_110","auniqueExprId_109",POM_enquiry_and, "auniqueExprId_55" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_111","auniqueExprId_110",POM_enquiry_and, "auniqueExprId_56" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_111","auniqueExprId_109",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Revision*/
	if (tc_strcmp(pcRev ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_200" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_112","auniqueExprId_111",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Released after date*/		
	if (tc_strcmp(pcRAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_113","auniqueExprId_112",POM_enquiry_and, "auniqueExprId_201" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_113","auniqueExprId_112",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Released before date*/		
	if (tc_strcmp(pcRBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_114","auniqueExprId_113",POM_enquiry_and, "auniqueExprId_202" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_114","auniqueExprId_113",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Filter for only CAP changes*/
	if (strcmp (acFormClassName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_115","auniqueExprId_114",POM_enquiry_and, "auniqueExprId_203" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_115","auniqueExprId_114",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}



	//set where expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_115" ));	
	
	//set distinct value
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
	//execute the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
	//delete the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
	//process result	
	if(iRows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(i=0;i<iRows;i++)
		{
			tChItem = NULLTAG;
			tChItem = *(tag_t *)paReport[i][0];
			(*foundTags)[i] = tChItem;
		}
		SAFE_MEM_free(paReport);
	}

	return iFail;
}