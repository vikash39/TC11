/************************************************************************************************************
File         : tiauto_ah_set_rev_master_form_value.c

Description  : The value of the attribute "Customer Authorization Number", "Customer Name" and 
			   "Released By Change" of the targetd item revision master form will be read from the CCR/PMR 
			   form of the targeted chage revision. If the item revision master form is already having some 
			   value in above mentioned attribute, it will be overwritten.

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jan 12, 2010    1.0        Dipak Naik      Initial Creation
Jan 14, 2011	1.1		   Dipak Naik	   Added the code to read the "Customer Authorization Number" from
										   the PMR form. If both PMR and CCR form are present, then the value 
										   will be read from the CCR form.
Feb 18, 2011	1.2		   Dipak Naik	   Modified the code to read the string arry attribute "Customer Name"
										   and the "Customer Authorization No." from the PMR and CCR form and
										   populate those values in the "Customer Name" and "Customer release
										   Number" attribute of the targeted item revision master form. Also
										   the targeted change revision Id value will be populated to the
										   string attribute "Released By Change" attribute of the targeted
										   item revision master form.
Sep 25 2016	   1.3		Shilpa			   ER#8963 - Modified code to read the values from affected programs and 
											update the same in Customer name attribute of Item Revision master form.
Nov 23,2018	   1.4		Jugunu             Updated for ER 9759 CAP3

**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

//-----------------------------------------------------------------------------
//! IsChildItemType()
//! \param  tag_t  objTag,	/*<I>*/ 
//!			bool  &isOEM,	/*<O>*/
//!			bool  &isDoc	/*<O>*/
//! \return int
//! \note Checks if the Items parent type is _OEM or TI_Document
//!		  and updates the corresponding logical to True. Default is false. 
//!		  Returns retcode.
//-----------------------------------------------------------------------------
int IsChildItemType( tag_t  objTag,	logical  *isOEM, logical  *isDoc )
{	 
	int iRetCode = ITK_ok;	
	tag_t typeTag = NULLTAG;
	tag_t parentTypeTag = NULLTAG;	
	char  typeName[TCTYPE_name_size_c+1] ;
	*isOEM = false;
	*isDoc = false;
	*typeName = '\0';

	iRetCode = TCTYPE_ask_object_type(objTag, &typeTag);
	if(iRetCode == ITK_ok)
	{
		iRetCode = TCTYPE_ask_parent_type(typeTag, &parentTypeTag); 
	}
	if(iRetCode == ITK_ok)  
	{
		iRetCode = TCTYPE_ask_name(parentTypeTag,  typeName);
	}
	if(iRetCode == ITK_ok)
	{
		if( tc_strcmp(typeName,"_OEM Revision") == 0 )
		{
			*isOEM = true;
		}
		else if( tc_strcmp(typeName,"TI_Document Revision") == 0 )
		{
			*isDoc = true;
		}
	}
	return iRetCode;
}
//-----------------------------------------------------------------------------------------------------------------
//! set_value_on_itemRevMaster_Form()
//! \param  tag_t	tItemRevMasterForm			/*<I>*/ 
//!			char	*pcChangeRevID				/*<I>*/
//!			int		iCntCustAuthNo				/*<I>*/
//!			char	**pcCustAuthNo				/*<I>*/
//!			int		iNoofCustName				/*<I>*/
//!			char	**pcCustomerName			/*<I>*/
//!			char	*pcCustRelNoPropName		/*<I>*/
//!			char	*pcReleasedChangePropName	/*<I>*/
//!			char	*pcCustomerNamePropName		/*<I>*/
//! \return int
//! \note Sets the "released by change", "customer release no" and "custome name" attribute value of the IRM form.
//!			If the IRM form is already having some value in the above mentioned attribute, then the value will be
//!			overwritten.
//!		  Returns retcode.
//-----------------------------------------------------------------------------------------------------------------
int set_value_on_itemRevMaster_Form(tag_t tItemRevMasterForm, char *pcChangeRevID,int iCntCustAuthNo,
									char **pcCustAuthNo,int iNoofCustName,char **pcCustomerName,
									char *pcCustRelNoPropName, char *pcReleasedChangePropName, char *pcCustomerNamePropName)
{
	int             iRetCode		= ITK_ok;	
	
	//set the change revision id				
	iRetCode = AOM_set_value_string (tItemRevMasterForm,pcReleasedChangePropName,pcChangeRevID);
	//set the customer name
	iRetCode = AOM_set_value_strings (tItemRevMasterForm,pcCustomerNamePropName,iNoofCustName,pcCustomerName);
	//set the Customer authorization no.
	iRetCode = AOM_set_value_strings(tItemRevMasterForm,pcCustRelNoPropName,iCntCustAuthNo,pcCustAuthNo);		
	
	return iRetCode;
}
//-----------------------------------------------------------------------------------------------------------------
//! Process_and_set_value()
//! \param  tag_t	tItemRev					/*<I>*/ 
//!			char	*pcChangeRevID				/*<I>*/
//!			int		iCntCustAuthNo				/*<I>*/
//!			char	**pcCustAuthNo				/*<I>*/
//!			int		iNoofCustName				/*<I>*/
//!			char	**pcCustomerName			/*<I>*/
//! \return int
//! \note	Sets the "released by change", "customer release no" and "custome name" attribute value of the IRM form
//!			of the item revision.
//!		  Returns retcode.
//-----------------------------------------------------------------------------------------------------------------
int Process_and_set_value(tag_t tItemRev,char *pcChangeRevID,int iCntCustAuthNo,char **pcCustAuthNo,
						  int iNoofCustName,char **pcCustomerName )
{
	int             iRetCode						= ITK_ok;
	int				iObjCount						= 0;
	char			acObjectType[WSO_name_size_c+1]	= "";
	tag_t			*ptItemRevMasterForm			= NULL;
	logical			lIsModifiable					= false;
	logical			isOEM							= false;
	logical			isDoc							= false;

	iRetCode = WSOM_ask_object_type(tItemRev, acObjectType);
	if (iRetCode == ITK_ok)
	{
		//get the item revision master form
		iRetCode = tiauto_get_related_objects( "IMAN_master_form",tItemRev,&iObjCount,&ptItemRevMasterForm);
	}
	if (iRetCode == ITK_ok && ptItemRevMasterForm != NULL)
	{
		lIsModifiable = false;
		iRetCode = AOM_ask_if_modifiable (ptItemRevMasterForm[0],&lIsModifiable);
	}
	if (iRetCode == ITK_ok && lIsModifiable == true)
	{
		iRetCode = AOM_refresh(ptItemRevMasterForm[0], true);
		if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_AltRep Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														pcCustAuthNo,iNoofCustName,pcCustomerName,
														"t1a48customerreleaseno","t1a48releasedbychange", "t1a48customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_Product Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														pcCustAuthNo,iNoofCustName,pcCustomerName,
														"t1a1customerreleaseno","t1a1releasedbychange", "t1a1customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_Program Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														pcCustAuthNo,iNoofCustName,pcCustomerName,
														"t1a3customerreleaseno","t1a3releasedbychange", "t1a3customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_Prg_Variant Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														pcCustAuthNo,iNoofCustName,pcCustomerName,
														"t1a4customerreleaseno","t1a4releasedbychange","t1a4customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_DWGFormat Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														pcCustAuthNo,iNoofCustName,pcCustomerName,
														"t1a57customerreleaseno","t1a57releasedbychange", "t1a57customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_CADSeed Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a58customerreleaseno","t1a58releasedbychange", "t1a58customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_CADConstruct Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a60customerreleaseno","t1a60releasedbychange", "t1a60customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "T8_TI_AltConstr Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t8_151customerreleaseno","t8_151releasedbychange", "t8_151customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_Material Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a53customerreleaseno","t1a53releasedbychange", "t1a53customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_Tooling Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a100customerreleaseno","t1a100releasedbychange", "t1a100customername" );
		}
		else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_AltTool Revision") == 0)
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a110customerreleaseno","t1a110releasedbychange","t1a110customername" );
		}
		else if(iRetCode == ITK_ok && ( (tc_strcmp (acObjectType, "T_PPAP Revision") == 0)||
										(tc_strcmp (acObjectType, "P_PPAP Revision") == 0) ) )
		{
			iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														 pcCustAuthNo,iNoofCustName,pcCustomerName,
														 "t1a62customerreleaseno","t1a62releasedbychange", "t1a62customername" );
		}
		else if(iRetCode == ITK_ok)
		{
			isOEM = false;
			isDoc = false;
			iRetCode = IsChildItemType(tItemRev, &isOEM, &isDoc);
			if(iRetCode == ITK_ok && isDoc == true)
			{
				iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														     pcCustAuthNo,iNoofCustName,pcCustomerName,
															 "t1a47customerreleaseno","t1a47releasedbychange","t1a47customername" );
			}
			else if(iRetCode == ITK_ok && isOEM == true)
			{
				iRetCode = set_value_on_itemRevMaster_Form ( ptItemRevMasterForm[0], pcChangeRevID,iCntCustAuthNo,
														     pcCustAuthNo,iNoofCustName,pcCustomerName,
															 "t1a2customerreleaseno","t1a2releasedbychange", "t1a2customername" );
			}
		}						
		if(iRetCode == ITK_ok)
				iRetCode = AOM_save(ptItemRevMasterForm[0]);
		if(iRetCode == ITK_ok)
			iRetCode = AOM_refresh(ptItemRevMasterForm[0],false);
	}
	SAFE_MEM_free(ptItemRevMasterForm);
	return iRetCode;
}
int set_released_info_on_cost_form(tag_t tCostForm,char *pcChangeRevID)
{
	int             iRetCode						= ITK_ok;
	char			acObjectType[WSO_name_size_c+1]	= "";
	logical			lIsModifiable					= false;	
	
	if (iRetCode == ITK_ok && tCostForm != NULLTAG)
	{
			lIsModifiable = false;
			iRetCode = AOM_ask_if_modifiable (tCostForm,&lIsModifiable);
		
			if (iRetCode == ITK_ok && lIsModifiable == true)
			{
				iRetCode = WSOM_ask_object_type(tCostForm, acObjectType);
				if(iRetCode == ITK_ok)
					iRetCode = AOM_refresh(tCostForm,true);

				if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_PurchasedCost") == 0)
				{
					//set the change revision id				
					iRetCode = AOM_set_value_string (tCostForm,"t8_18releasedbychange",pcChangeRevID);
				}
				else if(iRetCode == ITK_ok && tc_strcmp (acObjectType, "TI_ManufacturedCost") == 0)
				{
					//set the change revision id				
					iRetCode = AOM_set_value_string (tCostForm,"t8_16releasedbychange",pcChangeRevID);
				}

				if(iRetCode == ITK_ok)
					iRetCode = AOM_save(tCostForm);
				if(iRetCode == ITK_ok)
					iRetCode = AOM_refresh(tCostForm,false);


				iRetCode = 0;
			}
		
	}

	return iRetCode;
}
int Process_ITR_and_set_released_info_on_cost_form(tag_t tItemRev,char *pcChangeRevID )
{
	int             iRetCode						= ITK_ok;
	int				indx							= 0;
	int				iObjCount						= 0;
	char			acObjectType[WSO_name_size_c+1]	= "";
	tag_t			*ptCostForm			= NULL;
	logical			lIsModifiable					= false;

	
	if (iRetCode == ITK_ok)
	{
		//get the item revision master form
		iRetCode = tiauto_get_related_objects( "TI_CostForms",tItemRev,&iObjCount,&ptCostForm);
	}
	if (iRetCode == ITK_ok && ptCostForm != NULL)
	{
		for(indx =0;indx < iObjCount;indx++)
		{
			iRetCode = set_released_info_on_cost_form(ptCostForm[indx],pcChangeRevID);
		}
	}

	return iRetCode;
}
int findlov(int	iNoofAffPgm,char	**pcAffPgms,int	iLovs,tag_t	*ptLOVtags,int	*iNoofCustName,char	***pcCustomerName)
{
	int		iRetCode						=ITK_ok;
	int		iLOVValueCnt					= 0;
	char	**pcLOVValues					= NULL;
	int		iLoopAffPgm						= 0;
	int		iLoopLOV						= 0;
	int		iSubLOVcount						= 0;
	int		iLoopSubLOV						= 0;
	int		ilistOfFilters					= 0;
	int		*pilistOfFiltersIndexes			= 0;
	int		iLoopFilters					= 0;
	tag_t	*ptlistOfFilters				= NULL;
	tag_t*	ptSubLOV						= NULL;
	char	**pcSubLOVNames					= NULL;
	int		ilistOfParFilters				= 0;
	int		iLoopLOVfil						= 0;
	tag_t	*ptlistOfParFilters				= NULL;

	ptSubLOV=ptLOVtags;
	
	*pcCustomerName = (char**)MEM_alloc((iNoofAffPgm+1) * sizeof(char*));
	iRetCode=LOV_ask_values_string ( ptSubLOV[0],&iLOVValueCnt ,&pcLOVValues);
	for(iLoopLOV=0;iLoopLOV<iLOVValueCnt;iLoopLOV++)
	{
	//sub lov
		iRetCode=LOV_ask_value_filters(ptSubLOV[0],&ilistOfFilters,&pilistOfFiltersIndexes,&ptlistOfFilters);
		for(iLoopFilters =0; iLoopFilters < ilistOfFilters; iLoopFilters++)
		{
			iRetCode=LOV_ask_values_string (ptlistOfFilters[iLoopFilters],&iLOVValueCnt ,&pcLOVValues);			
			iRetCode=LOV_ask_value_filters(ptlistOfFilters[iLoopFilters],&ilistOfParFilters,&pilistOfFiltersIndexes,&ptlistOfParFilters);
			for(iLoopAffPgm=0; iLoopAffPgm< iNoofAffPgm; iLoopAffPgm++)
			{
				for(iLoopLOVfil=0; iLoopLOVfil< ilistOfParFilters; iLoopLOVfil++)
				{
					iRetCode=LOV_ask_values_string ( ptlistOfParFilters[iLoopLOVfil],&iSubLOVcount ,&pcSubLOVNames);
				
					for(iLoopSubLOV=0; iLoopSubLOV< iSubLOVcount; iLoopSubLOV++)
					{
						if((tc_strcmp(pcAffPgms[iLoopAffPgm],pcSubLOVNames[iLoopSubLOV])==0) && (iRetCode==ITK_ok) &&( (*iNoofCustName) < iNoofAffPgm))
						{	
							(*pcCustomerName)[*iNoofCustName] = (char*) MEM_alloc((sizeof(char)*tc_strlen(pcLOVValues[iLoopLOVfil])) + 1);
							tc_strcpy((*pcCustomerName)[*iNoofCustName],pcLOVValues[iLoopLOVfil]);
							(*iNoofCustName)++;
							
						}
					}
				}
			}
			
		}
	}	

	return iRetCode;
}
//main function of the handler "TIAUTO-AH-set-rev-master-form-value"
extern int tiauto_ah_set_rev_master_form_value(EPM_action_message_t msg)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				iNumAttachments								= 0;
	int				iNoofCustRel								= 0;
	int				iNoofCustName								= 0;
	int				iNoofAffPgm									= 0;
	int				iLovs										= 0;

	char			**pcCustomerName							= NULL;
	char			*pcErrMsg									= NULL;
	char			**pcCustAuthNo								= NULL;
	char			*pcChangeRevID								= NULL;
	char			caObjectType[WSO_name_size_c+1]				= "";
	char			caTargetClass[TCTYPE_class_name_size_c+1] = "";	
	char			**pcAffPgms									= NULL;
	char			*pcLOVname									= NULL;	
	
	tag_t			tChangeRev									= NULLTAG;
	tag_t			tRootTask									= NULLTAG;
	tag_t			tTargetType									= NULLTAG;
	tag_t           tCCRForm									= NULLTAG;
	tag_t			*ptAttachments								= NULL;
	tag_t			tLovtag										= NULLTAG;
	tag_t			*ptLovs										= NULL;

	
	if (iRetCode == ITK_ok )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
			if (iRetCode == ITK_ok && tRootTask != NULLTAG)
			{
				//get all target attachments
				iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
													&iNumAttachments, &ptAttachments);
			}
			if(iRetCode == ITK_ok && iNumAttachments > 0)
			{
				//from the targets get the Changerev-id
				iRetCode = tiauto_get_itemrev_name(tChangeRev,&pcChangeRevID);
				//check the PMR for existance as the PMR process can be initiated on the
				//CR, CRB and DAP approved process. DAP, CR and CRB are also having the TI_CCR form.
				//So if both CCR and PMR for present, the PMR form will be considered.
				if (iRetCode == ITK_ok)
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_PMR",&tCCRForm);
				if (iRetCode == ITK_ok && tCCRForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_strings (tCCRForm,"t1a84customerauthno",&iNoofCustRel,&pcCustAuthNo);
					if (iRetCode == ITK_ok)
						iRetCode = AOM_ask_value_strings (tCCRForm,"t1a84customername",&iNoofCustName,&pcCustomerName);
				}
				else if (iRetCode == ITK_ok && tCCRForm == NULLTAG)
				{
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"TI_CCR",&tCCRForm);
					if (iRetCode == ITK_ok && tCCRForm != NULLTAG )
					{
						iRetCode = AOM_ask_value_strings (tCCRForm,"t1a41customerauthno",&iNoofCustRel,&pcCustAuthNo);
						if (iRetCode == ITK_ok)
							iRetCode = AOM_ask_value_strings (tCCRForm,"t1a41customername",&iNoofCustName,&pcCustomerName);
					}
				}
				if (iRetCode == ITK_ok && tCCRForm == NULLTAG)
				{
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CCR2",&tCCRForm);
					if (iRetCode == ITK_ok && tCCRForm != NULLTAG )
					{
						iRetCode = AOM_ask_value_strings (tCCRForm,"t8_191customerauthno",&iNoofCustRel,&pcCustAuthNo);
						//if (iRetCode == ITK_ok)
							//iRetCode = AOM_ask_value_strings (tCCRForm,"t8_191customername",&iNoofCustName,&pcCustomerName);
					}
										
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP2",&tCCRForm);	
					//adding CAP3 changes
					if(tCCRForm == NULLTAG)
					    iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_CAP3",&tCCRForm);
					if (iRetCode == ITK_ok && tCCRForm != NULLTAG )
					{
						iRetCode=AOM_ask_value_strings(tCCRForm,"t8_t1a190affectedprograms",&iNoofAffPgm,&pcAffPgms);
						iRetCode=AOM_ask_lov(tCCRForm,"t8_t1a190affectedprograms",&tLovtag);
						if(tLovtag != NULLTAG)
							iRetCode=LOV_ask_name2(tLovtag,&pcLOVname);

						if(pcLOVname != NULL)
							iRetCode=LOV_find(pcLOVname,&iLovs,&ptLovs);

						if(iRetCode == ITK_ok && iLovs > 0)
							iRetCode =	findlov(iNoofAffPgm,pcAffPgms,iLovs,ptLovs,&iNoofCustName,&pcCustomerName);
					}
				}
				if (iRetCode == ITK_ok && tCCRForm == NULLTAG)
				{
					iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PMR",&tCCRForm);
					if (iRetCode == ITK_ok && tCCRForm != NULLTAG )
					{
						iRetCode = AOM_ask_value_strings (tCCRForm,"t8_193customerauthno",&iNoofCustRel,&pcCustAuthNo);
						//if (iRetCode == ITK_ok)
							//iRetCode = AOM_ask_value_strings (tCCRForm,"t8_193customername",&iNoofCustName,&pcCustomerName);

						iRetCode=AOM_ask_value_strings(tCCRForm,"t8_193affectedprogram",&iNoofAffPgm,&pcAffPgms);
						
						iRetCode=AOM_ask_lov(tCCRForm,"t8_193affectedprogram",&tLovtag);

						if(tLovtag != NULLTAG)							
							iRetCode=LOV_ask_name2(tLovtag,&pcLOVname);

						if(pcLOVname != NULL)
							iRetCode=LOV_find(pcLOVname,&iLovs,&ptLovs);

						if(iRetCode == ITK_ok && iLovs > 0)
							iRetCode =	findlov(iNoofAffPgm,pcAffPgms,iLovs,ptLovs,&iNoofCustName,&pcCustomerName);
						
					}
				}
			}
			for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
            {
				char			*pcTargetClass 								= NULL;	
				if(iRetCode == ITK_ok)
				{
					iRetCode = TCTYPE_ask_object_type(ptAttachments[indx],&tTargetType);
				}
				if(iRetCode == ITK_ok && tTargetType != NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tTargetType, &pcTargetClass));
					if (iRetCode == ITK_ok && ((tc_strcmp (pcTargetClass, TIAUTO_ITEMREVISION) != 0) || (tc_strcmp (pcTargetClass, TIAUTO_FORM) != 0)))
					{
						tag_t			tParentType									= NULLTAG;
					
						TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
						if(tParentType != NULLTAG)
						{
							SAFE_MEM_free(pcTargetClass);
							TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pcTargetClass));
						}
						
					}
				}               			
				// check if the classname of the targeted object pseudo folder is ItemRevision or Document Revision
				if (iRetCode == ITK_ok && ((tc_strcmp (pcTargetClass, TIAUTO_ITEMREVISION) == 0) || (tc_strcmp (pcTargetClass, TIAUTO_TI_DOCUMENTREVISION) == 0)))				
				{
					iRetCode = WSOM_ask_object_type(ptAttachments[indx], caObjectType);
					if (iRetCode == ITK_ok && ( (tc_strcmp (caObjectType, CHANGE_REV) == 0 ) || (tc_strcmp (caObjectType, NEWCHANGE_REV) == 0 ) ))
		            {					
						continue;
					}
					else if(iRetCode == ITK_ok)
					{
						//process the item revision					
						iRetCode = Process_and_set_value( ptAttachments[indx],pcChangeRevID,iNoofCustRel,pcCustAuthNo,
														  iNoofCustName,pcCustomerName);
					}
				}
				else if (iRetCode == ITK_ok && tc_strcmp (pcTargetClass, "Form") == 0)
				{
					iRetCode = WSOM_ask_object_type(ptAttachments[indx], caObjectType);
					if (iRetCode == ITK_ok && ( (tc_strcmp (caObjectType, "TI_PurchasedCost") == 0 ) || 
												(tc_strcmp (caObjectType, "TI_ManufacturedCost") == 0 )) )
		            {	
						iRetCode = set_released_info_on_cost_form(ptAttachments[indx],pcChangeRevID);
					}
				}
				SAFE_MEM_free(pcTargetClass);
			}
			SAFE_MEM_free(ptAttachments);
			SAFE_MEM_free(pcCustAuthNo);
			SAFE_MEM_free(pcChangeRevID);
			SAFE_MEM_free(pcCustomerName);
		}
	}
	if (iRetCode != ITK_ok ) 
	{
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcCustomerName);
	return iRetCode;
}
