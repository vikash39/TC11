/* tiauto_canned_methods.c       - canned methods for TI Automotive  */
/*                                                                    */
/*Version 00001 - 08/11/2006 D. Atherton - Initial Release            */
/*        Created family form canned method                           */
/*        00002 - 08/28/2006 D. Atherton 
/*        Modified family form canned method to use t1aPartFamily     */
/*        Modified family form canned method to use t1a1PartFamily    */
/*        00003 - 01/10/2007 D. Atherton 
/*        Modified to use an attribute defined by the preference:     */
/*         <ITEM_TYPE>_t1aAutomatedAttribute rather than part family  */
#include <tiauto_defines.h>
#include <tiauto_utils.h>
#include <tiauto_canned_methods.h>

void report_error_stack(int status);
/* t1aFamilyFormCreation - Canned Method to create a family form and set  */
/*                    the part family attribute in the Item Master Form  */
/*                    Inputs:                                            */
/*                           Option I  = LOV name containing the list of */
/*                                       part names for a specific family*/
/*                           Option II = Family Part attribute           */
/*                           Option III= Name of the form to create      */
/* The canned method will be invoked on the creation of a new item after */
/* From the Part Name, it will determine what the family part attribute  */
/* should be set to, set it and if applicable create the family form     */ 

int t1aFamilyFormCreation( METHOD_message_t * msg, va_list args )

{
    int 			 status = ITK_ok;
    int                          item_master_count;
    int                          cm_action_type; 
    int                          cm_execution_sequence; 
    int                          cm_num_of_option_values; 
    int                          cm_num_of_options; 
    int                          lov_cnt; 
    int                          lov_value_cnt; 
    int                          i;
    int                          j;
    int                          selected_value_num=-1;
 
    char                         cm_type_name[33];
    char                         cm_msg_name[33];
    char                         cm_method_name[33];
    char                         new_form_name[33];
    char                         partfamily[33];
    char                         formtype[33];
    char                         **lov_values;
    char                         att_pref[33];
    char                         *auto_attribute;
    
    char                         ***cm_option_values;

    tag_t                        family_form_t;
    tag_t                        spec_type_t;
    tag_t                        master_rel_type_t;
    tag_t                        new_rel_t;
    tag_t                        item_t;
    tag_t                        itemrev_t;
    tag_t                        *master_attachments_t;
    tag_t                        cmTag;
    tag_t                        formtype_t;
    tag_t                        *lov_t;
    WSO_description_t	         itemrev_desc;
    WSO_description_t	         item_desc;
    logical tag_valid = false;
   
    /* Load The Canned Method into Memory */
    TC_init_argument_list(msg->user_args);
    cmTag = TC_next_int_argument( msg->user_args );

    /* Get the item tag */
    item_t = va_arg(args,tag_t );
    status = ITEM_ask_latest_rev(item_t,&itemrev_t);
    if ( status != ITK_ok ) {report_error_stack(status);}

    WSOM_describe (itemrev_t,&itemrev_desc);
    WSOM_describe (item_t,&item_desc);

    TI_sprintf (att_pref,"%s_t1aAutomatedAttribute",item_desc.object_type);

    status = PREF_initialize();
    if ( status != ITK_ok ) report_error_stack(status);

    status = PREF_set_search_scope(TC_preference_all);
    if ( status != ITK_ok ) report_error_stack(status);
 
    status = PREF_ask_char_value(att_pref,0,&auto_attribute);
    if ( status != ITK_ok ) report_error_stack(status);


     /* Check if canned method tag is valid */
    if ( (status = POM_instance_exists(cmTag, &tag_valid)) != ITK_ok)
    {  
    report_error_stack(status);
    }

     /* If tag is not valid, store the error and return. */
    if (! tag_valid)
    {
    status =  METHOD_CM_tag_not_valid;
    return status;
    }

    /* load the canned method description */
    status = METHOD_CM_describe (  cmTag , 
                          cm_type_name ,
                          cm_msg_name ,
                          &cm_action_type ,
                          cm_method_name ,
                          &cm_execution_sequence ,
                          &cm_num_of_option_values ,
                          &cm_num_of_options ,
                          &cm_option_values  );

    if ( status != ITK_ok ) {report_error_stack(status);}

    /*Find the corresponding canned method option by checking the LOVs*/
    /*of each set of option values against the part number.  The first*/
    /*LOV found that contains the part name will be used to define the*/
    /*family part attribute and form name                             */
    for (i = 0; i < cm_num_of_option_values; i++)
    {
        lov_cnt = -1;

        status = LOV_find(cm_option_values[i][0],&lov_cnt,&lov_t);  

        if (lov_t == NULLTAG )
        {
            printf ("lov - %s was not found in the database!!!\n",
                      cm_option_values[i][0]);
            TC_write_syslog ("lov - %s was not found in the database!!!\n",
                      cm_option_values[i][0]);
            continue;
        }

        status = LOV_ask_values_string(lov_t[0],&lov_value_cnt,&lov_values);

        for (j = 0; j < lov_value_cnt; j ++)
        {
             if (tc_strcmp (itemrev_desc.object_name,lov_values[j]) == 0)
             {
                 selected_value_num = i;
                 i = cm_num_of_option_values;
             }
        
        }

        MEM_free(lov_values); 
        MEM_free(lov_t);
    }
   
    /* if there is no appropriate family form or part family */
    /* attribute found set the part family attribute to NONE and*/
    /* set form type to NONE (no form will be creates*/ 
    if (selected_value_num >= 0)   
    {
       if(cm_option_values[selected_value_num][1] != NULL)
       {
            TI_sprintf(partfamily,"%s",cm_option_values[selected_value_num][1]);
       }
       if(cm_option_values[selected_value_num][2] != NULL)
       {
            TI_sprintf(formtype,"%s",cm_option_values[selected_value_num][2]);
       } 
       else
       {
           TI_sprintf(partfamily,"%s","NONE");
           TI_sprintf(formtype,"%s","NONE");
       }
    }
    else
    {
        TI_sprintf(partfamily,"%s","NONE");
        TI_sprintf(formtype,"%s","NONE");
    }
    
    /* Modify the Item Master form by setting the attribute t1a1PartFamily to the
       correct value */ 
    status = TCTYPE_find_type( "IMAN_master_form", NULL, &master_rel_type_t );
    if ( status != ITK_ok ) {report_error_stack(status);}
    status = GRM_list_secondary_objects_only(item_t,master_rel_type_t,
            &item_master_count,&master_attachments_t);
    if ( status != ITK_ok ) {report_error_stack(status);}

    status = AOM_refresh(master_attachments_t[0],1);
    if ( status != ITK_ok ) {report_error_stack(status);}
                        
    status = AOM_set_value_string(master_attachments_t[0],
                                  auto_attribute, 
                                   partfamily);         

    if ( status != ITK_ok ) {report_error_stack(status);}
                  
    status = AOM_save(master_attachments_t[0]);
    if ( status != ITK_ok ) {report_error_stack(status);}
          
    status = AOM_refresh(master_attachments_t[0],0);
    if ( status != ITK_ok ) {report_error_stack(status);}
                   

    if (master_attachments_t != NULLTAG)
    {
        MEM_free(master_attachments_t);
    }

    /* Try to find the appropriate form type 
       (if NULLTAG is returned no form will be created)*/

    status = TCTYPE_find_type(formtype,"Form",&formtype_t);
    if ( status != ITK_ok ) {report_error_stack(status);}

    /* If the form type is found, create the form and relate
       it to the item revision with a specification relationship */
    if (formtype_t != NULLTAG)
    {
        /* The following line will name the form the same as the
           Item Name  */
        TI_sprintf (new_form_name,"%s",itemrev_desc.object_name);

        /* The following line could be used to create a form named 
           Item ID/Item Rev-Part Family Attribute.  If this is done,
           there would be a need to create code to modify the deep copy 
           naming rules for forms.  The default is to name the form 
           with theItem Name*/
        /* TI_sprintf (new_form_name,"%s-%s",itemrev_desc.id_string,partfamily); */

        status = FORM_create(new_form_name,
                         new_form_name,
                         formtype,
                         &family_form_t);

        if ( status != ITK_ok ) {report_error_stack(status);}

        status = TCTYPE_find_type( "IMAN_specification", NULL, &spec_type_t );
        if ( status != ITK_ok ) {report_error_stack(status);}
     
        status = GRM_create_relation(itemrev_t,family_form_t,spec_type_t,NULLTAG,&new_rel_t);
        if ( status != ITK_ok ) {report_error_stack(status);}
    
        status = AOM_save (family_form_t);
        if ( status != ITK_ok ) {report_error_stack(status);}
    
        status = AOM_refresh(family_form_t,0);
        if ( status != ITK_ok ) {report_error_stack(status);}
    
        status = GRM_save_relation(new_rel_t);
        if ( status != ITK_ok ) {report_error_stack(status);}
    
    }
    /* Free up the memory from the cm option values*/
    for (i = 0; i < cm_num_of_option_values; i++) 
    {
         MEM_free (cm_option_values[i]);
    }

    return status;

}
 
/* Register and add the TI specific canned methods */
int t1aAUTO_register_canned_methods(int *decision, va_list args)
{
    int status = ITK_ok; 
    *decision  = ALL_CUSTOMIZATIONS;

    /* Add FamilyFormCreation canned method.  
       This will require the queries:
          __t1a_LOV_STRING_NAMES (a query of the string lovs in the system)
          __t1a_AVAILABLE_TYPES  (a query of all form types in the system).
       lov_name (option I)   = LOV with a list of part names for a given part family.
       family   (option II)  = family part attribute. 
       form_name(option III) = form type name
    */ 

    status = METHOD_CM_register_function ("FamilyFormCreation", (METHOD_function_t)t1aFamilyFormCreation) ;

    if (status !=ITK_ok) 
    {
        report_error_stack(status);
    }
     
    status = METHOD_CM_add_method(
        "ItemRevision",
        ITEM_create_rev_msg, 
        METHOD_CM_Post_Action_type,
        "FamilyFormCreation",
        "lov_name::family::form_name",
        "Y::Y::N",
        "__t1a_LOV_STRING_NAMES~lov_name:: ::__t1a_AVAILABLE_TYPES~type_name" );


    if (status !=ITK_ok) 
    {
        report_error_stack(status);
    }
 
    return ITK_ok;
}

/*  Print out the full error stack. */
void report_error_stack( int status )
{
    int  i, n_errors;
    int *severities;
    int *statuses;
    char **messages;
    EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
    printf  ( "Error(s): \n");
    TC_write_syslog  ( "Error(s): \n");
    for (i = 0; i < n_errors; i++) {
        printf( "    %6d: %s\n", statuses[i], messages[i] );
        TC_write_syslog( "    %6d: %s\n", statuses[i], messages[i] );
    }
    exit(status);
}
