/************************************************************************************************************
File         : tiauto_ah_create_cae_report_translation_request.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
April 3, 2014    1.0        Dipak Naik      Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <time.h>

//main function of the handler "TIAUTO-AH-Create-ERP-Translation-Request"
extern int TIAUTO_AH_create_cae_report_translation_request(EPM_action_message_t msg)
{
	int             iRetCode									= ITK_ok;
	int				indx										= 0;
	int				iNumAttachments								= 0;
	int				iSite										= 0;
	int				iSiteID										= 0;
	int				iNoOfResultRevs								= 0;
	
	char			**pcCustomerName							= NULL;
	char			*pcErrMsg									= NULL;
	char			acObjectType[WSO_name_size_c+1]				= "";
	
	tag_t			tCAEReqRev								= NULLTAG;
	tag_t			tCAEResultRev								= NULLTAG;
	tag_t			tCAEResultRelation								= NULLTAG;
	tag_t			tRootTask									= NULLTAG;
	tag_t           tRequest								= NULLTAG;
	tag_t			*ptAttachments						= NULL;
	tag_t			*ptResultRevs						= NULL;

	boolean bValidERPPlant			= false;
	boolean bMfgRelAuthToBeCreated	= false;
	
	//Get the Current Site Name
	iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments, &ptAttachments);

    for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
    {
        iRetCode = WSOM_ask_object_type(ptAttachments[indx], acObjectType);
       
        if (iRetCode == ITK_ok && tc_strcmp (acObjectType, "T8_T_CAERequest Revision") == 0 )
        {
            tCAEReqRev = ptAttachments[indx];
            break; 
        }
    }

	if (iRetCode == ITK_ok && tCAEReqRev != NULLTAG )
	{
		tCAEResultRev = NULLTAG;
		
		iRetCode = GRM_find_relation_type ("T8_TI_CAERequestRevisions", &tCAEResultRelation);
		
		iRetCode = GRM_list_secondary_objects_only(tCAEReqRev,tCAEResultRelation,&iNoOfResultRevs,&ptResultRevs);
		for(indx =0; indx< iNoOfResultRevs; indx++)
		{
			tc_strcpy(acObjectType,"");
			iRetCode = WSOM_ask_object_type(ptResultRevs[indx],acObjectType);
			if(tc_strcmp(acObjectType,"T8_TI_CAE_ResultRevision") == 0)
			{
				//get the result revisions
				iRetCode = DISPATCHER_create_request  ( "TI-CAE", "caereport",3,0 ,0 ,0, 1,&(ptResultRevs[indx]),&tCAEReqRev ,0  ,NULL,"CAEReportCreate",0,NULL,NULL,&tRequest);
			}
		}
		SAFE_MEM_free(ptResultRevs);
	}
	if (iRetCode != ITK_ok ) 
	{
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(ptAttachments);
	
	return iRetCode;
}
