/************************************************************************************************************
File         : tiauto_ah_update_history_form_on_rejection.c

Description  : 

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------------------------
May 12, 2014    1.0        Manik			 Initial Creation
**************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


extern void TIA_sprintf(char* buffer, char * format, ... )
{
	int len = 0;
	va_list args;
	va_start( args, format );
	len = _vscprintf( format, args ) + 1;
	vsprintf_s( buffer, len, format, args);
}

/* This function will remove the status from the input form*/
static int  remove_existing_form_status (tag_t  tRevTag)
{
    int     iRetCode		= ITK_ok;
	int		iAttachmentType = EPM_target_attachment;
   
    char    *cProcess	   = "Remove Status";
    char    *pcProcessDesc = "Process template for removing existing status";
    char    *pcProcessName ="test";

    tag_t   tProcessTemplate	= NULLTAG;
    tag_t   tNewProcess			= NULLTAG;    
   logical verdict				= false;

	iRetCode = POM_is_loaded(tRevTag, &verdict);	
    if (verdict == FALSE && iRetCode == ITK_ok)
    {
		iRetCode = POM_refresh_instances_any_class(1, &tRevTag, POM_no_lock);
	}
	if ( iRetCode == ITK_ok )
	/*{
		iRetCode = WSOM_ask_release_status_list(tFormTag, &iStsCnt, &status_list);	
	}	
	if ( iStsCnt >= 1 && iRetCode == ITK_ok )*/
	{
		iRetCode = EPM_find_process_template (cProcess, &tProcessTemplate);
		// Removing the status of the item revision using quick release process.
		if (iRetCode == ITK_ok && tProcessTemplate != NULLTAG && tRevTag != NULLTAG)
		{
			iRetCode = EPM_create_process (pcProcessName, pcProcessDesc, 
												tProcessTemplate, 1,&tRevTag, &iAttachmentType, &tNewProcess);
		}		
		if(iRetCode != ITK_ok)
		{
			print_err_msg(iRetCode);
			iRetCode = ITK_ok;
		}
	}	
	return  iRetCode;
}

static int  set_editable_status (tag_t  tObjTag)
{
    int     iRetCode		= ITK_ok;
	int		iAttachmentType = EPM_target_attachment;
   
    char    *cProcess	   = "Part Release - TI Editable";
    char    *pcProcessDesc = "Process template for setting TI Editable status";
    char    *pcProcessName = "test";

    tag_t   tProcessTemplate	= NULLTAG;
    tag_t   tNewProcess			= NULLTAG;    
   logical verdict				= false;

	iRetCode = POM_is_loaded(tObjTag, &verdict);	
    if (verdict == FALSE && iRetCode == ITK_ok)
    {
		iRetCode = POM_refresh_instances_any_class(1, &tObjTag, POM_no_lock);
	}
	if ( iRetCode == ITK_ok )
	/*{
		iRetCode = WSOM_ask_release_status_list(tFormTag, &iStsCnt, &status_list);	
	}	
	if ( iStsCnt >= 1 && iRetCode == ITK_ok )*/
	{
		iRetCode = EPM_find_process_template (cProcess, &tProcessTemplate);
		// Removing the status of the item revision using quick release process.
		if (iRetCode == ITK_ok && tProcessTemplate != NULLTAG && tObjTag != NULLTAG)
		{
			iRetCode = EPM_create_process (pcProcessName, pcProcessDesc, 
												tProcessTemplate, 1,&tObjTag, &iAttachmentType, &tNewProcess);
		}
		if(iRetCode != ITK_ok)
		{
			print_err_msg(iRetCode);
			iRetCode = ITK_ok;
		}
	}
	return  iRetCode;
}

/* This function will remove the status from the input form*/
static int  set_form_status_to_study_rejected (tag_t  tObject)
{
    int     iRetCode		= ITK_ok;
	int		iAttachmentType = EPM_target_attachment;
   
    char    *cProcess	   = "Part Release - Study Rejected";
    char    *pcProcessDesc = "Process template for setting Study Rejected status";
    char    *pcProcessName ="to set Study Rejected status on the history form";

    tag_t   tProcessTemplate	= NULLTAG;
    tag_t   tNewProcess			= NULLTAG;    
    logical verdict				= false;

	iRetCode = POM_is_loaded(tObject, &verdict);	
    if (verdict == FALSE && iRetCode == ITK_ok)
    {
		iRetCode = POM_refresh_instances_any_class(1, &tObject, POM_no_lock);
	}
	if ( iRetCode == ITK_ok )
	/*{
		iRetCode = WSOM_ask_release_status_list(tFormTag, &iStsCnt, &status_list);	
	}	
	if ( iStsCnt >= 1 && iRetCode == ITK_ok )*/
	{
		iRetCode = EPM_find_process_template (cProcess, &tProcessTemplate);
		// Removing the status of the item revision using quick release process.
		if (iRetCode == ITK_ok && tProcessTemplate != NULLTAG && tObject != NULLTAG)
		{
			iRetCode = EPM_create_process (pcProcessName, pcProcessDesc, 
												tProcessTemplate, 1,&tObject, &iAttachmentType, &tNewProcess);
		}		
		if(iRetCode != ITK_ok)
		{
			print_err_msg(iRetCode);
			iRetCode = ITK_ok;
		}
	}	
	return  iRetCode;
}


int swap_attribute_value_of_history_form(tag_t tMainForm, tag_t tECRev, tag_t tRootTask)
{
	int iRetCode  = 0;
	int iStatus = 0;
	int		iSecCnt				= 0;
	int iPropCnt = 0;
	int ix = 0;
	int iHisFormIdx = 0;
	int	iAttachmnetType	= EPM_target_attachment;
	tag_t	*ptSecondaryList	= NULLTAG;
	tag_t tRelationtype = NULLTAG;
	tag_t tHistoryForm = NULLTAG;
	char **pcPropNames	= NULL;
	char *pcValueMainForm = NULL;
	char *pcValueHistoryForm = NULL;
	char *pcChangeRevStr = NULL;
	char acFormName[WSO_name_size_c + 1] = "";
	char acHistoryFormName[WSO_name_size_c + 1] = "";
	char acObjType[WSO_name_size_c+1] = "";
	char testName[50]="";
	date_t dReleasedDate = NULLDATE;
	logical verdict		= false;
	logical lIsHistoryFormModifiable	= false;
	char *pcClassName	= NULL;
	tag_t tClass		= NULLTAG;
	tag_t tObjName		= NULLTAG;
	tag_t tRelStatAttrId = NULLTAG;
	tag_t tRelDateAttrId = NULLTAG;
	tag_t *ptStatusList = NULL;
	tag_t tReleaseStatus = NULLTAG;
	date_t dReleaseDate = NULLDATE;
	date_t dCreationDate = NULLDATE;
	errno_t err;
	struct tm ltm;// = localtime(&now);
	time_t now = time(0);
	
	err = localtime_s(&ltm,&now);

	if(tMainForm==NULLTAG || tECRev==NULLTAG)
		return -1;
	dReleasedDate.day = ltm.tm_mday;
	dReleasedDate.year = 1900 + ltm.tm_year;
	dReleasedDate.month = ltm.tm_mon;
	dReleasedDate.hour = ltm.tm_hour;
	dReleasedDate.minute = ltm.tm_min;
	dReleasedDate.second = ltm.tm_sec;
	iRetCode = WSOM_ask_object_type (tMainForm, acObjType);
	iRetCode = GRM_find_relation_type ("TI_FormHistory", &tRelationtype);
	iRetCode = GRM_list_secondary_objects_only (tMainForm,tRelationtype, &iSecCnt, &ptSecondaryList);
	//get the change rev string
	iRetCode = tiauto_get_itemrev_name(tECRev,&pcChangeRevStr);
	
	if( iRetCode == ITK_ok && ptSecondaryList != NULLTAG )
	{
		tHistoryForm = ptSecondaryList[0];

		for(iHisFormIdx=0;iHisFormIdx <iSecCnt-1;iHisFormIdx++ )
		{	
			date_t dReleaseDateTemp = NULLDATE;
			date_t dReleaseDateTemp1 = NULLDATE;
			//iRetCode = WSOM_ask_name(ptSecondaryList[i],acFormName);
			iRetCode = AOM_ask_value_date (ptSecondaryList[iHisFormIdx],"creation_date",&dReleaseDateTemp);
			if(iHisFormIdx == 0)
			{
				dCreationDate = dReleaseDateTemp;
			}
			iRetCode = AOM_ask_value_date (ptSecondaryList[iHisFormIdx+1],"creation_date",&dReleaseDateTemp1);
			//printf("\nComparing %d :: %d\n",ptSecondaryList[i],ptSecondaryList[i+1]);
			if(dReleaseDateTemp1.year >= dCreationDate.year)
			{
				if(dReleaseDateTemp1.month >= dCreationDate.month)
				{
					if(dReleaseDateTemp1.day >= dCreationDate.day)
					{
						if(dReleaseDateTemp1.hour >= dCreationDate.hour)
						{
							if(dReleaseDateTemp1.minute >= dCreationDate.minute)
							{
								if(dReleaseDateTemp1.second >= dCreationDate.second)
								{
									dCreationDate = dReleaseDateTemp1;
									tHistoryForm = ptSecondaryList[iHisFormIdx+1];
								}
								else if(dReleaseDateTemp1.minute > dCreationDate.minute)
								{
									dCreationDate = dReleaseDateTemp1;
									tHistoryForm = ptSecondaryList[iHisFormIdx+1];
								}
							}
							else if(dReleaseDateTemp1.hour > dCreationDate.hour)
							{
								dCreationDate = dReleaseDateTemp1;
								tHistoryForm = ptSecondaryList[iHisFormIdx+1];
							}
						}
						else if(dReleaseDateTemp1.day > dCreationDate.day)
						{
							dCreationDate = dReleaseDateTemp1;
							tHistoryForm = ptSecondaryList[iHisFormIdx+1];
						}
					}
					else if(dReleaseDateTemp1.month > dCreationDate.month)
					{
						dCreationDate = dReleaseDateTemp1;
						tHistoryForm = ptSecondaryList[iHisFormIdx+1];
					}
				}
				else if(dReleaseDateTemp1.year > dCreationDate.year)
				{
					dCreationDate = dReleaseDateTemp1;
					tHistoryForm = ptSecondaryList[iHisFormIdx+1];
				}
			}
		}
	}
	else if(iSecCnt == 0)
	{
		return iRetCode;
	}
	SAFE_MEM_free(ptSecondaryList);
	if(tHistoryForm != NULLTAG)
	{
		iRetCode = AOM_ask_if_modifiable (tHistoryForm,&lIsHistoryFormModifiable);			
		iRetCode = WSOM_ask_release_status_list ( tHistoryForm, &iStatus, &ptStatusList);
		if(iStatus > 0 && ptStatusList != NULL)
		{
			iRetCode = AOM_ask_value_date (tHistoryForm,"date_released",&dReleaseDate);
		}
		//iRetCode = remove_existing_form_status(tHistoryForm);		
	}
	if(tHistoryForm != NULLTAG && lIsHistoryFormModifiable == false )
	{
		iRetCode = set_editable_status(tHistoryForm);
		if(iRetCode==ITK_ok)
			iRetCode = EPM_add_attachments (tRootTask, 1, &(tHistoryForm),&iAttachmnetType);
		if(iRetCode==ITK_ok)
		{
			iRetCode = AOM_ask_if_modifiable (tHistoryForm,&lIsHistoryFormModifiable);	
		}
	}
	if(tHistoryForm != NULLTAG && tMainForm != NULLTAG && lIsHistoryFormModifiable==true)
	{
		iRetCode = WSOM_ask_name(tMainForm,acFormName);
		iRetCode = WSOM_ask_object_type (tMainForm, acObjType);	
		printf("%s\n",acFormName);		
		iRetCode = AOM_refresh(tHistoryForm,true);
		iRetCode = AOM_refresh(tMainForm,true);
		iRetCode = FORM_ask_prop_names  ( tMainForm, &iPropCnt, &pcPropNames);
		for( ix = 0; ix < iPropCnt; ix++)
		{
			if( (tc_strncasecmp ("t1a",pcPropNames[ix],3) == 0)|| (tc_strncasecmp ("t8_",pcPropNames[ix],3) == 0))
			{
				iRetCode = AOM_UIF_ask_value (tMainForm, pcPropNames[ix], &pcValueMainForm);
				iRetCode = AOM_UIF_ask_value (tHistoryForm, pcPropNames[ix], &pcValueHistoryForm);
				iRetCode = AOM_UIF_set_value (tHistoryForm, pcPropNames[ix], pcValueMainForm);
				iRetCode = AOM_UIF_set_value (tMainForm, pcPropNames[ix], pcValueHistoryForm);
			}
			SAFE_MEM_free(pcValueMainForm);
			SAFE_MEM_free(pcValueHistoryForm);
		}
		SAFE_MEM_free(pcPropNames);
		if( tc_strcmp( acObjType, "TI_ManufacturedCost") == 0)
		{
			iRetCode = AOM_UIF_set_value (tHistoryForm, "t8_16releasedbychange", pcChangeRevStr);
		}
		else if(tc_strcmp( acObjType, "TI_PurchasedCost") == 0)
		{
			iRetCode = AOM_UIF_set_value (tHistoryForm, "t8_18releasedbychange", pcChangeRevStr);
		}
		else if(tc_strcmp( acObjType, "TI_Product Revision Master") == 0)
		{
			iRetCode = AOM_UIF_set_value (tHistoryForm, "t8_1irmupdatedbychange", pcChangeRevStr);
		}
		SAFE_MEM_free(pcChangeRevStr);
		//iRetCode = AOM_set_value_string(tHistoryForm,"object_name",acFormName);
		iRetCode = AOM_save(tMainForm);
		iRetCode = AOM_refresh(tMainForm,false);
		iRetCode = AOM_save(tHistoryForm);
		iRetCode = AOM_refresh(tHistoryForm,false);
		iRetCode = CR_create_release_status ("Study Rejected",&tReleaseStatus);
		iRetCode = AOM_save(tReleaseStatus);
		//iRetCode = updateFormName(tHistoryForm, acFormName);
		TIA_sprintf(acHistoryFormName,"%s;%d",acFormName,(iSecCnt));
		iRetCode = POM_is_loaded(tHistoryForm, &verdict);
		if (verdict == TRUE && iRetCode == ITK_ok)
		{
			iRetCode = POM_unload_instances(1, &tHistoryForm);
		}
		if( ( (tc_strcmp( acObjType, "TI_ManufacturedCost") == 0) ||
			   (tc_strcmp( acObjType, "TI_PurchasedCost") == 0)) && iStatus > 0 && ptStatusList != NULL)
		{
			iRetCode = t1aSetStatus(tMainForm,ptStatusList[iStatus-1],dReleaseDate);
		}
		SAFE_MEM_free(ptStatusList);
		if(iRetCode==ITK_ok)
			iRetCode = POM_load_instances_any_class(1, &tHistoryForm, POM_modify_lock);
		if(iRetCode==ITK_ok)
			iRetCode = POM_class_of_instance (tHistoryForm, &tClass);
		if(iRetCode==ITK_ok)
			iRetCode = POM_name_of_class (tClass, &pcClassName);
		if(iRetCode==ITK_ok)
			iRetCode = POM_attr_id_of_attr("object_name", pcClassName, &tObjName);
		if (iRetCode == ITK_ok)		
			iRetCode = POM_attr_id_of_attr ("release_status_list", pcClassName, &tRelStatAttrId);
		if ( iRetCode == ITK_ok )		
			iRetCode = POM_attr_id_of_attr ("date_released", pcClassName, &tRelDateAttrId);
		SAFE_MEM_free(pcClassName);
		iRetCode = iRetCode = EPM_remove_attachments( tRootTask,1, &tHistoryForm);

		if (iRetCode == ITK_ok)
			iRetCode = POM_set_attr_tags(1, &tHistoryForm, tRelStatAttrId, 0, 1, &tReleaseStatus);
		if(iRetCode == ITK_ok)
			iRetCode=POM_set_attr_date(1, &tHistoryForm, tRelDateAttrId, dReleasedDate);	
		if(iRetCode==ITK_ok)
			iRetCode = POM_set_attr_string(1, &tHistoryForm, tObjName, acHistoryFormName );
		if(iRetCode==ITK_ok)
			iRetCode = POM_save_instances(1, &tHistoryForm, FALSE);
		iRetCode = POM_refresh_instances_any_class(1, &tHistoryForm, POM_no_lock);	
		iRetCode = WSOM_ask_name(tHistoryForm,testName);		
		
	}
	return iRetCode;
}



extern int TIAUTO_AH_update_history_form_on_rejection(EPM_action_message_t msg)
{
	int iRetCode  = 0;
	int		i					= 0;
	int iNumArgs = 0;
	int indx = 0;
	
	int iCount = 0;
	int iNoOfRefs = 0;
	int		iAttachmnetType		= EPM_target_attachment;
	int		iNumJobs			= 0;
	tag_t	tECRev				= NULLTAG;
	tag_t	tRootTask			= NULLTAG;
	tag_t	tRelationtype		= NULLTAG;
	tag_t tSecondaryObjType = NULLTAG;
	tag_t tObjectType = NULLTAG;
	tag_t *ptChangeFolderSecObjs = NULL;
	tag_t *ptReferences = NULL;
	tag_t	*ptJobs				= NULL;
	tag_t	tCMFRelation		= NULLTAG;

	char acObjectTypeName[WSO_name_size_c+1]   = {'\0'};
	char acExitSecondaryType[WSO_name_size_c+1] = {'\0'};	
	char *pcArgName = NULL;
	char *pcArgValue = NULL;
	char *pcTargetTypeName = NULL;

	boolean lIsModifiable = false;
	/* get the arguments from the handler */
	iNumArgs = TC_number_of_arguments(msg.arguments);

	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,"EngChange Revision");

	/* validate the handler arguments */
    if ( iNumArgs == 1)
	{
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if ( iRetCode == ITK_ok ) 
			{
				if( iRetCode == ITK_ok && tc_strcmp(pcArgName, "target_type" ) == 0)
				{
					tc_strcpy( pcTargetTypeName, pcArgValue);
				}
				/* if the argument mentioned is not "lov" */
				else
					iRetCode = EPM_invalid_argument;
			}
		}
	}

    iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
	if ( (iRetCode == ITK_ok) && (tECRev != NULLTAG) )
	{	
		//check whether the EngChange revision is in process
		iRetCode = CR_ask_job(tECRev, &iNumJobs, &ptJobs);
		//get the root task
		if(iRetCode == ITK_ok && ptJobs!= NULL)
			iRetCode = EPM_ask_root_task (ptJobs[0], &tRootTask);
		
	
		iRetCode = GRM_find_relation_type ("TI_FormHistory", &tRelationtype);
		if(iRetCode == ITK_ok && tc_strcmp(pcTargetTypeName,"EngChange Revision")	== 0)
		{
			iRetCode = AOM_ask_value_tags(tECRev, "t1achanged_forms", &iCount,&ptChangeFolderSecObjs);
		}
		else if(iRetCode == ITK_ok && tc_strcmp(pcTargetTypeName,"T8_TI_ChangeRevision")	== 0)	
		{
			iRetCode = GRM_find_relation_type("T8_CMTIChangedForms",&tCMFRelation);
			if(tCMFRelation != NULLTAG)
				iRetCode = GRM_list_secondary_objects_only(tECRev, tCMFRelation, &iCount,&ptChangeFolderSecObjs);
		}

		for( i=0;iRetCode == ITK_ok && i<iCount;i++)
		{
			if(iRetCode == ITK_ok)
			iRetCode = TCTYPE_ask_object_type(ptChangeFolderSecObjs[i], &tSecondaryObjType);
			if(iRetCode == ITK_ok)
				iRetCode = TCTYPE_ask_name(tSecondaryObjType, acExitSecondaryType);
			iRetCode = AOM_ask_if_modifiable (ptChangeFolderSecObjs[i],&lIsModifiable);
			if( iRetCode == ITK_ok && lIsModifiable==true && tc_strcmp( acExitSecondaryType, "TI_Product Revision Master") == 0)
			{
				iRetCode = GRM_find_relation_type("IMAN_master_form", &tRelationtype);
				iRetCode = GRM_list_primary_objects_only(ptChangeFolderSecObjs[i],tRelationtype,&iNoOfRefs,&ptReferences);
				
				if( iNoOfRefs > 0 && ptReferences[0] != NULLTAG )
					iRetCode = TCTYPE_ask_object_type  ( ptReferences[0], &tObjectType);
				if( iRetCode == ITK_ok && tObjectType != NULLTAG)
					iRetCode = TCTYPE_ask_name  ( tObjectType, acObjectTypeName);
					
				if( iRetCode == ITK_ok && strcmp ( acObjectTypeName, "TI_Product Revision")== 0)
				{
					iRetCode = EPM_add_attachments (tRootTask, 1, &(ptReferences[0]),&iAttachmnetType);
					SAFE_MEM_free(ptReferences);
					//get the attribute details of the latest history form
					iRetCode = swap_attribute_value_of_history_form(ptChangeFolderSecObjs[i],tECRev,tRootTask);
				}				
			}
			else if( iRetCode == ITK_ok && lIsModifiable==true && ( (tc_strcmp( acExitSecondaryType, "TI_ManufacturedCost") == 0) ||
									 (tc_strcmp( acExitSecondaryType, "TI_PurchasedCost") == 0)) )
			{
				iRetCode = swap_attribute_value_of_history_form(ptChangeFolderSecObjs[i],tECRev,tRootTask);
			}
			lIsModifiable = false;
		}
		SAFE_MEM_free(ptChangeFolderSecObjs);
	}
	return iRetCode;
}

