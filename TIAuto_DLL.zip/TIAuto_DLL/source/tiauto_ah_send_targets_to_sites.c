/*********************************************************************************************************************************
File         : tiauto_ah_send_targets_to_sites.c

Description  :This action sends the targets to the other sites or in other words 
               replicates the data into the other sites.
Sample Mail  :
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
July 26         Created    Nivedita          Added the handler to send targets to the export targets to the other 
                                             sites after they are released in the workflow.
Jun 21,2011		1.1		   Dipak Naik		 Modified the code to ignore the ODS site when the target site value 
											 is All.
Feb 18,2013		1.2		   Dipak Naik		 Modified the code to send the email notification to the PLM Helpdesk
											 if there were any issue during replication and the handler execution
											 should be successful.
***************************************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

#define INIT_LIST_SIZE         200
#define ARG_TARGET_SITE_NAME     "target_sites"
#define ARG_CLASS_NAME            "Class"
#define ARG_CLASS_ITEMREV         "ItemRevision"
#define ARG_TARGETREV_ONLY        "target_rev_only"
#define ALL_TARGETS                "ALL"


void FreeMemoryForLinkdList(TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList);
int sendObjects(
    int n_send,
    tag_t *send_list,
    int n_sites,
    tag_t *site_list,
    tag_t site_tag,
    tag_t owning_site,
    logical exclude_files,
    char *export_reason,
    logical latest_ds_version_only,
    logical target_rev_only,
    int        n_reltypes,
    tag_t* reltype_list
    );
static int process_aliaslist_recipient( tag_t alist,                /* <I> */
                                   counted_list_t *mail_addresses   /* <OF> */
                                   );
static void release_string_array( int count,  char **list  );

extern int t1aAUTO_send_targets_to_sites(EPM_action_message_t msg)
{
	#define SEND_OPTION_MAX_LEN 10

    static tag_t item_rev_class = NULLTAG;

    int iRetCode				= ITK_ok;
    int numctr					= 0;
	int n_classes				= 0;
    int n_attachment			= 0;
    int n_send					= 0;
    int n_sites					= 0;
    int n_reltypes				= 0;
    int attachment_type			= EPM_reference_attachment;
	int	iSiteID					= 0;
	int iFileOpenErrCode		= 0;
    int num_of_args, i, j;

    char *flag									= NULL;     /* Free this variable w/ MEM_free */
    char *value									= NULL;     /* Free this variable w/ MEM_free */
	char *pcMailBodyFileName					= NULL;
    char **pcSiteList							= NULL;
	char acDataString[TIAUTO_error_message_len+1]="";
	char aFormName[WSO_name_size_c + 1]			= "";
	char acSiteName[SA_site_size_c + 1]			= "";
    char export_reason[WSO_desc_size_c+1];
    char target_rev_option[SEND_OPTION_MAX_LEN];
    char ds_version_option[SEND_OPTION_MAX_LEN];
    char exclude_files_option[SEND_OPTION_MAX_LEN];

    logical target_rev_only				= false;
    logical target_rev_only_is_defined	= false;
    logical latest_ds_version_only		= false;
    logical exclude_files				= false;
	logical lIsODS						= false;

    tag_t class_tag					= NULLTAG;
    tag_t site_tag					= NULLTAG;
    tag_t reltype_tag				= NULLTAG;
	tag_t tDistributionList			= NULLTAG;
	tag_t tTargetOwningSite			= NULLTAG;
    tag_t owning_site				= NULLTAG; /* site to transfer ownership to */
    tag_t root_task					= NULLTAG;
    tag_t *class_list				= NULL;    /* NULL means all classes */
    tag_t *att_list					= NULL;    /* target attachments to job */
    tag_t *send_list				= NULL;    /* objects to send */
    tag_t *site_list				= NULL;    /* target sites to send to */
    tag_t *reltype_list				= NULL;    /* relation types to exclude */

	FILE  *fMailBodyFile			= NULL;

	counted_list_t     mail_addresses;     
	counted_list_t     final_mail_list; 

	STATUS_Struct_t		sSeparatedSites;

	tiauto_initialize_status_progression_stuct(&sSeparatedSites);
	
#ifdef DEV_ENV
    /* The following is for testing only */
	
    if (msg.action != EPM_perform_action)
    {
        return ITK_ok;
    }
#endif

    tc_strcpy(export_reason, "");
    tc_strcpy(target_rev_option, "");
    tc_strcpy(ds_version_option, "");
    tc_strcpy(exclude_files_option, "");

    iRetCode = EPM_setup_parser( msg.task );
    if ( iRetCode != ITK_ok )
        return iRetCode;

    num_of_args = TC_number_of_arguments( msg.arguments );

    if ( num_of_args == 0 )
    {
          return BIER_no_target_site;
    }
    else
    {
        /* Assume the max when allocating memory */
        class_list = (tag_t*)MEM_alloc(sizeof(tag_t) * (num_of_args+1));
        site_list  = (tag_t*)MEM_alloc(sizeof(tag_t) * (num_of_args+1));
        reltype_list = (tag_t*)MEM_alloc(sizeof(tag_t) * (num_of_args+1));

        for ( numctr = 0; numctr < num_of_args && iRetCode == ITK_ok; numctr++ )
        {  /* FOR EACH ARGUMENT */
            iRetCode = ITK_ask_argument_named_value( TC_next_argument( msg.arguments ),
                                        &flag, &value);
            if ( iRetCode == ITK_ok )
            {   /* SUCCESSFUL GETTING FLAG */

                /* The flag should be of the form: class=<class_name> or
                   target_site=<site_name> and there could be one or more of
                   each. Or it could be owning_site=<site_name> but there can
                   be only one of this. Or it could be the export reason
                   given in the format reason=<export_reason>

                   <Vic 23-Mar-1999> The flag can also be of the form:
                    target_revision_only=yes or YES */

                if ( tc_strcmp("class", flag ) == 0 )
                {
                    iRetCode = POM_class_id_of_class(value, &class_tag);

                    class_list[n_classes] = class_tag;
                    n_classes++;
                }
                else
                {
                    if ( tc_strcmp("target_site", flag ) == 0 )
                    {
                        if ( tc_strcmp(value, "ALL") == 0 )
                        {
                            int    count = 0, local_site_id, idx,itemp1;
							int itemp = 0;
                            tag_t* tmp = 0, local_site_tag = NULLTAG;
                            /* get the tag for the local site */
                            iRetCode = POM_site_id ( &local_site_id );
                            if( iRetCode == ITK_ok )
                            {
                                iRetCode = POM_lookup_imc ( local_site_id, &local_site_tag );
                            }
                            if (iRetCode == ITK_ok)
                            {
								tTargetOwningSite = local_site_tag;
                                /* The extent will include the local site which we
                                   wanna remove from the list. Fortunately, the
                                   local site will always be the first entry in the
                                   list; this is probably cheating but we will do it
                                   anyway. */
                                /*
                                 * You can't depend on local site being the first anymore
                                 * so do it the old fashioned way
                                 */
                                iRetCode = SA_extent_site(&count, &tmp);
								
                                if( iRetCode == ITK_ok )
                                {
                                    MEM_free(site_list);
                                    site_list = (tag_t*)MEM_alloc(sizeof(tag_t) * (count - 1));
                                    for( idx = 0; idx < count; ++idx )
                                    {
										lIsODS = false;
										iRetCode = SITE_ask_ods_site(tmp[idx],&lIsODS);
										if(lIsODS == true)
										{
											printf("\n \n");
											printf("Site %d is ODS site:  %d\n",idx,tmp[idx]);
											continue;
										}
                                        if( tmp[idx] != local_site_tag )
                                        {
											printf("\n \n");
                                            site_list[itemp] = tmp[idx];
											printf("Site %d is :  %d\n",idx,site_list[itemp]);
											itemp++;
                                        }
																													
                                    }
                                    //n_sites = count - 1;
									/*lIsODS = false;
									iRetCode = SITE_ask_ods_site(tmp[idx],&lIsODS);
									if(lIsODS == true)
									{
										continue;
									}*/		
									n_sites = itemp;
									if(n_sites == 0)

									{
										printf("\nNo other Site Found except the current site and ODS site.\n");
										return iRetCode;
									}
									for(itemp1 = 0; itemp1 < n_sites;itemp1++)
									{
										printf("Site %d is :  %d\n",itemp1,site_list[itemp1]);
									}
                                }
                            }
                        }
                        else
                        {
							int     local_site_id, idx;
							int itemp = 0;
							tag_t local_site_tag = NULLTAG;
                            site_tag = NULLTAG;
                            if(iRetCode == ITK_ok)
								iRetCode = tiauto_get_values_from_comma_separated_string(value,&sSeparatedSites);
							pcSiteList = sSeparatedSites.StatusArray;
							/* get the tag for the local site */
                            iRetCode = POM_site_id ( &local_site_id );
                            if( iRetCode == ITK_ok )
                            {
                                iRetCode = POM_lookup_imc ( local_site_id, &local_site_tag );
                            }
							MEM_free(site_list);
						
                            site_list = (tag_t*)MEM_alloc(sizeof(tag_t) * (sSeparatedSites.iCount));
                            for( idx = 0; idx < sSeparatedSites.iCount; ++idx )
                            {
								iRetCode = SA_find_site(pcSiteList[idx], &site_tag);
                                if( site_tag != local_site_tag )
                                {
									printf("\n \n");
                                    site_list[itemp] = site_tag;
									printf("Site %d is :  %d\n",idx,site_list[itemp]);
									itemp++;
                                }								
                            }
							n_sites = sSeparatedSites.iCount - 1;
						    if (iRetCode == ITK_ok)
                            {
                                site_list[n_sites] = site_tag;
                                n_sites++;
                            }
                        }
                    }
                    else
                    {
                        if ( tc_strcmp("owning_site", flag ) == 0 )
                        {
                            /* There can be only one of these */
                            iRetCode = SA_find_site(value, &owning_site);
                            if (owning_site == NULLTAG)
                            {
                                iRetCode = SITE_NO_SUCH_SITE;
                            }
                            if (iRetCode == ITK_ok)
                            {
                                n_sites = 1;
                                site_list[0] = owning_site;
                            }

                        }
                        else
                        {
                            if ( tc_strcmp("reason", flag ) == 0 )
                            {
                                tc_strcpy(export_reason, value);
                            }
                            else
                            {
                                if ( tc_strcmp("target_revision_only", flag ) == 0 )
                                {
                                    tc_strcpy(target_rev_option, value);
                                }
                                else
                                {
                                    if ( tc_strcmp("exclude_relation", flag ) == 0 )
                                    {
                                        reltype_tag = NULLTAG;
                                        iRetCode = GRM_find_relation_type(value, &reltype_tag);
                                        if (reltype_tag == NULLTAG)
                                        {
                                            iRetCode = GRM_undefined_relation_type;
                                        }

                                        if (iRetCode == ITK_ok)
                                        {
                                            reltype_list[n_reltypes] = reltype_tag;
                                            n_reltypes++;
                                        }
                                    }
                                    else
                                    {
                                        if ( tc_strcmp("latest_ds_version", flag ) == 0 )
                                        {
                                            tc_strcpy(ds_version_option, value);
                                        }
                                        else
                                        {
                                            if ( tc_strcmp("exclude_files", flag ) == 0 )
                                            {
                                                tc_strcpy(exclude_files_option, value);
                                            }
                                            else
                                            {
                                                iRetCode = EPM_invalid_argument;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } /* END IF SUCCESSFUL GETTING FLAG */

            if ( flag != NULL )
            {
                MEM_free( flag );
                flag = NULL;
            }
            if ( value != NULL )
            {
                MEM_free( value );
                value = NULL;
            }
			 SAFE_MEM_free (sSeparatedSites.StatusArray);
        } /* END FOR EACH ARGUMENT */

    } /* END ELSE THERE ARE ARGUMENTS */

    if (iRetCode == ITK_ok)
    {
        if (n_classes == 0)
        {
            if (class_list) MEM_free(class_list);
            class_list = NULL;
        }

        if ( (n_sites == 0) && (owning_site == NULLTAG) )
        {
            return BIER_no_target_site;
        }

        /* Check if target_rev_only switch is defined. If so and one of the
           targets is a revision, then we will enable the bier option to
           process a specific revision only */
        if ( (tc_strlen(target_rev_option) > 0) &&
             ( (tc_strcmp(target_rev_option, "yes") == 0) ||
               (tc_strcmp(target_rev_option, "YES") == 0) ||
               (tc_strcmp(target_rev_option, "Yes") == 0) ) )
        {
            target_rev_only_is_defined = true;
        }
        else
        {
            target_rev_only_is_defined = false;
        }

        if ( (tc_strlen(ds_version_option) > 0) &&
             ( (tc_strcmp(ds_version_option, "yes") == 0) ||
               (tc_strcmp(ds_version_option, "YES") == 0) ||
               (tc_strcmp(ds_version_option, "Yes") == 0) ) )
        {
            latest_ds_version_only = true;
        }
        else
        {
            latest_ds_version_only = false;
        }

        if ( (tc_strlen(exclude_files_option) > 0) &&
             ( (tc_strcmp(exclude_files_option, "yes") == 0) ||
               (tc_strcmp(exclude_files_option, "YES") == 0) ||
               (tc_strcmp(exclude_files_option, "Yes") == 0) ) )
        {
            exclude_files = true;
        }
        else
        {
            exclude_files = false;
        }

        iRetCode = EPM_ask_attachments( msg.task, EPM_target_attachment,
                                         &n_attachment, &att_list );
        if ( ( iRetCode == ITK_ok ) && ( n_attachment == 0) )
        {
            iRetCode = EPM_ask_root_task(msg.task, &root_task);

            iRetCode = EPM_ask_attachments( root_task, EPM_target_attachment,
                                         &n_attachment, &att_list );
        }

        if ( (n_sites > 0) && (owning_site == NULLTAG) )
        {
            if ( root_task != NULLTAG)
            {
                EPM_remove_attachments(root_task, n_attachment, att_list);
                EPM_add_attachments(root_task, n_attachment, att_list, &attachment_type);
            }
            else
            {
                EPM_remove_attachments(msg.task, n_attachment, att_list);
                EPM_add_attachments(msg.task, n_attachment, att_list, &attachment_type);
            }
        }

#ifdef DEV_ENV
		 /* The following is for debugging only */
        printf("n_classes = %d\n", n_classes);
        printf("n_send = %d\n", n_send);
        printf("n_sites = %d\n", n_sites);
        printf("n_attachment = %d\n", n_attachment);
        printf("n_reltypes = %d\n", n_reltypes);
        printf("target_rev_only_is_defined = %d\n", (int)target_rev_only_is_defined);
        printf("latest_ds_version_only = %d\n", (int)latest_ds_version_only);
        printf("exclude_files = %d\n", (int)exclude_files);
       
#endif

        if ( ( iRetCode == ITK_ok ) && ( n_attachment > 0) )
        {
            send_list = (tag_t*)MEM_alloc(sizeof(tag_t) * n_attachment);
            for (i=0; i < n_attachment && iRetCode == ITK_ok; i++)
            {
                if (class_list == NULL)
                {
                    send_list[n_send] = att_list[i];
                    n_send++;
                    continue;
                }

                class_tag = NULLTAG;
                iRetCode = POM_class_of_instance(att_list[i], &class_tag);
                if (iRetCode != ITK_ok)
                    break;

                for ( j=0; j < n_classes; j++)
                {
                    if (class_tag == class_list[j])
                    {
                        /* If the target is an Item Rev, then we wanna send
                           the item unless the target_rev_only option has
                           been specified */
                        if (item_rev_class == NULLTAG)
                        {
                            /* Get the Item Rev class tag and cache it */
                            if ((iRetCode = POM_class_id_of_class(ITEM_rev_class_name_c,
                                         &item_rev_class)) != ITK_ok)
                            {
                                break;
                            }
                        }

                        if ( (class_tag == item_rev_class) && !target_rev_only_is_defined )
                        {
                            tag_t item;

                            if ((iRetCode = ITEM_ask_item_of_rev(att_list[i],
                                         &item)) != ITK_ok)
                            {
                                break;
                            }
                            send_list[n_send] = item;
                        }
                        else
                        {
                            send_list[n_send] = att_list[i];

                            /* If at least a single target rev is being sent
                               as target-revision-only then we need to enable
                               this bier option */
                            if ( (class_tag == item_rev_class) && target_rev_only_is_defined )
                            {
                                target_rev_only = true;
                            }
                        }
                        n_send++;
                    }
                }
            }
        }

        if (n_send == 0)
        {
            iRetCode = EPM_attachments_not_found;
        }

        if ( ( iRetCode == ITK_ok ) && ( n_send > 0) )
        {
            if ((n_sites > 0) && (site_tag != NULLTAG) && (owning_site != NULLTAG))
            {
                iRetCode = EPM_invalid_argument;
            }
            if (iRetCode == ITK_ok)
            {
                logical useSSTMode = false;
                if (owning_site != NULLTAG)
                {
                    iRetCode = OBJIO__is_sst_mode_supported(owning_site, &useSSTMode);
                }
                if (iRetCode == ITK_ok)
                {
					if (useSSTMode)
                    {
							printf("n_classes = %d\n", n_classes);
							printf("n_send = %d\n", n_send);
							printf("n_sites = %d\n", n_sites);
							printf("n_attachment = %d\n", n_attachment);
							printf("n_reltypes = %d\n", n_reltypes);
							printf("target_rev_only_is_defined = %d\n", (int)target_rev_only_is_defined);
							printf("latest_ds_version_only = %d\n", (int)latest_ds_version_only);
							printf("exclude_files = %d\n", (int)exclude_files);
							printf("The site tag beofre sending is %d\n",site_tag);
							printf("The owning site beofre sending tag is %d\n",owning_site);
                        /* transfer one object at a time if in SST mode         */
                        for (i = 0; i < n_send; i++)
                        {						
                            int ifail = sendObjects(1, send_list + i, n_sites, site_list, site_tag, owning_site, exclude_files, export_reason, latest_ds_version_only, target_rev_only, n_reltypes, reltype_list);
                            if (iRetCode != ITK_ok)
                            {
                                iRetCode = ifail;
                            }
                        }
                    }
                    else
                    {
							printf("n_classes = %d\n", n_classes);
							printf("n_send = %d\n", n_send);
							printf("n_sites = %d\n", n_sites);
							printf("n_attachment = %d\n", n_attachment);
							printf("n_reltypes = %d\n", n_reltypes);
							printf("target_rev_only_is_defined = %d\n", (int)target_rev_only_is_defined);
							printf("latest_ds_version_only = %d\n", (int)latest_ds_version_only);
							printf("exclude_files = %d\n", (int)exclude_files);
							printf("The site tag beofre sending is %d\n",site_tag);
							printf("The owning site tag beofre sending is %d\n",owning_site);
                       iRetCode = sendObjects(n_send, send_list, n_sites, site_list, site_tag, owning_site, exclude_files, export_reason, latest_ds_version_only, target_rev_only, n_reltypes, reltype_list);
                    }
                }
            }
        }
    }
    
    /* <Vic - 21-jan-2004> PR 4877474 - To make sure the EPM State Transition
       Engine does not see anything on the stack, let's make sure the stack
       is clear if the status returned is ITK_ok. */

    if (iRetCode == ITK_ok)
    {
        EMH_clear_errors();
    }
	else if(iRetCode != ITK_ok)
	{  
		iRetCode = ITK_ok;
		//if the iRetCode is not ITK_ok, then complete the workflow and send the mail to the owner and 
		//the PLM help desk to manually export the target form to the other sites
		
		final_mail_list.count = 0;
		mail_addresses.count = 0;
		final_mail_list.list = NULL;
		mail_addresses.list = (char **)MEM_alloc( 15 * sizeof(char*) );
		
		//get the target object name
		if(send_list != NULL && send_list[0] != NULLTAG)
			iRetCode = WSOM_ask_name(send_list[0],aFormName);
		if(tTargetOwningSite != NULLTAG)
			iRetCode = SA_ask_site_info(tTargetOwningSite,acSiteName,&iSiteID);

		TI_sprintf(acDataString,"Please replicate the Supplier Request form \"%s\" present in \"%s\" to other sites",aFormName,acSiteName);

		pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);

		iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
		if(fMailBodyFile != NULL)
		{
			fprintf(fMailBodyFile,"Supplier Request form : %s\n",aFormName);
			fprintf(fMailBodyFile,"Process Name          : 12_00 New Supplier Request\n");
			fprintf(fMailBodyFile,"Database              : %s\n",acSiteName);
			fprintf(fMailBodyFile,"\nThere were some issues while replicating the Supplier Request form automatically to the other sites. Please replicate the form to other sites.");
		
			fclose(fMailBodyFile);
		}
				
		iRetCode = MAIL_find_alias_list ("Supplier_Recipient",&tDistributionList);

		if(tDistributionList != NULLTAG)
			iRetCode = process_aliaslist_recipient(tDistributionList,&mail_addresses);
		
		if(mail_addresses.count > 0)
		{
			EPM_remove_duplicate_strings( mail_addresses.count , mail_addresses.list,
                                  &(final_mail_list.count),&(final_mail_list.list));
		}

		for(i =0; i <final_mail_list.count;i++)
		{
			iRetCode = tiauto_sendEMailFromPLMAdmin(acDataString, final_mail_list.list[i], pcMailBodyFileName);
		}
		
		release_string_array(mail_addresses.count,mail_addresses.list);
		release_string_array(final_mail_list.count,final_mail_list.list);
		// delete temporary file here
		remove(pcMailBodyFileName );

		iRetCode = ITK_ok;
	}
	
	MEM_free(class_list);
    MEM_free(att_list);
    MEM_free(send_list);
    MEM_free(site_list);
    MEM_free(reltype_list);

    return( iRetCode );

}
/*---------------------------------------------------------------------------*/
int sendObjects(
    int n_send,
    tag_t *send_list,
    int n_sites,
    tag_t *site_list,
    tag_t site_tag,
    tag_t owning_site,
    logical exclude_files,
    char *export_reason,
    logical latest_ds_version_only,
    logical target_rev_only,
    int        n_reltypes,
    tag_t* reltype_list
    )
{
    int rcode = ITK_ok;
    int k;
    char    *staging_dir = 0;
    tag_t   bier = NULLTAG, trans_bier = NULLTAG;
    logical isSSTMode = false;
    printf("********Inside sendobjects********** \n");
	printf("Printing site list \n");

	for(k = 0;k < n_sites;k++)
	{
		printf("The site tag %d is %d \n",k,site_list[k]);
	}
	printf("**Owning site tag in send objects %d\n",owning_site);
    rcode = OBJIO__make_temp_staging_dir(&staging_dir);
	printf("The retocde after making the staging directory is %d \n",rcode);

    if (rcode == ITK_ok)
    {
        if ((rcode = OBJIO_create(OBJIO_export_type, staging_dir, &bier)) != ITK_ok)
        {
			printf("The retocde after OBJIO create is %d \n",rcode);
            OBJIO_delete_staging_dir(staging_dir);
            MEM_free(staging_dir);
        }
    }

    if (rcode == ITK_ok)
    {
        if ((n_sites > 0) && (site_tag != NULLTAG) && (owning_site != NULLTAG))
            return rcode = EPM_invalid_argument;

	
        //if ((n_sites > 0) && (site_tag != NULLTAG))
		if (n_sites > 0)
        {
            rcode = OBJIO_set_target_sites(bier, n_sites, site_list);
			printf("The retocde after set target sites is %d \n",rcode);
        }
        else
        {
            rcode = OBJIO_set_owning_site(bier, owning_site);
			printf("The retocde after set owning site is %d \n",rcode);
            if (rcode == ITK_ok)
            {
                rcode = OBJIO_set_site_based_attribute(bier, owning_site, OBJIO_synchronous_site_transfer, 1);
				printf("The retocde is after set site based attribute %d \n",rcode);
                if (rcode == ITK_ok)
                {
                    isSSTMode = true;
                }
                else if( rcode == IDSM_ie_option_not_supported )
                {
					printf("The retocde is idsn supported %d \n",rcode);
                    rcode = ITK_ok;
                    EMH_clear_errors();
                }
            }
            if( rcode == ITK_ok && !isSSTMode )
            {
                /* Revert to using legacy synchonous mode */
                rcode = OBJIO_set_attribute(bier, OBJIO_synchronous_remote_transfer, 1);
				printf("The retocde fr syncronous mode transfer is %d \n",rcode);
            }
        }

        if (rcode != ITK_ok)
        {
            OBJIO_delete_staging_dir(staging_dir);
			printf("The retocde after delete staging dir is %d \n",rcode);
            MEM_free(staging_dir);
            OBJIO_delete(bier);
        }
    }

    if (rcode == ITK_ok)
    {
        if (tc_strlen(export_reason) > 0)
        {
            if ((rcode = OBJIO_set_export_reason(bier, export_reason)) != ITK_ok)
            {
				printf("The retocde export reason is %d \n",rcode);
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                OBJIO_delete(bier);
            }
        }
    }

    if ( (rcode == ITK_ok) && (owning_site == NULLTAG) )
    {
        if (target_rev_only)
        {
            if ((rcode = OBJIO_set_attribute(bier, OBJIO_selected_revs_only, 1)) != ITK_ok)
            {
				printf("The retocde after set attribute is %d \n",rcode);
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                OBJIO_delete(bier);
            }
        }
        else
        {
            rcode = OBJIO_set_attribute(bier, OBJIO_item_all_revisions, 1);
			printf("The retocde is after set attribute111 %d \n",rcode);
        }
    }

    if ( (rcode == ITK_ok) && (owning_site == NULLTAG) )
    {
        if (latest_ds_version_only)
        {
            if ((rcode = OBJIO_set_attribute(bier, OBJIO_dataset_all_versions, 0)) != ITK_ok)
            {
				printf("The retocde for ds all versions is %d \n",rcode);
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                OBJIO_delete(bier);
            }
        }
    }

    if ( (rcode == ITK_ok) && (owning_site == NULLTAG) )
    {
        if (exclude_files)
        {
            if ((rcode = OBJIO_set_attribute(bier, OBJIO_export_dataset_refs, 0)) != ITK_ok)
            {
				printf("The retocde for ds refs is %d \n",rcode);
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                OBJIO_delete(bier);
            }
        }
    }

    if ( (rcode == ITK_ok) && (owning_site == NULLTAG) )
    {
        /* Always exclude protected objects if not transferring */
        if ((rcode = OBJIO_set_attribute(bier, OBJIO_exclude_protected_wso, 1)) != ITK_ok)
        {
			printf("The retocde after set attribute for protected wso is %d \n",rcode);
            OBJIO_delete_staging_dir(staging_dir);
            MEM_free(staging_dir);
            OBJIO_delete(bier);
        }
    }

    if ( (rcode == ITK_ok) && (owning_site == NULLTAG) )
    {
        if (n_reltypes > 0)
        {
            if ((rcode = OBJIO_exclude_relation_types(bier, n_reltypes, reltype_list)) != ITK_ok)
            {
				printf("The retocde after excluding relation types is %d \n",rcode);
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                OBJIO_delete(bier);
            }
        }
    }

    if (rcode == ITK_ok)
    {
        /* Always set/unset other attributes so they don't take unknown
           default values */

        OBJIO_set_attribute(bier, OBJIO_preview_mode, 0);
        OBJIO_set_attribute(bier, OBJIO_completion_report, 0);
        OBJIO_set_attribute(bier, OBJIO_include_modified_only, 0);
        OBJIO_set_attribute(bier, OBJIO_is_retrieving_distributed_comp, 0);
    }

    if (rcode == ITK_ok)
    {
        if ((rcode = OBJIO_store_objects(bier, n_send, send_list)) != ITK_ok)
        {
            OBJIO_delete(bier);
			printf("The retocde after storing objects is %d \n",rcode);
            OBJIO_delete_staging_dir(staging_dir);
            MEM_free(staging_dir);
            staging_dir = 0;
        }
    }

    if (rcode == ITK_ok)
    {
        if ((rcode = OBJIO_write(bier)) != ITK_ok)
        {
            if( isSSTMode )
            {
                /* Note staging directory deleted by abort function */
                OBJIO_abort_sst_export_post_write(send_list[0]);
				printf("The retocde after export in sst mode is is %d \n",rcode);
            }
            else
            {
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                staging_dir = 0;
            }
        }

        OBJIO_delete(bier);
    }

    if (rcode == ITK_ok)
    {
        if ((rcode = OBJIO_create(OBJIO_remote_transfer_to_type, staging_dir, &trans_bier)) != ITK_ok)
        {
            if( isSSTMode )
            {
                /* Note staging directory deleted by abort function */
                OBJIO_abort_sst_export_post_write(send_list[0]);
				printf("The abort sst export  retocde is %d \n",rcode);
                MEM_free(staging_dir);
            }
            else
            {
                OBJIO_delete_staging_dir(staging_dir);
                MEM_free(staging_dir);
                staging_dir = 0;
            }

        }
    }

    if (rcode == ITK_ok)
    {
        int i = 0;
        for ( i = 0; i < n_sites; i++)
        {
            if( isSSTMode )
            {
                // set SST mode on transfer bier, we've already know the remote site supports it
                rcode = OBJIO_set_site_based_attribute(trans_bier, site_list[i], OBJIO_synchronous_site_transfer, 1);
				printf("The sst mode transfer failed retocde is %d \n",rcode);
            }
            if (rcode != ITK_ok)
            {
                if( isSSTMode )
                {
                    OBJIO_abort_sst_export_post_write(send_list[0]);
                    MEM_free(staging_dir);
                    staging_dir = 0;
                }
                    break;
            }
            if ((rcode = OBJIO_send(trans_bier, site_list[i])) != ITK_ok)
            {
				printf("The send failed retocde is %d \n",rcode);
                break;
            }
        }

        OBJIO_delete(trans_bier);
        if(staging_dir)
        {
            OBJIO_delete_staging_dir(staging_dir);
            MEM_free(staging_dir);
        }
    }
    return rcode;
}



/*
 * Description:
 *         This function takes an alias list name, the alias list may contain
 *         AliasList names, TC user names, OS user names and Email IDs.
 *         This function will create a list of Email IDs/OS names given an alias
 *         list.
 *
 * Parameters:
 *         alist <O>
 */
static int process_aliaslist_recipient( tag_t alist,                 /* <I> */
                                        counted_list_t * mail_addresses   /* <OF> */
                                      )
{
    int rcode = ITK_ok;
    int add_count = 0;
    char **tmp_add = NULL;

    rcode = MAIL_ask_alias_list_members( alist , &add_count , &tmp_add );

    if( rcode == ITK_ok )
    {
        int inx          = 0;

        for( inx = 0; inx < add_count ; inx++ )
        {

            // Check to see if this is an embedded alias list. If it is, then
            // recursively process it. If it isn't then add the name to the
            // recipient list.

            tag_t alist = NULLTAG;
            rcode = MAIL_find_alias_list( (const char *)tmp_add[inx], &alist );
            if (rcode== ITK_ok  &&  alist!=NULLTAG )
            {
                rcode = process_aliaslist_recipient(alist, mail_addresses);
            }
            else
            {
                // ahujak : The tmp_add could be a TC user, if its TCUser then
                // get the email id for TC user,
                // else assume it to be an OS user.
                // PR 6040910: dasatish It could be a TC Group as well
                tag_t the_user = NULLTAG;
                tag_t the_group = NULLTAG;
                char  *the_email = 0;
                logical group_found = false;
                int user_status = 1;

                // lets see if tmp_add is a TC user or a group ...
                if( ((rcode = SA_find_user(tmp_add[inx],&the_user)) == ITK_ok)
                      && (the_user != NULLTAG)
                  )
                {
                    // get the email address for TC user
                    rcode = EPM_get_user_email_addr( the_user, &the_email );

                    //PR#1797751 Email notification sent to inactive users
                    if ((SA_get_user_status(the_user,&user_status) == ITK_ok) && user_status == 0)
                    {
                        if( (rcode == ITK_ok) && (the_email != 0) )
                        {
                            rcode = EPM_add_to_list( mail_addresses, the_email );
                        }
                    }
                }
                else if( ((rcode = SA_find_group(tmp_add[inx], &the_group)) == ITK_ok) && (the_group != NULLTAG) )
                {
                    //support Group in the list
                    int groupmember_count = 0;
                    int inx_num = 0;
                    tag_t *groupmember_tags = NULL;     /* MEM_free this */
                    char * groupName = tmp_add[inx];

                    rcode = SA_find_groupmember_by_rolename(NULL, groupName, NULL,  &groupmember_count, &groupmember_tags);
                    if( rcode == ITK_ok && groupmember_count > 0 )
                    {
                        int   user_count = 0;
                        tag_t *user_tags = NULL ;
                        rcode = EPM_get_users_for_group_members( groupmember_count, groupmember_tags, &user_count, &user_tags );
                        if( rcode == ITK_ok )
                        {
                            for( inx_num = 0; inx_num < user_count ; inx_num++ )
                            {
                                char  *the_useremail = 0;
                                rcode = EPM_get_user_email_addr( user_tags[inx_num], &the_useremail );
                                user_status = 1;
                                if ((SA_get_user_status(user_tags[inx_num],&user_status) == ITK_ok) && user_status == 0)
                                {
                                    if( (rcode == ITK_ok) && (the_useremail != 0) )
                                    {
                                        rcode = EPM_add_to_list( mail_addresses, the_useremail );
                                    }
                                }
                            }
                        }
                        SAFE_SM_FREE( user_tags );
                    }
                    SAFE_SM_FREE( groupmember_tags );
                }

                // if not assume it to be an OS user/external Email ID..
                // also check if a group was found
                if( (the_user == NULLTAG) || (the_email == 0) && !group_found )
                {
                    rcode = EPM_add_to_list( mail_addresses, tmp_add[inx] );
                }

                MEM_free(the_email);
            }
            MEM_free( tmp_add[inx] );
        }
        SAFE_SM_FREE( tmp_add );
    }

    return rcode;

}

void release_string_array( int count,  char **list  )
{
    int inx;

    if( list == 0 )
    {
         return;
    }

    for(inx = 0; inx < count ; inx++ )
    {
         SAFE_SM_FREE( list[inx] );
    }

    SAFE_SM_FREE(list);

    list = 0;
}