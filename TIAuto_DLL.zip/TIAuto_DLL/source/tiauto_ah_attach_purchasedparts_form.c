/*******************************************************************************
File         : tiauto_ah_attach_purchasedparts_form.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
-----------------------------------------------------------------------------
July 05, 2013    1.0         Mahesh	BS		Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TIAUTO_AH_attach_purchasedparts_form (EPM_action_message_t msg)
{
	int			iCount =0;
	int			iNumArgs = 0;
	int			iRetCode = ITK_ok;

	tag_t		tECRev = NULL_TAG;
	tag_t		*atBasedOn = NULL;
	tag_t		tForm = NULL_TAG;
	tag_t		tPurPartForm = NULL_TAG;
	tag_t		tNewRelation = NULL_TAG;
	tag_t		tRelationType = NULL_TAG;

	char		*pcErrMsg = NULL;
	const char	*pcBasedOn = "IMAN_based_on";
	char		*pcFormType = "TI_PurchasedParts";


	iNumArgs = TC_number_of_arguments(msg.arguments);
	if(iNumArgs == 0)
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
		if(iRetCode == ITK_ok && tECRev)
		{
			//checking required form is not attached to target change revision
			iRetCode = tiauto_getFormAttachedToObject(tECRev, pcFormType, &tForm );
			if(iRetCode == ITK_ok && tForm == NULL_TAG)
			{
				//need to attach form so get based on change revision
				iRetCode = AOM_ask_value_tags(tECRev, pcBasedOn, &iCount, &atBasedOn);
				if(iRetCode == ITK_ok && iCount > 0)
				{
					//get the form attached to the change revision
					iRetCode = tiauto_getFormAttachedToObject(atBasedOn[0], pcFormType, &tPurPartForm );
					if(iRetCode == ITK_ok && tPurPartForm != NULL_TAG)
					{
						//attach form to change IR
						iRetCode = GRM_find_relation_type( TC_specification_rtype, &tRelationType );
						if(iRetCode == ITK_ok && tRelationType)
							iRetCode = GRM_create_relation(tECRev,tPurPartForm,tRelationType, NULL_TAG,&tNewRelation);
						if(iRetCode == ITK_ok && tNewRelation)
						{						
							iRetCode = AOM_refresh(tNewRelation,false);
							if(iRetCode == ITK_ok)
								iRetCode = GRM_save_relation(tNewRelation);
						}

					}
					SAFE_MEM_free(atBasedOn);
				}
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}

	/* if ITK error during the handler exceution */
    if( iRetCode != ITK_ok )
	{
		EMH_ask_error_text(iRetCode, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);		
	}

	return iRetCode;  
}