/*******************************************************************************
File         : tiauto_rh_check_remote_objects.c

Description  : This rule handler validates the target object whether it is a remote
				object or not. If remote, then this rule handler will provide 
				appropriate error message to the user.
  
Input        : None
                        
Output       : None

Author       : Dipak Naik,TCS

Revision History :
Date            Revision    Who					Description
*******************************************************************************
Feb 01, 2012    1.0         Dipak Naik			Initial Creation
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <stdio.h>
#include <res/res_itk.h>
#include <tiauto_defines.h>


//---------------------------------------------------------------------------------------------------
//Main method for the rule handler "TIAUTO-RH-check-remote-objects"
//---------------------------------------------------------------------------------------------------
EPM_decision_t TIAUTO_RH_check_remote_objects(EPM_rule_message_t message)
{
    int		iFail				= ITK_ok;
	int		indx				= 0;
	int		iNumAttachments		= 0;

	tag_t	tOwningSite			= NULLTAG;
	tag_t	tRootTask				= NULLTAG;
	tag_t	*ptAttachments = NULL;

	char	acErrorString[512]		= "";
	char    pszObject[WSO_name_size_c+1]="";
	char	*pcErrMsg				= NULL;
	char	*pcObjectName			= NULL;
	char	*pcClassName			= NULL;

	logical	lValidationFailed		= false;
	TIA_ErrorMessage *pstCurrErrMsg = NULL;
	TIA_ErrorMessage *tempErrMsg	= NULL;

	EPM_decision_t decision = EPM_go;	
	
		
	//get the targeted object
	if (iFail == ITK_ok )
	{
		iFail = EPM_ask_root_task(message.task , &tRootTask);
	}
	if (iFail == ITK_ok && tRootTask != NULLTAG)
	{
		iFail = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments,&ptAttachments);
	}
	for (indx = 0; indx < iNumAttachments && (iFail == ITK_ok); indx++)
    {
		if(ptAttachments[indx] != NULLTAG)
			iFail = tiauto_get_class_name_of_instance(ptAttachments[indx],&pcClassName);
			//getting parent class if the class name is NOT ITEM or ITEMREVISION
		if ((tc_strcmp (pcClassName,TIAUTO_ITEM) != 0) || (tc_strcmp (pcClassName,TIAUTO_ITEMREVISION) != 0))
		{
			tag_t	tTargetType					= NULLTAG;

			if(iFail == ITK_ok)
			{
				TIAUTO_ITKCALL(iFail,TCTYPE_ask_object_type(ptAttachments[indx],&tTargetType));
			}
			if(tTargetType != NULLTAG)
			{
				tag_t	tParentType					= NULLTAG;

				TIAUTO_ITKCALL(iFail,TCTYPE_ask_parent_type(tTargetType,&tParentType));
				if(tParentType != NULLTAG)
				{
					SAFE_MEM_free(pcClassName);
					TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tParentType, &pcClassName));
				}
			}
						
		}
		//check if the classname of the targeted objects is Item or ItemRevision or Document Revision or Document
		if ( (iFail == ITK_ok ) && ((tc_strcasecmp (pcClassName , TIAUTO_ITEM)== 0)||
			                        (tc_strcasecmp (pcClassName , TIAUTO_ITEMREVISION)== 0) || 
									(tc_strcasecmp (pcClassName , TIAUTO_TI_DOCUMENT)== 0) || 
									(tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
		{
			iFail = WSOM_ask_object_type(ptAttachments[indx], pszObject);
			if (iFail == ITK_ok )
			{
				tOwningSite = NULLTAG;
				iFail = AOM_ask_value_tag( ptAttachments[indx], "owning_site", &tOwningSite);	
				if(iFail == ITK_ok && tOwningSite != NULLTAG)
				{
					lValidationFailed = true;
					iFail = WSOM_ask_object_id_string (ptAttachments[indx],&pcObjectName);
					TI_sprintf(acErrorString, "The targeted object \"%s\" is remote object. So this workflow cannot be initiated.",pcObjectName); 
					tiauto_writeErrorMsgToStack(&pstCurrErrMsg, TIAUTO_REMOTE_ERROR, acErrorString);
					SAFE_MEM_free(pcObjectName);
				}
			}
		}
		SAFE_MEM_free(pcClassName);
    }		
	
	if( iFail != ITK_ok )
	{
		decision = EPM_nogo;
		EMH_ask_error_text(iFail, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iFail,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}

	/* if the validation failed */
	if( iFail == ITK_ok && (lValidationFailed == true) )
	{
		decision = EPM_nogo;
		iFail = TIAUTO_REMOTE_ERROR;
		TI_sprintf( acErrorString, "\nPlease initiate this workflow on the current owning site object. "  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_CHECKEDOUT_ERROR, acErrorString );	
		tempErrMsg = pstCurrErrMsg;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog("\n");   
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
		tiauto_clearErrorMsgStack(pstCurrErrMsg);
	}
		
	return decision;
}
