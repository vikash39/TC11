/*******************************************************************************
FILE        :   tiauto_rh_verify_status_progression_stacked_change.c

DESCRIPTION :   This file contains the implementation for
                "TIAUTO-RH-verify-status-progression-StackedCR" Custom Rule Handler.

                This handler validates release status of the of the all item revisions
                for correct status progression. Each progression failure item revision is 
				validated to check if the item revision is associated to any parallel on-going 
				process with same/higher target release status. There are four different types of
                status progression checks are added in this handler. If any one check
                is failed, task will be continue to next task for demaotion. If parallel process 
				are present an EPM_nogo will be set, till all the parts in parallel process get a 
				valid status.

                Status Progression Checks:
                � Backwards Progression -  Validates the status progression of current
                  revision of item w.r.t later revisions of the same item. 
				    1)  EPM_go: Current item revision is to be released to a status when 
					    a newer/later version has been released to this status or higher,
						EPM_go will be set ( so that the Action handler (in Task 2_483) will fail and the
						process will be rejected/demoted).
					3)  EPM_go: The Action handler (in Task 2_483) will pass.

                � Assembly Item Rev Progression - A check should be performed on all
                  item revisions contained in the affected and solution folder to ensure
                  that all first level components in it�s precise BOM meet one of the
                  following requirements:
                    1)	EPM_go: The component is included in the affected folder.
                    2)	EPM_go: The component is included in the solution folder.
                    3)	EPM_go: The component is at the target status.
                    4)	EPM_go: The component is at a status higher than the target status.
					5)  EPM_nogo: The component is in an on-going parallel process which has 
					    same/higher target released status ( so that the task is held till the 
						parallel process is complete and the child component is statused).
					6)  EPM_go: The component is in an on-going parallel process which has 
					    lower target released status ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).
					7)  EPM_go: The component doesn't satisfy any of the above mentioned "Assembly 
					    Item Rev Progression" Checks ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).

                � Component Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  meet one of the following requirements:
                    1)	EPM_go: The item revision is not yet released.
                    2)	EPM_go: The item revision is at a lower status than the target status.
                    3)	EPM_go: The item revision is already at the target status.
					4)  EPM_nogo: The item revision is in an on-going parallel process which has 
					    same/higher target released status ( so that the task is held till the 
						parallel process is complete and the item revision is statused).
					5)  EPM_go: The item revision is in an on-going parallel process which has 
					    lower target released status ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).
					6)  EPM_go: The item revision doesn't satisfy any of the above mentioned "Component 
					    Item Rev Progression" Checks ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).
					

                � Generic Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  that have ProAsm or ProPrt dataset and are instance items, the generic item rev
				  should meet one of the following requirements:
                    1)	EPM_go: The generic is included in the affected folder.
                    2)	EPM_go: The generic is included in the solution folder.
                    3)	EPM_go: The generic is at the target status.
					4)  EPM_go: The generic is at a status higher than the target release status.
					5)  EPM_nogo: The generic is in an on-going parallel process which has 
					    same/higher target released status ( so that the task is held till the 
						parallel process is complete and the generic part is statused).
					6)  EPM_go: The generic is in an on-going parallel process which has 
					    lower target released status ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).
					7)  EPM_go: The generic doesn't satisfy any of the above mentioned "Generic Item 
					    Rev Progression" Checks ( so that the Action handler (in Task 2_483) will fail and 
						the process will be rejected/demoted).




REVISION HISTORY :

Date              Revision        Who                    Description
March 20, 2009    1.0           Garima Dewangan      Initial Creation
june 18, 2009     1.1           Dipak Naik			 Moved all the progression ckeck functions to 
													 "tiauto_workflow_utils.c" file.
*******************************************************************************/

/* includes */

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <tiauto_workflow_utils.h>


// static function prototypes
static int executeProgressionCheckRuleHandler( tag_t _tECRev,char *pcEndOfWarningMsg, EPM_decision_t *decision );


EPM_decision_t TIAUTO_RH_verify_status_progression_stacked_change( EPM_rule_message_t msg )
{
	int iRetCode = ITK_ok;
	int iNumArgs = 0;
	int iSkipCheck = 0;
	int i = 0;
	tag_t tECRev = NULLTAG;
	char *szArgName = NULL;
	char *szArgValue = NULL;
	char *szErrMsg = NULL;
	char *pcEndOfWarningMsg	= NULL;
	EPM_decision_t decision = EPM_nogo;

	TI_DEBUG_PRINT1("%s\n", "Enter -> TIAUTO_RH_verify_status_progression_StackedCR");

	iNumArgs = TC_number_of_arguments(msg.arguments);

	TI_DEBUG_PRINT1("No of Arguments : %d\n", iNumArgs);

    if (iNumArgs == 2)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &szArgName, &szArgValue );
			if ( iRetCode == ITK_ok )
			{
		
				if( ( iRetCode == ITK_ok ) && (szArgName != NULL) && (szArgValue != NULL) )
				{				
					if(tc_strcasecmp(szArgName, ARG_NAME_PROGRESSION_CHECK_RULE_HANDLER) == 0)
					{
						if( tc_strcasecmp(szArgValue, "Yes") == 0 )
						{
							iSkipCheck = 1;
						}
						else if( tc_strcasecmp(szArgValue, "No") == 0 )
						{
							iSkipCheck = 0;
						}
						else
						{
							iRetCode = EPM_invalid_argument;
						}
					}
					else if (tc_strcasecmp(szArgName, ARG_NAME_PROGRESSION_CHECK_ACTION_HANDLER4) == 0 && szArgValue != NULL)
					{
						pcEndOfWarningMsg = (char*) MEM_alloc(( (int)tc_strlen(szArgValue) + 1) * sizeof(char));
						tc_strcpy( pcEndOfWarningMsg, szArgValue);
					}
					else
					{
						iRetCode = EPM_invalid_argument;
					}
				}			
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	if(iRetCode == ITK_ok && pcEndOfWarningMsg == NULL)
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	if ( iRetCode == ITK_ok )
	{
		//If iSkipCheck is 1, then exit from this handler with EPM_go
		if ( iSkipCheck == 1 )
		{
			decision = EPM_go;
		}
		else if(iSkipCheck == 0)
		{			
			iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
			if ( (iRetCode == ITK_ok) && (tECRev != NULLTAG) )
			{
				//Call the static function to execute the handler to do the Progression Check
				 iRetCode = executeProgressionCheckRuleHandler(tECRev,pcEndOfWarningMsg, &decision);
			}
		}
	}	

	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &szErrMsg);
		TC_write_syslog(szErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg) ;
		SAFE_MEM_free (szErrMsg);		
	}

	SAFE_MEM_free (szArgName);
	SAFE_MEM_free (szArgValue);

	TI_DEBUG_PRINT1("%s\n", "Exit -> TIAUTO_RH_verify_status_progression_StackedCR");

	return decision;
}


 int executeProgressionCheckRuleHandler( tag_t _tECRev,char *pcEndOfWarningMsg, EPM_decision_t *decision )
{
    int iRetCode = ITK_ok;
    int indx = 0;
	int iNumAffected = 0;
	int iError = 0;
	int	iPopulateErrMsgInStack = 0;			// for this handler, we wont need the error message. 
	int	iPopulateWarningMsgInStack = 1;		// for this handler, we need only the warning message.
											// 0 -> not required
											// 1 -> required
	tag_t *ptAffectedItems = NULL;

    char            szErrorString[TIAUTO_error_message_len+1] = "";
	char		   *pszClassName = NULL;
    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;	

	TIA_ErrorMessage *backwordProgErrMsgStack = NULL;
	TIA_ErrorMessage *itemRevProgErrMsgStack = NULL;
	TIA_ErrorMessage *assemblyProgWarningMsgStack = NULL;
	TIA_ErrorMessage *assemblyProgErrMsgStack = NULL;
	TIA_ErrorMessage *genericProgWarningMsgStack = NULL;
	TIA_ErrorMessage *genericProgErrMsgStack = NULL;

	*decision = EPM_nogo;	

	TI_DEBUG_PRINT1("%s\n", "Enter -> executeHandler in TIAUTO_RH_verify_status_progression_StackedCR");

	//EMH_store_error_s1(EMH_severity_error, 919702, "XYZ");

	tiauto_initialize_status_progression_stuct(&StatusProgression);
    iRetCode = tiauto_get_status_progression_array (&StatusProgression);

    if (iRetCode == ITK_ok)
    { 		
		iRetCode = tiauto_get_target_release_status( _tECRev, TargetReleaseStatus.szTargetReleaseStatus);
		if(iRetCode == ITK_ok)
		{
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			if (TargetReleaseStatus.iLevel == -1)
			{
				TI_sprintf(szErrorString, "%s",TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT);
				iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
				EMH_store_error_s1( EMH_severity_error, iRetCode, 
					                szErrorString) ;
				TC_write_syslog(szErrorString);
			}
		}
		else
		{
			TI_sprintf(szErrorString, "Failed to verify Target Release Status with the site Preference \"TI_Progression_Path\".");
			EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;						
			TC_write_syslog(szErrorString);
		}
	}

	if (iRetCode == ITK_ok)
    {
		iRetCode = ECM_get_affected_items(_tECRev, &iNumAffected, &ptAffectedItems);
	}
	
	for (indx = 0; (indx < iNumAffected) && (iRetCode == ITK_ok); indx++)
	{	
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		if( (iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "ItemRevision")== 0 ) )
        {
			//Backward progression check 	 
			iRetCode = check_for_backward_progression ( ptAffectedItems[indx],ptAffectedItems, iNumAffected, StatusProgression, 
											TargetReleaseStatus, iPopulateErrMsgInStack, &iError, &backwordProgErrMsgStack );

			if ( (iRetCode == ITK_ok) && (iError != 0) )
			{
				// if backward progression check fails, then the workflow should immediately go to 2_483, thats 
				// the reason for seeting EPM_go
				*decision = EPM_go;
			}

			// this check will be performed only if there is no error in backward progression check
			if ( (iRetCode == ITK_ok) && (*decision == EPM_nogo) )
			{
				iRetCode = check_for_item_rev_progression ( ptAffectedItems[indx], StatusProgression, 
											TargetReleaseStatus, iPopulateErrMsgInStack, &iError, &itemRevProgErrMsgStack );
			
				if ( (iRetCode == ITK_ok) && (iError != 0) )
				{
					*decision = EPM_go;
				}
			}
			// this check will be performed only if there is no error in item revision progression check
			if ( (iRetCode == ITK_ok) && (*decision == EPM_nogo) )
			{
				iRetCode = check_for_assembly_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
														iPopulateWarningMsgInStack, iPopulateErrMsgInStack, &iError, 
														&assemblyProgWarningMsgStack, &assemblyProgErrMsgStack);
			
				if ( (iRetCode == ITK_ok) && (iError != 0) )
				{
					*decision = EPM_go;
				}
			}

			if ( (iRetCode == ITK_ok) && (*decision == EPM_nogo) )
			{
				iRetCode = check_for_generic_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
														StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
														iPopulateWarningMsgInStack, iPopulateErrMsgInStack, &iError, 
														&genericProgWarningMsgStack, &genericProgErrMsgStack);
			
				if ( (iRetCode == ITK_ok) && (iError != 0) )
				{
					*decision = EPM_go;
				}
			}

			//If *decision = EPM_go, break it as we don't want to wait here in case of any error,
			//The errors will be reported in the progression action handler in next step
			if ( *decision == EPM_go )
			{
				break;
			}
		}
	}

	if ((iRetCode == ITK_ok) && (*decision == EPM_nogo ) )
	{
		//If no warning messages are there, we assume NO ERROR and NO WARNING, so go ahead
		if ( (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) )
		{
            *decision = EPM_go;
		}
		//if any of these warning messages are there, print them and wait
		else
		{
			if(assemblyProgWarningMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;		
				while( assemblyProgWarningMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, assemblyProgWarningMsgStack->iRetCode, 
						                assemblyProgWarningMsgStack->errMsg );
					TC_write_syslog(assemblyProgWarningMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = assemblyProgWarningMsgStack;
         			assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				assemblyProgWarningMsgStack = NULL;
			}
			if(genericProgWarningMsgStack != NULL)
			{
				TIA_ErrorMessage *tempErrMsg = NULL;		
				while( genericProgWarningMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, genericProgWarningMsgStack->iRetCode, 
						                genericProgWarningMsgStack->errMsg );
					TC_write_syslog(genericProgWarningMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = genericProgWarningMsgStack;
         			genericProgWarningMsgStack = genericProgWarningMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				genericProgWarningMsgStack = NULL;
			}
		}
	}	

	TI_DEBUG_PRINT1("%s\n", "Exit -> executeHandler in TIAUTO_RH_verify_status_progression_StackedCR");
	
    return iRetCode;
}
																			
