/*******************************************************************************
FILE        :   tiauto_check_blank_change.c

DESCRIPTION :   This C file Implements the "TAUTO_check_blank_change"
				server exit which will be used to check the blank change (i.e. no item revs
				in the Affected and solution items folder of the change revision)

AUTHOR      :   Dipak Naik, TCS

Revision History :
Date            Revision    Who              Description
June 01, 2010    1.0        Dipak Naik		 Initial Creation

*******************************************************************************/
/* includes */
#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>

extern int setStatustoObjs(int iNoOfObjs, tag_t tStatus, date_t dateVal, tag_t *ptObjs)
{
	int i=0;
	int iFail = 0;
	char *classid_s = NULL;
	logical verdict = false;
	tag_t object_classID = NULLTAG;
	tag_t object_reldateID = NULLTAG;
	tag_t object_relStatListID = NULLTAG;
	int iAttachTypes[1] = {1};
	tag_t tProcess = NULLTAG;
	tag_t tProcessTemplate = NULLTAG;

	for(i=0;i<iNoOfObjs;i++)
	{
		iFail = POM_class_of_instance(ptObjs[i], &object_classID);
		if ( iFail == ITK_ok && object_classID!=NULLTAG)
		{
			iFail = POM_name_of_class(object_classID,&classid_s);
		}
		if ( iFail == ITK_ok )
		{
			iFail = POM_attr_id_of_attr("date_released",classid_s,&object_reldateID);
			iFail = POM_attr_id_of_attr("release_status_list",classid_s,&object_relStatListID);
			if ( iFail == ITK_ok )
			{
				iFail = POM_is_loaded(ptObjs[i], &verdict);
			}
			if (verdict == TRUE && iFail == ITK_ok)
			{
				iFail=POM_unload_instances(1, &ptObjs[i]);
			}
			if (iFail == ITK_ok)
			{
				iFail = POM_load_instances_any_class(1, &ptObjs[i], POM_modify_lock);
			}
			iFail = POM_clear_attr	( 1, &ptObjs[i], object_relStatListID);	
			iFail = EPM_find_process_template("Remove Status", &tProcessTemplate);
			iFail =  EPM_create_process("Delete Status", "", tProcessTemplate, 1, &ptObjs[i], iAttachTypes, &tProcess);
			iFail = EPM_add_release_status(tStatus,1,&ptObjs[i],false);
			iFail = POM_unload_instances(1, &ptObjs[i]);
			/*iFail = POM_load_instances_any_class(1, &ptObjs[i], POM_modify_lock);
			iFail = POM_set_attr_date(1, &ptObjs[i], object_reldateID, dateVal);
			if (iFail == ITK_ok)
			{
				iFail = POM_save_instances(1, &ptObjs[i], FALSE);
			}*/
		}
		SAFE_MEM_free(classid_s);
	}
	return iFail;
}

int TAUTO_set_status_on_object(void *return_value)
{
	int i=0;
	int iSecAttCount = 0; 
	int iFail = 0;
	char *pcStatusName = NULL;
	char acObjType[WSO_name_size_c+1]	 = "";
	char *classid_s = NULL;
	logical isDataset = false;
	date_t dateVal = NULLDATE;
	tag_t tObject = NULLTAG;
	AE_reference_type_t ref_type ;
	tag_t tNamedRef = NULLTAG;
	tag_t tDatasetType = NULLTAG;
	tag_t object_classID = NULLTAG;
	tag_t *ptSecObjects = NULL; 
	tag_t tSpecRelation = NULLTAG;
	tag_t tReleaseStatus = NULLTAG;
	int iItemRevBvrCount = 0;
	tag_t *ptItemRevBvrs = NULL;
	time_t rawtime;
	struct tm * timeinfo;

    iFail = USERARG_get_tag_argument(&tObject);
	iFail = USERARG_get_string_argument(&pcStatusName);

	if(tObject!=NULLTAG && pcStatusName!=NULL)
	{
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );
		printf(asctime(timeinfo));

		dateVal.day = timeinfo->tm_mday;
		dateVal.hour = timeinfo->tm_hour;
		dateVal.minute = timeinfo->tm_min;
		dateVal.month = timeinfo->tm_mon;
		dateVal.second = timeinfo->tm_sec;
		dateVal.year = timeinfo->tm_year+1900;

		TCTYPE_find_type("Dataset",NULL, &tDatasetType) ;
		
		iFail = CR_create_release_status (pcStatusName,&tReleaseStatus);
		if(tReleaseStatus!=NULLTAG)
			iFail = AOM_save(tReleaseStatus);
		else
			return -1;

		iFail = POM_class_of_instance(tObject, &object_classID);
		if ( iFail == ITK_ok && object_classID!=NULLTAG)
		{
			iFail = POM_name_of_class(object_classID,&classid_s); 
		}
		if ( iFail == ITK_ok )
		{
			if(tc_strcmp(classid_s, "ItemRevision")==0)
			{
				 iFail = GRM_find_relation_type("IMAN_specification", &tSpecRelation);
				iFail = GRM_list_secondary_objects_only  ( tObject, tSpecRelation, &iSecAttCount, &ptSecObjects) ; 
				for(i=0;i<iSecAttCount;i++)
				{
					iFail = AOM_is_type_of(ptSecObjects[i],tDatasetType,&isDataset);
					if(isDataset)// type of dataset
					{
						iFail = AE_ask_dataset_named_ref(ptSecObjects[i],"T8_Partner-CADAttributes",&ref_type,&tNamedRef);
						if(tNamedRef!=NULLTAG)
						{
							iFail = WSOM_ask_object_type(tNamedRef,acObjType);
							if(tc_strcmp(acObjType,"T8_TI_PartnerCADImportForm")==0)
							{
								//set status on the form
								iFail = setStatustoObjs(1, tReleaseStatus, dateVal, &tNamedRef);
								//iFail = AOM_refresh(tNamedRef,false);
							}
						}
						isDataset = false;
					}
				}
				// set status on all the sec objs
				if(iSecAttCount>0 && ptSecObjects!=NULL)
				{
					iFail = setStatustoObjs(iSecAttCount, tReleaseStatus, dateVal, ptSecObjects);
					SAFE_MEM_free(ptSecObjects);
				}

				tSpecRelation = NULLTAG;
				iSecAttCount = 0;
				//SAFE_MEM_free(ptSecObjects);
				iFail = GRM_find_relation_type("IMAN_Rendering", &tSpecRelation);
				iFail = GRM_list_secondary_objects_only  ( tObject, tSpecRelation, &iSecAttCount, &ptSecObjects) ; 
				if(iSecAttCount>0 && ptSecObjects!=NULL)
				{
					iFail = setStatustoObjs(iSecAttCount, tReleaseStatus, dateVal, ptSecObjects);
					SAFE_MEM_free(ptSecObjects);
				}

				iFail = ITEM_rev_list_bom_view_revs ( tObject, &iItemRevBvrCount, &ptItemRevBvrs);
				if ( (iFail == ITK_ok) &&  iItemRevBvrCount > 0 )
				{
					iFail = setStatustoObjs(1, tReleaseStatus, dateVal, &ptItemRevBvrs[0]);
					//iFail = AOM_refresh(ptItemRevBvrs[0],false);
				}
			}
			else if(tc_strcmp(classid_s, "Dataset")==0)
			{
				AE_ask_dataset_named_ref(tObject,"T8_Partner-CADAttributes",&ref_type,&tNamedRef);
				if(tNamedRef!=NULLTAG)
				{
					iFail = WSOM_ask_object_type(tNamedRef,acObjType);
					if(tc_strcmp(acObjType,"T8_TI_PartnerCADImportForm")==0)
					{
						//set status on the form
						iFail = setStatustoObjs(1, tReleaseStatus, dateVal, &tNamedRef);
						//iFail = AOM_refresh(tNamedRef,false);
					}
				}				
			}
			// set staus on the tObject
			iFail = setStatustoObjs(1, tReleaseStatus, dateVal, &tObject);	
			//iFail = AOM_refresh(tObject,false);
		}
	}
    return iFail;
}
