/*******************************************************************************************************************
File         : tiauto_user_query.c

Description  : These are functions related to the user query - "Change Affected programs"
			   This function will search the given program in various change item revision forms and
			   list the change items.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
08 Mar 2012		1.0			Mahesh B.S			Initial Creation  
06 Nov 2014     1.1         Pradeep M           Addded Change ID field to the query and modified the logic 
												for "owning site" search for local and remote objects.
19 Oct 2015		1.2			Pradeep				Made changes accordingly to TC10 env, added new Change Type(T8_TI_change)  
******************************************************************************************************************/
#include <tiauto_user_query.h>

/*=============================================================================================================
*		TIAUTO_find_Change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "Change Affected programs" user query.
================================================================================================================*/
extern int find_change_affected_program_in_form(char		*pcProgName,char	*pcChangeID,date_t	pcCreAfter, date_t	pcCreBefore, date_t	pcModAfter,
												date_t	pcModBefore, char		*pcDiv, char		*pcDesc, char		*pcSite, char		*pcGroup,
												char		*pcOwner, char		*pcLast_Mod_User, char		*pcRel_Stat, char		*pcTask,
												logical	alIn_data[12], char	*pcForm,char	*pcFo_Attr, char	*pcFo_ADiv,char	*pcFo_ADesc, int *iNumFound,tag_t **foundTags)
{
	int				iFail = ITK_ok;
	const char		*select_attr_list1[] = {"puid"};
	const char		*pcRelTypeName = "IMAN_specification";
	const char		*pcItemType[] = {"EngChange","T8_TI_Change"};
	int				iRows		= 0;
	int				i			= 0;
	int				iCols		= 0;
	void			***paReport;
	tag_t			tChItem	= NULLTAG;
	
	//Create the main query
	iFail = POM_enquiry_create ("Find_change_affect_prog");
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change_affect_prog", pcForm, pcFo_Attr,"class_affected"));  
	
	//select output attribute for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change_affect_prog", "Item", 1, select_attr_list1));
	
	//craete alias
	TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change_affect_prog", "user", 1, "user_alias"));	
	
	//start query expression for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_2","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_4","ImanRelation","relation_type",POM_enquiry_equal,"imantype","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id1", 1, &pcRelTypeName, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_5", "imantype","type_name",POM_enquiry_equal ,"aunique_value_id1" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_6","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_7","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
	/*Affected Program*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_8","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_9",pcForm,"puid",POM_enquiry_equal,"class_affected","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id2", 1, &pcProgName, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_10", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id2" ));
	/*TI Description*/
	if(alIn_data[6]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id3", 1, &pcDesc, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_11", pcForm, pcFo_ADesc,POM_enquiry_like ,"aunique_value_id3" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change_affect_prog","auniqueExprId_11",POM_case_insensitive));
	}
	/*TI Division*/
	if(alIn_data[5]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id4", 1, &pcDiv, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_12", pcForm, pcFo_ADiv,POM_enquiry_like ,"aunique_value_id4" ));
	}
	/*Owning Group*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_13","Pom_application_object","owning_group",POM_enquiry_equal,"pom_group","puid"));	
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id5", 1, &pcGroup, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_14", "pom_group","name",POM_enquiry_like ,"aunique_value_id5" ));
	/*Owning user*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_15","Pom_application_object","owning_user",POM_enquiry_equal,"user","puid"));	
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id6", 1, &pcOwner, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_16", "user","os_username",POM_enquiry_like ,"aunique_value_id6" ));
	/*last modified user*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_17","Pom_application_object","last_mod_user",POM_enquiry_equal,"user_alias","puid"));	
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id7", 1, &pcLast_Mod_User, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_18", "user_alias","os_username",POM_enquiry_like ,"aunique_value_id7" ));	
	/*Owning site*/
	if(alIn_data[8]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_19","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_20","pom_object","owning_site",POM_enquiry_equal, "pom_imc", "puid"  ));		
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id8", 1, &pcSite, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_21", "pom_imc","name",POM_enquiry_like ,"aunique_value_id8" ));
	}
	/*Release status*/
	if(alIn_data[11]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_22","itemrevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id9", 1, &pcRel_Stat, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_23", "ReleaseStatus", "name",POM_enquiry_like ,"aunique_value_id9" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change_affect_prog","auniqueExprId_23",POM_case_insensitive));

	}
	/*Current task*/
	if(alIn_data[12]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_24","itemrevision","process_stage_list",POM_enquiry_equal,"epmtask","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_25","epmtask","task_template",POM_enquiry_equal,"epmtasktemplate","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id10", 1, &pcTask, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_26", "epmtasktemplate", "template_name",POM_enquiry_like ,"aunique_value_id10"));
	}
	/*Created after date*/		
	if(alIn_data[1]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change_affect_prog", "aunique_value_id11", 1, &pcCreAfter, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_27","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id11"));	
	}
	/*Created before date*/
	if(alIn_data[2]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change_affect_prog", "aunique_value_id12", 1, &pcCreBefore, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_28","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id12"));
	}	
	/*Modified after date*/
	if(alIn_data[3]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change_affect_prog", "aunique_value_id13", 1, &pcModAfter, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_29","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id13"));
	}
	/*Modified before date*/
	if(alIn_data[4]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change_affect_prog", "aunique_value_id14", 1, &pcModBefore, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_30","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id14"));
	}
	/*Filter for EngChange items only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id15", 2, pcItemType, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_31", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id15" ));

	/*If Owning site & Logged in site are same*/
	if(alIn_data[13]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change_affect_prog", "auniqueExprId_100","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_101","pom_object","owning_site",POM_enquiry_is_null, NULL  ));		
	}
	/*Change ID*/
	if(alIn_data[14]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change_affect_prog", "aunique_value_id16", 1, &pcChangeID, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change_affect_prog", "auniqueExprId_102","Item", "item_id",POM_enquiry_like,"aunique_value_id16"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change_affect_prog","auniqueExprId_102",POM_case_insensitive));
	}

	//join the expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_40","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_41","auniqueExprId_40",POM_enquiry_and, "auniqueExprId_3" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_4" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_5" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_6" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_7" ));
	/*Affected Program*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_8" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_9" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_10" ));
	/*TI Description*/
	if(alIn_data[6]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_11" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*TI Division*/
	if(alIn_data[5]==true)
	{	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_12" ));	
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Owning Group*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_13" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_14" ));
	/*Owning user*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_15" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_16" ));
	/*last modified user*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_17" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_18" ));
	/*Owning site*/
	if(alIn_data[8]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_19" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_20" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_21" ));	
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_59","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Release status*/
	if(alIn_data[11]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_22" ));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_23" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_61","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Current task*/
	if(alIn_data[12]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_24" ));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_25" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_26" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_64","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Created after date*/		
	if(alIn_data[1]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_27" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Created before date*/
	if(alIn_data[2]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_28" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}	
	/*Modified after date*/
	if(alIn_data[3]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_29" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}	
	/*Modified before date*/
	if(alIn_data[4]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_30" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}
	/*Filter for EngChange items only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_31" ));

	/*If Owning site & Logged in site are same*/
	if(alIn_data[13]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_103","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_100" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_104","auniqueExprId_103",POM_enquiry_and, "auniqueExprId_101" ));	
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_104","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}

	/*Change ID*/
	if(alIn_data[14]==true)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_105","auniqueExprId_104",POM_enquiry_and, "auniqueExprId_102" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change_affect_prog","auniqueExprId_105","auniqueExprId_104",POM_enquiry_and, "auniqueExprId_7" ));//dummy
	}

	//set where expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change_affect_prog","auniqueExprId_105" ));	
	
	//set distinct value
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change_affect_prog", true));
	
	//execute the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change_affect_prog",&iRows,&iCols,&paReport));
	
	//delete the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change_affect_prog" ));
	
	//process result	
	if(iRows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(i=0;i<iRows;i++)
		{
			tChItem = NULLTAG;
			tChItem = *(tag_t *)paReport[i][0];
			(*foundTags)[i] = tChItem;
		}
		SAFE_MEM_free(paReport);
	}

	return iFail;
}