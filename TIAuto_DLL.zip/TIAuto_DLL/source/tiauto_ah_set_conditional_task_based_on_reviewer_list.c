/*******************************************************************************
File         : tiauto_ah_set_conditional_task_based_on_reviewer_list.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
June 28, 2013    1.0        Mahesh BS		Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
           
extern int TIAUTO_AH_set_conditional_task_based_on_reviewer_list(EPM_action_message_t msg)
{
	int			iRetCode = ITK_ok;
	int			iNumArgs = 0;
	logical		lAddRewReq = false;
	char		*pcErrMsg = NULL;
	int			i = 0;
	char		*pcValue = NULL;
    char		*pcFlag = NULL;
	char		*pcTaskName = NULL;
	
	char         szErrorString[TIAUTO_error_message_len+1]	= ""; 
	tag_t		tRootTaskTag = NULL_TAG;
	tag_t		tTask = NULL_TAG;
	tag_t		tTaskType = NULL_TAG;
	char        *pcTaskTypeName	= NULL;
	int			iAttachmentCnt = 0;
	tag_t       *ptAttachments = NULL;
	tag_t		tGroupMember = NULL_TAG;
	tag_t		tReposibleParty = NULL_TAG;
	int			iSubTaskCnt = 0;
	tag_t		*ptReviewSubTasks	= NULL;
	int			isubTaskIndx = 0;
	char		*pcSubTaskType = NULL;	

	//get the no. of arguments
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,"review_task_name") == 0 && pcValue != NULL)
				{
					pcTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTaskName, pcValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			}
			else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-set-conditional-task-on-additional-reviewer\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;				
			}
		}		
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }


	if(iRetCode == ITK_ok && pcTaskName != NULL)
	{
		//get the tag of the root task
		iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			//check whether the task name mentioned in the argument exists or not
			iRetCode = EPM_ask_sub_task(tRootTaskTag, pcTaskName,&tTask);
			//get the task type
			if(iRetCode == ITK_ok && tTask)
			{
				iRetCode = TCTYPE_ask_object_type(tTask,&tTaskType);
				if(iRetCode == ITK_ok && tTaskType != NULLTAG)
				{
					//get the task type name
					iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
					if(iRetCode == ITK_ok && ( (tc_strcmp(pcTaskTypeName, "EPMReviewTask") == 0) ||
												(tc_strcmp(pcTaskTypeName, "EPMAcknowledgeTask") == 0) ) )
					{
						//get sub tasks
						iRetCode = EPM_ask_sub_tasks( tTask, &iSubTaskCnt, &ptReviewSubTasks);
						if(iRetCode == ITK_ok && iSubTaskCnt)
						{
							for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && iRetCode == ITK_ok; isubTaskIndx++  )
							{
								if(ptReviewSubTasks[isubTaskIndx])
								{
									//get sub task type
									iRetCode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
									if( iRetCode == ITK_ok && pcSubTaskType != NULL && (tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
									{
										//get attachments of EPMSelectSignoffTask
										//iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
										iRetCode = EPM_ask_attachments(ptReviewSubTasks[isubTaskIndx],EPM_signoff_attachment,&iAttachmentCnt,&ptAttachments);
										if(iRetCode == ITK_ok && iAttachmentCnt>0)
										{
											//get the user from the 1st user selected in the select signoff
											iRetCode = AOM_ask_value_tag( ptAttachments[0], "group_member", &tGroupMember );
											if( iRetCode == ITK_ok && tGroupMember != NULLTAG)
											{
												tReposibleParty = NULLTAG;
												iRetCode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
												if(iRetCode == ITK_ok)
												{
													if(tReposibleParty)
													{
														lAddRewReq=true;
														break;
													}
													else
														lAddRewReq=false;
												}
											}						
											SAFE_MEM_free(ptAttachments);
										}
									}
									SAFE_MEM_free(pcSubTaskType);
								}
							}					
							SAFE_MEM_free(ptReviewSubTasks);
						}					
					}				
					SAFE_MEM_free(pcTaskTypeName);
				}
			}

			if(lAddRewReq==true)
			{
				iRetCode = EPM_set_condition_task_result(msg.task,EPM_RESULT_TRUE);
			}
			else
			{
				iRetCode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
			}
		}
	}


	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}

	return iRetCode;  
}