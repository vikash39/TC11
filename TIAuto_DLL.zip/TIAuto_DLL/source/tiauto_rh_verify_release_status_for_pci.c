/*******************************************************************************
FILE        :   tiauto_rh_verify_release_status_for_pci.c
Details     :   This handler blocks to initiate PCI if based on revision released status is either of PROTOTYPE, 
				Awarded or Quoted. PCI process can be initiated if the target release status of based on change revision 
				is either Production Released or Production Launched.

REVISION HISTORY :

Date              Revision        Who						Description
Dec  26, 2017     1.0			  Kantesh				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Rule Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_verify_release_status_for_pci(EPM_rule_message_t msg )
{
    int				iRetCode							= ITK_ok;
	int				iBasedOnSecObjCount					= 0;
	int				iChangeRevCnt						= 0;
	
	tag_t			tEngChangeRev						= NULLTAG;
	tag_t			*ptEngChangeBasedOnRev				= NULLTAG;
	
	logical			lValidStatus						= true;

	EPM_decision_t	decision							= EPM_go;

	/* To get change revision tag */
	if(iRetCode == 0)
	{
		iRetCode = tiauto_get_change_item_rev(msg.task, &tEngChangeRev);
	}

	/* To get based on revision tag */
	if(iRetCode == 0 && tEngChangeRev != NULLTAG)
	{
		TIAUTO_ITKCALL(iRetCode,AOM_ask_value_tags(tEngChangeRev,Rel_Change_ObjectRev,&iChangeRevCnt,&ptEngChangeBasedOnRev));
	}

	/* To get release status of based on change revision */
	if(iRetCode == 0 && iChangeRevCnt > 0 && ptEngChangeBasedOnRev[iChangeRevCnt-1] != NULLTAG)
	{
		char   *pcRelStatus		= NULL;

		TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(ptEngChangeBasedOnRev[iChangeRevCnt-1],CAP_TARGET_REL_STS,&pcRelStatus));

		/* If based on revision is released by CAP process and target release status is PROTOTYPE or QUOTED or AWARDED */
		if(iRetCode == 0 && (tc_strcmp(pcRelStatus,PROTOTYPE) == 0 || tc_strcmp(pcRelStatus,QUOTED) == 0 || tc_strcmp(pcRelStatus,AWARDED) == 0))
		{
			lValidStatus = false;
		}

		/* If based on revision is released by PMR process */
		if(iRetCode == 0 && tc_strcmp(pcRelStatus,"") == 0 )
		{
			TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(ptEngChangeBasedOnRev[iChangeRevCnt-1],PMR_TARGET_REL_STS,&pcRelStatus));
			/* If based on revision target released status is PROTOTYPE or QUOTED or AWARDED */
			if(iRetCode == 0 && (tc_strcmp(pcRelStatus,PROTOTYPE) == 0 || tc_strcmp(pcRelStatus,QUOTED) == 0 || tc_strcmp(pcRelStatus,AWARDED) == 0))
			{
				lValidStatus = false;
			}
		}

		SAFE_MEM_free(pcRelStatus);
	}
	
	if( iRetCode != ITK_ok )
	{
		char	*pcErrMsg		= NULL;
		decision				= EPM_nogo;

		EMH_ask_error_text(iRetCode, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}

	/* Setting decision to EPM_nogo if based on revision target release status is PROTOTYPE or Awardec or Quoted */
	if( iRetCode == ITK_ok && lValidStatus == false)
	{
		iRetCode = TIAUTO_PCI_INITIATION_PROCESS_NOT_ALLOWED;
		EMH_store_error(EMH_severity_error,iRetCode);
		decision = EPM_nogo;
	}

	SAFE_MEM_free(ptEngChangeBasedOnRev);

	return decision;
}
