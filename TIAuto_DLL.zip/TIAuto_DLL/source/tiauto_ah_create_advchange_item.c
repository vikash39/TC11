/*******************************************************************************
File         : tiauto_ah_create_mfgrelauthorisation_item.c

Description  : This will create the Mfg Release Authorization item and will ceate the ets request
				to update the Mfg Release Authorization PDF file.

Input        : None

Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                 Description
*******************************************************************************
26-Mar-2013    1.0        Dipak Naik			Initial Creation
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

int tiauto_Is_Object_Checked_out1(tag_t		tObject,					/*<I>*/
						  logical	*lIsCheckedOut,				/*<O>*/
						  char		**pcCheckedOutUserName,		/*<O>*/
						  char		**pcCheckedOutDate)			/*<O>*/
{
	int		iFail							= ITK_ok;
	tag_t	tCheckedOutUser					= NULLTAG;
	tag_t	tCheckedOutGroup				= NULLTAG;
	char	acOSUserName[SA_name_size_c+1]	= "";

	*lIsCheckedOut = false;
	// check if item revision is checked out
	if ( iFail == ITK_ok && tObject != NULLTAG)
		iFail = RES_is_checked_out( tObject, lIsCheckedOut );
	if( iFail == ITK_ok && *lIsCheckedOut == true)
	{
		iFail = RES_who_checked_object_out (tObject,&tCheckedOutUser,&tCheckedOutGroup);
		if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
		{
			iFail = SA_ask_user_person_name (  tCheckedOutUser, acOSUserName );
			if ( iFail == ITK_ok)
			{
				*pcCheckedOutUserName = (char *)malloc((int)tc_strlen(acOSUserName)+1);
				tc_strcpy(*pcCheckedOutUserName,acOSUserName);
			}
		}
		if ( iFail == ITK_ok)
		{
			iFail = AOM_UIF_ask_value  (tObject,"checked_out_date",pcCheckedOutDate);
		}
	}
	return iFail;
}

int create_M2M_AND_R2R_Relation1(tag_t tProductRev,tag_t tMRADocRev,TIA_ErrorMessage **pstCurrErrMsg)
{
	int   iFail = ITK_ok;
	int   iNumPrim = 0;
	int   iCheck = 0;

	tag_t tProduct = NULLTAG;
	tag_t tSite = NULLTAG;
	tag_t tRelation = NULLTAG;
	tag_t tItem = NULLTAG;
	tag_t tRelationType = NULLTAG;

	tag_t *ptPrimaryObjects = NULL;

	boolean bIsMfgRelAuthDocRevFound = false;
	boolean bIsMfgRelAuthDocFound = false;

	logical lHasAccess = false;

	char acProductItemID[ITEM_id_size_c+1] = "";
	char acMRAItemID[ITEM_id_size_c+1] = "";
	char	acErrorString[512]			= "";
	char *pcErrMsg = NULL;
	char *pcErrMsg1 = NULL;

	iFail = AOM_ask_value_tag(tProductRev,"owning_site",&tSite);

	iFail = ITEM_ask_item_of_rev (tProductRev,&tProduct);

	iFail = GRM_find_relation_type ("TI_DocProdRevisions",&tRelation);
	if( iFail == ITK_ok && tRelation != NULLTAG && tProductRev != NULLTAG)
	{
		iFail = GRM_list_primary_objects_only (tProductRev,tRelation,&iNumPrim,&ptPrimaryObjects);
		for(iCheck = 0; iCheck < iNumPrim && (iFail == ITK_ok) ; iCheck++ )
		{
			if(tMRADocRev == ptPrimaryObjects[iCheck])
			{
				bIsMfgRelAuthDocRevFound = true;
				SAFE_MEM_free(ptPrimaryObjects);
				break;
			}
		}
		SAFE_MEM_free(ptPrimaryObjects);
	}
	if(tMRADocRev != NULLTAG)
		iFail = ITEM_ask_item_of_rev (tMRADocRev,&tItem);

	iFail = GRM_find_relation_type ("TI_Engineering",&tRelation);
	if( iFail == ITK_ok && tRelation != NULLTAG)
	{
		iFail = GRM_list_secondary_objects_only (tProduct,tRelation,&iNumPrim,&ptPrimaryObjects);
		for(iCheck = 0; iCheck < iNumPrim && (iFail == ITK_ok) ; iCheck++ )
		{
			if(tItem == ptPrimaryObjects[iCheck])
			{
				bIsMfgRelAuthDocFound = true;
				SAFE_MEM_free(ptPrimaryObjects);
				break;
			}
		}
		SAFE_MEM_free(ptPrimaryObjects);
	}

	if(bIsMfgRelAuthDocRevFound == false && tMRADocRev != NULLTAG && tProductRev != NULLTAG)
	{
		iFail = GRM_find_relation_type ("TI_DocProdRevisions",&tRelationType);
		iFail = GRM_create_relation (tMRADocRev,tProductRev,tRelationType,NULLTAG,&tRelation);
		iFail = GRM_save_relation (tRelation);
	}
	tRelationType = NULLTAG;
	tRelation = NULLTAG;
	if(tProduct != NULLTAG)
		iFail = ITEM_ask_id (tProduct,acProductItemID);

	if(tItem != NULLTAG)
		iFail = ITEM_ask_id (tItem,acMRAItemID);

	if(bIsMfgRelAuthDocFound == false && tSite == NULLTAG)
	{
		iFail = GRM_find_relation_type ("TI_Engineering",&tRelationType);
		if(tRelationType != NULLTAG)
			iFail = GRM_create_relation (tProduct,tItem,tRelationType,NULLTAG,&tRelation);
		if(iFail == ITK_ok && tRelation != NULLTAG)
			iFail = GRM_save_relation (tRelation);

		if( (iFail != ITK_ok) || (tRelation == NULLTAG) )
		{
			tiauto_Is_Object_Checked_out1(tProduct,&lHasAccess,&pcErrMsg,&pcErrMsg1);
			if(lHasAccess == true)
			{
				TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to %s checked out by user %s on %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg,pcErrMsg1);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
			}
			else
			{
				EMH_ask_error_text (iFail, &pcErrMsg);
				TI_sprintf(acErrorString, "%-19s%-16s%s\n",acMRAItemID,acProductItemID,pcErrMsg);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
			}
		}
		iFail = 0;
	}
	else if(bIsMfgRelAuthDocFound == false && tSite != NULLTAG && tProduct != NULLTAG)
	{
		iFail = AOM_UIF_ask_value(tProduct,"owning_site",&pcErrMsg);
		iFail = RES_is_checked_out(tProduct,&lHasAccess);
		if(lHasAccess == false)
		{
			iFail = AM_check_privilege (tProduct,"REMOTE_CICO",&lHasAccess);
			if(lHasAccess != true)
				iFail = AM_check_privilege (tProduct,"CICO",&lHasAccess);

			if(lHasAccess == true && tProduct != NULLTAG)
			{
				//iFail = RES_assert_object_modifiable (tProduct);
				iFail = RES_checkout (tProduct,"Remote Check-Out","1","c:\\temp",RES_EXCLUSIVE_RESERVE);
				if(iFail == ITK_ok)
					iFail = GRM_find_relation_type ("TI_Engineering",&tRelationType);
				if(iFail == ITK_ok)
					iFail = GRM_create_relation (tProduct,tItem,tRelationType,NULLTAG,&tRelation);
				if(tRelation != NULLTAG)
				{
					iFail = GRM_save_relation (tRelation);
				}
				if( (iFail != ITK_ok) || (tRelation == NULLTAG) )
				{
					TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to %s checked out at remote site %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg);
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
				}
				iFail = AOM_save (tItem);
				iFail = AOM_save (tMRADocRev);
				iFail = AOM_refresh (tMRADocRev,false);
				iFail = AOM_refresh (tItem,false);

				iFail = RES_checkin (tProduct);
				iFail = 0;
			}
		}
		else
		{
			TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to no Write access on %s belongs to remote site %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg);
			tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
		}
	}
	SAFE_MEM_free(pcErrMsg);
	return iFail;
}

int create_child_MRA_Link1(tag_t tChildItemRev,tag_t tParentRev,char *pcItemRevId,TIA_ErrorMessage **pstCurrErrMsg)
{
	int   iFail = ITK_ok;
	int   iNumPrim = 0;
	int   iCheck = 0;
	int   iITRMCount = 0;

	tag_t tRelation = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t tMRADocRev = NULLTAG;

	tag_t *ptPrimaryObjects = NULL;
	tag_t *ptITRMAttach = NULL;

	char	acParentType[TCTYPE_name_size_c+1]			=	 "";
	char    szReleaseStatus[WSO_name_size_c+1]		  = "";
	char *pcMfgRelAuthCode = NULL;

	iFail = GRM_find_relation_type ("TI_DocProdRevisions",&tRelation);
	if( iFail == ITK_ok && tRelation != NULLTAG)
	{
		iFail = GRM_list_primary_objects_only (tParentRev,tRelation,&iNumPrim,&ptPrimaryObjects);
		for(iCheck = 0; iCheck < iNumPrim && (iFail == ITK_ok) ; iCheck++ )
		{
			tc_strcpy(acParentType,"");
			/* get the object type */
			iFail = WSOM_ask_object_type (ptPrimaryObjects[iCheck], acParentType);
			iFail = tiauto_get_release_status( ptPrimaryObjects[iCheck], szReleaseStatus );
			if( (tc_strcmp(acParentType,"T8_T_AdvChangeRevision") == 0) &&
				(tc_strcmp(szReleaseStatus,"") == 0))
			{
				tRelationType = NULLTAG;
				iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptPrimaryObjects[iCheck],tRelationType,&iITRMCount,&ptITRMAttach);
				if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
				{
					iFail = AOM_ask_value_string (ptITRMAttach[0],"t8_150acdnum",&pcMfgRelAuthCode);
					if( (pcMfgRelAuthCode != NULL) && (tc_strcmp(pcMfgRelAuthCode,"") != 0) &&
						(tc_strstr(pcMfgRelAuthCode,pcItemRevId) != NULL))
					{
						tMRADocRev = ptPrimaryObjects[iCheck];
						iFail = create_M2M_AND_R2R_Relation1(tChildItemRev,tMRADocRev,pstCurrErrMsg);
						break;
					}
				}
			}
		}
	}

	SAFE_MEM_free(ptPrimaryObjects);
	SAFE_MEM_free(ptITRMAttach);
	SAFE_MEM_free(pcMfgRelAuthCode);

	return iFail;
}

int create_acd_doc(tag_t tNewTopLevelAssmItem,tag_t tNewTopLevelAssmItemRev,tag_t tChangeRev,char *pcChgItemRevId,int iMfgRelAuthCount,boolean bIsCompMRA,tag_t	tUser,tag_t *tACDDoc,TIA_ErrorMessage **pstCurrErrMsg)
{
    int   iFail = ITK_ok;
	int iITRMCount = 0;
	int iNumPrim = 0;
	int iCheck = 0;
	char *pcItemId = NULL;
	char *pcItemDesc = NULL;
	char *pcMfgRelAuthCode = NULL;
	tag_t tSite = NULLTAG;
	tag_t tItem = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t tRelation = NULLTAG;
	tag_t tItemRev = NULLTAG;
	tag_t tGroup = NULLTAG;
	tag_t *ptITRMAttach = NULL;
	tag_t *ptPrimaryObjects = NULL;
	char acMfgRelAuthCode[32] = "";
	char	acParentType[TCTYPE_name_size_c+1]			=	 "";
	char acErrorString[513] = "";
	char acProductItemID[ITEM_id_size_c+1] = "";
	char acMRAItemID[ITEM_id_size_c+1] = "";
	boolean bIsMfgRelAuthDocFound = false;
	logical lHasAccess = false;
	char *pcErrMsg = NULL;
	char *pcErrMsg1 = NULL;

	*tACDDoc = NULLTAG;

	TI_sprintf(acMfgRelAuthCode,"TRA-%s-%d",pcChgItemRevId,iMfgRelAuthCount);

	iFail = AOM_ask_value_tag(tNewTopLevelAssmItem,"owning_site",&tSite);

	iFail = WSOM_ask_object_id_string (tNewTopLevelAssmItem,&pcItemDesc);
	//verify whether the MfgRelease Authorization is already created or not
	iFail = GRM_find_relation_type ("TI_DocProdRevisions",&tRelation);
	if( iFail == ITK_ok && tRelation != NULLTAG)
	{
		iFail = GRM_list_primary_objects_only (tNewTopLevelAssmItemRev,tRelation,&iNumPrim,&ptPrimaryObjects);
		for(iCheck = 0; iCheck < iNumPrim && (iFail == ITK_ok) ; iCheck++ )
		{
			tc_strcpy(acParentType,"");
			/* get the object type */
			iFail = WSOM_ask_object_type (ptPrimaryObjects[iCheck], acParentType);
			if(tc_strcmp(acParentType,"T8_T_AdvChangeRevision") == 0)
			{
				tRelationType = NULLTAG;
				iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptPrimaryObjects[iCheck],tRelationType,&iITRMCount,&ptITRMAttach);
				if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
				{
					iFail = AOM_ask_value_string (ptITRMAttach[0],"t8_150acdnum",&pcMfgRelAuthCode);
					if( (pcMfgRelAuthCode != NULL) && (tc_strcmp(pcMfgRelAuthCode,"") != 0) &&
						(tc_strstr(pcMfgRelAuthCode,pcChgItemRevId) != NULL))
					{
						bIsMfgRelAuthDocFound = true;
						iFail = ITEM_ask_item_of_rev (ptPrimaryObjects[iCheck],&tItem);

						break;
					}
					SAFE_MEM_free(pcMfgRelAuthCode);
				}
				SAFE_MEM_free(ptITRMAttach);
			}
		}
		SAFE_MEM_free(ptPrimaryObjects);
	}

	if(bIsMfgRelAuthDocFound == false)
	{
		iFail = NR_next_value("T8_T_AdvChange", "item_id", NULLTAG,"", "", "", NULLTAG, ""," ", &pcItemId);
		//create the item based on the input data
		iFail = ITEM_create_item  ( pcItemId,"Tech Release Authorisation", "T8_T_AdvChange",NULL, &tItem,&tItemRev );
		//set the item description
		if(tItem != NULLTAG)
			iFail = ITEM_set_description (tItem,pcItemDesc);
		//set the revision description
		if(tItemRev != NULLTAG)
			iFail = ITEM_set_rev_description (tItemRev,pcItemDesc);
	}
	else if(bIsMfgRelAuthDocFound == true)
	{
		iFail = NR_next_value("T8_T_AdvChange", "item_revision_id", tItem,"", "", "", NULLTAG, ""," ", &pcItemId);
		iFail = ITEM_create_rev (tItem,pcItemId,&tItemRev);
		if(tItemRev != NULLTAG)
			iFail = ITEM_set_rev_description (tItemRev,pcItemDesc);
	}

	//iFail = SA_find_user (TI_ERP_INTEGRATION_USER,&tUser);
	
	if(tUser != NULLTAG)
		iFail = SA_ask_user_login_group(tUser,&tGroup);

	//iFail = POM_set_owning_user(tItemRev, tUser);
	//iFail = POM_set_owning_group(tItemRev,tGroup);
	//create the M2m & R2R relation
	iFail = GRM_find_relation_type ("TI_DocProdRevisions",&tRelationType);
	iFail = GRM_create_relation (tItemRev,tNewTopLevelAssmItemRev,tRelationType,NULLTAG,&tRelation);
	if(tItem != NULLTAG && (bIsMfgRelAuthDocFound == false) )
		iFail = ITEM_save_item (tItem);

	iFail = ITEM_save_rev (tItemRev);
	iFail = GRM_save_relation (tRelation);
	tRelationType = NULLTAG;
	tRelation = NULLTAG;

	if(tNewTopLevelAssmItem != NULLTAG)
		iFail = ITEM_ask_id (tNewTopLevelAssmItem,acProductItemID);

	if(tItem != NULLTAG)
		iFail = ITEM_ask_id (tItem,acMRAItemID);

	if(bIsMfgRelAuthDocFound == false && tSite == NULLTAG)
	{
		iFail = GRM_find_relation_type ("TI_Engineering",&tRelationType);
		if( (iFail == ITK_ok) && (tRelationType != NULLTAG) )
			iFail = GRM_create_relation (tNewTopLevelAssmItem,tItem,tRelationType,NULLTAG,&tRelation);
		if( (iFail == ITK_ok) && (tRelation != NULLTAG) )
			iFail = GRM_save_relation (tRelation);

		if( (iFail != ITK_ok) || (tRelation == NULLTAG) )
		{
			tiauto_Is_Object_Checked_out1(tNewTopLevelAssmItem,&lHasAccess,&pcErrMsg,&pcErrMsg1);
			if(lHasAccess == true)
			{
				TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to %s checked out by user %s on %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg,pcErrMsg1);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
			}
			else
			{
				EMH_ask_error_text (iFail, &pcErrMsg);
				TI_sprintf(acErrorString, "%-19s%-16s%s\n",acMRAItemID,acProductItemID,pcErrMsg);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
			}
		}
		iFail = ITK_ok;
	}
	else if(bIsMfgRelAuthDocFound == false && tSite != NULLTAG)
	{
		iFail = AOM_UIF_ask_value(tNewTopLevelAssmItem,"owning_site",&pcErrMsg);

		iFail = AM_check_privilege (tNewTopLevelAssmItem,"REMOTE_CICO",&lHasAccess);
		if(lHasAccess != true)
			iFail = AM_check_privilege (tNewTopLevelAssmItem,"CICO",&lHasAccess);

		if(lHasAccess == true)
		{
			//iFail = RES_assert_object_modifiable (tNewTopLevelAssmItem);
			iFail = RES_checkout (tNewTopLevelAssmItem,"Remote Check-Out","1","c:\\temp",RES_EXCLUSIVE_RESERVE);
			if(iFail == ITK_ok)
			{
				iFail = GRM_find_relation_type ("TI_Engineering",&tRelationType);
				if(iFail == ITK_ok && tRelationType != NULLTAG)
					iFail = GRM_create_relation (tNewTopLevelAssmItem,tItem,tRelationType,NULLTAG,&tRelation);
				if(iFail == ITK_ok && tRelation != NULLTAG)
					iFail = GRM_save_relation (tRelation);

				iFail = AOM_save (tItem);
				iFail = AOM_save (tItemRev);
				iFail = AOM_refresh (tItemRev,false);
				iFail = AOM_refresh (tItem,false);

				if(iFail == ITK_ok)
					iFail = RES_checkin (tNewTopLevelAssmItem);
			}
			if( (iFail != ITK_ok) || (tRelation == NULLTAG) )
			{
				TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to %s checked out at remote site %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
			}
			iFail = 0;
		}
		else
		{
			TI_sprintf(acErrorString, "%-19s%-16sFailed to create due to no Write access on %s belongs to remote site %s\n",acMRAItemID,acProductItemID,acProductItemID,pcErrMsg);
			tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_MRA_M2M_RELATION_CREATION_ERROR, acErrorString);
		}

	}
	//iFail = ITEM_save_rev (tNewTopLevelAssmItem);
	*tACDDoc = tItemRev;

	tRelationType = NULLTAG;
	iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
	if(tRelationType != NULLTAG)
		iFail = GRM_list_secondary_objects_only(tItemRev,tRelationType,&iITRMCount,&ptITRMAttach);
	if(iITRMCount > 0 && ptITRMAttach[0] != NULLTAG)
	{
		iFail = AOM_refresh (ptITRMAttach[0],true);
		//get the Master Drawing and Rev value from the item rev master form
		iFail = AOM_set_value_string (ptITRMAttach[0],"t8_150acdnum",acMfgRelAuthCode);
		iFail = AOM_save (ptITRMAttach[0]);
		iFail = AOM_refresh (ptITRMAttach[0],false);
	}
	SAFE_MEM_free(ptITRMAttach);

	if(tItemRev != NULLTAG && tSite != NULLTAG)
		iFail = AOM_refresh (tItemRev,true);

	if(tUser != NULLTAG && tGroup != NULLTAG && tItemRev != NULLTAG)// && bIsCompMRA == false)
		iFail = AOM_set_ownership (tItemRev,tUser,tGroup);
	if(bIsMfgRelAuthDocFound == false)
	{
		if(tItem != NULLTAG && tSite != NULLTAG)
			iFail = AOM_refresh (tItem,true);

		if(tUser != NULLTAG && tGroup != NULLTAG && tItem != NULLTAG)// && bIsCompMRA == false)
			iFail = AOM_set_ownership (tItem,tUser,tGroup);

		iFail = ITEM_save_item (tItem);
		iFail = AOM_refresh (tItem,false);
	}

	if(tItemRev != NULLTAG)
	{
		iFail = ITEM_save_rev (tItemRev);
		iFail = AOM_refresh (tItemRev,false);
	}
	
	SAFE_MEM_free(pcItemId);
	SAFE_MEM_free(pcItemDesc);
	SAFE_MEM_free(pcErrMsg);

	return iFail;
}


int process_aliaslist_recipient1( tag_t alist,                 /* <I> */
                                        counted_list_t * mail_addresses   /* <OF> */
                                      )
{
    int rcode = ITK_ok;
    int add_count = 0;
    char **tmp_add = NULL;

    rcode = MAIL_ask_alias_list_members( alist , &add_count , &tmp_add );

    if( rcode == ITK_ok )
    {
        int inx          = 0;

        for( inx = 0; inx < add_count ; inx++ )
        {

            // Check to see if this is an embedded alias list. If it is, then
            // recursively process it. If it isn't then add the name to the
            // recipient list.

            tag_t alist = NULLTAG;
            rcode = MAIL_find_alias_list( (const char *)tmp_add[inx], &alist );
            if (rcode== ITK_ok  &&  alist!=NULLTAG )
            {
                rcode = process_aliaslist_recipient1(alist, mail_addresses);
            }
            else
            {
                // ahujak : The tmp_add could be a TC user, if its TCUser then
                // get the email id for TC user,
                // else assume it to be an OS user.
                // PR 6040910: dasatish It could be a TC Group as well
                tag_t the_user = NULLTAG;
                tag_t the_group = NULLTAG;
                char  *the_email = 0;
                logical group_found = false;
                int user_status = 1;

                // lets see if tmp_add is a TC user or a group ...
                if( ((rcode = SA_find_user(tmp_add[inx],&the_user)) == ITK_ok)
                      && (the_user != NULLTAG)
                  )
                {
                    // get the email address for TC user
                    rcode = EPM_get_user_email_addr( the_user, &the_email );

                    //PR#1797751 Email notification sent to inactive users
                    if ((SA_get_user_status(the_user,&user_status) == ITK_ok) && user_status == 0)
                    {
                        if( (rcode == ITK_ok) && (the_email != 0) )
                        {
                            rcode = EPM_add_to_list( mail_addresses, the_email );
                        }
                    }
                }
                else if( ((rcode = SA_find_group(tmp_add[inx], &the_group)) == ITK_ok) && (the_group != NULLTAG) )
                {
                    //support Group in the list
                    int groupmember_count = 0;
                    int inx_num = 0;
                    tag_t *groupmember_tags = NULL;     /* MEM_free this */
                    char * groupName = tmp_add[inx];

                    rcode = SA_find_groupmember_by_rolename(NULL, groupName, NULL,  &groupmember_count, &groupmember_tags);
                    if( rcode == ITK_ok && groupmember_count > 0 )
                    {
                        int   user_count = 0;
                        tag_t *user_tags = NULL ;
                        rcode = EPM_get_users_for_group_members( groupmember_count, groupmember_tags, &user_count, &user_tags );
                        if( rcode == ITK_ok )
                        {
                            for( inx_num = 0; inx_num < user_count ; inx_num++ )
                            {
                                char  *the_useremail = 0;
                                rcode = EPM_get_user_email_addr( user_tags[inx_num], &the_useremail );
                                user_status = 1;
                                if ((SA_get_user_status(user_tags[inx_num],&user_status) == ITK_ok) && user_status == 0)
                                {
                                    if( (rcode == ITK_ok) && (the_useremail != 0) )
                                    {
                                        rcode = EPM_add_to_list( mail_addresses, the_useremail );
                                    }
                                }
                            }
                        }
                        SAFE_SM_FREE( user_tags );
                    }
                    SAFE_SM_FREE( groupmember_tags );
                }

                // if not assume it to be an OS user/external Email ID..
                // also check if a group was found
                if( (the_user == NULLTAG) || (the_email == 0) && !group_found )
                {
                    rcode = EPM_add_to_list( mail_addresses, tmp_add[inx] );
                }

                MEM_free(the_email);
            }
            MEM_free( tmp_add[inx] );
        }
        SAFE_SM_FREE( tmp_add );
    }

    return rcode;

}

void tiauto_release_string_array1( int count,  char **list  )
{
    int inx;

    if( list == 0 )
    {
         return;
    }

    for(inx = 0; inx < count ; inx++ )
    {
         SAFE_SM_FREE( list[inx] );
    }

    SAFE_SM_FREE(list);

    list = 0;
}

extern int TIAUTO_AH_Create_ACD_Item(EPM_action_message_t msg)
{
	tag_t		tChangeRev			= NULLTAG;	
	tag_t		tGroup				= NULLTAG;
	tag_t		tRequest			= NULLTAG;
	tag_t		tSite				= NULLTAG;
	tag_t		tRootTask			= NULLTAG;
	tag_t		tProgramManager		= NULLTAG;
	tag_t		tChangeForm			= NULLTAG;
	tag_t		tACDDoc		= NULLTAG;
	tag_t		tOldAssemItem		= NULLTAG;
	tag_t 		tNewAssemItem		= NULLTAG;
	tag_t		tMRAOwner			= NULLTAG;
	tag_t		tRespParty			= NULLTAG;
	tag_t		*ptParents			= NULL;
	tag_t		*ptAffectedItems	= NULL;
	tag_t		*ptOldAssembly		= NULL;
	tag_t		*ptNewAssembly		= NULL;
	tag_t		*ptCompMRA			= NULL;

	char		*pcItemId					= NULL;
	char		*pcItemRevId				= NULL;
	char		*pcRevDesc					= NULL;
	char		*pcFlag						= NULL;
	char		*pcValue					= NULL;
	char		*pcReportDecision			= NULL;
	char		*pcProgMgrName				= NULL;
	char		*pcDisPatcherArgValue		= NULL;
	char		*pcValidReleaseStatusList	= NULL;
	char		*pcTargetReleaseStatus		= NULL;
	char		*pcMailBodyFileName = NULL;

	char		acSiteName[SA_site_size_c+1]			= {'\0'};
	char		acRootTaskName[WSO_name_size_c+1]		= "";
	char		acOldAssmRevId[ITEM_id_size_c+1]		= "";
	char		acNewAssmRevId[ITEM_id_size_c+1]		= "";
	char		acObjectType[TCTYPE_name_size_c+1]		= "";
	char		acTargetObjectType[TCTYPE_name_size_c + 1]					= "";

	int			indx					= 0;
	int			iNumArgs				= 0;
	int			i						= 0;
    int         iRetCode				= ITK_ok;
	int         iMfgRelAuthCount		= 0;
	int			iSite					= 0;
	int			iSiteID					= 0;
	int			iNewAseemCount			= 0;
	int			iOldAseemCount			= 0;
	int			iCompMRACount			= 0;
	int			iNumAffected			= 0;
	int			iNoOfParent				= 0;
	int			*piLevel				= NULL;
	int         iFileOpenErrCode		= 0;

	boolean bValidERPPlant = false;
	boolean bIsToolNoteToBeCreated = false;
	boolean bIsToolNoteValidation = false;
	boolean bIsAdditionalToolNoteValidation = false;
	boolean bIsDraftVersion = false;
	boolean bParentMRAFound = false;
	boolean bIsToolNotePreCondition = false;

	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;
	TIA_ErrorMessage *pstCurrErrMsg = NULL;
	TIA_ErrorMessage *tempErrMsg	= NULL;

	FILE *fMailBodyFile = NULL;
	counted_list_t     mail_addresses;
	counted_list_t     final_mail_list;
	tag_t tDistributionList			= NULLTAG;
	char acDataString[513]			= "";
	char *pcTaskId  = NULL;


	tag_t tRelationType = NULLTAG;
	tag_t tRelation = NULLTAG;

	//Get the Current Site Name
	if( iRetCode == ITK_ok )
		iRetCode = POM_site_id(&iSite);

	if(iRetCode== ITK_ok && iSite != 0)
		iRetCode = SA_find_site_by_id(iSite,&tSite);

	if(iRetCode == ITK_ok && tSite != NULLTAG)
		iRetCode = SA_ask_site_info(tSite,acSiteName,&iSiteID);

	iNumArgs = TC_number_of_arguments(msg.arguments);
	if (iNumArgs > 0)
	{
		for(i = 0; i < iNumArgs; i++)
		{

			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag, "action") == 0 && pcValue != NULL)
				{
					if( tc_strcasecmp(pcValue, "draft") == 0 )
					{
						pcReportDecision = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcReportDecision, pcValue);
						bIsDraftVersion = true;
					}
				}
			}
		}
	}
	if ( iRetCode == ITK_ok)
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);

	if(tChangeRev != NULLTAG)
		iRetCode = WSOM_ask_object_type(tChangeRev,acTargetObjectType);

	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);
		iRetCode = tiauto_get_status_progression_array (&StatusProgression);

		tSite = NULLTAG;
		//get the owning site
		iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
		//get the root task
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
		iRetCode = EPM_ask_responsible_party (msg.task, &tRespParty) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}		

		if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TPR",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201newacdassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a201componentacd",&iCompMRACount,&ptCompMRA);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a201targetreleasestate",&pcTargetReleaseStatus);
			}
			iRetCode = tiauto_getUser(tRootTask,"23_170 Approve Preliminary TRA",&tProgramManager);
			if(tProgramManager != NULLTAG)
				iRetCode = SA_ask_user_person_name2 (tProgramManager,&pcProgMgrName);
		}
		else if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0 )
		{
			iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_TER",&tChangeForm);
			if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
			{
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205newacdassembly",&iNewAseemCount,&ptNewAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205oldtoplevassembly",&iOldAseemCount,&ptOldAssembly);
				iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a205componentmra",&iCompMRACount,&ptCompMRA);
				iRetCode = AOM_ask_value_string(tChangeForm,"t8_t1a205targetreleasestate",&pcTargetReleaseStatus);
			}
			iRetCode = tiauto_getUser(tRootTask,"25_90 Approve Preliminary TRA",&tProgramManager);
			if(tProgramManager != NULLTAG)
				iRetCode = SA_ask_user_person_name2 (tProgramManager,&pcProgMgrName);
		}
		
		if(pcTargetReleaseStatus != NULL)
		{
			tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,pcTargetReleaseStatus);
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
		}
		//verify the old and new top level assembly
		if(iNewAseemCount > 0 || iCompMRACount > 0)
		{
			tag_t		tUser				= NULLTAG;	
			//iRetCode = SA_find_user (TI_ERP_INTEGRATION_USER,&tUser);
			//if(tUser != NULLTAG)
				//iRetCode = SA_ask_user_login_group(tUser,&tGroup);			
			iRetCode = verify_Valid_ACD_Condition(msg.task,&bIsToolNoteToBeCreated,&pcValidReleaseStatusList);			
			//verify the starts
			pcDisPatcherArgValue = (char *)MEM_alloc(sizeof(pcProgMgrName) + 30);
			tc_strcpy(pcDisPatcherArgValue,"ProgramManagerName=");
			tc_strcat(pcDisPatcherArgValue,pcProgMgrName);
			if ( (bIsDraftVersion == true && ( tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0  )) || (bIsDraftVersion == true && ( tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0  )))
			{
				iRetCode = tiauto_get_itemrev_name(tChangeRev,&pcItemRevId);
				iMfgRelAuthCount = 1;
				for(indx = 0; indx < iNewAseemCount; indx++)
				{
					tOldAssemItem = NULLTAG;
					tNewAssemItem = NULLTAG;
					tACDDoc = NULLTAG;
					bIsToolNoteValidation = false;
					bIsToolNotePreCondition = false;

					tc_strcpy(acObjectType,"");
					/* get the object type */
					iRetCode = WSOM_ask_object_type (ptNewAssembly[indx], acObjectType);
					if( (tc_strcmp(acObjectType,"TI_Product Revision") != 0) && (tc_strcmp(acObjectType,"TI_Prg_Variant Revision") != 0))
					{
						continue;
					}
					//get the item tag
					iRetCode = ITEM_ask_item_of_rev(ptNewAssembly[indx], &tNewAssemItem);
					if(indx < iOldAseemCount)
					{
						if(ptOldAssembly[indx] != NULLTAG)
						{
							iRetCode = ITEM_ask_item_of_rev(ptOldAssembly[indx], &tOldAssemItem);

							if(tNewAssemItem == tOldAssemItem)
							{
								tc_strcpy(acNewAssmRevId,"");
								tc_strcpy(acOldAssmRevId,"");
								iRetCode = ITEM_ask_rev_id (ptNewAssembly[indx],acNewAssmRevId);
								iRetCode = ITEM_ask_rev_id (ptOldAssembly[indx],acOldAssmRevId);
								if(tc_strcasecmp(acNewAssmRevId, acOldAssmRevId) > 0)
								{
									bIsToolNotePreCondition = true;
								}
							}
							else
							{
								bIsToolNotePreCondition = true;
							}
						}
						else
						{
							bIsToolNotePreCondition = true;
						}
					}
					else
					{
						bIsToolNotePreCondition = true;
					}

					if(bIsToolNotePreCondition == true)
					{						
						iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptNewAssembly[indx],pcTargetReleaseStatus,"All",&bIsToolNoteValidation);//pcValidReleaseStatusList,&bIsToolNoteValidation);
						if(bIsToolNoteValidation == true)
							iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptNewAssembly[indx],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,false, iNewAseemCount,ptNewAssembly,&bIsAdditionalToolNoteValidation);
						if(bIsToolNoteValidation == true && bIsAdditionalToolNoteValidation == true)
							iRetCode = create_acd_doc(tNewAssemItem,ptNewAssembly[indx],tChangeRev,pcItemRevId,iMfgRelAuthCount,false,tRespParty,&tACDDoc,&pstCurrErrMsg);						
						
					}
					if(tACDDoc != NULLTAG)
					{
						iMfgRelAuthCount++;
						if(tc_strcmp(acTargetObjectType,"EngChange Revision") ==0)
						{
							iRetCode = ECM_add_contents(tChangeRev,"solution_items",1,&tACDDoc);
						}
						else
						{
							iRetCode = GRM_find_relation_type ("CMHasSolutionItem",&tRelationType);
							if(iRetCode == ITK_ok && tRelationType!=NULLTAG)
							{
								if(iRetCode == ITK_ok && tRelationType != NULLTAG)
									iRetCode = GRM_create_relation (tChangeRev,tACDDoc,tRelationType,NULLTAG,&tRelation);
								if(iRetCode == ITK_ok && tRelation != NULLTAG)
									iRetCode = GRM_save_relation (tRelation);

								//iRetCode = AOM_refresh(tChangeRev,true);
								//iRetCode = AOM_save(tChangeRev);
								//iRetCode = AOM_refresh(tChangeRev,false);

							}
							//iRetCode = ECM_add_contents (tChangeRev,"CMHasSolutionItem",1,&tACDDoc);
						}
					}
				}
				if(iNewAseemCount > 0)
				{
					iRetCode = ECM_get_affected_items(tChangeRev, &iNumAffected, &ptAffectedItems);
					for(indx = 0; indx < iNumAffected; indx++)
					{
						bParentMRAFound = false;
						tc_strcpy(acObjectType,"");
						/* get the object type */
						iRetCode = WSOM_ask_object_type (ptAffectedItems[indx], acObjectType);
						if( (tc_strcmp(acObjectType,"TI_Product Revision") != 0) && (tc_strcmp(acObjectType,"TI_Prg_Variant Revision") != 0))
						{
							continue;
						}

						//check where used verify same in the top level field
						iRetCode = PS_where_used_precise (ptAffectedItems[indx],PS_where_used_all_levels,&iNoOfParent,&piLevel,&ptParents);
						for(i=0; i <iNoOfParent; i++)
						{
							for(iNumArgs=0; iNumArgs <iNewAseemCount; iNumArgs++)
							{
								if(ptNewAssembly[iNumArgs] == ptParents[i])
								{
									//find the parent MRA and create the link
									iRetCode = create_child_MRA_Link1(ptAffectedItems[indx],ptNewAssembly[iNumArgs],pcItemRevId,&pstCurrErrMsg);
									bParentMRAFound = true;
									break;
								}
							}
							if(bParentMRAFound == true)
							{
								break;
							}
						}
					}
				}
				tACDDoc = NULLTAG;
				if(iCompMRACount > 0)
				{
					for(indx=0; indx<iCompMRACount;indx++)
					{
						bIsToolNoteValidation = false;
						tc_strcpy(acObjectType,"");
						/* get the object type */
						iRetCode = WSOM_ask_object_type (ptCompMRA[indx], acObjectType);
						if(tc_strcmp(acObjectType,"TI_Product Revision") != 0)
						{
							continue;
						}
						iRetCode = verify_MfgReleaseAuthorisation_Creation_Condition(ptCompMRA[indx],pcTargetReleaseStatus,pcValidReleaseStatusList,&bIsToolNoteValidation);
						if(bIsToolNoteValidation == true)
							iRetCode = verify_MfgReleaseAuthorisation_Creation_Additional_Condition(ptCompMRA[indx],tChangeRev,pcTargetReleaseStatus,&StatusProgression,&TargetReleaseStatus,true, iNewAseemCount,ptNewAssembly,&bIsAdditionalToolNoteValidation);

						if(bIsToolNoteValidation == true && bIsAdditionalToolNoteValidation == true )
						{
							tNewAssemItem = NULLTAG;
							iRetCode = ITEM_ask_item_of_rev(ptCompMRA[indx], &tNewAssemItem);
							if( tACDDoc == NULLTAG)
							{
								iRetCode = create_acd_doc(tNewAssemItem,ptCompMRA[indx],tChangeRev,pcItemRevId,iMfgRelAuthCount,true,tRespParty,&tACDDoc,pstCurrErrMsg);
								if(tACDDoc != NULLTAG)
								{

									if(tc_strcmp(acTargetObjectType,"EngChange Revision") ==0)
									{
										iRetCode = ECM_add_contents(tChangeRev,"solution_items",1,&tACDDoc);
									}
									else
									{
										iRetCode = GRM_find_relation_type ("CMHasSolutionItem",&tRelationType);
										if(iRetCode == ITK_ok && tRelationType!=NULLTAG)
										{
											if(iRetCode == ITK_ok && tRelationType != NULLTAG)
												iRetCode = GRM_create_relation (tChangeRev,tACDDoc,tRelationType,NULLTAG,&tRelation);
											if(iRetCode == ITK_ok && tRelation != NULLTAG)
												iRetCode = GRM_save_relation (tRelation);

											//iRetCode = AOM_refresh(tChangeRev,true);
											//iRetCode = AOM_save(tChangeRev);
											//iRetCode = AOM_refresh(tChangeRev,false);
										}
										//iRetCode = ECM_add_contents (tChangeRev,"CMHasSolutionItem",1,&tACDDoc);
									}

								}
							}
							else
							{
								//create the M2M & R2R relation
								iRetCode = create_M2M_AND_R2R_Relation1(ptCompMRA[indx],tACDDoc,&pstCurrErrMsg);
							}
						}
					}
					if(tUser != NULLTAG && tACDDoc != NULLTAG)
					{
						iRetCode = AOM_ask_owner(tACDDoc,&tMRAOwner);
						if(tMRAOwner != tUser)
						{
							iRetCode = AOM_set_ownership (tACDDoc,tUser,tGroup);
							iRetCode = AOM_refresh (tACDDoc,false);
						}
					}
				}

				iRetCode = DISPATCHER_create_request  ( "TI-ERP", "advancedtechnology",3,0 ,0 ,0, 1,&tChangeRev,NULL,1  ,&pcDisPatcherArgValue,"AdvChangeCreate_Draft",0,NULL,NULL,&tRequest);
				if(tUser != NULLTAG && tRequest != NULLTAG)
				{
					iRetCode = AOM_set_ownership (tRequest,tUser,tGroup);
					iRetCode = AOM_refresh (tRequest,false);
				}
			}
			//if(bValidERPPlant == true && bIsToolNoteToBeCreated == true && bIsDraftVersion == false)
			if( (bIsDraftVersion == false && ( tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0  )) || (bIsDraftVersion == false && ( tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0  )))
			{
				iRetCode = SA_find_user (TI_ERP_INTEGRATION_USER,&tUser);
				iRetCode = DISPATCHER_create_request  ( "TI-ERP", "advancedtechnology",3,0 ,0 ,0, 1,&tChangeRev,NULL,1  ,&pcDisPatcherArgValue,"AdvChangeCreate",0,NULL,NULL,&tRequest);

				if(tUser != NULLTAG && tRequest != NULLTAG)
				{
					iRetCode = SA_ask_user_login_group(tUser,&tGroup);
					iRetCode = AOM_set_ownership (tRequest,tUser,tGroup);
					iRetCode = AOM_refresh (tRequest,false);
				}
			}
		}

	}

	if(pstCurrErrMsg != NULL)
	{
		pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
		iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
		if(fMailBodyFile != NULL)
		{

			fprintf(fMailBodyFile,"In the %s PLM site, the master to master relationship failed to be created between MRA document(s) and TI Product(s) for the following:\n\n",acSiteName);
			fprintf(fMailBodyFile,"\n\n%-19s%-26s%s","TRA DOCUMENT","TI Product/Prg Variant","Reason");
			fprintf(fMailBodyFile,"\n------------------------------------------------------------------------------------------------------\n");

			tempErrMsg = pstCurrErrMsg;
			while(tempErrMsg)
			{
				fprintf(fMailBodyFile,"%s\n",tempErrMsg->errMsg);
				TC_write_syslog(tempErrMsg->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = tempErrMsg->next;
			}


			if(tRequest != NULLTAG)
			{
				//iRetCode = DISPATCHER_find_request_by_tag (tRequest,&pcTaskId,&pcPproviderName,&pcServiceName,&iPpriority,&pcCurrentState,&pctType,
				//											&iNumObjs,&ptPrimaryObjs,&ptSecondaryObjs,&iNumDisArgs,&pcArgKeys,&pcArgData);
				iRetCode = AOM_ask_value_string (tRequest,"taskID",&pcTaskId);
			}
			fprintf(fMailBodyFile,"\n\nDetails can be found in ETS dispatcher request %s for %s.\n",pcTaskId,pcItemRevId);
			fclose(fMailBodyFile);
		}

		final_mail_list.count = 0;
		mail_addresses.count = 0;
		final_mail_list.list = NULL;
		mail_addresses.list = (char **)MEM_alloc( 15 * sizeof(char*) );

		iRetCode = MAIL_find_alias_list ("PLM to ERP Integration",&tDistributionList);

		if(tDistributionList != NULLTAG)
			iRetCode = process_aliaslist_recipient1(tDistributionList,&mail_addresses);

		if(mail_addresses.count > 0)
		{
			EPM_remove_duplicate_strings( mail_addresses.count , mail_addresses.list,
                                  &(final_mail_list.count),&(final_mail_list.list));
		}

		TI_sprintf(acDataString,"%s � [MRA-M2M] Master to Master relationship failed for MRA Document",acSiteName);

		for(i =0; i <final_mail_list.count;i++)
		{
			iRetCode = tiauto_sendEMailFromPLMAdmin(acDataString, final_mail_list.list[i], pcMailBodyFileName);
		}
		if(tProgramManager != NULLTAG)
		{
			char *pcUserMailId = NULL;
			iRetCode = EPM_get_user_email_addr(tProgramManager,&pcUserMailId);
			if(pcUserMailId != NULLTAG)
			{
				iRetCode = tiauto_sendEMail(acDataString, pcUserMailId, pcMailBodyFileName);
			}
		}

		tiauto_release_string_array1(mail_addresses.count,mail_addresses.list);
		tiauto_release_string_array1(final_mail_list.count,final_mail_list.list);
		tiauto_clearErrorMsgStack(pstCurrErrMsg);
		remove(pcMailBodyFileName );

		iRetCode = 0;
	}

	SAFE_MEM_free(pcItemId);
	SAFE_MEM_free(pcRevDesc);
	SAFE_MEM_free(ptNewAssembly);
	SAFE_MEM_free(ptOldAssembly);
	SAFE_MEM_free(ptCompMRA);	
	SAFE_MEM_free(pcProgMgrName);

	return iRetCode;
}
