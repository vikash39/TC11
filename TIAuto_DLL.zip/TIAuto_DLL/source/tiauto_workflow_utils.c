/*******************************************************************************
FILE        :   tiauto_workflow_utils.c

REVISION HISTORY :

Date              Revision        Who                    Description
Apr 22, 2009      1.7         Dipak Naik				 Initial Creation.
Jan, 25,2010      1.3         Nivedita Kamath            Modified code to add check for obsolete child item 
                                                         revisions in assembly.
Jun, 18,2019      1.9         Trisha Saha                Modified code to add check for solution items are of same state as 
                                                         target status
*******************************************************************************/

/* includes */

#include <tiauto_workflow_utils.h>


//If the part in the change folders is not a assembly part, but just component part -
//then this function is used for validating component part progression check.
//This validates progression of current revision status w.r.t target release status
//of change process. 
extern int check_for_item_rev_progression(	tag_t						_tItem,
											STATUS_Struct_t				_StatusProgression,
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											int							_iPopulateErrMsgInStack,//0 in case of the stacked cr rule handler, 1 for others 
											int							*iError_, 
											TIA_ErrorMessage			**errMsgStack_ )

{
    int     iRetCode = ITK_ok;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    *szItemRevId = NULL;
	
	char szErrorString[TIAUTO_error_message_len+1]="";
	*iError_ = 0;
    iRetCode = tiauto_get_release_status( _tItem, szReleaseStatus );

	if ( iRetCode == ITK_ok )
	{
        iRetCode = WSOM_ask_id_string ( _tItem, &szItemRevId );
	}

    // If component part rev is lesser or same as the Changege Process Target Release status OR 
    if ( (iRetCode == ITK_ok) &&
		 (tiauto_status_progression_index (szReleaseStatus, _StatusProgression) >  _TargetReleaseStatus.iLevel) )
    {
		// Item revision is at invalid status
		*iError_ = TIAUTO_PARTREV_INVALID_STATUS;
		if (_iPopulateErrMsgInStack == 1)
		{

			TI_sprintf(szErrorString, "%s %s \"%s\"%s\n",szItemRevId, TIAUTO_PARTREV_INVALID_STATUS_TEXT1,
									_TargetReleaseStatus.szTargetReleaseStatus ,TIAUTO_PARTREV_INVALID_STATUS_TEXT2 );
			tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_INVALID_STATUS, szErrorString);
		}
                        
    }
	//start of 15.02 P-check
	else if ( (iRetCode == ITK_ok) &&
		 (tiauto_status_progression_index (szReleaseStatus, _StatusProgression) ==  _TargetReleaseStatus.iLevel) )
    {
		// Item revision is at invalid status
		*iError_ = TIAUTO_PARTREV_EQUAL_STATUS;
		if (_iPopulateErrMsgInStack == 1)
		{

			TI_sprintf(szErrorString, "%s %s \"%s\"%s\n",szItemRevId, TIAUTO_PARTREV_EQUAL_STATUS_TEXT1,
									_TargetReleaseStatus.szTargetReleaseStatus ,TIAUTO_PARTREV_EQUAL_STATUS_TEXT2 );
			tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_EQUAL_STATUS, szErrorString);
		}
                        
    }
	//end of 15.02 P-check
	SAFE_MEM_free(szItemRevId);
    return  iRetCode;
}


//validates the existing status of each and every item revision under change folders
//for backwards status progression, In this function we will return either 
//user defined error code TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR
//or teamcenter standard errorCode, based on this errorCode we will frame the error message in the 
//calling function

//IMP In the caling function we will check if the affected item of change is of class ItemRevision
//Then only we will call this function, so no need to perform that check here
extern int check_for_backward_progression ( tag_t						_tItemRev,
										    tag_t						*_ptAffectedItems,
											int							_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression,
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											int							_iPopulateErrMsgInStack,//0 in case of the stacked cr rule handler, 1 for others
											int							*iError_,  
											TIA_ErrorMessage			**errMsgStack_ )
{    
    int iRetCode = 0;
    int iRevCount = 0;
	int indx = 0;

    tag_t *ptItemRevList = NULL;
    tag_t tItem = NULLTAG;

    char *szItemRevInChangeId = NULL; 
	char *szItemRevId = NULL;
    char szReleaseStatusName[WSO_name_size_c+1]="";
	char szErrorString[2048]="";
	char szItemRevIdTemp[TIAUTO_error_message_len+1] = "";
	
	TIA_ErrorItems  *sBOMItemRevs = NULL;

	*iError_ = 0;

	TI_DEBUG_PRINT1("%s\n", "Enter -> check_for_item_rev_backward_progression");

	//WSOM_ask_id_string returns the string "Item/Rev" format i. e "AR001/AA"
    iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
    if(iRetCode == ITK_ok)
	{
        iRetCode = ITEM_ask_item_of_rev(_tItemRev, &tItem);
	}

    if(iRetCode == ITK_ok)
	{
        iRetCode = ITEM_list_all_revs(tItem, &iRevCount, &ptItemRevList);
	}

	if(DEBUG_PRINT) 
	{
		printf("\n Item in Change Rev is : [%s]", szItemRevInChangeId);
	}

	//Here is an Use Case. 001/AA - no status, 001/AB - Prod Released, 001/AC - Prod Launched,
	//001/AA in in Change folder, target status is Pre-Production
	//Do we need to give the error message about AB, AC are in greater status than that of AA,
	//But I guess we can break when we find the 1st error, i. e. AB, the current code does that
    for (indx = 0; indx < iRevCount && (iRetCode == ITK_ok) && (iRevCount >1); indx++)
    {
        iRetCode = WSOM_ask_id_string(ptItemRevList[indx], &szItemRevId);
        if(iRetCode == ITK_ok)
        {
            TI_DEBUG_PRINT1("Item Rev : %s\n", szItemRevId);

			//Compare the release staus of the itemrev in EC with the higher revs of the item
			//i.e if itemrev 001/AD is in Change then compare the release status of itemrev 001/AD
			//with AF, AG and so on. no need to check w.r.t AA, AB, AC and AD
            if(tc_strcasecmp(szItemRevId, szItemRevInChangeId) > 0)
            {
                iRetCode =  tiauto_get_release_status(ptItemRevList[indx], szReleaseStatusName);
				if( iRetCode == ITK_ok )
				{
					//ignore this higher revision having "Cad Release Only" status; valid status
					if( tc_strcasecmp(  szReleaseStatusName, CRO ) == 0 )
					{
						continue; 
					}
					else if(tiauto_status_progression_index (szReleaseStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel)
					{						
						//if _iPopulateErrMsgInStack == 1 then populate the errmsg to stack
						if (_iPopulateErrMsgInStack == 1)
						{
							//I want the TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR message to be 
							//printed first, because of the insert into stack logic, I'm insurting it later
							tc_strcpy(szItemRevIdTemp,"");
							//to find where this error item rev is used in the BOM
							iRetCode = Where_used_in_BOM(_tItemRev,_ptAffectedItems, _iNumAffectedItems,szItemRevIdTemp,&sBOMItemRevs);
							while(sBOMItemRevs != NULL)
							{
								if(tc_strcmp(szItemRevIdTemp,"") != 0)
									tc_strcat(szItemRevIdTemp,", ");
								tc_strcat(szItemRevIdTemp,sBOMItemRevs->szErrorItems);
								sBOMItemRevs = sBOMItemRevs->next;
							}
							if(!tc_strcmp(szItemRevIdTemp,""))
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s",
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);							
								TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId, 
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
													szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
													_TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
															szErrorString);
							}
							else
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s(%s)",
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6,szItemRevIdTemp);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);							
								TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId, 
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
													szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
													_TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
															szErrorString);
							}

							/*TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId, 
								                   TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
												   szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
												   _TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
														szErrorString);

							TI_sprintf(szErrorString, "%s %s %s %s %s",
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
												   TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6);
							tiauto_writeErrorMsgToStack(errMsgStack_, 
								     TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);*/
							
						}
                        *iError_ = TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR;
						break;
					}
				}
			}
        }
        SAFE_MEM_free (szItemRevId);
		tc_strcpy(szReleaseStatusName, "");
    }

	SAFE_MEM_free (szItemRevInChangeId);
    SAFE_MEM_free (ptItemRevList);

	TI_DEBUG_PRINT1("%s\n", "Exit -> check_for_item_rev_backward_progression");

    return iRetCode;
}


//If the part is an assembly part, then this function validates the present statuses of
//each and every component part of the assembly (same rev progression w.r.t target release
//status of change process. In the present implementation, there is only ONE BOM and it should
//be PRECISE. So we are ignoring any NON-PRECISE BOMs and more than one BOMs 
extern int check_for_assembly_progression(	tag_t						_tItemRev, 
											tag_t						*_ptAffectedItems,
											int							_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression, 
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											char						*pcEndOfWarningMsg,
											int							_iPopulateWarningMsgInStack,
											int							_iPopulateErrMsgInStack,//0 in case of the stacked cr rule handler, 1 for others
											int							*iError_,
											TIA_ErrorMessage			**warningMsgStack_,
											TIA_ErrorMessage			**errMsgStack_) 
{
    int iRetCode = 0;	
    int iCount = 0;
    int iItemRevBvrCount = 0;
    int iNumOccs = 0;
	int iFound = 0;

    tag_t   *ptItemRevBvrs = NULL;
    
    tag_t   *ptOccs = NULL;
    tag_t   tChildItem = NULLTAG;
	tag_t	tChildBomView = NULLTAG;
	
    char szChildRelStatus[WSO_name_size_c+1] = "";
	char *szStackedCRTargetStatusName = NULL;
	char *szStackedCRName = NULL;
	char *szChildItemRev = NULL;
	char *szItemRevInChangeId = NULL;
	char szErrorString[TIAUTO_error_message_len+1]="";
    logical lIsPrecise = false;
	logical lIsOEM = false;

	*iError_ = 0;

	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
	if ( iRetCode == ITK_ok)
		iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);
    if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
    {
        //As per existing implementation, there is only one BVR in the system, So always take the 1st one
        iRetCode = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
		if ( (iRetCode == ITK_ok) && (lIsPrecise == false) )
		{
			*iError_ = TIAUTO_IMPRECISE_BVR_FOUND;

			//If _iPopulateErrMsgInStack == 1, then populate error message
			if(_iPopulateErrMsgInStack == 1)
			{
				TI_sprintf(szErrorString, "%s %s", szItemRevInChangeId, TIAUTO_IMPRECISE_BVR_FOUND_TEXT);
				tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_IMPRECISE_BVR_FOUND, szErrorString);				
			}
		}
	}
    
	//If the item doesn't have a precise BOM, we need not proceed further
	if ( (iRetCode == ITK_ok) && (*iError_ == 0) && iItemRevBvrCount > 0 )
    {
        iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
	
		for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
        {
			tChildItem = NULLTAG;
            tChildBomView = NULLTAG;
            tc_strcpy ( szChildRelStatus, "" );
			 szChildItemRev = NULL;
			iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],
                                               &tChildItem, &tChildBomView);							
		    if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				iRetCode = tiauto_get_release_status(tChildItem, szChildRelStatus);
			}
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				iRetCode = WSOM_ask_id_string( tChildItem, &szChildItemRev);
			}
			if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
			{
				iRetCode = tiauto_check_if_itemType_isOEM(tChildItem, &lIsOEM);	
                if ( iRetCode == ITK_ok )
                {
                    TI_DEBUG_PRINT1("Child Item Status Type : %s\n", szChildRelStatus);
					//1.If the child component is OEM then it has to be in "Cad Release Only" status
					//So whenever we find the above condition, it will be considered as an ERROR, 
					//no matter stacked CR exists or not, so we will not care about the flag
					if( lIsOEM == true )
					{
						if(tc_strcasecmp(szChildRelStatus, CRO)!= 0)
						{
							*iError_ = TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",
										TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1, szChildItemRev,
										TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
										TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR, szErrorString);				
							}
						}
					}
					//check if child item revisions have obsolete status.
					else if(!tc_strcmp(szChildRelStatus,OBSOLETE))
					{
						*iError_ = TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR;
						if(_iPopulateErrMsgInStack == 1)
						{
							TI_sprintf(szErrorString,"%s \"%s\" %s \"%s\" %s",
							TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
							TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
							TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2);
                            tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
						}
						
					}
					//2.Verifying whether child component rev is at SAME or HIGHER status than 
					//target release status of Change process. 
					//If yes, accept the child component and continue to verify another child rev.
					else if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
					{
						//If not as above mentioned, verify if the child component rev is part of 
						//Affected OR Solution Items folders of Change Process. 
						//If yes, accept and continue to verify another child rev.
						IsTagExistsInArray( tChildItem, _ptAffectedItems, _iNumAffectedItems, &iFound );
						if( iFound == 0)
						{
							if ( _iPopulateWarningMsgInStack ==1 )
							{								
								//Check if any stacked CR exists to take care of this error, 
								//add them to warnings
								
								iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tChildItem, 
									  _StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);

								if( (szStackedCRTargetStatusName != NULL) && 
									(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
								{
									//Populate the WARNING MESSAGE stack 
									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1, 
												szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,szStackedCRName,
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,szStackedCRName,
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,szStackedCRTargetStatusName,
												TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
									tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
								}
								else
								{
									*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and 
									//will not wait in the rule handlers, even if some of the child may be 
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1, 
												szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
									}
								}

								//Clean up the two variables
								SAFE_MEM_free( szStackedCRTargetStatusName );
								SAFE_MEM_free( szStackedCRName );
							}
							else 
							{
								*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

								//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
								//because, in case of error we will get out of this function and 
								//will not wait in the rule handlers, even if some of the child may be 
								//in stacked CR
								if ( _iPopulateErrMsgInStack == 1 )
								{
									//Populate the ERROR MESSAGE stack
									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1, 
												szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
								}
							}
							
						}
					}
                }				
			}

			//Break if _iPopulateErrMsgInStack == 0 and *iError_ != 0
			//This will be for the Stacked CR rule handler
			//if the assembly progression error can n't be taken care of by Stacked CR then no need to wait 
			//for the stacked CR as it will be reported in the next Progression action handler and 
			//either the task will be demoted to 2_30 or the workflow will be rejected
			if ( (_iPopulateErrMsgInStack == 0) && (*iError_ != 0) )
			{
				break;
			}
        }        
    }
	SAFE_MEM_free(szChildItemRev);
    SAFE_MEM_free (ptItemRevBvrs);    
    SAFE_MEM_free (ptOccs);
	SAFE_MEM_free(szItemRevInChangeId);
    return iRetCode;
}


//The output szGenItemDisplayName_ will be used in displaying the error message, if any
extern int check_for_generic_progression(	tag_t					_tItemRev, 
											tag_t					*_ptAffectedItems,
											int						_iNumAffectedItems,
											STATUS_Struct_t			_StatusProgression, 
											TARGET_RELEASE_Struct_t _TargetReleaseStatus,
											char					*pcEndOfWarningMsg,
											int						_iPopulateWarningMsgInStack,
											int						_iPopulateErrMsgInStack,
											int						*iError_,
											TIA_ErrorMessage		**warningMsgStack_,
											TIA_ErrorMessage		**errMsgStack_ ) 
{
	int iRetCode = ITK_ok;
	int iFound = 0;

	logical     lIsProE = false;

	tag_t		tGenericItemRevTag = NULLTAG;

	char szGenericRelStatusName[WSO_name_size_c+1]="";
	char szGenItemDisplayName[80] = "";
	char *szItemRevInChangeId = NULL;
	char *szStackedCRName = NULL;
	char *pszActualGenericName = NULL;
	char *szStackedCRTargetStatusName = NULL;
	char szErrorString[TIAUTO_error_message_len+1]="";
	char *pcValue = NULL;

	*iError_ = 0;
	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
	// check if pro/E item	isProEType
	// if instance get generic item rev
	// get status of generic item rev
	// validate status of generic item rev with targetReleaseStatus
	if (iRetCode == ITK_ok)
		iRetCode = tiauto_checkIf_affected_isA_proEInstance_getGenericPart( _tItemRev, 
		                   &lIsProE, &tGenericItemRevTag, szGenItemDisplayName );
	if( iRetCode == ITK_ok )
	{
		pcValue = malloc(sizeof(szGenItemDisplayName));
		tc_strcpy(pcValue,szGenItemDisplayName);
		pcValue= tc_strtok ( pcValue , "-");
	}
	if ( (iRetCode == ITK_ok) && (lIsProE == true) && (tGenericItemRevTag != NULLTAG) )
	{
		iRetCode = tiauto_get_release_status(tGenericItemRevTag, szGenericRelStatusName);

		//If the generic is equal to or above the target release status
		if ( (iRetCode == ITK_ok) &&
			 (tiauto_status_progression_index (szGenericRelStatusName, _StatusProgression) < _TargetReleaseStatus.iLevel))
		{
			//Check if the generic is one of the affected items in the EC
			IsTagExistsInArray( tGenericItemRevTag, _ptAffectedItems, _iNumAffectedItems, &iFound );
			if( iFound == 0)
			{
				iRetCode = WSOM_ask_id_string(tGenericItemRevTag, &pszActualGenericName);
				if(iRetCode == ITK_ok)
				{
					if ( _iPopulateWarningMsgInStack ==1 )
					{
						//Check if any stacked CR exists to take care of this error, 
						//add them to warnings					
						iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tGenericItemRevTag, 
								_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);

						if( (szStackedCRTargetStatusName != NULL) && 
							(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
						{
							//Populate the WARNING MESSAGE stack
							if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, pszActualGenericName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId, 
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
								tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							}
							else
							{
								TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualGenericName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId, 
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
												TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
								tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							}
							
						}
						else
						{
							*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;
							
							//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
							//because, in case of error we will get out of this function and 
							//will not wait in the rule handlers, even if some of the child may be 
							//in stacked CR
							if ( _iPopulateErrMsgInStack == 1 )
							{
								//Populate the ERROR MESSAGE stack
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId, 
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId, 
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
													TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
							}
						}
						//Clean up the two variables
						SAFE_MEM_free( szStackedCRTargetStatusName );
						SAFE_MEM_free( szStackedCRName );
					}
					else 
					{
						*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;

						//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
						//because, in case of error we will get out of this function and 
						//will not wait in the rule handlers, even if some of the child may be 
						//in stacked CR
						if ( _iPopulateErrMsgInStack == 1 )
						{
							//Populate the ERROR MESSAGE stack
							if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId, 
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							}
							else
							{
								TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId, 
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
												TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							}
						}
					}
				}
			}
		}
	}
	SAFE_MEM_free(szItemRevInChangeId);
	SAFE_MEM_free(pszActualGenericName);
	
	return iRetCode;
}
																		
// This function writes parts status progression failure messages to
// Audit file of workflow process.
extern void writeErrorsMsgToAuditFile(tag_t tMsgTask, TIA_ErrorMessage *backwordProgErrMsgStack,
									  TIA_ErrorMessage *itemRevProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgErrMsgStack,
									  TIA_ErrorMessage *genericProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgWarningMsgStack,
									  TIA_ErrorMessage *genericProgWarningMsgStack)
{
	tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
    IMF_file_t  tFileDescriptor = NULL;
	
    int         iRetCode = 0;	
    
	iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);
	if (iRetCode == ITK_ok)
	{
		printf( " \n********** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        TC_write_syslog  ( "Status Progression Failure Error(s): \n");
        iRetCode = IMF_write_file_line(tFileDescriptor, "\n*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n");
        if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
			(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL) )
		{
			iRetCode = IMF_write_file_line(tFileDescriptor, "****************************ERROR**********************************\n");
			if(backwordProgErrMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Backwards Progression**********************************\n");
				while(backwordProgErrMsgStack != NULL)
				{
					printf( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, backwordProgErrMsgStack->errMsg);
					backwordProgErrMsgStack = backwordProgErrMsgStack->next;
				}
			}
			if(itemRevProgErrMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Item Revision Progression**********************************\n");
				while(itemRevProgErrMsgStack != NULL)
				{
					printf( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, itemRevProgErrMsgStack->errMsg);
					itemRevProgErrMsgStack = itemRevProgErrMsgStack->next;
				}
			}
			if(assemblyProgErrMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Assembly Progression**********************************\n");
				while(assemblyProgErrMsgStack != NULL)
				{
					printf( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, assemblyProgErrMsgStack->errMsg);
					assemblyProgErrMsgStack = assemblyProgErrMsgStack->next;
				}
			}
			if(genericProgErrMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Generic Progression**********************************\n");
				while(genericProgErrMsgStack != NULL)
				{
					printf( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, genericProgErrMsgStack->errMsg);
					genericProgErrMsgStack = genericProgErrMsgStack->next;
				}
			}
		}
		if ( (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
		{
			iRetCode = IMF_write_file_line(tFileDescriptor, "****************************WARNING**********************************\n");
			if(assemblyProgWarningMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Assembly Progression**********************************\n");
				while(assemblyProgWarningMsgStack != NULL)
				{
					printf( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, assemblyProgWarningMsgStack->errMsg);
					assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
				}
			}
			if(genericProgWarningMsgStack != NULL)
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Generic Progression**********************************\n");
				while(genericProgWarningMsgStack != NULL)
				{
					printf( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
					TC_write_syslog( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
					iRetCode = IMF_write_file_line(tFileDescriptor, genericProgWarningMsgStack->errMsg);
					genericProgWarningMsgStack = genericProgWarningMsgStack->next;
				}
			}

		}

		printf( " \n********** END OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** END OF STATUS PROGRESSION FAILURE ERROR MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n\n");   
	}
	if (iRetCode == ITK_ok)
        iRetCode = IMF_close_file(tFileDescriptor);

    EMH_clear_errors();
}


extern void IsTagExistsInArray( tag_t tInput, tag_t* ptArray, int iNum, int *iFound )
{
    int inx = 0;

	TI_DEBUG_PRINT1( "%s\n", "Enter - > IsTagExistsInArray" );

    *iFound = 0;

    if( iNum == 0 || ptArray == NULL )
    {
        return;
    }

    for( inx = 0; inx < iNum; inx++ )
    {
        if( ptArray[inx] == tInput )
        {
            *iFound = 1;
            break;
        }
    }
     
    TI_DEBUG_PRINT1( "%s\n", "Exit -> IsTagExistsInArray" );  
}

extern void free_TIA_ErrorMessage_Stack( TIA_ErrorMessage *_errMsgStack )
{
	if (_errMsgStack != NULL)
	{
        TIA_ErrorMessage *tempErrMsg = NULL;		
		while( _errMsgStack )
		{ 
			tempErrMsg = _errMsgStack;
			_errMsgStack = _errMsgStack->next;
			free( tempErrMsg );
			tempErrMsg = NULL;
		}
        _errMsgStack = NULL;
	}
}

//to find out the list of the parent item revs present in the Affected & Solution item folder 
//where the error item revision is used
int Where_used_in_BOM(	tag_t			tErrorItem,
						tag_t			*_ptAffectedItems,
						int				_iNumAffectedItems,
						char			*szItemRevs,
						TIA_ErrorItems  **sBOMItemRevs)
{
	int		iRetCode				= 0;	
    int		iCount					= 0;
	int		iFound					= 0; 
	int		iParents				= 0;
	int		*piLevels				= 0;  
	tag_t	*ptParents				= NULL;  
	char	*szItemRevInChangeId	= NULL;
	char szItemRevIdTemp[TIAUTO_error_message_len+1] = "";
	int		iPTempParents = 0;
	int		*piPTempLevels = NULL;
	tag_t	*ptPTempParents = NULL;
	
	
	tc_strcpy(szItemRevIdTemp,szItemRevs);
	//get all the parent item revisions
	iRetCode = PS_where_used_precise (tErrorItem,1,&iParents,&piLevels,&ptParents);
	for(iCount =0;iCount<iParents;iCount++)
	{
		iFound = 0;
		//check whether the parent item rev is present in the Affected & Solution item folder
		IsTagExistsInArray( ptParents[iCount], _ptAffectedItems, _iNumAffectedItems, &iFound );
		//get the parent item rev id
		iRetCode = WSOM_ask_id_string( ptParents[iCount], &szItemRevInChangeId);
		if((tc_strcmp(szItemRevs,"")==0 )&& (tc_strcmp(szItemRevIdTemp,"")!= 0) )
			tc_strcpy(szItemRevs,szItemRevIdTemp);	
		if(tc_strcmp(szItemRevs,"")!=0)
		{
			tc_strcat(szItemRevs,"-->");
		}
		tc_strcat(szItemRevs,szItemRevInChangeId);

		if(iFound == 0)
		{
			//if the parent item rev not found in the Affected & Solution item folder
			iRetCode = Where_used_in_BOM(ptParents[iCount],_ptAffectedItems, _iNumAffectedItems,szItemRevs,sBOMItemRevs);
		}
		else if(iFound == 1)
		{
			iPTempParents = 0;
			piPTempLevels = NULL;
			ptPTempParents = NULL;
			
			//if the parent item rev found in the Affected & Solution item folder, then
			//store it in the stack
			tiauto_writeErrorItemsToStack(sBOMItemRevs,szItemRevs);
			iRetCode = PS_where_used_precise (tErrorItem,1,&iPTempParents,&piPTempLevels,&ptPTempParents);
			if(iPTempParents > 1)
			{
				tc_strcpy(szItemRevs,szItemRevIdTemp);
				SAFE_MEM_free(piPTempLevels);
				SAFE_MEM_free(ptPTempParents);
				continue;
			}
			SAFE_MEM_free(piPTempLevels);
			SAFE_MEM_free(ptPTempParents);
		}
		tc_strcpy(szItemRevs,"");
		
	}    
	
	SAFE_MEM_free(piLevels);
    SAFE_MEM_free (ptParents); 
	SAFE_MEM_free(szItemRevInChangeId);

    return iRetCode;	
}
