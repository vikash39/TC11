
/************************************************************************************************************************************
FILE        :   tiauto_rh_verify_status_progression_quick.c
Details     :   This handler perform offline progression check when a workflow
                Quick Progression Check is ini-tiated on a 
                folder containing items . This rule handler will load itemrev/backward
				/assembly/generic progression errors in the error store and display it to
				the user.

REVISION HISTORY :
------------------------------------------------------------------------------------------------------------------------------------
Date              Revision        Who						Description
------------------------------------------------------------------------------------------------------------------------------------
Oct  12, 2009     1.0			  Dipak Naik				Initial Creation.
Oct	 22, 2009	  1.1			  Dipak Naik				Added the code for sending the mail to the owner if there
															is no progression failure.
Dec	 16, 2009	  1.2			  Dipak Naik				Added the code for handling the checked out and romote objects
															and also to error out if the item revision is in target of other process.
Jan	 18, 2010	  1.3			  Dipak Naik				commented the code for checking whether the item revision 
															is in target of other process
Apr	 01, 2010	  1.4			  Dipak Naik				Modified the code so that the workflow initiator will get an email notification
															in case of progression failure also. If the dataset is already present and the
															initiator doest not have the write access on it then appropriate error message
															will be thrown along with the progression result.
July 13, 2010     1.5             Nivedita                  Modified the code to proceed with the progression check even when there
                                                            remote or checked out object.(7.02 release)
Jul 14, 2010	  1.5			  Dipak Naik			    Modified the code to print the checked-out user name and
												            the date on which the object is checked out(7.02 release)
Jan 03, 2011	  1.5			  Dipak Naik				Modified the code to read the target status from PMR form class and
															pointed to the new progression common methods in progression_utils.c. 
Jan 05, 2011	  1.5			  Dipak Naik				Merged the code for ER6075(7.02 release)
Feb 11, 2011	  1.6			  Rajesh N					Modified the code for ER6299
May 03, 2012	  1.7			  Manik Vij					Modiifed the code to validate the AltRep and TI_Document Revisions to have Item
															revisions under the Related Revision Folder.
Jun 05, 2012	  1.8			  Dipak Naik				Added the enhancemnets as per the ER#6715
Jun 21, 2012	  1.9			  Dipak Naik				Added the enhancement as per the ER#6731
Sept03, 2012	  1.9			  Manik Vij					Modify the code to add the functionality to check the mandatory attributes.
Feb 20, 2014	  2.0			  Shruti					Modified the code as per ER#7468
Apr 24, 2014	  2.1			  Shruti					Modified the code as per ER#7474
Oct 26, 2016	  2.2			  Kantesh					Modified the code for ER#8992
Apr 19, 2018	  2.3			  Kantesh					Modified the code for ER#9227
May 8 ,2018       2.4             Jugunu                    Commented Custom error message and uncommented EMH_Store_error statements.
Jun 18,2019       2.5             Trisha Saha               added error message for p-check
************************************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <tiauto_progression_check_utils.h>
#include <time.h>
#include <res/res_itk.h>

static int executeProgressionCheckOnFolder(tag_t tTask, tag_t tFolder,EPM_decision_t *decision );
int CreateDataset (	char        *pcDatasetName,
                    tag_t       tDatasetType,
                    char        *pcDatasetFormat,
                    char        *pcDescription,
                    tag_t       tDefaultTool,
                    tag_t       *tDatasetTag	);
int SaveObject (tag_t     objectTag);
int check_remote_and_checked_out_objects(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **pstCurrErrMsg);
//int check_attached_to_other_process(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **pstCurrErrMsg);
int Check_status_of_ITRs(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **currErrMsg);
static int validateRelatedRevisions(int iNumAffected, tag_t* ptAffectedItems,TIA_ErrorMessage **relatedRevisionErrMsg);
int remove_data_from_folder(tag_t tFolder,char *folderName);
int remove_duplicate_itemrevisions(tag_t tMissingFolder);
/*==================================================================
*    Implementation of Action Handler -  TIAUTO_AH_verify_status_progression_quick
====================================================================*/
EPM_decision_t TIAUTO_RH_verify_status_progression_quick(EPM_rule_message_t msg )
{
    int iRetCode = ITK_ok;
	int iNumArgs = 0;	
	tag_t tFolder = NULLTAG;
	char *szErrMsg = NULL;	
	EPM_decision_t decision = EPM_go;
	
	iNumArgs = TC_number_of_arguments(msg.arguments);

	if(iNumArgs > 0)
	{
		iRetCode = EPM_wrong_number_of_arguments; 
	}	
	if(iRetCode == ITK_ok)
	{
		iRetCode = tiauto_get_target_folder (msg.task, &tFolder);
	}
	if ( (iRetCode == ITK_ok) && (tFolder != NULLTAG) )
	{
		//Call the static function to execute the handler to do the Progression Check
		iRetCode = executeProgressionCheckOnFolder(msg.task,tFolder, &decision);
	}

	/*to pop up message box. Commented as it not working on 4T.*/
	/*if(iRetCode == ITK_ok)
	{
		iRetCode = EMH_clear_errors();
		MessageBox(0,"Detailed report is attached under the folder as a text dataset with name \"Progression_check_report\". Please refresh the folder and it's sub-folders(if present) to see the latest progression result.", "Information", 1);
	}*/

	if ( (iRetCode != ITK_ok ) && (iRetCode != TIAUTO_TARGETSTATUS_FORM_NOT_FOUND) && 
									(iRetCode != TIAUTO_TARGETSTATUS_FORM_NO_TARGET_REL_STATUS) )
	{
		EMH_ask_error_text (iRetCode, &szErrMsg);
		
		TC_write_syslog(szErrMsg);
		
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg) ;
		
		SAFE_MEM_free (szErrMsg);		
	}

	return decision;
}
	
int executeProgressionCheckOnFolder(tag_t tTask, tag_t tFolder,EPM_decision_t *decision )
{
    int iRetCode					= ITK_ok;
	int iFileOpenErrCode            = 0;
    int indx						= 0;
	int	ix							= 0;
	int iNumAffected				= 0;
	int iRefCount					= 0;
	int iToolFormatCount			= 0;
	int iMissingFolderSize			= 0;
	int iRemovalFolderSize			= 0;
	int iDrawingFolderSize			= 0;
	int iError						= 0;
	int	iPopulateErrMsgInStack		= 1;			// for this handler, we need the error message. 
	int	iPopulateWarningMsgInStack	= 1;
	int	iTotal						= 0;
	// for this handler, we wont need the warning message.
													// 0 -> not required
													// 1 -> required
	
	tag_t *ptAffectedItems			= NULL;
	tag_t *ptFolderReferences		= NULL;
	tag_t tUser						= NULLTAG;
	tag_t tFile						= NULLTAG;
	tag_t tDatasetType				= NULLTAG;
	tag_t tDefaultTool				= NULLTAG;
	tag_t tDatasetTag				= NULLTAG;
	tag_t tOwningUser				= NULLTAG;
	tag_t tMissingFolder			= NULLTAG;
	tag_t tRemovalFolder			= NULLTAG;
	tag_t tObjectType				= NULLTAG; 
	tag_t tParentType				= NULLTAG;	
	tag_t tDrawingFolder			= NULLTAG;

	logical isItemRevPresent				= false;
	logical isDatasetPresent				= false;
	logical lIsProgressionError				= false;
	logical verdict							= false;
	logical targetFolderAccess				= false;
	logical missingFolderAccess				= false;
	logical removalFolderAccess				= false;
	logical lDatasetAccess					= false;
	logical	drawingFolderAccess				= false;

    char            szErrorString[TIAUTO_error_message_len+1]	= "";
    char			caFolderName[WSO_name_size_c+1]				= "";
	char			acOwningUserName[SA_name_size_c+1]			= "";
	char			*pcEndOfWarningMsg							= ".";
	char			acParentType[TCTYPE_name_size_c+1]			= "";
	char			szChildRelStatus[WSO_name_size_c+1]			= "";
	char		    *pszClassName								= NULL;
   // char			*pcMsgName									= NULL;
    char			*pcComments									= NULL;
	char			*pcEmailId									= NULL;
	char			*pcMailBodyFileName							= NULL;
	char			**pcToolOutputFormats						= NULL;
	char			*pcFolderName								= NULL;
	char			*pcReportFileName							= NULL;
	char			**pcRefNames								= NULL;
	FILE			*fMailBodyFile								= NULL;
	FILE			*fReportFile								= NULL;
	//txt_t			the_text_server								= NULL;
    STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

	TIA_ErrorMessage *backwordProgErrMsgStack				= NULL;
	TIA_ErrorMessage *itemRevProgErrMsgStack				= NULL;
	TIA_ErrorMessage *assemblyProgWarningMsgStack			= NULL;
	TIA_ErrorMessage *assemblyProgErrMsgStack				= NULL;
	TIA_ErrorMessage *genericProgWarningMsgStack			= NULL;
	TIA_ErrorMessage *genericProgErrMsgStack				= NULL;
	TIA_ErrorMessage *remoteANDcheckedoutErrMsgStack		= NULL;
	TIA_ErrorMessage *ITRsStatusErrMsgStack					= NULL;	
	TIA_ErrorMessage *relatedRevisionErrMsg					= NULL;	
	TIA_ErrorMessage *missingAttrErrMsgStack				= NULL;
	TIA_ErrorMessage *relatedRevisionWarningMsg				= NULL;		
	TIA_ErrorMessage *productRevWarningMsgStack				= NULL;	
	TIA_ErrorMessage *productRevErrMsgStack					= NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectErrMsgStack					= NULL;
	TIA_ErrorMessage *masterDrawingReferenceObjectWarnMsgStack					= NULL;

	//TIA_ErrorMessage *attachedtootherprocessErrMsgStack		= NULL;
	TIA_UniqueWSOMObjects *itemRevisionErrorList = NULL;
	TIA_UniqueWSOMObjects *genericMissingItemsList = NULL;
	TIA_UniqueWSOMObjects *backwardMissingItemsList = NULL;
	TIA_UniqueWSOMObjects *backwardErrorList = NULL;
	TIA_UniqueWSOMObjects *assemblyMissingItemsList = NULL;
	TIA_UniqueWSOMObjects *assemblyMissingItemsvalidStatusList = NULL;
	TIA_UniqueWSOMObjects *assemblyErrorItemsList = NULL;
	TIA_UniqueWSOMObjects *productRevMissingAttributesList	= NULL;
	TIA_UniqueWSOMObjects *masterDrawingReferenceObjectErrorList				= NULL;	
	TIA_UniqueWSOMObjects *errorListTemp = NULL;

	FL_sort_criteria_t tSort =  FL_fsc_by_type ;	
	IMF_file_t fileDescriptor;
	errno_t err;
	char dateStr [30];

	struct tm tim;
    time_t now;
	now = time(NULL);
	err = localtime_s(&tim,&now);
	strftime(dateStr,30,"%b %d %Y %H:%M:%S\n",&tim);	
	*decision = EPM_go;
	tiauto_initialize_status_progression_stuct(&StatusProgression);
    iRetCode = tiauto_get_status_progression_array (&StatusProgression);
	
    if (iRetCode == ITK_ok)
    { 		
		iRetCode = tiauto_get_target_release_sts_quick_progression( tFolder,"TI_TargetStatus", TargetReleaseStatus.szTargetReleaseStatus);
		if(iRetCode == ITK_ok)
		{
			TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
			if (TargetReleaseStatus.iLevel == -1)
			{
				TI_sprintf(szErrorString, "%s",TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE_TEXT);
				iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
				EMH_store_error_s1( EMH_severity_error, iRetCode, 
					                szErrorString) ;
				TC_write_syslog(szErrorString);
			}
		}
	}

	if (iRetCode == ITK_ok)
    {
		iRetCode = FL_ask_references(tFolder,tSort,&iNumAffected, &ptAffectedItems);
	}	
	if (iRetCode == ITK_ok)
		iRetCode = WSOM_ask_name  (  tFolder, caFolderName );
	if (iRetCode == ITK_ok)
		iRetCode = AM_check_privilege  ( tFolder,"WRITE", &targetFolderAccess ) ;
	
	for (indx = 0; (indx < iNumAffected) && (iRetCode == ITK_ok); indx++)
	{	
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		
		if((iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "Dataset")!= 0 ) && (tc_strcasecmp (pszClassName , "Folder") != 0 ) 
			&& (tc_strcasecmp (pszClassName , "ItemRevision")!= 0 ))
		{
			tag_t tTargetType = NULLTAG;
			tag_t	tParentType					= NULLTAG;
			TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType));
			if(tTargetType != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));

			if(tParentType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pszClassName));
			}					
			
		}

		if((iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "Dataset")== 0 ))
		{
			char    caObjectType[WSO_name_size_c+1]= "";
			char    caObjectName[WSO_name_size_c+1]= "";
			iRetCode = WSOM_ask_object_type(ptAffectedItems[indx], caObjectType);
			if((iRetCode == ITK_ok) && (tc_strcasecmp (caObjectType , "Text")== 0 ))
			{
				iRetCode = WSOM_ask_name(ptAffectedItems[indx], caObjectName);
			}
			if((iRetCode == ITK_ok) && (tc_strcasecmp (caObjectName , "Progression_check_report")== 0 ))
			{
				tDatasetTag = ptAffectedItems[indx];
				isDatasetPresent = true;
			}
		}
		else if((iRetCode == ITK_ok)  &&( (tc_strcasecmp (pszClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pszClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
        {			
			isItemRevPresent = true;	
			//Backward progression check 			
			iRetCode = ti_check_for_backward_progression ( ptAffectedItems[indx],ptAffectedItems, iNumAffected, 
													StatusProgression, TargetReleaseStatus, iPopulateErrMsgInStack, 
													&iError, &backwordProgErrMsgStack, 1,&backwardErrorList, 
													&backwardMissingItemsList );

			// item revision progression check
			if ( (iRetCode == ITK_ok))
			{
				iRetCode = ti_check_for_item_revision_progression ( ptAffectedItems[indx], StatusProgression, 
											TargetReleaseStatus, iPopulateErrMsgInStack, &iError, 
											&itemRevProgErrMsgStack, 1, &itemRevisionErrorList );
			}
			// assembly progression check
			if ( (iRetCode == ITK_ok))
			{
				
				iRetCode = ti_check_for_assembly_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															  StatusProgression, TargetReleaseStatus,pcEndOfWarningMsg, 
															  iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															  "Quick Progression Check",-1,&iError, 
															  &assemblyProgWarningMsgStack, &assemblyProgErrMsgStack,1 , &assemblyMissingItemsList);
			}
			// generic progression check
			if ( (iRetCode == ITK_ok) )
			{			
				iRetCode = ti_check_for_generic_progression( ptAffectedItems[indx], ptAffectedItems, iNumAffected,
															StatusProgression, TargetReleaseStatus, pcEndOfWarningMsg,
															iPopulateWarningMsgInStack, iPopulateErrMsgInStack, 
															"Quick Progression Check",&iError, 
															&genericProgWarningMsgStack, &genericProgErrMsgStack, 1, &genericMissingItemsList);		
			}
			if ( (iRetCode == ITK_ok) )
			{
				//check for the TI_Product Revision objects
				iRetCode = ti_Verify_MasterDrawingInfo( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression, TargetReleaseStatus,
													     iPopulateErrMsgInStack,&iError, &productRevWarningMsgStack, 
													     &productRevErrMsgStack, 1,&productRevMissingAttributesList);
			}
			if ( (iRetCode == ITK_ok) )
			{
				//check for the TI_Product Revision Master Drawing Reference linked object status
				iRetCode = ti_Verify_MasterDrawingReferenceLinkedObjectStatus( ptAffectedItems[indx], ptAffectedItems,iNumAffected, StatusProgression, TargetReleaseStatus,
																				iPopulateWarningMsgInStack,iPopulateErrMsgInStack,&iError,
																				&masterDrawingReferenceObjectWarnMsgStack,&masterDrawingReferenceObjectErrMsgStack,pcEndOfWarningMsg,1,
																				&masterDrawingReferenceObjectErrorList);
			}

		}
		else if((iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "Folder")== 0 ))
		{
			iRetCode = AOM_ask_value_string(ptAffectedItems[indx], "object_name", &pcFolderName);
			if(tc_strcmp(pcFolderName, MISSING_ITEMS_FOLDER)==0)
			{
				tMissingFolder = ptAffectedItems[indx];
			}
			else if(tc_strcmp(pcFolderName, DATA_REMOVAL_FOLDER)==0)
			{
				tRemovalFolder = ptAffectedItems[indx];	
			}
			else if( tc_strcmp(pcFolderName, MASTER_DRAWING_FOLDER) == 0)
			{
				tDrawingFolder = ptAffectedItems[indx];	
			}
			SAFE_MEM_free(pcFolderName);
		}
		SAFE_MEM_free(pszClassName);
	}

	//combine masterDrawingReferenceObjectErrorList and productRevMissingAttributesList
	/*if(masterDrawingReferenceObjectErrorList != NULL)
	{
		tiauto_Store_wsom_tags(&productRevMissingAttributesList,&iTotal,masterDrawingReferenceObjectErrorList->tUniqueWSOMObjects);
	}*/

	/*to split assemblyMissingItemsList to invalid status list of items and valid status list of items*/
	while(assemblyMissingItemsList != NULL)
	{
		//insert into the newly created folder
		if(assemblyMissingItemsList->tUniqueWSOMObjects != NULLTAG)
		{
			iRetCode = tiauto_get_release_status(assemblyMissingItemsList->tUniqueWSOMObjects, szChildRelStatus);
			if(((tc_strstr(szChildRelStatus,TECHNOLOGY) != 0) && (tc_strstr(TargetReleaseStatus.szTargetReleaseStatus,TECHNOLOGY) == 0)) || (tc_strcmp(szChildRelStatus,OBSOLETE) == 0))
			{
				tiauto_Store_wsom_tags(&assemblyErrorItemsList,&iTotal,assemblyMissingItemsList->tUniqueWSOMObjects);
			}
			else 
			{
				tiauto_Store_wsom_tags(&assemblyMissingItemsvalidStatusList,&iTotal,assemblyMissingItemsList->tUniqueWSOMObjects);
			}
		}
		errorListTemp = assemblyMissingItemsList;
		assemblyMissingItemsList = assemblyMissingItemsList->next;
		free(errorListTemp);
	}



	if(ITK_ok == iRetCode && targetFolderAccess)
	{
		if(tMissingFolder == NULLTAG && (backwardMissingItemsList != NULL || assemblyMissingItemsvalidStatusList != NULL || genericMissingItemsList || masterDrawingReferenceObjectErrorList != NULL) )
		{	
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = FL_create( MISSING_ITEMS_FOLDER, "Missing Item Revisions that needs to be added to the target folder",&tMissingFolder);				
			iRetCode = FL_insert(tFolder, tMissingFolder, 999);
			iRetCode = SaveObject(tMissingFolder);
			iRetCode = SaveObject(tFolder);
		}
		else if(tMissingFolder != NULLTAG && backwardMissingItemsList == NULL)
		{
			iRetCode = remove_data_from_folder(tMissingFolder, "Backward Progression" );	
		}
		else if(tMissingFolder != NULLTAG && assemblyMissingItemsvalidStatusList == NULL)
		{
			iRetCode = remove_data_from_folder(tMissingFolder, "Assembly Progression");		
		}
		else if(tMissingFolder != NULLTAG && genericMissingItemsList == NULL)
		{	
			iRetCode = remove_data_from_folder(tMissingFolder, "Generic Progression" );
		}
		else if(tMissingFolder != NULLTAG && masterDrawingReferenceObjectErrorList == NULL)
		{	
			iRetCode = remove_data_from_folder(tMissingFolder, "Drawing Progression" );
		}
		if(tRemovalFolder == NULLTAG && (itemRevisionErrorList != NULL || backwardErrorList != NULL || assemblyErrorItemsList != NULL) )	
		{		
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = FL_create( DATA_REMOVAL_FOLDER, "Item Revisions that needs to be removed from the target folder ",&tRemovalFolder);				
			iRetCode = FL_insert(tFolder, tRemovalFolder, 999);
			iRetCode = SaveObject(tRemovalFolder);
			iRetCode = SaveObject(tFolder);
		}
		else if(tRemovalFolder != NULLTAG && itemRevisionErrorList == NULL)
		{
			iRetCode = remove_data_from_folder(tRemovalFolder, "ItemRevision Progression" );	
		}
		else if(tRemovalFolder != NULLTAG && backwardErrorList == NULL)
		{
			iRetCode = remove_data_from_folder(tRemovalFolder, "Backward Progression");		
		}
		else if(tRemovalFolder != NULLTAG && assemblyErrorItemsList == NULL)
		{
			iRetCode = remove_data_from_folder(tRemovalFolder, "Assembly Progression");		
		}
		if(tDrawingFolder == NULLTAG && productRevMissingAttributesList != NULLTAG)	
		{		
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = FL_create( MASTER_DRAWING_FOLDER, "Product Revisions that needs to be updated for master drawing information added to the target folder ",&tDrawingFolder);				
			iRetCode = FL_insert(tFolder, tDrawingFolder, 999);
			iRetCode = SaveObject(tDrawingFolder);
			iRetCode = SaveObject(tFolder);
		}
		else if(tDrawingFolder != NULLTAG && productRevMissingAttributesList == NULL)
		{
			iRetCode = remove_data_from_folder(tDrawingFolder, "" );	
		}
	}
	if(iRetCode == ITK_ok && tMissingFolder != NULLTAG)
		iRetCode = AM_check_privilege  ( tMissingFolder,"WRITE", &missingFolderAccess ) ;
	if(iRetCode == ITK_ok && tRemovalFolder != NULLTAG)
		iRetCode = AM_check_privilege  ( tRemovalFolder,"WRITE", &removalFolderAccess ) ;
	if(iRetCode == ITK_ok && tDrawingFolder != NULLTAG)
		iRetCode = AM_check_privilege  ( tDrawingFolder,"WRITE", &drawingFolderAccess ) ;

	if(iRetCode == ITK_ok && tMissingFolder != NULLTAG && missingFolderAccess)
	{
		iRetCode = copyErrorItemsToFolder(tMissingFolder, "Drawing Progression",  masterDrawingReferenceObjectErrorList );
		iRetCode = copyErrorItemsToFolder(tMissingFolder, "Backward Progression", backwardMissingItemsList );
		iRetCode = copyErrorItemsToFolder(tMissingFolder, "Assembly Progression", assemblyMissingItemsvalidStatusList );				
		iRetCode = copyErrorItemsToFolder(tMissingFolder, "Generic Progression", genericMissingItemsList );
	}

	//remove duplicate Item Revisions
	if(iRetCode == ITK_ok && masterDrawingReferenceObjectErrorList != NULL)
	{
		iRetCode = remove_duplicate_itemrevisions(tMissingFolder);
	}

	if(iRetCode == ITK_ok && tRemovalFolder != NULLTAG && removalFolderAccess)
	{
		iRetCode = copyErrorItemsToFolder(tRemovalFolder, "ItemRevision Progression",itemRevisionErrorList );
		iRetCode = copyErrorItemsToFolder(tRemovalFolder, "Backward Progression", backwardErrorList );
		iRetCode = copyErrorItemsToFolder(tRemovalFolder, "Assembly Progression", assemblyErrorItemsList );
	}	
	if(iRetCode == ITK_ok && productRevMissingAttributesList != NULL && drawingFolderAccess )
	{
		iRetCode = copyErrorItemsToFolder(tDrawingFolder,"", productRevMissingAttributesList );
	}
	if(iRetCode == ITK_ok && tMissingFolder != NULLTAG) 
	{
		iRetCode = FL_ask_size  ( tMissingFolder, &iMissingFolderSize);
		if(0 == iMissingFolderSize && missingFolderAccess)
		{				
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = AOM_delete_from_parent(tMissingFolder, tFolder);
			iRetCode = SaveObject(tFolder);
		}
	}
	if(iRetCode == ITK_ok && tRemovalFolder != NULLTAG)
	{
		iRetCode = FL_ask_size ( tRemovalFolder, &iRemovalFolderSize);
		if(0 == iRemovalFolderSize && removalFolderAccess)
		{				
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = AOM_delete_from_parent(tRemovalFolder, tFolder);
			iRetCode = SaveObject(tFolder);
		}
	}
	if(iRetCode == ITK_ok && tDrawingFolder != NULLTAG)
	{
		//remove the items from the folder for which the attributes are not missing
		//iRetCode = validateErrorItemsInFolder( tDrawingFolder );
		if( iRetCode == ITK_ok )
			iRetCode = FL_ask_size ( tDrawingFolder, &iDrawingFolderSize);
		if(0 == iDrawingFolderSize && drawingFolderAccess)
		{				
			iRetCode = AOM_refresh(tFolder, true);
			iRetCode = AOM_delete_from_parent(tDrawingFolder, tFolder);
			iRetCode = SaveObject(tFolder);
		}
	}
	SAFE_MEM_free(ptFolderReferences);

	//check for remote and checked out objects
	if(iRetCode == ITK_ok && iNumAffected > 0)
	    iRetCode = check_remote_and_checked_out_objects(iNumAffected,ptAffectedItems,&remoteANDcheckedoutErrMsgStack);
	//validate the status of the item revisions present in the folder
	if(iRetCode == ITK_ok && iNumAffected > 0)
		iRetCode = Check_status_of_ITRs(iNumAffected,ptAffectedItems,&ITRsStatusErrMsgStack);
	//check for the related revisions
	if ( (iRetCode == ITK_ok)&& iNumAffected > 0 )
	{
		iRetCode = validateRelatedRevisions(iNumAffected,ptAffectedItems,&relatedRevisionErrMsg);
		//check for the Document Revision
		for( ix = 0; ix < iNumAffected; ix++)
		{	
			/* get the object type */
			iRetCode = TCTYPE_ask_object_type(ptAffectedItems[ix], &tObjectType );
			/* get the parent type tag*/
			if (iRetCode == ITK_ok)
				iRetCode = TCTYPE_ask_parent_type(tObjectType, &tParentType);
			/* get the parent type name*/
			if (iRetCode == ITK_ok)
				iRetCode = TCTYPE_ask_name(tParentType, acParentType);
			if (tc_strcasecmp( acParentType , DOCUMENT_REV)== 0 && (iRetCode == ITK_ok) )
			{
				iRetCode = check_document_related_revision_folder( ptAffectedItems[ix], &relatedRevisionWarningMsg );
			}
		}
	}
	// check if the mandatory attributes of IRM forms are filled or not
	if ( (iRetCode == ITK_ok)&& iNumAffected > 0 )
	{
		iRetCode = Validate_IRM_form_mandatory_Attributes(iNumAffected, ptAffectedItems, &missingAttrErrMsgStack);
	}
	SAFE_MEM_free(ptAffectedItems);
	
	if(iRetCode == ITK_ok)
	{		 
		pcReportFileName = USER_new_file_name("report","TEXT","txt",1);
		iFileOpenErrCode = fopen_s(&fReportFile,pcReportFileName, "w" );

		iRetCode = AM_check_privilege  ( tFolder,"WRITE", &verdict ) ;
		if((iRetCode == ITK_ok) && (verdict == true))
		{			
			fprintf(fReportFile,"\nFolder Name: %s\n\n",caFolderName );
			fprintf(fReportFile,"Target Release Status: %s\n\n",TargetReleaseStatus.szTargetReleaseStatus );			
			fprintf(fReportFile,"Execution date and time: %s\n",dateStr );
			
			iRetCode = AE_find_datasettype ( "Text", &tDatasetType );
			if(iRetCode == ITK_ok && tDatasetType != NULLTAG)
				iRetCode = AE_ask_datasettype_refs (tDatasetType, &iRefCount, &pcRefNames);
			/*  Remove the named ref matching the given dataset format */
			if (iRetCode == ITK_ok && tDatasetTag != NULLTAG)
			{
				//to check the write access on the dataset
				iRetCode = AM_check_privilege(tDatasetTag,"WRITE", &lDatasetAccess); 
				//if the has the write access on the dataset then remove the names reference 
				if((iRetCode == ITK_ok) && (lDatasetAccess == true))
				{
					iRetCode = AOM_refresh (tDatasetTag,true);
					//remove the referenced names to the dataset.
					if(iRetCode == ITK_ok && iRefCount > 0)
						iRetCode = AE_remove_dataset_named_ref (tDatasetTag, pcRefNames[0]);
					if(iRetCode == ITK_ok)
						iRetCode = SaveObject(tDatasetTag);		
				}
			}
			else if(iRetCode == ITK_ok && tDatasetTag == NULLTAG)
			{		
				if((iRetCode == ITK_ok) && (tDatasetType != NULLTAG))
				{
					iRetCode = AE_ask_datasettype_def_tool (tDatasetType,&tDefaultTool);
				}
				if((iRetCode == ITK_ok) && (tDefaultTool != NULLTAG))
				{
					iRetCode = AE_ask_tool_output_formats ( tDefaultTool,&iToolFormatCount,&pcToolOutputFormats );
				}
				if((iRetCode == ITK_ok) && (iToolFormatCount > 0))
				{
					iRetCode = CreateDataset("Progression_check_report",tDatasetType,pcToolOutputFormats[0],NULL,
								tDefaultTool,&tDatasetTag);
				}
				if((iRetCode == ITK_ok) && (tDatasetTag != NULLTAG))
				{
					//if the dataset is not present, then the dataset will be created and the initiator is the
					// owing user of the dataset.
					lDatasetAccess = true;
				}
				for(indx =0; indx < iToolFormatCount ;indx++)
				{
					SAFE_MEM_free(pcToolOutputFormats[indx]);
				}
			}			
		}			
	}
	if (iRetCode == ITK_ok)
	{		
		*decision = EPM_go;

		iRetCode = EPM_ask_responsible_party( tTask,&tUser);
		if(iRetCode == ITK_ok && tUser != NULLTAG)
		{
			iRetCode = EPM_get_user_email_addr  (  tUser,&pcEmailId )  ;
			if(iRetCode == ITK_ok && pcEmailId != NULL)
			{					
				/* Initialize TextServer here */
				//the_text_server = txt_ctor( "iman_text.xml" );
				//pcMsgName = "User_Comments";
				//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
				/* release text server object here...*/
				//txt_destructor(the_text_server);
			
				pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
				iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
				
				if(iRetCode == ITK_ok )
				{
					fprintf(fMailBodyFile,"Target Release Status: %s\n\n",TargetReleaseStatus.szTargetReleaseStatus );
					fprintf(fMailBodyFile,"Folder Name: %s\n\n",caFolderName );
					fprintf(fMailBodyFile,"Execution date and time: %s\n",dateStr );
					if(isItemRevPresent == true )
					{	
						TIA_ErrorMessage *tempErrMsg = NULL;
						//to send mail about the ITRs having invalid status
						if(ITRsStatusErrMsgStack != NULL)
						{
							
							tempErrMsg = ITRsStatusErrMsgStack;
							fprintf(fMailBodyFile,"There are some Item revisions having invalid status which is not allowed in the workflow process, present in the folder \"%s\".",
													caFolderName);
							if(ITRsStatusErrMsgStack != NULL)
							{
								fprintf(fMailBodyFile,"\n********Start of Item Revisions Having Invalid Status ERROR*******\n");
								while(tempErrMsg != NULL)
								{
									fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
									tempErrMsg = tempErrMsg->next;
								}
								fprintf( fMailBodyFile, "\nTo fix the invalid status errors, please set the correct status on mentioned Item revisions or remove them from the folder before initiating the workflow.\n");	
							}
						}
						//to send mail for the remote and checked out error
						if(remoteANDcheckedoutErrMsgStack != NULL)
						{
							
							tempErrMsg = remoteANDcheckedoutErrMsgStack;
							fprintf(fMailBodyFile,"There are some remote and checked out objects present in the folder \"%s\".",
													caFolderName);
							if(remoteANDcheckedoutErrMsgStack != NULL)
							{
								fprintf(fMailBodyFile,"\n********Start of Remote and checked out object ERROR*******\n");
								while(tempErrMsg != NULL)
								{
									fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
									tempErrMsg = tempErrMsg->next;
								}
								fprintf( fMailBodyFile, "\nIf the object is checked out, please check-in the object before initiating the workflow.\nIf the object is a remote object, please fix it before initiating the workflow.\n\n\n");	
							}
						}
						//send mail for Related revision error
						if(relatedRevisionErrMsg != NULL)
						{
							fprintf(fMailBodyFile,"\n*************************Related Revision ERROR*****************************\n");
							tempErrMsg = relatedRevisionErrMsg;
							while(tempErrMsg != NULL)
							{
								fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
								tempErrMsg = tempErrMsg->next;
							}
							fprintf( fMailBodyFile, "\nTo fix Related Revision error problem, Please add at least one item revision to the Related Revisions folder for the above item revisions.\n\n");	
						}
						//send mail for Related revision warning
						if(relatedRevisionWarningMsg != NULL)
						{
							fprintf(fMailBodyFile,"\n*************************Related Revision WARNING*****************************\n");
							tempErrMsg = relatedRevisionWarningMsg;
							while(tempErrMsg != NULL)
							{
								fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
								tempErrMsg = tempErrMsg->next;
							}
							fprintf( fMailBodyFile, "\nTo fix Related Revision warning problem, Please add at least one item revision to the Related Revisions folder for the above document revisions.\n\n");	
						}
						//send mail for missing mandatory attributes error
						if(missingAttrErrMsgStack != NULL)
						{
							fprintf(fMailBodyFile,"\n*************************Mandatory Attributes ERROR*****************************\n");
							tempErrMsg = missingAttrErrMsgStack;
							while(tempErrMsg != NULL)
							{
								fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
								tempErrMsg = tempErrMsg->next;
							}
							fprintf( fMailBodyFile, "\nTo fix Mandatory attributes error, Please fill the above mentioned mandatory attributes of item revision master forms.\n");
						}
						//to send mail for the progression error
						if ( (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) && 
								(genericProgErrMsgStack == NULL) && (assemblyProgErrMsgStack== NULL) && 
								(itemRevProgErrMsgStack == NULL) && (backwordProgErrMsgStack == NULL) && (masterDrawingReferenceObjectErrMsgStack == NULL))
						{	
							fprintf(fMailBodyFile,"There are no progression check failures for the item revisions present in the folder \"%s\".",
													caFolderName);							
							fprintf(fReportFile,"There are no progression check failures for the item revisions present in the folder \"%s\".",
													caFolderName);
						}
						else
						{					
							//if any of the error stack is not empty (null) that means there are some progression failure
							fprintf(fMailBodyFile,"There are progression check failures for the item revisions present in the folder \"%s\".",
													caFolderName);	
														
							if( (genericProgErrMsgStack != NULL) || (assemblyProgErrMsgStack != NULL) || 
								(itemRevProgErrMsgStack != NULL) || (backwordProgErrMsgStack != NULL) ||(masterDrawingReferenceObjectErrMsgStack == NULL))
							{
								fprintf(fMailBodyFile,"\n\n*************************PROGRESSION ERROR MESSAGES*****************************\n");
								tempErrMsg = backwordProgErrMsgStack;
								if(backwordProgErrMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Backward Progression ERROR*********\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
									lIsProgressionError = true;
								}
								tempErrMsg = itemRevProgErrMsgStack;
								if(itemRevProgErrMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of ItemRev Progression ERROR********\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
										
									}
									lIsProgressionError = true;
								}
								tempErrMsg = assemblyProgErrMsgStack;
								if(assemblyProgErrMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Assembly Progression ERROR*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
									lIsProgressionError = true;
								}
								tempErrMsg = genericProgErrMsgStack;
								if(genericProgErrMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Generic Progression ERROR*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
									lIsProgressionError = true;
								}
								tempErrMsg = masterDrawingReferenceObjectErrMsgStack;
								if(masterDrawingReferenceObjectErrMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Master Drawing Reference linked Item Revision status check ERROR*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
									lIsProgressionError = true;
								}
							}
							if((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
							{
								fprintf(fMailBodyFile,"\n\n*************************PROGRESSION WARNING MESSAGES*****************************\n");
								tempErrMsg = assemblyProgWarningMsgStack;
								if(assemblyProgWarningMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Assembly Progression WARNING*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
								}
								tempErrMsg = genericProgWarningMsgStack;
								if(genericProgWarningMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n********Start of Generic Progression WARNING*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
								}
							}
							
							if( productRevWarningMsgStack != NULL )
							{
								tempErrMsg = productRevWarningMsgStack;
								if(productRevWarningMsgStack != NULL)
								{
									fprintf(fMailBodyFile,"\n\n********Start of missing Master Drawing Information WARNING*******\n");
									while(tempErrMsg != NULL)
									{
										fprintf(fMailBodyFile," %s\n", tempErrMsg->errMsg );
										tempErrMsg = tempErrMsg->next;
									}
								}
							}
							if(lDatasetAccess == true)
							{
								//If the user has the wite access on the dataset, then the progression errors will be written to the dataset 
								fprintf(fMailBodyFile,"\n\nDetailed report is attached under the folder \"%s\" as a text dataset with name \"Progression_check_report\". In case you don�t see the dataset, refresh the folder \"%s\".", 
														caFolderName, caFolderName);
							}

						}
					}
					else if(isItemRevPresent == false )
					{
						fprintf(fMailBodyFile,"There are no item revisions in the folder \"%s\".",caFolderName);							
						fprintf(fReportFile,"There are no item revisions in the folder \"%s\".",caFolderName);
					}
					if(fMailBodyFile != NULL )
					{
						fclose(fMailBodyFile);
					}
					TI_sprintf(szErrorString, "Quick Progression Check results");
					if(pcEmailId != NULL)
						iRetCode = tiauto_sendEMail(szErrorString, pcEmailId, pcMailBodyFileName);
				}
			}
		}		
		SAFE_MEM_free(pcComments);
		remove(pcMailBodyFileName);
		SAFE_MEM_free(pcEmailId);	
				
		//to write the ITRs having invalid status error message to the text dataset 			
		if( (iRetCode == ITK_ok) &&(ITRsStatusErrMsgStack != NULL ))
		{		
			TIA_ErrorMessage *tempErrMsg = NULL;
			fprintf(fReportFile,"\n********Item Revisions Having Invalid Status Error*******\n");
				
			if(ITRsStatusErrMsgStack != NULL)
			{					
				tempErrMsg = ITRsStatusErrMsgStack;			
				while(tempErrMsg != NULL)
				{
					fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
					tempErrMsg = tempErrMsg->next;
				}				
				fprintf( fReportFile, "\nTo fix the invalid status errors, please set the correct status on mentioned Item revisions or remove them from the folder before initiating the workflow.\n");	
			}			
		}	
		//to write the checked-out and remote error message to the text dataset 			
		if( (iRetCode == ITK_ok) &&(remoteANDcheckedoutErrMsgStack != NULL ))//	|| (attachedtootherprocessErrMsgStack != NULL)) )
		{		
			TIA_ErrorMessage *tempErrMsg = NULL;
			fprintf(fReportFile,"\n********Remote or Checked Out Object Error*******\n");
				
			if(remoteANDcheckedoutErrMsgStack != NULL)
			{					
				tempErrMsg = remoteANDcheckedoutErrMsgStack;			
				while(tempErrMsg != NULL)
				{
					fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
					tempErrMsg = tempErrMsg->next;
				}				
				fprintf( fReportFile, "\nIf the object is checked out, please check-in the object before initiating the workflow.\nIf the object is a remote object, please fix it before initiating the workflow.\n\n");	
			}			
		}
		//to write the related revision error message to the text dataset
		if ( (iRetCode == ITK_ok) && (relatedRevisionErrMsg != NULL)  )
		{		
			TIA_ErrorMessage *tempErrMsg = NULL;
			fprintf(fReportFile,"\n*************************Related Revision Error*****************************\n");
			tempErrMsg = relatedRevisionErrMsg;
			while(tempErrMsg != NULL)
			{
				fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
				tempErrMsg = tempErrMsg->next;
			}
			fprintf( fReportFile, "\nTo fix Related Revision error problem, Please add at least one item revision to the Related Revisions folder for the above item revisions.\n\n");	
		}
		//to write the related revision warning message to the text dataset
		if ( (iRetCode == ITK_ok) && (relatedRevisionWarningMsg != NULL)  )
		{		
			TIA_ErrorMessage *tempErrMsg = NULL;
			fprintf(fReportFile,"\n*************************Related Revision Warning*****************************\n");
			tempErrMsg = relatedRevisionWarningMsg;
			while(tempErrMsg != NULL)
			{
				fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
				tempErrMsg = tempErrMsg->next;
			}
			fprintf( fReportFile, "\nTo fix Related Revision warning problem, Please add at least one item revision to the Related Revisions folder for the above document revisions.\n\n");	
		}
		//to write the mandatory attributes error message to the text dataset
		if ( (iRetCode == ITK_ok) && (missingAttrErrMsgStack != NULL)  )
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			fprintf(fReportFile,"\n*************************Mandatory Attributes Error*****************************\n");
			tempErrMsg = missingAttrErrMsgStack;
			while(tempErrMsg != NULL)
			{
				fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
				tempErrMsg = tempErrMsg->next;
			}
			fprintf( fReportFile, "\nTo fix Mandatory attributes error, Please fill the above mentioned mandatory attributes of item revision master forms.\n");
		}

		if ( (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) && 
			 (genericProgErrMsgStack == NULL) && (assemblyProgErrMsgStack== NULL) && 
			 (itemRevProgErrMsgStack == NULL) && (backwordProgErrMsgStack == NULL) && productRevWarningMsgStack == NULL && masterDrawingReferenceObjectErrMsgStack == NULL)
		{
			/*if(iRetCode == ITK_ok && isItemRevPresent == true )
			{
				TI_sprintf(szErrorString,"There are no progression check failures for the item revisions present in the folder \"%s\".\n",
										caFolderName);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}
			else if(iRetCode == ITK_ok && isItemRevPresent == false )
			{
				TI_sprintf(szErrorString,"There are no item revisions in the folder \"%s\".",caFolderName);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}*/
		}
		else
		{
			if(iRetCode == ITK_ok)
			{				
				TIA_ErrorMessage *tempErrMsg = NULL;
				if( (genericProgErrMsgStack != NULL) || (assemblyProgErrMsgStack != NULL) || 
					(itemRevProgErrMsgStack != NULL) || (backwordProgErrMsgStack != NULL)  ||
					productRevWarningMsgStack != NULL || masterDrawingReferenceObjectErrMsgStack != NULL )
				{
					fprintf(fReportFile,"\n\n*************************PROGRESSION ERROR MESSAGES*****************************\n");
					tempErrMsg = backwordProgErrMsgStack;
					if(backwordProgErrMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Backward Progression ERROR*********\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						lIsProgressionError = true;
					}
					tempErrMsg = itemRevProgErrMsgStack;
					if(itemRevProgErrMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of ItemRev Progression ERROR********\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						lIsProgressionError = true;
					}
					tempErrMsg = assemblyProgErrMsgStack;
					if(assemblyProgErrMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Assembly Progression ERROR*******\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						lIsProgressionError = true;
					}
					tempErrMsg = genericProgErrMsgStack;
					if(genericProgErrMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Generic Progression ERROR*******\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						lIsProgressionError = true;
					}
					tempErrMsg = masterDrawingReferenceObjectErrMsgStack;
					if(masterDrawingReferenceObjectErrMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Master Drawing Reference linked Item Revision status check ERROR*******\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
						fprintf(fReportFile,"Please add the Master Drawing revision to current change folder or remove it from the Master Drawing refernce.");
						lIsProgressionError = true;
					}
				}
				if((assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
				{
						fprintf(fReportFile,"\n\n*************************PROGRESSION WARNING MESSAGES*****************************\n");
					tempErrMsg = assemblyProgWarningMsgStack;
					if(assemblyProgWarningMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Assembly Progression WARNING*******\n");
						while(tempErrMsg != NULL)
						{
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
					}
					tempErrMsg = genericProgWarningMsgStack;
					if(genericProgWarningMsgStack != NULL)
					{
						fprintf(fReportFile,"\n********Start of Generic Progression WARNING*******\n");
						while(tempErrMsg != NULL)
						{	
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
					}
				}
				if( productRevWarningMsgStack != NULL )
				{
					tempErrMsg = productRevWarningMsgStack;
					if(productRevWarningMsgStack != NULL)
					{
						fprintf(fReportFile,"\n\n********Start of missing Master Drawing Information WARNING*******\n");
						while(tempErrMsg != NULL)
						{	
							fprintf(fReportFile," %s\n", tempErrMsg->errMsg );
							tempErrMsg = tempErrMsg->next;
						}
					}
				}
			}
			
			fprintf(fReportFile,"\n\nPlease refresh the folder \"%s\" and it's sub-folders(if present) to see the latest progression result.\n\n", caFolderName);
			fprintf(fReportFile,"For Assembly Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Assembly Progression\"\n", caFolderName);
			fprintf(fReportFile,"For Generic Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Generic Progression\"\n", caFolderName);
			fprintf(fReportFile,"For Backward Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Backward Progression\"\n", caFolderName);
			fprintf(fReportFile,"For Backward Progression Error Item revisions: check the folder \"%s --> Item Revisions - To be removed --> Backward Progression\"\n", caFolderName);
			fprintf(fReportFile,"For ItemRevision Progression Error Item revisions: check the folder \"%s --> Item Revisions - To be removed --> ItemRevision Progression\"\n", caFolderName);
			fprintf(fReportFile,"For Product Revision missing Master Drawing information: check the folder \"%s --> Item Revisions - Update Master Drawing Attributes \"\n", caFolderName);
			//fprintf(fReportFile,"For Master Drawing Reference linked object status check ERROR: check the folder \"%s --> Item Revisions - Remove Master Drawing Reference linked object or add it to the current folder \"\n", caFolderName);
		}	
		
		if(iRetCode == ITK_ok && (missingFolderAccess == false) && (tMissingFolder != NULLTAG) && 
			(targetFolderAccess == true) && (lIsProgressionError == true) )
		{
			iRetCode = AOM_ask_owner (tMissingFolder,&tOwningUser);
			if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
			{
				iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
			}
			TI_sprintf(szErrorString,"\nThe Missing Item Revisions could not be copied to the \"%s\" folder as you don't have Write access to the \"%s\" folder which is owned by user \"%s\".\n", MISSING_ITEMS_FOLDER, MISSING_ITEMS_FOLDER, acOwningUserName );					
			TC_write_syslog(szErrorString); 
			fprintf(fReportFile," %s\n", szErrorString );
			tOwningUser = NULLTAG;
		}				
		if(iRetCode == ITK_ok && (removalFolderAccess == false) && (tRemovalFolder != NULLTAG) && 
			(targetFolderAccess == true) && (lIsProgressionError == true) )
		{
			iRetCode = AOM_ask_owner (tRemovalFolder,&tOwningUser);
			if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
			{
				iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
			}
			TI_sprintf(szErrorString,"\nThe Error Item Revisions could not be copied to the \"%s\" folder as you don't have Write access to the \"%s\" folder which is owned by user \"%s\".\n", DATA_REMOVAL_FOLDER, DATA_REMOVAL_FOLDER, acOwningUserName );					
			TC_write_syslog(szErrorString); 
			fprintf(fReportFile," %s\n", szErrorString );
			tOwningUser = NULLTAG;
		}

		if(fReportFile != NULL )
		{
			fclose(fReportFile);
		}

		if((iRetCode == ITK_ok) && (pcReportFileName != NULL) && (lDatasetAccess == true))
		{
				iRetCode = IMF_import_file (pcReportFileName,NULL,SS_TEXT,
												&tFile, &fileDescriptor);
		}
		if (iRetCode == ITK_ok && (tFile != NULLTAG) && (lDatasetAccess == true))
		{
			iRetCode = IMF_close_file (fileDescriptor);
			if (iRetCode == ITK_ok)
				iRetCode = SaveObject(tFile);
		}
		if((iRetCode == ITK_ok) && (tFile != NULLTAG) && (tDatasetTag != NULLTAG)&& (lDatasetAccess == true) )
		{			
			iRetCode = AOM_refresh (tDatasetTag,true);
			//Add the referenced names to the dataset.
			if (iRetCode == ITK_ok)
			{
				iRetCode = AE_add_dataset_named_ref ( tDatasetTag, pcRefNames[0],
										AE_PART_OF, tFile );
			}
			if (iRetCode == ITK_ok)
			{
				iRetCode = SaveObject(tDatasetTag);
			}
			for(indx =0; indx < iRefCount ;indx++)
			{
				SAFE_MEM_free(pcRefNames[indx]);
			}
		}
		if(iRetCode == ITK_ok && (lDatasetAccess == true))
		{
			TI_sprintf(szErrorString,"\nDetailed report is attached under the folder \"%s\" as a text dataset with name \"Progression_check_report\". In case you don�t see the dataset, please refresh the folder \"%s\".", 
									caFolderName, caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 			 
		}
		else if(iRetCode == ITK_ok && (lDatasetAccess == false)&& (tDatasetTag != NULLTAG))
		{	
			//if the user does not have the write access on the dataset then print the following error message
			
			iRetCode = AOM_ask_owner (tDatasetTag,&tOwningUser);
			if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
			{
				iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
			}
			TI_sprintf(szErrorString,"\n\"Progression_check_report\" dataset present in the folder \"%s\" could not be refreshed as you don't have access to the dataset and it is owned by \"%s\".", 
									caFolderName,acOwningUserName );
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString);  
		}

		if ( (assemblyProgWarningMsgStack == NULL) && (genericProgWarningMsgStack == NULL) && 
			 (genericProgErrMsgStack == NULL) && (assemblyProgErrMsgStack== NULL) && 
			 (itemRevProgErrMsgStack == NULL) && (backwordProgErrMsgStack == NULL)  && (masterDrawingReferenceObjectErrMsgStack == NULL) )
		{
			if(iRetCode == ITK_ok && isItemRevPresent == true )
			{
				TI_sprintf(szErrorString,"\nThere are no progression check failures for the item revisions present in the folder \"%s\".\n",
										caFolderName);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}
			else if(iRetCode == ITK_ok && isItemRevPresent == false )
			{
				TI_sprintf(szErrorString,"\nThere are no item revisions in the folder \"%s\".\n",caFolderName);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}
		}
		
		//print the details about folder structure creation in the pop-up dialog
		if(iRetCode == ITK_ok && (targetFolderAccess == true) && (missingFolderAccess == true) && 
			(removalFolderAccess == true) && (lIsProgressionError == true) )
		{
			iRetCode = AOM_ask_owner (tFolder,&tOwningUser);
			if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
			{
				iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
			}
			TI_sprintf(szErrorString,"For Backward Progression Error Item revisions: check the folder \"%s --> Item Revisions - To be removed --> Backward Progression\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString);

			TI_sprintf(szErrorString,"For ItemRevision Progression Error Item revisions: check the folder \"%s --> Item Revisions - To be removed --> ItemRevision Progression\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 

			TI_sprintf(szErrorString,"For Backward Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Backward Progression\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 

			TI_sprintf(szErrorString,"For Generic Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Generic Progression\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 

			TI_sprintf(szErrorString,"For Assembly Progression missing Item revisions: check the folder \"%s --> Item Revisions - To be added --> Assembly Progression\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 
			
			TI_sprintf(szErrorString,"For Product Revision missing Master Drawing information: check the folder \"%s --> Item Revisions - Update Master Drawing Attributes\"", caFolderName);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 

			//TI_sprintf(szErrorString,"For Master Drawing Reference linked object status check: check the folder \"%s --> --> Item Revisions - To be added --> Master Drawing Reference linked object status check\"", caFolderName);
			//EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			//TC_write_syslog(szErrorString);

			tOwningUser = NULLTAG;
		}
		else if(iRetCode == ITK_ok && (targetFolderAccess == false) && (lIsProgressionError == true) )
		{
			iRetCode = AOM_ask_owner (tFolder,&tOwningUser);
			if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
			{
				iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
			}
			TI_sprintf(szErrorString,"\nThe Folder structure could not be created as you don't have the Write access to the \"%s\" folder which is owned by user \"%s\".", caFolderName,acOwningUserName );
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			TC_write_syslog(szErrorString); 				
			tOwningUser = NULLTAG;
		}
		else if(lIsProgressionError == true)
		{				
			if(iRetCode == ITK_ok && (missingFolderAccess == false) && (tMissingFolder != NULLTAG))
			{
				iRetCode = AOM_ask_owner (tMissingFolder,&tOwningUser);
				if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
				{
					iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
				}
				TI_sprintf(szErrorString,"\nThe Missing Item Revisions could not be copied to the \"%s\" folder as you don't have Write access to the \"%s\" folder which is owned by user \"%s\".\n", MISSING_ITEMS_FOLDER, MISSING_ITEMS_FOLDER, acOwningUserName );
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);					
				tOwningUser = NULLTAG;
			}				
			if(iRetCode == ITK_ok && (removalFolderAccess == false) && (tRemovalFolder != NULLTAG))
			{
				iRetCode = AOM_ask_owner (tRemovalFolder,&tOwningUser);
				if(iRetCode == ITK_ok && tOwningUser != NULLTAG)
				{
					iRetCode = SA_ask_user_person_name (tOwningUser,acOwningUserName);	
				}
				TI_sprintf(szErrorString,"\nThe Error Item Revisions could not be copied to the \"%s\" folder as the initiator does not has Write access to the \"%s\" folder which is owned by user \"%s\".\n", DATA_REMOVAL_FOLDER, DATA_REMOVAL_FOLDER, acOwningUserName );
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
				tOwningUser = NULLTAG;
			}				
		}
		TI_sprintf(szErrorString,"\nPlease refresh the folder \"%s\" and it's sub-folders(if present) to see the latest progression result.\n", caFolderName);
		EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
		TC_write_syslog(szErrorString); //Reverted

		if(iRetCode == ITK_ok && (isDatasetPresent == false) && (verdict == true) )
		{	
			if(iRetCode == ITK_ok)
				iRetCode = AOM_refresh(tFolder,true);
			if(iRetCode == ITK_ok)
				iRetCode = FL_insert(tFolder,tDatasetTag,999);
			if(iRetCode == ITK_ok)
				iRetCode = AOM_save(tFolder);			
			if(iRetCode == ITK_ok)
				iRetCode = AOM_refresh(tFolder,false);
		}
		remove(pcReportFileName);
		
		//to write the ITRs having invalid status error message to the pop-up dialog .//Reverted			
		if(ITRsStatusErrMsgStack != NULL )
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;			
			if(ITRsStatusErrMsgStack != NULL)
			{					
				TI_sprintf( szErrorString, "\nTo fix the invalid status errors, please set the correct status on mentioned Item revisions or remove them from the folder before initiating the workflow.\n");	
				EMH_store_error_s1(EMH_severity_error, TIAUTO_QUICKPROGRESSION_ERROR, szErrorString );
				
				tempErrMsg = ITRsStatusErrMsgStack;
				while( ITRsStatusErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, ITRsStatusErrMsgStack->iRetCode, 
										ITRsStatusErrMsgStack->errMsg );
					TC_write_syslog(ITRsStatusErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = ITRsStatusErrMsgStack;
         			ITRsStatusErrMsgStack = ITRsStatusErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				ITRsStatusErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Item Revisions Having Invalid Status Error******* ");
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}			
		}
		//to write the checked-out and remote error message to the pop-up dialog 			
		if(remoteANDcheckedoutErrMsgStack != NULL )//	|| (attachedtootherprocessErrMsgStack != NULL)) )
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;			
			if(remoteANDcheckedoutErrMsgStack != NULL)
			{					
				TI_sprintf( szErrorString, "\nIf the object is checked out, please check-in the object before initiating the workflow.\nIf the object is a remote object, please fix it before initiating the workflow.\n\n");	
				EMH_store_error_s1(EMH_severity_error, TIAUTO_QUICKPROGRESSION_ERROR, szErrorString );
				
				tempErrMsg = remoteANDcheckedoutErrMsgStack;
				while( remoteANDcheckedoutErrMsgStack )
				{	           
					EMH_store_error_s1( EMH_severity_error, remoteANDcheckedoutErrMsgStack->iRetCode, 
										remoteANDcheckedoutErrMsgStack->errMsg );
					TC_write_syslog(remoteANDcheckedoutErrMsgStack->errMsg);
					TC_write_syslog("\n");
         			tempErrMsg = remoteANDcheckedoutErrMsgStack;
         			remoteANDcheckedoutErrMsgStack = remoteANDcheckedoutErrMsgStack->next;
					free( tempErrMsg );
					tempErrMsg = NULL;
				}
				remoteANDcheckedoutErrMsgStack = NULL;
				TI_sprintf(szErrorString,"\n********Remote or Checked Out Object Error******* ");
				EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ERROR,szErrorString);
			}			
		}
		//to show the Mandatory IRM form attribute error in the pop-up dialog
		if(missingAttrErrMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			TI_sprintf( szErrorString, "\nTo fix Mandatory attributes error, Please fill the above mentioned mandatory attributes of item revision master forms.\n");
			EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY , szErrorString );

			while( missingAttrErrMsgStack )
			{
				EMH_store_error_s1( EMH_severity_error, missingAttrErrMsgStack->iRetCode,
						            missingAttrErrMsgStack->errMsg );
				TC_write_syslog(missingAttrErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = missingAttrErrMsgStack;
         		missingAttrErrMsgStack = missingAttrErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			missingAttrErrMsgStack = NULL;
			TI_sprintf(szErrorString,"\n********Start of Mandatory Attributes Error********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY,szErrorString);
		}
		//to show the Related revisions error in the pop-up dialog
		if(relatedRevisionErrMsg != NULL)
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;
			TI_sprintf( szErrorString, "\nTo fix Related Revision error problem, Please add at least one item revision to the Related Revisions folder for the above item revisions.\n");	
			EMH_store_error_s1(EMH_severity_error, TIAUTO_QUICKPROGRESSION_ERROR, szErrorString );
				
			while( relatedRevisionErrMsg )
			{	           
				EMH_store_error_s1( EMH_severity_error, relatedRevisionErrMsg->iRetCode, 
						            relatedRevisionErrMsg->errMsg );				
				TC_write_syslog(relatedRevisionErrMsg->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = relatedRevisionErrMsg;
         		relatedRevisionErrMsg = relatedRevisionErrMsg->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			relatedRevisionErrMsg = NULL;
			TI_sprintf(szErrorString,"\n\n********Start of Related Revision Error********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_RELATEED_REV_ERROR,szErrorString);
		}	
		//to show the Related revisions warning in the pop-up dialog
		if(relatedRevisionWarningMsg != NULL)
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;
			TI_sprintf( szErrorString, "\nTo fix Related Revision error problem, Please add at least one item revision to the Related Revisions folder for the above document revisions.\n");	
			EMH_store_error_s1(EMH_severity_error, TIAUTO_QUICKPROGRESSION_ERROR, szErrorString );
				
			while( relatedRevisionWarningMsg )
			{	           
				EMH_store_error_s1( EMH_severity_error, relatedRevisionWarningMsg->iRetCode, 
						            relatedRevisionWarningMsg->errMsg );				
				TC_write_syslog(relatedRevisionWarningMsg->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = relatedRevisionWarningMsg;
         		relatedRevisionWarningMsg = relatedRevisionWarningMsg->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			relatedRevisionWarningMsg = NULL;
			TI_sprintf(szErrorString,"\n\n********Start of Related Revision Warning********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_RELATED_REV_WARNING,szErrorString);
		}		
		if(productRevWarningMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( productRevWarningMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, productRevWarningMsgStack->iRetCode, 
						            productRevWarningMsgStack->errMsg );
				//iRetCode = genericProgWarningMsgStack->iRetCode;
				TC_write_syslog(productRevWarningMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = productRevWarningMsgStack;
         		productRevWarningMsgStack = productRevWarningMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			productRevWarningMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of missing Master Drawing Information WARNING******* ");
            EMH_store_error_s1(EMH_severity_error,TIAUTO_MASTER_DRAWING_ATTRIBUTES_NOT_FOUND,szErrorString);
		}
		//to write the assembly warning message to the pop-up dialog
		if(assemblyProgWarningMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( assemblyProgWarningMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, assemblyProgWarningMsgStack->iRetCode, 
						            assemblyProgWarningMsgStack->errMsg );
				//iRetCode = assemblyProgWarningMsgStack->iRetCode;
				TC_write_syslog(assemblyProgWarningMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = assemblyProgWarningMsgStack;
         		assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			assemblyProgWarningMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of Assembly Progression WARNING******* ");
            EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ASSEMBLY_WARNING,szErrorString);
		}
		if(genericProgWarningMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( genericProgWarningMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, genericProgWarningMsgStack->iRetCode, 
						            genericProgWarningMsgStack->errMsg );
				//iRetCode = genericProgWarningMsgStack->iRetCode;
				TC_write_syslog(genericProgWarningMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = genericProgWarningMsgStack;
         		genericProgWarningMsgStack = genericProgWarningMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			genericProgWarningMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of Generic Progression WARNING******* ");
            EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_WARNING,szErrorString);
		}
		if(backwordProgErrMsgStack != NULL)
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( backwordProgErrMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, backwordProgErrMsgStack->iRetCode, 
						            backwordProgErrMsgStack->errMsg );
				//iRetCode = backwordProgErrMsgStack->iRetCode;
				TC_write_syslog(backwordProgErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = backwordProgErrMsgStack;
         		backwordProgErrMsgStack = backwordProgErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			backwordProgErrMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of Backward Progression ERROR*********");
			TC_write_syslog(szErrorString);
            EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_BACKWARD_ERROR,szErrorString);
		}
		if(itemRevProgErrMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( itemRevProgErrMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, itemRevProgErrMsgStack->iRetCode, 
						            itemRevProgErrMsgStack->errMsg );
				//iRetCode = itemRevProgErrMsgStack->iRetCode;
				TC_write_syslog(itemRevProgErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = itemRevProgErrMsgStack;
         		itemRevProgErrMsgStack = itemRevProgErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			itemRevProgErrMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of ItemRev Progression ERROR********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ITEMREV_ERROR,szErrorString);
		}		
		if(assemblyProgErrMsgStack != NULL)
		{				
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( assemblyProgErrMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, assemblyProgErrMsgStack->iRetCode, 
						            assemblyProgErrMsgStack->errMsg );
				//iRetCode = assemblyProgErrMsgStack->iRetCode;
				//iRetCode = assemblyProgErrMsgStack->iRetCode;
				TC_write_syslog(assemblyProgErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = assemblyProgErrMsgStack;
         		assemblyProgErrMsgStack = assemblyProgErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			assemblyProgErrMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of Assembly Progression ERROR********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_ASSEMBLY_ERROR,szErrorString);
		}			
		if(genericProgErrMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			while( genericProgErrMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, genericProgErrMsgStack->iRetCode, 
						            genericProgErrMsgStack->errMsg );
				//iRetCode = genericProgErrMsgStack->iRetCode;
				TC_write_syslog(genericProgErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = genericProgErrMsgStack;
         		genericProgErrMsgStack = genericProgErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			
			genericProgErrMsgStack = NULL;
			TI_sprintf(szErrorString,"********Start of Generic Progression ERROR******* ");
            EMH_store_error_s1(EMH_severity_error,TIAUTO_QUICKPROGRESSION_GENERIC_ERROR,szErrorString);
			
		}	
		if(masterDrawingReferenceObjectErrMsgStack != NULL)
		{
			TIA_ErrorMessage *tempErrMsg = NULL;
			
			TI_sprintf(szErrorString,"Please add the Master Drawing revision to current change folder or remove it from the Master Drawing refernce of the Product Revison Master Form.");
			TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS,szErrorString);

			while( masterDrawingReferenceObjectErrMsgStack )
			{	           
				EMH_store_error_s1( EMH_severity_error, masterDrawingReferenceObjectErrMsgStack->iRetCode, 
						            masterDrawingReferenceObjectErrMsgStack->errMsg );
				//iRetCode = itemRevProgErrMsgStack->iRetCode;
				TC_write_syslog(masterDrawingReferenceObjectErrMsgStack->errMsg);
				TC_write_syslog("\n");
         		tempErrMsg = masterDrawingReferenceObjectErrMsgStack;
         		masterDrawingReferenceObjectErrMsgStack = masterDrawingReferenceObjectErrMsgStack->next;
				free( tempErrMsg );
				tempErrMsg = NULL;
			}
			masterDrawingReferenceObjectErrMsgStack = NULL;

			TI_sprintf(szErrorString,"********Start of Master Drawing Reference linked Item Revision status check ERROR********");
            TC_write_syslog(szErrorString);
			EMH_store_error_s1(EMH_severity_error,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS,szErrorString);
		}
	} //Reverted
	
	/*if(iRetCode != ITK_ok)
	{	
		*decision = EPM_nogo;
	}*/

    return iRetCode;
}

int CreateDataset (	char        *pcDatasetName,
                    tag_t       tDatasetType,
                    char        *pcDatasetFormat,
                    char        *pcDescription,
                    tag_t       tDefaultTool,
                    tag_t       *tDatasetTag	)
{
    int iRetCode = ITK_ok;

    /*
     * Create a dataset.
     */
    if (!pcDescription)
        iRetCode = AE_create_dataset_with_id ( tDatasetType, pcDatasetName,
                                                 "", "", "", tDatasetTag );
    else
        iRetCode = AE_create_dataset_with_id ( tDatasetType, pcDatasetName,
                                                 pcDescription, "", "", tDatasetTag );
    if (iRetCode == ITK_ok)
    {
		/* Set the default tool for the new dataset */
		iRetCode = AE_set_dataset_tool (*tDatasetTag, tDefaultTool);
		/*
		* If tool output formats exist, use the tool output format to set for the
		* dataset format
		*/
	}    
    /* Set the dataset format */
	if (iRetCode == ITK_ok)
		iRetCode = AE_set_dataset_format ( *tDatasetTag, pcDatasetFormat);
	if (iRetCode == ITK_ok)
		iRetCode = SaveObject(*tDatasetTag);
    
    return (iRetCode);
}	

int SaveObject (tag_t     objectTag)
{
    int iReturnCode = ITK_ok;

    /*  Save the object.  */
    iReturnCode = AOM_save (objectTag);

    /* Unlock the object. */
	iReturnCode = AOM_unlock (objectTag);	

    return (iReturnCode);
}

/*=====================================================================================
//! check_remote_and_checked_out_objects()
//! \param  int					iNumAffected,		<I> 
//!			tag_t				*ptAffectedItems	<I>
//!			TIA_ErrorMessage	**pstCurrErrMsg		<O>
//! \return int
//! \note Checks whether the item revision and the secondary parts are a remote object or checked out 
//!		  if remote or checked-out, then error out the objects. 
//!		  Returns retcode.
=====================================================================================*/
int check_remote_and_checked_out_objects(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **pstCurrErrMsg)
{
	int		iFail							= ITK_ok;
	int		iAffCntr						= 0;
	int		iNumSec							= 0;
	int		iSecCntr						= 0;
	int     iItemBvrCount                   = 0;

	tag_t	tOwningSite						= NULLTAG;
	tag_t	tItem							= NULLTAG;
	tag_t	tCheckedOutUser					= NULLTAG;
	tag_t	tCheckedOutGroup				= NULLTAG;
	//tag_t	*ptSecondaryObjects				= NULL;
	GRM_relation_t *ptSecondaryList			= NULL;
	tag_t   *ptItemRevBvrs                  = NULL;

	char	acItemId[ITEM_id_size_c+1]		= "";
	char	acRevId[ITEM_id_size_c+1]		= "";
	char	acErrorString[512]				= "";
	char	acOSUserName[SA_name_size_c+1]	= "";
	char	*pcClassName					= NULL;
	char	*pcSecObjClassName				= NULL;
	char    *pcBVRObjClassName              = NULL;
	char	*pcObjName						= NULL;
	char	*pcCheckedOutDate				= NULL;
	char     acRelationType[TCTYPE_name_size_c+1];
	logical lCheckedOut						= false;
	logical lReadAccess						= false;

	for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iFail == ITK_ok) ; iAffCntr++)
	{
		tag_t tTargetType = NULLTAG;
		tag_t tParentType = NULLTAG;
		// get the classname of the objects inside affected and solution items folder
		if (iFail == ITK_ok && ptAffectedItems[iAffCntr] != NULLTAG )
			iFail = tiauto_get_class_name_of_instance (ptAffectedItems[iAffCntr], &pcClassName);
		
		if(tc_strcasecmp (pcClassName , "ItemRevision")!= 0 && (iFail == ITK_ok) )
		{
			//get the classname of the object
			if (iFail == ITK_ok && ptAffectedItems[iAffCntr] != NULLTAG )
			{
				TIAUTO_ITKCALL(iFail,TCTYPE_ask_object_type(ptAffectedItems[iAffCntr],&tTargetType));
			}
		
			if(tTargetType != NULLTAG)
			{
				TIAUTO_ITKCALL(iFail,TCTYPE_ask_parent_type(tTargetType,&tParentType));
				if(tParentType != NULLTAG)
				{
					TIAUTO_ITKCALL(iFail,TCTYPE_ask_class_name2(tParentType, &pcClassName));
				}
				
			}
		}
		// check if the classname of the object inside affected and solution items folder is ItemRevision
        if((iFail == ITK_ok)  &&( (tc_strcasecmp (pcClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcmp (pcClassName,TIAUTO_TI_DOCUMENTREVISION) == 0)))
        {
			// check if read access available for item revision
			lReadAccess = false;	
			iFail = AM_check_privilege(ptAffectedItems[iAffCntr],"READ", &lReadAccess);
			if( iFail == ITK_ok && lReadAccess == true )
			{			
				// get item tag
				iFail = ITEM_ask_item_of_rev(ptAffectedItems[iAffCntr], &tItem);
				// get item id string 
				if(iFail == ITK_ok && tItem != NULLTAG)
					iFail = ITEM_ask_id(tItem, acItemId);
				// get item rev id string 
				if( iFail == ITK_ok)
					iFail = ITEM_ask_rev_id(ptAffectedItems[iAffCntr],acRevId );
				// check if item revision is checked out
				if ( iFail == ITK_ok)
					iFail = RES_is_checked_out( ptAffectedItems[iAffCntr], &lCheckedOut );
				if( iFail == ITK_ok && lCheckedOut == true)
				{
					lCheckedOut = false;
					iFail = RES_who_checked_object_out (ptAffectedItems[iAffCntr],&tCheckedOutUser,&tCheckedOutGroup);
					if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
					{
						iFail = SA_ask_os_user_name  (  tCheckedOutUser, acOSUserName );
					}
					if ( iFail == ITK_ok)
					{
						iFail = AOM_UIF_ask_value  (ptAffectedItems[iAffCntr],"checked_out_date",&pcCheckedOutDate);
					}
					TI_sprintf(acErrorString, "Error: The item revision \"%s/%s\" is checked out by \"%s\" on \"%s\".",acItemId, acRevId,acOSUserName,pcCheckedOutDate); 						
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);
					SAFE_MEM_free(pcCheckedOutDate);
				}
				// check if the item revision is remote
				if( iFail == ITK_ok)
					iFail = AOM_ask_value_tag( ptAffectedItems[iAffCntr], "owning_site", &tOwningSite);
				if(iFail == ITK_ok && tOwningSite != NULLTAG )
				{
					tOwningSite = NULLTAG;
					TI_sprintf(acErrorString, "The item revision \"%s/%s\" is a remote object.",acItemId, acRevId); 
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);
					
				}
			}
			// if no read access
			if (iFail == ITK_ok && lReadAccess == false )
			{
				iFail = AOM_ask_name(ptAffectedItems[iAffCntr],&pcObjName); 
                TI_sprintf(acErrorString, "The user does not have read access for the item revision \"%s/%s\".", acItemId, acRevId); 
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);
				
				SAFE_MEM_free (pcObjName);
			}			

			//Check if the item revision has any BomViews.
			iFail = ITEM_rev_list_bom_view_revs (ptAffectedItems[iAffCntr], &iItemBvrCount, &ptItemRevBvrs);
			if( iFail == ITK_ok && iItemBvrCount > 0 )
			{
				// get the class name of the BVR object
				iFail = tiauto_get_class_name_of_instance (ptItemRevBvrs[0], &pcBVRObjClassName);
				iFail = RES_is_checked_out( ptItemRevBvrs[0], &lCheckedOut );
				if( iFail == ITK_ok && lCheckedOut == true )
				{
					lCheckedOut = false;
					iFail = AOM_ask_name(ptItemRevBvrs[0],&pcObjName); 
					iFail = RES_who_checked_object_out (ptItemRevBvrs[0],&tCheckedOutUser,&tCheckedOutGroup);
					if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
					{
						iFail = SA_ask_os_user_name  (  tCheckedOutUser, acOSUserName );
					}
					if ( iFail == ITK_ok)
					{
						iFail = AOM_UIF_ask_value  (ptItemRevBvrs[0],"checked_out_date",&pcCheckedOutDate);
					}
					TI_sprintf(acErrorString, "Error: The BVR \"%s\" attached to the item revision \"%s/%s\" is checked out by \"%s\" on \"%s\".",pcObjName, acItemId, acRevId,acOSUserName,pcCheckedOutDate); 
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);
					SAFE_MEM_free (pcObjName);
					SAFE_MEM_free(pcBVRObjClassName);
					SAFE_MEM_free(ptItemRevBvrs);
					SAFE_MEM_free(pcCheckedOutDate);
				}
			}

			//get the objects related to Item revision with any relationship		
			//if(iFail == ITK_ok)
				//iFail = GRM_list_secondary_objects_only(ptAffectedItems[iAffCntr], NULLTAG, 
                //                                &iNumSec, &ptSecondaryObjects);
			if(iFail == ITK_ok)
				iFail =GRM_list_secondary_objects( ptAffectedItems[iAffCntr], NULLTAG,&iNumSec,&ptSecondaryList);
			for( iSecCntr = 0; (iFail == ITK_ok) && (iSecCntr < iNumSec) ; iSecCntr++ )
			{
				//check whether secondary object is in the related revision folder
				iFail=TCTYPE_ask_name( ptSecondaryList[iSecCntr].relation_type,acRelationType);
				if ( (iFail == ITK_ok)&& ( (tc_strcmp(acRelationType,"TI_DocProdRevisions")==0) ||
										   (tc_strcmp(acRelationType,"IMAN_based_on")==0) ) )
				{
					continue;
				}
				//check if related object is checked out
				lReadAccess = false;
				iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName); 
				iFail = tiauto_get_class_name_of_instance (ptSecondaryList[iSecCntr].secondary, &pcClassName);
				iFail = AM_check_privilege(ptSecondaryList[iSecCntr].secondary,"READ", &lReadAccess);
				if( iFail == ITK_ok && lReadAccess == true )
				{
					// get the class name of the secondary object
					iFail = tiauto_get_class_name_of_instance (ptSecondaryList[iSecCntr].secondary, &pcSecObjClassName);

					// check if related object is checked out
					if( iFail == ITK_ok && ptSecondaryList[iSecCntr].secondary != NULLTAG )
						iFail = RES_is_checked_out( ptSecondaryList[iSecCntr].secondary, &lCheckedOut );
					if( iFail == ITK_ok && lCheckedOut == true )
					{
						lCheckedOut = false;
						iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName); 
						if ( iFail == ITK_ok)
							iFail = RES_who_checked_object_out (ptSecondaryList[iSecCntr].secondary,&tCheckedOutUser,&tCheckedOutGroup);
						if ( iFail == ITK_ok && tCheckedOutUser != NULLTAG)
						{
							iFail = SA_ask_os_user_name  (  tCheckedOutUser, acOSUserName );
						}
						if ( iFail == ITK_ok)
						{
							iFail = AOM_UIF_ask_value  (ptSecondaryList[iSecCntr].secondary,"checked_out_date",&pcCheckedOutDate);
						}
						TI_sprintf(acErrorString, "Error: The %s \"%s\" attached to the item revision \"%s/%s\" is checked out by \"%s\" on \"%s\".",pcSecObjClassName,pcObjName, acItemId, acRevId,acOSUserName,pcCheckedOutDate); 						
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);

						SAFE_MEM_free (pcObjName);
						SAFE_MEM_free(pcCheckedOutDate);
					}
					// check if related object is remote
					if( iFail == ITK_ok)
						iFail = AOM_ask_value_tag( ptSecondaryList[iSecCntr].secondary, "owning_site", &tOwningSite);
					if(iFail == ITK_ok && tOwningSite != NULLTAG )
					{
						tOwningSite = NULLTAG;
						iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName); 
						TI_sprintf(acErrorString, "The %s \"%s \" attached to the item revision \"%s/%s\" is a remote object.",pcSecObjClassName,pcObjName, acItemId, acRevId ); 
						tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);

						SAFE_MEM_free (pcObjName);
					}
				}
				// if no read access
				if (iFail == ITK_ok && lReadAccess == false )
				{
					iFail = AOM_ask_name(ptSecondaryList[iSecCntr].secondary,&pcObjName); 
					TI_sprintf(acErrorString, "The user does not have read access for the %s \"%s \". attached to item revision \"%s/%s\"\n",pcObjName,pcSecObjClassName, acItemId, acRevId); 
					tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR, acErrorString);
					
					SAFE_MEM_free (pcObjName);
				}
				SAFE_MEM_free (pcSecObjClassName);
			}
			SAFE_MEM_free (ptSecondaryList);
		}
		SAFE_MEM_free(pcClassName);
	}

	return iFail;
}

//to add the progression missing and error item revs to the mentioned folder
int copyErrorItemsToFolder(tag_t tFolder, char* folderName,TIA_UniqueWSOMObjects *errorList)
{
	TIA_UniqueWSOMObjects *errorListTemp = NULL;
	int iRetCode = ITK_ok;
	int iFolderReferences = 0;
	int iSubFolderReferences = 0;
	int iCount =0, iCount1 = 0;
	char pcReferenceType[WSO_name_size_c+1] = "";
	char *pcFolderName = NULL;
	tag_t tNewfolder = NULLTAG;
	tag_t *ptFolderReferences = NULLTAG;
	tag_t *ptSubFolderReferences = NULLTAG;	

	iRetCode = FL_ask_references  ( tFolder, FL_fsc_no_order, &iFolderReferences, &ptFolderReferences);
	for(iCount = 0; iCount<iFolderReferences; iCount++)
	{	
		iRetCode = WSOM_ask_object_type  ( ptFolderReferences[iCount], pcReferenceType);
		if(tc_strcmp(pcReferenceType, "Folder")==0)
		{	
			iRetCode = AOM_ask_value_string(ptFolderReferences[iCount], "object_name", &pcFolderName);
			if(tc_strcmp(pcFolderName, folderName)==0)
			{				
				tNewfolder = ptFolderReferences[iCount];
				iRetCode = FL_ask_references  ( ptFolderReferences[iCount], FL_fsc_no_order, &iSubFolderReferences, &ptSubFolderReferences);
				iRetCode = AOM_refresh(tNewfolder, true);
				for(iCount1 = 0; iCount1< iSubFolderReferences; iCount1++)
				{	
					iRetCode = FL_remove(ptFolderReferences[iCount],ptSubFolderReferences[iCount1]);					
				}
				iRetCode = SaveObject(tNewfolder);				
				SAFE_MEM_free(ptSubFolderReferences);				
				break;							 
			}
			SAFE_MEM_free(pcFolderName);
		}
	}		
	if(errorList != NULL)
	{
		if(tFolder != NULLTAG)
		{
			if(folderName!=NULL && strcmp(folderName,"")!=0)
			{					
				if(iCount == iFolderReferences)
				{
					iRetCode = FL_create  ( folderName, "",&tNewfolder);
				}				
				
				while(errorList != NULL)
				{
					//insert into the newly created folder
					if(errorList->tUniqueWSOMObjects != NULLTAG)
					{
						iRetCode = FL_insert(tNewfolder, errorList->tUniqueWSOMObjects, 999);
					}
					errorListTemp = errorList;
					errorList = errorList->next;
					free(errorListTemp);
				}				
				iRetCode = SaveObject(tNewfolder);
				if(iCount == iFolderReferences)
				{
					iRetCode = FL_insert(tFolder, tNewfolder, 999);
					iRetCode = SaveObject(tFolder);					
				}
				SAFE_MEM_free(ptFolderReferences);				
			}	  
		
			//if( folderName == NULL && strcmp( folderName, "" ) == 0 )
			else
			{
				while(errorList != NULL)
				{
					//insert into the newly created folder
					if(errorList->tUniqueWSOMObjects != NULLTAG)
					{
						iRetCode = FL_insert(tFolder, errorList->tUniqueWSOMObjects, 999);
					}
					errorListTemp = errorList;
					errorList = errorList->next;
					free(errorListTemp);
				}				
				iRetCode = SaveObject(tFolder);
			}
		}
	}
	
	else if(tNewfolder != NULLTAG)
	{
		//iRetCode = AOM_refresh(tNewfolder, true);
		//iRetCode = AOM_delete_from_parent(tNewfolder, tFolder);
		//iRetCode = SaveObject(tFolder);	
		SAFE_MEM_free(ptFolderReferences);
	}
	

	return iRetCode;
}
/*=====================================================================================
//! check_attached_to_other_process()
//! \param  int					iNumAffected,		<I> 
//!			tag_t				*ptAffectedItems	<I>
//!			TIA_ErrorMessage	**pstCurrErrMsg		<O>
//! \return int
//! \note Checks whether the item revision is in target of other process or not. 
//!		  Returns retcode.
=====================================================================================*/
//int check_attached_to_other_process(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **pstCurrErrMsg)
//{
//	int          iRetCode		= ITK_ok;
//	int			 iNoOfRefs		= 0;
//	int			 iAffCntr		= 0;
//	int			 i				= 0;
//	int			 j				= 0;
//	int			 iNumAttachments= 0;
//
//	tag_t		 tJob			= NULLTAG;
//	tag_t		 tRootTask		= NULLTAG;
//	tag_t	     tEngChngRev	= NULLTAG;
//	tag_t		 tTypeTag		= NULLTAG;
//	tag_t		*ptReferencers	= NULL;	
//    tag_t		*ptAttachments	= NULL;	
//
//	char		*pcClassName						= NULL;
//    char		pszObject[WSO_name_size_c+1]		= "";
//	char		type_class[TCTYPE_class_name_size_c+1] = "";	
//	char		acErrorString[512]					= "";
//	char		caChangeId[ITEM_id_size_c+1]		= {'\0'};
//	char		caChangeRevId[ITEM_id_size_c+1]		= {'\0'};
//	char		caChangeName[ITEM_name_size_c+1]	= {'\0'};
//	char		caItemId[ITEM_id_size_c+1]			= {'\0'};
//	char		caItemRevId[ITEM_id_size_c+1]		= {'\0'};
//	char		caItemName[ITEM_name_size_c+1]		= {'\0'};
//
//	for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iRetCode == ITK_ok) ; iAffCntr++)
//	{
//		// get the classname of the objects inside affected and solution items folder
//		if (iRetCode == ITK_ok && ptAffectedItems[iAffCntr] != NULLTAG )
//			iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[iAffCntr], &pcClassName);
//
//		// check if the classname of the object inside affected and solution items folder is ItemRevision
//        if((iRetCode == ITK_ok)  && (tc_strcasecmp (pcClassName , "ItemRevision")== 0) )
//        {
//			iRetCode = CR_ask_job(ptAffectedItems[iAffCntr], &iNoOfRefs, &ptReferencers);
//
//			for(i=0; (i < iNoOfRefs) && ( iRetCode == ITK_ok ); i++)
//			{
//				iRetCode = TCTYPE_ask_object_type(ptReferencers[i],&tTypeTag);
//				if(iRetCode == ITK_ok)
//					iRetCode = TCTYPE_ask_class_name (tTypeTag, type_class);
//				if( ( iRetCode == ITK_ok ) && (tc_strcmp(type_class,"EPMJob") == 0) )
//				{
//					//tProcess = ptReferencers[i];
//					tJob = ptReferencers[i];
//					tEngChngRev = NULLTAG;
//					if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
//					{		
//						//iRetCode = EPM_ask_job( tProcess, &tJob);
//						//if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
//							iRetCode = EPM_ask_root_task (tJob, &tRootTask) ;
//						if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
//							iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
//													&iNumAttachments, &ptAttachments); 
//						for(j = 0; (j < iNumAttachments) && (iRetCode == ITK_ok); j++)
//						{
//							iRetCode = WSOM_ask_object_type(ptAttachments[j], pszObject);			
//							if (iRetCode == ITK_ok && tc_strcmp (pszObject, CHANGE_REV) == 0 )
//							{
//								tEngChngRev = ptAttachments[j];
//								break;  // there should be only one change rev in target objects.
//							}							
//						}
//						SAFE_MEM_free(ptAttachments);
//						if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
//						{
//							if( tiauto_isComponent_partOf_affectedItems(ptAffectedItems[iAffCntr], tEngChngRev) == true )
//							{
//								iRetCode = tiauto_getItemRevDetails(tEngChngRev, caChangeId, caChangeRevId, caChangeName);
//								if( iRetCode == ITK_ok )
//									iRetCode = tiauto_getItemRevDetails(ptAffectedItems[iAffCntr], caItemId, caItemRevId, caItemName);
//								
//								TI_sprintf( acErrorString, "The item revision \"%s/%s - %s\" is already in target of another change process \"%s/%s - %s\".",
//													caItemId, caItemRevId, caItemName,caChangeId, caChangeRevId, caChangeName);
//								tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_QUICKPROGRESSION_ERROR , acErrorString);
//							}
//						}
//					}
//				}
//			}
//			SAFE_MEM_free(ptReferencers);
//		}
//		SAFE_MEM_free(pcClassName);
//	}
//	
//	return iRetCode;
//}

/*---------------------------------------------------------------------------------------------------------
//! Check_status_of_ITRs()
//! \param  int					iNumAffected,		<I> 
//!			tag_t				*ptAffectedItems	<I>
//!			TIA_ErrorMessage	**pstCurrErrMsg		<O>
//! \return int
//! \note Checks whether the item revision present in the folder are having the required status. 
//!		  Returns retcode.
-----------------------------------------------------------------------------------------------------------*/
int Check_status_of_ITRs(int iNumAffected,tag_t *ptAffectedItems,TIA_ErrorMessage **currErrMsg)
{
	int     indx = 0;
    int     iRetCode = ITK_ok;
    char    *pszClassName = NULL;
    char    *pszAffectedItemRevObjectID = NULL;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]=""; 
	logical lIsDoc = false;
	logical lIsPresent = false;
	STRING_Array_Struct_t    AllowedStatus;

	AllowedStatus.iCount = 0;
	AllowedStatus.ValueArray = NULL;
	//get the target statuses mentioned in the LOV
	iRetCode = tiauto_get_lov_values("T8_t1a_CAP_Init_ValidStatus",&AllowedStatus);
    for (indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++)
    {
		tag_t tTargetType = NULLTAG;
		tag_t tParentType = NULLTAG;
        iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		if(tc_strcasecmp (pszClassName , "ItemRevision")!= 0 && (iRetCode == ITK_ok) )
		{
			//get the classname of the object
			if (iRetCode == ITK_ok && ptAffectedItems[indx] != NULLTAG )
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType));
			}
		
			if(tTargetType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
				if(tParentType != NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType, &pszClassName));
				}
				
			}
		}
		if ( (iRetCode == ITK_ok) && ((tc_strcmp (pszClassName,TIAUTO_ITEMREVISION) != 0) || (tc_strcmp (pszClassName,TIAUTO_TI_DOCUMENTREVISION) != 0)) )
		{
            iRetCode = tiauto_get_release_status (ptAffectedItems[indx], szReleaseStatus);
			if(tc_strcmp(szReleaseStatus,"T8_Standard - Preliminary") == 0)
			{
				tc_strcpy(szReleaseStatus, "Standard - Preliminary");
			}
			else if(tc_strcmp(szReleaseStatus,"T8_Standard - Released") == 0)
			{
				tc_strcpy(szReleaseStatus, "Standard - Released");
			}
			else if(tc_strcmp(szReleaseStatus,"T8_Technology Prototype") == 0)
			{
				tc_strcpy(szReleaseStatus, "Technology Prototype");
			}
			else if(tc_strcmp(szReleaseStatus,"T8_Technology Released") == 0)
			{
				tc_strcpy(szReleaseStatus, "Technology Released");
			}
            if (iRetCode == ITK_ok)
            {
				lIsDoc = false;
				lIsPresent = false;
				iRetCode = tiauto_check_if_itemType_isDOC(ptAffectedItems[indx],&lIsDoc);
				if( (lIsDoc == true) && (tc_strcmp (szReleaseStatus,"") == 0 ))
				{
				}
                else if(tc_strcmp (szReleaseStatus,"") == 0 )
                {
                     /* "NONE" string used for comparing WIP status/No STATUS items.*/
                    tc_strcpy (szReleaseStatus, "NONE" );
                }
				tiauto_is_value_available_in_list(AllowedStatus,szReleaseStatus,&lIsPresent);
				if( (tc_strcmp(szReleaseStatus,"T8_Standard - Preliminary") == 0) ||
					(tc_strcmp(szReleaseStatus,"Standard - Preliminary") == 0) ||
					(tc_strcmp(szReleaseStatus,"T8_Standard - Released") == 0) ||
					(tc_strcmp(szReleaseStatus,"Standard - Released") == 0) )
				{
					lIsPresent = true;
				}
                if ( lIsPresent == false )
                {
                    iRetCode = WSOM_ask_object_id_string(ptAffectedItems[indx], &pszAffectedItemRevObjectID);
                    if( (lIsDoc == true) && (tc_strcmp (szReleaseStatus,"") == 0 ))
					{
						TI_sprintf(szErrorString, "Document Revision - '%s' is at WIP status, which is invalid for the change process.",
                                pszAffectedItemRevObjectID); 
						tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
					}
					else if(tc_strcasecmp (szReleaseStatus,"NONE") == 0 )
                    {
                        TI_sprintf(szErrorString, "Item Revision - '%s' is at WIP status, which is invalid for the change process.",
                                pszAffectedItemRevObjectID); 
						tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
                    }
                    else
                    {                         
                        TI_sprintf(szErrorString, "Item Revision - '%s' is at \"%s\" status, which is invalid for the change process.",
                                pszAffectedItemRevObjectID, szReleaseStatus);
						tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
                    }
                    
                    SAFE_MEM_free ( pszAffectedItemRevObjectID );
                   
                }
            }
        } 
		SAFE_MEM_free ( pszClassName );
    }
	
    SAFE_MEM_free ( pszClassName );
    return iRetCode;
}
//to validate the related revision folder of the TI_AltRep and TI_Document revisions
static int validateRelatedRevisions(int iNumAffected, tag_t* ptAffectedItems,TIA_ErrorMessage **relatedRevisionErrMsg)
{
	char    caItemRevType[WSO_name_size_c+1]			= "";
	char	**pcLovValues								=	NULL;
	/*char	acParentType[TCTYPE_name_size_c+1]			= "";
	tag_t	tObjectType = NULLTAG, tParentType			= NULLTAG;*/
	int		iRetCode									= ITK_ok;
    int     inx											= 0;
	int		iLovs										=	0;
	int		iLovValues									=	0;
	int     iLovValuesIndex								=   0;

	tag_t	*ptLovs										=	NULL;
	
	if(iNumAffected > 0)
	{
		//get the object types list from the LOV T8_ObjectTypes
		iRetCode = LOV_find( "T8_VerifyRelatedRevisions" ,&iLovs,&ptLovs);

		if (iRetCode == ITK_ok && ptLovs != NULL)
			iRetCode = LOV_ask_values_string (ptLovs[0],&iLovValues ,&pcLovValues);
	}
	for(inx=0; inx<iNumAffected; inx++)
	{		
		iRetCode = WSOM_ask_object_type  ( ptAffectedItems[inx], caItemRevType) ;
		for (iLovValuesIndex = 0; iLovValuesIndex < iLovValues && (iRetCode == ITK_ok); iLovValuesIndex++)
		{
			if (tc_strcasecmp( caItemRevType , pcLovValues[iLovValuesIndex])== 0 && (iRetCode == ITK_ok) )
			{
				iRetCode = check_related_revision_folder(ptAffectedItems[inx], relatedRevisionErrMsg );
				break;
			}
		}
		/*if (tc_strcasecmp( caItemRevType , ALTREP_REV)== 0 && (iRetCode == ITK_ok) )
		{
			iRetCode = check_related_revision_folder(ptAffectedItems[inx], relatedRevisionErrMsg );
		}
		if (tc_strcasecmp( caItemRevType , ALTTOOL_REV)== 0 && (iRetCode == ITK_ok) )
		{
			iRetCode = check_related_revision_folder(ptAffectedItems[inx], relatedRevisionErrMsg );
		}
		if (tc_strcasecmp( caItemRevType , "T8_TI_AltConstr Revision")== 0 && (iRetCode == ITK_ok) )
		{
			iRetCode = check_related_revision_folder(ptAffectedItems[inx], relatedRevisionErrMsg );
		}*/
		//else if(iRetCode == ITK_ok)
		//{	
		//	/* get the object type */
		//	iRetCode = TCTYPE_ask_object_type(ptAffectedItems[inx], &tObjectType );
		//	/* get the parent type tag*/
		//	if (iRetCode == ITK_ok)
		//		iRetCode = TCTYPE_ask_parent_type(tObjectType, &tParentType);
		//	/* get the parent type name*/
		//	if (iRetCode == ITK_ok)
		//		iRetCode = TCTYPE_ask_name(tParentType, acParentType);
		//	if (tc_strcasecmp( acParentType , DOCUMENT_REV)== 0 && (iRetCode == ITK_ok) )
		//	{
		//		iRetCode = check_document_related_revision_folder( ptAffectedItems[inx], relatedRevisionErrMsg );
		//	}
		//}
	}
	
	SAFE_MEM_free (ptLovs);
	SAFE_MEM_free (pcLovValues);

	return iRetCode;

}

//to validate the Master drawing attributes
//if attributes are not missing then removing 
//those items from the folder
int validateErrorItemsInFolder( tag_t tFolder )
{
	int		iRetCode				= ITK_ok;
	int		iCount					= 0;
	int		ix						= 0;
	int		iReferences				= 0;
	tag_t	tRelationType			= NULLTAG;
	tag_t	tMasterDrawingRef		= NULLTAG;
	tag_t	*ptReferences			= NULLTAG;
	tag_t	*ptSecObjects			= NULLTAG;
	char	pcReferenceType[WSO_name_size_c+1]  = "";
	char	*pcMasterDrawing					= NULL;
	char	*pcMasterDrawingRev					= NULL;

	iRetCode = FL_ask_references  ( tFolder, FL_fsc_no_order, &iReferences, &ptReferences);
	for(ix = 0; ix < iReferences; ix++)
	{	
		iRetCode = WSOM_ask_object_type  ( ptReferences[ix], pcReferenceType);
		if(tc_strcmp(pcReferenceType, "TI_Product Revision")==0)
		{	
			//find the relation between master form and item revision
			iRetCode = GRM_find_relation_type ("IMAN_master_form", &tRelationType);
			if(tRelationType != NULLTAG)
				iRetCode = GRM_list_secondary_objects_only( ptReferences[ix], tRelationType, &iCount, &ptSecObjects);
			if( iRetCode == ITK_ok && ptSecObjects != NULLTAG && iCount == 1 )
			{
				//retrieve all the master drawing attributes 
				iRetCode = AOM_ask_value_string ( ptSecObjects[0], "t8_t1a1masterdrawing", &pcMasterDrawing);
				iRetCode = AOM_ask_value_string ( ptSecObjects[0], "t8_t1a1masterdrawingrev", &pcMasterDrawingRev);
				iRetCode = AOM_ask_value_tag ( ptSecObjects[0], "t8_t1a1masterdrawingref", &tMasterDrawingRef);

				//if attribute values are not missing then 
				//remove those items from the folder
				if( ( (pcMasterDrawing != NULL ) || (tc_strcmp( pcMasterDrawing , "") != 0 ) ) &&
					( ( pcMasterDrawingRev != NULL) || (tc_strcmp( pcMasterDrawingRev, "" ) != 0)) &&
					 tMasterDrawingRef != NULLTAG )
				{
					iRetCode = AOM_refresh(tFolder, true);
					iRetCode = FL_remove( tFolder, ptReferences[ix]);
					iRetCode = SaveObject(tFolder);

					SAFE_MEM_free ( pcMasterDrawing);
					SAFE_MEM_free ( pcMasterDrawingRev);
				}
			}
		}
	}

	return iRetCode;
}
int remove_data_from_folder(tag_t tFolder,char *folderName)
{
	int iRetCode = ITK_ok;
	int iFolderReferences = 0;
	int iSubFolderReferences = 0;
	int iCount =0, iCount1 = 0;
	int iMissingFolderSize = 0;
	char pcReferenceType[WSO_name_size_c+1] = "";
	char *pcFolderName = NULL;
	tag_t tNewfolder = NULLTAG;
	tag_t *ptFolderReferences = NULLTAG;
	tag_t *ptSubFolderReferences = NULLTAG;	

	iRetCode = FL_ask_references  ( tFolder, FL_fsc_no_order, &iFolderReferences, &ptFolderReferences);
	for(iCount = 0; iCount<iFolderReferences; iCount++)
	{	
		if(folderName != NULL && (tc_strcmp(folderName,"") != 0) )
		{
			iRetCode = WSOM_ask_object_type  ( ptFolderReferences[iCount], pcReferenceType);
			if(tc_strcmp(pcReferenceType, "Folder")==0)
			{	
				iRetCode = AOM_ask_value_string(ptFolderReferences[iCount], "object_name", &pcFolderName);
				if(tc_strcmp(pcFolderName, folderName)==0)
				{				
					tNewfolder = ptFolderReferences[iCount];
					iRetCode = FL_ask_references  ( ptFolderReferences[iCount], FL_fsc_no_order, &iSubFolderReferences, &ptSubFolderReferences);
					iRetCode = AOM_refresh(tNewfolder, true);
					for(iCount1 = 0; iCount1< iSubFolderReferences; iCount1++)
					{	
						iRetCode = FL_remove(ptFolderReferences[iCount],ptSubFolderReferences[iCount1]);					
					}
					iRetCode = SaveObject(tNewfolder);				
					SAFE_MEM_free(ptSubFolderReferences);	
					//
					iRetCode = FL_ask_size  (  ptFolderReferences[iCount], &iMissingFolderSize);
					if(0 == iMissingFolderSize)
					{				
						iRetCode = AOM_refresh(tFolder, true);
						iRetCode = AOM_delete_from_parent( ptFolderReferences[iCount], tFolder);
						iRetCode = SaveObject(tFolder);
					}
					break;							 
				}
				SAFE_MEM_free(pcFolderName);
			}
		}
		else
		{
			iRetCode = FL_remove(tFolder,ptFolderReferences[iCount]);
		}
	}	
	SAFE_MEM_free(ptFolderReferences);

	return iRetCode;
}

int remove_duplicate_itemrevisions(tag_t tMissingFolder)
{
	int iRetCode = ITK_ok;
	int iProgFolders = 0;
	int iDrawingItems = 0;
	int iAssmItems = 0;
	int iBackwardItems = 0;
	int iGenItems = 0;
	int iCount =0, iCount1 = 0, iCount2 = 0, iCount3 = 0, iCount4 = 0, iCount5 = 0;
	char *pcProgFolderName = NULL;
	char *pcDrawingItemsName = NULL;
	char *pcBackwardItemsName = NULL;
	char *pcAssmItemsName = NULL;
	char *pcGenItemsName = NULL;
	tag_t *ptProgFolders = NULLTAG;
	tag_t *ptProgFolders1 = NULLTAG;
	tag_t *ptDrawingItemsFolder = NULLTAG;
	tag_t *ptAssmItemsFolder = NULLTAG;
	tag_t *ptBackwardItemsFolder = NULLTAG;
	tag_t *ptGenItemsFolder = NULLTAG;

	iRetCode = FL_ask_references  ( tMissingFolder, FL_fsc_no_order, &iProgFolders, &ptProgFolders);
	for(iCount = 0; iCount<iProgFolders; iCount++)
	{	
		iRetCode = AOM_ask_value_string(ptProgFolders[iCount], "object_name", &pcProgFolderName);
		if(tc_strcmp(pcProgFolderName, "Drawing Progression")==0)
		{
			iRetCode = FL_ask_references  ( ptProgFolders[iCount], FL_fsc_no_order, &iDrawingItems, &ptDrawingItemsFolder);
			for(iCount1 = 0; iCount1< iDrawingItems; iCount1++)
			{	
				iRetCode = AOM_ask_value_string(ptDrawingItemsFolder[iCount1], "object_string", &pcDrawingItemsName);
				iRetCode = FL_ask_references  ( tMissingFolder, FL_fsc_no_order, &iProgFolders, &ptProgFolders1);
				for(iCount2 = 0; iCount2<iProgFolders; iCount2++)
				{	
					iRetCode = AOM_ask_value_string(ptProgFolders1[iCount2], "object_name", &pcProgFolderName);
					if(tc_strcmp(pcProgFolderName, "Assembly Progression")==0)
					{
						iRetCode = FL_ask_references  ( ptProgFolders1[iCount2], FL_fsc_no_order, &iAssmItems, &ptAssmItemsFolder);
						for(iCount3 = 0; iCount3< iAssmItems; iCount3++)
						{	
							iRetCode = AOM_ask_value_string(ptAssmItemsFolder[iCount3], "object_string", &pcAssmItemsName);
							if(tc_strcmp(pcAssmItemsName, pcDrawingItemsName)==0)
							{
								iRetCode = AOM_refresh(ptAssmItemsFolder[iCount3], true);
								iRetCode = FL_remove(ptProgFolders[iCount2],ptAssmItemsFolder[iCount3]);
							}
						}
						iRetCode = SaveObject(ptProgFolders[iCount2]);
						SAFE_MEM_free(ptAssmItemsFolder);
					}

					if(tc_strcmp(pcProgFolderName, "Backward Progression")==0)
					{
						iRetCode = FL_ask_references  ( ptProgFolders1[iCount2], FL_fsc_no_order, &iBackwardItems, &ptBackwardItemsFolder);
						for(iCount4 = 0; iCount4< iBackwardItems; iCount4++)
						{	
							iRetCode = AOM_ask_value_string(ptBackwardItemsFolder[iCount4], "object_string", &pcBackwardItemsName);
							if(tc_strcmp(pcBackwardItemsName, pcDrawingItemsName)==0)
							{
								iRetCode = AOM_refresh(ptBackwardItemsFolder[iCount4], true);
								iRetCode = FL_remove(ptProgFolders[iCount2],ptBackwardItemsFolder[iCount4]);
							}
						}
						iRetCode = SaveObject(ptProgFolders[iCount2]);
						SAFE_MEM_free(ptBackwardItemsFolder);
					}

					if(tc_strcmp(pcProgFolderName, "Generic Progression")==0)
					{
						iRetCode = FL_ask_references  ( ptProgFolders1[iCount2], FL_fsc_no_order, &iGenItems, &ptGenItemsFolder);
						for(iCount5 = 0; iCount5< iGenItems; iCount5++)
						{	
							iRetCode = AOM_ask_value_string(ptGenItemsFolder[iCount5], "object_string", &pcGenItemsName);
							if(tc_strcmp(pcGenItemsName, pcDrawingItemsName)==0)
							{
								iRetCode = AOM_refresh(ptGenItemsFolder[iCount5], true);
								iRetCode = FL_remove(ptProgFolders[iCount2],ptGenItemsFolder[iCount5]);
							}
						}
						iRetCode = SaveObject(ptProgFolders[iCount2]);
						SAFE_MEM_free(ptGenItemsFolder);
					}
				}
				SAFE_MEM_free(pcProgFolderName);
			}
			
		}
		SAFE_MEM_free(ptProgFolders1);
	}
	SAFE_MEM_free(ptDrawingItemsFolder);
	SAFE_MEM_free(ptProgFolders);
	
	return iRetCode;
}