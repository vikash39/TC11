/*******************************************************************************
FILE        :   tiauto_rh_verify_designwork_required.c
Details     :   This rule handler is used to check whether ECR form "Design Work" 
                attribute value is "Yes".If the Application Engg has selected Opt Out 
				and Design Work attribute in ECR form is Yes, then throw an error message.

REVISION HISTORY :

Date              Revision        Who						Description
Feb  1, 2016      1.0			 Shilpa						Initial Creation.

*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Rule Handler -  TIAUTO_RH_verify_designwork_required
===================================================================================*/
EPM_decision_t TIAUTO_RH_verify_designwork_required(EPM_rule_message_t msg )
{
	int		iRetCode				= ITK_ok;
	int		iArg					= 0;
	int		iNumArgs				= 0;	
	tag_t	tECRForm				= NULLTAG;
	tag_t	tChangeRev				= NULLTAG;
	tag_t	tGroupmember			= NULLTAG;
	tag_t	tGroup					= NULLTAG;
	char	*pcFlag					= NULL;
	char	*pcValue				= NULL;	
	char	*pcTaskResult			= NULL;
	char	*pcInputErrorMessage	= NULL;
	char	acUserGroup[SA_group_name_size_c + 1]	= "";
	
	
	EPM_decision_t decision = EPM_go;

	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_current_groupmember(&tGroupmember);

	
	if(iRetCode == ITK_ok && tGroupmember != NULLTAG)
		iRetCode = SA_ask_groupmember_group(tGroupmember, &tGroup);

	if(iRetCode == ITK_ok && tGroup != NULLTAG)
	    iRetCode = SA_ask_group_name(tGroup, acUserGroup);

	if(tc_strcmp(acUserGroup,"dba") == 0)
	{
		decision = EPM_go;
		return decision;
	}

	//getting the error message from handler argument
	iNumArgs = TC_number_of_arguments(msg.arguments); 
	if(iNumArgs>0)
	{
		for(iArg = 0; (iArg < iNumArgs) && (iRetCode==ITK_ok) ; iArg++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue);
			if(iRetCode == ITK_ok)
			{					
				if( tc_strcasecmp(pcFlag,TIAUTO_ERROR_MSG) == 0 && pcValue != NULL)
				{
					pcInputErrorMessage = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcInputErrorMessage, pcValue);
				}
			}
			else
			{
				iRetCode = EPM_invalid_argument_value;
			}
		}
	}	
	else
	{
		iRetCode = EPM_invalid_argument;
	}
	//getting change revision from the current task
	iRetCode = tiauto_get_change_item_rev(msg.task, &tChangeRev);
	//getting current task result
	if(iRetCode==ITK_ok)
		iRetCode= EPM_get_task_result(msg.task,&pcTaskResult);
	//getting the ECR form from the change revision
	if (iRetCode == ITK_ok&& (tChangeRev != NULLTAG))
	{
		TIAUTO_ITKCALL(iRetCode,tiauto_getFormAttachedToObject(tChangeRev,TIAUTO_TI_ECR,&tECRForm));
	}
	//Checking if the Design required attribute of ECR form is Yes and  if task result contains Opt Out. Then throw error message
	if (iRetCode == ITK_ok && tECRForm != NULLTAG)
	{
		char	*pcAttrValue			= NULL;

		TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(tECRForm,ATTR_DESIGN_WORK,&pcAttrValue));			
		if((tc_strcmp(pcAttrValue,VALUE_YES) == 0) && (tc_strstr(pcTaskResult,TIAUTO_OPTOUT)!= NULL) && iRetCode== ITK_ok)
		{
			decision= EPM_nogo;
			TC_write_syslog(pcInputErrorMessage);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_ECR_OPTION, pcInputErrorMessage) ;
			
		}
		SAFE_MEM_free(pcAttrValue);
	}
	
	if ( iRetCode != ITK_ok )
	{
		char	*pcErrMsg				= NULL;
		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcValue);	
	SAFE_MEM_free(pcTaskResult);
	SAFE_MEM_free(pcInputErrorMessage);

	return decision;
}
	
	