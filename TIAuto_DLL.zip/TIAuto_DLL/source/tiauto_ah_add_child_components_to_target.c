/*******************************************************************************
File         : tiauto_ah_add_child_components_to_target.c

Description  :get the child components of the item revisions available in the solution items folder recursively and add it to target if it's release status is less than the target

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 7, 2016     1.0       	Shilpa    		 Initial Creation
Oct 26, 2016	1.1			Kantesh			 Modified for code ER#8898
Jun 18, 2019    1.2         Trisha Saha      PCI substitue changes
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int t1aAUTO_AH_add_child_compoenents_to_target(EPM_action_message_t msg)
{
	int				iRetcode							= ITK_ok;
	int				iSecObjCount						= 0;
	int				iLoopSecObjCnt						= 0;
	int				iNumAffected				      	= 0;
	tag_t			tRootTaskTag						= NULLTAG;	
	tag_t			tEngChangeRev						= NULLTAG;
	tag_t			*ptSecObjTags						= NULL;	
	tag_t			tRelTag								= NULLTAG;
	tag_t	        *ptAffectedItems					= NULL;
	char			 szErrorString[TIAUTO_error_message_len+1]= "";
	
		
	if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the change revision details
		if(iRetcode == ITK_ok && tRootTaskTag!= NULLTAG)
		{	
			iRetcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
			//iRetcode = GRM_find_relation_type("CMHasSolutionItem", &tRelTag);
			//iRetcode = GRM_list_secondary_objects_only(tEngChangeRev,tRelTag,&iSecObjCount,&ptSecObjTags);
			iRetcode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);
			for(iLoopSecObjCnt =0; iLoopSecObjCnt < iNumAffected; iLoopSecObjCnt++)
			{
				iRetcode = CheckStatusofChildItemsinBOM(ptAffectedItems[iLoopSecObjCnt],msg,tRootTaskTag,"Production Released",tEngChangeRev);
				iRetcode = AddMasterDrawingReferenceToTarget(ptAffectedItems[iLoopSecObjCnt], tEngChangeRev, tRootTaskTag);
			}
		}
	}	
	else if ( iRetcode != ITK_ok )
	{
		char			*pcErrMsg			= NULL;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
			
	return iRetcode;

}
					
					
int	CheckStatusofChildItemsinBOM(tag_t ptSecObjTags,EPM_action_message_t msg,tag_t tRootTaskTag,char *pcReleaseStatus,tag_t tEngChangeRev)
{
	int			ibvrcount									= 0;
	int			iCount										= 0;		
	int			iNumOccs									= 0;
	int			iNoAlternates								= 0;
	tag_t		*ptBvrTags									= NULL;	
	tag_t		*ptOccs										= NULL;
	tag_t		tChildItem									= NULLTAG;
	tag_t		tChildBomView								= NULLTAG;
	tag_t		tAlternate									= NULLTAG;
	tag_t		*ptAltItems									= NULL;
	tag_t		*pAltViews									= NULL;
	int			iRetcode									= ITK_ok;
	int			*iError_									= 0;
	int			_iPopulateErrMsgInStack;
	logical		lHasAlternates								= false;
	logical		lIsPrecise									= false;
	char		*szItemRevInChangeId						= NULL;
	char		szErrorString[TIAUTO_error_message_len+1]	= "";
	

	iRetcode = ITEM_rev_list_bom_view_revs (ptSecObjTags, &ibvrcount, &ptBvrTags);

	

	if(ibvrcount > 0)
	{
		iRetcode = PS_list_occurrences_of_bvr (ptBvrTags[0], &iNumOccs, &ptOccs);
		iRetcode = PS_ask_is_bvr_precise (ptBvrTags[0], &lIsPrecise);
		
		if( iRetcode != ITK_ok )
		{
			char		*pcItemRevName			= NULL;
			WSOM_ask_id_string(ptSecObjTags, &pcItemRevName);
			TI_sprintf(szErrorString, "Error while getting %s Part's BOM.", pcItemRevName);
			SAFE_MEM_free(pcItemRevName);					         		
		}
		 if( iNumOccs > 0  && (lIsPrecise == true) && iRetcode == ITK_ok) 
		{				
			for (iCount = 0; iCount < iNumOccs ; iCount++)
			{
				int		iLoopChildItemRev					 	= 0;			
				int		iChildItemRevCnt						= 0;
				int		iNoOfRefs								= 0;
				int		iRefIndex								= 0;
				tag_t	*ptChildItemRevTags						= NULL;			
				tag_t	tUserData								= NULLTAG;
				tag_t	tTarRelTag								= NULLTAG;	
				tag_t	*ptReferencers							= NULL;
				tag_t	tTypeTag								= NULLTAG;
				logical lIsReferencedinOtherWF					= false;
				char	acTypeClass[TCTYPE_class_name_size_c+1]	= "";

							
				iRetcode = PS_ask_occurrence_child (ptBvrTags[0], ptOccs[iCount],
												&tChildItem, &tChildBomView);
				
				iRetcode = CR_ask_job(tChildItem, &iNoOfRefs, &ptReferencers);

				for(iRefIndex=0; (iRefIndex < iNoOfRefs) && ( iRetcode == ITK_ok ); iRefIndex++)
				{
					iRetcode = TCTYPE_ask_object_type(ptReferencers[iRefIndex],&tTypeTag);
					if(iRetcode == ITK_ok)
						iRetcode = TCTYPE_ask_class_name (tTypeTag, acTypeClass);
					if( ( iRetcode == ITK_ok ) && (tc_strcmp(acTypeClass,"EPMJob") == 0) )
					{
						lIsReferencedinOtherWF = true;
						break;
					}
				}
				
				if(lIsReferencedinOtherWF == true)
				{
					continue;
				}

				iRetcode = AddChildCompToTarget(tChildItem,ptSecObjTags,tChildBomView,tRootTaskTag,msg,pcReleaseStatus,tEngChangeRev);
				iRetcode = AddMasterDrawingReferenceToTarget(tChildItem, tEngChangeRev, tRootTaskTag);

				if(lIsPrecise == true && iRetcode == ITK_ok)
				{
					lHasAlternates = false;
					iRetcode = PS_ask_has_substitutes  (  ptBvrTags[0], ptOccs[iCount], &lHasAlternates );
					if ( iRetcode == ITK_ok && lHasAlternates == true)
					{
						iRetcode = PS_list_substitutes (ptBvrTags[0],ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews);
					
						if(iRetcode == ITK_ok && iNoAlternates > 0)
						{
							int		iAltCount			= 0;
							for (iAltCount = 0; (iAltCount < iNoAlternates);iAltCount++)
							{
								int		ialtbvrcount		= 0;
								tag_t	*ptaltBvrTags		= NULL;
								tAlternate = ptAltItems[iAltCount];
								iRetcode = ITEM_rev_list_bom_view_revs (tAlternate, &ialtbvrcount, &ptaltBvrTags);
								if(tAlternate != NULLTAG && iRetcode == ITK_ok &&  ialtbvrcount > 0)
								{
									iRetcode = CheckStatusofChildItemsinBOM(tAlternate,msg,tRootTaskTag,pcReleaseStatus,tEngChangeRev);
								}
								//start of PCI 15.02
								else if(iAltCount > 0 && tAlternate != NULLTAG && iRetcode == ITK_ok && ialtbvrcount <= 0)
								{
									iRetcode = AddChildCompToTarget(tAlternate,ptSecObjTags,tChildBomView,tRootTaskTag,msg,pcReleaseStatus,tEngChangeRev);
								}
								//end of PCI 15.02
							}
						}
					}
				}
				
				iRetcode = CheckStatusofChildItemsinBOM(tChildItem,msg,tRootTaskTag,pcReleaseStatus,tEngChangeRev);

				SAFE_MEM_free(ptChildItemRevTags);
			}
			
		}
	}

	SAFE_MEM_free(ptBvrTags);
	SAFE_MEM_free(ptOccs);
	SAFE_MEM_free(ptAltItems);
	SAFE_MEM_free(pAltViews);
	SAFE_MEM_free(szItemRevInChangeId);
	return iRetcode;
}
					
int	AddChildCompToTarget(tag_t	tChildItem,tag_t ptSecObjTags,tag_t	tChildBomView,tag_t	tRootTaskTag,EPM_action_message_t msg, char *pcReleaseStatus,tag_t tEngChangeRev)
{
	
	char    szReleaseStatus[WSO_name_size_c+1]		= "";
	char    szChildRelStatus[WSO_name_size_c+1]		= "";
	int		iLoopPref								= 0;
	int		iSecObjRelStatus						= 0;
	int		iRetcode								= ITK_ok;
	tag_t	tOwningSite								= NULLTAG;

	STATUS_Struct_t    StatusProgression;

	if ( iRetcode == ITK_ok && tChildItem != NULLTAG)
	{		
		
			iRetcode = tiauto_get_release_status(tChildItem,szChildRelStatus);
			if(tc_strcmp(szChildRelStatus, pcReleaseStatus) == 0 ) 
			{
				int     iAttachmentType				= EPM_target_attachment;
				int		iTargetCount				= 0;
				int		iLoopTargCount				= 0;
				tag_t	*ptTargetAtt				= NULL;
				char	*pcSecObjID					= NULL;
				logical lisChildItemNotInTargets	= false;

				iRetcode = EPM_ask_attachments(tRootTaskTag,EPM_target_attachment,&iTargetCount,&ptTargetAtt);
				
				for(iLoopTargCount =0; iLoopTargCount < iTargetCount; iLoopTargCount++)
				{
					char		*pcObjectID		= NULL;						
									
					if( (tChildItem ==ptTargetAtt[iLoopTargCount]) && iRetcode == ITK_ok)
					{
						//lisChildItemNotInTargets=false;
						break;								
					}
					else if((tChildItem !=ptTargetAtt[iLoopTargCount]) && iRetcode == ITK_ok)
					{
						lisChildItemNotInTargets=true;
					}
				}
				if((lisChildItemNotInTargets == true) && iRetcode == ITK_ok)
				{
					tOwningSite = NULLTAG;
					iRetcode = AOM_ask_value_tag( tChildItem, "owning_site", &tOwningSite);
					//if object is remote, store the error message in the error stack
					if(iRetcode == ITK_ok && tOwningSite == NULLTAG)
					{
						iRetcode = EPM_add_attachments(tRootTaskTag,1,&(tChildItem),&iAttachmentType);
						//iRetcode = AddMasterDrawingReferenceToTarget(tChildItem, tEngChangeRev, tRootTaskTag);

						iRetcode = 0;
					}
				}
				SAFE_MEM_free(ptTargetAtt);
				SAFE_MEM_free(pcSecObjID);
			}						
		
	}
	return iRetcode;
}

//**********************************************************************************************
//Function : AddMasterDrawingReferenceToTarget

//**********************************************************************************************
int AddMasterDrawingReferenceToTarget (	tag_t _tItemRev, tag_t tEngChangeRev, tag_t tRootTaskTag )

{
    int     iRetCode											= ITK_ok;
	int		iIRMFCnt											= 0;
	int     i                                                   = 0;
	int     iAttachmentType										= EPM_target_attachment;
	int		iNumAffected				      				    = 0;

	tag_t	tIRMFRelationType									= NULLTAG;
	tag_t	tRefItemRev											= NULLTAG;
	tag_t	*ptIRMFList											= NULL;
	tag_t	tOwningSite											= NULLTAG;
	tag_t	*ptAffectedItems									= NULL;

	char    *pcItemRevId										= NULL;
	char    *pcRefItemRevId                                     = NULL;
	char    *pcTempItemRevId                                    = NULL;
    char    szRefItemRevReleaseStatus[WSO_name_size_c+1]		= "";	

	char	acItemRevType[ITEM_type_size_c+1]					= "";

	logical     lIsPresent										= false;
	logical		lisInTargets									= false;

	//get the item revision type
    iRetCode = ITEM_ask_rev_type(_tItemRev, acItemRevType);

	if ( (iRetCode == 0) && (tc_strcmp(acItemRevType,"TI_Product Revision") == 0) )
	{
		//get the item revision id string: "Item/Rev" format i. e "00001/AA"
		iRetCode = WSOM_ask_id_string ( _tItemRev, &pcItemRevId );

		iRetCode = GRM_find_relation_type("IMAN_master_form", &tIRMFRelationType);
		if (iRetCode == 0 && tIRMFRelationType != NULLTAG);
		{
			iRetCode = GRM_list_secondary_objects_only (_tItemRev,tIRMFRelationType,&iIRMFCnt,&ptIRMFList);
		}
		if (iRetCode == 0 && iIRMFCnt == 1)
		{
			int			iTarObjCount			= 0;
			int			iLoopTarObj				= 0;
			tag_t		*ptTarObj				= NULL;

			iRetCode = AOM_ask_value_tag (ptIRMFList[0], "t8_t1a1masterdrawingref", &tRefItemRev);
			if ( iRetCode == ITK_ok && tRefItemRev != NULLTAG)
			{
				//get the reference item revision id string: "Item/Rev" format i. e "AR001/AA"
				iRetCode = WSOM_ask_id_string ( tRefItemRev, &pcRefItemRevId );

				// check whether the Master Drawing Reference linked Item rev is present in the current change folder
				if (iRetCode == ITK_ok)
				{
					iRetCode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);
				}
				if (iRetCode == ITK_ok)
				{
					iRetCode = EPM_ask_attachments(tRootTaskTag, EPM_target_attachment,&iTarObjCount,&ptTarObj);
				}
				for (i=0; i<iNumAffected; i++)
				{
					iRetCode = WSOM_ask_id_string ( ptAffectedItems[i], &pcTempItemRevId );
					if ( (iRetCode == 0) && (tc_strcmp(pcRefItemRevId, pcTempItemRevId) == 0) ) 
					{
						lIsPresent = true;
					}

				}
				for(iLoopTarObj =0; iLoopTarObj < iTarObjCount; iLoopTarObj++)
				{
					if((ptTarObj[iLoopTarObj]==tRefItemRev) && (iRetCode == 0))
					{
						lisInTargets= true;
						break;
					}
				}

				if ( (lIsPresent == true) && (iRetCode == 0) )
				{
				}
				if ( (lIsPresent == false) && (iRetCode == 0) && (lisInTargets==false))
				{
					//get the release status
					iRetCode = tiauto_get_release_status( tRefItemRev, szRefItemRevReleaseStatus );
					if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Released");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Released");
					}
					// If Master Drawing Reference linked item rev has no Release status or less than the Changege Process Target Release status
					if( (iRetCode == ITK_ok) && ((tc_strcasecmp(szRefItemRevReleaseStatus, "") == 0) || (tc_strcasecmp(szRefItemRevReleaseStatus,"Production Launched") != 0)))
					{
						tOwningSite = NULLTAG;
						iRetCode = AOM_ask_value_tag( tRefItemRev, "owning_site", &tOwningSite);
						//if object is remote, store the error message in the error stack
						if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
						{
							iRetCode = EPM_add_attachments(tRootTaskTag,1,&(tRefItemRev),&iAttachmentType);
						}
					}
				}
			}
			MEM_free(ptTarObj);
		}
	}

    return  iRetCode;
}