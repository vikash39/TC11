/*********************************************************************************************************************
FILE        :   tiauto_ah_remove_items_from_project.c
Details     :   This rule handler is used to remove affected items of a change from Advance Engineering project

REVISION HISTORY :

Date              Revision        Who						Description
Sep  27, 2017     1.0			  Shilpa R					Initial Creation.

**************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int TIAUTO_AH_remove_items_from_project(EPM_action_message_t msg )
{
	int             iRetCode						= ITK_ok;
	tag_t			tChangeRev						= NULLTAG;
	int				iSecObjCount					= 0;
	int				iLoopSecObj						= 0;
	tag_t			*ptSecObjs						= NULL;
	tag_t			tRelation						= NULLTAG;

	if (iRetCode == ITK_ok )
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_IMAN_SPEC_REL,&tRelation));
		if( iRetCode == ITK_ok && tRelation != NULLTAG)
		{
			
			TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(tChangeRev,tRelation,&iSecObjCount,&ptSecObjs));
			for(iLoopSecObj = 0; iLoopSecObj < iSecObjCount; iLoopSecObj++)
			{
				char		*pcObjectType			= NULL;
				char		*pcTarRelState			= NULL;

				TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(ptSecObjs[iLoopSecObj],TIAUTO_OBJECT_TYPE,&pcObjectType));
				if((tc_strcmp(pcObjectType,TIAUTO_TI_TPR)==0) && iRetCode==ITK_ok)
				{
					AOM_ask_value_string(ptSecObjs[iLoopSecObj],TIAUTO_TPR_TAR_REL_STATE,&pcTarRelState);
				}
				else if((tc_strcmp(pcObjectType,TIAUTO_TI_TER)==0) && iRetCode==ITK_ok)
				{
					AOM_ask_value_string(ptSecObjs[iLoopSecObj],TIAUTO_TER_TAR_REL_STATE,&pcTarRelState);
				}
				if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) && (tc_strcmp(pcTarRelState,TIAUTO_TECH_REL)==0))
				{	
					int			iNumAffected			= 0;
					int			iLoopSecObjCnt			= 0;
					tag_t		*ptAffectedItems		= NULL;					
					int			iFormCount				= 0;
					tag_t		*ptForm					= NULL;
					int			iLoopForm				= 0;
					tag_t		tSummRelation			= NULLTAG;
					int			iSummObjCount			= 0;
					tag_t		*ptSummObjs				= NULL;
					int			iLoopSummImag			= 0;

					if((tc_strcmp(pcObjectType,TIAUTO_TI_TPR)==0) && iRetCode==ITK_ok)
					{
						TIAUTO_ITKCALL(iRetCode,RemoveFromProject(tChangeRev,TIAUTO_TPR_APPROVED));	
					}
					else if((tc_strcmp(pcObjectType,TIAUTO_TI_TER)==0) && iRetCode==ITK_ok)
					{
						TIAUTO_ITKCALL(iRetCode,RemoveFromProject(tChangeRev,TIAUTO_TER_APPROVED));	
					}
					TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(tChangeRev,tRelation,&iFormCount,&ptForm));
					for(iLoopForm = 0; iLoopForm < iFormCount; iLoopForm++)
					{
						if((tc_strcmp(pcObjectType,TIAUTO_TI_TPR)==0) && iRetCode==ITK_ok)
						{
							TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptForm[iLoopForm],TIAUTO_TPR_APPROVED));
						}
						else if((tc_strcmp(pcObjectType,TIAUTO_TI_TER)==0) && iRetCode==ITK_ok)
						{
							TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptForm[iLoopForm],TIAUTO_TER_APPROVED));	
						}
					}
					
					TIAUTO_ITKCALL(iRetCode,ECM_get_affected_items(tChangeRev, &iNumAffected, &ptAffectedItems));
					for(iLoopSecObjCnt =0; iLoopSecObjCnt < iNumAffected; iLoopSecObjCnt++)
					{
						int		iCostFrmCnt			= 0;
						tag_t	*ptCostFrm			= NULL;
						tag_t	tCostFrmRel			= NULLTAG;
						int		iLoopCostForm		= 0;
						TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptAffectedItems[iLoopSecObjCnt],TIAUTO_TECH_REL_STATUS));							
						TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_COST_FORM_REL,&tCostFrmRel));
						if( iRetCode == ITK_ok && tCostFrmRel != NULLTAG)
						{
							TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(ptAffectedItems[iLoopSecObjCnt],tCostFrmRel,&iCostFrmCnt,&ptCostFrm));
							for(iLoopCostForm =0; iLoopCostForm < iCostFrmCnt; iLoopCostForm++)
							{
								TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptCostFrm[iLoopCostForm],TIAUTO_TECH_REL_STATUS));	
							}
						}
					}
					
					for(iLoopSecObjCnt =0; iLoopSecObjCnt < iNumAffected; iLoopSecObjCnt++)
					{
						char		*pcObjectType		= NULL;
						TIAUTO_ITKCALL(iRetCode,WSOM_ask_object_type2(ptAffectedItems[iLoopSecObjCnt],&pcObjectType));
						if((tc_strcmp(pcObjectType,TIAUTO_ADV_CHANGE_REV)==0) && iRetCode==ITK_ok)
						{
							TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptAffectedItems[iLoopSecObjCnt],NULL));
						}
					}
					TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (TIAUTO_SUMM_IMAG_REL,&tSummRelation));
					if( iRetCode == ITK_ok && tSummRelation != NULLTAG)
					{			
						TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(tChangeRev,tSummRelation,&iSummObjCount,&ptSummObjs));
						for(iLoopSummImag =0; iLoopSummImag < iSummObjCount; iLoopSummImag++)
						{
							TIAUTO_ITKCALL(iRetCode,RemoveFromProject(ptSummObjs[iLoopSummImag],TIAUTO_TECH_REL_STATUS));	
						}
					}
					SAFE_MEM_free(ptAffectedItems);				
					SAFE_MEM_free(ptForm);
					SAFE_MEM_free(ptSummObjs);
				}				
			}
		}
		SAFE_MEM_free(ptSecObjs);
	}
	return iRetCode;
}

int RemoveFromProject(tag_t	tItem,char	*pcRelStatus)
{
	int			iRetCode			= ITK_ok;
	int			iRelStCnt				= 0;
	int			iLoopRel				= 0;
	tag_t		*ptRelStList			= NULL;
	int			iProjList				= 0;
	int			iLoopProjList			= 0;
	char		*pcProjList				= NULL;
	char		*pcTemp1				= NULL;
	logical		lisInProject			= false;
	char		*pcProjIDName			= NULL;	
	tag_t		tProj					= NULLTAG;					
	char		*pcProjID				= NULL;
	tag_t		tProjItem				= NULLTAG;

	TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(tItem,TIAUTO_PROJ_LIST,&pcProjList));
	TIAUTO_ITKCALL(iRetCode,WSOM_ask_release_status_list(tItem,&iRelStCnt,&ptRelStList));
	for(iLoopRel = 0; iLoopRel < iRelStCnt;iLoopRel++)
	{
		char	*pcRelStaName			= NULL;
		tag_t	tObjClass				= NULLTAG;
		char	*pcObjClassName			= NULL;
		char	*pcObjectType			= NULL;
		TIAUTO_ITKCALL(iRetCode,AOM_ask_name(ptRelStList[iLoopRel],&pcRelStaName));
		TIAUTO_ITKCALL(iRetCode,WSOM_ask_object_type2(tItem,&pcObjectType));

		if(((tc_strcmp(pcRelStaName,pcRelStatus)==0) || (tc_strcmp(pcObjectType,TIAUTO_ADV_CHANGE_REV)==0)) && iRetCode==ITK_ok)
		{
			if(iRetCode == ITK_ok && tItem != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,POM_class_of_instance(tItem, &tObjClass));

			if(iRetCode == ITK_ok && tObjClass != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,POM_name_of_class(tObjClass, &pcObjClassName));

			pcTemp1 = (char *)MEM_alloc( ((int)tc_strlen(pcProjList)) * sizeof(char));
			tc_strcpy(pcTemp1,pcProjList);
			pcProjIDName = tc_strtok (pcTemp1,TIAUTO_COMMA);	
			while(pcProjIDName != NULL && iRetCode == ITK_ok)
			{							
				if((tc_strcmp(pcProjIDName,TIAUTO_PROJ_ID)==0) && iRetCode==ITK_ok)
				{
					char	*pcProjID			= NULL;
					char	*pcTemp2			= NULL;
					tag_t	tProj				= NULLTAG;						
					tag_t	tItemRev			= NULLTAG;					
					
					tProjItem=tItem;
					pcTemp2 = (char *)MEM_alloc( ((int)tc_strlen(pcProjIDName)) * sizeof(char));
					tc_strcpy(pcTemp2,pcProjIDName);
					pcProjID = tc_strtok (pcTemp2,TIAUTO_HYPHEN);
					TIAUTO_ITKCALL(iRetCode,PROJ_find(pcProjID,&tProj));
					if((tc_strcmp(pcObjClassName,TI_FORM)==0) && iRetCode==ITK_ok)
					{
						TIAUTO_ITKCALL(iRetCode,RemoveForm(tProjItem,tProj));
					}
					else
					{
						TIAUTO_ITKCALL(iRetCode,RemoveItemandRev(tProjItem,tProj));		
					}
					SAFE_MEM_free(pcTemp2);					
					
				}
				pcProjIDName = tc_strtok (NULL,TIAUTO_COMMA);	
			}
		}
		SAFE_MEM_free(pcRelStaName);
	}
	SAFE_MEM_free(ptRelStList);
	SAFE_MEM_free(pcProjList);
	SAFE_MEM_free(pcTemp1);
	SAFE_MEM_free(pcProjIDName);
	SAFE_MEM_free(pcProjID);

	return iRetCode;
}

int	RemoveItemandRev(tag_t	tItemRev,tag_t	tProj)
{
	int			iRetCode			= ITK_ok;
	char		*pcItemID			= NULL;
	tag_t		tItem				= NULLTAG;

	TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(tItemRev,TIAUTO_ITEM_ID,&pcItemID));
	TIAUTO_ITKCALL(iRetCode,ITEM_find_item(pcItemID,&tItem));	
	TIAUTO_ITKCALL(iRetCode,PROJ_remove_objects(1,&tProj,1,&tItemRev));
	TIAUTO_ITKCALL(iRetCode,PROJ_remove_objects(1,&tProj,1,&tItem));
	SAFE_MEM_free(pcItemID);
	return iRetCode;
}

int	RemoveForm(tag_t	tItemRev,tag_t	tProj)
{
	int			iRetCode			= ITK_ok;	
	tag_t		tItem				= NULLTAG;
		
	TIAUTO_ITKCALL(iRetCode,PROJ_remove_objects(1,&tProj,1,&tItemRev));		
	return iRetCode;
}