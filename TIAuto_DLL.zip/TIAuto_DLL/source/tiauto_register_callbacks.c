/* tiauto_register_callbacks.c    - used to create tiauto.dll     */
/*                                  TI Automotive's custom exits  */
/*                                  used instead of user exits    */
/*                                                                */
/*Version 00001 - 08/11/2006 D. Atherton - Initial Release        */
/*        Created to call canned methods                          */
/*        (included in ti_auto_canned_methods)                    */
/*Version 00002 - 08/13/2010 Rajesh Natesan - Modified		      */
/*        added t1aAUTO_register_runtime_properties               */
/*Version 00003 - 12/31/2010 Dipak Naik -					       */
/*        Created to call the server exits                        */
/*        (included in t1aAUTO_register_server_exits)				*/


#include <ict/ict_userservice.h>
#include <tccore/tcaehelper.h>
#include <user_exits/aiws_ext.h>
#include <tc/preferences.h>
#include <ss/ss_errors.h>
#include <tccore/custom.h>
#include <itk/mem.h>
#include <tc/tc.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include "tiauto_canned_methods.h"
#include "tiauto_user_query.h"
#include <tiauto_custom_handlers.h>
#include <tiauto_runtime_properties.h>
#include <tiauto_server_exits.h>

extern DLLAPI int tiauto_register_callbacks ()
{ 
    CUSTOM_register_exit ( "tiauto", "USER_add_canned_methods", 
       (CUSTOM_EXIT_ftn_t) t1aAUTO_register_canned_methods );

    CUSTOM_register_exit ( "tiauto", "USER_gs_shell_init_module", 
       (CUSTOM_EXIT_ftn_t) t1aAUTO_register_custom_handlers );

	CUSTOM_register_exit ( "tiauto", "USER_register_properties", 
       (CUSTOM_EXIT_ftn_t) t1aAUTO_register_runtime_properties );
	
	CUSTOM_register_exit ( "tiauto", "USERSERVICE_register_methods", 
       (CUSTOM_EXIT_ftn_t) t1aAUTO_register_server_exits );

	CUSTOM_register_exit ( "tiauto", "USER_execute_saved_query",
       (CUSTOM_EXIT_ftn_t)  t1aAUTO_register_user_query );

    return ( ITK_ok );
}
 
