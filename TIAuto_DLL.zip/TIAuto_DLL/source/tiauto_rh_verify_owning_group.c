/************************************************************************************************
FILE        :   tiauto_rh_verify_owning_group.c

DESCRIPTION :   

AUTHOR      :   Pradeep, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
16 Dec, 2015    1.0        Pradeep	         Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_owning_group(EPM_rule_message_t msg)
{
    int				 iRetCode									= ITK_ok;
	int				 indx										= 0;          
    int				 iNumAttachments							= 0;		
    
	char			szErrorString[TIAUTO_error_message_len+1]	= "";
	char			acObjectType[WSO_name_size_c+1]				= ""; 
	char*			pcLoggedInGroup								= NULL;
	char*			pcDocOwningGroup							= NULL;
	char*			pcObjectString								= NULL;

	tag_t			tRootTask									= NULLTAG;
	tag_t			tDocrev										= NULLTAG;
	tag_t			tLoggedInGroup								= NULLTAG;
	tag_t			tDocOwningGroup								= NULLTAG;
	tag_t*			ptAttachments								= NULL;

	TIA_ErrorMessage *ErrMsgStack								= NULL;
	EPM_decision_t decision										= EPM_go;

	logical			lIsDOC										= false;

	iRetCode = EPM_ask_root_task(msg.task , &tRootTask);

	if (iRetCode == ITK_ok)
		
		iRetCode = AOM_ask_value_tag( tRootTask, "owning_group", &tLoggedInGroup);
		iRetCode = POM_ask_group_name(tLoggedInGroup, &pcLoggedInGroup); 


    if (iRetCode == ITK_ok)
    iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iNumAttachments, &ptAttachments);

	for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
    {
		iRetCode = AOM_ask_value_string(ptAttachments[indx], "object_string", &pcObjectString);
		iRetCode = WSOM_ask_object_type (ptAttachments[indx], acObjectType); 

		iRetCode = tiauto_check_if_itemType_isDOC(ptAttachments[indx], &lIsDOC);
        
		if (iRetCode == ITK_ok && lIsDOC == true)
		{
			tDocrev = ptAttachments[indx];

			//get the owning group
			iRetCode = AOM_ask_group (tDocrev, &tDocOwningGroup);
			iRetCode = POM_ask_group_name(tDocOwningGroup, &pcDocOwningGroup); 

			if (iRetCode == ITK_ok && (tc_strcmp(pcLoggedInGroup,pcDocOwningGroup) != 0))
			{
				decision = EPM_nogo;
				TI_sprintf( szErrorString, "\n\"%s\" is owned by \"%s\" group.\n",pcObjectString,pcDocOwningGroup);
				EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_DOCUMENT_OWNING_GROUP, szErrorString) ;
				tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_INVALID_DOCUMENT_OWNING_GROUP ,szErrorString);
				TC_write_syslog(szErrorString);
			}
		}
		if (iRetCode == ITK_ok && lIsDOC == false)
		{
			decision = EPM_nogo;
			TI_sprintf( szErrorString, "\n\"%s\" is not of type Document.\n",pcObjectString);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_DOCUMENT_TYPE, szErrorString) ;
			tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_INVALID_DOCUMENT_TYPE ,szErrorString);
			TC_write_syslog(szErrorString);
		}
    }

	if (decision == EPM_nogo)
	{
		TI_sprintf( szErrorString, "\nYou are not allowed to release the following objects because :\n");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_DOCUMENT_OWNING_GROUP, szErrorString) ;
		tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_INVALID_DOCUMENT_OWNING_GROUP ,szErrorString);
		TC_write_syslog(szErrorString);
	}

	SAFE_MEM_free (ptAttachments);
	SAFE_MEM_free (pcObjectString);
	SAFE_MEM_free (pcLoggedInGroup);
	SAFE_MEM_free (pcDocOwningGroup);

	return decision;
}
