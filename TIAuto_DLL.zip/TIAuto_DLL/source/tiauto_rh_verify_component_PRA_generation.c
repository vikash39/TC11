/************************************************************************************************
FILE        :   tiauto_rh_verify_component_PRA_generation.c

DESCRIPTION :   

AUTHOR      :   Shruthi, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
16 Nov, 2018    1.0        Shruthi	         Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_component_PRA_generation(EPM_rule_message_t msg)
{
    int				iRetCode									= ITK_ok;
	int				iNewAseemCount								= 0;
	int				iCompPRACount								= 0;
	int             iCompPRAIndx                                = 0;
	int             iNewAssyIndx                                = 0;

	char			*pcErrMsg									= NULL;
	char			*pcValidReleaseStatusList					= NULL;
	char		    acRootTaskName[WSO_name_size_c+1]			= "";
	char			szErrorString[TIAUTO_error_message_len+1]	= "";

	tag_t			tChangeRev									= NULLTAG;
	tag_t			tRootTask									= NULLTAG;
	tag_t           tChangeForm									= NULLTAG;
	tag_t			tSite										= NULLTAG;
	tag_t			tChildComp									= NULLTAG;	
	tag_t			tAssmComp									= NULLTAG;
	tag_t			*ptNewAssembly								= NULL;
	tag_t			*ptCompPRA									= NULL;

	boolean			bValidERPPlant								= false;
	boolean			bProRelToBeCreated							= false;
	boolean			bPRAFoundInNewAssy                          = false;
	boolean			bValidtoProceed								= false;

	char *pcParentItemrev = NULL;
	char *pcChildItemrev = NULL;

	EPM_decision_t decision = EPM_go;
	TIA_ErrorMessage *ErrMsgStack				= NULL;
		

	//get the root task
	iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	if( tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0 )
	{
		iRetCode = verify_Valid_PRA_Condition(msg.task,&bProRelToBeCreated,&pcValidReleaseStatusList);
	}
	else
	{
		return decision;
	}

	//if there are any ITK failure
	if ( iRetCode != ITK_ok && iRetCode != EPM_invalid_argument_value)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}

	//Conditional Task result decision
	//if ( bValidERPPlant == true && bProRelToBeCreated == true && iRetCode == ITK_ok)
	//if ( bProRelToBeCreated == true && iRetCode == ITK_ok)
	if ( iRetCode == ITK_ok && ( (bProRelToBeCreated == true && tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0 ) ))
	{
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
		if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
		{
			//get the owning site
			iRetCode = AOM_ask_value_tag(tChangeRev,"owning_site",&tSite);
			//get the root task
			iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;

			if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) && (tSite == NULLTAG) )
			{
				//get the root task name
				iRetCode = EPM_ask_name  ( tRootTask, acRootTaskName );
			}
			//read the change form and
			if(iRetCode == ITK_ok && tc_strcmp(acRootTaskName,"PRP - Prototype Release Process") == 0 )
			{
				iRetCode = tiauto_getFormAttachedToObject(tChangeRev,"T8_TI_PRP",&tChangeForm);
				if(iRetCode == ITK_ok && tChangeForm != NULLTAG)
				{
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a206newtoplevelassem",&iNewAseemCount,&ptNewAssembly);
					iRetCode = AOM_ask_value_tags(tChangeForm,"t8_t1a206componentpra",&iCompPRACount,&ptCompPRA);
				}
			}
			
			for(iCompPRAIndx = 0;iCompPRAIndx<iCompPRACount && iRetCode == 0;iCompPRAIndx++)
			{
				bPRAFoundInNewAssy = false;
				tChildComp = ptCompPRA[iCompPRAIndx] ;
				tAssmComp = 0;
				for(iNewAssyIndx = 0;iNewAssyIndx<iNewAseemCount && iRetCode == 0;iNewAssyIndx++)
				{
					tAssmComp = ptNewAssembly[iNewAssyIndx];
					if(ptCompPRA[iCompPRAIndx] == ptNewAssembly[iNewAssyIndx])
					{
						bValidtoProceed = true;
						bPRAFoundInNewAssy = true;
						break;
					}
					if(bPRAFoundInNewAssy == false)
					{
						iRetCode = verify_ChildPart_in_ParentBOM(ptCompPRA[iCompPRAIndx], ptNewAssembly[iNewAssyIndx], &bPRAFoundInNewAssy);
						if (iRetCode == 0 && bPRAFoundInNewAssy == true)
						{
							bValidtoProceed= true;
							break;
						}
					}
				}
				if (bPRAFoundInNewAssy == true)
				{
					WSOM_ask_id_string(tAssmComp,&pcParentItemrev);
					WSOM_ask_id_string(tChildComp,&pcChildItemrev);
					TI_sprintf(szErrorString, "Item revision \"%s\" mentioned in the Component PRA field is part of the assembly \"%s\" mentioned in the New Top Level Assembly field.\n" , 
													pcChildItemrev,pcParentItemrev);
					tiauto_writeErrorMsgToStack(&ErrMsgStack,TIAUTO_PRA_CREATION_PROCESS_NOT_COMPLETED ,
															szErrorString);

					SAFE_MEM_free(pcParentItemrev);
					SAFE_MEM_free(pcChildItemrev);
				}
			}
		}
	}
	if (iRetCode == 0 && bValidtoProceed == true)
	{
		iRetCode = TIAUTO_PRA_CREATION_PROCESS_NOT_COMPLETED;
		decision = EPM_nogo;
		//TI_sprintf(szErrorString, "%s","One of the component MRA found in New Assembly");
		//EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
		//TC_write_syslog(szErrorString);
	}
	if(ErrMsgStack != NULL)
	{				
		TIA_ErrorMessage *tempErrMsg = NULL;

		TI_sprintf(szErrorString,"\nThe above mentioned item revisions in the Components PRA field are part of the assemblies mentioned in the New Top Level Assembly of PRP form. Please remove these item revisions from the Components PRA field to proceed. \n");
		
		TC_write_syslog(szErrorString);
        EMH_store_error_s1(EMH_severity_error,TIAUTO_PRA_CREATION_PROCESS_NOT_COMPLETED,szErrorString);
		tempErrMsg = ErrMsgStack;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
		free( ErrMsgStack );
		ErrMsgStack = NULL;
		
	}

	SAFE_MEM_free (ptNewAssembly);
	SAFE_MEM_free (ptCompPRA);
	
	return decision;
}
