/*******************************************************************************
File         : tiauto_ah_set_initiator_approval_date.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jan 27, 2010    1.0        Dipak Naik      Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200
#define ARG_NAME     "attribute"
#define ARG_VALUE_INITIATOR     "Initiator"
#define ARG_VALUE_APPROVALDATE     "Approval Date"

//declare the function prtotypes here
int TI_GetTarget_Attachments(tag_t tRootTaskTag,tag_t *tSupplierRequestForm);

extern int t1aAUTO_set_initiator_approval_date(EPM_action_message_t msg)
{
	int       iRetCode                              = ITK_ok;
	int       iNumArgs                              = ITK_ok;
	int       i                                     = 0;
	tag_t     tInitiator                            = NULLTAG;
	tag_t     tRootTaskTag							= NULLTAG;
	tag_t     tSupplierRequestForm					= NULLTAG;
	char      acInitiatorName[SA_name_size_c+1]         = "";
	char      szErrorString[TIAUTO_error_message_len+1] = "";
	char      *pcFlag                                   = NULL;
	char      *pcValue                                  = NULL;
	char	  *pcErrMsg									= NULL;
	date_t    dDateReleased                             = NULLDATE;
	date_t    dDateInitiated                        = NULLDATE;
	logical	  lIsInitiator	= false;

	//Fetch the handler arguments
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,ARG_NAME) == 0 && pcValue != NULL)
				{
					if(tc_strcasecmp(pcValue,ARG_VALUE_INITIATOR) == 0)
					{   
						lIsInitiator = true;	
					}
					else if(tc_strcasecmp(pcValue,ARG_VALUE_APPROVALDATE) == 0)
					{
						lIsInitiator	= false;									
					}
					else
						iRetCode = EPM_invalid_argument;
				}
				else
					iRetCode = EPM_invalid_argument;
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-set-initiator-approval-date\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					
				}				
			}
			else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-set-initiator-approval-date\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }
	if(iRetCode == ITK_ok )
	{
		
		iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			//Get the target attachment. ( SupplierRequest  Form)
			iRetCode = TI_GetTarget_Attachments(tRootTaskTag, &tSupplierRequestForm);
		}
		if(iRetCode == ITK_ok && tSupplierRequestForm != NULLTAG && lIsInitiator == true )
		{
			//logic to set the initiator attribute
			iRetCode = EPM_ask_responsible_party(tRootTaskTag,&tInitiator);
			if(iRetCode == ITK_ok && tInitiator!= NULLTAG)
				iRetCode = SA_ask_user_person_name (tInitiator,acInitiatorName);
							
			if(iRetCode == ITK_ok &&  tSupplierRequestForm!= NULLTAG)
				iRetCode = AOM_set_value_string( tSupplierRequestForm, "t1a80initiator",acInitiatorName);
			if(iRetCode == ITK_ok)
				iRetCode = AOM_ask_value_date(tRootTaskTag,"creation_date",&dDateInitiated);
			if(iRetCode == ITK_ok)
				iRetCode = AOM_set_value_date(tSupplierRequestForm,"t1a80reqinitiatedon",dDateInitiated);
		}
		else if(iRetCode == ITK_ok && tSupplierRequestForm != NULLTAG && lIsInitiator == false)
		{
			if(iRetCode == ITK_ok &&  tSupplierRequestForm!= NULLTAG)
				iRetCode = AOM_ask_value_date ( tSupplierRequestForm,"date_released",&dDateReleased);
			if(iRetCode == ITK_ok)
				iRetCode = AOM_set_value_date( tSupplierRequestForm,"t1a80approvaldate",dDateReleased);
		}
		if(iRetCode == ITK_ok)
			iRetCode = AOM_save( tSupplierRequestForm);
	}
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcValue);
	return iRetCode;  
}
/*=====================================================================================
* TI_GetTarget_Attachments()
* Param:				tag_t		tRootTaskTag,			<I>
*						tag_t		* tSupplierRequestForm			<O>
*return: int
*note:		To get the tag of the
*			target attachment which is the TI_DemandForSupplier Form.
=====================================================================================*/
int TI_GetTarget_Attachments(tag_t tRootTaskTag,tag_t *tSupplierRequestForm)
{
	int               iRetCode                          =  ITK_ok;
	int               iAttachmentCnt                    = 0;
	int               i                                 = 0;
	tag_t             tTypeTag                          = NULLTAG;
	tag_t             *ptAttachments                    = NULL;
	char              acObjType[TCTYPE_name_size_c+1] = "";


	iRetCode = EPM_ask_attachments(tRootTaskTag,EPM_target_attachment,&iAttachmentCnt,&ptAttachments);
	if(iRetCode == ITK_ok)
	{
		for(i = 0; i< iAttachmentCnt;i++)
		{
			iRetCode = TCTYPE_ask_object_type(ptAttachments[i],&tTypeTag);
			if(iRetCode == ITK_ok && tTypeTag != NULLTAG)
				iRetCode = TCTYPE_ask_name(tTypeTag,acObjType);
			if(iRetCode == ITK_ok && !tc_strcmp(acObjType,"TI_SupplierRequest"))
			{
                *tSupplierRequestForm = ptAttachments[i];
				break;
			}
		}
	}
	SAFE_MEM_free(ptAttachments);
	return iRetCode;

}


