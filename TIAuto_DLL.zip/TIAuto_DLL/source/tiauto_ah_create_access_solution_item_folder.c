/*******************************************************************************
File         : tiauto_ah_create_access_solitem_rel.c

Description  : This handler is configured for a pre-condition(TIIsRelationCreationAllowed), so that 
               affected item relation creation can be stopped.
Sample Mail  :
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Feb 10, 2010    1.0        Nivedita Kamath     Initial Creation
/*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int tiauto_ah_create_access_solitem_rel(EPM_action_message_t msg)
{
   int iRetcode = ITK_ok;
	
	return iRetcode;  
}
