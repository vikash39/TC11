
/*******************************************************************************
/*******************************************************************************
File         : tiauto_rh_verify_child_comp_are_on_same_state.c

Description  : Verify whether the child components of the item revisions availabe in the solution items folder are at same or higher state (status)

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 10, 2016     1.0       	Shilpa    		 Initial Creation

*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_verify_child_comps_are_on_same_state(EPM_rule_message_t msg )
{
	int				iRetcode							= ITK_ok;
	int				iSecObjCount						= 0;
	int				iLoopSecObjCnt						= 0;
	tag_t			tRootTaskTag						= NULLTAG;	
	tag_t			tEngChangeRev						= NULLTAG;
	tag_t			*ptSecObjTags						= NULL;	
	tag_t			tRelTag								= NULLTAG;
	char			*pcErrorMsg							= NULL;
	char			*pcParentItemName					= NULL;
	logical			lisLessChildStatus					= false;
	logical			lIsValid							= true;

	EPM_decision_t decision = EPM_nogo;
		
	if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the change revision details
		if(iRetcode == ITK_ok && tRootTaskTag!= NULLTAG)
		{	
			iRetcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
			iRetcode = GRM_find_relation_type("CMHasSolutionItem", &tRelTag);
			iRetcode = GRM_list_secondary_objects_only(tEngChangeRev,tRelTag,&iSecObjCount,&ptSecObjTags);
			
			for(iLoopSecObjCnt =0; iLoopSecObjCnt < iSecObjCount; iLoopSecObjCnt++)	
			{
				lisLessChildStatus = false;
				iRetcode = WSOM_ask_id_string(ptSecObjTags[iLoopSecObjCnt], &pcParentItemName);
				iRetcode = VerifyStatusofChildItemsinBOM(ptSecObjTags[iLoopSecObjCnt],tRootTaskTag,&lisLessChildStatus,pcParentItemName);	
				
				if(lisLessChildStatus == true)
				{
					lIsValid = false;
				}

			}
			
		}
		if(lIsValid == true)
		{
			decision = EPM_go;
		}
		else if(lIsValid == false)
		{
			decision = EPM_nogo;
		}
	}	
	else if ( iRetcode != ITK_ok)
	{
		char	*pcErrMsg		= NULL;
		decision = EPM_nogo;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);	
	}
	SAFE_MEM_free(ptSecObjTags);
	SAFE_MEM_free(pcErrorMsg);
			
	return decision;

}
					
					
int	VerifyStatusofChildItemsinBOM(tag_t ptSecObjTags,tag_t tRootTaskTag,logical	*lisLessChildStatus,char* pcParentItemName)
{
	int			ibvrcount									= 0;
	int			iCount										= 0;		
	int			iNumOccs									= 0;
	int			iNoAlternates								= 0;
	tag_t		*ptBvrTags									= NULL;	
	tag_t		*ptOccs										= NULL;
	tag_t		tChildItem									= NULLTAG;
	tag_t		tChildBomView								= NULLTAG;
	tag_t		tAlternate									= NULLTAG;
	tag_t		*ptAltItems									= NULL;
	tag_t		*pAltViews									= NULL;
	int			iRetcode									= ITK_ok;
	int			_iPopulateErrMsgInStack						= 0;
	logical		lHasAlternates								= false;
	logical		lIsPrecise									= false;
	char		*szItemRevInChangeId						= NULL;
	char		szErrorString[TIAUTO_error_message_len+1]	= "";
	char		*pcChildItemName							= NULL;
	

	iRetcode = ITEM_rev_list_bom_view_revs (ptSecObjTags, &ibvrcount, &ptBvrTags);
	if(ibvrcount > 0)
	{
		iRetcode = PS_list_occurrences_of_bvr (ptBvrTags[0], &iNumOccs, &ptOccs);
		iRetcode = PS_ask_is_bvr_precise (ptBvrTags[0], &lIsPrecise);
		
		if( iRetcode != ITK_ok )
		{
			char		*pcItemRevName			= NULL;
			WSOM_ask_id_string(ptSecObjTags, &pcItemRevName);
			TI_sprintf(szErrorString, "Error while getting %s Part's BOM.", pcItemRevName);
			SAFE_MEM_free(pcItemRevName);					         		
		}
		 if( iNumOccs > 0  && (lIsPrecise == true) && iRetcode == ITK_ok) 
		{				
			for (iCount = 0; iCount < iNumOccs ; iCount++)
			{		
				iRetcode = PS_ask_occurrence_child (ptBvrTags[0], ptOccs[iCount],
												&tChildItem, &tChildBomView);
				iRetcode = WSOM_ask_id_string(tChildItem, &pcChildItemName);
			
				iRetcode = AddChildCompToTargets(tChildItem,ptSecObjTags,tChildBomView,tRootTaskTag,lisLessChildStatus,pcParentItemName,pcChildItemName);

				if(lIsPrecise == true && iRetcode == ITK_ok)
				{
					lHasAlternates = false;
					iRetcode = PS_ask_has_substitutes  (  ptBvrTags[0], ptOccs[iCount], &lHasAlternates );
					if ( iRetcode == ITK_ok && lHasAlternates == true)
					{
						iRetcode = PS_list_substitutes (ptBvrTags[0],ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews);
					
						if(iRetcode == ITK_ok && iNoAlternates > 0)
						{
							int		iAltCount			= 0;
							for (iAltCount = 0; (iAltCount < iNoAlternates);iAltCount++)
							{
								int		ialtbvrcount		= 0;
								tag_t	*ptaltBvrTags		= NULL;
								tAlternate = ptAltItems[iAltCount];
								iRetcode = ITEM_rev_list_bom_view_revs (tAlternate, &ialtbvrcount, &ptaltBvrTags);
								if(tAlternate != NULLTAG && iRetcode == ITK_ok &&  ialtbvrcount > 0)
								{
									iRetcode = VerifyStatusofChildItemsinBOM(tAlternate,tRootTaskTag,lisLessChildStatus,pcParentItemName);
								}
								else if(tAlternate != NULLTAG && iRetcode == ITK_ok && ialtbvrcount <= 0)
								{
									iRetcode = AddChildCompToTargets(tAlternate,ptSecObjTags,tChildBomView,tRootTaskTag,lisLessChildStatus,pcParentItemName,pcChildItemName);
								}

								SAFE_MEM_free(ptaltBvrTags);
							}
						}
					}
				}
				
			}
			
		}
	}


	SAFE_MEM_free(ptBvrTags);
	SAFE_MEM_free(ptOccs);
	SAFE_MEM_free(ptAltItems);
	SAFE_MEM_free(pAltViews);
	SAFE_MEM_free(szItemRevInChangeId);
	
	return iRetcode;
}
					
int	AddChildCompToTargets(tag_t	tChildItem,tag_t ptSecObjTags,tag_t	tChildBomView,tag_t	tRootTaskTag,logical *lisChildStatus,char* pcParentItemName,char* pcChildItemName)
{
	
	char    szReleaseStatus[WSO_name_size_c+1]		= "";
	char    szChildRelStatus[WSO_name_size_c+1]		= "";
	int		iLoopPref								= 0;
	int		iRetcode								= ITK_ok;
	char	acTempError[TIAUTO_error_message_len+1] = "";

	STATUS_Struct_t    StatusProgression;
    TARGET_RELEASE_Struct_t TargetReleaseStatus;
    TARGET_RELEASE_Struct_t ChildReleaseStatus;	

	if ( iRetcode == ITK_ok && tChildItem != NULLTAG)
	{
		tiauto_initialize_status_progression_stuct(&StatusProgression);

		iRetcode = tiauto_get_status_progression_array(&StatusProgression);

		iRetcode = tiauto_get_release_status(ptSecObjTags,szReleaseStatus);

		tc_strcpy(TargetReleaseStatus.szTargetReleaseStatus,szReleaseStatus);
		TargetReleaseStatus.iLevel = tiauto_status_progression_index(TargetReleaseStatus.szTargetReleaseStatus, StatusProgression );
						
		for(iLoopPref =0; iLoopPref < StatusProgression.iCount; iLoopPref++)
		{
			iRetcode = tiauto_get_release_status(tChildItem,szChildRelStatus);	

			tc_strcpy(ChildReleaseStatus.szTargetReleaseStatus,szChildRelStatus);
			ChildReleaseStatus.iLevel = tiauto_status_progression_index(ChildReleaseStatus.szTargetReleaseStatus, StatusProgression );
		
			if(ChildReleaseStatus.iLevel >= TargetReleaseStatus.iLevel)
			{
				*lisChildStatus= false;	
			}
			else
			{			
				*lisChildStatus= true;	
				tc_strcpy(acTempError,"");
				TI_sprintf( acTempError,"The child component \"%s\" which is at \"%s\" status is lower than the Parent item \"%s\" having \"%s\" status \n",pcChildItemName,szChildRelStatus,pcParentItemName,szReleaseStatus);
				EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_VALID_SAME_STATE,acTempError);	
				break;
			}
		}
		
		if(tChildBomView != NULLTAG)
		{
			iRetcode = VerifyStatusofChildItemsinBOM(tChildItem,tRootTaskTag,lisChildStatus,pcParentItemName);
		}
	}
	return iRetcode;
}