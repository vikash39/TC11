/***********************************************************************************************************************************************
FILE        :   TIAUTO_check_mandatry_attribute_state.c
Details     :   This handler perform check weather all the mandatory atriutes of affected programs Item revision master forms are filled or not.

REVISION HISTORY :
------------------------------------------------------------------------------------------------------------------------------------
Date              Revision        Who						Description
------------------------------------------------------------------------------------------------------------------------------------
July  4, 2016     1.0			  Dipak Naik				Initial Creation.
************************************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

static int Validate_change_form_mandatory_Attributes(tag_t	tForm,EPM_decision_t *decision)
{
	int				iny = 0;
	int				iNumProp = 0;
	int				iRetCode = ITK_ok;
	char			acTypeName[TCTYPE_name_size_c+1]="";
	char			**ptProp_names = NULL;
	char			*pcPropReq = NULL;
    char			acTempError[TIAUTO_error_message_len+1]= "";
	logical			lPropEmpty = true;
	logical			lHasEmptyProp = false;
	char			*pcAttrDisplayName = NULL;
	char			*pcFormName = NULL;
	tag_t			tType = NULLTAG;
	
	iRetCode = WSOM_ask_name2(tForm,&pcFormName);

	iRetCode = TCTYPE_ask_object_type  (tForm,&tType);
	if(iRetCode == ITK_ok )
		iRetCode = TCTYPE_ask_name  (tType,acTypeName);  

	if(iRetCode == ITK_ok )
		iRetCode = AOM_ask_prop_names(tForm,&iNumProp,&ptProp_names); 									
	//Check Required Item revision master form property filled or not 
	for(iny = 0; iny < iNumProp && (iRetCode == ITK_ok); iny++)
	{
		iRetCode = CONSTANTS_get_property_constant_value( PROPERTY_CONST_REQUIRED,acTypeName,ptProp_names[iny], &pcPropReq); 
		if(iRetCode == ITK_ok && tc_strcasecmp(pcPropReq,"true")== 0 )
		{
			iRetCode = AOM_is_null_empty(tForm,  ptProp_names[iny],true,&lPropEmpty);
			if(iRetCode == ITK_ok && lPropEmpty==true)
			{
				lHasEmptyProp = true;
				if(iRetCode == ITK_ok)
					iRetCode = AOM_UIF_ask_name  ( tForm, ptProp_names[iny],  &pcAttrDisplayName ) ;
				if(iRetCode == ITK_ok && pcAttrDisplayName != NULL)
				{
					acTempError[0]='\0';
					TI_sprintf( acTempError,"%s\n",pcAttrDisplayName);
					EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY,acTempError);																							
				}
				SAFE_MEM_free(pcAttrDisplayName);
			}
		}
		SAFE_MEM_free(pcPropReq);
	}

	if(iRetCode == ITK_ok && lHasEmptyProp==true)
	{
		*decision = EPM_nogo;
		TI_sprintf( acTempError,"\nFollowing attributes of %s are not filled. Please fill the form.\n",pcFormName);
		EMH_store_error_s1(EMH_severity_error,TIAUTO_NOT_FILLED_REQUIRED_PROPERTY,acTempError);	
	}
	
	return iRetCode;
}
//main method
EPM_decision_t TIAUTO_RH_check_change_form_mandatory_attributes(EPM_rule_message_t msg)
{
	int				iArg = 0;
	int				iNumArgs = 0;
    int				iRetCode = ITK_ok;
	int				iNumAttachments = 0;
	int				indx			= 0;
    char			*pcFlag = NULL;
	char			*pcValue = NULL;
	char			*szErrMsg = NULL;
	char			*pcTarget = NULL;
	char			*pcTaskTypeName = NULL;
	char			*pcUserName = NULL;
	tag_t			tUser = NULL_TAG;
	tag_t			tTaskType = NULLTAG;
	tag_t			tRootTask = NULLTAG;
	tag_t			*ptAttachments = NULL;	
	tag_t			tForm	= NULLTAG;
	EPM_decision_t	decision = EPM_go;	
	char                acObjectType[WSO_name_size_c+1] = "";
	tag_t	tGroupmember = NULLTAG;
	tag_t tGroup = NULLTAG;
	char          acUserGroup[SA_group_name_size_c + 1] = "";
	
	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_current_groupmember(&tGroupmember);

	
	if(iRetCode == ITK_ok && tGroupmember != NULLTAG)
		iRetCode = SA_ask_groupmember_group(tGroupmember, &tGroup);

	if(iRetCode == ITK_ok && tGroup != NULLTAG)
	    iRetCode = SA_ask_group_name(tGroup, acUserGroup);

	if(tc_strcmp(acUserGroup,"dba") == 0)
	{
		decision = EPM_go;
		return decision;
	}

	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask);	
		if ( iRetCode==ITK_ok && tRootTask!=NULLTAG )
		{
			//get input arguments
			iNumArgs = TC_number_of_arguments(msg.arguments);
			if(iNumArgs>0)
			{
				for(iArg = 0; (iArg < iNumArgs) && (iRetCode==ITK_ok) ; iArg++)
				{
					iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue);
					if(iRetCode == ITK_ok)
					{					
						if( tc_strcasecmp(pcFlag, "form_type") == 0 && pcValue != NULL)
						{
							pcTarget = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
							tc_strcpy( pcTarget, pcValue);							
						}
					}
					SAFE_MEM_free(pcFlag);
					SAFE_MEM_free(pcValue);
				}
			}

			//get the targeted object
			if(iRetCode == ITK_ok)
			{
				
					//get the targeted form type
					iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
					if (iRetCode == ITK_ok)
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iNumAttachments, &ptAttachments);

					for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
					{
						iRetCode = WSOM_ask_object_type(ptAttachments[indx], acObjectType);
						//if( DEBUG_PRINT ) printf("\n WSO type - tiauto_get_change_item_rev : %s\n", acObjectType);
						if (iRetCode == ITK_ok &&  (tc_strcmp (acObjectType, pcTarget) == 0 ) )
						{
							tForm = ptAttachments[indx];
							break;  // there should be only one change rev in target objects.
						}
					}
					
					if(tForm != NULLTAG)
						iRetCode = Validate_change_form_mandatory_Attributes(tForm, &decision);
				
				
			}			
		}  
	}

	if (iRetCode != ITK_ok)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &szErrMsg);
		TC_write_syslog(szErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg);		
		SAFE_MEM_free (szErrMsg);
	}
	if(decision==EPM_nogo)
	{
		iRetCode=TIAUTO_NOT_FILLED_REQUIRED_PROPERTY;
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
	}
	
	
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);

	return decision;
}