/***********************************************************************************************************************************************
FILE        :   TIAUTO_check_mandatry_attribute_state.c
Details     :   This handler perform check weather all the mandatory atriutes of affected programs Item revision master forms are filled or not.

REVISION HISTORY :
------------------------------------------------------------------------------------------------------------------------------------
Date              Revision        Who						Description
------------------------------------------------------------------------------------------------------------------------------------
July  4, 2016     1.0			  Dipak Naik				Initial Creation.
************************************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

//main method
EPM_decision_t TIAUTO_RH_check_plant_value_in_changetiming_and_pci(EPM_rule_message_t msg)
{
    int				iRetCode = ITK_ok;

	char			*szErrMsg = NULL;	
	char			*pcTaskTypeName = NULL;
	char			*pcUserName = NULL;

	tag_t			tUser = NULL_TAG;
	tag_t			tTaskType = NULLTAG;
	tag_t			tRootTask = NULLTAG;		

	EPM_decision_t	decision = EPM_go;
	tag_t	tGroupmember = NULLTAG;
	tag_t tGroup = NULLTAG;
	char          acUserGroup[SA_group_name_size_c + 1] = "";
		
	int iPlantCnt = 0;
	
	char **pcPlants = NULL;
	tag_t tEngChangeRev = NULLTAG;
	tag_t tPCI = NULLTAG;
	tag_t tChaneTiming = NULLTAG;
	char *pcPCIValue = NULL;
	char *pcChangeTimingValue = NULL;

	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_current_groupmember(&tGroupmember);


	if(iRetCode == ITK_ok && tGroupmember != NULLTAG)
		iRetCode = SA_ask_groupmember_group(tGroupmember, &tGroup);

	if(iRetCode == ITK_ok && tGroup != NULLTAG)
	    iRetCode = SA_ask_group_name(tGroup, acUserGroup);



	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask);
		if ( iRetCode==ITK_ok && tRootTask!=NULLTAG )
		{
			iRetCode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
			if(tEngChangeRev != NULLTAG)
			{
				iRetCode = tiauto_getFormAttachedToObject(tEngChangeRev,"T8_TI_PCI",&tPCI);
				iRetCode = tiauto_getFormAttachedToObject(tEngChangeRev,"T8_TI_ChangeTiming",&tChaneTiming);
			}
			//get the targeted object
			if(iRetCode == ITK_ok && tChaneTiming != NULLTAG && tPCI != NULLTAG)
			{
				iRetCode = AOM_ask_value_strings(tChaneTiming,"t8_t1a188affectedplants",&iPlantCnt,&pcPlants);
				if(iPlantCnt > 1)
				{
					decision = EPM_nogo;
					EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PLANT_ATTRIBUTE_VALUE, "More than one Affected Plants are mentioned Change Timing form.") ;

					return decision;
				}

				iPlantCnt = 0;

				iRetCode = AOM_ask_value_strings(tPCI,"t8_t1a123affectedplant",&iPlantCnt,&pcPlants);
				if(iPlantCnt > 1)
				{
					decision = EPM_nogo;
					EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PLANT_ATTRIBUTE_VALUE, "More than one Affected Plants are mentioned PCI form.") ;

					return decision;
				}



				if(tPCI != NULLTAG)
				{
					iRetCode = AOM_UIF_ask_value(tPCI,"t8_t1a123affectedplant",&pcPCIValue);


					iRetCode = AOM_UIF_ask_value(tChaneTiming,"t8_t1a188affectedplants",&pcChangeTimingValue);

					if(pcPCIValue != NULL &&  pcChangeTimingValue != NULL && tc_strcmp(pcPCIValue,pcChangeTimingValue) != 0)
					{
						decision = EPM_nogo;
						EMH_store_error_s1( EMH_severity_error, TIAUTO_PLANT_ATTRIBUTE_VALUE_MISMATCH, "Affected Plant value mentioned in PCI form and Change Timing form are not same.") ;
					}


				}


			}
		}
	}

	if (iRetCode != ITK_ok)
	{
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &szErrMsg);
		TC_write_syslog(szErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg);
		SAFE_MEM_free (szErrMsg);
	}



	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);

	return decision;
}