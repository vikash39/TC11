/*******************************************************************************************************************
File         : tiauto_user_query.c

Description  : This file implements the logic for query "Item Revision - Any Part Number". It searches the part number 
				in the following fields and returns the matching item revisions.
				1) item id
				2) item description
				3) item revision description
				4) item name
				5) dataset name
				6) dataset description
				7) legacy info (part no, part description, part name)
				8) Alternate id
				9) Alternate Description
				10) IFS_CATPart_query search
				11) Dataset named Reference
				13) Supplier Part Number in PurchasedCost form
				14) Supplier Part Name in PurchasedCost form
				15) Supplier Part Description in PurchasedCost form

Input        : None

Output       : None

Author       : TCS

Revision History :
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
12 Jan 2011		1.0			Nivedita K			Initial Creation     
02 Feb 2011		1.1			Dipak Naik			Modified the code for the query and input field name change
												and also for the case insensitive search.
04 Feb 2011		1.2			Dipak Naik			Added the code to search the part number in the dataset named
												reference and the attributes "Supplier part Number", 
												"Supplier Part name" and "Supplier Part Description" of the
												TI_PurchasedCost form.
07 Apr 2012		1.3			Mahesh B.S			Added the code to search the change items form affected programs in forms.
05 Feb 2013		1.4			Mahesh B.S          Added the code to sort Item-Any part number and Item revision - Any part number search
07 Feb 2014     1.5         Pradeep M           Added the code to search Document ID in Find_partner_submission_data query.
21 Feb 2014     1.6         Pradeep M           Added the code to search assemblies having substitute parts
19 May 2014     1.6         Pradeep M           Added the code to search Parts by Customer info.
19 Nov 2015     1.7         Pradeep M           Added new functions "TIAUTO_find_change" for "  TI Change" user query and
												"TIAUTO_find_change_rev" for " TI Change Rev" user query.
26 Jun 2016     1.8         Pradeep M           Updated "TIAUTO_find_change" and "TIAUTO_find_change_rev" to implement logic for 
												NEW_CAP, NEW_CCR, NEW_PMR and STD forms, also included new property "ProductGroup".
13 Jan 2017		1.9			Kantesh				Added new functions "TIAUTO_find_OEM" for "TI OEM Part" user query and
												"TIAUTO_find_OEM_rev" for "TI OEM Part Rev" user query.
17 Jan 2017		1.10		Kantesh				Added new functions "TIAUTO_find_Doc" for "TI Document Item" user query and
												"TIAUTO_find_Doc_rev" for "TI Document Item Rev" user query.												
7 Jun 2017		2.0		Shilpa				    Added new function "TIAUTO_find_WorkSpaceObject" for "Find Objects Based On UIDs" user query
Nov 23 2018		2.1		Jugunu                  Updated for ER 9759 CAP3
27 Feb 2019     2.2		Shruti					Updated search query for affected programs change - CAP & PMR
******************************************************************************************************************/
#include <tiauto_user_query.h>

int     itagscnt                = 0;
extern int check_for_child_items(tag_t tItemRev,tag_t **ptfound_childtags, int *piTotal_tags_found);
/*=============================================================================================================
*		t1aAUTO_register_user_query()
*\param				int *decision						<I>
*					va_list args						<O>
*\return int				
* Description:
*			Implements the the logic for the registered user query.
================================================================================================================*/
int t1aAUTO_register_user_query (int *decision, va_list args )
{
    int ifail = ITK_ok;
	const char *name = NULL;
	int num_args = 0;
	char **names = NULL;
	char **values = NULL;
	int *num_found = NULL;
	tag_t **found = NULL;
    *decision  = ALL_CUSTOMIZATIONS;

	name = va_arg(args,char *);
	num_args = va_arg(args,int);
	names = va_arg(args,char **);
	values = va_arg(args,char **);
	num_found = va_arg(args,int *);
	found = va_arg(args,tag_t **);


    BMF_EXECUTE_USER_EXIT_EXTENSIONS(("ImanQuery", "", QRY_custom_execute_msg, name, num_args, names, values, num_found, found));
	ifail = CUSTOM_execute_callbacks ( decision, "t1aAUTO_register_user_query", name, num_args, names, values, num_found, found );
    if ( ifail != ITK_ok || *decision != ALL_CUSTOMIZATIONS )
    {
        return ifail;
    }
	if(tc_strcmp(name,"Item Revision - Any Part Number") == 0)
	{
		ifail = TIAUTO_item_rev_any_part_number(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"Item - Any Part Number") == 0)
	{
		ifail = TIAUTO_item_any_part_number(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"Tasks by Assigned User") == 0)
	{
		ifail = TIAUTO_find_tasks_assigned_to_users(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Change (Affected Programs)") == 0)
	{
		ifail = TIAUTO_find_change_affected_programs(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"Partner Submission Data (Documents)") == 0)
	{
		ifail = TIAUTO_find_partner_submission_documents(name, num_args,names, values, num_found, found);
	}
    else if(tc_strcmp(name,"Find Assembly having substitute parts") == 0)
	{
		ifail = TIAUTO_find_assembly_having_substitute_parts(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI Product Rev (Program Attributes)") == 0)
	{
		ifail = TIAUTO_find_parts_by_customer_info(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI Change Rev (Affected Programs)") == 0)
	{
		ifail = TIAUTO_find_change_rev_affected_programs(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Change") == 0)
	{
		ifail = TIAUTO_find_change(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Change Rev") == 0)
	{
		ifail = TIAUTO_find_change_rev(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Change (CAP Form)") == 0)
	{
		ifail = TIAUTO_find_CAP_change(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI Change Rev (CAP Form)") == 0)
	{
		ifail = TIAUTO_find_CAP_change_rev(name, num_args,names, values, num_found, found);
	}	
	else if(tc_strcmp(name," TI Change (PMR Form)") == 0)
	{
		ifail = TIAUTO_find_PMR_change(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI Change Rev (PMR Form)") == 0)
	{
		ifail = TIAUTO_find_PMR_change_rev(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI OEM Part") == 0)
	{
		ifail = TIAUTO_find_OEM(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI OEM Part Rev") == 0)
	{
		ifail = TIAUTO_find_OEM_rev(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Document Items") == 0)
	{
		ifail = TIAUTO_find_Doc(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,"TI Document Item Rev") == 0)
	{
		ifail = TIAUTO_find_Doc_rev(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name,TIAUTO_Find_Obj_BasedOn_UID)==0)
	{
		ifail = TIAUTO_Find_WorkspaceObject(name, num_args,names, values, num_found, found);
	}
	else if(tc_strcmp(name," TI Change (CCR Form)")==0)
	{
		ifail = TIAUTO_find_CCR_change(name, num_args,names, values, num_found, found);
	}	
	else if(tc_strcmp(name,"TI Change Rev (CCR Form)")==0)
	{
		ifail = TIAUTO_find_CCR_change_rev(name, num_args,names, values, num_found, found);
	}
	return ifail;
}

/*=============================================================================================================
*		TIAUTO_item_rev_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "TI_Super_Search" user query.
================================================================================================================*/
int TIAUTO_item_rev_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int ifail								= ITK_ok;
	int	indx								= 0;
	int iArgIndex							= 0;
	int j									= 0;
	int k                                   = 0;
	int iNumInAltIdFound					= 0;
	int iNumInAltNameFound					= 0;
	int iNumInAltIdDescFound				= 0;
	int iNumInDatasetNameFound				= 0;
	int iNumInDatasetDescFound				= 0;
	int iNumInLegaryPartNumFound			= 0;
	int iNumInLegaryPartDescFound			= 0;
	int iNumInItemIdFound					= 0;
	int iNumInItemNameFound					= 0;
	int iNumInItemDescFound					= 0;
	int iNumInItemRevDescFound				= 0;
	int iNumInLegaryPartNameFound			= 0;
	int iNumTotalTags						= 0;
	int iNumInDatasetNamedRefFound			= 0;
	int iNumInPurchSuppPartNumFound			= 0;
	int iNumInPurchSuppPartDescFound		= 0;
	int iNumInPurchSuppPartNameFound		= 0;
	int iNumInPartNumFound					= 0;
	int iNumInDocNumFound					= 0;
	int iCount                              = 0;	
	int iNumInPartnerCADFileNameFound		= 0;
	int iNumInPartnerCADPartNameFound		= 0;
	int iNumInPartnerCADPartNumberFound		= 0;

	char acKeywordVal[1024]	= {'\0'};
	char acKeywordValTemp[1024]	= {'\0'};
	char szErrorString[TIAUTO_error_message_len+1]	= "";
	char pcClassName[50]				            = {'\0'};
    
	char    **pszDelimiter  = NULL; 
    TC_preference_search_scope_t tScope;
	
	tag_t *tInAltIdfound					= NULL;
	tag_t *tInAltNamefound					= NULL;
	tag_t *tInAltIdDescfound				= NULL;
	tag_t *tInLegaryNamefound				= NULL;
	tag_t *tInItemIdIdfound					= NULL;
	tag_t *tInItemNamefound					= NULL;
	tag_t *tInItemDescfound					= NULL;
	tag_t *tInItemRevDescfound				= NULL;	
	tag_t *tInDatasetNamefound				= NULL;
	tag_t *tInDatasetDescfound				= NULL;
	tag_t *tInLegaryPartNumfound			= NULL;
	tag_t *tInLegaryDescfound				= NULL;
	tag_t *tInDatasetNamedReffound			= NULL;
	tag_t *tInPurchSuppPartNumfound			= NULL;
	tag_t *tInPurchSuppDescfound			= NULL;
	tag_t *tInPurchSuppNamefound			= NULL;
	tag_t *tInPartNumfound					= NULL;
	tag_t *tInDocNumfound					= NULL;
	tag_t *tInPartnerCADFileNamefound		= NULL;
	tag_t *tInPartnerCADPartNamefound		= NULL;
	tag_t *tInPartnerCADPartNumberfound		= NULL;
	
	int				z = 0;
	int				i = 0;	
	char			acRev_id_1[ITEM_id_size_c + 1] = ""; 
	char			acRev_id_2[ITEM_id_size_c + 1] = ""; 
	char			acItem_1[ITEM_id_size_c + 1] = "";
	char			acItem_2[ITEM_id_size_c + 1] = "";
	tag_t			tTemp	= NULLTAG;
	tag_t			tItem_1 = NULLTAG;
	tag_t			tItem_2 = NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects = NULL;
	TIA_UniqueWSOMObjects *tempObjects = NULL;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
	
    
	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"Item Revision - Any Part Number") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.
			if ( tc_strcasecmp(names[iArgIndex], "Part Number") == 0 )
			{
			    // Get the preference value for delimiter				
				ifail = PREF_ask_search_scope( &tScope );
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( TC_preference_site );
				if (ifail == ITK_ok)
				{
					ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
					if (ifail != ITK_ok)
					{
						TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
						ifail = TIAUTO_DELIMITER_NOT_FOUND;
					}
				}
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( tScope );
			    //value entered in the search field is passed to a function that will split the delimted string 
			    // and store it in a structure
				ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);
					
				for(k = 0; k< sDelimitedKey.iCount;k++)
			    {
				    //Initialise all integers to 0 so that it does not try to store a nulltag
					 iNumInAltIdFound					= 0;
					 iNumInAltNameFound					= 0;
					 iNumInAltIdDescFound				= 0;
					 iNumInDatasetNameFound				= 0;
					 iNumInDatasetDescFound				= 0;
					 iNumInLegaryPartNumFound			= 0;
					 iNumInLegaryPartDescFound			= 0;
					 iNumInItemIdFound					= 0;
					 iNumInItemNameFound				= 0;
					 iNumInItemDescFound				= 0;
					 iNumInItemRevDescFound				= 0;
					 iNumInLegaryPartNameFound			= 0;
					 iNumInDatasetNamedRefFound			= 0;
					 iNumInPurchSuppPartNumFound		= 0;
					 iNumInPurchSuppPartDescFound		= 0;
					 iNumInPurchSuppPartNameFound		= 0;
					 //Perform the check for presence of keyword in Alt Id
						tc_strcpy(acKeywordValTemp,sDelimitedKey.StatusArray[k]);
						ifail = IsPresentInAltId(acKeywordValTemp,&iNumInAltIdFound,&tInAltIdfound);
						for(j = 0; j < iNumInAltIdFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltIdfound[j]);
						}
						SAFE_MEM_free(tInAltIdfound);
						//Perform the check for presence of keyword in Alt Name
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInAltIdName(acKeywordValTemp,&iNumInAltNameFound,&tInAltNamefound);
						for(j = 0; j < iNumInAltNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltNamefound[j]);
						}
						SAFE_MEM_free(tInAltNamefound);
						//Perform the check for presence of keyword in Alt Description
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInAltIdDescription(acKeywordValTemp,&iNumInAltIdDescFound,&tInAltIdDescfound);
						for(j = 0; j < iNumInAltIdDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltIdDescfound[j]);
						}
						SAFE_MEM_free(tInAltIdDescfound);
						//Perform the check for presence of keyword in dataset name
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInDatasetName(acKeywordValTemp,&iNumInDatasetNameFound,&tInDatasetNamefound);
						for(j = 0; j < iNumInDatasetNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetNamefound[j]);
						}
						SAFE_MEM_free(tInDatasetNamefound);
						//Perform the check for presence of keyword in dataset description
						 j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInDatasetDescription(acKeywordValTemp,&iNumInDatasetDescFound,&tInDatasetDescfound);
						for(j = 0; j < iNumInDatasetDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetDescfound[j]);
						}
						SAFE_MEM_free(tInDatasetDescfound);
						//Perform the check for presence of keyword in dataset named reference
						 j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInDatasetNamedRef(acKeywordValTemp,&iNumInDatasetNamedRefFound,&tInDatasetNamedReffound);
						for(j = 0; j < iNumInDatasetNamedRefFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetNamedReffound[j]);
						}
						SAFE_MEM_free(tInDatasetNamedReffound);
						//Perform the check for presence of keyword in legacy part number
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInLegacyPartNum(acKeywordValTemp,&iNumInLegaryPartNumFound,&tInLegaryPartNumfound);
						for(j = 0; j < iNumInLegaryPartNumFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryPartNumfound[j]);
						}
						SAFE_MEM_free(tInLegaryPartNumfound);
						//Perform the check for presence of keyword in legacy part description
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInLegacyPartDesc(acKeywordValTemp,&iNumInLegaryPartDescFound,&tInLegaryDescfound);
						for(j = 0; j < iNumInLegaryPartDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryDescfound[j]);
						}
						SAFE_MEM_free(tInLegaryDescfound);
						//Perform the check for presence of keyword in legacy part name
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInLegacyPartName(acKeywordValTemp,&iNumInLegaryPartNameFound,&tInLegaryNamefound);
						for(j = 0; j < iNumInLegaryPartNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryNamefound[j]);
						}
						SAFE_MEM_free(tInLegaryNamefound);
						//Perform the check for presence of keyword in item id
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInItemId(acKeywordValTemp,&iNumInItemIdFound,&tInItemIdIdfound);
						for(j = 0; j < iNumInItemIdFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemIdIdfound[j]);
						}
						SAFE_MEM_free(tInItemIdIdfound);
						//Perform the check for presence of keyword in item name
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInItemName(acKeywordValTemp,&iNumInItemNameFound,&tInItemNamefound);
						for(j = 0; j < iNumInItemNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemNamefound[j]);
						}
						SAFE_MEM_free(tInItemNamefound);
						//Perform the check for presence of keyword in item description
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInItemDesc(acKeywordValTemp,&iNumInItemDescFound,&tInItemDescfound);
						for(j = 0; j < iNumInItemDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemDescfound[j]);
						}
						SAFE_MEM_free(tInItemDescfound);
						//Perform the check for presence of keyword in item rev description
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInItemRevDesc(acKeywordValTemp,&iNumInItemRevDescFound,&tInItemRevDescfound);
						for(j = 0; j < iNumInItemRevDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemRevDescfound[j]);
						}
						SAFE_MEM_free(tInItemRevDescfound);
						
						//Perform the check for presence of keyword in Supplier part number of the PurchasedCost form
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInPurchSuppPartNum(acKeywordValTemp,&iNumInPurchSuppPartNumFound,&tInPurchSuppPartNumfound);
						for(j = 0; j < iNumInPurchSuppPartNumFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppPartNumfound[j]);
						}
						SAFE_MEM_free(tInPurchSuppPartNumfound);
						//Perform the check for presence of keyword in Supplier part description of the PurchasedCost Form
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInPurchSuppPartDesc(acKeywordValTemp,&iNumInPurchSuppPartDescFound,&tInPurchSuppDescfound);
						for(j = 0; j < iNumInPurchSuppPartDescFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppDescfound[j]);
						}
						SAFE_MEM_free(tInPurchSuppDescfound);
						//Perform the check for presence of keyword in Supplier part name of the PurchasedCost Form
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInPurchSuppPartName(acKeywordValTemp,&iNumInPurchSuppPartNameFound,&tInPurchSuppNamefound);
						for(j = 0; j < iNumInPurchSuppPartNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppNamefound[j]);
						}
						SAFE_MEM_free(tInPurchSuppNamefound);

						//Perform the IFS_CATPart_query to find the keyword
						j = 0;
						if(ifail == ITK_ok)
							ifail = IsPresentInIFSCATPart(acKeywordValTemp,&iNumTotalTags,&UniqueObjects);		

						//Perform the check for presence of keyword in Partner Submission Form Part Number
						j = 0;
						for( i = 0; i< 10; i++)    
						{
							if (i == 0) tc_strcpy (pcClassName, "t8_116PDE");
							if (i == 1) tc_strcpy (pcClassName, "t1a98MeetingMin_DocRevMstr");
							if (i == 2) tc_strcpy (pcClassName, "t1a62T_PPAP_DocRevMaster");
							if (i == 3) tc_strcpy (pcClassName, "t1a64Lessons_DocRevMaster");
							if (i == 4) tc_strcpy (pcClassName, "t1a75PurcNotes_DocRevMaster");
							if (i == 5) tc_strcpy (pcClassName, "t1a113PurPrtsBOM_DocRevMstr");
							if (i == 6) tc_strcpy (pcClassName, "t1a87SrcDecisn_DocRevMaster");
							if (i == 7) tc_strcpy (pcClassName, "t1a81SuppAudit_DocRevMaster");
							if (i == 8) tc_strcpy (pcClassName, "T8_t1a132SupplierCR_RevMast");
							if (i == 9) tc_strcpy (pcClassName, "t1a69SuppRFQ_DocRevMaster");

							if(ifail == ITK_ok)
								ifail = IsPresentInPartnerSubmissionPartNum(acKeywordValTemp,pcClassName,&iNumInPartNumFound,&tInPartNumfound);
							for(j = 0; j < iNumInPartNumFound;j++)
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartNumfound[j]);
							}
							SAFE_MEM_free(tInPartNumfound);
							iNumInPartNumFound = 0;

							// Emptying the pcClassName char array
							// memset(pcClassName, 0, sizeof(char ) * 50);
							tc_strcpy (pcClassName,"");
						}

						//Perform the check for presence of keyword in Partner Submission Form Document Number
						j = 0;
						for( i = 0; i< 10; i++)    
						{
							if (i == 0) tc_strcpy (pcClassName, "t8_116PDE");
							if (i == 1) tc_strcpy (pcClassName, "t1a98MeetingMin_DocRevMstr");
							if (i == 2) tc_strcpy (pcClassName, "t1a62T_PPAP_DocRevMaster");
							if (i == 3) tc_strcpy (pcClassName, "t1a64Lessons_DocRevMaster");
							if (i == 4) tc_strcpy (pcClassName, "t1a75PurcNotes_DocRevMaster");
							if (i == 5) tc_strcpy (pcClassName, "t1a113PurPrtsBOM_DocRevMstr");
							if (i == 6) tc_strcpy (pcClassName, "t1a87SrcDecisn_DocRevMaster");
							if (i == 7) tc_strcpy (pcClassName, "t1a81SuppAudit_DocRevMaster");
							if (i == 8) tc_strcpy (pcClassName, "T8_t1a132SupplierCR_RevMast");
							if (i == 9) tc_strcpy (pcClassName, "t1a69SuppRFQ_DocRevMaster");

							if(ifail == ITK_ok)
								ifail = IsPresentInPartnerSubmissionDocNum(acKeywordValTemp,pcClassName,&iNumInDocNumFound,&tInDocNumfound);
							for(j = 0; j < iNumInDocNumFound;j++)
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDocNumfound[j]);
							}
							SAFE_MEM_free(tInDocNumfound);
							iNumInDocNumFound = 0;

							// Emptying the pcClassName char array
							// memset(pcClassName, 0, sizeof(char ) * 50);
							tc_strcpy (pcClassName,"");
						}
						
						//Perform the check for presence of keyword in filename field of the PartnerCADImportForm
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInPartnerCADFileName(acKeywordValTemp,&iNumInPartnerCADFileNameFound,&tInPartnerCADFileNamefound);
						for(j = 0; j < iNumInPartnerCADFileNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADFileNamefound[j]);
						}
						SAFE_MEM_free(tInPartnerCADFileNamefound);
						//Perform the check for presence of keyword in partname field of the PartnerCADImportForm
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInPartnerCADPartName(acKeywordValTemp,&iNumInPartnerCADPartNameFound,&tInPartnerCADPartNamefound);
						for(j = 0; j < iNumInPartnerCADPartNameFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADPartNamefound[j]);
						}
						SAFE_MEM_free(tInPartnerCADPartNamefound);
						//Perform the check for presence of keyword in partnumber field of the PartnerCADImportForm
						j = 0;
						if(ifail == ITK_ok )
							ifail = IsPresentInPartnerCADPartNumber(acKeywordValTemp,&iNumInPartnerCADPartNumberFound,&tInPartnerCADPartNumberfound);
						for(j = 0; j < iNumInPartnerCADPartNumberFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADPartNumberfound[j]);
						}
						SAFE_MEM_free(tInPartnerCADPartNumberfound);
				
					}
				
			}
		}
		//total no. of out result count		
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
         	UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}
		//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				ifail = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!ifail)
					ifail = ITEM_ask_id(tItem_1, acItem_1);
				if(!ifail)
				{
					ifail = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!ifail)
						ifail = ITEM_ask_id(tItem_2, acItem_2);
					if(!ifail)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							ifail = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!ifail)
								ifail = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!ifail)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

		tiauto_clearTagStack(UniqueObjects);				
	}
	

	return ifail;
}

/*=============================================================================================================
*		TIAUTO_item_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "TI_Super_Search" user query.
================================================================================================================*/
int TIAUTO_item_any_part_number(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int ifail								= ITK_ok;
	int	indx								= 0;
	int iArgIndex							= 0;
	int j									= 0;
	int iNumInAltIdFound					= 0;
	int iNumInAltNameFound					= 0;
	int iNumInAltIdDescFound				= 0;
	int iNumInDatasetNameFound				= 0;
	int iNumInDatasetDescFound				= 0;
	int iNumInLegaryPartNumFound			= 0;
	int iNumInLegaryPartDescFound			= 0;
	int iNumInItemIdFound					= 0;
	int iNumInItemNameFound					= 0;
	int iNumInItemDescFound					= 0;
	int iNumInItemRevDescFound				= 0;
	int iNumInLegaryPartNameFound			= 0;
	int iNumTotalTags						= 0;
	int iNumInDatasetNamedRefFound			= 0;
	int iNumInPurchSuppPartNumFound			= 0;
	int iNumInPurchSuppPartDescFound		= 0;
	int iNumInPurchSuppPartNameFound		= 0;
	int iNumInPartNumFound					= 0;
	int iNumInDocNumFound					= 0;
	int k                                   = 0;
	int iCount                              = 0;
	int iNumInPartnerCADFileNameFound		= 0;
	int iNumInPartnerCADPartNameFound		= 0;
	int iNumInPartnerCADPartNumberFound		= 0;

	char acKeywordVal[1024]	= {'\0'};
	char szErrorString[TIAUTO_error_message_len+1]	= "";
	char pcClassName[50]				            = {'\0'};
	
	tag_t *tInAltIdfound					= NULL;
	tag_t *tInAltNamefound					= NULL;
	tag_t *tInAltIdDescfound				= NULL;
	tag_t *tInLegaryNamefound				= NULL;
	tag_t *tInItemIdIdfound					= NULL;
	tag_t *tInItemNamefound					= NULL;
	tag_t *tInItemDescfound					= NULL;
	tag_t *tInItemRevDescfound				= NULL;	
	tag_t *tInDatasetNamefound				= NULL;
	tag_t *tInDatasetDescfound				= NULL;
	tag_t *tInLegaryPartNumfound			= NULL;
	tag_t *tInLegaryDescfound				= NULL;
	tag_t *tInDatasetNamedReffound			= NULL;
	tag_t *tInPurchSuppPartNumfound			= NULL;
	tag_t *tInPurchSuppDescfound			= NULL;
	tag_t *tInPurchSuppNamefound			= NULL;
	tag_t *tInPartNumfound					= NULL;
	tag_t *tInDocNumfound					= NULL;
	tag_t *tInPartnerCADFileNamefound		= NULL;
	tag_t *tInPartnerCADPartNamefound		= NULL;
	tag_t *tInPartnerCADPartNumberfound		= NULL;

	int		z = 0;
	int		i = 0;
	char	acItem_1[ITEM_id_size_c + 1] = "";
	char	acItem_2[ITEM_id_size_c + 1] = "";
	tag_t	tTemp = NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects = NULL;
	TIA_UniqueWSOMObjects *tempObjects = NULL;
	//Getting the delimiter from the preference
	char    **pszDelimiter  = NULL; 
    TC_preference_search_scope_t tScope; 

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
  
	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"Item - Any Part Number") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.
			if ( tc_strcasecmp(names[iArgIndex], "Part Number") == 0 )
			{
			// Get the preference value for delimiter				
				ifail = PREF_ask_search_scope( &tScope );
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( TC_preference_site );
				if (ifail == ITK_ok)
				{
					ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
					if (ifail != ITK_ok)
					{
						TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
						ifail = TIAUTO_DELIMITER_NOT_FOUND;
					}
				}
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( tScope );
			    //value entered in the search field is passed to a function that will split the delimted string 
			    // and store it in a structure
				ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);

				for(k = 0;k < sDelimitedKey.iCount;k++)
				{
				    iNumInAltIdFound					= 0;
					iNumInAltNameFound					= 0;
					iNumInAltIdDescFound				= 0;
					iNumInDatasetNameFound				= 0;
					iNumInDatasetDescFound				= 0;
					iNumInLegaryPartNumFound			= 0;
					iNumInLegaryPartDescFound			= 0;
					iNumInItemIdFound					= 0;
					iNumInItemNameFound					= 0;
					iNumInItemDescFound					= 0;
					iNumInItemRevDescFound				= 0;
					iNumInLegaryPartNameFound			= 0;
					iNumInDatasetNamedRefFound			= 0;
					iNumInPurchSuppPartNumFound			= 0;
					iNumInPurchSuppPartDescFound		= 0;
					iNumInPurchSuppPartNameFound		= 0;
					//value entered in the search field
					tc_strcpy(acKeywordVal,sDelimitedKey.StatusArray[k]);	
					//Perform the check for presence of keyword in Alt Id				
					ifail = IsPresentInAltId_item(acKeywordVal,&iNumInAltIdFound,&tInAltIdfound);
					for(j = 0; j < iNumInAltIdFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltIdfound[j]);
					}
					SAFE_MEM_free(tInAltIdfound);
					//Perform the check for presence of keyword in Alt Name
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInAltIdName_item(acKeywordVal,&iNumInAltNameFound,&tInAltNamefound);
					for(j = 0; j < iNumInAltNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltNamefound[j]);
					}
					SAFE_MEM_free(tInAltNamefound);
					//Perform the check for presence of keyword in Alt Description
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInAltIdDescription_item(acKeywordVal,&iNumInAltIdDescFound,&tInAltIdDescfound);
					for(j = 0; j < iNumInAltIdDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInAltIdDescfound[j]);
					}
					SAFE_MEM_free(tInAltIdDescfound);
					//Perform the check for presence of keyword in dataset name
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInDatasetName_item(acKeywordVal,&iNumInDatasetNameFound,&tInDatasetNamefound);
					for(j = 0; j < iNumInDatasetNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetNamefound[j]);
					}
					SAFE_MEM_free(tInDatasetNamefound);
					//Perform the check for presence of keyword in dataset description
					 j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInDatasetDescription_item(acKeywordVal,&iNumInDatasetDescFound,&tInDatasetDescfound);
					for(j = 0; j < iNumInDatasetDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetDescfound[j]);
					}
					SAFE_MEM_free(tInDatasetDescfound);
					//Perform the check for presence of keyword in dataset named reference
					 j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInDatasetNamedRef_item(acKeywordVal,&iNumInDatasetNamedRefFound,&tInDatasetNamedReffound);
					for(j = 0; j < iNumInDatasetNamedRefFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDatasetNamedReffound[j]);
					}
					SAFE_MEM_free(tInDatasetNamedReffound);
					//Perform the check for presence of keyword in legacy part number
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInLegacyPartNum_item(acKeywordVal,&iNumInLegaryPartNumFound,&tInLegaryPartNumfound);
					for(j = 0; j < iNumInLegaryPartNumFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryPartNumfound[j]);
					}
					SAFE_MEM_free(tInLegaryPartNumfound);
					//Perform the check for presence of keyword in legacy part description
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInLegacyPartDesc_item(acKeywordVal,&iNumInLegaryPartDescFound,&tInLegaryDescfound);
					for(j = 0; j < iNumInLegaryPartDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryDescfound[j]);
					}
					SAFE_MEM_free(tInLegaryDescfound);
					//Perform the check for presence of keyword in legacy part name
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInLegacyPartName_item(acKeywordVal,&iNumInLegaryPartNameFound,&tInLegaryNamefound);
					for(j = 0; j < iNumInLegaryPartNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInLegaryNamefound[j]);
					}
					SAFE_MEM_free(tInLegaryNamefound);
					//Perform the check for presence of keyword in item id
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInItemId_item(acKeywordVal,&iNumInItemIdFound,&tInItemIdIdfound);
					for(j = 0; j < iNumInItemIdFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemIdIdfound[j]);
					}
					SAFE_MEM_free(tInItemIdIdfound);
					//Perform the check for presence of keyword in item name
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInItemName_item(acKeywordVal,&iNumInItemNameFound,&tInItemNamefound);
					for(j = 0; j < iNumInItemNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemNamefound[j]);
					}
					SAFE_MEM_free(tInItemNamefound);
					//Perform the check for presence of keyword in item description
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInItemDesc_item(acKeywordVal,&iNumInItemDescFound,&tInItemDescfound);
					for(j = 0; j < iNumInItemDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemDescfound[j]);
					}
					SAFE_MEM_free(tInItemDescfound);
					//Perform the check for presence of keyword in item rev description
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInItemRevDesc_item(acKeywordVal,&iNumInItemRevDescFound,&tInItemRevDescfound);
					for(j = 0; j < iNumInItemRevDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInItemRevDescfound[j]);
					}
					SAFE_MEM_free(tInItemRevDescfound);
					
					//Perform the check for presence of keyword in Supplier part number of the PurchasedCost form
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInPurchSuppPartNum_item(acKeywordVal,&iNumInPurchSuppPartNumFound,&tInPurchSuppPartNumfound);
					for(j = 0; j < iNumInPurchSuppPartNumFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppPartNumfound[j]);
					}
					SAFE_MEM_free(tInPurchSuppPartNumfound);
					//Perform the check for presence of keyword in Supplier part description of the PurchasedCost Form
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInPurchSuppPartDesc_item(acKeywordVal,&iNumInPurchSuppPartDescFound,&tInPurchSuppDescfound);
					for(j = 0; j < iNumInPurchSuppPartDescFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppDescfound[j]);
					}
					SAFE_MEM_free(tInPurchSuppDescfound);
					//Perform the check for presence of keyword in Supplier part name of the PurchasedCost Form
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInPurchSuppPartName_item(acKeywordVal,&iNumInPurchSuppPartNameFound,&tInPurchSuppNamefound);
					for(j = 0; j < iNumInPurchSuppPartNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPurchSuppNamefound[j]);
					}
					SAFE_MEM_free(tInPurchSuppNamefound);

					//Perform the IFS_CATPart_query to find the keyword
					j = 0;
					if(ifail == ITK_ok)
						ifail = IsPresentInIFSCATPart_item(acKeywordVal,&iNumTotalTags,&UniqueObjects);

					//Perform the check for presence of keyword in Partner Submission Form Part Number
					j = 0;
					for( i = 0; i< 10; i++)    
					{
						if (i == 0) tc_strcpy (pcClassName, "t8_116PDE");
						if (i == 1) tc_strcpy (pcClassName, "t1a98MeetingMin_DocRevMstr");
						if (i == 2) tc_strcpy (pcClassName, "t1a62T_PPAP_DocRevMaster");
						if (i == 3) tc_strcpy (pcClassName, "t1a64Lessons_DocRevMaster");
						if (i == 4) tc_strcpy (pcClassName, "t1a75PurcNotes_DocRevMaster");
						if (i == 5) tc_strcpy (pcClassName, "t1a113PurPrtsBOM_DocRevMstr");
						if (i == 6) tc_strcpy (pcClassName, "t1a87SrcDecisn_DocRevMaster");
						if (i == 7) tc_strcpy (pcClassName, "t1a81SuppAudit_DocRevMaster");
						if (i == 8) tc_strcpy (pcClassName, "T8_t1a132SupplierCR_RevMast");
						if (i == 9) tc_strcpy (pcClassName, "t1a69SuppRFQ_DocRevMaster");

						if(ifail == ITK_ok)
							ifail = IsPresentInPartnerSubmissionPartNum_Item(acKeywordVal,pcClassName,&iNumInPartNumFound,&tInPartNumfound);
						for(j = 0; j < iNumInPartNumFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartNumfound[j]);
						}
						SAFE_MEM_free(tInPartNumfound);
						iNumInPartNumFound = 0;

						// Emptying the pcClassName char array
						// memset(pcClassName, 0, sizeof(char ) * 50);
						tc_strcpy (pcClassName,"");
					}

					//Perform the check for presence of keyword in Partner Submission Form Document Number
					j = 0;
					for( i = 0; i< 10; i++)    
					{
						if (i == 0) tc_strcpy (pcClassName, "t8_116PDE");
						if (i == 1) tc_strcpy (pcClassName, "t1a98MeetingMin_DocRevMstr");
						if (i == 2) tc_strcpy (pcClassName, "t1a62T_PPAP_DocRevMaster");
						if (i == 3) tc_strcpy (pcClassName, "t1a64Lessons_DocRevMaster");
						if (i == 4) tc_strcpy (pcClassName, "t1a75PurcNotes_DocRevMaster");
						if (i == 5) tc_strcpy (pcClassName, "t1a113PurPrtsBOM_DocRevMstr");
						if (i == 6) tc_strcpy (pcClassName, "t1a87SrcDecisn_DocRevMaster");
						if (i == 7) tc_strcpy (pcClassName, "t1a81SuppAudit_DocRevMaster");
						if (i == 8) tc_strcpy (pcClassName, "T8_t1a132SupplierCR_RevMast");
						if (i == 9) tc_strcpy (pcClassName, "t1a69SuppRFQ_DocRevMaster");

						if(ifail == ITK_ok)
							ifail = IsPresentInPartnerSubmissionDocNum_Item(acKeywordVal,pcClassName,&iNumInDocNumFound,&tInDocNumfound);
						for(j = 0; j < iNumInDocNumFound;j++)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInDocNumfound[j]);
						}
						SAFE_MEM_free(tInDocNumfound);
						iNumInDocNumFound = 0;

						// Emptying the pcClassName char array
						// memset(pcClassName, 0, sizeof(char ) * 50);
						tc_strcpy (pcClassName,"");
					}
					
					//Perform the check for presence of keyword in filename field of the PartnerCADImportForm
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInPartnerCADFileName_Item(acKeywordVal,&iNumInPartnerCADFileNameFound,&tInPartnerCADFileNamefound);
					for(j = 0; j < iNumInPartnerCADFileNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADFileNamefound[j]);
					}
					SAFE_MEM_free(tInPartnerCADFileNamefound);
					//Perform the check for presence of keyword in partname field of the PartnerCADImportForm
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInPartnerCADPartName_Item(acKeywordVal,&iNumInPartnerCADPartNameFound,&tInPartnerCADPartNamefound);
					for(j = 0; j < iNumInPartnerCADPartNameFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADPartNamefound[j]);
					}
					SAFE_MEM_free(tInPartnerCADPartNamefound);
					//Perform the check for presence of keyword in partnumber field of the PartnerCADImportForm
					j = 0;
					if(ifail == ITK_ok )
						ifail = IsPresentInPartnerCADPartNumber_Item(acKeywordVal,&iNumInPartnerCADPartNumberFound,&tInPartnerCADPartNumberfound);
					for(j = 0; j < iNumInPartnerCADPartNumberFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInPartnerCADPartNumberfound[j]);
					}
					SAFE_MEM_free(tInPartnerCADPartNumberfound);
				}
			}
		}
		//total no. of out result count		
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
         	UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}
		//Sorting in assending order		
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				ifail = ITEM_ask_id((*found)[z], acItem_1);
				if(!ifail)
				{
					ifail = ITEM_ask_id((*found)[i], acItem_2);
					if(!ifail)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
					}
				}
			}
		}

		tiauto_clearTagStack(UniqueObjects);				
	}
	

	return ifail;
}

/*=============================================================================================================
*		TIAUTO_find_tasks_assigned_to_users(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "Tasks by Assigned User" user query.
================================================================================================================*/
extern int TIAUTO_find_tasks_assigned_to_users(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int ifail = ITK_ok;
	int iNumRespTasksFound = 0;
	int iNumSignOffTasksFound = 0;
	int iNumTotalTags = 0;
	int iArgIndex = 0;
	int iCount    = 0;
	int indx = 0;
	int k = 0;
	int j = 0;
	tag_t *ptRespTaskTagsFound = NULL;
	tag_t *ptSignOffTaskTagsFound = NULL;

	TIA_UniqueWSOMObjects *UniqueObjects = NULL;
	TIA_UniqueWSOMObjects *tempObjects = NULL;
	//Getting the delimiter from the preference
	char    **pszDelimiter  = NULL; 
	char szErrorString[TIAUTO_error_message_len+1]	= "";
	char acKeywordVal[1024]	= {'\0'};
    TC_preference_search_scope_t tScope; 

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
  
	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"Tasks by Assigned User") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.
			if( ( tc_strcasecmp(names[iArgIndex], "User Id") == 0 )|| ( tc_strcasecmp(names[iArgIndex], "UserId") == 0 ) )
			{
				//Get the preference value for delimiter				
				ifail = PREF_ask_search_scope( &tScope );
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( TC_preference_site );
				if (ifail == ITK_ok)
				{
					ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
					if (ifail != ITK_ok)
					{
						TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
						ifail = TIAUTO_DELIMITER_NOT_FOUND;
					}
				}
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( tScope );
			    //value entered in the search field is passed to a function that will split the delimted string 
			    // and store it in a structure
				if (ifail == ITK_ok)
					ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);

				for(k = 0;k < sDelimitedKey.iCount;k++)
				{
					iNumRespTasksFound = 0;
					tc_strcpy(acKeywordVal,sDelimitedKey.StatusArray[k]);
					
					if (ifail == ITK_ok)
						ifail = find_tasks_assigned_to_users(acKeywordVal,&iNumRespTasksFound,&ptRespTaskTagsFound);
					for(j = 0; j < iNumRespTasksFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptRespTaskTagsFound[j]);
					}
					SAFE_MEM_free(ptRespTaskTagsFound);
					//Find the tasks pending with sign off users.
					j = 0;
					if(ifail == ITK_ok)
						ifail = find_tasks_assigned_to_signoff_users(acKeywordVal,&iNumSignOffTasksFound,&ptSignOffTaskTagsFound);
					for(j = 0; j < iNumSignOffTasksFound;j++)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptSignOffTaskTagsFound[j]);
					}
					SAFE_MEM_free(ptSignOffTaskTagsFound);
				}
			}
		}
		//total no. of out result count		
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
         	UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}
		tiauto_clearTagStack(UniqueObjects);
	}

	return ifail;
}

/*=============================================================================================================
*TIAUTO_find_Change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "Change Affected programs" user query.
================================================================================================================*/
extern int TIAUTO_find_change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{	
	int						j = 0;
	int						indx = 0;	
	int						iFail = ITK_ok;
	int						iArgIndex = 0;
	char					*pcProg = NULL;
	char					*pcDiv = NULL;
	char					*pcDesc = NULL;
	//char					*pcSite = NULL;//Check NULL or *	
	char					*pcSite = "*";//Check NULL or *
	char					*pcGroup = "*";
	char					*pcOwner = "*";
	char					*pcChangeID = "*";
	char					*pcLast_Mod_User = "*";
	char					*pcRel_Stat = NULL;
	char					*pcTask = NULL;
	int						iNumTotalTags = 0;
	int						iCAP1_NumChItemFound = 0;
	int						iCAP2_NumChItemFound = 0;
	int						iCAP3_NumChItemFound = 0;
	int						iECR_NumChItemFound = 0;
	int						iCI_NumChItemFound = 0;
	int						iPMR1_NumChItemFound = 0;
	int						iPMR2_NumChItemFound = 0;
	int						iOBS_NumChItemFound = 0;
	int						iDEV_NumChItemFound = 0;
	int						iSite               = 0;
	int						iSiteID             = 0;
	date_t					dCre_Aft = NULLDATE;
	date_t					dCre_Bef = NULLDATE;
	date_t					dMode_Aft = NULLDATE;
	date_t					dMode_Bef = NULLDATE;
	logical					lValid_date=true;
	logical					alIn_data[15] = {false};
	TIA_UniqueWSOMObjects	*tempObjects = NULL;
	TIA_UniqueWSOMObjects	*UniqueObjects = NULL;
	tag_t					*ptCAP_ChItemFound = NULL;
	tag_t					*ptECR_ChItemFound = NULL;
	tag_t					*ptCI_ChItemFound = NULL;
	tag_t					*ptPMR_ChItemFound = NULL;
	tag_t					*ptOBS_ChItemFound = NULL;
	tag_t					*ptDEV_ChItemFound = NULL;
	tag_t					tSitetag           = NULLTAG;
	char					szErrorString[TIAUTO_error_message_len+1]	= "";
	char					acSiteName[SA_site_size_c+1]				= {'\0'};

	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name," TI Change (Affected Programs)") == 0)
	{		
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			if(tc_strcasecmp(names[iArgIndex], "Affected Program") == 0 || tc_strcasecmp(names[iArgIndex], "AffectedProgram") == 0)
			{
				pcProg=values[iArgIndex];
				alIn_data[0]=true;
			}
			else if(tc_strcasecmp(names[iArgIndex], "Created After") == 0 || tc_strcasecmp(names[iArgIndex], "CreatedAfter") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dCre_Aft));
					alIn_data[1]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Created Before") == 0 || tc_strcasecmp(names[iArgIndex], "CreatedBefore") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dCre_Bef));
					alIn_data[2]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Modified After") == 0 || tc_strcasecmp(names[iArgIndex], "ModifiedAfter") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dMode_Aft));
					alIn_data[3]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Modified Before") == 0 || tc_strcasecmp(names[iArgIndex], "ModifiedBefore") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dMode_Bef));
					alIn_data[4]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "TI Divisions") == 0 || tc_strcasecmp(names[iArgIndex], "TIDivisions") == 0)
			{
				if(values[iArgIndex])
				{
					pcDiv=values[iArgIndex];
					alIn_data[5]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Change Description") == 0 || tc_strcasecmp(names[iArgIndex], "ChangeDescription") == 0)
			{
				if(values[iArgIndex])
				{
					pcDesc=values[iArgIndex];
					alIn_data[6]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning User") == 0 || tc_strcasecmp(names[iArgIndex], "OwningUser") == 0)
			{
				if(values[iArgIndex])
				{
					pcOwner=values[iArgIndex];
					alIn_data[7]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning Site") == 0 || tc_strcasecmp(names[iArgIndex], "OwningSite") == 0)
			{
				iFail = POM_site_id(&iSite);
				if(iSite != 0)
					iFail = SA_find_site_by_id(iSite,&tSitetag);
				if(iFail == ITK_ok && tSitetag!= NULLTAG)
					iFail = SA_ask_site_info(tSitetag,acSiteName,&iSiteID);

				pcSite=values[iArgIndex];

				if (tc_strcmp(pcSite, acSiteName) == 0)
				{
					alIn_data[13]=true;
				}
				else
				{
					alIn_data[8]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning Group") == 0 || tc_strcasecmp(names[iArgIndex], "OwningGroup") == 0)
			{
				if(values[iArgIndex])
				{
					pcGroup=values[iArgIndex];
					alIn_data[9]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0 || tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				if(values[iArgIndex])
				{
					pcLast_Mod_User=values[iArgIndex];
					alIn_data[10]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Release Status") == 0 || tc_strcasecmp(names[iArgIndex], "ReleaseStatus") == 0)
			{
				if(values[iArgIndex])
				{
					pcRel_Stat=values[iArgIndex];
					alIn_data[11]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Current Task") == 0 || tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				if(values[iArgIndex])
				{
					pcTask=values[iArgIndex];
					alIn_data[12]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Change ID") == 0 || tc_strcasecmp(names[iArgIndex], "ChangeID") == 0)
			{
				if(values[iArgIndex])
				{
					pcChangeID=values[iArgIndex];
					alIn_data[14]=true;
				}
			}
		}

		if(alIn_data[0]==true)
		{
			//Check in CAP Form
			iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "t8_t1a120cap", "t8_t1a120affectedprograms", "t8_t1a120tidivision", "t8_t1a120changedescription",
													   &iCAP1_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP1_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in CAP2 Form
			iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a190CAP2", "t8_t1a190affectedprograms", "t8_t1a190productgroup", "t8_t1a190changedescription",
													   &iCAP2_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP2_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in New CAP3 Form
			iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a190CAP3", "t8_t1a190affectedprograms", "t8_t1a190productgroup", "t8_t1a190changedescription",
													   &iCAP3_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP3_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in PMR Form
			iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "t1A84PMR", "t1A84affectedprogram", "t8_t1a84tidivision", "t1a84changedescription",
													   &iPMR1_NumChItemFound, &ptPMR_ChItemFound);
			for(j = 0; j<iPMR1_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptPMR_ChItemFound[j]);
			}
			SAFE_MEM_free(ptPMR_ChItemFound);
			//Check in New PMR Form
			iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a193pmr2", "t8_193affectedprogram", "t8_193productgroup", "t8_193changedescription",
													   &iPMR2_NumChItemFound, &ptPMR_ChItemFound);
			for(j = 0; j<iPMR2_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptPMR_ChItemFound[j]);
			}
			SAFE_MEM_free(ptPMR_ChItemFound);
			//For other then CAP and PMR forms
			{
				alIn_data[5]=false;//TI Divisions for other forms doesnot exist
				//Check in ECR Form
				iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A40ECR", "t1A40affectedprograms", NULL,"t1a40changedescription",
														   &iECR_NumChItemFound, &ptECR_ChItemFound);
				for(j = 0; j<iECR_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptECR_ChItemFound[j]);
				}
				SAFE_MEM_free(ptECR_ChItemFound);
				//Check in CI Form
				iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A37CI", "t1A37affectedprograms", NULL, "t1a37changedescription",
														   &iCI_NumChItemFound, &ptCI_ChItemFound);
				for(j = 0; j<iCI_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCI_ChItemFound[j]);
				}
				SAFE_MEM_free(ptCI_ChItemFound);
				
				//Check in OBS Form
				iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													       pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A52OBS", "t1A52affectedprograms", NULL,"t1a52description",
														   &iOBS_NumChItemFound, &ptOBS_ChItemFound);
				for(j = 0; j<iOBS_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptOBS_ChItemFound[j]);
				}
				SAFE_MEM_free(ptOBS_ChItemFound);	
				//Check in DEV Form
				iFail=find_change_affected_program_in_form(pcProg, pcChangeID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A51DEV", "t1A51affectedprograms", NULL, "t1a51deviationdescriptio",
														   &iDEV_NumChItemFound, &ptDEV_ChItemFound);
				for(j = 0; j<iDEV_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptDEV_ChItemFound[j]);
				}
				SAFE_MEM_free(ptDEV_ChItemFound);	
			}
			
			//total no. of out result count		
			*num_found = iNumTotalTags;
			if((*num_found) > 0)
			{
				*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
			}			
			indx = 0;
			while(UniqueObjects)
			{
				tempObjects = UniqueObjects;
				(*found)[indx] = tempObjects->tUniqueWSOMObjects;
				indx++;
         		UniqueObjects = UniqueObjects->next;
				free( tempObjects );
				tempObjects = NULL;
			}
			tiauto_clearTagStack(UniqueObjects);
		}
		else
		{
			//Error message	
			TI_sprintf(szErrorString, "Empty \"Affected program\" search field. Retry with valid program name.\n"); 
			TC_write_syslog(szErrorString);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_AFFECTED_PROGRAM, szErrorString);
			iFail = TIAUTO_NOT_VALID_AFFECTED_PROGRAM;			
		}
	}
	return iFail;
}
/*=============================================================================================================
*		TIAUTO_find_partner_submission_documents(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
* created by- Pradeep
*			Implements the the logic for the "Find Partner Submission Data (Documents)" user query.
===============================================================================================================*/
int TIAUTO_find_partner_submission_documents(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int ifail									= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
 	int k										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	int iCount									= 0;
	int iNumTotalTags							= 0;

	char szErrorString[TIAUTO_error_message_len+1]	= "";
	char pcClassName[50]				            = "t8_116PDE";    
	char **pszDelimiter								= NULL; 
    TC_preference_search_scope_t tScope;
	
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	
	tag_t			tTemp							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	char tempkey_DocumentID[1024]						= {'\0'};
	char tempkey_RevisionID[1024]                       = {'\0'};
	char tempkey_Name[1024]								= {'\0'};
    char tempkey_DocumentType[1024]						= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_PdeJobNumber[1024]						= {'\0'};
	char tempkey_SendingCompanyName[1024]				= {'\0'};
	char tempkey_SendingCountry[1024]					= {'\0'};
	char tempkey_SendingCity[1024]						= {'\0'};
	char tempkey_SenderName[1024]						= {'\0'};
	char tempkey_SenderEmailAddr[1024]					= {'\0'};
	char tempkey_ReceivingCompanyName[1024]				= {'\0'};
	char tempkey_ReceivingCountry[1024]					= {'\0'};
	char tempkey_ReceivingCity[1024]					= {'\0'};
	char tempkey_ReceiverName[1024]						= {'\0'};
	char tempkey_ReceiverDept[1024]						= {'\0'};
	char tempkey_ReceiverMailAddr[1024]					= {'\0'};
	char tempkey_ReceiverFax[1024]						= {'\0'};
	char tempkey_ReceivingLocation[1024]				= {'\0'};
	char tempkey_ReceivingPostalCode[1024]				= {'\0'};
	char tempkey_ReceivingStreet[1024]					= {'\0'};
	char tempkey_ReceiverContactNum[1024]				= {'\0'};
	char tempkey_SenderContactNum[1024]					= {'\0'};
	char tempkey_SenderDept[1024]						= {'\0'};
	char tempkey_SenderFax[1024]						= {'\0'};
	char tempkey_SenderPostalcode[1024]					= {'\0'};
	char tempkey_SendingLocation[1024]					= {'\0'};
	char tempkey_SendingStreet[1024]					= {'\0'};
	char tempkey_Action[1024]							= {'\0'};
	char tempkey_DocDescription[1024]					= {'\0'};
	char tempkey_DocNumber[1024]						= {'\0'};
	char tempkey_Information[1024]						= {'\0'};
	char tempkey_PartNumber[1024]						= {'\0'};
	char tempkey_PartRev[1024]							= {'\0'};
	char tempkey_State[1024]							= {'\0'};
	
	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	
	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"Partner Submission Data (Documents)") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.

			//{
			    // Get the preference value for delimiter				
				ifail = PREF_ask_search_scope( &tScope );
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( TC_preference_site );
				if (ifail == ITK_ok)
				{
					ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
					if (ifail != ITK_ok)
					{
						TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
						ifail = TIAUTO_DELIMITER_NOT_FOUND;
					}
				}
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( tScope );
			    //value entered in the search field is passed to a function that will split the delimted string 
			    // and store it in a structure
				ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);
					
				for(k = 0; k< sDelimitedKey.iCount;k++)
			    {
				    //Initialise all integers to 0 so that it does not try to store a nulltag					 
					 iNumInT8_AttrValueFound                = 0;					
//===================================================================================================

					if( (  tc_strcasecmp(names[iArgIndex], "Document ID") == 0)||(  tc_strcasecmp(names[iArgIndex], "DocumentID") == 0) )
						{
								tc_strcpy(tempkey_DocumentID,sDelimitedKey.StatusArray[k]);
						}

					if( (  tc_strcasecmp(names[iArgIndex], "Revision ID") == 0)||(  tc_strcasecmp(names[iArgIndex], "RevisionID") == 0) )
						{
								tc_strcpy(tempkey_RevisionID,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Name") == 0)
						{
								tc_strcpy(tempkey_Name,sDelimitedKey.StatusArray[k]);
						}	

					if(  (tc_strcasecmp(names[iArgIndex], "Document Type") == 0) || (tc_strcasecmp(names[iArgIndex], "DocumentType") == 0) )
						{
								tc_strcpy(tempkey_DocumentType,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "Created After") == 0) || (tc_strcasecmp(names[iArgIndex], "CreatedAfter") == 0) )
						{
							tc_strcpy(tempkey_CAD,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "Created Before") == 0) || (tc_strcasecmp(names[iArgIndex], "CreatedBefore") == 0) )
						{
							tc_strcpy(tempkey_CBD,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)||(tc_strcasecmp(names[iArgIndex], "ModifiedAfter") == 0))
						{
							tc_strcpy(tempkey_MAD,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0) || (tc_strcasecmp(names[iArgIndex], "ModifiedBefore") == 0) )
						{
							tc_strcpy(tempkey_MBD,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_pdejobnumber") == 0) || (tc_strcasecmp(names[iArgIndex], "PDE Job #") == 0)|| (tc_strcasecmp(names[iArgIndex], "PDEJob#") == 0) )
						{
							tc_strcpy(tempkey_PdeJobNumber,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendingcompanyname") == 0) || (tc_strcasecmp(names[iArgIndex], "Sending Company Name") == 0) || (tc_strcasecmp(names[iArgIndex], "SendingCompanyName") == 0))
						{
							tc_strcpy(tempkey_SendingCompanyName,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendingcountry") == 0) || (tc_strcasecmp(names[iArgIndex], "Sending Country") == 0) || (tc_strcasecmp(names[iArgIndex], "SendingCountry") == 0))
						{
							tc_strcpy(tempkey_SendingCountry,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendingcity") == 0) || (tc_strcasecmp(names[iArgIndex], "Sending City") == 0)|| (tc_strcasecmp(names[iArgIndex], "SendingCity") == 0) )
						{
							tc_strcpy(tempkey_SendingCity,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendername") == 0)  || (tc_strcasecmp(names[iArgIndex], "Sender Name (Last, First)") == 0)|| (tc_strcasecmp(names[iArgIndex], "SenderName(Last,First)") == 0) )
						{
							tc_strcpy(tempkey_SenderName,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_senderemailaddr") == 0) || (tc_strcasecmp(names[iArgIndex], "Sender Email Address") == 0)|| (tc_strcasecmp(names[iArgIndex], "SenderEmailAddress") == 0) )
						{
							tc_strcpy(tempkey_SenderEmailAddr,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivingcompanyname") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiving Company Name") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceivingCompanyName") == 0))
						{
							tc_strcpy(tempkey_ReceivingCompanyName,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivingcountry") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiving Country") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceivingCountry") == 0))
						{
							tc_strcpy(tempkey_ReceivingCountry,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivingcity") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiving City") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceivingCity") == 0))
						{
							tc_strcpy(tempkey_ReceivingCity,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivername") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Name (Last, First)") == 0)|| (tc_strcasecmp(names[iArgIndex], "ReceiverName(Last,First)") == 0) )
						{
							tc_strcpy(tempkey_ReceiverName,sDelimitedKey.StatusArray[k]);
						}
						
					if(  (tc_strcasecmp(names[iArgIndex], "t8_receiverdept") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Department") == 0)|| (tc_strcasecmp(names[iArgIndex], "ReceiverDepartment") == 0) )
						{
							tc_strcpy(tempkey_ReceiverDept,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivermailaddr") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Email Address") == 0)|| (tc_strcasecmp(names[iArgIndex], "ReceiverEmailAddress") == 0) )
						{ 
							tc_strcpy(tempkey_ReceiverMailAddr,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receiverfax") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Fax") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceiverFax") == 0) )
						{
							tc_strcpy(tempkey_ReceiverFax,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivinglocation") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiving Location") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceivingLocation") == 0))
						{
							tc_strcpy(tempkey_ReceivingLocation,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receiverpostalcode") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Postal Code") == 0)|| (tc_strcasecmp(names[iArgIndex], "ReceiverPostalCode") == 0) )
						{
							tc_strcpy(tempkey_ReceivingPostalCode,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivingstreet") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiving Street") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceivingStreet") == 0) )
						{
							tc_strcpy(tempkey_ReceivingStreet,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_receivercontactnum") == 0) || (tc_strcasecmp(names[iArgIndex], "Receiver Contact No") == 0) || (tc_strcasecmp(names[iArgIndex], "ReceiverContactNo") == 0))
						{
							tc_strcpy(tempkey_ReceiverContactNum,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendercontactnum") == 0) || (tc_strcasecmp(names[iArgIndex], "Sender Contact No") == 0)|| (tc_strcasecmp(names[iArgIndex], "SenderContactNo") == 0) )
						{
							tc_strcpy(tempkey_SenderContactNum,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_senderdept") == 0) || (tc_strcasecmp(names[iArgIndex], "Sender Department") == 0) || (tc_strcasecmp(names[iArgIndex], "SenderDepartment") == 0))
						{
							tc_strcpy(tempkey_SenderDept,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_senderfax") == 0) || (tc_strcasecmp(names[iArgIndex], "Sender Fax") == 0)|| (tc_strcasecmp(names[iArgIndex], "SenderFax") == 0) )
						{
							tc_strcpy(tempkey_SenderFax,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_senderspostalcode") == 0) || (tc_strcasecmp(names[iArgIndex], "Sender Postal Code") == 0)|| (tc_strcasecmp(names[iArgIndex], "SenderPostalCode") == 0) )
						{
							tc_strcpy(tempkey_SenderPostalcode,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendinglocation") == 0) || (tc_strcasecmp(names[iArgIndex], "Sending Location") == 0) || (tc_strcasecmp(names[iArgIndex], "SendingLocation") == 0))
						{
							tc_strcpy(tempkey_SendingLocation,sDelimitedKey.StatusArray[k]);
						}

					if(  (tc_strcasecmp(names[iArgIndex], "t8_sendingstreet") == 0) || (tc_strcasecmp(names[iArgIndex], "Sending Street") == 0)|| (tc_strcasecmp(names[iArgIndex], "SendingStreet") == 0) )
						{
							tc_strcpy(tempkey_SendingStreet,sDelimitedKey.StatusArray[k]);
						}

					/*Changes according to ER#7855*/
					if(( tc_strcasecmp(names[iArgIndex], "t8_action") == 0) || (tc_strcasecmp(names[iArgIndex], "Action") == 0) )
					{
						tc_strcpy(tempkey_Action,sDelimitedKey.StatusArray[k]);
					}

					if(( tc_strcasecmp(names[iArgIndex], "t8_documentdescription") == 0) || (tc_strcasecmp(names[iArgIndex], "Document Description") == 0) || (tc_strcasecmp(names[iArgIndex], "DocumentDescription") == 0) )
					{
						tc_strcpy(tempkey_DocDescription,sDelimitedKey.StatusArray[k]);
					}

					if( (tc_strcasecmp(names[iArgIndex], "t8_documentnumber") == 0) || (tc_strcasecmp(names[iArgIndex], "Document Number") == 0) || (tc_strcasecmp(names[iArgIndex], "DocumentNumber") == 0) )
					{
						tc_strcpy(tempkey_DocNumber,sDelimitedKey.StatusArray[k]);
					}

					if( (tc_strcasecmp(names[iArgIndex], "t8_information") == 0) || (tc_strcasecmp(names[iArgIndex], "Information") == 0) )
					{
						tc_strcpy(tempkey_Information,sDelimitedKey.StatusArray[k]);
					}

					if( (tc_strcasecmp(names[iArgIndex], "t8_partnumber") == 0) || (tc_strcasecmp(names[iArgIndex], "Part Number") == 0)|| (tc_strcasecmp(names[iArgIndex], "PartNumber") == 0) )
					{
						tc_strcpy(tempkey_PartNumber,sDelimitedKey.StatusArray[k]);
					}

					if( (tc_strcasecmp(names[iArgIndex], "t8_partrevision") == 0) || (tc_strcasecmp(names[iArgIndex], "Part Revision") == 0)|| (tc_strcasecmp(names[iArgIndex], "PartRevision") == 0) )
					{
						tc_strcpy(tempkey_PartRev,sDelimitedKey.StatusArray[k]);
					}

					if(( tc_strcasecmp(names[iArgIndex], "t8_state") == 0) || (tc_strcasecmp(names[iArgIndex], "State") == 0) )
					{
						tc_strcpy(tempkey_State,sDelimitedKey.StatusArray[k]);
					}
			                        
				}
		}
		//================================================================================
					// Passing classnames to the POM query
		//===============================================================================	

		for( i = 0; i< 10; i++)    
		{
			
			if (i == 0) tc_strcpy (pcClassName, "t8_116PDE");
			if (i == 1) tc_strcpy (pcClassName, "t1a98MeetingMin_DocRevMstr");
			if (i == 2) tc_strcpy (pcClassName, "t1a62T_PPAP_DocRevMaster");
			if (i == 3) tc_strcpy (pcClassName, "t1a64Lessons_DocRevMaster");
			if (i == 4) tc_strcpy (pcClassName, "t1a75PurcNotes_DocRevMaster");
			if (i == 5) tc_strcpy (pcClassName, "t1a113PurPrtsBOM_DocRevMstr");
			if (i == 6) tc_strcpy (pcClassName, "t1a87SrcDecisn_DocRevMaster");
			if (i == 7) tc_strcpy (pcClassName, "t1a81SuppAudit_DocRevMaster");
			if (i == 8) tc_strcpy (pcClassName, "T8_t1a132SupplierCR_RevMast");
			if (i == 9) tc_strcpy (pcClassName, "t1a69SuppRFQ_DocRevMaster");

						
			//Passing the attribute values to a variable

			j = 0;
			iNumInT8_AttrValueFound=0;
			if(tempkey_PdeJobNumber == '\0' || tc_strcmp(tempkey_PdeJobNumber,"")==0)
				tc_strcpy(tempkey_PdeJobNumber,"*");

				if ((tempkey_DocumentID != '\0') || (tempkey_RevisionID != '\0') || (tempkey_Name != '\0') || 
					(tempkey_DocumentType != '\0') || (tempkey_CAD != '\0') || (tempkey_CBD != '\0') || 
					(tempkey_MAD != '\0') || (tempkey_MBD != '\0') || (tempkey_PdeJobNumber != '\0') || 
					(tempkey_SendingCompanyName != '\0') || (tempkey_SendingCountry != '\0') || (tempkey_SendingCity != '\0') || 
					(tempkey_SenderName != '\0') || (tempkey_SenderEmailAddr != '\0') ||(tempkey_ReceivingCompanyName != '\0') ||
					(tempkey_ReceivingCountry != '\0') || (tempkey_ReceivingCity != '\0') || (tempkey_ReceiverName != '\0') ||
					(tempkey_ReceiverDept != '\0') || (tempkey_ReceiverMailAddr != '\0') || (tempkey_ReceiverFax != '\0') || 
					(tempkey_ReceivingLocation != '\0') || (tempkey_ReceivingPostalCode != '\0') || (tempkey_ReceivingStreet != '\0') ||
					(tempkey_ReceiverContactNum != '\0') || (tempkey_SenderContactNum != '\0') || (tempkey_SenderDept != '\0') ||
					(tempkey_SenderFax != '\0') || (tempkey_SenderPostalcode != '\0') || (tempkey_SendingLocation != '\0') ||
					(tempkey_SendingStreet != '\0') || (tempkey_Action != '\0') || (tempkey_DocDescription != '\0') ||
					(tempkey_DocNumber != '\0') || (tempkey_Information!= '\0') || (tempkey_PartNumber!= '\0') || 
					(tempkey_PartRev != '\0') || (tempkey_State != '\0') )

			{

				ifail = find_partner_submission_data(tempkey_DocumentID,tempkey_RevisionID,tempkey_Name,tempkey_DocumentType,
													 tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
													 tempkey_PdeJobNumber,tempkey_SendingCompanyName,tempkey_SendingCountry,
													 tempkey_SendingCity,tempkey_SenderName,tempkey_SenderEmailAddr,tempkey_ReceivingCompanyName,
													 tempkey_ReceivingCountry,tempkey_ReceivingCity,tempkey_ReceiverName,
													 tempkey_ReceiverDept,tempkey_ReceiverMailAddr,tempkey_ReceiverFax,
													 tempkey_ReceivingLocation,tempkey_ReceivingPostalCode,tempkey_ReceivingStreet,
													 tempkey_ReceiverContactNum,tempkey_SenderContactNum,
													 tempkey_SenderDept,tempkey_SenderFax,tempkey_SenderPostalcode,tempkey_SendingLocation,
													 tempkey_SendingStreet, tempkey_Action, tempkey_DocDescription, tempkey_DocNumber,
													 tempkey_Information, tempkey_PartNumber, tempkey_PartRev, tempkey_State,
													 &iNumInT8_AttrValueFound,&tInT8_AttrValueFound, pcClassName);

				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
				}
				SAFE_MEM_free(tInT8_AttrValueFound);
			}
			// Emptying the pcClassName char array
		    //memset(pcClassName, 0, sizeof(char ) * 50); 
				tc_strcpy(pcClassName,"");
					
		} 
		//======================================================================================================

		//total no. of out result count		
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
         	UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}
		//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				ifail = ITEM_ask_id((*found)[z], acItem_1);
				if(!ifail)
				{
					ifail = ITEM_ask_id((*found)[i], acItem_2);
					if(!ifail)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
					}
				}
			}
		}

		tiauto_clearTagStack(UniqueObjects);				
	}
	

	return ifail;
}

/*=============================================================================================================
*		TIAUTO_find_assembly_having_substitute_parts(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
* created by- Pradeep
*			Implements the the logic for the "Find Assemblies having substitute parts" user query.
===============================================================================================================*/
int TIAUTO_find_assembly_having_substitute_parts(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int ifail									= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
 	int k										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	int iCount									= 0;
	int iNumTotalTags							= 0;

	char szErrorString[TIAUTO_error_message_len+1]	= "";
	/*char pcClassName[50]				            = "t8_116PDE";*/    
	char **pszDelimiter								= NULL; 
    TC_preference_search_scope_t tScope;
	
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_RevisionID[1024]                       = {'\0'};
	char tempkey_Name[1024]								= {'\0'};
    char tempkey_ItemType[1024]							= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	
	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	
	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"Find Assembly having substitute parts") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.

			//{
			    // Get the preference value for delimiter				
				ifail = PREF_ask_search_scope( &tScope );
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( TC_preference_site );
				if (ifail == ITK_ok)
				{
					ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
					if (ifail != ITK_ok)
					{
						TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
						ifail = TIAUTO_DELIMITER_NOT_FOUND;
					}
				}
				if (ifail == ITK_ok)
					ifail = PREF_set_search_scope( tScope );
			    //value entered in the search field is passed to a function that will split the delimted string 
			    // and store it in a structure
				ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);
					
				for(k = 0; k< sDelimitedKey.iCount;k++)
			    {
				    //Initialise all integers to 0 so that it does not try to store a nulltag					 
					 iNumInT8_AttrValueFound                = 0;					
//===================================================================================================

					if(  tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
						{
								tc_strcpy(tempkey_ItemID,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Revision ID") == 0)
						{
								tc_strcpy(tempkey_RevisionID,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Name") == 0)
						{
								tc_strcpy(tempkey_Name,sDelimitedKey.StatusArray[k]);
						}	

					if(  tc_strcasecmp(names[iArgIndex], "ItemType") == 0)
						{
								tc_strcpy(tempkey_ItemType,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Created After") == 0)
						{
							tc_strcpy(tempkey_CAD,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
						{
							tc_strcpy(tempkey_CBD,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
						{
							tc_strcpy(tempkey_MAD,sDelimitedKey.StatusArray[k]);
						}

					if(  tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
						{
							tc_strcpy(tempkey_MBD,sDelimitedKey.StatusArray[k]);
						}	
			                        
					}
		}	
						
						//Passing the attribute values to a variable

						j = 0;
						iNumInT8_AttrValueFound=0;

						if ((tempkey_ItemID != '\0') || (tempkey_RevisionID != '\0') || (tempkey_Name != '\0') || (tempkey_ItemType != '\0') ||
							(tempkey_CAD != '\0') || (tempkey_CBD != '\0') || (tempkey_MAD != '\0') || (tempkey_MBD != '\0'))
						{

							ifail = find_assembly_having_substitute_parts(tempkey_ItemID,tempkey_RevisionID,tempkey_Name,tempkey_ItemType,
																		  tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
																		  &iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

						for(j = 0; j < iNumInT8_AttrValueFound;j++)
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
							}
							SAFE_MEM_free(tInT8_AttrValueFound);
						}
		
//======================================================================================================

		//total no. of out result count		
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
         	UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}
		//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				ifail = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!ifail)
					ifail = ITEM_ask_id(tItem_1, acItem_1);
				if(!ifail)
				{
					ifail = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!ifail)
						ifail = ITEM_ask_id(tItem_2, acItem_2);
					if(!ifail)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							ifail = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!ifail)
								ifail = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!ifail)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

		tiauto_clearTagStack(UniqueObjects);				
	}
	

	return ifail;
}

/*=============================================================================================================
*		TIAUTO_find_parts_by_customer_info(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
* created by- Pradeep
*			Implements the the logic for the "Parts By Customer Name" user query.
===============================================================================================================*/
int TIAUTO_find_parts_by_customer_info(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int		ifail												= ITK_ok;
	int		indx												= 0;
	int		iArgIndex											= 0;
	int		j													= 0;
	int		jj   												= 0;
 	int		k													= 0;
	int		z													= 0;
	int		i													= 0;
	int     d                                                   = 0;
	int		iNumInT8_AttrValueFound								= 0;
	int		iCount												= 0;
	int		iNumTotalTags										= 0;
	int		iTags_cnt											= 0;
	int		iTotalTags_cnt										= 0;	
	int		iParents_cnt										= 0;
	int		iPrg												= 0;
	int		iIRMF_cnt											= 0;
	int		iqry_found_cnt										= 0;
	int		*piParents_Level									= 0;
	int		idiv_cnt											= 0;
							

	char	acTempkey_ProgramName[1024]							= {'\0'};
	char	acTempkey_CustomerName[1024]						= {'\0'};
	char	acTempkey_CompanyType[1024]							= {'\0'};
    char	acTempkey_TIDivisions[1024]							= {'\0'};
	char	acTempkey_ItemType[1024]							= {'\0'};
	char	acTempkey_CBD[1024]									= {'\0'};
	char	acTempkey_CAD[1024]									= {'\0'};
	char	acTempkey_MBD[1024]									= {'\0'};
	char	acTempkey_MAD[1024]									= {'\0'};
	char	acRev_id_1[ITEM_id_size_c + 1]						= ""; 
	char	acRev_id_2[ITEM_id_size_c + 1]						= ""; 
	char	acItem_1[ITEM_id_size_c + 1]						= "";
	char	acItem_2[ITEM_id_size_c + 1]						= "";	
	char	szErrorString[TIAUTO_error_message_len+1]			= "";
	char	*pcProg_name										= NULL;
	//char    *pcDivision_name                                    = NULL;
	char    *pcProgVar_ID										= NULL;
	char    *pcProg_type                                        = NULL;
	char    *pcProgVar_type                                     = NULL;
	char    *pcChild_object_type								= NULL;
	char    *pcqry_entries[2]									= {"Name","Type"};
	char	**pszDelimiter										= NULL; 
	char	**pcdiv_list										= NULL;

	tag_t	tTemp												= NULLTAG;
	tag_t	tItem_1												= NULLTAG;
	tag_t	tItem_2												= NULLTAG;
	tag_t	trelation_type										= NULLTAG;
	tag_t	tquery												= NULLTAG;
	tag_t	*tInT8_AttrValueFound								= NULL;
	tag_t	*ptchild_tags_list									= NULL;
	tag_t	*ptParents_tag										= NULL;
	tag_t	*ptIRMF_list										= NULL;
	tag_t	*ptqry_found										= NULL;

	TIA_UniqueWSOMObjects	*UniqueObjects						= NULL;
	TIA_UniqueWSOMObjects	*tempObjects						= NULL;	
	
	STATUS_Struct_t					sDelimitedKey;
	TC_preference_search_scope_t	tScope;

	
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
	
	//Check if the user query found is of type TI_Super_Search
	if (tc_strcmp(name,"TI Product Rev (Program Attributes)") == 0)
	{
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			//Parse through the argument names and check if it has an argument called Keyword.
			// Get the preference value for delimiter				
			ifail = PREF_ask_search_scope( &tScope );
			if (ifail == ITK_ok)
				ifail = PREF_set_search_scope( TC_preference_site );
			if (ifail == ITK_ok)
			{
				ifail = PREF_ask_char_values(DELIMITER_PREF, &iCount, &pszDelimiter);
				if (ifail != ITK_ok)
				{
					TI_sprintf(szErrorString, "Could not find \"WSOM_find_list_separator\" Preference in the system. Please update your site preferences.\n"); 
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, TIAUTO_DELIMITER_NOT_FOUND, szErrorString);
					ifail = TIAUTO_DELIMITER_NOT_FOUND;
				}
			}
			if (ifail == ITK_ok)
				ifail = PREF_set_search_scope( tScope );
		    //value entered in the search field is passed to a function that will split the delimted string 
		    // and store it in a structure
			ifail = tiauto_get_values_from_any_delimiter_string(pszDelimiter[0],values[iArgIndex],&sDelimitedKey);
				
			for(k = 0; k< sDelimitedKey.iCount;k++)
		    {	
			    //Initialise all integers to 0 so that it does not try to store a nulltag					 
				iNumInT8_AttrValueFound                = 0;					

				if ( (tc_strcasecmp(names[iArgIndex], "ProgramName") == 0) || (tc_strcasecmp(names[iArgIndex], "Program Name") == 0) )
				{
					tc_strcpy(acTempkey_ProgramName,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "CustomerName") == 0) || (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0) )
				{
					tc_strcpy(acTempkey_CustomerName,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "CustomerType") == 0) || (tc_strcasecmp(names[iArgIndex], "Customer Type") == 0))
				{
					tc_strcpy(acTempkey_CompanyType,sDelimitedKey.StatusArray[k]);
				}	

				if( (tc_strcasecmp(names[iArgIndex], "TIDivisions") == 0) || (tc_strcasecmp(names[iArgIndex], "TI Divisions") == 0) )
				{
					tc_strcpy(acTempkey_TIDivisions,sDelimitedKey.StatusArray[k]);
				}

				if (tc_strcasecmp(names[iArgIndex], "Type") == 0)
				{
					tc_strcpy(acTempkey_ItemType,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "Created Before") == 0) || (tc_strcasecmp(names[iArgIndex], "CreatedBefore") == 0))
				{
					tc_strcpy(acTempkey_CBD,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "Created After") == 0) || (tc_strcasecmp(names[iArgIndex], "CreatedAfter") == 0))
				{
					tc_strcpy(acTempkey_CAD,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0) || (tc_strcasecmp(names[iArgIndex], "ModifiedBefore") == 0) )
				{
					tc_strcpy(acTempkey_MBD,sDelimitedKey.StatusArray[k]);
				}

				if( (tc_strcasecmp(names[iArgIndex], "Modified After") == 0) || (tc_strcasecmp(names[iArgIndex], "ModifiedAfter") == 0) )
				{
					tc_strcpy(acTempkey_MAD,sDelimitedKey.StatusArray[k]);
				}                  
			}
		}

		//Passing the attribute values to a variable
		j = 0;
		iNumInT8_AttrValueFound=0;

		if ((acTempkey_ProgramName != '\0') || (acTempkey_CustomerName != '\0') || (acTempkey_CompanyType != '\0') || (acTempkey_TIDivisions != '\0') ||
			(acTempkey_ItemType != '\0') || (acTempkey_CBD != '\0') || (acTempkey_CAD != '\0') || (acTempkey_MBD != '\0') || (acTempkey_MAD != '\0'))
		{
			ifail = find_parts_by_customer_info(acTempkey_ProgramName,acTempkey_CustomerName,acTempkey_CompanyType,
												acTempkey_CBD,acTempkey_CAD,acTempkey_MBD,acTempkey_MAD,
												&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			if (tc_strcmp(acTempkey_TIDivisions, "") !=0)
			{
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "object_type", &pcProgVar_type);

					ifail = PS_where_used_all ( tInT8_AttrValueFound[j], PS_where_used_all_levels , &iParents_cnt, &piParents_Level, &ptParents_tag);
					for(iPrg = 0; iPrg < iParents_cnt && ifail == ITK_ok ; iPrg++)
					{
						ifail = AOM_ask_value_string( ptParents_tag[iPrg], "object_type", &pcProg_type);
						if (tc_strcmp(pcProg_type, "TI_Program Revision") == 0)
						{
							ifail = GRM_find_relation_type("IMAN_master_form", &trelation_type);
							ifail = GRM_list_secondary_objects_only ( ptParents_tag[iPrg],trelation_type,&iIRMF_cnt,&ptIRMF_list);

							/* Item rev master form will always be just one */
							ifail = AOM_ask_value_strings ( ptIRMF_list[0], "t8_3tidivisions", &idiv_cnt, &pcdiv_list);
							for (d=0; d<idiv_cnt; d++)
							{
								if (tc_strcmp(pcdiv_list[d], acTempkey_TIDivisions) == 0)
								{
									//tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
									if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProg_type,acTempkey_ItemType) == 0 )
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
									}
									if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProgVar_type,acTempkey_ItemType) == 0 )
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
									}
									else if (tc_strcmp(acTempkey_ItemType, "") ==0)
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
									}

									//****************************************************************************************************************
									// Searching for Child item tags using "check_for_child_items" function and passing the tags to UniqueObjects list
									//****************************************************************************************************************

									//Allocating Memory to pointer tag "ptchild_tags_list"...
									if (ptchild_tags_list == NULL)
									{
										ptchild_tags_list = (tag_t *)malloc(200*sizeof(tag_t));
									}
									ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);

									// Calling the check_for_child_items Function...
									ifail = check_for_child_items(tInT8_AttrValueFound[j],&ptchild_tags_list, &iTags_cnt);
									iTotalTags_cnt = iTags_cnt;

									// Checking for chid item items type...
									for (jj = 0; jj < iTotalTags_cnt;jj++)
									{
										ifail = AOM_ask_value_string( ptchild_tags_list[jj], "object_type", &pcChild_object_type);

										if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcChild_object_type,acTempkey_ItemType) == 0 )
										{
											tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
										}
										else if (tc_strcmp(acTempkey_ItemType, "") ==0)
										{
											tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
										}
									}
									itagscnt = 0;
									iTags_cnt = 0;
									iTotalTags_cnt = 0;
									//free(ptchild_tags_list);
									if (ptchild_tags_list != NULL)
									{
										free(ptchild_tags_list);
										ptchild_tags_list = NULL;
									}
									//SAFE_MEM_free(ptchild_tags_list);
								}
							}
						}
						SAFE_MEM_free( pcProg_type);
					}
					SAFE_MEM_free( pcProgVar_ID);
					SAFE_MEM_free( pcProgVar_type);
				}
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "object_type", &pcProgVar_type);

					ifail =  GRM_find_relation_type("IMAN_master_form", &trelation_type);
					ifail =  GRM_list_secondary_objects_only (tInT8_AttrValueFound[j],trelation_type,&iIRMF_cnt,&ptIRMF_list);

					/* Item rev master form will always be just one */
					ifail = AOM_ask_value_string( ptIRMF_list[0], "t1a4programname", &pcProg_name);

					// Find the existing Query
					ifail = QRY_find("General...", &tquery);
					if (ifail == ITK_ok )
					{
						char	*pcqry_values[2] =  {pcProg_name, "TI_Program Revision"};
						ifail =  QRY_execute(tquery, 2, pcqry_entries, pcqry_values, &iqry_found_cnt, &ptqry_found);
					}		
					if(iqry_found_cnt > 0)
					{		
						for(i=0;i<iqry_found_cnt;i++)
						{
							ifail = AOM_ask_value_string( ptqry_found[i], "object_type", &pcProg_type);
							ifail = GRM_find_relation_type("IMAN_master_form", &trelation_type);
							ifail = GRM_list_secondary_objects_only ( ptqry_found[i],trelation_type,&iIRMF_cnt,&ptIRMF_list);

							/* Item rev master form will always be just one */
							ifail = AOM_ask_value_strings ( ptIRMF_list[0], "t8_3tidivisions", &idiv_cnt, &pcdiv_list);
							for (d=0; d<idiv_cnt; d++)
							{
								if (tc_strcmp(pcdiv_list[d], acTempkey_TIDivisions) == 0)
								{
									//tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[iqry_found_cnt]);
									if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProg_type,acTempkey_ItemType) == 0 )
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[i]);
									}
									if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProgVar_type,acTempkey_ItemType) == 0 )
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
									}
									else if (tc_strcmp(acTempkey_ItemType, "") ==0)
									{
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[i]);
										tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
									}

									//****************************************************************************************************************
									// Searching for Child item tags using "check_for_child_items" function and passing the tags to UniqueObjects list
									//****************************************************************************************************************

									//Allocating Memory to pointer tag "ptchild_tags_list"...
									if (ptchild_tags_list == NULL)
									{
										ptchild_tags_list = (tag_t *)malloc(200*sizeof(tag_t));
									}
									ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);

									// Calling the check_for_child_items Function...
									ifail = check_for_child_items(tInT8_AttrValueFound[j],&ptchild_tags_list, &iTags_cnt);
									iTotalTags_cnt = iTags_cnt;

									// Checking for chid item items type...
									for (jj = 0; jj < iTotalTags_cnt;jj++)
									{
										ifail = AOM_ask_value_string( ptchild_tags_list[jj], "object_type", &pcChild_object_type);

										if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcChild_object_type,acTempkey_ItemType) == 0 )
										{
											tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
										}
										else if (tc_strcmp(acTempkey_ItemType, "") ==0)
										{
											tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
										}
									}
									itagscnt = 0;
									iTags_cnt = 0;
									iTotalTags_cnt = 0;
									//free(ptchild_tags_list);
									if (ptchild_tags_list != NULL)
									{
										free(ptchild_tags_list);
										ptchild_tags_list = NULL;
									}
									//SAFE_MEM_free(ptchild_tags_list);
								}
							}
							SAFE_MEM_free(pcdiv_list);
							SAFE_MEM_free(pcProg_type);
						}
					}
					SAFE_MEM_free( pcProgVar_ID);
					SAFE_MEM_free( pcProgVar_type);
				}

			}

			if (tc_strcmp(acTempkey_TIDivisions, "") ==0)
			{
				//**************************************************************************************
				//  Passing TI_Program Variant revision tags to UniqueObjects list
				//**************************************************************************************
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "object_type", &pcProgVar_type);

					if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProgVar_type,acTempkey_ItemType) == 0 )
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
					}
					else if (tc_strcmp(acTempkey_ItemType, "") ==0)
					{
						tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
					}
					SAFE_MEM_free( pcProgVar_ID);
					SAFE_MEM_free( pcProgVar_type);
				}

				//**********************************************************************************************************
				//  Searching for TI_Program Revision tags using where using call and passing the tags to UniqueObjects list
				//**********************************************************************************************************
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					ifail = PS_where_used_all ( tInT8_AttrValueFound[j], PS_where_used_all_levels , &iParents_cnt, &piParents_Level, &ptParents_tag);
					for(iPrg = 0; iPrg < iParents_cnt && ifail == ITK_ok ; iPrg++)
					{
						ifail = AOM_ask_value_string( ptParents_tag[iPrg], "object_type", &pcProg_type);
	 
						if (tc_strcmp(pcProg_type, "TI_Program Revision") == 0)
						{
							//tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
							if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProg_type,acTempkey_ItemType) == 0 )
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
							}
							else if (tc_strcmp(acTempkey_ItemType, "") ==0)
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptParents_tag[iPrg]);
							}
						}
						SAFE_MEM_free( pcProg_type);
					}
					SAFE_MEM_free( ptParents_tag);
				}
				//******************************************************************************************************
				// Searching for TI_Program Revision tags using General Query and passing the tags to UniqueObjects list
				//******************************************************************************************************
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					ifail =  GRM_find_relation_type("IMAN_master_form", &trelation_type);
					ifail =  GRM_list_secondary_objects_only (tInT8_AttrValueFound[j],trelation_type,&iIRMF_cnt,&ptIRMF_list);

					/* Item rev master form will always be just one */
					ifail = AOM_ask_value_string( ptIRMF_list[0], "t1a4programname", &pcProg_name);

					// Find the existing Query
					ifail = QRY_find("General...", &tquery);
					if (ifail == ITK_ok )
					{
						char	*pcqry_values[2] =  {pcProg_name, "TI_Program Revision"};
						ifail =  QRY_execute(tquery, 2, pcqry_entries, pcqry_values, &iqry_found_cnt, &ptqry_found);
					}		
					if(iqry_found_cnt > 0)
					{		
						for(i=0;i<iqry_found_cnt;i++)
						{
							ifail = AOM_ask_value_string( ptqry_found[i], "object_type", &pcProg_type);

							//tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[iqry_found_cnt]);
							if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcProg_type,acTempkey_ItemType) == 0 )
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[i]);
							}
							else if (tc_strcmp(acTempkey_ItemType, "") ==0)
							{
								tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptqry_found[i]);
							}
							SAFE_MEM_free( pcProg_type);
						}
					}
				}
				//****************************************************************************************************************
				// Searching for Child item tags using "check_for_child_items" function and passing the tags to UniqueObjects list
				//****************************************************************************************************************
				for(j = 0; j < iNumInT8_AttrValueFound;j++)
				{
					//Allocating Memory to pointer tag "ptchild_tags_list"...
					if (ptchild_tags_list == NULL)
					{
						ptchild_tags_list = (tag_t *)malloc(200*sizeof(tag_t));
					}
					ifail = AOM_ask_value_string( tInT8_AttrValueFound[j], "item_id", &pcProgVar_ID);

					// Calling the check_for_child_items Function...
					ifail = check_for_child_items(tInT8_AttrValueFound[j],&ptchild_tags_list, &iTags_cnt);
					iTotalTags_cnt = iTags_cnt;

					// Checking for chid item items type...
					for (jj = 0; jj < iTotalTags_cnt;jj++)
					{
						ifail = AOM_ask_value_string( ptchild_tags_list[jj], "object_type", &pcChild_object_type);

						if ((tc_strcmp(acTempkey_ItemType, "") !=0) && tc_strcmp(pcChild_object_type,acTempkey_ItemType) == 0 )
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
						}
						else if (tc_strcmp(acTempkey_ItemType, "") ==0)
						{
							tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptchild_tags_list[jj]);
						}
						SAFE_MEM_free(pcChild_object_type);
					}
					itagscnt = 0;
					iTags_cnt = 0;
					iTotalTags_cnt = 0;
					//free(ptchild_tags_list);
					if (ptchild_tags_list != NULL)
					{
						free(ptchild_tags_list);
						ptchild_tags_list = NULL;
						//ptchild_tags_list = NULL;
					}
					SAFE_MEM_free(pcProgVar_ID);
				}
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
		}

		//total no. of out result count	
		*num_found = iNumTotalTags;
		if((*num_found) > 0)
		{
			*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
		}
		
		indx = 0;
		while(UniqueObjects)
		{
			tempObjects = UniqueObjects;
			(*found)[indx] = tempObjects->tUniqueWSOMObjects;
			indx++;
     		UniqueObjects = UniqueObjects->next;
			free( tempObjects );
			tempObjects = NULL;
		}

		//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				ifail = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!ifail)
					ifail = ITEM_ask_id(tItem_1, acItem_1);
				if(!ifail)
				{
					ifail = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!ifail)
						ifail = ITEM_ask_id(tItem_2, acItem_2);
					if(!ifail)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							ifail = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!ifail)
								ifail = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!ifail)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

		tiauto_clearTagStack(UniqueObjects);				
	}
	return ifail;
}
extern int check_for_child_items(tag_t tItemRev,tag_t **ptfound_childtags, int *piTotal_tags_found)
{
	int     ifail                   = 0;
 	int		iItemRevBvrCount		= 0;
	int		iNumOccs				= 0;
	int     iCount                  = 0;   

	tag_t   *ptItemRevBvrs			= NULL;
	tag_t   tChildItem				= NULLTAG;
	tag_t	tChildBomView			= NULLTAG;
	tag_t   *ptOccs					= NULL;
	
	ifail = ITEM_rev_list_bom_view_revs ( tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);

	//If the item doesn't have a precise BOM, we need not proceed further
	if ( (ifail == ITK_ok) && iItemRevBvrCount > 0 )
	{
		ifail = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);

		// If the BVR does not have any child component, no need to proceed further
		for (iCount = 0; (iCount < iNumOccs) && (ifail == ITK_ok) ; iCount++)
		{
			tChildItem = NULLTAG;
			tChildBomView = NULLTAG;

			ifail = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount], &tChildItem, &tChildBomView);

			if(ifail == ITK_ok && tChildItem != NULLTAG )
			{
				(*ptfound_childtags)[itagscnt] = tChildItem;
				itagscnt++;
				*piTotal_tags_found = itagscnt;

				ifail = check_for_child_items( tChildItem, ptfound_childtags, piTotal_tags_found );
			}
		}
	}
    SAFE_MEM_free (ptItemRevBvrs);
    SAFE_MEM_free (ptOccs);

    return ifail;
}

/*=============================================================================================================
*TIAUTO_find_Change_Rev_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "Change Affected programs" user query.
================================================================================================================*/
extern int TIAUTO_find_change_rev_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{	
	int						j = 0;
	int						indx = 0;	
	int						iFail = ITK_ok;
	int						iArgIndex = 0;
	char					*pcProg = NULL;
	char					*pcDiv = NULL;
	char					*pcDesc = NULL;
	//char					*pcSite = NULL;//Check NULL or *
	char					*pcSite = "*";//Check NULL or *
	char					*pcGroup = "*";
	char					*pcOwner = "*";
	char					*pcChangeID = "*";
	char					*pcRevID = "*";
	char					*pcLast_Mod_User = "*";
	char					*pcRel_Stat = NULL;
	char					*pcTask = NULL;
	int						iNumTotalTags = 0;
	int						iCAP1_NumChItemFound = 0;
	int						iCAP2_NumChItemFound = 0;
	int						iCAP3_NumChItemFound = 0;
	int						iECR_NumChItemFound = 0;
	int						iCI_NumChItemFound = 0;
	int						iPMR1_NumChItemFound = 0;
	int						iPMR2_NumChItemFound = 0;
	int						iOBS_NumChItemFound = 0;
	int						iDEV_NumChItemFound = 0;
	int						iSite               = 0;
	int						iSiteID             = 0;
	date_t					dCre_Aft = NULLDATE;
	date_t					dCre_Bef = NULLDATE;
	date_t					dMode_Aft = NULLDATE;
	date_t					dMode_Bef = NULLDATE;
	logical					lValid_date=true;
	logical					alIn_data[16] = {false};
	TIA_UniqueWSOMObjects	*tempObjects = NULL;
	TIA_UniqueWSOMObjects	*UniqueObjects = NULL;
	tag_t					*ptCAP_ChItemFound = NULL;
	tag_t					*ptECR_ChItemFound = NULL;
	tag_t					*ptCI_ChItemFound = NULL;
	tag_t					*ptPMR_ChItemFound = NULL;
	tag_t					*ptOBS_ChItemFound = NULL;
	tag_t					*ptDEV_ChItemFound = NULL;
	tag_t					tSitetag           = NULLTAG;
	char					szErrorString[TIAUTO_error_message_len+1]	= "";
	char					acSiteName[SA_site_size_c+1]				= {'\0'};

	//Check if the user query found is of type TI_Super_Search
	if(tc_strcmp(name,"TI Change Rev (Affected Programs)") == 0)
	{		
		for ( iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{
			if(tc_strcasecmp(names[iArgIndex], "Affected Program") == 0 || tc_strcasecmp(names[iArgIndex], "AffectedProgram") == 0)
			{
				pcProg=values[iArgIndex];
				alIn_data[0]=true;
			}
			else if(tc_strcasecmp(names[iArgIndex], "Created After") == 0 || tc_strcasecmp(names[iArgIndex], "CreatedAfter") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dCre_Aft));
					alIn_data[1]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Created Before") == 0 || tc_strcasecmp(names[iArgIndex], "CreatedBefore") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dCre_Bef));
					alIn_data[2]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Modified After") == 0 || tc_strcasecmp(names[iArgIndex], "ModifiedAfter") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dMode_Aft));
					alIn_data[3]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Modified Before") == 0 || tc_strcasecmp(names[iArgIndex], "ModifiedBefore") == 0)
			{
				if(values[iArgIndex])
				{
					TIAUTO_ITKCALL(iFail,DATE_string_to_date_t(values[iArgIndex],&lValid_date,&dMode_Bef));
					alIn_data[4]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "TI Divisions") == 0 || tc_strcasecmp(names[iArgIndex], "TIDivisions") == 0)
			{
				if(values[iArgIndex])
				{
					pcDiv=values[iArgIndex];
					alIn_data[5]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Change Description") == 0 || tc_strcasecmp(names[iArgIndex], "ChangeDescription") == 0)
			{
				if(values[iArgIndex])
				{
					pcDesc=values[iArgIndex];
					alIn_data[6]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning User") == 0 || tc_strcasecmp(names[iArgIndex], "OwningUser") == 0)
			{
				if(values[iArgIndex])
				{
					pcOwner=values[iArgIndex];
					alIn_data[7]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning Site") == 0 || tc_strcasecmp(names[iArgIndex], "OwningSite") == 0)
			{
				if(values[iArgIndex])
				{
					iFail = POM_site_id(&iSite);
					if(iSite != 0)
						iFail = SA_find_site_by_id(iSite,&tSitetag);
					if(iFail == ITK_ok && tSitetag!= NULLTAG)
						iFail = SA_ask_site_info(tSitetag,acSiteName,&iSiteID);

					pcSite=values[iArgIndex];

					if (tc_strcmp(pcSite, acSiteName) == 0)
					{
						alIn_data[13]=true;
					}
					else
					{
						alIn_data[8]=true;
					}
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Owning Group") == 0 || tc_strcasecmp(names[iArgIndex], "OwningGroup") == 0)
			{
				if(values[iArgIndex])
				{
					pcGroup=values[iArgIndex];
					alIn_data[9]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0 || tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				if(values[iArgIndex])
				{
					pcLast_Mod_User=values[iArgIndex];
					alIn_data[10]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Release Status") == 0 || tc_strcasecmp(names[iArgIndex], "ReleaseStatus") == 0)
			{
				if(values[iArgIndex])
				{
					pcRel_Stat=values[iArgIndex];
					alIn_data[11]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Current Task") == 0 || tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				if(values[iArgIndex])
				{
					pcTask=values[iArgIndex];
					alIn_data[12]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Change ID") == 0 || tc_strcasecmp(names[iArgIndex], "ChangeID") == 0)
			{
				if(values[iArgIndex])
				{
					pcChangeID=values[iArgIndex];
					alIn_data[14]=true;
				}
			}
			else if(tc_strcasecmp(names[iArgIndex], "Revision ID") == 0 || tc_strcasecmp(names[iArgIndex], "RevisionID") == 0)
			{
				if(values[iArgIndex])
				{
					pcRevID=values[iArgIndex];
					alIn_data[15]=true;
				}
			}
		}

		if(alIn_data[0]==true)
		{
			//Check in CAP Form
			iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "t8_t1a120cap", "t8_t1a120affectedprograms", "t8_t1a120tidivision", "t8_t1a120changedescription",
													   &iCAP1_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP1_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in CAP2 Form
			iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a190CAP2", "t8_t1a190affectedprograms", "t8_t1a190productgroup", "t8_t1a190changedescription",
													   &iCAP2_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP2_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in New CAP3 Form
			iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a190CAP3", "t8_t1a190affectedprograms", "t8_t1a190productgroup", "t8_t1a190changedescription",
													   &iCAP3_NumChItemFound, &ptCAP_ChItemFound);
			for(j = 0; j<iCAP3_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCAP_ChItemFound[j]);
			}
			SAFE_MEM_free(ptCAP_ChItemFound);
			//Check in PMR Form
			iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "t1A84PMR", "t1A84affectedprogram", "t8_t1a84tidivision", "t1a84changedescription",
													   &iPMR1_NumChItemFound, &ptPMR_ChItemFound);
			for(j = 0; j<iPMR1_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptPMR_ChItemFound[j]);
			}
			SAFE_MEM_free(ptPMR_ChItemFound);
			//Check in New PMR Form
			iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
													   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
													   alIn_data, "T8_t1a193pmr2", "t8_193affectedprogram", "t8_193productgroup", "t8_193changedescription",
													   &iPMR2_NumChItemFound, &ptPMR_ChItemFound);
			for(j = 0; j<iPMR2_NumChItemFound ;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptPMR_ChItemFound[j]);
			}
			SAFE_MEM_free(ptPMR_ChItemFound);
			//For other then CAP and PMR forms
			{
				alIn_data[5]=false;//TI Divisions for other forms doesnot exist
				//Check in ECR Form
				iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A40ECR", "t1A40affectedprograms", NULL,"t1a40changedescription",
														   &iECR_NumChItemFound, &ptECR_ChItemFound);
				for(j = 0; j<iECR_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptECR_ChItemFound[j]);
				}
				SAFE_MEM_free(ptECR_ChItemFound);
				//Check in CI Form
				iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A37CI", "t1A37affectedprograms", NULL, "t1a37changedescription",
														   &iCI_NumChItemFound, &ptCI_ChItemFound);
				for(j = 0; j<iCI_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptCI_ChItemFound[j]);
				}
				SAFE_MEM_free(ptCI_ChItemFound);
				
				//Check in OBS Form
				iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A52OBS", "t1A52affectedprograms", NULL,"t1a52description",
														   &iOBS_NumChItemFound, &ptOBS_ChItemFound);
				for(j = 0; j<iOBS_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptOBS_ChItemFound[j]);
				}
				SAFE_MEM_free(ptOBS_ChItemFound);	
				//Check in DEV Form
				iFail=find_change_rev_affected_program_in_form(pcProg, pcChangeID, pcRevID, dCre_Aft, dCre_Bef, dMode_Aft, dMode_Bef,
														   pcDiv, pcDesc, pcSite, pcGroup, pcOwner, pcLast_Mod_User, pcRel_Stat, pcTask,
														   alIn_data, "t1A51DEV", "t1A51affectedprograms", NULL, "t1a51deviationdescriptio",
														   &iDEV_NumChItemFound, &ptDEV_ChItemFound);
				for(j = 0; j<iDEV_NumChItemFound ;j++)
				{
					tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,ptDEV_ChItemFound[j]);
				}
				SAFE_MEM_free(ptDEV_ChItemFound);	
			}
			
			//total no. of out result count		
			*num_found = iNumTotalTags;
			if((*num_found) > 0)
			{
				*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
			}			
			indx = 0;
			while(UniqueObjects)
			{
				tempObjects = UniqueObjects;
				(*found)[indx] = tempObjects->tUniqueWSOMObjects;
				indx++;
         		UniqueObjects = UniqueObjects->next;
				free( tempObjects );
				tempObjects = NULL;
			}
			tiauto_clearTagStack(UniqueObjects);
		}
		else
		{
			//Error message	
			TI_sprintf(szErrorString, "Empty \"Affected program\" search field. Retry with valid program name.\n"); 
			TC_write_syslog(szErrorString);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_AFFECTED_PROGRAM, szErrorString);
			iFail = TIAUTO_NOT_VALID_AFFECTED_PROGRAM;			
		}
	}
	return iFail;
}

/*=============================================================================================================
*TIAUTO_find_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "TI Change" user query.
================================================================================================================*/
extern int TIAUTO_find_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0; 	
	int iNumInT8_AttrValueFound                 = 0;	
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
	
  	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ChangeID[1024]							= {'\0'};
	char tempkey_ChangeName[1024]                       = {'\0'};
	char tempkey_ObjDesc[1024] 							= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_CustTrackingNum[1024]					= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_IsProdImpacted[1024]					= {'\0'};
	char tempkey_SuggChangeImpDateAfter[1024]			= {'\0'};
	char tempkey_SuggChangeImpDateBefore[1024]			= {'\0'};
	char tempkey_DesignWorkReq[1024]					= {'\0'};
	char tempkey_LevelOfReq[1024]						= {'\0'};
	char tempkey_MaterialImpacted[1024]					= {'\0'};
	char tempkey_TypeOfChange[1024]						= {'\0'};
	char tempkey_BillableCompType[1024]					= {'\0'};
	char tempkey_BillableComp[1024]						= {'\0'};
	char tempkey_CustAuthNum[1024]						= {'\0'};
	char tempkey_CustName[1024]							= {'\0'};
	char tempkey_CustNameType[1024]						= {'\0'};
	char tempkey_CustAppReq[1024]						= {'\0'};
	char tempkey_RFQIssuedAfter[1024]					= {'\0'};
	char tempkey_RFQIssuedBefore[1024]					= {'\0'};
	char tempkey_NewBusiness[1024]						= {'\0'};
	char tempkey_IsEnggAppReq[1024]						= {'\0'};
	char tempkey_DesignValReq[1024]						= {'\0'};
	char tempkey_InventoryStatus[1024]					= {'\0'};
	char tempkey_PMRReason[1024]						= {'\0'};
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	
	//TIA_ChangeAttrs *tempAttrs						= NULL;

	TIA_ChangeAttrs *Parsed_Attrs					= NULL;
	TIA_ChangeAttrs *CAP_Attrs						= NULL;
	TIA_ChangeAttrs *PMR_Attrs						= NULL;
	TIA_ChangeAttrs *OBS_Attrs						= NULL;
	TIA_ChangeAttrs *DEV_Attrs						= NULL;	
	TIA_ChangeAttrs *PCI_Attrs						= NULL;
	TIA_ChangeAttrs *CRO_Attrs						= NULL;
	TIA_ChangeAttrs *STD_Attrs						= NULL;

	TIA_ChangeAttrs *temp1					= NULL;
	TIA_ChangeAttrs *temp2					= NULL;
	
	int iParsed_Attrs								= 0;
	int iCAP_Attrs									= 0;
	int iPMR_Attrs									= 0;
	int iOBS_Attrs									= 0;
	int iDEV_Attrs									= 0;
	int iPCI_Attrs									= 0;
	int iCRO_Attrs									= 0;
	int iSTD_Attrs									= 0;
	
	logical lfound = false;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
	
	//Add CAP attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_AffPlant");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_IsProdImpacted");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuggChangeImpDateAfter");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuggChangeImpDateBefore");

	//Add CCR attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_BillableComp");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustAppReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustAuthNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustName");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustNameType");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_RFQIssuedAfter");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_RFQIssuedBefore");

	//Add NEW ECR attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_DesignWorkReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MaterialImpacted");

	//Add PMR attributes to struct
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_AffPlant");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_BillableComp");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustAuthNum");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustName");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustNameType");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_RFQIssuedAfter");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_RFQIssuedBefore");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_PMRReason");

	//Add ECR attributes to struct
	/*tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_DesignWorkReq");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_DesignValReq");*/

	//Add CI attributes to struct
	/*tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_NewBusiness");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuggChangeImpDateAfter");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuggChangeImpDateBefore");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuppTrackingNum");
	*/
	//Add OBS attributes to struct
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_InventoryStatus");

	//Add DEV attributes to struct
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_BillableComp");

	

	//Add PCI attributes to struct
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_AffPlant");

	//Add CRO attributes to struct
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_IsEnggAppReq");

	//Add Standard attributes to struct
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_TargetReleaseStatus");

	if(tc_strcmp(name," TI Change") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Change ID") == 0)
			{
				tc_strcpy(tempkey_ChangeID,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeID");
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_ChangeName,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeName");
			}
			if (tc_strcasecmp(names[iArgIndex], "Description") == 0)
			{
				tc_strcpy(tempkey_ObjDesc,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ObjDesc");
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CAD");
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CBD");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MAD");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MBD");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningUser");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningGroup");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
					tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningSite");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
					tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningSite");
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_LastModUser");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ReleaseStatus");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CurrentTask");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_AffPgms");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_AffPlant");
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TIDiv");
			}     
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ProductGroup");
			}     
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeDesc");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeDriver");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TargetReleaseStatus");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ReqGroup");
			}      
			if (tc_strcasecmp(names[iArgIndex], "Customer Tracking Number") == 0)
			{
				tc_strcpy(tempkey_CustTrackingNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustTrackingNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuppTrackingNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Product Impacted") == 0)
			{
				tc_strcpy(tempkey_IsProdImpacted,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_IsProdImpacted");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Suggested Change Implementation Date After") == 0)
			{
				tc_strcpy(tempkey_SuggChangeImpDateAfter,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuggChangeImpDateAfter");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Suggested Change Implementation Date Before") == 0)
			{
				tc_strcpy(tempkey_SuggChangeImpDateBefore,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuggChangeImpDateBefore");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Design Work Required") == 0)
			{
				tc_strcpy(tempkey_DesignWorkReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_DesignWorkReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Level of Request") == 0)
			{
				tc_strcpy(tempkey_LevelOfReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_LevelOfReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Material Impacted") == 0)
			{
				tc_strcpy(tempkey_MaterialImpacted,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MaterialImpacted");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Type of Change") == 0)
			{
				tc_strcpy(tempkey_TypeOfChange,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TypeOfChange");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company Type") == 0)
			{
				tc_strcpy(tempkey_BillableCompType,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_BillableCompType");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company") == 0)
			{
				tc_strcpy(tempkey_BillableComp,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_BillableComp");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Authorization Number") == 0)
			{
				tc_strcpy(tempkey_CustAuthNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustAuthNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Name Type") == 0)
			{
				tc_strcpy(tempkey_CustNameType,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustNameType");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				tc_strcpy(tempkey_CustName,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustName");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Approval Required") == 0)
			{
				tc_strcpy(tempkey_CustAppReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustAppReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued After") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedAfter,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_RFQIssuedAfter");
			}  
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued Before") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedBefore,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_RFQIssuedBefore");
			} 
			if (tc_strcasecmp(names[iArgIndex], "New Business") == 0)
			{
				tc_strcpy(tempkey_NewBusiness,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_NewBusiness");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Engineering Approval Required") == 0)
			{
				tc_strcpy(tempkey_IsEnggAppReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_IsEnggAppReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Design Validation Required") == 0)
			{
				tc_strcpy(tempkey_DesignValReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_DesignValReq");
			}     
			if (tc_strcasecmp(names[iArgIndex], "Inventory Status") == 0)
			{
				tc_strcpy(tempkey_InventoryStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_InventoryStatus");
			}    
			if (tc_strcasecmp(names[iArgIndex], "PMR Reason") == 0)
			{
				tc_strcpy(tempkey_PMRReason,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_PMRReason");
			}     
		}
	}	

	//Check in CAP Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		/*temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(found == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)*/
		iRetCode = find_change_cap (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		iRetCode = find_change_cap (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		iRetCode = find_change_cap (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CAP Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in CAP2 Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in CAP3 Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) || (strcmp (tempkey_PMRReason ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PMR_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"PMR",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR2 process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) || (strcmp (tempkey_PMRReason ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PMR_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"pmr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in ECR Form
	//if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
	//	 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
	//	 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
	//	 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) ||
	//	 (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_DesignValReq ,"") != 0) )	
	//{
	//	iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
	//							tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
	//							tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
	//							tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
	//							tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
	//							tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
	//							tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
	//							tempkey_InventoryStatus,tempkey_PMRReason,"t1a40ecr",
	//							&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

	//	for(j = 0; j < iNumInT8_AttrValueFound;j++)
	//	{
	//		tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
	//	}
	//	SAFE_MEM_free(tInT8_AttrValueFound);
	//	iNumInT8_AttrValueFound = 0;
	//}

	////Check in CI Form
	//if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
	//	 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
	//	 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
	//	 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_NewBusiness ,"") != 0) || 
	//	 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0)  )	
	//{
	//	iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
	//							tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
	//							tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
	//							tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
	//							tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
	//							tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
	//							tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
	//							tempkey_InventoryStatus,tempkey_PMRReason,"t1a37CI",
	//							&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

	//	for(j = 0; j < iNumInT8_AttrValueFound;j++)
	//	{
	//		tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
	//	}
	//	SAFE_MEM_free(tInT8_AttrValueFound);
	//	iNumInT8_AttrValueFound = 0;
	//}

	//Check in OBS Process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_InventoryStatus ,"") != 0) )
	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = OBS_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"obs",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in DEV Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  ||
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = DEV_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"dev",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CCR Form
	/*if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || 
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0)  || (strcmp (tempkey_RFQIssuedBefore ,"") != 0))	
	{
		iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"t1a41CCR",
								&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}*/

	//Check in NEW ECR Form
	/*if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_DesignWorkReq ,"") != 0)  || 
		 (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0) )	
	{
		iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"t8_t1a133ecr",
								&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}*/

	//Check in PCI Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_AffPlant ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PCI_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"pci",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CRO Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_IsEnggAppReq ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CRO_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cro",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in STD Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0)  || 
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = STD_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change (tempkey_ChangeID,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"STD",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
	for(z=0;z<(indx-1);z++)
	{
		tTemp=NULL_TAG;
		for(i=(z+1);i<indx;i++)
		{
			iRetCode = ITEM_ask_id((*found)[z], acItem_1);
			if(!iRetCode)
			{
				iRetCode = ITEM_ask_id((*found)[i], acItem_2);
				if(!iRetCode)
				{
					if(tc_strcmp(acItem_1,acItem_2)>0)
					{
						tTemp=(*found)[z];
						(*found)[z] = (*found)[i];
						(*found)[i] = tTemp;
					}
				}
			}
		}
	}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}
/*=============================================================================================================
*TIAUTO_find_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "TI Change Rev" user query.
================================================================================================================*/
extern int TIAUTO_find_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0; 	
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ChangeID[1024]							= {'\0'};
	char tempkey_ChangeRev[1024]						= {'\0'};
	char tempkey_ChangeName[1024]                       = {'\0'};
	char tempkey_ObjDesc[1024] 							= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_CustTrackingNum[1024]					= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_IsProdImpacted[1024]					= {'\0'};
	char tempkey_SuggChangeImpDateAfter[1024]			= {'\0'};
	char tempkey_SuggChangeImpDateBefore[1024]			= {'\0'};
	char tempkey_DesignWorkReq[1024]					= {'\0'};
	char tempkey_LevelOfReq[1024]						= {'\0'};
	char tempkey_MaterialImpacted[1024]					= {'\0'};
	char tempkey_TypeOfChange[1024]						= {'\0'};
	char tempkey_BillableCompType[1024]					= {'\0'};
	char tempkey_BillableComp[1024]						= {'\0'};
	char tempkey_CustAuthNum[1024]						= {'\0'};
	char tempkey_CustName[1024]							= {'\0'};
	char tempkey_CustNameType[1024]						= {'\0'};
	char tempkey_CustAppReq[1024]						= {'\0'};
	char tempkey_RFQIssuedAfter[1024]					= {'\0'};
	char tempkey_RFQIssuedBefore[1024]					= {'\0'};
	char tempkey_NewBusiness[1024]						= {'\0'};
	char tempkey_IsEnggAppReq[1024]						= {'\0'};
	char tempkey_DesignValReq[1024]						= {'\0'};
	char tempkey_InventoryStatus[1024]					= {'\0'};
	char tempkey_PMRReason[1024]						= {'\0'};
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	
	//TIA_ChangeAttrs *tempAttrs						= NULL;

	TIA_ChangeAttrs *Parsed_Attrs					= NULL;
	TIA_ChangeAttrs *CAP_Attrs						= NULL;
	TIA_ChangeAttrs *PMR_Attrs						= NULL;
	TIA_ChangeAttrs *ECR_Attrs						= NULL;
	TIA_ChangeAttrs *CI_Attrs						= NULL;
	TIA_ChangeAttrs *OBS_Attrs						= NULL;
	TIA_ChangeAttrs *DEV_Attrs						= NULL;
	TIA_ChangeAttrs *PCI_Attrs						= NULL;
	TIA_ChangeAttrs *CRO_Attrs						= NULL;
	TIA_ChangeAttrs *STD_Attrs						= NULL;

	TIA_ChangeAttrs *temp1					= NULL;
	TIA_ChangeAttrs *temp2					= NULL;
	
	int iParsed_Attrs								= 0;
	int iCAP_Attrs									= 0;
	int iPMR_Attrs									= 0;
	int iECR_Attrs									= 0;
	int iCI_Attrs									= 0;
	int iOBS_Attrs									= 0;
	int iDEV_Attrs									= 0;	
	int iPCI_Attrs									= 0;
	int iCRO_Attrs									= 0;
	int iSTD_Attrs									= 0;
	
	logical lfound = false;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);
	
	//Add CAP attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_AffPlant");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_IsProdImpacted");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuggChangeImpDateAfter");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_SuggChangeImpDateBefore");

	//Add CCR attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_BillableComp");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustAppReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustAuthNum");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustName");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_CustNameType");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_RFQIssuedAfter");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_RFQIssuedBefore");

	//Add NEW ECR attributes to struct
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_DesignWorkReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&CAP_Attrs,&iCAP_Attrs,"tempkey_MaterialImpacted");

	//Add PMR attributes to struct
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_AffPlant");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_BillableComp");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustAuthNum");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustName");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_CustNameType");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_RFQIssuedAfter");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_RFQIssuedBefore");
	tiauto_Store_ChangeAttrs(&PMR_Attrs,&iPMR_Attrs,"tempkey_PMRReason");

	//Add ECR attributes to struct
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_TargetReleaseStatus");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_LevelOfReq");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_TypeOfChange");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_DesignWorkReq");
	tiauto_Store_ChangeAttrs(&ECR_Attrs,&iECR_Attrs,"tempkey_DesignValReq");

	//Add CI attributes to struct
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_NewBusiness");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuggChangeImpDateAfter");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuggChangeImpDateBefore");
	tiauto_Store_ChangeAttrs(&CI_Attrs,&iCI_Attrs,"tempkey_SuppTrackingNum");
	
	//Add OBS attributes to struct
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&OBS_Attrs,&iOBS_Attrs,"tempkey_InventoryStatus");

	//Add DEV attributes to struct
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_ReqGroup");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_CustTrackingNum");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_SuppTrackingNum");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_BillableCompType");
	tiauto_Store_ChangeAttrs(&DEV_Attrs,&iDEV_Attrs,"tempkey_BillableComp");

	

	//Add PCI attributes to struct
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&PCI_Attrs,&iPCI_Attrs,"tempkey_AffPlant");

	//Add CRO attributes to struct
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_AffPgms");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&CRO_Attrs,&iCRO_Attrs,"tempkey_IsEnggAppReq");

	//Add Standard attributes to struct
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeID");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeRev");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeName");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ObjDesc");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CAD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CBD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_MAD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_MBD");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningUser");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningGroup");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_OwningSite");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_LastModUser");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ReleaseStatus");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_CurrentTask");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_TIDiv");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ProductGroup");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeDesc");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_ChangeDriver");
	tiauto_Store_ChangeAttrs(&STD_Attrs,&iSTD_Attrs,"tempkey_TargetReleaseStatus");

	if(tc_strcmp(name," TI Change Rev") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Change ID") == 0)
			{
				tc_strcpy(tempkey_ChangeID,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeID");
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				tc_strcpy(tempkey_ChangeRev,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeRev");
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_ChangeName,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeName");
			}
			if (tc_strcasecmp(names[iArgIndex], "Description") == 0)
			{
				tc_strcpy(tempkey_ObjDesc,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ObjDesc");
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CAD");
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CBD");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MAD");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MBD");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningUser");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningGroup");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
					tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningSite");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
					tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_OwningSite");
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_LastModUser");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ReleaseStatus");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CurrentTask");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_AffPgms");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_AffPlant");
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TIDiv");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ProductGroup");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeDesc");
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ChangeDriver");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TargetReleaseStatus");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_ReqGroup");
			}      
			if (tc_strcasecmp(names[iArgIndex], "Customer Tracking Number") == 0)
			{
				tc_strcpy(tempkey_CustTrackingNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustTrackingNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuppTrackingNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Product Impacted") == 0)
			{
				tc_strcpy(tempkey_IsProdImpacted,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_IsProdImpacted");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Suggested Change Implementation Date After") == 0)
			{
				tc_strcpy(tempkey_SuggChangeImpDateAfter,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuggChangeImpDateAfter");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Suggested Change Implementation Date Before") == 0)
			{
				tc_strcpy(tempkey_SuggChangeImpDateBefore,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_SuggChangeImpDateBefore");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Design Work Required") == 0)
			{
				tc_strcpy(tempkey_DesignWorkReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_DesignWorkReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Level of Request") == 0)
			{
				tc_strcpy(tempkey_LevelOfReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_LevelOfReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Material Impacted") == 0)
			{
				tc_strcpy(tempkey_MaterialImpacted,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_MaterialImpacted");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Type of Change") == 0)
			{
				tc_strcpy(tempkey_TypeOfChange,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_TypeOfChange");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company Type") == 0)
			{
				tc_strcpy(tempkey_BillableCompType,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_BillableCompType");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company") == 0)
			{
				tc_strcpy(tempkey_BillableComp,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_BillableComp");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Authorization Number") == 0)
			{
				tc_strcpy(tempkey_CustAuthNum,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustAuthNum");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Name Type") == 0)
			{
				tc_strcpy(tempkey_CustNameType,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustNameType");
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				tc_strcpy(tempkey_CustName,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustName");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Approval Required") == 0)
			{
				tc_strcpy(tempkey_CustAppReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_CustAppReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued After") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedAfter,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_RFQIssuedAfter");
			}  
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued Before") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedBefore,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_RFQIssuedBefore");
			} 
			if (tc_strcasecmp(names[iArgIndex], "New Business") == 0)
			{
				tc_strcpy(tempkey_NewBusiness,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_NewBusiness");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Engineering Approval Required") == 0)
			{
				tc_strcpy(tempkey_IsEnggAppReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_IsEnggAppReq");
			}   
			if (tc_strcasecmp(names[iArgIndex], "Design Validation Required") == 0)
			{
				tc_strcpy(tempkey_DesignValReq,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_DesignValReq");
			}     
			if (tc_strcasecmp(names[iArgIndex], "Inventory Status") == 0)
			{
				tc_strcpy(tempkey_InventoryStatus,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_InventoryStatus");
			}    
			if (tc_strcasecmp(names[iArgIndex], "PMR Reason") == 0)
			{
				tc_strcpy(tempkey_PMRReason,values[iArgIndex]);
				tiauto_Store_ChangeAttrs(&Parsed_Attrs,&iParsed_Attrs,"tempkey_PMRReason");
			}     
		}
	}	

	//Check in CAP Process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		/*temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(found == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)*/
		iRetCode = find_change_rev_cap (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		iRetCode = find_change_rev_cap (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		iRetCode = find_change_rev_cap (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CAP Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in CAP2 Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in CAP3 Workflow
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0) || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || 
		 (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) ||
		 (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0))
	
	{
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CAP_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
					
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) || (strcmp (tempkey_PMRReason ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PMR_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"PMR",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR2 process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_TIDiv ,"") != 0) ||
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0) || (strcmp (tempkey_PMRReason ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PMR_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"pmr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in ECR Form
	//if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
	//	 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
	//	 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
	//	 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) ||
	//	 (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_DesignWorkReq ,"") != 0) || (strcmp (tempkey_DesignValReq ,"") != 0) )	
	//{
	//	iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
	//							tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
	//							tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
	//							tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
	//							tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
	//							tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
	//							tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
	//							tempkey_InventoryStatus,tempkey_PMRReason,"t1a40ecr",
	//							&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

	//	for(j = 0; j < iNumInT8_AttrValueFound;j++)
	//	{
	//		tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
	//	}
	//	SAFE_MEM_free(tInT8_AttrValueFound);
	//	iNumInT8_AttrValueFound = 0;
	//}

	////Check in CI Form
	//if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
	//	 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
	//	 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
	//	 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_NewBusiness ,"") != 0) || 
	//	 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateAfter ,"") != 0) || (strcmp (tempkey_SuggChangeImpDateBefore ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0)  )	
	//{
	//	iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
	//							tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
	//							tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
	//							tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
	//							tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
	//							tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
	//							tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
	//							tempkey_InventoryStatus,tempkey_PMRReason,"t1a37CI",
	//							&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

	//	for(j = 0; j < iNumInT8_AttrValueFound;j++)
	//	{
	//		tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
	//	}
	//	SAFE_MEM_free(tInT8_AttrValueFound);
	//	iNumInT8_AttrValueFound = 0;
	//}

	//Check in OBS Process
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_InventoryStatus ,"") != 0) )
	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = OBS_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"obs",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in DEV Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  ||
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) ||
		 (strcmp (tempkey_BillableCompType ,"") != 0)  || (strcmp (tempkey_BillableComp ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;

		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = DEV_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"dev",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CCR Form
	/*if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_BillableCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillableComp ,"") != 0) || (strcmp (tempkey_CustAppReq ,"") != 0) || (strcmp (tempkey_CustAuthNum ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) || 
		 (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_RFQIssuedAfter ,"") != 0)  || (strcmp (tempkey_RFQIssuedBefore ,"") != 0))	
	{
		iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"t1a41CCR",
								&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}*/

	//Check in NEW ECR Form
	/*if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_DesignWorkReq ,"") != 0)  || 
		 (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) || (strcmp (tempkey_MaterialImpacted ,"") != 0) )	
	{
		iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDate,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssued,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"t8_t1a133ecr",
								&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}*/

	//Check in PCI Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_AffPlant ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = PCI_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"pci",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//Check in CRO Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_AffPgms ,"") != 0)  || 
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_IsEnggAppReq ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = CRO_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"cro",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in STD Form
	if ( (strcmp (tempkey_ChangeID ,"") != 0) || (strcmp (tempkey_ChangeRev ,"") != 0) || (strcmp (tempkey_ChangeName ,"") != 0) || (strcmp (tempkey_ObjDesc ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  || (strcmp (tempkey_OwningSite ,"") != 0) ||
		 (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) || (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0)  || 
		 (strcmp (tempkey_ProductGroup ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) )	
	{
		tInT8_AttrValueFound = 0;
		lfound = false;
		temp1 = Parsed_Attrs;
		while(temp1)
		{
			temp2 = STD_Attrs;
			while(temp2)
			{			
				if (tc_strcmp(temp2->acChangeAttrs,temp1->acChangeAttrs) == 0)
				{
					lfound = true;
					break;
				}
				else
				{
					lfound = false;
				}
				temp2 = temp2->next;
			}
			if(lfound == false)
			{
				break;
			}
			temp1 = temp1->next;
		}
		if(lfound == true)
			iRetCode = find_change_rev (tempkey_ChangeID,tempkey_ChangeRev,tempkey_ChangeName,tempkey_ObjDesc,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
								tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,
								tempkey_CurrentTask,tempkey_AffPgms,tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
								tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
								tempkey_SuggChangeImpDateAfter,tempkey_SuggChangeImpDateBefore,tempkey_DesignWorkReq,tempkey_LevelOfReq,tempkey_MaterialImpacted,tempkey_TypeOfChange,
								tempkey_BillableCompType,tempkey_BillableComp,tempkey_CustAuthNum,tempkey_CustName,tempkey_CustNameType,
								tempkey_CustAppReq,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,tempkey_NewBusiness,tempkey_IsEnggAppReq,tempkey_DesignValReq,
								tempkey_InventoryStatus,tempkey_PMRReason,"STD",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				iRetCode = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!iRetCode)
					iRetCode = ITEM_ask_id(tItem_1, acItem_1);
				if(!iRetCode)
				{
					iRetCode = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!iRetCode)
						iRetCode = ITEM_ask_id(tItem_2, acItem_2);
					if(!iRetCode)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							iRetCode = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!iRetCode)
								iRetCode = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!iRetCode)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}



/*=============================================================================================================
*TIAUTO_find_CAP_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "TI Change (CAP Form)" user query.
================================================================================================================*/
extern int TIAUTO_find_CAP_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0; 	
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
	
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_CustTrackingNum[1024]					= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_IsProdImpacted[1024]					= {'\0'};
	char tempkey_ImpAfter[1024]							= {'\0'};
	char tempkey_ImpBefore[1024]						= {'\0'};
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;
		
	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name," TI Change (CAP Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
			}    
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "Customer Tracking Number") == 0)
			{
				tc_strcpy(tempkey_CustTrackingNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Product Impacted?") == 0)
			{
				tc_strcpy(tempkey_IsProdImpacted,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Implementation After") == 0)
			{
				tc_strcpy(tempkey_ImpAfter,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Implementation Before") == 0)
			{
				tc_strcpy(tempkey_ImpBefore,values[iArgIndex]);
			} 
		}
	}	
	//Check in CAP Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) ||
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) ||
		 (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_ImpAfter ,"") != 0) || (strcmp (tempkey_ImpBefore ,"") != 0))
	
	{
		iRetCode = find_CAP_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_OwningUser,tempkey_OwningGroup,
									tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
									tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,
									tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,tempkey_ImpAfter,tempkey_ImpBefore,
									"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		if ((strcmp (tempkey_ImpAfter ,"") == 0) && (strcmp (tempkey_ImpBefore ,"") == 0))
		{
			iRetCode = find_CAP_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_OwningUser,tempkey_OwningGroup,
										tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
										tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,
										tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,tempkey_ImpAfter,tempkey_ImpBefore,
										"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		}
		if ((strcmp (tempkey_ImpAfter ,"") == 0) && (strcmp (tempkey_ImpBefore ,"") == 0))
		{
			iRetCode = find_CAP_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_OwningUser,tempkey_OwningGroup,
										tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
										tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,
										tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,tempkey_ImpAfter,tempkey_ImpBefore,
										"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		}
	}
	

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
	for(z=0;z<(indx-1);z++)
	{
		tTemp=NULL_TAG;
		for(i=(z+1);i<indx;i++)
		{
			iRetCode = ITEM_ask_id((*found)[z], acItem_1);
			if(!iRetCode)
			{
				iRetCode = ITEM_ask_id((*found)[i], acItem_2);
				if(!iRetCode)
				{
					if(tc_strcmp(acItem_1,acItem_2)>0)
					{
						tTemp=(*found)[z];
						(*found)[z] = (*found)[i];
						(*found)[i] = tTemp;
					}
				}
			}
		}
	}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}
/*=============================================================================================================
*TIAUTO_find_CAP_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "TI Change Rev (CAP Form)" user query.
================================================================================================================*/
extern int TIAUTO_find_CAP_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0; 	
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;	
	int	z										= 0;
	int	i										= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;

	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Revision[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_RAD[1024]								= {'\0'};
	char tempkey_RBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_CustTrackingNum[1024]					= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_IsProdImpacted[1024]					= {'\0'};
	char tempkey_ImpAfter[1024]							= {'\0'};
	char tempkey_ImpBefore[1024]						= {'\0'};
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;
	
	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name,"TI Change Rev (CAP Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				tc_strcpy(tempkey_Revision,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				tc_strcpy(tempkey_RAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				tc_strcpy(tempkey_RBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
			}    
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "Customer Tracking Number") == 0)
			{
				tc_strcpy(tempkey_CustTrackingNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Is Product Impacted?") == 0)
			{
				tc_strcpy(tempkey_IsProdImpacted,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Implementation After") == 0)
			{
				tc_strcpy(tempkey_ImpAfter,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Implementation Before") == 0)
			{
				tc_strcpy(tempkey_ImpBefore,values[iArgIndex]);
			} 
		}
	}	
	//Check in CAP Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Revision ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_ChangeDesc ,"") != 0) ||
		 (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) || (strcmp (tempkey_ReqGroup ,"") != 0) ||
		 (strcmp (tempkey_CustTrackingNum ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) || (strcmp (tempkey_IsProdImpacted ,"") != 0) ||
		 (strcmp (tempkey_ImpAfter ,"") != 0) || (strcmp (tempkey_ImpBefore ,"") != 0))
	
	{
		iRetCode = find_CAP_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,
									tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,
									tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
									tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
									tempkey_ImpAfter,tempkey_ImpBefore,
									"cap",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;

		if ((strcmp (tempkey_ImpAfter ,"") == 0) && (strcmp (tempkey_ImpBefore ,"") == 0))
		{
			iRetCode = find_CAP_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,
									tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,
									tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
									tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
									tempkey_ImpAfter,tempkey_ImpBefore,
									"cap2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		}
		if ((strcmp (tempkey_ImpAfter ,"") == 0) && (strcmp (tempkey_ImpBefore ,"") == 0))
		{
			iRetCode = find_CAP_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,
									tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,
									tempkey_TIDiv,tempkey_ProductGroup,tempkey_AffPgms,tempkey_AffPlant,tempkey_ChangeDesc,tempkey_ChangeDriver,
									tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_CustTrackingNum,tempkey_SuppTrackingNum,tempkey_IsProdImpacted,
									tempkey_ImpAfter,tempkey_ImpBefore,
									"cap3",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		}
	}
	

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				iRetCode = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!iRetCode)
					iRetCode = ITEM_ask_id(tItem_1, acItem_1);
				if(!iRetCode)
				{
					iRetCode = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!iRetCode)
						iRetCode = ITEM_ask_id(tItem_2, acItem_2);
					if(!iRetCode)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							iRetCode = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!iRetCode)
								iRetCode = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!iRetCode)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}
/*=============================================================================================================
*TIAUTO_find_PMR_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the " TI Change (PMR Form)" user query.
================================================================================================================*/
extern int TIAUTO_find_PMR_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_BillCompType[1024]						= {'\0'};
	char tempkey_BillComp[1024]							= {'\0'};
	char tempkey_CustNameType[1024]						= {'\0'};
	char tempkey_CustName[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_LevelOfReq[1024]						= {'\0'};
	char tempkey_TypeOfChange[1024]						= {'\0'};
	char tempkey_PMRReason[1024]						= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_RFQIssuedAfter[1024]					= {'\0'};
	char tempkey_RFQIssuedBefore[1024]					= {'\0'};
	
	tag_t			tTemp							= NULLTAG;	
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name," TI Change (PMR Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company Type") == 0)
			{
				tc_strcpy(tempkey_BillCompType,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company") == 0)
			{
				tc_strcpy(tempkey_BillComp,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Name Type") == 0)
			{
				tc_strcpy(tempkey_CustNameType,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				tc_strcpy(tempkey_CustName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "Level Of Request") == 0)
			{
				tc_strcpy(tempkey_LevelOfReq,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Type Of Change") == 0)
			{
				tc_strcpy(tempkey_TypeOfChange,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "PMR Reason") == 0)
			{
				tc_strcpy(tempkey_PMRReason,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued After") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedAfter,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued Before") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedBefore,values[iArgIndex]);
			} 
		}
	}	
	//Check in PMR Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillComp ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_PMRReason ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) ||
		 (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0))
	
	{
		iRetCode = find_PMR_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_OwningUser,tempkey_OwningGroup,
									tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
									tempkey_AffPgms,tempkey_AffPlant,tempkey_BillCompType,tempkey_BillComp,tempkey_CustNameType,tempkey_CustName,
									tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_LevelOfReq,
									tempkey_TypeOfChange,tempkey_PMRReason,tempkey_SuppTrackingNum,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,
									"pmr",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || (strcmp (tempkey_CBD ,"") != 0) ||
		 (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillComp ,"") != 0) ||
		 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_PMRReason ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) )
	
	{

		//if ((strcmp (tempkey_RFQIssuedAfter ,"") == 0) && (strcmp (tempkey_RFQIssuedBefore ,"") == 0))
		//{
			iRetCode = find_PMR_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_OwningUser,tempkey_OwningGroup,
										tempkey_OwningSite,tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
										tempkey_AffPgms,tempkey_AffPlant,tempkey_BillCompType,tempkey_BillComp,tempkey_CustNameType,tempkey_CustName,
										tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_LevelOfReq,
										tempkey_TypeOfChange,tempkey_PMRReason,tempkey_SuppTrackingNum,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,
										"pmr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		//}
	}
	

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
	for(z=0;z<(indx-1);z++)
	{
		tTemp=NULL_TAG;
		for(i=(z+1);i<indx;i++)
		{
			iRetCode = ITEM_ask_id((*found)[z], acItem_1);
			if(!iRetCode)
			{
				iRetCode = ITEM_ask_id((*found)[i], acItem_2);
				if(!iRetCode)
				{
					if(tc_strcmp(acItem_1,acItem_2)>0)
					{
						tTemp=(*found)[z];
						(*found)[z] = (*found)[i];
						(*found)[i] = tTemp;
					}
				}
			}
		}
	}
	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}
/*=============================================================================================================
*TIAUTO_find_PMR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return int				
* Description:
*			Implements the the logic for the "TI Change Rev (PMR Form)" user query.
================================================================================================================*/
extern int TIAUTO_find_PMR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Revision[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_RAD[1024]								= {'\0'};
	char tempkey_RBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_LastModUser[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_TIDiv[1024]							= {'\0'};
	char tempkey_ProductGroup[1024]						= {'\0'};
	char tempkey_AffPgms[1024]							= {'\0'};
	char tempkey_AffPlant[1024]							= {'\0'};
	char tempkey_BillCompType[1024]						= {'\0'};
	char tempkey_BillComp[1024]							= {'\0'};
	char tempkey_CustNameType[1024]						= {'\0'};
	char tempkey_CustName[1024]							= {'\0'};
	char tempkey_ChangeDesc[1024]						= {'\0'};
	char tempkey_ChangeDriver[1024]						= {'\0'};
	char tempkey_TargetReleaseStatus[1024]				= {'\0'};
	char tempkey_ReqGroup[1024]							= {'\0'};
	char tempkey_LevelOfReq[1024]						= {'\0'};
	char tempkey_TypeOfChange[1024]						= {'\0'};
	char tempkey_PMRReason[1024]						= {'\0'};
	char tempkey_SuppTrackingNum[1024]					= {'\0'};
	char tempkey_RFQIssuedAfter[1024]					= {'\0'};
	char tempkey_RFQIssuedBefore[1024]					= {'\0'};
	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name,"TI Change Rev (PMR Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				tc_strcpy(tempkey_Revision,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				tc_strcpy(tempkey_RAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				tc_strcpy(tempkey_RBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Last Modifying User") == 0)
			{
				tc_strcpy(tempkey_LastModUser,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "TI Division") == 0)
			{
				tc_strcpy(tempkey_TIDiv,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Product Group") == 0)
			{
				tc_strcpy(tempkey_ProductGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Affected Programs") == 0)
			{
				tc_strcpy(tempkey_AffPgms,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Affected Plant") == 0)
			{
				tc_strcpy(tempkey_AffPlant,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company Type") == 0)
			{
				tc_strcpy(tempkey_BillCompType,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Billable Company") == 0)
			{
				tc_strcpy(tempkey_BillComp,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Customer Name Type") == 0)
			{
				tc_strcpy(tempkey_CustNameType,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				tc_strcpy(tempkey_CustName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Change Description") == 0)
			{
				tc_strcpy(tempkey_ChangeDesc,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Change Driver") == 0)
			{
				tc_strcpy(tempkey_ChangeDriver,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Target Release Status") == 0)
			{
				tc_strcpy(tempkey_TargetReleaseStatus,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Requesting Group") == 0)
			{
				tc_strcpy(tempkey_ReqGroup,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "Level Of Request") == 0)
			{
				tc_strcpy(tempkey_LevelOfReq,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Type Of Change") == 0)
			{
				tc_strcpy(tempkey_TypeOfChange,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "PMR Reason") == 0)
			{
				tc_strcpy(tempkey_PMRReason,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "Supplier Tracking Number") == 0)
			{
				tc_strcpy(tempkey_SuppTrackingNum,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued After") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedAfter,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "RFQ Issued Before") == 0)
			{
				tc_strcpy(tempkey_RFQIssuedBefore,values[iArgIndex]);
			} 
		}
	}	
	//Check in PMR Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Revision ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillComp ,"") != 0) || (strcmp (tempkey_CustNameType ,"") != 0) || (strcmp (tempkey_CustName ,"") != 0) ||
		 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_PMRReason ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) ||
		 (strcmp (tempkey_RFQIssuedAfter ,"") != 0) || (strcmp (tempkey_RFQIssuedBefore ,"") != 0))
	
	{
		iRetCode = find_PMR_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
										tempkey_RAD,tempkey_RBD,tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,
										tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
										tempkey_AffPgms,tempkey_AffPlant,tempkey_BillCompType,tempkey_BillComp,tempkey_CustNameType,tempkey_CustName,
										tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_LevelOfReq,
										tempkey_TypeOfChange,tempkey_PMRReason,tempkey_SuppTrackingNum,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,
										"pmr",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}
	//Check in PMR2 Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Revision ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_LastModUser ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_TIDiv ,"") != 0) || (strcmp (tempkey_ProductGroup ,"") != 0) ||
		 (strcmp (tempkey_AffPgms ,"") != 0)  || (strcmp (tempkey_AffPlant ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0)  || 
		 (strcmp (tempkey_BillComp ,"") != 0) || 
		 (strcmp (tempkey_ChangeDesc ,"") != 0) || (strcmp (tempkey_ChangeDriver ,"") != 0) || (strcmp (tempkey_TargetReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_ReqGroup ,"") != 0) || (strcmp (tempkey_LevelOfReq ,"") != 0) || (strcmp (tempkey_TypeOfChange ,"") != 0) ||
		 (strcmp (tempkey_PMRReason ,"") != 0) || (strcmp (tempkey_SuppTrackingNum ,"") != 0) )
	{

		//if ((strcmp (tempkey_RFQIssuedAfter ,"") == 0) && (strcmp (tempkey_RFQIssuedBefore ,"") == 0))
		//{
			iRetCode = find_PMR_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,
											tempkey_RAD,tempkey_RBD,tempkey_OwningUser,tempkey_OwningGroup,tempkey_OwningSite,
											tempkey_LastModUser,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_TIDiv,tempkey_ProductGroup,
											tempkey_AffPgms,tempkey_AffPlant,tempkey_BillCompType,tempkey_BillComp,tempkey_CustNameType,tempkey_CustName,
											tempkey_ChangeDesc,tempkey_ChangeDriver,tempkey_TargetReleaseStatus,tempkey_ReqGroup,tempkey_LevelOfReq,
											tempkey_TypeOfChange,tempkey_PMRReason,tempkey_SuppTrackingNum,tempkey_RFQIssuedAfter,tempkey_RFQIssuedBefore,
											"pmr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

			for(j = 0; j < iNumInT8_AttrValueFound;j++)
			{
				tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
			}
			SAFE_MEM_free(tInT8_AttrValueFound);
			iNumInT8_AttrValueFound = 0;
		//}
	}
	

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				iRetCode = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!iRetCode)
					iRetCode = ITEM_ask_id(tItem_1, acItem_1);
				if(!iRetCode)
				{
					iRetCode = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!iRetCode)
						iRetCode = ITEM_ask_id(tItem_2, acItem_2);
					if(!iRetCode)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							iRetCode = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!iRetCode)
								iRetCode = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!iRetCode)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}

/*=============================================================================================================
*TIAUTO_find_OEM(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return 	 :	int				
* Description:	Implements the the logic for the " TI OEM Parts" user query.
================================================================================================================*/
extern int TIAUTO_find_OEM(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int 	iRetCode								= ITK_ok;
	int 	iArgIndex								= 0;
	int 	iSite									= 0;
	int 	iSiteID									= 0;
	tag_t	tSite									= NULLTAG;
	char	*pcLoggedInSiteName 					= NULL;
	char	*pcItemID								= NULL;
	char	*pcName									= NULL;
	char	*pcType									= NULL;
	char	*pcProgram								= NULL;
	char	*pcLaunchModelYear						= NULL;
	char	*pcReleasedByChange						= NULL;
	char	*pcCustomerName							= NULL;
	char	*pcCustomerReleaseNo					= NULL;
	char	*pcOwningUser							= NULL;
	char	*pcOwningGroup							= NULL;
	char	*pcOwningSite							= NULL;
	char	*pcLastModUser							= NULL;
	char	*pcCreatedAfter							= NULL;
	char	*pcCreatedBefore						= NULL;
	char	*pcModifiedAfter						= NULL;
	char	*pcModifiedBefore						= NULL;
	char	*pcReleasedAfter						= NULL;
	char	*pcReleasedBefore						= NULL;
	char	*pcReleaseStatus						= NULL;
	char	*pcCurrentTask							= NULL;

	//copying attribute values to variables
	if(tc_strcmp(name," TI OEM Part") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				pcItemID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				pcName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcName,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "OEM Type") == 0)
			{
				pcType = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcType,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Programs") == 0)
			{
				pcProgram = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcProgram,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Launch Model Year") == 0)
			{
				pcLaunchModelYear = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLaunchModelYear,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released By Change") == 0)
			{
				pcReleasedByChange = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedByChange,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				pcCustomerName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Release No") == 0)
			{
				pcCustomerReleaseNo = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerReleaseNo,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				pcOwningUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				pcOwningGroup = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningGroup,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				TIAUTO_ITKCALL(iRetCode,POM_site_id(&iSite));
				
				if(iRetCode == ITK_ok && iSite != 0)
				{
					TIAUTO_ITKCALL(iRetCode,SA_find_site_by_id(iSite,&tSite));
				}
				
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,SA_ask_site_info2(tSite,&pcLoggedInSiteName,&iSiteID));
				}

				if (tc_strcmp(pcLoggedInSiteName, values[iArgIndex]) == 0)
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(LOCAL) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,LOCAL);
				}
				
				else
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				pcLastModUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLastModUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				pcCreatedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedAfter,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				pcCreatedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedBefore,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				pcModifiedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				pcModifiedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				pcReleasedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				pcReleasedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				pcReleaseStatus = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleaseStatus,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				pcCurrentTask = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCurrentTask,values[iArgIndex]);
			}
		}
	}	

	//quering for oem
	if ( (pcItemID != NULL) ||  (pcName != NULL) ||  (pcType != NULL) || (pcProgram != NULL) ||  (pcLaunchModelYear != NULL) ||  
		 (pcReleasedByChange != NULL) || (pcCustomerName != NULL) ||  (pcCustomerReleaseNo != NULL) ||  (pcOwningUser != NULL) || 
		 (pcOwningGroup != NULL) ||  (pcOwningSite != NULL) ||  (pcLastModUser != NULL) || (pcCreatedAfter != NULL) ||  
		 (pcCreatedBefore != NULL) ||  (pcModifiedAfter != NULL) || (pcModifiedBefore != NULL) ||  (pcReleasedAfter != NULL) ||  
		 (pcReleasedBefore != NULL) || (pcReleaseStatus != NULL) ||  (pcCurrentTask!= NULL) )
	{
		TIAUTO_ITKCALL(iRetCode,find_OEM (pcItemID,pcName,pcType,pcProgram,pcLaunchModelYear,pcReleasedByChange,
										  pcCustomerName,pcCustomerReleaseNo,pcOwningUser,pcOwningGroup,pcOwningSite,pcLastModUser,
										  pcCreatedAfter,pcCreatedBefore,pcModifiedAfter,pcModifiedBefore,pcReleasedAfter,pcReleasedBefore,
										  pcReleaseStatus,pcCurrentTask,num_found,found));
	}
		
	//to free the memory
	SAFE_MEM_free(pcLoggedInSiteName);
	SAFE_MEM_free(pcItemID);
	SAFE_MEM_free(pcName);
	SAFE_MEM_free(pcType);
	SAFE_MEM_free(pcProgram);
	SAFE_MEM_free(pcLaunchModelYear);
	SAFE_MEM_free(pcReleasedByChange);
	SAFE_MEM_free(pcCustomerName);
	SAFE_MEM_free(pcCustomerReleaseNo);
	SAFE_MEM_free(pcOwningUser);
	SAFE_MEM_free(pcOwningGroup);	
	SAFE_MEM_free(pcOwningSite);
	SAFE_MEM_free(pcLastModUser);
	SAFE_MEM_free(pcCreatedAfter);
	SAFE_MEM_free(pcCreatedBefore);
	SAFE_MEM_free(pcModifiedAfter);	
	SAFE_MEM_free(pcModifiedBefore);
	SAFE_MEM_free(pcReleasedAfter);
	SAFE_MEM_free(pcReleasedBefore);
	SAFE_MEM_free(pcReleaseStatus);
	SAFE_MEM_free(pcCurrentTask);
	
	return iRetCode;
}


/*=============================================================================================================
*TIAUTO_find_OEM_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return 		int				
* Description:	Implements the the logic for the "TI OEM Parts" user query.
================================================================================================================*/
extern int TIAUTO_find_OEM_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{	
	int 	iRetCode								= ITK_ok;
	int 	iArgIndex								= 0;
	int 	iSite									= 0;
	int 	iSiteID									= 0;
	tag_t	tSite									= NULLTAG;
	char	*pcLoggedInSiteName 					= NULL;
	char	*pcItemID								= NULL;
	char	*pcRevID								= NULL;
	char	*pcName									= NULL;
	char	*pcType									= NULL;
	char	*pcProgram								= NULL;
	char	*pcLaunchModelYear						= NULL;
	char	*pcReleasedByChange						= NULL;
	char	*pcCustomerName							= NULL;
	char	*pcCustomerReleaseNo					= NULL;
	char	*pcOwningUser							= NULL;
	char	*pcOwningGroup							= NULL;
	char	*pcOwningSite							= NULL;
	char	*pcLastModUser							= NULL;
	char	*pcCreatedAfter							= NULL;
	char	*pcCreatedBefore						= NULL;
	char	*pcModifiedAfter						= NULL;
	char	*pcModifiedBefore						= NULL;
	char	*pcReleasedAfter						= NULL;
	char	*pcReleasedBefore						= NULL;
	char	*pcReleaseStatus						= NULL;
	char	*pcCurrentTask							= NULL;

	//copying attribute values to variables
	if(tc_strcmp(name,"TI OEM Part Rev") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				pcItemID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				pcRevID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcRevID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				pcName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcName,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "OEM Type") == 0)
			{
				pcType = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcType,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Programs") == 0)
			{
				pcProgram = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcProgram,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Launch Model Year") == 0)
			{
				pcLaunchModelYear = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLaunchModelYear,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released By Change") == 0)
			{
				pcReleasedByChange = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedByChange,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				pcCustomerName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Release No") == 0)
			{
				pcCustomerReleaseNo = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerReleaseNo,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				pcOwningUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				pcOwningGroup = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningGroup,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				TIAUTO_ITKCALL(iRetCode,POM_site_id(&iSite));
				
				if(iRetCode == ITK_ok && iSite != 0)
				{
					TIAUTO_ITKCALL(iRetCode,SA_find_site_by_id(iSite,&tSite));
				}
				
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,SA_ask_site_info2(tSite,&pcLoggedInSiteName,&iSiteID));
				}

				if (tc_strcmp(pcLoggedInSiteName, values[iArgIndex]) == 0)
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(LOCAL) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,LOCAL);
				}
				
				else
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				pcLastModUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLastModUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				pcCreatedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedAfter,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				pcCreatedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedBefore,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				pcModifiedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				pcModifiedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				pcReleasedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				pcReleasedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				pcReleaseStatus = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleaseStatus,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				pcCurrentTask = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCurrentTask,values[iArgIndex]);
			}
		}
	}	
	
	//quering for oem revision
	if ( (pcItemID != NULL) || (pcRevID != NULL) || (pcName != NULL) ||  (pcType != NULL) || (pcProgram != NULL) ||  (pcLaunchModelYear != NULL) ||  
		 (pcReleasedByChange != NULL) || (pcCustomerName != NULL) ||  (pcCustomerReleaseNo != NULL) ||  (pcOwningUser != NULL) || 
		 (pcOwningGroup != NULL) ||  (pcOwningSite != NULL) ||  (pcLastModUser != NULL) || (pcCreatedAfter != NULL) ||  
		 (pcCreatedBefore != NULL) ||  (pcModifiedAfter != NULL) || (pcModifiedBefore != NULL) ||  (pcReleasedAfter != NULL) ||  
		 (pcReleasedBefore != NULL) || (pcReleaseStatus != NULL) ||  (pcCurrentTask!= NULL) )
	{
		TIAUTO_ITKCALL(iRetCode,find_OEM_rev (pcItemID,pcRevID,pcName,pcType,pcProgram,pcLaunchModelYear,pcReleasedByChange,
											  pcCustomerName,pcCustomerReleaseNo,pcOwningUser,pcOwningGroup,pcOwningSite,pcLastModUser,
											  pcCreatedAfter,pcCreatedBefore,pcModifiedAfter,pcModifiedBefore,pcReleasedAfter,pcReleasedBefore,
											  pcReleaseStatus,pcCurrentTask,num_found,found));
	}
	
	//to free the memory
	SAFE_MEM_free(pcLoggedInSiteName);
	SAFE_MEM_free(pcItemID);
	SAFE_MEM_free(pcRevID);
	SAFE_MEM_free(pcName);
	SAFE_MEM_free(pcType);
	SAFE_MEM_free(pcProgram);
	SAFE_MEM_free(pcLaunchModelYear);
	SAFE_MEM_free(pcReleasedByChange);
	SAFE_MEM_free(pcCustomerName);
	SAFE_MEM_free(pcCustomerReleaseNo);
	SAFE_MEM_free(pcOwningUser);
	SAFE_MEM_free(pcOwningGroup);	
	SAFE_MEM_free(pcOwningSite);
	SAFE_MEM_free(pcLastModUser);
	SAFE_MEM_free(pcCreatedAfter);
	SAFE_MEM_free(pcCreatedBefore);
	SAFE_MEM_free(pcModifiedAfter);	
	SAFE_MEM_free(pcModifiedBefore);
	SAFE_MEM_free(pcReleasedAfter);
	SAFE_MEM_free(pcReleasedBefore);
	SAFE_MEM_free(pcReleaseStatus);
	SAFE_MEM_free(pcCurrentTask);
				
	return iRetCode;
}


/*=============================================================================================================
*TIAUTO_find_Doc(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return 		int				
* Description:	Implements the the logic for the " TI Document Items" user query.
================================================================================================================*/
extern int TIAUTO_find_Doc(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int 	iRetCode								= ITK_ok;
	int 	iArgIndex								= 0;
	int 	iSite									= 0;
	int 	iSiteID									= 0;
	tag_t	tSite									= NULLTAG;
	char	*pcLoggedInSiteName 					= NULL;
	char	*pcItemID								= NULL;
	char	*pcName									= NULL;
	char	*pcType									= NULL;
	char	*pcDescription							= NULL;
	char	*pcReleasedByChange						= NULL;
	char	*pcCustomerName							= NULL;
	char	*pcCustomerReleaseNo					= NULL;
	char	*pcOwningUser							= NULL;
	char	*pcOwningGroup							= NULL;
	char	*pcOwningSite							= NULL;
	char	*pcLastModUser							= NULL;
	char	*pcCreatedAfter							= NULL;
	char	*pcCreatedBefore						= NULL;
	char	*pcModifiedAfter						= NULL;
	char	*pcModifiedBefore						= NULL;
	char	*pcReleasedAfter						= NULL;
	char	*pcReleasedBefore						= NULL;
	char	*pcReleaseStatus						= NULL;
	char	*pcCurrentTask							= NULL;

	//copying attribute values to variables
	if(tc_strcmp(name," TI Document Items") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				pcItemID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				pcName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcName,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Document Type") == 0)
			{
				pcType = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcType,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Description") == 0)
			{
				pcDescription = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcDescription,values[iArgIndex]);
			}			
			if (tc_strcasecmp(names[iArgIndex], "Released By Change") == 0)
			{
				pcReleasedByChange = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedByChange,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				pcCustomerName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Release No") == 0)
			{
				pcCustomerReleaseNo = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerReleaseNo,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				pcOwningUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				pcOwningGroup = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningGroup,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				TIAUTO_ITKCALL(iRetCode,POM_site_id(&iSite));
				
				if(iRetCode == ITK_ok && iSite != 0)
				{
					TIAUTO_ITKCALL(iRetCode,SA_find_site_by_id(iSite,&tSite));
				}
				
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,SA_ask_site_info2(tSite,&pcLoggedInSiteName,&iSiteID));
				}

				if (tc_strcmp(pcLoggedInSiteName, values[iArgIndex]) == 0)
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(LOCAL) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,LOCAL);
				}
				
				else
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				pcLastModUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLastModUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				pcCreatedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedAfter,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				pcCreatedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedBefore,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				pcModifiedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				pcModifiedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				pcReleasedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				pcReleasedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				pcReleaseStatus = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleaseStatus,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				pcCurrentTask = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCurrentTask,values[iArgIndex]);
			}
		}
	}	

	//quering for document
	if ( (pcItemID != NULL) ||  (pcName != NULL) ||  (pcType != NULL) ||  (pcDescription != NULL) || (pcReleasedByChange != NULL) || 
		 (pcCustomerName != NULL) || (pcCustomerReleaseNo != NULL) ||  (pcOwningUser != NULL) || (pcOwningGroup != NULL) ||  
		 (pcOwningSite != NULL) || (pcLastModUser != NULL) || (pcCreatedAfter != NULL) ||  (pcCreatedBefore != NULL) ||  
		 (pcModifiedAfter != NULL) || (pcModifiedBefore != NULL) ||  (pcReleasedAfter != NULL) ||  (pcReleasedBefore != NULL) || 
		 (pcReleaseStatus != NULL) ||  (pcCurrentTask!= NULL) )
		 
	{
		TIAUTO_ITKCALL(iRetCode,find_Doc_Item (pcItemID,pcName,pcType,pcDescription,pcReleasedByChange,pcCustomerName,pcCustomerReleaseNo,
										  pcOwningUser,pcOwningGroup,pcOwningSite,pcLastModUser,pcCreatedAfter,pcCreatedBefore,
										  pcModifiedAfter,pcModifiedBefore,pcReleasedAfter,pcReleasedBefore,
										  pcReleaseStatus,pcCurrentTask,num_found,found));
	}
		
	//to free the memory
	SAFE_MEM_free(pcLoggedInSiteName);
	SAFE_MEM_free(pcItemID);
	SAFE_MEM_free(pcName);
	SAFE_MEM_free(pcType);
	SAFE_MEM_free(pcDescription);
	SAFE_MEM_free(pcReleasedByChange);
	SAFE_MEM_free(pcCustomerName);
	SAFE_MEM_free(pcCustomerReleaseNo);
	SAFE_MEM_free(pcOwningUser);
	SAFE_MEM_free(pcOwningGroup);	
	SAFE_MEM_free(pcOwningSite);
	SAFE_MEM_free(pcLastModUser);
	SAFE_MEM_free(pcCreatedAfter);
	SAFE_MEM_free(pcCreatedBefore);
	SAFE_MEM_free(pcModifiedAfter);	
	SAFE_MEM_free(pcModifiedBefore);
	SAFE_MEM_free(pcReleasedAfter);
	SAFE_MEM_free(pcReleasedBefore);
	SAFE_MEM_free(pcReleaseStatus);
	SAFE_MEM_free(pcCurrentTask);				
	return iRetCode;
}

/*=============================================================================================================
*TIAUTO_find_Doc_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
* return		int				
* Description:	Implements the the logic for the "TI Document Item Rev" user query.
================================================================================================================*/
extern int TIAUTO_find_Doc_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int 	iRetCode								= ITK_ok;
	int 	iArgIndex								= 0;
	int 	iSite									= 0;
	int 	iSiteID									= 0;
	tag_t	tSite									= NULLTAG;
	char	*pcLoggedInSiteName 					= NULL;
	char	*pcItemID								= NULL;
	char	*pcRevID								= NULL;
	char	*pcName									= NULL;
	char	*pcType									= NULL;
	char	*pcDescription							= NULL;
	char	*pcReleasedByChange						= NULL;
	char	*pcCustomerName							= NULL;
	char	*pcCustomerReleaseNo					= NULL;
	char	*pcOwningUser							= NULL;
	char	*pcOwningGroup							= NULL;
	char	*pcOwningSite							= NULL;
	char	*pcLastModUser							= NULL;
	char	*pcCreatedAfter							= NULL;
	char	*pcCreatedBefore						= NULL;
	char	*pcModifiedAfter						= NULL;
	char	*pcModifiedBefore						= NULL;
	char	*pcReleasedAfter						= NULL;
	char	*pcReleasedBefore						= NULL;
	char	*pcReleaseStatus						= NULL;
	char	*pcCurrentTask							= NULL;
	
	//copying attribute values to variables
	if(tc_strcmp(name,"TI Document Item Rev") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				pcItemID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				pcRevID = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcRevID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				pcName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcName,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Document Type") == 0)
			{
				pcType = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcType,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Description") == 0)
			{
				pcDescription = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcDescription,values[iArgIndex]);
			}			
			if (tc_strcasecmp(names[iArgIndex], "Released By Change") == 0)
			{
				pcReleasedByChange = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedByChange,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Name") == 0)
			{
				pcCustomerName = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerName,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Customer Release No") == 0)
			{
				pcCustomerReleaseNo = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCustomerReleaseNo,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				pcOwningUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				pcOwningGroup = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcOwningGroup,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				TIAUTO_ITKCALL(iRetCode,POM_site_id(&iSite));
				
				if(iRetCode == ITK_ok && iSite != 0)
				{
					TIAUTO_ITKCALL(iRetCode,SA_find_site_by_id(iSite,&tSite));
				}
				
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
				{
					TIAUTO_ITKCALL(iRetCode,SA_ask_site_info2(tSite,&pcLoggedInSiteName,&iSiteID));
				}

				if (tc_strcmp(pcLoggedInSiteName, values[iArgIndex]) == 0)
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(LOCAL) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,LOCAL);
				}
				
				else
				{
					pcOwningSite = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
					tc_strcpy(pcOwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "LastModifyingUser") == 0)
			{
				pcLastModUser = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcLastModUser,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				pcCreatedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedAfter,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				pcCreatedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCreatedBefore,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				pcModifiedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				pcModifiedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcModifiedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				pcReleasedAfter = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedAfter,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				pcReleasedBefore = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleasedBefore,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				pcReleaseStatus = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcReleaseStatus,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Current Task") == 0)
			{
				pcCurrentTask = (char *)MEM_alloc(((int)tc_strlen(values[iArgIndex]) + 1)* sizeof(char));
				tc_strcpy(pcCurrentTask,values[iArgIndex]);
			}
		}
	}	
	
	//quering for document revision
	if ( (pcItemID != NULL) || (pcRevID != NULL) || (pcName != NULL) ||  (pcType != NULL) ||  (pcDescription != NULL) || (pcReleasedByChange != NULL) || 
		 (pcCustomerName != NULL) || (pcCustomerReleaseNo != NULL) ||  (pcOwningUser != NULL) || (pcOwningGroup != NULL) ||  
		 (pcOwningSite != NULL) || (pcLastModUser != NULL) || (pcCreatedAfter != NULL) ||  (pcCreatedBefore != NULL) ||  
		 (pcModifiedAfter != NULL) || (pcModifiedBefore != NULL) ||  (pcReleasedAfter != NULL) ||  (pcReleasedBefore != NULL) || 
		 (pcReleaseStatus != NULL) ||  (pcCurrentTask!= NULL) )
		 
	{
		TIAUTO_ITKCALL(iRetCode,find_Doc_Item_rev (pcItemID,pcRevID,pcName,pcType,pcDescription,pcReleasedByChange,pcCustomerName,pcCustomerReleaseNo,
												   pcOwningUser,pcOwningGroup,pcOwningSite,pcLastModUser,pcCreatedAfter,pcCreatedBefore,
										           pcModifiedAfter,pcModifiedBefore,pcReleasedAfter,pcReleasedBefore,
										           pcReleaseStatus,pcCurrentTask,num_found,found));
	}
	
	//to free the memory
	SAFE_MEM_free(pcLoggedInSiteName);
	SAFE_MEM_free(pcItemID);
	SAFE_MEM_free(pcRevID);
	SAFE_MEM_free(pcName);
	SAFE_MEM_free(pcType);
	SAFE_MEM_free(pcDescription);
	SAFE_MEM_free(pcReleasedByChange);
	SAFE_MEM_free(pcCustomerName);
	SAFE_MEM_free(pcCustomerReleaseNo);
	SAFE_MEM_free(pcOwningUser);
	SAFE_MEM_free(pcOwningGroup);	
	SAFE_MEM_free(pcOwningSite);
	SAFE_MEM_free(pcLastModUser);
	SAFE_MEM_free(pcCreatedAfter);
	SAFE_MEM_free(pcCreatedBefore);
	SAFE_MEM_free(pcModifiedAfter);	
	SAFE_MEM_free(pcModifiedBefore);
	SAFE_MEM_free(pcReleasedAfter);
	SAFE_MEM_free(pcReleasedBefore);
	SAFE_MEM_free(pcReleaseStatus);
	SAFE_MEM_free(pcCurrentTask);	
	return iRetCode;
}

/*=============================================================================================================
*TIAUTO_Find_WorkspaceObject(const char *pcname, int inum_args, char **pcnames, char **pcvalues,
                                              int *inum_found, tag_t **tfound /*<OF num_found>
pcname- local query name(I)
inum_args- number of input arguments in query(I)
pcnames- query attribute names(I)
inum_found- number of output result to be returned to query(O)
ptfound - output result tags to be returned to query(O)

* return int				
* Description:
*			Implementation of logic for the "Find Objects Based On UIDs" user query.
================================================================================================================*/
extern int TIAUTO_Find_WorkspaceObject(const char *pcname, int inumargs, char **pcnames, char **pcvalues,
                                              int *inum_found, tag_t **ptfound /*<OF num_found>*/)
{
	int		iRetCode									= ITK_ok;
	int		indx										= 0;
	int		iArgIndex									= 0;		
	int		iNumAttrValueFound							= 0;	
	tag_t  *ptAttrValueFound							= NULL;	
	char	acTempKeyPuid[WSO_object_type_size_c+1]		= {'\0'};

	//Checking the query name
	if((tc_strcmp(pcname,TIAUTO_Find_Obj_BasedOn_UID) == 0 && iRetCode==ITK_ok))
	{		
		//checking for query attribute
		if ((tc_strcasecmp(pcnames[inumargs-1], TIAUTO_PUID) == 0)  && iRetCode==ITK_ok)
		{				
			char	*pcbuffer				= NULL;
			//splitting the input value with ,
			if ( pcvalues[inumargs-1] != NULL && iRetCode==ITK_ok)
			{
				pcbuffer = NULL;
				pcbuffer = tc_strtok( (pcvalues[inumargs-1] ), ",");
				while ( pcbuffer !=NULL && iRetCode==ITK_ok)
				{			
					tc_strcpy(acTempKeyPuid,pcbuffer);						
					if (strcmp (acTempKeyPuid ,"") != 0 && iRetCode==ITK_ok) 	
					{
						iRetCode = TIAUTO_Find_WorkspaceObjectQuery(acTempKeyPuid,&iNumAttrValueFound,&ptAttrValueFound);
						//total no. of out result count	
						if((iNumAttrValueFound) > 0 && iRetCode==ITK_ok)
						{	
							indx++;
							//Memory allocation
							if (*ptfound == NULL)
							{
								*ptfound = (tag_t *)MEM_alloc( (indx) * sizeof(tag_t) );									
							}
							else
							{
								*ptfound = (tag_t *)MEM_realloc ( *ptfound,(indx) * sizeof(tag_t));
									
							}
							//assigning pom query result to the found attribute
							(*ptfound)[indx-1] = ptAttrValueFound[iNumAttrValueFound-1];								
						}							
						SAFE_MEM_free(ptAttrValueFound);
						iNumAttrValueFound = 0;
						iRetCode=0;
					}						
					pcbuffer = tc_strtok( NULL , "," );						
				}
				*inum_found = indx;
			}				
			SAFE_MEM_free(pcbuffer);
		}
	}

	if ( iRetCode != ITK_ok )
	{	
		char	*pcErrMsg			= NULL;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	return iRetCode;
}
extern int TIAUTO_find_CCR_change_rev(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Revision[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_RAD[1024]								= {'\0'};
	char tempkey_RBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_PricingGuidance[1024]					= {'\0'};
	char tempkey_SplCustCommerReq[1024]					= {'\0'};
	char tempkey_LaborEcoYrmax[1024]					= {'\0'};
	char tempkey_LaborEcoYrmin[1024]					= {'\0'};
	char tempkey_Packaging[1024]						= {'\0'};
	char tempkey_TypeofQuote[1024]                      = {'\0'};
    char tempkey_BillCompType[1024]						= {'\0'};
	char tempkey_BillComp[1024]							= {'\0'};
    char tempkey_CustName[1024]							= {'\0'};
	char tempkey_CustAuthorNum[1024]                    = {'\0'};
	char tempkey_CustContName[1024]						= {'\0'}; 
	char tempkey_CustContEmail[1024]					= {'\0'}; 
	char tempkey_CustPhone[1024]					    = {'\0'}; 
	char tempkey_EstNum[1024]							= {'\0'}; 
	char tempkey_VarEstNum[1024]						= {'\0'}; 							
	char tempkey_CostofChangeCur[1024]					= {'\0'}; 
	char tempkey_ToolCostmax[1024]					    = {'\0'}; 
	char tempkey_ToolCostmin[1024]					    = {'\0'}; 
	char tempkey_CustPaidToolmax[1024]			        = {'\0'}; 
	char tempkey_CustPaidToolmin[1024]			        = {'\0'}; 
	char tempkey_PurExWorkCostmax[1024]				    = {'\0'};
	char tempkey_PurExWorkCostmin[1024]				    = {'\0'}; 
	char tempkey_PurDelDutyPaidCostmax[1024]		    = {'\0'}; 
	char tempkey_PurDelDutyPaidCostmin[1024]		    = {'\0'}; 
	char tempkey_LogisCostmax[1024]				        = {'\0'}; 
	char tempkey_LogisCostmin[1024]				        = {'\0'}; 
	char tempkey_MfgLaborCostmax[1024]			        = {'\0'}; 
	char tempkey_MfgLaborCostmin[1024]			        = {'\0'}; 
	char tempkey_MatCostmax[1024]					    = {'\0'}; 
	char tempkey_MatCostmin[1024]					    = {'\0'}; 
	char tempkey_MfgVarCostmax[1024]			        = {'\0'};
	char tempkey_MfgVarCostmin[1024]			        = {'\0'};
	char tempkey_MfgScrapPermax[1024]		            = {'\0'}; 
	char tempkey_MfgScrapPermin[1024]		            = {'\0'};
	char tempkey_TotalVarCostmax[1024]			        = {'\0'}; 
	char tempkey_TotalVarCostmin[1024]			        = {'\0'};
	char tempkey_MfgSellingTransPricemax[1024]		    = {'\0'};
	char tempkey_MfgSellingTransPricemin[1024]		    = {'\0'}; 
	char tempkey_TIMarkupUnitCurrmax[1024]			    = {'\0'}; 
	char tempkey_TIMarkupUnitCurrmin[1024]			    = {'\0'}; 
	char tempkey_ScreeningReq[1024]				        = {'\0'}; 
	char tempkey_CustAppReq[1024]			            = {'\0'}; 
	char tempkey_CustAppType[1024]				        = {'\0'}; 
	char tempkey_RFQIssuemax[1024]						= {'\0'}; 
	char tempkey_RFQIssuemin[1024]                      = {'\0'}; 
	char tempkey_RFQCustDuemax[1024]					= {'\0'}; 
	char tempkey_RFQCustDuemin[1024]					= {'\0'}; 
	char tempkey_ProtoDuemax[1024]						= {'\0'}; 
	char tempkey_ProtoDuemin[1024]						= {'\0'}; 
	char tempkey_ProtoQltSignmax[1024]				    = {'\0'}; 
	char tempkey_ProtoQltSignmin[1024]				    = {'\0'}; 
	char tempkey_DesignValDuemax[1024]					= {'\0'}; 
	char tempkey_DesignValDuemin[1024]					= {'\0'}; 
	char tempkey_PPAPReq[1024]						    = {'\0'}; 
	char tempkey_TarPPAPLevel[1024]					    = {'\0'}; 
	char tempkey_CritPathItem[1024]						= {'\0'}; 
	char tempkey_CriPathItemPPAPmax[1024]				= {'\0'}; 
	char tempkey_CriPathItemPPAPmin[1024]				= {'\0'}; 
	char tempkey_PPAPBuildEvemax[1024]					= {'\0'}; 
	char tempkey_PPAPBuildEvemin[1024]					= {'\0'};
	char tempkey_ProValSignmax[1024]					= {'\0'}; 
	char tempkey_ProValSignmin[1024]					= {'\0'}; 
	char tempkey_RunRateSignmax[1024]					= {'\0'}; 
	char tempkey_RunRateSignmin[1024]					= {'\0'}; 
	char tempkey_PPAPSignmax[1024]						= {'\0'}; 
	char tempkey_PPAPSignmin[1024]						= {'\0'}; 
	char tempkey_ProSignmax[1024]						= {'\0'}; 
	char tempkey_ProSignmin[1024]						= {'\0'}; 
	char tempkey_ProdMatReqmax[1024]				    = {'\0'}; 
	char tempkey_ProdMatReqmin[1024]				    = {'\0'}; 
	char tempkey_StartProdmax[1024]						= {'\0'}; 
	char tempkey_StartProdmin[1024]						= {'\0'}; 
	char tempkey_EndProdmax[1024]						= {'\0'}; 
	char tempkey_EndProdmin[1024]                       = {'\0'}; 

	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name,"TI Change Rev (CCR Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				tc_strcpy(tempkey_Revision,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				tc_strcpy(tempkey_RAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				tc_strcpy(tempkey_RBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			}   
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "CurrentTask") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "PricingGuidance") == 0)
			{
				tc_strcpy(tempkey_PricingGuidance,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "SpecialCustomerCommercialRequirements") == 0)
			{
				tc_strcpy(tempkey_SplCustCommerReq ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "LaborEconomicYearmax") == 0)
			{
				tc_strcpy(tempkey_LaborEcoYrmax,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "LaborEconomicYearmin") == 0)
			{
				tc_strcpy(tempkey_LaborEcoYrmin,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Packaging") == 0)
			{
				tc_strcpy(tempkey_Packaging,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "TypeofQuote") == 0)
			{
				tc_strcpy(tempkey_TypeofQuote,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "BillableCompanyType") == 0)
			{
				tc_strcpy(tempkey_BillCompType ,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "BillableCompany") == 0)
			{
				tc_strcpy(tempkey_BillComp,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CustomerAuthorizationNumber") == 0)
			{
				tc_strcpy(tempkey_CustAuthorNum ,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "CustomerContactName") == 0)
			{
				tc_strcpy(tempkey_CustContName ,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CustomerContactEmail") == 0)
			{
				tc_strcpy(tempkey_CustContEmail ,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CustomerContactPhone") == 0)
			{
				tc_strcpy(tempkey_CustPhone ,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "EstimateNumber") == 0)
			{
				tc_strcpy(tempkey_EstNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "VarianceEstimateNumber") == 0)
			{
				tc_strcpy(tempkey_VarEstNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCurrency") == 0)
			{
				tc_strcpy(tempkey_CostofChangeCur,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeToolingCostmax") == 0)
			{
				tc_strcpy(tempkey_ToolCostmax,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeToolingCostmin") == 0)
			{
				tc_strcpy(tempkey_ToolCostmin,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCustomerPaidTooling(CurrencyUnits)max ") == 0)
			{
				tc_strcpy(tempkey_CustPaidToolmax ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCustomerPaidTooling(CurrencyUnits)min") == 0)
			{
				tc_strcpy(tempkey_CustPaidToolmin ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsExWorksCostmax") == 0)
			{
				tc_strcpy(tempkey_PurExWorkCostmax ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsExWorksCostmin") == 0)
			{
				tc_strcpy(tempkey_PurExWorkCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsDeliveredDutyPaidCostmax") == 0)
			{
				tc_strcpy(tempkey_PurDelDutyPaidCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsDeliveredDutyPaidCostmin") == 0)
			{
				tc_strcpy(tempkey_PurDelDutyPaidCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeLogisticsCostmax") == 0)
			{
				tc_strcpy(tempkey_LogisCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeLogisticsCostmin") == 0)
			{
				tc_strcpy(tempkey_LogisCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsLaborCostmax") == 0)
			{
				tc_strcpy(tempkey_MfgLaborCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsLaborCostmin") == 0)
			{
				tc_strcpy(tempkey_MfgLaborCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeMaterialsCostmax") == 0)
			{
				tc_strcpy(tempkey_MatCostmax  ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeMaterialsCostmax") == 0)
			{
				tc_strcpy(tempkey_MatCostmax  ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsVariable Overhead Cost max") == 0)
			{
				tc_strcpy(tempkey_MfgVarCostmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsVariableOverheadCostmin") == 0)
			{
				tc_strcpy(tempkey_MfgVarCostmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsScrapPercentagemax") == 0)
			{
				tc_strcpy(tempkey_MfgScrapPermax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsScrapPercentagemin") == 0)
			{
				tc_strcpy(tempkey_MfgScrapPermin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTotalVariableCostmax") == 0)
			{
				tc_strcpy(tempkey_TotalVarCostmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTotalVariableCostmin") == 0)
			{
				tc_strcpy(tempkey_TotalVarCostmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsSelling/TransferPricemax") == 0)
			{
				tc_strcpy(tempkey_MfgSellingTransPricemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsSelling/TransferPricemin") == 0)
			{
				tc_strcpy(tempkey_MfgSellingTransPricemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTIMarkup(UnitsofCurrency)max") == 0)
			{
				tc_strcpy(tempkey_TIMarkupUnitCurrmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTIMarkup(UnitsofCurrency)min") == 0)
			{
				tc_strcpy(tempkey_TIMarkupUnitCurrmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ScreeningRequired") == 0)
			{
				tc_strcpy(tempkey_ScreeningReq ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CustomerApprovalRequired") == 0)
			{
				tc_strcpy(tempkey_CustAppReq,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CustomerApprovalType") == 0)
			{
				tc_strcpy(tempkey_CustAppType,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQIssuedmax") == 0)
			{
				tc_strcpy(tempkey_RFQIssuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQIssuedmin") == 0)
			{
				tc_strcpy(tempkey_RFQIssuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQCustomerDuemax") == 0)
			{
				tc_strcpy(tempkey_RFQCustDuemax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQCustomerDuemin") == 0)
			{
				tc_strcpy(tempkey_RFQCustDuemin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeDuemax") == 0)
			{
				tc_strcpy(tempkey_ProtoDuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeDuemin") == 0)
			{
				tc_strcpy(tempkey_ProtoDuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeQualitySignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProtoQltSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeQualitySignoffmin") == 0)
			{
				tc_strcpy(tempkey_ProtoQltSignmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Design Validation Due max") == 0)
			{
				tc_strcpy(tempkey_DesignValDuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "DesignValidationDuemin") == 0)
			{
				tc_strcpy(tempkey_DesignValDuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPRequired") == 0)
			{
				tc_strcpy(tempkey_PPAPReq,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "TargetPPAPLevel") == 0)
			{
				tc_strcpy(tempkey_TarPPAPLevel,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItem") == 0)
			{
				tc_strcpy(tempkey_CritPathItem,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItemPPAPSignoffmax") == 0)
			{
				tc_strcpy(tempkey_CriPathItemPPAPmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItemPPAPSignoffmin") == 0)
			{
				tc_strcpy(tempkey_CriPathItemPPAPmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPBuildEventmax") == 0)
			{
				tc_strcpy(tempkey_PPAPBuildEvemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPBuildEventmin") == 0)
			{
				tc_strcpy(tempkey_PPAPBuildEvemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessValidationSignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProValSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Process Validation Signoff min") == 0)
			{
				tc_strcpy(tempkey_ProValSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Run at Rate Signoff max") == 0)
			{
				tc_strcpy(tempkey_RunRateSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RunatRateSignoffmin") == 0)
			{
				tc_strcpy(tempkey_RunRateSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPSignoffmax") == 0)
			{
				tc_strcpy(tempkey_PPAPSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPSignoffmin") == 0)
			{
				tc_strcpy(tempkey_PPAPSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessSignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProSignmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessSignoffmin") == 0)
			{
				tc_strcpy(tempkey_ProSignmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProductionMaterialsRequiredmax") == 0)
			{
				tc_strcpy(tempkey_ProdMatReqmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProductionMaterialsRequiredmin") == 0)
			{
				tc_strcpy(tempkey_ProdMatReqmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "StartofProductionmax") == 0)
			{
				tc_strcpy(tempkey_StartProdmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "StartofProductionmin") == 0)
			{
				tc_strcpy(tempkey_StartProdmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "EndofProductionmax") == 0)
			{
				tc_strcpy(tempkey_EndProdmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "EndofProductionmin") == 0)
			{
				tc_strcpy(tempkey_EndProdmin,values[iArgIndex]);
			}
		}
	}	
	//Check in CAP Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Revision ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_PricingGuidance ,"") != 0) || (strcmp (tempkey_SplCustCommerReq,"") != 0) ||
		 (strcmp (tempkey_LaborEcoYrmax ,"") != 0)  || (strcmp (tempkey_LaborEcoYrmin ,"") != 0) || (strcmp (tempkey_Packaging ,"") != 0)  || 
		 (strcmp (tempkey_TypeofQuote ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0) || (strcmp (tempkey_BillComp ,"") != 0) ||
		 (strcmp (tempkey_CustAuthorNum ,"") != 0) || (strcmp (tempkey_CustContName ,"") != 0) || (strcmp (tempkey_CustContEmail ,"") != 0) ||
		 (strcmp (tempkey_CustPhone ,"") != 0) || (strcmp (tempkey_EstNum ,"") != 0) || (strcmp (tempkey_VarEstNum ,"") != 0) ||
		 (strcmp (tempkey_CostofChangeCur ,"") != 0) || (strcmp (tempkey_ToolCostmax ,"") != 0) || (strcmp (tempkey_ToolCostmin ,"") != 0) || 
		 (strcmp (tempkey_CustPaidToolmin ,"") != 0) || (strcmp (tempkey_PurExWorkCostmax ,"") != 0) || 
		 (strcmp (tempkey_PurExWorkCostmin ,"") != 0) || (strcmp (tempkey_PurDelDutyPaidCostmax ,"") != 0) || 
		 (strcmp (tempkey_PurDelDutyPaidCostmin ,"") != 0) || (strcmp (tempkey_LogisCostmax ,"") != 0) || 
		 (strcmp (tempkey_LogisCostmin ,"") != 0) || (strcmp (tempkey_MfgLaborCostmax ,"") != 0) ||  (strcmp (tempkey_MfgLaborCostmin ,"") != 0) ||
		 (strcmp (tempkey_MatCostmax,"") != 0) ||(strcmp (tempkey_MatCostmin,"") != 0) ||(strcmp (tempkey_MfgVarCostmax,"") != 0) ||(strcmp (tempkey_MfgVarCostmin,"") != 0) ||
		 (strcmp (tempkey_MfgScrapPermax,"") != 0) ||(strcmp (tempkey_MfgScrapPermin,"") != 0) || (strcmp (tempkey_TotalVarCostmax,"") != 0) ||(strcmp (tempkey_TotalVarCostmin,"") != 0) ||
		 (strcmp (tempkey_MfgSellingTransPricemax,"") != 0) ||(strcmp (tempkey_MfgSellingTransPricemin,"") != 0) ||(strcmp (tempkey_TIMarkupUnitCurrmax,"") != 0) ||
		 (strcmp (tempkey_TIMarkupUnitCurrmin,"") != 0) ||(strcmp (tempkey_ScreeningReq,"") != 0) ||(strcmp (tempkey_CustAppReq,"") != 0) ||(strcmp (tempkey_CustAppType,"") != 0) ||
		 (strcmp (tempkey_RFQIssuemax,"") != 0) || (strcmp (tempkey_RFQIssuemin,"") != 0) || (strcmp (tempkey_RFQCustDuemax,"") != 0) ||(strcmp (tempkey_RFQCustDuemin,"") != 0) ||
		 (strcmp (tempkey_ProtoDuemax,"") != 0) ||(strcmp (tempkey_ProtoDuemin,"") != 0) ||(strcmp (tempkey_ProtoQltSignmax,"") != 0) ||(strcmp  (tempkey_ProtoQltSignmin,"") != 0) ||
		 (strcmp (tempkey_DesignValDuemax,"") != 0) ||(strcmp (tempkey_DesignValDuemin,"") != 0) ||(strcmp (tempkey_PPAPReq,"") != 0) ||(strcmp (tempkey_TarPPAPLevel,"") != 0) || 
		 (strcmp (tempkey_CritPathItem,"") != 0) ||(strcmp (tempkey_CriPathItemPPAPmax,"") != 0) ||(strcmp (tempkey_CriPathItemPPAPmin,"") != 0) ||(strcmp (tempkey_PPAPBuildEvemax,"") != 0) ||
		 (strcmp (tempkey_PPAPBuildEvemin,"") != 0) ||(strcmp (tempkey_ProValSignmax,"") != 0) ||(strcmp (tempkey_ProValSignmin,"") != 0) ||(strcmp (tempkey_RunRateSignmax,"") != 0) || 
		 (strcmp (tempkey_RunRateSignmin,"") != 0) ||(strcmp ( tempkey_PPAPSignmax,"") != 0) || (strcmp (tempkey_PPAPSignmin,"") != 0) || (strcmp (tempkey_ProSignmax,"") != 0) || 
		 (strcmp (tempkey_ProSignmin,"") != 0) || (strcmp (tempkey_ProdMatReqmax,"") != 0) ||(strcmp (tempkey_ProdMatReqmin,"") != 0) ||(strcmp (tempkey_StartProdmax,"") != 0) ||
		 (strcmp (tempkey_StartProdmin,"") != 0) ||(strcmp (tempkey_EndProdmax,"") != 0) ||(strcmp (tempkey_EndProdmin,"") != 0)
		 ) 
	
	{
		iRetCode = find_CCR_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,tempkey_OwningUser,
			tempkey_OwningGroup, tempkey_OwningSite,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_PricingGuidance,tempkey_SplCustCommerReq,
			tempkey_LaborEcoYrmax,tempkey_LaborEcoYrmin,tempkey_Packaging,tempkey_TypeofQuote,tempkey_BillCompType,tempkey_BillComp,tempkey_CustAuthorNum,tempkey_CustContName,
			tempkey_CustContEmail,tempkey_CustPhone,tempkey_EstNum, tempkey_VarEstNum, tempkey_CostofChangeCur,tempkey_ToolCostmax,tempkey_ToolCostmin,tempkey_CustPaidToolmax,
			tempkey_CustPaidToolmin,tempkey_PurExWorkCostmax,tempkey_PurExWorkCostmin,tempkey_PurDelDutyPaidCostmax,tempkey_PurDelDutyPaidCostmin,tempkey_LogisCostmax, 
			tempkey_LogisCostmin,tempkey_MfgLaborCostmax,tempkey_MfgLaborCostmin,tempkey_MatCostmax,tempkey_MatCostmin,tempkey_MfgVarCostmax,tempkey_MfgVarCostmin,
			tempkey_MfgScrapPermax,tempkey_MfgScrapPermin,tempkey_TotalVarCostmax,tempkey_TotalVarCostmin,tempkey_MfgSellingTransPricemax,tempkey_MfgSellingTransPricemin,
			tempkey_TIMarkupUnitCurrmax,tempkey_TIMarkupUnitCurrmin,tempkey_ScreeningReq,tempkey_CustAppReq,tempkey_CustAppType,tempkey_RFQIssuemax, tempkey_RFQIssuemin, 
			tempkey_RFQCustDuemax,tempkey_RFQCustDuemin,tempkey_ProtoDuemax,tempkey_ProtoDuemin,tempkey_ProtoQltSignmax, tempkey_ProtoQltSignmin,tempkey_DesignValDuemax,
			tempkey_DesignValDuemin,tempkey_PPAPReq,tempkey_TarPPAPLevel, tempkey_CritPathItem,tempkey_CriPathItemPPAPmax,tempkey_CriPathItemPPAPmin,tempkey_PPAPBuildEvemax,
			tempkey_PPAPBuildEvemin,tempkey_ProValSignmax,tempkey_ProValSignmin,tempkey_RunRateSignmax, tempkey_RunRateSignmin, tempkey_PPAPSignmax, tempkey_PPAPSignmin, 
			tempkey_ProSignmax, tempkey_ProSignmin, tempkey_ProdMatReqmax,tempkey_ProdMatReqmin,tempkey_StartProdmax,tempkey_StartProdmin,tempkey_EndProdmax,tempkey_EndProdmin,
			"ccr",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);
		
		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

		//Check in CAP2 Workflow with CCR form attributes
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Revision ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_PricingGuidance ,"") != 0) || (strcmp (tempkey_SplCustCommerReq,"") != 0) ||
		 (strcmp (tempkey_LaborEcoYrmax ,"") != 0)  || (strcmp (tempkey_LaborEcoYrmin ,"") != 0) || (strcmp (tempkey_Packaging ,"") != 0)  || 
		 (strcmp (tempkey_TypeofQuote ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0) || (strcmp (tempkey_BillComp ,"") != 0)  ||
		 (strcmp (tempkey_CostofChangeCur ,"") != 0) ||(strcmp (tempkey_ScreeningReq,"") != 0) ||(strcmp (tempkey_CustAppReq,"") != 0) 
		 ) 
	{
			iRetCode = find_CCR_change_rev (tempkey_ItemID,tempkey_Revision,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,tempkey_OwningUser,
			tempkey_OwningGroup, tempkey_OwningSite,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_PricingGuidance,tempkey_SplCustCommerReq,
			tempkey_LaborEcoYrmax,tempkey_LaborEcoYrmin,tempkey_Packaging,tempkey_TypeofQuote,tempkey_BillCompType,tempkey_BillComp,tempkey_CustAuthorNum,tempkey_CustContName,
			tempkey_CustContEmail,tempkey_CustPhone,tempkey_EstNum, tempkey_VarEstNum, tempkey_CostofChangeCur,tempkey_ToolCostmax,tempkey_ToolCostmin,tempkey_CustPaidToolmax,
			tempkey_CustPaidToolmin,tempkey_PurExWorkCostmax,tempkey_PurExWorkCostmin,tempkey_PurDelDutyPaidCostmax,tempkey_PurDelDutyPaidCostmin,tempkey_LogisCostmax, 
			tempkey_LogisCostmin,tempkey_MfgLaborCostmax,tempkey_MfgLaborCostmin,tempkey_MatCostmax,tempkey_MatCostmin,tempkey_MfgVarCostmax,tempkey_MfgVarCostmin,
			tempkey_MfgScrapPermax,tempkey_MfgScrapPermin,tempkey_TotalVarCostmax,tempkey_TotalVarCostmin,tempkey_MfgSellingTransPricemax,tempkey_MfgSellingTransPricemin,
			tempkey_TIMarkupUnitCurrmax,tempkey_TIMarkupUnitCurrmin,tempkey_ScreeningReq,tempkey_CustAppReq,tempkey_CustAppType,tempkey_RFQIssuemax, tempkey_RFQIssuemin, 
			tempkey_RFQCustDuemax,tempkey_RFQCustDuemin,tempkey_ProtoDuemax,tempkey_ProtoDuemin,tempkey_ProtoQltSignmax, tempkey_ProtoQltSignmin,tempkey_DesignValDuemax,
			tempkey_DesignValDuemin,tempkey_PPAPReq,tempkey_TarPPAPLevel, tempkey_CritPathItem,tempkey_CriPathItemPPAPmax,tempkey_CriPathItemPPAPmin,tempkey_PPAPBuildEvemax,
			tempkey_PPAPBuildEvemin,tempkey_ProValSignmax,tempkey_ProValSignmin,tempkey_RunRateSignmax, tempkey_RunRateSignmin, tempkey_PPAPSignmax, tempkey_PPAPSignmin, 
			tempkey_ProSignmax, tempkey_ProSignmin, tempkey_ProdMatReqmax,tempkey_ProdMatReqmin,tempkey_StartProdmax,tempkey_StartProdmin,tempkey_EndProdmax,tempkey_EndProdmin,
			"ccr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
		for(z=0;z<(indx-1);z++)
		{
			tTemp=NULL_TAG;
			for(i=(z+1);i<indx;i++)
			{
				iRetCode = ITEM_ask_item_of_rev((*found)[z],&tItem_1);
				if(!iRetCode)
					iRetCode = ITEM_ask_id(tItem_1, acItem_1);
				if(!iRetCode)
				{
					iRetCode = ITEM_ask_item_of_rev((*found)[i],&tItem_2);
					if(!iRetCode)
						iRetCode = ITEM_ask_id(tItem_2, acItem_2);
					if(!iRetCode)
					{
						if(tc_strcmp(acItem_1,acItem_2)>0)
						{
							tTemp=(*found)[z];
							(*found)[z] = (*found)[i];
							(*found)[i] = tTemp;
						}
						else if(tc_strcmp(acItem_1,acItem_2)==0)
						{
							iRetCode = ITEM_ask_rev_id((*found)[z],acRev_id_1);
							if(!iRetCode)
								iRetCode = ITEM_ask_rev_id((*found)[i],acRev_id_2);
							if(!iRetCode)
							{
								if(tc_strcmp(acRev_id_1,acRev_id_2)>0)
								{
									tTemp=(*found)[z];
									(*found)[z] = (*found)[i];
									(*found)[i] = tTemp;
								}
							}
						}
					}
				}
			}
		}

	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}
extern int TIAUTO_find_CCR_change(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>*/)
{
	int iRetCode								= ITK_ok;
	int	indx									= 0;
	int iArgIndex								= 0;
	int j										= 0;
	int iNumInT8_AttrValueFound                 = 0;
	int iNumTotalTags							= 0;
	int iSite									= 0;
	int iSiteID									= 0;
		
	tag_t *tInT8_AttrValueFound					= NULL;
	
	int				z								= 0;
	int				i								= 0;	
	char			acRev_id_1[ITEM_id_size_c + 1]	= ""; 
	char			acRev_id_2[ITEM_id_size_c + 1]	= ""; 
	char			acItem_1[ITEM_id_size_c + 1]	= "";
	char			acItem_2[ITEM_id_size_c + 1]	= "";
	char			acLoggedInSiteName[SA_site_size_c + 1]	= "";

	char tempkey_ItemID[1024]							= {'\0'};
	char tempkey_Revision[1024]							= {'\0'};
	char tempkey_Name[1024]								= {'\0'};
	char tempkey_CAD[1024]								= {'\0'};
	char tempkey_CBD[1024]								= {'\0'};
	char tempkey_MAD[1024]								= {'\0'};
	char tempkey_MBD[1024]								= {'\0'};
	char tempkey_RAD[1024]								= {'\0'};
	char tempkey_RBD[1024]								= {'\0'};
	char tempkey_OwningUser[1024]						= {'\0'};
	char tempkey_OwningGroup[1024]                      = {'\0'};
	char tempkey_OwningSite[1024]						= {'\0'};
	char tempkey_ReleaseStatus[1024]					= {'\0'};
	char tempkey_CurrentTask[1024]						= {'\0'};
	char tempkey_PricingGuidance[1024]					= {'\0'};
	char tempkey_SplCustCommerReq[1024]					= {'\0'};
	char tempkey_LaborEcoYrmax[1024]					= {'\0'};
	char tempkey_LaborEcoYrmin[1024]					= {'\0'};
	char tempkey_Packaging[1024]						= {'\0'};
	char tempkey_TypeofQuote[1024]                      = {'\0'};
    char tempkey_BillCompType[1024]						= {'\0'};
	char tempkey_BillComp[1024]							= {'\0'};
    char tempkey_CustName[1024]							= {'\0'};
	char tempkey_CustAuthorNum[1024]                    = {'\0'};
	char tempkey_CustContName[1024]						= {'\0'}; 
	char tempkey_CustContEmail[1024]					= {'\0'}; 
	char tempkey_CustPhone[1024]					    = {'\0'}; 
	char tempkey_EstNum[1024]							= {'\0'}; 
	char tempkey_VarEstNum[1024]						= {'\0'}; 							
	char tempkey_CostofChangeCur[1024]					= {'\0'}; 
	char tempkey_ToolCostmax[1024]					    = {'\0'}; 
	char tempkey_ToolCostmin[1024]					    = {'\0'}; 
	char tempkey_CustPaidToolmax[1024]			        = {'\0'}; 
	char tempkey_CustPaidToolmin[1024]			        = {'\0'}; 
	char tempkey_PurExWorkCostmax[1024]				    = {'\0'};
	char tempkey_PurExWorkCostmin[1024]				    = {'\0'}; 
	char tempkey_PurDelDutyPaidCostmax[1024]		    = {'\0'}; 
	char tempkey_PurDelDutyPaidCostmin[1024]		    = {'\0'}; 
	char tempkey_LogisCostmax[1024]				        = {'\0'}; 
	char tempkey_LogisCostmin[1024]				        = {'\0'}; 
	char tempkey_MfgLaborCostmax[1024]			        = {'\0'}; 
	char tempkey_MfgLaborCostmin[1024]			        = {'\0'}; 
	char tempkey_MatCostmax[1024]					    = {'\0'}; 
	char tempkey_MatCostmin[1024]					    = {'\0'}; 
	char tempkey_MfgVarCostmax[1024]			        = {'\0'};
	char tempkey_MfgVarCostmin[1024]			        = {'\0'};
	char tempkey_MfgScrapPermax[1024]		            = {'\0'}; 
	char tempkey_MfgScrapPermin[1024]		            = {'\0'};
	char tempkey_TotalVarCostmax[1024]			        = {'\0'}; 
	char tempkey_TotalVarCostmin[1024]			        = {'\0'};
	char tempkey_MfgSellingTransPricemax[1024]		    = {'\0'};
	char tempkey_MfgSellingTransPricemin[1024]		    = {'\0'}; 
	char tempkey_TIMarkupUnitCurrmax[1024]			    = {'\0'}; 
	char tempkey_TIMarkupUnitCurrmin[1024]			    = {'\0'}; 
	char tempkey_ScreeningReq[1024]				        = {'\0'}; 
	char tempkey_CustAppReq[1024]			            = {'\0'}; 
	char tempkey_CustAppType[1024]				        = {'\0'}; 
	char tempkey_RFQIssuemax[1024]						= {'\0'}; 
	char tempkey_RFQIssuemin[1024]                      = {'\0'}; 
	char tempkey_RFQCustDuemax[1024]					= {'\0'}; 
	char tempkey_RFQCustDuemin[1024]					= {'\0'}; 
	char tempkey_ProtoDuemax[1024]						= {'\0'}; 
	char tempkey_ProtoDuemin[1024]						= {'\0'}; 
	char tempkey_ProtoQltSignmax[1024]				    = {'\0'}; 
	char tempkey_ProtoQltSignmin[1024]				    = {'\0'}; 
	char tempkey_DesignValDuemax[1024]					= {'\0'}; 
	char tempkey_DesignValDuemin[1024]					= {'\0'}; 
	char tempkey_PPAPReq[1024]						    = {'\0'}; 
	char tempkey_TarPPAPLevel[1024]					    = {'\0'}; 
	char tempkey_CritPathItem[1024]						= {'\0'}; 
	char tempkey_CriPathItemPPAPmax[1024]				= {'\0'}; 
	char tempkey_CriPathItemPPAPmin[1024]				= {'\0'}; 
	char tempkey_PPAPBuildEvemax[1024]					= {'\0'}; 
	char tempkey_PPAPBuildEvemin[1024]					= {'\0'};
	char tempkey_ProValSignmax[1024]					= {'\0'}; 
	char tempkey_ProValSignmin[1024]					= {'\0'}; 
	char tempkey_RunRateSignmax[1024]					= {'\0'}; 
	char tempkey_RunRateSignmin[1024]					= {'\0'}; 
	char tempkey_PPAPSignmax[1024]						= {'\0'}; 
	char tempkey_PPAPSignmin[1024]						= {'\0'}; 
	char tempkey_ProSignmax[1024]						= {'\0'}; 
	char tempkey_ProSignmin[1024]						= {'\0'}; 
	char tempkey_ProdMatReqmax[1024]				    = {'\0'}; 
	char tempkey_ProdMatReqmin[1024]				    = {'\0'}; 
	char tempkey_StartProdmax[1024]						= {'\0'}; 
	char tempkey_StartProdmin[1024]						= {'\0'}; 
	char tempkey_EndProdmax[1024]						= {'\0'}; 
	char tempkey_EndProdmin[1024]                       = {'\0'}; 

	
	tag_t			tTemp							= NULLTAG;
	tag_t			tItem_1							= NULLTAG;
	tag_t			tItem_2							= NULLTAG;
	tag_t			tSite							= NULLTAG;

	TIA_UniqueWSOMObjects *UniqueObjects			= NULL;
	TIA_UniqueWSOMObjects *tempObjects				= NULL;

	STATUS_Struct_t		sDelimitedKey;
	tiauto_initialize_status_progression_stuct(&sDelimitedKey);

	if(tc_strcmp(name," TI Change (CCR Form)") == 0)
	{
		for (iArgIndex =0; iArgIndex<num_args; iArgIndex++)
		{				
			if (tc_strcasecmp(names[iArgIndex], "Item ID") == 0)
			{
				tc_strcpy(tempkey_ItemID,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Revision") == 0)
			{
				tc_strcpy(tempkey_Revision,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Name") == 0)
			{
				tc_strcpy(tempkey_Name,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created After") == 0)
			{
				tc_strcpy(tempkey_CAD,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "Created Before") == 0)
			{
				tc_strcpy(tempkey_CBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Modified After") == 0)
			{
				tc_strcpy(tempkey_MAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Modified Before") == 0)
			{
				tc_strcpy(tempkey_MBD,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Released After") == 0)
			{
				tc_strcpy(tempkey_RAD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Released Before") == 0)
			{
				tc_strcpy(tempkey_RBD,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning User") == 0)
			{
				tc_strcpy(tempkey_OwningUser,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Group") == 0)
			{
				tc_strcpy(tempkey_OwningGroup,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "Owning Site") == 0)
			{
				iRetCode = POM_site_id(&iSite);
				if(iSite != 0)
					iRetCode = SA_find_site_by_id(iSite,&tSite);
				if(iRetCode == ITK_ok && tSite!= NULLTAG)
					iRetCode = SA_ask_site_info(tSite,acLoggedInSiteName,&iSiteID);

				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) == 0)
				{
					tc_strcpy(tempkey_OwningSite,"Local");
				}
				if (tc_strcmp(acLoggedInSiteName, values[iArgIndex]) != 0)
				{
					tc_strcpy(tempkey_OwningSite,values[iArgIndex]);
				}
			} 
			if (tc_strcasecmp(names[iArgIndex], "Release Status") == 0)
			{
				tc_strcpy(tempkey_ReleaseStatus,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "CurrentTask") == 0)
			{
				tc_strcpy(tempkey_CurrentTask,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "PricingGuidance") == 0)
			{
				tc_strcpy(tempkey_PricingGuidance,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "SpecialCustomerCommercialRequirements") == 0)
			{
				tc_strcpy(tempkey_SplCustCommerReq ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "LaborEconomicYearmax") == 0)
			{
				tc_strcpy(tempkey_LaborEcoYrmax,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "LaborEconomicYearmin") == 0)
			{
				tc_strcpy(tempkey_LaborEcoYrmin,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "Packaging") == 0)
			{
				tc_strcpy(tempkey_Packaging,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "TypeofQuote") == 0)
			{
				tc_strcpy(tempkey_TypeofQuote,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "BillableCompanyType") == 0)
			{
				tc_strcpy(tempkey_BillCompType ,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "BillableCompany") == 0)
			{
				tc_strcpy(tempkey_BillComp,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CustomerAuthorizationNumber") == 0)
			{
				tc_strcpy(tempkey_CustAuthorNum ,values[iArgIndex]);
			}  
			if (tc_strcasecmp(names[iArgIndex], "Customer Contact Name") == 0)
			{
				tc_strcpy(tempkey_CustContName ,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CustomerContactEmail") == 0)
			{
				tc_strcpy(tempkey_CustContEmail ,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CustomerContactPhone") == 0)
			{
				tc_strcpy(tempkey_CustPhone ,values[iArgIndex]);
			}      
			if (tc_strcasecmp(names[iArgIndex], "EstimateNumber") == 0)
			{
				tc_strcpy(tempkey_EstNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "VarianceEstimateNumber") == 0)
			{
				tc_strcpy(tempkey_VarEstNum,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCurrency") == 0)
			{
				tc_strcpy(tempkey_CostofChangeCur,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeToolingCostmax") == 0)
			{
				tc_strcpy(tempkey_ToolCostmax,values[iArgIndex]);
			}     
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeToolingCostmin") == 0)
			{
				tc_strcpy(tempkey_ToolCostmin,values[iArgIndex]);
			}   
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCustomerPaidTooling(CurrencyUnits)max ") == 0)
			{
				tc_strcpy(tempkey_CustPaidToolmax ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeCustomerPaidTooling(CurrencyUnits)min") == 0)
			{
				tc_strcpy(tempkey_CustPaidToolmin ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsExWorksCostmax") == 0)
			{
				tc_strcpy(tempkey_PurExWorkCostmax ,values[iArgIndex]);
			} 
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsExWorksCostmin") == 0)
			{
				tc_strcpy(tempkey_PurExWorkCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsDeliveredDutyPaidCostmax") == 0)
			{
				tc_strcpy(tempkey_PurDelDutyPaidCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangePurchasedPartsDeliveredDutyPaidCostmin") == 0)
			{
				tc_strcpy(tempkey_PurDelDutyPaidCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeLogisticsCostmax") == 0)
			{
				tc_strcpy(tempkey_LogisCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeLogisticsCostmin") == 0)
			{
				tc_strcpy(tempkey_LogisCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsLaborCostmax") == 0)
			{
				tc_strcpy(tempkey_MfgLaborCostmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsLaborCostmin") == 0)
			{
				tc_strcpy(tempkey_MfgLaborCostmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeMaterialsCostmax") == 0)
			{
				tc_strcpy(tempkey_MatCostmax  ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeMaterialsCostmax") == 0)
			{
				tc_strcpy(tempkey_MatCostmax  ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsVariableOverheadCostmax") == 0)
			{
				tc_strcpy(tempkey_MfgVarCostmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsVariableOverheadCostmin") == 0)
			{
				tc_strcpy(tempkey_MfgVarCostmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsScrapPercentagemax") == 0)
			{
				tc_strcpy(tempkey_MfgScrapPermax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsScrapPercentagemin") == 0)
			{
				tc_strcpy(tempkey_MfgScrapPermin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTotalVariableCostmax") == 0)
			{
				tc_strcpy(tempkey_TotalVarCostmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTotalVariableCostmin") == 0)
			{
				tc_strcpy(tempkey_TotalVarCostmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsSelling/TransferPrice max") == 0)
			{
				tc_strcpy(tempkey_MfgSellingTransPricemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeManufacturedPartsSelling/TransferPricemin") == 0)
			{
				tc_strcpy(tempkey_MfgSellingTransPricemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTIMarkup(UnitsofCurrency)max") == 0)
			{
				tc_strcpy(tempkey_TIMarkupUnitCurrmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CostofChangeTIMarkup(UnitsofCurrency)min") == 0)
			{
				tc_strcpy(tempkey_TIMarkupUnitCurrmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ScreeningRequired") == 0)
			{
				tc_strcpy(tempkey_ScreeningReq ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CustomerApprovalRequired") == 0)
			{
				tc_strcpy(tempkey_CustAppReq,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CustomerApprovalType") == 0)
			{
				tc_strcpy(tempkey_CustAppType,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQIssuedmax") == 0)
			{
				tc_strcpy(tempkey_RFQIssuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQIssuedmin") == 0)
			{
				tc_strcpy(tempkey_RFQIssuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQCustomerDuemax") == 0)
			{
				tc_strcpy(tempkey_RFQCustDuemax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RFQCustomerDuemin") == 0)
			{
				tc_strcpy(tempkey_RFQCustDuemin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeDuemax") == 0)
			{
				tc_strcpy(tempkey_ProtoDuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeDuemin") == 0)
			{
				tc_strcpy(tempkey_ProtoDuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeQualitySignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProtoQltSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PrototypeQualitySignoffmin") == 0)
			{
				tc_strcpy(tempkey_ProtoQltSignmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "DesignValidationDuemax") == 0)
			{
				tc_strcpy(tempkey_DesignValDuemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "DesignValidationDuemin") == 0)
			{
				tc_strcpy(tempkey_DesignValDuemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPRequired") == 0)
			{
				tc_strcpy(tempkey_PPAPReq,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "TargetPPAPLevel") == 0)
			{
				tc_strcpy(tempkey_TarPPAPLevel,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItem") == 0)
			{
				tc_strcpy(tempkey_CritPathItem,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItemPPAPSignoffmax") == 0)
			{
				tc_strcpy(tempkey_CriPathItemPPAPmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "CriticalPathItemPPAPSignoffmin") == 0)
			{
				tc_strcpy(tempkey_CriPathItemPPAPmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPBuildEventmax") == 0)
			{
				tc_strcpy(tempkey_PPAPBuildEvemax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPBuildEventmin") == 0)
			{
				tc_strcpy(tempkey_PPAPBuildEvemin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessValidationSignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProValSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessValidationSignoffmin") == 0)
			{
				tc_strcpy(tempkey_ProValSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RunatRateSignoffmax") == 0)
			{
				tc_strcpy(tempkey_RunRateSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "RunatRateSignoffmin") == 0)
			{
				tc_strcpy(tempkey_RunRateSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPSignoffmax") == 0)
			{
				tc_strcpy(tempkey_PPAPSignmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "PPAPSignoffmin") == 0)
			{
				tc_strcpy(tempkey_PPAPSignmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessSignoffmax") == 0)
			{
				tc_strcpy(tempkey_ProSignmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProcessSignoffmin") == 0)
			{
				tc_strcpy(tempkey_ProSignmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProductionMaterialsRequiredmax") == 0)
			{
				tc_strcpy(tempkey_ProdMatReqmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "ProductionMaterialsRequiredmin") == 0)
			{
				tc_strcpy(tempkey_ProdMatReqmin,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "StartofProductionmax") == 0)
			{
				tc_strcpy(tempkey_StartProdmax ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "StartofProductionmin") == 0)
			{
				tc_strcpy(tempkey_StartProdmin ,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "EndofProductionmax") == 0)
			{
				tc_strcpy(tempkey_EndProdmax,values[iArgIndex]);
			}
			if (tc_strcasecmp(names[iArgIndex], "EndofProductionmin") == 0)
			{
				tc_strcpy(tempkey_EndProdmin,values[iArgIndex]);
			}
		}
	}	
	//Check in CAP Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_PricingGuidance ,"") != 0) || (strcmp (tempkey_SplCustCommerReq,"") != 0) ||
		 (strcmp (tempkey_LaborEcoYrmax ,"") != 0)  || (strcmp (tempkey_LaborEcoYrmin ,"") != 0) || (strcmp (tempkey_Packaging ,"") != 0)  || 
		 (strcmp (tempkey_TypeofQuote ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0) || (strcmp (tempkey_BillComp ,"") != 0) ||
		 (strcmp (tempkey_CustAuthorNum ,"") != 0) || (strcmp (tempkey_CustContName ,"") != 0) || (strcmp (tempkey_CustContEmail ,"") != 0) ||
		 (strcmp (tempkey_CustPhone ,"") != 0) || (strcmp (tempkey_EstNum ,"") != 0) || (strcmp (tempkey_VarEstNum ,"") != 0) ||
		 (strcmp (tempkey_CostofChangeCur ,"") != 0) || (strcmp (tempkey_ToolCostmax ,"") != 0) || (strcmp (tempkey_ToolCostmin ,"") != 0) || 
		 (strcmp (tempkey_CustPaidToolmin ,"") != 0) || (strcmp (tempkey_PurExWorkCostmax ,"") != 0) || 
		 (strcmp (tempkey_PurExWorkCostmin ,"") != 0) || (strcmp (tempkey_PurDelDutyPaidCostmax ,"") != 0) || 
		 (strcmp (tempkey_PurDelDutyPaidCostmin ,"") != 0) || (strcmp (tempkey_LogisCostmax ,"") != 0) || 
		 (strcmp (tempkey_LogisCostmin ,"") != 0) || (strcmp (tempkey_MfgLaborCostmax ,"") != 0) ||  (strcmp (tempkey_MfgLaborCostmin ,"") != 0) ||
		 (strcmp (tempkey_MatCostmax,"") != 0) ||(strcmp (tempkey_MatCostmin,"") != 0) ||(strcmp (tempkey_MfgVarCostmax,"") != 0) ||(strcmp (tempkey_MfgVarCostmin,"") != 0) ||
		 (strcmp (tempkey_MfgScrapPermax,"") != 0) ||(strcmp (tempkey_MfgScrapPermin,"") != 0) || (strcmp (tempkey_TotalVarCostmax,"") != 0) ||(strcmp (tempkey_TotalVarCostmin,"") != 0) ||
		 (strcmp (tempkey_MfgSellingTransPricemax,"") != 0) ||(strcmp (tempkey_MfgSellingTransPricemin,"") != 0) ||(strcmp (tempkey_TIMarkupUnitCurrmax,"") != 0) ||
		 (strcmp (tempkey_TIMarkupUnitCurrmin,"") != 0) ||(strcmp (tempkey_ScreeningReq,"") != 0) ||(strcmp (tempkey_CustAppReq,"") != 0) ||(strcmp (tempkey_CustAppType,"") != 0) ||
		 (strcmp (tempkey_RFQIssuemax,"") != 0) || (strcmp (tempkey_RFQIssuemin,"") != 0) || (strcmp (tempkey_RFQCustDuemax,"") != 0) ||(strcmp (tempkey_RFQCustDuemin,"") != 0) ||
		 (strcmp (tempkey_ProtoDuemax,"") != 0) ||(strcmp (tempkey_ProtoDuemin,"") != 0) ||(strcmp (tempkey_ProtoQltSignmax,"") != 0) ||(strcmp  (tempkey_ProtoQltSignmin,"") != 0) ||
		 (strcmp (tempkey_DesignValDuemax,"") != 0) ||(strcmp (tempkey_DesignValDuemin,"") != 0) ||(strcmp (tempkey_PPAPReq,"") != 0) ||(strcmp (tempkey_TarPPAPLevel,"") != 0) || 
		 (strcmp (tempkey_CritPathItem,"") != 0) ||(strcmp (tempkey_CriPathItemPPAPmax,"") != 0) ||(strcmp (tempkey_CriPathItemPPAPmin,"") != 0) ||(strcmp (tempkey_PPAPBuildEvemax,"") != 0) ||
		 (strcmp (tempkey_PPAPBuildEvemin,"") != 0) ||(strcmp (tempkey_ProValSignmax,"") != 0) ||(strcmp (tempkey_ProValSignmin,"") != 0) ||(strcmp (tempkey_RunRateSignmax,"") != 0) || 
		 (strcmp (tempkey_RunRateSignmin,"") != 0) ||(strcmp ( tempkey_PPAPSignmax,"") != 0) || (strcmp (tempkey_PPAPSignmin,"") != 0) || (strcmp (tempkey_ProSignmax,"") != 0) || 
		 (strcmp (tempkey_ProSignmin,"") != 0) || (strcmp (tempkey_ProdMatReqmax,"") != 0) ||(strcmp (tempkey_ProdMatReqmin,"") != 0) ||(strcmp (tempkey_StartProdmax,"") != 0) ||
		 (strcmp (tempkey_StartProdmin,"") != 0) ||(strcmp (tempkey_EndProdmax,"") != 0) ||(strcmp (tempkey_EndProdmin,"") != 0)
		 ) 
	
	{
		iRetCode = find_CCR_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,tempkey_OwningUser,
			tempkey_OwningGroup, tempkey_OwningSite,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_PricingGuidance,tempkey_SplCustCommerReq,
			tempkey_LaborEcoYrmax,tempkey_LaborEcoYrmin,tempkey_Packaging,tempkey_TypeofQuote,tempkey_BillCompType,tempkey_BillComp,tempkey_CustAuthorNum,tempkey_CustContName,
			tempkey_CustContEmail,tempkey_CustPhone,tempkey_EstNum, tempkey_VarEstNum, tempkey_CostofChangeCur,tempkey_ToolCostmax,tempkey_ToolCostmin,tempkey_CustPaidToolmax,
			tempkey_CustPaidToolmin,tempkey_PurExWorkCostmax,tempkey_PurExWorkCostmin,tempkey_PurDelDutyPaidCostmax,tempkey_PurDelDutyPaidCostmin,tempkey_LogisCostmax, 
			tempkey_LogisCostmin,tempkey_MfgLaborCostmax,tempkey_MfgLaborCostmin,tempkey_MatCostmax,tempkey_MatCostmin,tempkey_MfgVarCostmax,tempkey_MfgVarCostmin,
			tempkey_MfgScrapPermax,tempkey_MfgScrapPermin,tempkey_TotalVarCostmax,tempkey_TotalVarCostmin,tempkey_MfgSellingTransPricemax,tempkey_MfgSellingTransPricemin,
			tempkey_TIMarkupUnitCurrmax,tempkey_TIMarkupUnitCurrmin,tempkey_ScreeningReq,tempkey_CustAppReq,tempkey_CustAppType,tempkey_RFQIssuemax, tempkey_RFQIssuemin, 
			tempkey_RFQCustDuemax,tempkey_RFQCustDuemin,tempkey_ProtoDuemax,tempkey_ProtoDuemin,tempkey_ProtoQltSignmax, tempkey_ProtoQltSignmin,tempkey_DesignValDuemax,
			tempkey_DesignValDuemin,tempkey_PPAPReq,tempkey_TarPPAPLevel, tempkey_CritPathItem,tempkey_CriPathItemPPAPmax,tempkey_CriPathItemPPAPmin,tempkey_PPAPBuildEvemax,
			tempkey_PPAPBuildEvemin,tempkey_ProValSignmax,tempkey_ProValSignmin,tempkey_RunRateSignmax, tempkey_RunRateSignmin, tempkey_PPAPSignmax, tempkey_PPAPSignmin, 
			tempkey_ProSignmax, tempkey_ProSignmin, tempkey_ProdMatReqmax,tempkey_ProdMatReqmin,tempkey_StartProdmax,tempkey_StartProdmin,tempkey_EndProdmax,tempkey_EndProdmin,
			"ccr",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);
		
		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

		//Check in CAP2 Workflow
	if ( (strcmp (tempkey_ItemID ,"") != 0) || (strcmp (tempkey_Name ,"") != 0) || (strcmp (tempkey_CAD ,"") != 0)  || 
		 (strcmp (tempkey_CBD ,"") != 0) || (strcmp (tempkey_MAD ,"") != 0) || (strcmp (tempkey_MBD ,"") != 0) || (strcmp (tempkey_RAD ,"") != 0) || 
		 (strcmp (tempkey_RBD ,"") != 0) || (strcmp (tempkey_OwningUser ,"") != 0) || (strcmp (tempkey_OwningGroup ,"") != 0)  ||
		 (strcmp (tempkey_OwningSite ,"") != 0) || (strcmp (tempkey_ReleaseStatus ,"") != 0) ||
		 (strcmp (tempkey_CurrentTask ,"") != 0) || (strcmp (tempkey_PricingGuidance ,"") != 0) || (strcmp (tempkey_SplCustCommerReq,"") != 0) ||
		 (strcmp (tempkey_LaborEcoYrmax ,"") != 0)  || (strcmp (tempkey_LaborEcoYrmin ,"") != 0) || (strcmp (tempkey_Packaging ,"") != 0)  || 
		 (strcmp (tempkey_TypeofQuote ,"") != 0) || (strcmp (tempkey_BillCompType ,"") != 0) || (strcmp (tempkey_BillComp ,"") != 0)  ||
		 (strcmp (tempkey_CostofChangeCur ,"") != 0) ||(strcmp (tempkey_ScreeningReq,"") != 0) ||(strcmp (tempkey_CustAppReq,"") != 0) 
		 ) 
	{
			iRetCode = find_CCR_change (tempkey_ItemID,tempkey_Name,tempkey_CAD,tempkey_CBD,tempkey_MAD,tempkey_MBD,tempkey_RAD,tempkey_RBD,tempkey_OwningUser,
			tempkey_OwningGroup, tempkey_OwningSite,tempkey_ReleaseStatus,tempkey_CurrentTask,tempkey_PricingGuidance,tempkey_SplCustCommerReq,
			tempkey_LaborEcoYrmax,tempkey_LaborEcoYrmin,tempkey_Packaging,tempkey_TypeofQuote,tempkey_BillCompType,tempkey_BillComp,tempkey_CustAuthorNum,tempkey_CustContName,
			tempkey_CustContEmail,tempkey_CustPhone,tempkey_EstNum, tempkey_VarEstNum, tempkey_CostofChangeCur,tempkey_ToolCostmax,tempkey_ToolCostmin,tempkey_CustPaidToolmax,
			tempkey_CustPaidToolmin,tempkey_PurExWorkCostmax,tempkey_PurExWorkCostmin,tempkey_PurDelDutyPaidCostmax,tempkey_PurDelDutyPaidCostmin,tempkey_LogisCostmax, 
			tempkey_LogisCostmin,tempkey_MfgLaborCostmax,tempkey_MfgLaborCostmin,tempkey_MatCostmax,tempkey_MatCostmin,tempkey_MfgVarCostmax,tempkey_MfgVarCostmin,
			tempkey_MfgScrapPermax,tempkey_MfgScrapPermin,tempkey_TotalVarCostmax,tempkey_TotalVarCostmin,tempkey_MfgSellingTransPricemax,tempkey_MfgSellingTransPricemin,
			tempkey_TIMarkupUnitCurrmax,tempkey_TIMarkupUnitCurrmin,tempkey_ScreeningReq,tempkey_CustAppReq,tempkey_CustAppType,tempkey_RFQIssuemax, tempkey_RFQIssuemin, 
			tempkey_RFQCustDuemax,tempkey_RFQCustDuemin,tempkey_ProtoDuemax,tempkey_ProtoDuemin,tempkey_ProtoQltSignmax, tempkey_ProtoQltSignmin,tempkey_DesignValDuemax,
			tempkey_DesignValDuemin,tempkey_PPAPReq,tempkey_TarPPAPLevel, tempkey_CritPathItem,tempkey_CriPathItemPPAPmax,tempkey_CriPathItemPPAPmin,tempkey_PPAPBuildEvemax,
			tempkey_PPAPBuildEvemin,tempkey_ProValSignmax,tempkey_ProValSignmin,tempkey_RunRateSignmax, tempkey_RunRateSignmin, tempkey_PPAPSignmax, tempkey_PPAPSignmin, 
			tempkey_ProSignmax, tempkey_ProSignmin, tempkey_ProdMatReqmax,tempkey_ProdMatReqmin,tempkey_StartProdmax,tempkey_StartProdmin,tempkey_EndProdmax,tempkey_EndProdmin,
			"ccr2",&iNumInT8_AttrValueFound,&tInT8_AttrValueFound);

		for(j = 0; j < iNumInT8_AttrValueFound;j++)
		{
			tiauto_Store_wsom_tags(&UniqueObjects,&iNumTotalTags,tInT8_AttrValueFound[j]);
		}
		SAFE_MEM_free(tInT8_AttrValueFound);
		iNumInT8_AttrValueFound = 0;
	}

	//total no. of out result count		
	*num_found = iNumTotalTags;
	if((*num_found) > 0)
	{
		*found = (tag_t *)MEM_alloc( (*num_found) * sizeof(tag_t) );
	}
		
	indx = 0;
	while(UniqueObjects)
	{
		tempObjects = UniqueObjects;
		(*found)[indx] = tempObjects->tUniqueWSOMObjects;
		indx++;
        UniqueObjects = UniqueObjects->next;
		free( tempObjects );
		tempObjects = NULL;
	}
	//Sorting in assending order
	for(z=0;z<(indx-1);z++)
	{
		tTemp=NULL_TAG;
		for(i=(z+1);i<indx;i++)
		{
			iRetCode = ITEM_ask_id((*found)[z], acItem_1);
			if(!iRetCode)
			{
				iRetCode = ITEM_ask_id((*found)[i], acItem_2);
				if(!iRetCode)
				{
					if(tc_strcmp(acItem_1,acItem_2)>0)
					{
						tTemp=(*found)[z];
						(*found)[z] = (*found)[i];
						(*found)[i] = tTemp;
					}
				}
			}
		}
	}
	tiauto_clearTagStack(UniqueObjects);				
	return iRetCode;
}