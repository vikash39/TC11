#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


extern int TIAUTO_AH_remove_status_from_root_task(EPM_action_message_t msg)
{
	int iRetCode = 0;
	int iCount = 0;
	tag_t *ptAttachments = NULL;
	int iNumJobs = 0;
	tag_t *ptJobs = NULL;
	tag_t tECRev = NULLTAG;
	tag_t tRootTask = NULLTAG;

	iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
	if ( (iRetCode == ITK_ok) && (tECRev != NULLTAG) )
	{	
		//check whether the EngChange revision is in process
		iRetCode = CR_ask_job(tECRev, &iNumJobs, &ptJobs);
		//get the root task
		if(iRetCode == ITK_ok && ptJobs!= NULL)
			iRetCode = EPM_ask_root_task (ptJobs[0], &tRootTask);
		if(iRetCode == ITK_ok && tRootTask!= NULLTAG)
		{
			iRetCode = EPM_ask_attachments	(	tRootTask, EPM_release_status_attachment, &iCount,&ptAttachments);
			if(iCount>0 && ptAttachments!=NULL)
				iRetCode = EPM_remove_attachments( tRootTask,iCount, ptAttachments);
		}
	}
	return iRetCode ;
}