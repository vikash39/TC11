/***********************************************************************************************************************************************
FILE        :   TIAUTO_check_mandatry_attribute_state.c
Details     :   This handler perform check weather all the mandatory atriutes of affected programs Item revision master forms are filled or not.

REVISION HISTORY :
------------------------------------------------------------------------------------------------------------------------------------
Date              Revision        Who						Description
------------------------------------------------------------------------------------------------------------------------------------
July  4, 2016     1.0			  Dipak Naik				Initial Creation.
************************************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

//main method
EPM_decision_t TIAUTO_RH_check_changetiming_form_attribute_value(EPM_rule_message_t msg)
{
	int				iArg = 0;
	int				iNumArgs = 0;
    int				iRetCode = ITK_ok;
	int				iNumAttachments = 0;
	int				indx			= 0;
    char			*pcFlag = NULL;
	char			*pcValue = NULL;
	char			*szErrMsg = NULL;
	char			*pcTarget = NULL;
	char			*pcTaskTypeName = NULL;
	char			*pcUserName = NULL;
	tag_t			tUser = NULL_TAG;
	tag_t			tTaskType = NULLTAG;
	tag_t			tRootTask = NULLTAG;
	tag_t			*ptAttachments = NULL;	
	tag_t			tForm	= NULLTAG;
	EPM_decision_t	decision = EPM_go;	
	char                acObjectType[WSO_name_size_c+1] = "";
	tag_t	tGroupmember = NULLTAG;
	tag_t tGroup = NULLTAG;
	char          acUserGroup[SA_group_name_size_c + 1] = "";

	int iSOPCnt = 0;
	int iPlantCnt = 0;
	date_t *pdSOPDates = NULL;
	char **pcPlants = NULL;

	
	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_current_groupmember(&tGroupmember);

	
	if(iRetCode == ITK_ok && tGroupmember != NULLTAG)
		iRetCode = SA_ask_groupmember_group(tGroupmember, &tGroup);

	if(iRetCode == ITK_ok && tGroup != NULLTAG)
	    iRetCode = SA_ask_group_name(tGroup, acUserGroup);

	if(tc_strcmp(acUserGroup,"dba") == 0)
	{
		decision = EPM_go;
		return decision;
	}

	//get current logged in user
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask);	
		if ( iRetCode==ITK_ok && tRootTask!=NULLTAG )
		{
			//get input arguments
			iNumArgs = TC_number_of_arguments(msg.arguments);
			if(iNumArgs>0)
			{
				for(iArg = 0; (iArg < iNumArgs) && (iRetCode==ITK_ok) ; iArg++)
				{
					iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue);
					if(iRetCode == ITK_ok)
					{					
						if( tc_strcasecmp(pcFlag, "form_type") == 0 && pcValue != NULL)
						{
							pcTarget = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
							tc_strcpy( pcTarget, pcValue);							
						}
					}
					SAFE_MEM_free(pcFlag);
					SAFE_MEM_free(pcValue);
				}
			}

			//get the targeted object
			if(iRetCode == ITK_ok)
			{
				
					//get the targeted form type
					iRetCode = EPM_ask_root_task(msg.task , &tRootTask);
					if (iRetCode == ITK_ok)
						iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iNumAttachments, &ptAttachments);

					for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
					{
						iRetCode = WSOM_ask_object_type(ptAttachments[indx], acObjectType);
						//if( DEBUG_PRINT ) printf("\n WSO type - tiauto_get_change_item_rev : %s\n", acObjectType);
						if (iRetCode == ITK_ok &&  (tc_strcmp (acObjectType, pcTarget) == 0 ) )
						{
							tForm = ptAttachments[indx];
							break;  // there should be only one change rev in target objects.
						}
					}
					
					if(tForm != NULLTAG)
					{
						iRetCode = AOM_UIF_ask_value(tForm,"t8_t1a188rfqissued",&pcValue);
					
						if(pcValue != NULL && tc_strstr(pcValue,"31-Dec-9999") != NULL)
						{
							decision = EPM_nogo;
							EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_RFQ_ATTRIBUTE_VALUE, "RFQ Issued attribute of Change Timing form contains incorrect date value.") ;
						}

						iRetCode = AOM_UIF_ask_value(tForm,"t8_t1a188startofproduction",&pcValue);
					
						if(pcValue != NULL && tc_strstr(pcValue,"31-Dec-9999") != NULL)
						{
							decision = EPM_nogo;
							EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_SOP_ATTRIBUTE_VALUE, "Start of Production attribute of Change Timing form contains incorrect date value.") ;
						}
						
						iRetCode = AOM_ask_value_dates(tForm,"t8_t1a188startofproduction",&iSOPCnt,&pdSOPDates);
						iRetCode = AOM_ask_value_strings(tForm,"t8_t1a188affectedplants",&iPlantCnt,&pcPlants);

						if(iSOPCnt > 0 && iPlantCnt > 0 && iSOPCnt != iPlantCnt)
						{
							decision = EPM_nogo;
							EMH_store_error_s1( EMH_severity_error, TIAUTO_INVALID_MISMATCH_SOP_AND_PLANT_ATTRIBUTE_VALUE, "Number of values mentioned in Affected Plants attribute is not matching with the number of values mentioned in Start of Production attribute of Change Timing form.") ;						
						}
					}
				
				
			}			
		}  
	}

	if (iRetCode != ITK_ok)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &szErrMsg);
		TC_write_syslog(szErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, szErrMsg);		
		SAFE_MEM_free (szErrMsg);
	}
	
	
	
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);

	return decision;
}