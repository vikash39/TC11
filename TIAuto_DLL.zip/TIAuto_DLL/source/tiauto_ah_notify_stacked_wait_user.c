/*******************************************************************************
File         : tiauto_ah_notify_stacked_wait_user.c

Description  : This action handler sends mails to all stacked wait change process's
			   wait task responsible party.

Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                 Description
*******************************************************************************
Oct 01, 2010    1.0        Dipak Naik			Initial Creation
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

void tiauto_Store_StackedTask_Details(TIA_StackedTask **StackedWaitTaskList,char *pcItemRevId,
									  tag_t tTask,char *pcWaitChangeRevId,char *pcWaitTaskName);
void tiauto_Store_StackedTask(TIA_WaitTaskDetails **StackedTaskList, tag_t tTask, 
							  char *pcChangeProcessName,char *pcWaitTaskName);
void FreeMemoryofListSupplier(TIA_WaitTaskDetails *TaskNamesPerUserList);
void FreeMemoryofStackedTaskList(TIA_StackedTask *StackedWaitTaskList);
int Check_for_Parent(tag_t tItemRev,char *pcChildProcessRootTask,TIA_WaitTaskDetails **StackedTask);
int Send_Stacked_Mail(tag_t tUser,char *pcCurrentChangeRevId,char *pcStackedWaitChangeRevId,
							char *pcStackedItemRevId,char *pcWaitTaskName,char *pcSubject);
int Check_for_Instance(tag_t tGeneric,char *pcChildProcessRootTask,TIA_WaitTaskDetails **StackedTask);

//mail method
extern int TIAUTO_AH_notify_stacked_wait_user(EPM_action_message_t msg)
{
	int				iRetCode			= ITK_ok;
    int				iNumAffected		= 0;
	int				iCount				= 0;

	tag_t			tRootTask			= NULLTAG;
	tag_t			tReposibleParty		= NULLTAG;
	tag_t			tECRev				= NULLTAG;
	tag_t			*ptAffectedItems	= NULL;

	char			*pcChangeRevId								= NULL;
	char			*pcItemRevId								= NULL;
	char			*pcErrMsg									= NULL;
	char			acSubject[1024]								= {'\0'};
	char			acRootTaskName[WSO_name_size_c+1]			= {'\0'};


	TIA_StackedTask *StackedWaitTaskList = NULL;

    //Get the target change revision
	iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
	if(iRetCode == ITK_ok && tECRev != NULLTAG)
	{
		//get all the affected item revisions that are present in the affected and Solution
		//item folder of the change revision
		iRetCode = ECM_get_affected_items(tECRev, &iNumAffected, &ptAffectedItems);
	}
	if(iRetCode == ITK_ok && iNumAffected > 0)
	{
		//get the root task
		iRetCode = EPM_ask_root_task (msg.task, &tRootTask) ;
		if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
		{
			//get the root task name
			iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
		}
	}
	for(iCount = 0; iCount < iNumAffected && (iRetCode == ITK_ok);iCount++)
	{
		TIA_WaitTaskDetails *tempList = NULL;
		//get the item revision id
		iRetCode = WSOM_ask_id_string(ptAffectedItems[iCount], &pcItemRevId);			
		//check for the parent that is attached to a stacked process
		iRetCode = Check_for_Parent(ptAffectedItems[iCount],acRootTaskName,&tempList);
		//check for the instance that is attached to a stacked process
		iRetCode = Check_for_Instance(ptAffectedItems[iCount],acRootTaskName,&tempList);
		while(tempList != NULL)
		{
			tiauto_Store_StackedTask_Details(&StackedWaitTaskList,pcItemRevId,tempList->tWaitTask,
												tempList->acWaitStackedChangeRev,tempList->acWaitTaskName);
			tempList = tempList->next;
		}
		FreeMemoryofListSupplier(tempList);
		SAFE_MEM_free(pcItemRevId);
	}
	SAFE_MEM_free(ptAffectedItems);	
	
	if(iRetCode == ITK_ok && StackedWaitTaskList != NULL)
	{	
		iRetCode = WSOM_ask_id_string(tECRev, &pcChangeRevId);
		
		while(StackedWaitTaskList != NULL && iRetCode == ITK_ok)
		{
			tReposibleParty = NULLTAG;
			//subject of the mail
			TI_sprintf(acSubject,"Please perform the task (%s) of the process %s",StackedWaitTaskList->acWaitTaskName
																		  ,StackedWaitTaskList->acChangeRev);
			//get the responsible party of the task
			iRetCode = EPM_ask_responsible_party(StackedWaitTaskList->tTask,&tReposibleParty);				
			if(iRetCode == ITK_ok &&  tReposibleParty != NULLTAG)
			{
				//send mail
				iRetCode = Send_Stacked_Mail(tReposibleParty,pcChangeRevId, StackedWaitTaskList->acChangeRev,
												StackedWaitTaskList->acStackedItemRev,
												StackedWaitTaskList->acWaitTaskName, acSubject);
			}
			StackedWaitTaskList = StackedWaitTaskList->next;				
		} 	
		SAFE_MEM_free(pcChangeRevId);
		FreeMemoryofStackedTaskList(StackedWaitTaskList);
	}
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	
	return iRetCode;  
}


/*=====================================================================================
*   Check_for_Parent()
*\param				tag_t					tItemRev,					<I>
*					char					*pcChildProcessRootTask,	<I>
*					TIA_WaitTaskDetails		**StackedTask				<O>
*\return int
*
* Description: To check whether the parent item revision is attached to any other .
*				stacked process. 	
=====================================================================================*/
int Check_for_Parent(tag_t tItemRev,char *pcChildProcessRootTask,TIA_WaitTaskDetails **StackedTask)
{
	int		iRetCode				= ITK_ok;
	int		iParentCount			= 0;
	int		indx					= 0;
	int		iNoOfJobs				= 0;
	int		iNumAttachments			= 0;
	int		iCount					= 0;
	int		iCurrentTaskCount		= 0;
	int		i						= 0;
	int		*piLevel				= NULL;

	tag_t	tTypeTag				= NULLTAG;
	tag_t	tJob					= NULLTAG;
	tag_t	tRootTask				= NULLTAG;
	tag_t	tEngChngRev				= NULLTAG;
    tag_t	*ptAttachments			= NULL;	
	tag_t	*ptParentRev			= NULL;
	tag_t	*ptJobs					= NULL;
	tag_t	*ptCurrentTask			= NULL;

	char	acTypeClass[TCTYPE_class_name_size_c+1]	= "";
    char	pszObject[WSO_name_size_c+1]				= "";
	char	acRootTaskName[WSO_name_size_c+1]			= "";
	char	acCuurentTaskName[WSO_name_size_c+1]		= "";
	char	*pcOtherProcessName							= NULL;

	logical lIsCorrectStackedProcess	= false;
	logical lIsParentInCorrectProcess	= false;
	//check the parent that is attached to the stacked process
	iRetCode = PS_where_used_precise (tItemRev,1,&iParentCount,&piLevel,&ptParentRev);
	for(indx = 0;indx < iParentCount && ( iRetCode == ITK_ok );indx++)
	{
		lIsParentInCorrectProcess = false;
		iRetCode = CR_ask_job(ptParentRev[indx], &iNoOfJobs, &ptJobs);
		if( (iNoOfJobs > 0) && ( iRetCode == ITK_ok ))
		{
			iRetCode = TCTYPE_ask_object_type(ptJobs[0],&tTypeTag);
			if(iRetCode == ITK_ok)
				iRetCode = TCTYPE_ask_class_name (tTypeTag, acTypeClass);
			if( ( iRetCode == ITK_ok ) && (tc_strcmp(acTypeClass,"EPMJob") == 0) )
			{
				tJob = ptJobs[0];
				tEngChngRev = NULLTAG;
				lIsCorrectStackedProcess = false;
				iCurrentTaskCount = 0;
				if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
				{	
					iRetCode = EPM_ask_root_task (tJob, &tRootTask) ;
					if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
					{
						//get the root task name
						iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
						//check if the root task name is DAP process
						if( ( iRetCode == ITK_ok ) && 
						    ( tc_strcmp(acRootTaskName,"6_00 DAP - Design Approval")==0) && 
							( tc_strcmp(acRootTaskName,pcChildProcessRootTask) == 0) )
						{
							lIsCorrectStackedProcess = true;
						}
						else if(  ( iRetCode == ITK_ok ) && 
							      ( (tc_strcmp(acRootTaskName,"2_00 CR - Change Request")==0)|| 
								    (tc_strcmp(acRootTaskName,"10_00 CRB - CR Bypass")==0)||
								    (tc_strcmp(acRootTaskName,"13_00 CRB - CR Bypass")==0) ||
									(tc_strcmp(acRootTaskName,"9_00 CRO - CAD Release Only")==0) ||
									(tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process")==0) ||
									(tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process")==0) ||
									(tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(acRootTaskName,"CAP - Change Approval Process")==0) ||
									(tc_strcmp(acRootTaskName,"SRP - Standards Release Process")==0) ||
									(tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation")==0) ||
									(tc_strcmp(acRootTaskName,"CRO - CAD Release Only")==0) ||
									(tc_strcmp(acRootTaskName,"TPR - Technology Primary Release")==0) ||
									(tc_strcmp(acRootTaskName,"TER - Technology Emergency Release")==0)) && 
								  ( (tc_strcmp(pcChildProcessRootTask,"2_00 CR - Change Request")==0)|| 
								    (tc_strcmp(pcChildProcessRootTask,"10_00 CRB - CR Bypass")==0)||
								    (tc_strcmp(pcChildProcessRootTask,"13_00 CRB - CR Bypass")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"9_00 CRO - CAD Release Only")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"14_00 PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"15_00 CAP - Change Approval Process")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"22_00 PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"19_00 CAP - Change Approval Process")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"SRP - Standards Release Process")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"PCI - Plant Change Implementation")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"CRO - CAD Release Only")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"PMR - Program Mgmt Release")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"CAP - Change Approval Process")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"TPR - Technology Primary Release")==0) ||
									(tc_strcmp(pcChildProcessRootTask,"TER - Technology Emergency Release")==0)) ) 
						{
							lIsCorrectStackedProcess = true;
						}

						if( ( iRetCode == ITK_ok ) && lIsCorrectStackedProcess == true)
						{
							iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
															&iNumAttachments, &ptAttachments); 
							for(iCount = 0; (iCount < iNumAttachments) && (iRetCode == ITK_ok); iCount++)
							{
								iRetCode = WSOM_ask_object_type(ptAttachments[iCount], pszObject);			
								if (iRetCode == ITK_ok && tc_strcmp (pszObject, CHANGE_REV) == 0 )
								{
									tEngChngRev = ptAttachments[iCount];
									break;  // there should be only one change rev in target objects.
								}
							}
							SAFE_MEM_free(ptAttachments);
							if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
							{
								//get the cuurent task
								iRetCode = EPM_ask_tasks (tJob,EPM_started,&iCurrentTaskCount,&ptCurrentTask);
								for(i = 0; i < iCurrentTaskCount ; i++)
								{
									if( ( iRetCode == ITK_ok ) && (tRootTask != ptCurrentTask[i]))
									{
										//get the current task name
										iRetCode = EPM_ask_name  (  ptCurrentTask[i], acCuurentTaskName );
										if( ( iRetCode == ITK_ok ) && 
											( ( tc_strcmp(acCuurentTaskName,"6_215 Wait for Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"2_482 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"13_160 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"10_190 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"14_40 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"22_40 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"9_70 Wait for Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"17_160 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"19_410 Wait For Stacked Change") == 0) ||
											   ( tc_strcmp(acCuurentTaskName,"28_410 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"20_190 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"15_240 Wait For Stacked Change") == 0) ||
											   ( tc_strcmp(acCuurentTaskName,"23_190 Wait For Stacked Change") == 0) ||
											  ( tc_strcmp(acCuurentTaskName,"25_110 Wait For Stacked Change") == 0)) )
										{
											if( tiauto_isComponent_partOf_affectedItems(ptParentRev[indx], tEngChngRev) == true )
											{
												lIsParentInCorrectProcess = true;
												iRetCode = WSOM_ask_id_string(tEngChngRev, &pcOtherProcessName);
												tiauto_Store_StackedTask(StackedTask,ptCurrentTask[i],pcOtherProcessName,acCuurentTaskName);
												SAFE_MEM_free(pcOtherProcessName);
											}
										}
									}
								}
								SAFE_MEM_free(ptCurrentTask);
							}
						}
					}
				}
			}		
		}
		SAFE_MEM_free(ptJobs);
		if(iRetCode == ITK_ok && lIsParentInCorrectProcess == false)
		{
			//if the item revision is not attached to any process, then check its parent
			iRetCode = Check_for_Parent(ptParentRev[indx],pcChildProcessRootTask,StackedTask);
		}
	}
	SAFE_MEM_free(piLevel);
	SAFE_MEM_free(ptParentRev);

	return iRetCode;
}

/*=====================================================================================
*  FreeMemoryofListSupplier()
*\param				TIA_WaitTaskDetails *TaskNamesPerUserList	<I>			
*\return void				
* Description:
*			To free the structure.
=====================================================================================*/
void FreeMemoryofListSupplier(TIA_WaitTaskDetails *TaskNamesPerUserList)
{
	TIA_WaitTaskDetails *tempFree1 = NULL;
	while(TaskNamesPerUserList != NULL)
	{
		tempFree1 = TaskNamesPerUserList->next;
		free (TaskNamesPerUserList);
		TaskNamesPerUserList = tempFree1;
		tempFree1 = NULL;
	}
	return;
}
/*=====================================================================================
*   tiauto_Store_StackedTask_Details()
*\param				TIA_WaitTaskDetails		**TaskNamesPerUserList,	<O>
*					tag_t					tTask,					<I>
*					char					*pcChangeProcessName	<I>
*					char					*pcWaitTaskName			<I>
*\return void				
* Description:
*			To store all the details of the tasks per task(unique).
=====================================================================================*/
void tiauto_Store_StackedTask(TIA_WaitTaskDetails **StackedTaskList, tag_t tTask, 
							  char *pcChangeProcessName,char *pcWaitTaskName)
{	
	TIA_WaitTaskDetails *temp = NULL;
    logical isPresent = false;
	temp = *StackedTaskList;

	if( (*StackedTaskList == NULL) || (temp == NULL) )
	{
		*StackedTaskList=malloc(sizeof(TIA_WaitTaskDetails));
		temp = *StackedTaskList;
		temp->tWaitTask = 0;
		TI_sprintf(temp->acWaitStackedChangeRev, "");
		TI_sprintf(temp->acWaitTaskName, "");
	}
	else
	{	
		for(;;)
		{
			if( temp->tWaitTask == tTask )
			{
				isPresent = true;
				//TI_sprintf(temp->acWaitStackedChangeRev,"%s\n%s",temp->acWaitStackedChangeRev,pcChangeProcessName);
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else 
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_WaitTaskDetails));
			temp=temp->next;
			temp->tWaitTask = 0;
			TI_sprintf(temp->acWaitStackedChangeRev, "");
			TI_sprintf(temp->acWaitTaskName, "");
		}
	}
	if ( isPresent == false )
	{
		temp->tWaitTask = tTask;
		TI_sprintf(temp->acWaitStackedChangeRev,"%s",pcChangeProcessName);
		TI_sprintf(temp->acWaitTaskName,"%s",pcWaitTaskName);
		temp->next  = NULL;
	}	
	
	//free ( temp );
	temp = NULL;
}
/*=====================================================================================
*  FreeMemoryofListSupplier()
*\param				TIA_WaitTaskDetails *TaskNamesPerUserList	<I>			
*\return void				
* Description:
*			To free the structure.
=====================================================================================*/
void FreeMemoryofStackedTaskList(TIA_StackedTask *StackedWaitTaskList)
{
	TIA_StackedTask *tempFree1 = NULL;
	while(StackedWaitTaskList != NULL)
	{
		tempFree1 = StackedWaitTaskList->next;
		free (StackedWaitTaskList);
		StackedWaitTaskList = tempFree1;
		tempFree1 = NULL;
	}
	return;
}
/*=====================================================================================
*   tiauto_Store_StackedTask_Details()
*\param				TIA_StackedTask		**StackedWaitTaskList,	<O>
*					char				*pcItemRevId			<I>
*					tag_t				tTask,					<I>
*					char				*pcWaitChangeRevId		<I>
*					char				*pcWaitTaskName			<I>
*\return void				
* Description:
*			To store all the details of the tasks per task(unique).
=====================================================================================*/
void tiauto_Store_StackedTask_Details(TIA_StackedTask **StackedWaitTaskList,char *pcItemRevId,
									  tag_t tTask,char *pcWaitChangeRevId,char *pcWaitTaskName)
{
	TIA_StackedTask *temp = NULL;
    logical isPresent = false;
	temp = *StackedWaitTaskList;

	if( (*StackedWaitTaskList == NULL) || (temp == NULL) )
	{
		*StackedWaitTaskList=malloc(sizeof(TIA_StackedTask));
		temp = *StackedWaitTaskList;
		temp->tTask = 0;
		TI_sprintf(temp->acChangeRev, "");
		TI_sprintf(temp->acStackedItemRev, "");
		TI_sprintf(temp->acWaitTaskName, "");
	}
	else
	{	
		for(;;)
		{
			if( temp->tTask == tTask )
			{
				isPresent = true;
				TI_sprintf(temp->acStackedItemRev,"%s\n%s",temp->acStackedItemRev,pcItemRevId);
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else 
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_StackedTask));
			temp=temp->next;
			temp->tTask = 0;
			TI_sprintf(temp->acChangeRev, "");
			TI_sprintf(temp->acStackedItemRev, "");
			TI_sprintf(temp->acWaitTaskName, "");
		}
	}
	if ( isPresent == false )
	{
		temp->tTask = tTask;
		TI_sprintf(temp->acChangeRev,"%s",pcWaitChangeRevId);
		TI_sprintf(temp->acStackedItemRev,"%s",pcItemRevId);
		TI_sprintf(temp->acWaitTaskName, "%s",pcWaitTaskName);
		temp->next  = NULL;
	}	
	
	//free ( temp );
	temp = NULL;
}

/*=====================================================================================
*   Send_Stacked_Mail()
*\param				tag_t	tUser,						<I>
					char	*pcCurrentChangeRevId,		<I>
					char	*pcStackedWaitChangeRevId,	<I>
					char	*pcStackedItemRevId,		<I>
					char	*pcWaitTaskName				<I>		
					char	*pcSubject					<I>
*\return int				
* Description:
*			To send the mails.
=====================================================================================*/
int Send_Stacked_Mail(tag_t tUser,char *pcCurrentChangeRevId,char *pcStackedWaitChangeRevId,
							char *pcStackedItemRevId,char *pcWaitTaskName,char *pcSubject)
{
	int			iRetCode									= ITK_ok;
	int         iFileOpenErrCode                            = 0;
	txt_t		the_text_server								= NULL;
    char		*pcMsgName									= NULL;
    char		*pcComments									= NULL;	
	char		*pcUserName									= NULL;
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	FILE		*fMailBodyFile								= NULL;
	//get the email id of the user
	iRetCode = EPM_get_user_email_addr(tUser,&pcEmailId );
	//get teh name of the user
	if(iRetCode == ITK_ok)
	{
		iRetCode = SA_ask_user_person_name2 (tUser,&pcUserName );
	}
	if(iRetCode == ITK_ok &&  pcEmailId != NULL)
	{
		//Initialize TextServer here 
		//the_text_server = txt_ctor( "iman_text.xml" );
		//pcMsgName = "User_Comments";
		//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
		//txt_destructor(the_text_server);
		pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
        iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w");
		fprintf(fMailBodyFile,"Dear %s,\n",pcUserName);
		fprintf(fMailBodyFile,"You are waiting at task \"%s\" of the process \"%s\" because of the following "
								"stacked item revisions that are attached to the other stacked change process \"%s\":\n",
								pcWaitTaskName,pcStackedWaitChangeRevId,pcCurrentChangeRevId );
		fprintf(fMailBodyFile,"\n%s\n",pcStackedItemRevId);
		fprintf(fMailBodyFile,"\nThe stacked change process \"%s\" is completed. ",pcCurrentChangeRevId);
		fprintf(fMailBodyFile,"Now you can complete the task \"%s\" of the change process \"%s\".\n", 
								pcWaitTaskName,pcStackedWaitChangeRevId);
		if(fMailBodyFile != NULL)
		{
			fclose(fMailBodyFile);
		}
		//send mail
		if(pcEmailId != NULL)
			iRetCode = tiauto_sendEMail(pcSubject, pcEmailId, pcMailBodyFileName);
	}

	SAFE_MEM_free(pcComments);
	SAFE_MEM_free(pcUserName);
	SAFE_MEM_free(pcEmailId);
	// delete temporary file here
    remove(pcMailBodyFileName );
	return iRetCode;
}
/*=====================================================================================
*   Check_for_Instance()
*\param				tag_t					tItemRev,					<I>
*					char					*pcChildProcessRootTask,	<I>
*					TIA_WaitTaskDetails		**StackedTask				<O>
*\return int
*
* Description: To check whether the instace item revision of the generic is attached 
*				to any other stacked process. 	
=====================================================================================*/
int Check_for_Instance(tag_t tGeneric,char *pcChildProcessRootTask,TIA_WaitTaskDetails **StackedTask)
{
	int iRetCode				= ITK_ok;
	int iProEDSRefCnt			= 0;
	int iProDsCntIter			= 0;
	int iPrimaryOfProEDSCnt		= 0;
	int iPrimaryOfProEDSIter	= 0;
	int iNumAttachments			= 0;
	int iNumAttchIter			= 0;
	int iCurrentTaskCount		= 0;
	int iCurrentTaskIter		= 0;
	int iNoOfJobs				= 0;	

	tag_t tSpecRelTypeTag				= NULLTAG;
	tag_t tIPEMMasterDepRelTypeTag		= NULLTAG;
	tag_t tJobTypeTag					= NULLTAG;
	tag_t tPrimaryInstanceTypeTag		= NULLTAG;
	tag_t tJob							= NULLTAG;
	tag_t tRootTask						= NULLTAG;
	tag_t tEngChngRev					= NULLTAG;
	tag_t *ptPrimaryProEDSTags			= NULL;
	tag_t *ptPrimaryInstanceItemRevTags = NULL;
	tag_t *ptAttachments				= NULL;
	tag_t *ptCurrentTask				= NULL;
	tag_t *ptJobs						= NULL;

	char  acPrimaryObjectType[WSO_name_size_c+1]					= {'\0'};
	char  acPrimaryInstanceClassName[TCTYPE_class_name_size_c+1]	= {'\0'};
	char  acJobTypeClass[TCTYPE_class_name_size_c+1]				=  {'\0'};
	char  acRootTaskName[WSO_name_size_c+1]							= {'\0'};
	char  acAttachmentTypeName[WSO_name_size_c+1]					= {'\0'};
	char  acCurrentTaskName[WSO_name_size_c+1]						= {'\0'};
	char  *pcOtherProcessName										= NULL;

	logical lIsCorrectStackedProcess	= false;
	
	//get the IPEM_master_dependency relation tag
	iRetCode = GRM_find_relation_type("IPEM_master_dependency", &tIPEMMasterDepRelTypeTag);
	if( iRetCode == ITK_ok)
		iRetCode = GRM_find_relation_type("IMAN_specification", &tSpecRelTypeTag);
	//get the primary object of the gereric item revision with IPEM_master_dependency relation
	if (iRetCode == ITK_ok && tIPEMMasterDepRelTypeTag != NULLTAG)
		iRetCode = GRM_list_primary_objects_only(tGeneric,tIPEMMasterDepRelTypeTag,&iProEDSRefCnt,&ptPrimaryProEDSTags);
	for( iProDsCntIter = 0; iProDsCntIter < iProEDSRefCnt && iRetCode == ITK_ok && ptPrimaryProEDSTags != NULL; iProDsCntIter++)
	{
		//get the object type
		iRetCode = WSOM_ask_object_type(ptPrimaryProEDSTags[iProDsCntIter], acPrimaryObjectType);
		//if the object type is ProPrt or ProAsm the process that object
		if( iRetCode == ITK_ok && ( (tc_strcasecmp(acPrimaryObjectType, "ProPrt") == 0) || 
			(tc_strcasecmp(acPrimaryObjectType, "ProAsm") == 0)))
		{
			//get the primary object of the ProPrt or ProAsm dataset with specification relation
			iRetCode = GRM_list_primary_objects_only(ptPrimaryProEDSTags[iProDsCntIter],tSpecRelTypeTag,&iPrimaryOfProEDSCnt,&ptPrimaryInstanceItemRevTags);
			for( iPrimaryOfProEDSIter = 0; iPrimaryOfProEDSIter < iPrimaryOfProEDSCnt && iRetCode == ITK_ok && ptPrimaryInstanceItemRevTags != NULL; iPrimaryOfProEDSIter++)
			{
				//check the primary object
				iRetCode = TCTYPE_ask_object_type(ptPrimaryInstanceItemRevTags[iPrimaryOfProEDSIter],&tPrimaryInstanceTypeTag);
				if(iRetCode == ITK_ok)
					iRetCode = TCTYPE_ask_class_name (tPrimaryInstanceTypeTag, acPrimaryInstanceClassName);
				//if the primary object class is item revision, then process the next
				if( ( iRetCode == ITK_ok ) && (tc_strcmp(acPrimaryInstanceClassName,"ItemRevision") == 0) )
				{
					//get the process attached to the instance item rev
					iRetCode = CR_ask_job(ptPrimaryInstanceItemRevTags[iPrimaryOfProEDSIter], &iNoOfJobs, &ptJobs);
					if( (iNoOfJobs > 0) && ( iRetCode == ITK_ok ))
					{
						iRetCode = TCTYPE_ask_object_type(ptJobs[0],&tJobTypeTag);
						if(iRetCode == ITK_ok)
							iRetCode = TCTYPE_ask_class_name (tJobTypeTag, acJobTypeClass);
						if( ( iRetCode == ITK_ok ) && (tc_strcmp(acJobTypeClass,"EPMJob") == 0) )
						{
							tJob = ptJobs[0];
							tEngChngRev = NULLTAG;
							lIsCorrectStackedProcess = false;
							iCurrentTaskCount = 0;
							if( ( iRetCode == ITK_ok ) && ( tJob != NULLTAG ) )
							{	
								//get the root task
								iRetCode = EPM_ask_root_task (tJob, &tRootTask) ;
								if( ( iRetCode == ITK_ok ) && ( tRootTask != NULLTAG ) )
								{
									//get the root task name
									iRetCode = EPM_ask_name  (  tRootTask, acRootTaskName );
									//check if the root task name is DAP process
									if( ( iRetCode == ITK_ok ) && 
										( tc_strcmp(acRootTaskName,"6_00 DAP - Design Approval")==0) && 
										( tc_strcmp(acRootTaskName,pcChildProcessRootTask) == 0) )
									{
										lIsCorrectStackedProcess = true;
									}
									else if(  ( iRetCode == ITK_ok ) && 
											( (tc_strcmp(acRootTaskName,"2_00 CR - Change Request")==0)|| 
										      (tc_strcmp(acRootTaskName,"10_00 CRB - CR Bypass")==0)||
										      (tc_strcmp(acRootTaskName,"13_00 CRB - CR Bypass")==0) ||
											  (tc_strcmp(acRootTaskName,"9_00 CRO - CAD Release Only")==0) ||
											  (tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process")==0) ||
											  (tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process")==0) ||
											  (tc_strcmp(acRootTaskName,"CRO - CAD Release Only")==0) ||
											  (tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(acRootTaskName,"CAP - Change Approval Process")==0) ||
											  (tc_strcmp(acRootTaskName,"PCI - Plant Change Implementation")==0) ||
											  (tc_strcmp(acRootTaskName,"SRP - Standards Release Process")==0) ||
											  (tc_strcmp(acRootTaskName,"TPR - Technology Primary Release")==0) ||
											  (tc_strcmp(acRootTaskName,"TER - Technology Emergency Release")==0)) && 
										    ( (tc_strcmp(pcChildProcessRootTask,"2_00 CR - Change Request")==0)|| 
										      (tc_strcmp(pcChildProcessRootTask,"10_00 CRB - CR Bypass")==0)||
										      (tc_strcmp(pcChildProcessRootTask,"13_00 CRB - CR Bypass")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"9_00 CRO - CAD Release Only")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"14_00 PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"15_00 CAP - Change Approval Process")==0)||
											  (tc_strcmp(pcChildProcessRootTask,"22_00 PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"19_00 CAP - Change Approval Process")==0)||
											  (tc_strcmp(pcChildProcessRootTask,"CRO - CAD Release Only")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"PMR - Program Mgmt Release")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"CAP - Change Approval Process")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"PCI - Plant Change Implementation")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"SRP - Standards Release Process")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"TPR - Technology Primary Release")==0) ||
											  (tc_strcmp(pcChildProcessRootTask,"TER - Technology Emergency Release")==0)) ) 
									{
										lIsCorrectStackedProcess = true;
									}
									if( ( iRetCode == ITK_ok ) && lIsCorrectStackedProcess == true)
									{
										iRetCode = EPM_ask_attachments(tRootTask, EPM_target_attachment,
																		&iNumAttachments, &ptAttachments); 
										for(iNumAttchIter = 0; (iNumAttchIter < iNumAttachments) && (iRetCode == ITK_ok); iNumAttchIter++)
										{
											iRetCode = WSOM_ask_object_type(ptAttachments[iNumAttchIter], acAttachmentTypeName);			
											if (iRetCode == ITK_ok && tc_strcmp (acAttachmentTypeName, CHANGE_REV) == 0 )
											{
												tEngChngRev = ptAttachments[iNumAttchIter];
												break;  // there should be only one change rev in target objects.
											}
										}
										SAFE_MEM_free(ptAttachments);
										if( ( iRetCode == ITK_ok ) && ( tEngChngRev != NULLTAG ) )
										{
											//get the cuurent task
											iRetCode = EPM_ask_tasks (tJob,EPM_started,&iCurrentTaskCount,&ptCurrentTask);
											for(iCurrentTaskIter = 0; iCurrentTaskIter < iCurrentTaskCount ; iCurrentTaskIter++)
											{
												if( ( iRetCode == ITK_ok ) && (tRootTask != ptCurrentTask[iCurrentTaskIter]))
												{
													//get the current task name
													iRetCode = EPM_ask_name(ptCurrentTask[iCurrentTaskIter], acCurrentTaskName );
													if( ( iRetCode == ITK_ok ) && 
														( ( tc_strcmp(acCurrentTaskName,"6_215 Wait for Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"2_482 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"13_160 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"9_70 Wait for Stacked Change") == 0) ||
													      ( tc_strcmp(acCurrentTaskName,"10_190 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"14_40 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"22_40 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"17_160 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"19_410 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"28_410 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"20_190 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"15_240 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"23_190 Wait For Stacked Change") == 0) ||
														  ( tc_strcmp(acCurrentTaskName,"25_110 Wait For Stacked Change") == 0))  )
													{
														if( tiauto_isComponent_partOf_affectedItems(ptPrimaryInstanceItemRevTags[iPrimaryOfProEDSIter], tEngChngRev) == true )
														{
															iRetCode = WSOM_ask_id_string(tEngChngRev, &pcOtherProcessName);
															tiauto_Store_StackedTask(StackedTask,ptCurrentTask[iCurrentTaskIter],pcOtherProcessName,acCurrentTaskName);
															SAFE_MEM_free(pcOtherProcessName);
														}
													}
												}
											}
											SAFE_MEM_free(ptCurrentTask);
										}
									}
								}
							}
						}		
					}
					SAFE_MEM_free(ptJobs);
				}
			}
			SAFE_MEM_free(ptPrimaryInstanceItemRevTags);
		}	
	}
	SAFE_MEM_free(ptPrimaryProEDSTags);
	return iRetCode;
}
