/*******************************************************************************
File         : tiauto_ah_copy_and_attach_timing_form.c

Description  : Create a copy of the Change Timing form available on the change revision based on change revision
			   Attach the new form to the current change revision with IMAN_specification relation

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jun 6, 2016    1.0        Shilpa      Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define FORM_NAME "Change Timing"
#define INIT_LIST_SIZE         200


extern int t1aAUTO_AH_copy_and_attach_timing_form(EPM_action_message_t msg)
{
	int				iRetcode							= ITK_ok;
	int				iTargetCount						= 0;
	int				iLoopTargetCnt						= 0;
	int				inum								= 0;
	tag_t			tRootTaskTag						= NULLTAG;	
	tag_t			tEngChangeRev						= NULLTAG;
	tag_t			tEngChangeRevLatest					= NULLTAG;
	tag_t			*ptTargetAtt						= NULL;
	char			*tTargetObjType						= NULL;
	char            pszObjectType[WSO_name_size_c+1]	="";
	tag_t			*tEngChangeRevs						= NULL;	
	tag_t			tRelTag								= NULLTAG;
	tag_t			tFormCopyTag						= NULLTAG;
	tag_t 			tUserData							= NULLTAG;
	tag_t			tEngChangeItem						= NULLTAG;

	if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the change revision details
		if(iRetcode == ITK_ok && tRootTaskTag!= NULLTAG)
		{
			iRetcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
			iRetcode = ITEM_ask_item_of_rev(tEngChangeRev,&tEngChangeItem);
			iRetcode = ITEM_ask_latest_rev(tEngChangeItem,&tEngChangeRevLatest);
			iRetcode = AOM_ask_value_tags( tEngChangeRevLatest,Rel_Change_ObjectRev,&inum,&tEngChangeRevs);
			if(inum > 0 )
			{
				int			iLoopChangeRev				=0;
				iRetcode = GRM_find_relation_type("IMAN_specification", &tRelTag);
				for(iLoopChangeRev= 0; iLoopChangeRev < inum; iLoopChangeRev++)
				{
					int			iLoopSecObj				=0;
					int			iSecObjCount			=0;
					tag_t		*ptSecObjTags			= NULL;
					tag_t		tRelatioifFound			= NULLTAG;

					iRetcode = GRM_list_secondary_objects_only(tEngChangeRevs[iLoopChangeRev],tRelTag,&iSecObjCount,&ptSecObjTags);
					for(iLoopSecObj=0; iLoopSecObj < iSecObjCount; iLoopSecObj++)
					{
						iRetcode = WSOM_ask_object_type(ptSecObjTags[iLoopSecObj], pszObjectType);
						if((strcmp(pszObjectType,"T8_TI_ChangeTiming") == 0)  && (iRetcode == ITK_ok))
						{
							//iRetcode =	FORM_copy2(pszObjectType,ptSecObjTags,&tFormCopyTag);
							//iRetcode =	AOM_set_value_string	(tFormCopyTag,"object_name",FORM_NAME);
							iRetcode =	WSOM_copy	(ptSecObjTags[iLoopSecObj],FORM_NAME,&tFormCopyTag);
							//iRetcode =	AOM_set_value_strings(tFormCopyTag,"t8_t1a188affectedplants",0,NULL);
							iRetcode = AOM_UIF_set_value(tFormCopyTag,"t8_t1a188startofproduction","31-Dec-9999");
							iRetcode =	AOM_save(tFormCopyTag);
							if((tFormCopyTag != NULLTAG) && (iRetcode == ITK_ok))
							{							
								iRetcode = GRM_find_relation(tEngChangeRevLatest,tFormCopyTag,tRelTag,&tRelatioifFound);
								if((tRelatioifFound == NULLTAG) && (iRetcode == ITK_ok))
								{	
									tag_t			tCreaRelation			= NULLTAG;
									
									iRetcode = AOM_refresh(tEngChangeRevLatest,true);
									iRetcode = GRM_create_relation	(tEngChangeRevLatest,tFormCopyTag,tRelTag,tUserData,&tCreaRelation);
									if((tCreaRelation != NULLTAG)   && (iRetcode == ITK_ok))
									{

										iRetcode = GRM_save_relation(tCreaRelation);
										iRetcode = AOM_save(tEngChangeRevLatest);
										iRetcode = AOM_refresh(tEngChangeRevLatest,false);
									}
								}
							}
						}
					}
					SAFE_MEM_free(ptSecObjTags);
				}
			}
		}
	}
	
	else if ( iRetcode != ITK_ok )
	{
		char			*pcErrMsg			= NULL;
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(ptTargetAtt);
	SAFE_MEM_free(tTargetObjType);
	SAFE_MEM_free(tEngChangeRevs);

	return iRetcode;
}