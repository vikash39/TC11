/*********************************************************************************************************************
FILE        :   tiauto_rh_verify_product_impacted.c
Details     :   This rule handler is used to check whether CAP form "product imapcted" 
                attribute value is "No" and Item Revisions in affected and soultion folders
				are have same status has CAP form "target status"  except document IR's.

REVISION HISTORY :

Date              Revision        Who						Description
June  25, 2013     1.0			  Mahesh BS				Initial Creation.
Jan	  19, 2017	   1.1			  Kantesh				Modified code to include the product impacted check for
														new CAP workflow.
Nov 23 2018		 1.2		       Jugunu               Updated for ER 9759 CAP3
**************************************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

int Validate_Targeted_Object_Status (	char		caTarRelValue[],			/*<I>*/
										int		    iNumAffected,				/*<I>*/
										tag_t	    *ptAffectedObjects,			/*<I>*/
										char		*pcFolderName,				/*<I>*/
										logical	    *lValidationFailed,			/*<O>*/
										TIA_ErrorMessage **pstCurrErrMsg )	;
/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_verify_product_impacted
===================================================================================*/
EPM_decision_t TIAUTO_RH_verify_product_impacted(EPM_rule_message_t msg )
{
	int		iFail					= ITK_ok;
	int		iNumArgs				= 0;
	int		iRelNameCount			= 0;	
	int		iAttchCntr				= 0;
	int		iNumAffected			= 0;
	int		iArg					= 0;
	int		iLoopAllTasks			= 0;
	int		iAllTasks				= 0;

	char	*pcUserName				= NULL;
	char	*pcTaskTypeName			= NULL;
	char	*pcRelation				= NULL;
	char	*pcName					= NULL;
	char	*pcTarget				= NULL;
	char	**pcRelationNames		= NULL;
	char	*pcTemp					= NULL;
	char	acErrorString[512]		= "";
	char	*pcPseudoFolderName		= NULL;	
	char	*pcErrMsg				= NULL;
	char	caPrdImpValue[WSO_name_size_c+1] = "";
	char	caTarRelValue[WSO_name_size_c+1] = "";
	char	*pcFlag					= NULL;
	char	*pcValue				= NULL;
	char	*pcTaskResult			= NULL;
	char	*pcTaskName				= NULL;

    tag_t	tUser					= NULLTAG;
    tag_t	tTaskType				= NULLTAG;
	tag_t	tEngChangeRev			= NULLTAG;
	tag_t	tRelation				= NULLTAG;
	tag_t	*ptAffectedObjects		= NULL;
	tag_t 	tDescriptor 			= NULLTAG;
	tag_t	*ptAllTaskTags			= NULL;

	TIA_ErrorMessage *pstCurrErrMsg = NULL;
	TIA_ErrorMessage *tempErrMsg	= NULL;
	
	logical	lValidationFailed		= false;
	EPM_decision_t decision = EPM_go;
	tag_t tRootTask = NULLTAG;
	char   acRootTaskName[WSO_name_size_c + 1] = "";

	//get the root task
	iFail = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iFail == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iFail = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}

	//get current logged in user    	
	iFail = POM_get_user (&pcUserName, &tUser);
	if(iFail == ITK_ok && (msg.task != NULLTAG) )
	{
		iFail = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iFail == ITK_ok && tTaskType != NULLTAG)
	{
		iFail = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}	

	iNumArgs = TC_number_of_arguments(msg.arguments); 
	if(iNumArgs>0)
	{
		for(iArg = 0; (iArg < iNumArgs) && (iFail==ITK_ok) ; iArg++)
		{
			iFail = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue);
			if(iFail == ITK_ok)
			{					
				if( tc_strcasecmp(pcFlag, "target") == 0 && pcValue != NULL)
				{
					pcTarget = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTarget, pcValue);
				}
				else if( tc_strcasecmp(pcFlag, "folder") == 0) 
				{
					if(pcValue != NULL)
					{
						pcRelation = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
						tc_strcpy( pcRelation, pcValue);
					}
					else
					{
						iFail = EPM_invalid_argument_value;
					}
				}
				else if( tc_strcasecmp(pcFlag, "task_name") == 0 && pcValue != NULL)
				{
					pcName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcName, pcValue);
				}
			}
		}
	}

	else
	{
		iFail = EPM_invalid_argument;
	}

	//get the targeted change revision
	if (iFail == ITK_ok )
		iFail = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
	if (iFail == ITK_ok && tEngChangeRev != NULLTAG)
	{
		if(pcRelation == NULL || tc_strlen(pcRelation) == 0)
		{
			//get the content from the Affected and solution item folder
			pcRelation = (char *)MEM_alloc(65);
			tc_strcpy(pcRelation,"affected_items,solution_items");
		}
		//tc_strcpy(pcRelation,"CMHasImpactedItem,CMHasSolutionItem");

		if(pcRelation != NULL)
		{				
			pcRelationNames = (char **)malloc(10* sizeof(char *));			
			pcTemp = tc_strtok (pcRelation,",");
			while(pcTemp != NULL && iFail == ITK_ok)
			{
				//validate the input argument value				
				iFail = AOM_ask_descriptor (tEngChangeRev,pcTemp,&tRelation);
				if(iFail == ITK_ok && tRelation != NULLTAG)
				{
					pcRelationNames[iRelNameCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);
					tc_strcpy(pcRelationNames[iRelNameCount],pcTemp);			
					iRelNameCount++;					
					pcTemp = tc_strtok(NULL,",");
				}
				else
				{
					iFail = EPM_invalid_argument_value;
					TI_sprintf(acErrorString, "Invalid value parsed \"%s\".",pcRelation);
					EMH_store_error_s1( EMH_severity_error, iFail, acErrorString) ;						
					TC_write_syslog(acErrorString);
					decision = EPM_nogo;
					break;
				}
			}
		}

		//get targeted change revision CAP form "Poducted impacted" and "target status" values
		if( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
		{
			iFail = tiauto_get_Form_attribute_value_of_ItemRev(tEngChangeRev,"T8_TI_CAP","t8_t1a120isproductimacted", caPrdImpValue);
		}
		else if( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
		{
			//iFail = tiauto_get_Form_attribute_value_of_ItemRev(tEngChangeRev,"T8_TI_CAP2","t8_t1a190isproductimacted", caPrdImpValue);
			if(pcName == NULL)
			{
				tc_strcpy(pcName,"19_70 Feasibility Study - Application Engineer");
			}
	
			iFail = EPM_ask_sub_tasks(tRootTask,&iAllTasks,&ptAllTaskTags);
			for(iLoopAllTasks =0 ; iLoopAllTasks < iAllTasks; iLoopAllTasks++)
			{				
				iFail = EPM_ask_name2(ptAllTaskTags[iLoopAllTasks],&pcTaskName);
				
				if((tc_strcmp(pcTaskName,pcName)==0) && iFail == ITK_ok)
				{
					iFail = EPM_get_task_result	(ptAllTaskTags[iLoopAllTasks],&pcTaskResult);
					break;
				}
			}
		}
		else if ( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
		{
			if(pcName == NULL)
			{
				tc_strcpy(pcName,"28_140 Content Creation - Application Engineer");
			}
	
			iFail = EPM_ask_sub_tasks(tRootTask,&iAllTasks,&ptAllTaskTags);
			for(iLoopAllTasks =0 ; iLoopAllTasks < iAllTasks; iLoopAllTasks++)
			{				
				iFail = EPM_ask_name2(ptAllTaskTags[iLoopAllTasks],&pcTaskName);
				
				if((tc_strcmp(pcTaskName,pcName)==0) && iFail == ITK_ok)
				{
					iFail = EPM_get_task_result	(ptAllTaskTags[iLoopAllTasks],&pcTaskResult);
					break;
				}
			}
		}
		if(iFail == ITK_ok && ( ((!tc_strcmp(caPrdImpValue,"No")) && ( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 ))  ||
			                    (( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )) ))
		{
			if( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 )
			{
				iFail = tiauto_get_Form_attribute_value_of_ItemRev(tEngChangeRev,"T8_TI_CAP","t8_t1a120targetreleasestate", caTarRelValue);
			}
			else if( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 )
			{
				iFail = tiauto_get_Form_attribute_value_of_ItemRev(tEngChangeRev,"T8_TI_CAP2","t8_t1a190targetreleasestate", caTarRelValue);
			}
			else if( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 )
			{
				iFail = tiauto_get_Form_attribute_value_of_ItemRev(tEngChangeRev,"T8_TI_CAP3","t8_t1a190targetreleasestate", caTarRelValue);
			}
			//get all the objects present in affected_items and solution_items pseudo folders of the targeted change revision based on relation
			for(iAttchCntr = 0; (iAttchCntr < iRelNameCount) && (iFail == ITK_ok); iAttchCntr++)
			{
				tRelation = NULLTAG;
				iNumAffected = 0;
				
				if(iFail == ITK_ok)
				{
					//iFail = PROPDESC_ask_display_name_by_name  (pcRelationNames[iAttchCntr],&pcPseudoFolderName);
					tDescriptor = NULLTAG;
					iFail = AOM_ask_descriptor (tEngChangeRev,pcRelationNames[iAttchCntr],&tDescriptor);
					if(tDescriptor != NULLTAG)
					{
						iFail = PROPDESC_ask_display_name  (tDescriptor,&pcPseudoFolderName);
					}

				}
				if( iFail == ITK_ok) 
				{
					char    pszObjType[WSO_name_size_c+1]="";
					iFail = WSOM_ask_object_type(tEngChangeRev, pszObjType);

					if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
					{
						tag_t tRelTemp = NULLTAG;
						iFail = GRM_find_relation_type (pcRelationNames[iAttchCntr],&tRelTemp);
						if(iFail == ITK_ok && tRelTemp!=NULLTAG)
						{
							iFail = GRM_list_secondary_objects_only(tEngChangeRev,tRelTemp,&iNumAffected,&ptAffectedObjects);
						}
					}
					else
						iFail = ECM_get_contents  (tEngChangeRev,pcRelationNames[iAttchCntr],&iNumAffected, &ptAffectedObjects);
				}
				if(iFail == ITK_ok && iNumAffected > 0)
				{
					iFail = Validate_Targeted_Object_Status(caTarRelValue,iNumAffected,ptAffectedObjects,pcPseudoFolderName,&lValidationFailed,&pstCurrErrMsg);
				}
				SAFE_MEM_free(ptAffectedObjects);
				SAFE_MEM_free(pcPseudoFolderName);
			}	
		}
	}
	if(pcRelation != NULL)
	{
		SAFE_MEM_free(pcRelation);
	}
	if(pcRelationNames != NULL)
	{
		free(pcRelationNames);
		pcRelation = NULL;
	}

	if( iFail != ITK_ok && iFail != EPM_invalid_argument_value)
	{
		decision = EPM_nogo;
		EMH_ask_error_text(iFail, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iFail,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
	}

	//if the validation is failed 
	if( iFail == ITK_ok && lValidationFailed == true)
	{
		decision = EPM_nogo;	
		iFail = TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR;
		TI_sprintf( acErrorString, "To fix this problem, Please remove said item revision from the specified folder of the Change Revision before completing the task. ");//\n Affected or solution folder should not contain non-document item revisions of status not equal to target released status.
		EMH_store_error_s1(EMH_severity_error, TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR, acErrorString );
		tempErrMsg = pstCurrErrMsg;
		while(tempErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, tempErrMsg->iRetCode, tempErrMsg->errMsg);
			TC_write_syslog(tempErrMsg->errMsg);
			TC_write_syslog("\n");         	
         	tempErrMsg = tempErrMsg->next;
		}
	}
	
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);
	SAFE_MEM_free (pcTaskName);
	SAFE_MEM_free (pcName);
	return decision;
}
//-----------------------------------------------------------------------------------------------------
// This method checks whether any objects present in Change revision pseudo folder are statused other than
// "target status" except document IR's that are released, then error message will be displayed
//-----------------------------------------------------------------------------------------------------
int Validate_Targeted_Object_Status (	char		caTarRelValue[],			/*<I>*/
										int		    iNumAffected,				/*<I>*/
										tag_t	    *ptAffectedObjects,			/*<I>*/
										char		*pcFolderName,				/*<I>*/
										logical	    *lValidationFailed,			/*<O>*/
										TIA_ErrorMessage **pstCurrErrMsg )		/*<O>*/
{
	int		iFail = ITK_ok;
	int		iAffCntr = 0;

	char	*pcClassName = NULL;
	tag_t	tObjectType = NULL_TAG;	
	tag_t	tParentType = NULL_TAG;
	char	acTypeName[TCTYPE_name_size_c+1] = "";

	
	tag_t	tItem = NULL_TAG;			
	char	acItemId[ITEM_id_size_c+1]	= "";
	char	acRevId[ITEM_id_size_c+1]	= "";
	int		iStCount	= 0;
	tag_t	*atChildStatus = NULL_TAG;
	char    *pcChildRelSts = NULL;
	char	acErrorString[512]	= "";

	for (iAffCntr = 0; (iAffCntr < iNumAffected) && (iFail == ITK_ok) ; iAffCntr++)
	{
		//get the classname of the object
		if (iFail == ITK_ok && ptAffectedObjects[iAffCntr] != NULLTAG )
			iFail = tiauto_get_class_name_of_instance (ptAffectedObjects[iAffCntr], &pcClassName);
		//check if the classname of the targeted object pseudo folder is ItemRevision
		if((iFail == ITK_ok)  && (tc_strcasecmp (pcClassName , "ItemRevision")== 0) )
		{
			// get item tag
			iFail = ITEM_ask_item_of_rev(ptAffectedObjects[iAffCntr], &tItem);
			// get item id string 
			if(iFail == ITK_ok && tItem != NULLTAG)
				iFail = ITEM_ask_id(tItem, acItemId);
			// get item rev id string 
			if( iFail == ITK_ok)
				iFail = ITEM_ask_rev_id(ptAffectedObjects[iAffCntr],acRevId );
			iStCount=0;
			iFail = WSOM_ask_release_status_list(ptAffectedObjects[iAffCntr],&iStCount,&atChildStatus);
			if(iFail == ITK_ok && iStCount>0)
			{
				// get item revision type
				if( iFail == ITK_ok)
					iFail = TCTYPE_ask_object_type(ptAffectedObjects[iAffCntr], &tObjectType);
				if( iFail == ITK_ok)
					iFail = TCTYPE_ask_parent_type(tObjectType, &tParentType); 
				if( iFail == ITK_ok)
					iFail = TCTYPE_ask_name(tParentType, acTypeName);
				if(iFail == ITK_ok)
					iFail = AOM_ask_name(atChildStatus[0],&pcChildRelSts);
				if(iFail == ITK_ok)
				{
					if(tc_strcmp(acTypeName,DOCUMENT_REV))
					{
						if(tc_strcmp(pcChildRelSts,caTarRelValue))
						{
							//error if status not matching to Eng Change target status
							TI_sprintf(acErrorString, "Error: The item revision \"%s\\%s\" with status \"%s\" present in the \"%s\" folder is invalid.",acItemId,acRevId,pcChildRelSts,pcFolderName);
							printf("\n%s",acErrorString);
							tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR, acErrorString);
							*lValidationFailed=true;
						}
					}
					else
					{
						/*if(tc_strcmp(pcChildRelSts,"Document Released"))//Document Released or same as target status
						{
							//error if document IR is not status as released
							TI_sprintf(acErrorString, "Error: The item revision \"%s\\%s\" with status \"%s\" present in the \"%s\" folder is invalid.",acItemId,acRevId,pcChildRelSts,pcFolderName);
							printf("\n%s",acErrorString);
							tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR, acErrorString);
							*lValidationFailed=true;
						}*/
					}
				}
			}
			else
			{
				//error if non statused IR's exists
				TI_sprintf(acErrorString, "Error: The item revision \"%s\\%s\" with no status present in the \"%s\" folder is invalid.",acItemId,acRevId,pcFolderName);
				tiauto_writeErrorMsgToStack(pstCurrErrMsg, TIAUTO_NOT_VALID_AFFECTED_SOLUTION_FOLDERS_IR_ERROR, acErrorString);
				*lValidationFailed=true;
			}
		}
	}
	return iFail;
}