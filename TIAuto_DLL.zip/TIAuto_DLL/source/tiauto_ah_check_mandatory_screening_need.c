/*******************************************************************************
File         : t1aAUTO_ah_check_mandatory_screening_need.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date			  Revision		Who              Description
*******************************************************************************
10th Jun, 2016	  1.0           Pradeep          Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

double getActualCost (double dTotalCash, char* pcTempCurrencyType);
int getCCRForm (tag_t tTempRootTask, const char* CCRFormTypeName, tag_t* tTempCCRForm);
int getSecondaryObject (tag_t tPrimary, const char* cRelation, const char* cSecObjectType, tag_t* tSecObj);
int getMaxAllowedCashFromPref ();

extern int t1aAUTO_ah_check_mandatory_screening_need(EPM_action_message_t msg)
{
	int				iRetCode									= ITK_ok;
	int				iMaxAllowedTotalCashInvestment				= 0;
	double          dTotalCashInvestment						= 0;
	double          dActualTotalCashInvestment					= 0;
	tag_t           tCurrentTask								= NULLTAG;
	tag_t           tRootTask									= NULLTAG; 
	tag_t			tNewCCRForm									= NULLTAG;
	char*			pcCurrencyType								= NULL;
	char*			pcRootTaskName									= NULL;

	tCurrentTask = msg.task;
	iRetCode = EPM_ask_root_task (tCurrentTask, &tRootTask);
	
	if (iRetCode == 0 && tRootTask != NULLTAG)
	{
		iRetCode = AOM_ask_name(tRootTask,&pcRootTaskName);
		//adding CAP3 changes
		if(tc_strcmp(pcRootTaskName,"CAP - Change Approval Process") == 0 || tc_strcmp(pcRootTaskName,"19_00 CAP - Change Approval Process") == 0)
		{
			iRetCode = getCCRForm (tRootTask, NEWCCR_FORM, &tNewCCRForm);
			if (iRetCode == 0 && tNewCCRForm != NULLTAG)
			{
				iRetCode = AOM_ask_value_double (tNewCCRForm, "t8_t1a191totalcashinvestmen", &dTotalCashInvestment);
				if (iRetCode == ITK_ok && dTotalCashInvestment != 0)
				{
					iRetCode = AOM_ask_value_string (tNewCCRForm, "t8_t1a191currency", &pcCurrencyType);
					if (iRetCode == ITK_ok && pcCurrencyType != NULL)
					{
						dActualTotalCashInvestment = getActualCost (dTotalCashInvestment, pcCurrencyType);
					}
				}		
			}
		}
		else if(tc_strcmp(pcRootTaskName,"PMR - Program Mgmt Release") == 0 || tc_strcmp(pcRootTaskName,"22_00 PMR - Program Mgmt Release") == 0)
		{
			iRetCode = getCCRForm (tRootTask, "T8_TI_PMR", &tNewCCRForm);
			if (iRetCode == 0 && tNewCCRForm != NULLTAG)
			{
				iRetCode = AOM_ask_value_double (tNewCCRForm, "t8_193totalcashinvestmen", &dTotalCashInvestment);
				if (iRetCode == ITK_ok && dTotalCashInvestment != 0)
				{
					iRetCode = AOM_ask_value_string (tNewCCRForm, "t8_193currency", &pcCurrencyType);
					if (iRetCode == ITK_ok && pcCurrencyType != NULL)
					{
						dActualTotalCashInvestment = getActualCost (dTotalCashInvestment, pcCurrencyType);
					}
				}		
			}
		}

		
	}
	iMaxAllowedTotalCashInvestment = getMaxAllowedCashFromPref ();

	if (iRetCode == ITK_ok && dActualTotalCashInvestment != 0 && iMaxAllowedTotalCashInvestment != 0)
	{
		if (dTotalCashInvestment >= iMaxAllowedTotalCashInvestment)
			iRetCode = EPM_set_condition_task_result(msg.task,EPM_RESULT_TRUE);
		else
			iRetCode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
	}
	if (iRetCode == ITK_ok && (dActualTotalCashInvestment == 0 || iMaxAllowedTotalCashInvestment == 0))
	{
		iRetCode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
	}
	

	return iRetCode;  
}
//***************************************************************************************************
// getActualCost
//***************************************************************************************************
double getActualCost (double dTotalCash, char* pcTempCurrencyType)
{
	int			iRetCode								= ITK_ok;
	int			i										= 0;
	int			j										= 0;
	int         iCurrencyItems							= 0;
	int         iProps									= 0;
	double      dActualCost								= 0;
	double      dConversionValueInUSD					= 0;
	tag_t		tCurrencyRev							= NULLTAG;
	tag_t		tCurrencyRevMF							= NULLTAG;
	tag_t		tDescriptor								= NULLTAG;
	tag_t*		ptCurrencyItems							= NULL;
	char        acObjectType[WSO_name_size_c+1]			= "";
	char*		pcDisplayName							= NULL; 
	char**		pcProps									= NULL;
	char*		pcRet									= NULL;

	iRetCode = WSOM_find ("Currency", &iCurrencyItems, &ptCurrencyItems);
	if (iRetCode == ITK_ok && iCurrencyItems>0)
	{
		for (i;i<iCurrencyItems;i++)
		{
			iRetCode = WSOM_ask_object_type (ptCurrencyItems[i], acObjectType);
			if (iRetCode == ITK_ok && (tc_strcmp(acObjectType, "TI_Currency") == 0))
			{
				iRetCode = ITEM_ask_latest_rev (ptCurrencyItems[i], &tCurrencyRev);
				if (iRetCode == ITK_ok && tCurrencyRev != NULLTAG)
				{
					iRetCode = getSecondaryObject (tCurrencyRev, "IMAN_master_form", "TI_Currency Revision Master", &tCurrencyRevMF);
					if (iRetCode == ITK_ok && tCurrencyRevMF != NULLTAG)
					{
						iRetCode = AOM_ask_prop_names (tCurrencyRevMF, &iProps, &pcProps);
						if (iRetCode == ITK_ok && iProps>0)
						{
							for (j;j<iProps;j++)
							{
								tDescriptor = NULLTAG;
								iRetCode = AOM_ask_descriptor (tCurrencyRevMF,pcProps[j],&tDescriptor);
								if(tDescriptor != NULLTAG)
									iRetCode = PROPDESC_ask_display_name  (tDescriptor,&pcDisplayName);

								//iRetCode = PROPDESC_ask_display_name_by_name (pcProps[j], &pcDisplayName);
								if (iRetCode == ITK_ok && tc_strcmp(pcTempCurrencyType,pcDisplayName) == 0)
								{
									pcRet = tc_strstr(pcProps[j], "t1a5e");
									if (pcRet != NULL)
									{
										iRetCode = AOM_ask_value_double (tCurrencyRevMF, pcProps[j], &dConversionValueInUSD);
										if (iRetCode == ITK_ok)
											break;
									}
								}
								SAFE_MEM_free(pcDisplayName);
							}
						}
						SAFE_MEM_free(pcProps);
					}
				}
			}
		}
	}
	if (iRetCode == ITK_ok && dConversionValueInUSD != 0)
	{
		dActualCost = dTotalCash/dConversionValueInUSD;
	}
	SAFE_MEM_free(ptCurrencyItems);

	return dActualCost;
}
//***************************************************************************************************
// getCCRForm
//***************************************************************************************************
int getCCRForm (tag_t tTempRootTask, const char* CCRFormTypeName, tag_t* tTempCCRForm)
{
	int				iRetCode									= ITK_ok;
	int				i											= 0;
	int             iTargetAttachments							= 0;
	tag_t			tNewCCRForm									= NULLTAG;
	tag_t*          ptTargetAttachments							= NULL;
	char			acObjectType[WSO_name_size_c+1]				= ""; 

	iRetCode = EPM_ask_attachments (tTempRootTask, EPM_target_attachment, &iTargetAttachments, &ptTargetAttachments);
	if (iRetCode == 0 && iTargetAttachments>0)
	{
		for (i; i<iTargetAttachments; i++)
		{
			iRetCode = WSOM_ask_object_type (ptTargetAttachments[i], acObjectType);
			if (iRetCode == ITK_ok && tc_strcmp(acObjectType, NEWCHANGE_REV) == 0 )
			{
				iRetCode = getSecondaryObject (ptTargetAttachments[i], "IMAN_specification", CCRFormTypeName, &tNewCCRForm);
				if (iRetCode == ITK_ok && tNewCCRForm != NULLTAG)
				{
					*tTempCCRForm = tNewCCRForm;
					break;
				}
			}
		}
	}
	SAFE_MEM_free(ptTargetAttachments);

	return iRetCode;
}
//***************************************************************************************************
// getSecondaryObject
//***************************************************************************************************
int getSecondaryObject (tag_t tPrimary, const char* cRelation, const char* cSecObjectType, tag_t* tSecObj)
{
	int iRetCode = ITK_ok;
	int i = 0;
	int iSecObjs = 0;
	tag_t tRelationType = NULLTAG;
	tag_t* ptSecObjs = NULL;
	char			acObjectType[WSO_name_size_c+1] = "";  

	iRetCode = GRM_find_relation_type (cRelation, &tRelationType);

	if (iRetCode == ITK_ok && tRelationType != NULLTAG)
		iRetCode =  GRM_list_secondary_objects_only (tPrimary , tRelationType, &iSecObjs, &ptSecObjs);

	if (iRetCode == ITK_ok && iSecObjs>0)
	{
		for (i; i<iSecObjs; i++)
		{
			iRetCode = WSOM_ask_object_type (ptSecObjs[i], acObjectType);
			if (iRetCode == ITK_ok && (tc_strcmp(acObjectType, cSecObjectType) == 0))
			{
				*tSecObj = ptSecObjs[i];
				break;
			}
		}
	}
	SAFE_MEM_free(ptSecObjs);

	return iRetCode;
}
//***************************************************************************************************
// getMaxAllowedCashFromPref
//***************************************************************************************************
int getMaxAllowedCashFromPref ()
{
	int			iRetCode								= ITK_ok;
	int			iPrefCount								= 0;
	int			iPrefValues								= 0;
	int			iMaxAllowedCash							= 0;
	int*		piPrefValues							= 0;

	TC_preference_search_scope_t OldScope;

	iRetCode = PREF_initialize();

	if (iRetCode == ITK_ok)
		iRetCode = PREF_ask_search_scope(&OldScope);

    if (iRetCode == ITK_ok)
        iRetCode = PREF_set_search_scope( TC_preference_site );

    if (iRetCode == ITK_ok)
        iRetCode = PREF_ask_value_count( "TI_send_mandatory_screening_notification", &iPrefCount );

    if (iRetCode == ITK_ok && iPrefCount != 0)
        iRetCode = PREF_ask_int_values ("TI_send_mandatory_screening_notification", &iPrefValues, &piPrefValues);

	if (iRetCode == ITK_ok && iPrefValues>0)
	{
		if (iPrefValues == 1)
			iMaxAllowedCash = piPrefValues[0];
	}
	iRetCode = PREF_set_search_scope(OldScope);

	SAFE_MEM_free(piPrefValues);

	return iMaxAllowedCash;
}


