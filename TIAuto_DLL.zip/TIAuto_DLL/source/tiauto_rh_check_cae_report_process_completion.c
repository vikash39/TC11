
/*******************************************************************************
FILE        :   tiauto_rh_check_cae_report_process_completion.c
Details     :   

REVISION HISTORY :

Date              Revision        Who						Description
Apr  3, 2014     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_caereport_dataset_creation(EPM_rule_message_t msg )
{
    int iFail				= ITK_ok;
	int iCAEResSecCount		= 0;
	int iCAEReqSecObjCount			= 0;
	int iNumAttachments			= 0;
	int indx				= 0;
	int iCount				= 0;

	
	boolean bCAEReportCreated		= true;

	char *pcErrMsg										= NULL;
	char acObjectType[WSO_name_size_c+1]				= "";	
	char acObjectName[WSO_name_size_c+1]				= "";
	char acErrorString[TIAUTO_error_message_len+1]		= "";
	char  acItemId[ITEM_id_size_c+1]  = "";
	char  acRevId[ITEM_id_size_c+1]  = "";	
	char  acItemRevId[ITEM_id_size_c+ITEM_id_size_c+1]  = "";
	
	tag_t			tCAEReqRev								= NULLTAG;
	tag_t			tRootTask								= NULLTAG;
	tag_t			*ptAttachments						= NULL;

	tag_t tRelationType		= NULLTAG;
	tag_t tCAEResItem = NULLTAG;
	tag_t *ptCAEReqSecObjs	= NULL;
	tag_t *ptCAEResSecObj			= NULL;

	EPM_decision_t decision = EPM_go;
	
	//if there are any ITK failure
	if ( iFail != ITK_ok && iFail != EPM_invalid_argument_value)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iFail, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iFail, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}

	iFail = EPM_ask_root_task(msg.task , &tRootTask);
    if (iFail == ITK_ok)
        iFail = EPM_ask_attachments(tRootTask, EPM_target_attachment,&iNumAttachments, &ptAttachments);

    for (indx = 0; indx < iNumAttachments && (iFail == ITK_ok); indx++)
    {
        iFail = WSOM_ask_object_type(ptAttachments[indx], acObjectType);
       
        if (iFail == ITK_ok && tc_strcmp (acObjectType, "T8_T_CAERequest Revision") == 0 )
        {
            tCAEReqRev = ptAttachments[indx];
            break; 
        }
    }

	if (iFail == ITK_ok && tCAEReqRev != NULLTAG )
	{	
		iFail = GRM_find_relation_type("T8_TI_CAERequestRevisions", &tRelationType);
		if(tRelationType != NULLTAG)
			iFail = GRM_list_secondary_objects_only(tCAEReqRev,tRelationType,&iCAEReqSecObjCount,&ptCAEReqSecObjs); 
		//verify in Ref. folder
		for (iCount = 0; iCount < iCAEReqSecObjCount && (iFail == ITK_ok); iCount++)
		{
			tc_strcpy(acObjectType,"");
			/* get the object type */
			iFail = WSOM_ask_object_type (ptCAEReqSecObjs[iCount], acObjectType);
			if(tc_strcmp(acObjectType,"T8_TI_CAE_ResultRevision") == 0)
			{
				tCAEResItem = NULLTAG;
				iFail = ITEM_ask_item_of_rev  (ptCAEReqSecObjs[iCount],&tCAEResItem);

				iFail = ITEM_ask_id (tCAEResItem,acItemId);
				iFail = ITEM_ask_rev_id (ptCAEReqSecObjs[iCount],acRevId);
				tc_strcpy(acItemRevId,acItemId);
				tc_strcat(acItemRevId,"_");
				tc_strcat(acItemRevId,acRevId);

				
				tRelationType = NULLTAG;
				iFail = GRM_find_relation_type("IMAN_specification", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptCAEReqSecObjs[iCount],tRelationType,&iCAEResSecCount,&ptCAEResSecObj); 
				if(iCAEResSecCount == 0)
				{
					bCAEReportCreated = false;
					break;
				}
				for(indx =0; indx < iCAEResSecCount; indx++)
				{
					tc_strcpy(acObjectType,"");
					iFail = WSOM_ask_object_type (ptCAEResSecObj[indx], acObjectType);
					if(tc_strcmp(acObjectType,"MSWordX") == 0)
					{
						iFail = WSOM_ask_name (ptCAEResSecObj[indx],acObjectName);
						if(tc_strcmp(acItemRevId,acObjectName) == 0)
						{
							break;
						}
						else
						{
							bCAEReportCreated = false;
						}
					}
				}
				SAFE_MEM_free(ptCAEResSecObj);
				if(bCAEReportCreated == false)
				{
					break;
				}
			}
		}
	}
	if(bCAEReportCreated == false)
	{
		iFail = TIAUTO_CAE_REPORT_CREATION_PROCESS_NOT_COMPLETED;
		decision = EPM_nogo;
		TI_sprintf(acErrorString, "The CAE Report dataset creation is currently in progress. This workflow task cannot be completed until the dataset creation process is finished. An email notification will be sent when this process is complete.");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_CAE_REPORT_CREATION_PROCESS_NOT_COMPLETED, acErrorString) ;						
		TC_write_syslog(acErrorString);
	}

	SAFE_MEM_free(ptCAEReqSecObjs);
	SAFE_MEM_free(ptAttachments);

	return decision;
}
