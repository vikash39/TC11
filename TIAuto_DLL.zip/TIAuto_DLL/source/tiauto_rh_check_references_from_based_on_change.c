
/*******************************************************************************
FILE        :   tiauto_rh_check_targets_from_based_on_change.c
Details     :   This is a dummy rule handler. This is used to check whether a
				perticular task is assigned to user that matches with the role
				and group name mentioned in the handler argument during apply
				assignment

REVISION HISTORY :

Date              Revision        Who						Description
Sept  2, 2011     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_references_from_based_on_change(EPM_rule_message_t msg )
{
    int			iRetCode							= ITK_ok;
	int			iSecObjCount						= 0;
	int			iBasedOnSecObjCount					= 0;
	int			iLoopBasedOnSecObj					= 0;
	int			iChangeRevCnt						= 0;
	int			iLoopSecObj							= 0;
	tag_t		tRootTaskTag						= NULLTAG;
	tag_t		tEngChangeRev						= NULLTAG;
	tag_t		*ptEngChangeBasedOnRev				= NULLTAG;
	tag_t		*ptSecObjTags						= NULL;
	tag_t		*ptBasedOnSecObjTags				= NULL;
	tag_t		tRelationType						= NULLTAG;
	char		*pcChangeBasedOnItemName			= NULL;
	char		*pcSolnItemName						= NULL;
	logical		IsSolnItemExist						= false;
	char		    *pszClassName								= NULL;

	EPM_decision_t decision = EPM_go;

	iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);

	iRetCode = tiauto_get_change_item_rev(msg.task, &tEngChangeRev);
	if(tEngChangeRev != NULLTAG)
	{
		tRelationType = NULLTAG;
		iRetCode = GRM_find_relation_type("CMReferences", &tRelationType);
		if(tRelationType != NULLTAG)
			iRetCode = GRM_list_secondary_objects_only(tEngChangeRev,tRelationType,&iSecObjCount,&ptSecObjTags);
	}

	if(tEngChangeRev != NULLTAG)
		iRetCode = AOM_ask_value_tags(tEngChangeRev,Rel_Change_ObjectRev,&iChangeRevCnt,&ptEngChangeBasedOnRev);

	if(iChangeRevCnt > 0 && ptEngChangeBasedOnRev[iChangeRevCnt-1] != NULLTAG)
		iRetCode = ECM_get_affected_items(ptEngChangeBasedOnRev[iChangeRevCnt-1],&iBasedOnSecObjCount,&ptBasedOnSecObjTags);

	if(iChangeRevCnt > 0 && ptEngChangeBasedOnRev[iChangeRevCnt-1] != NULLTAG)
		iRetCode =  tiauto_get_itemrev_name(ptEngChangeBasedOnRev[iChangeRevCnt-1],&pcChangeBasedOnItemName);

	for(iLoopSecObj = 0; iLoopSecObj < iSecObjCount; iLoopSecObj++)
	{	
		logical		lIsBasedOnSolnItemDoc			= false;

		IsSolnItemExist = false;
		iRetCode = tiauto_get_class_name_of_instance (ptSecObjTags[iLoopSecObj], &pszClassName);
		if( (iRetCode == ITK_ok) && (tc_strcasecmp (pszClassName , "ItemRevision")== 0 ) )
		{
		}
		else
			continue;

		for(iLoopBasedOnSecObj = 0; iLoopBasedOnSecObj < iBasedOnSecObjCount; iLoopBasedOnSecObj++)
		{
			iRetCode = tiauto_check_if_itemType_isDOC(ptBasedOnSecObjTags[iLoopBasedOnSecObj],&lIsBasedOnSolnItemDoc);
			if(lIsBasedOnSolnItemDoc== false && (iRetCode == ITK_ok))
			{			
				if((ptSecObjTags[iLoopSecObj] == ptBasedOnSecObjTags[iLoopBasedOnSecObj])  && (iRetCode == ITK_ok))
				{					
					IsSolnItemExist = true;
					break;									
				}
				else
				{					
					IsSolnItemExist = false;
				}
			}
		}
					
		if((IsSolnItemExist == false) && (iRetCode == ITK_ok))
		{
			iRetCode =  tiauto_get_itemrev_name(ptSecObjTags[iLoopSecObj],&pcSolnItemName);
			decision= EPM_nogo;
			EMH_store_error_s2( EMH_severity_error,TIAUTO_NOT_IN_BASEDON_CHANGE_REV,pcSolnItemName,pcChangeBasedOnItemName);

		}
			
		
				
	}
	
	if( iRetCode != ITK_ok )
	{
		char	*pcErrMsg		= NULL;
		decision = EPM_nogo;
		EMH_ask_error_text(iRetCode, &pcErrMsg );
		EMH_store_error_s1(EMH_severity_error,iRetCode,pcErrMsg);
		SAFE_MEM_free (pcErrMsg);
		
	}

	SAFE_MEM_free(ptEngChangeBasedOnRev);
	SAFE_MEM_free(ptSecObjTags);
	SAFE_MEM_free(ptBasedOnSecObjTags);
	SAFE_MEM_free(pcChangeBasedOnItemName);
	SAFE_MEM_free(pcSolnItemName);

	return decision;
}
