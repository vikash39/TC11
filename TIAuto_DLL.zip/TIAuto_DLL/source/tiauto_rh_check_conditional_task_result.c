
/*******************************************************************************
FILE        :   tiauto_rh_check_conditional_task_result.c
Details     :   This is used to check whether a the selected conditional task
				option statisfies the dependant form attribute value i.e. to
				check whether the to be demoted task is completed or not.
 
REVISION HISTORY :

Date              Revision        Who						Description
Sept  5, 2011     1.0			  Dipak Naik				Initial Creation.
May	  30,2016	  1.1			  Shilpa R					Added code to handle No Response option in the conditional task

*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_conditional_task_result
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_conditional_task_result(EPM_rule_message_t msg )
{
    int		iRetCode		= ITK_ok;
	int		iNumArgs		= 0;
	int		i				= 0;
	
	char	*pcArgName								= NULL;
	char    *pcDemotedTaskName                      = NULL;
	char    *pcTaskResult	                        = NULL;
	char	*pcArgValue								= NULL;
	char	*pcErrMsg								= NULL;
	char	*pcInputErrorMessage					= NULL;
	char    *pcTaskTypeName                         = NULL;
	char    *pcResult								= NULL;
	char	*pcUserName								= NULL;
	char acUserGroup[SA_name_size_c+1] = {'\0'};

	tag_t	tTaskType		= NULLTAG;
	tag_t	tRootTaskTag	= NULLTAG;
	tag_t	tSubTask		= NULLTAG;
	tag_t	tUser			= NULLTAG;
	tag_t current_groupmember_tag = NULLTAG;
	tag_t group_tag = NULLTAG;

	EPM_state_t State ;
	EPM_decision_t decision = EPM_nogo;

	iRetCode = POM_get_user (&pcUserName, &tUser);
	
	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_current_groupmember(&current_groupmember_tag);

	
	if(iRetCode == ITK_ok && current_groupmember_tag != NULLTAG)
		iRetCode = SA_ask_groupmember_group(current_groupmember_tag, &group_tag);

	if(iRetCode == ITK_ok && group_tag != NULLTAG)
	    iRetCode = SA_ask_group_name(group_tag, acUserGroup);

	if(tc_strcmp(acUserGroup,"dba") == 0)
	{
		decision = EPM_go;
		return decision;
	}

	iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
						
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}

	if( (iRetCode == ITK_ok) && (pcTaskTypeName != NULL) && (tc_strcmp(pcTaskTypeName,"EPMConditionTask") != 0) )
	{
		decision = EPM_go;
		return decision;
	}
	//get no. of arguments
	iNumArgs = TC_number_of_arguments(msg.arguments);
	
	if(iNumArgs >= 2 && iNumArgs < 4)
	{
		for( i = 0;i < iNumArgs;i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if( ( iRetCode == ITK_ok ) && (pcArgName != NULL) && (pcArgValue != NULL) )
			{
			   
				if(tc_strcasecmp(pcArgName, "demoted_task") == 0)
				{
				    //get the task name.
			        pcDemotedTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
                    tc_strcpy( pcDemotedTaskName, pcArgValue);
					
				}
				else if(tc_strcasecmp(pcArgName, "result") == 0)
				{
				    //conditional task result.
			        pcTaskResult = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
                    tc_strcpy( pcTaskResult, pcArgValue);
					
				}
				else if(tc_strcasecmp(pcArgName, "error_message") == 0)
				{
					//error message
					pcInputErrorMessage = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcInputErrorMessage, pcArgValue);
				}
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
			else
			{						
				iRetCode = EPM_invalid_argument;			
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	//check the mandatory argument check
	if(iRetCode == ITK_ok && ((pcInputErrorMessage == NULL)  || 
								(pcTaskResult == NULL)) )
	{
		iRetCode = EPM_invalid_argument_value;
	}
	if(iRetCode == ITK_ok)
	{
		iRetCode = EPM_get_task_result ( msg.task,&pcResult);
		if( iRetCode == ITK_ok && (tc_strcmp(pcResult,pcTaskResult) == 0) && pcDemotedTaskName!=NULL)
		{
			//Get the root task
			iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
			if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG && pcDemotedTaskName != NULL)
				iRetCode = EPM_ask_sub_task  (  tRootTaskTag, pcDemotedTaskName,&tSubTask);
			if(iRetCode == ITK_ok && tSubTask != NULLTAG)
				iRetCode = EPM_ask_state(tSubTask,&State);
			if(iRetCode == ITK_ok && State == EPM_completed)
			{
				decision = EPM_go;
			}
			
			else if(iRetCode == ITK_ok)
			{
				decision = EPM_nogo;
				//error
				TC_write_syslog(pcInputErrorMessage);
				EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_COND_OPTION, pcInputErrorMessage) ;
			}
		}
		else if( iRetCode == ITK_ok && (tc_strstr(pcResult,pcTaskResult)!= NULL) && pcDemotedTaskName==NULL)
		{
			decision = EPM_nogo;
			//error
			TC_write_syslog(pcInputErrorMessage);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_NOT_VALID_COND_OPTION, pcInputErrorMessage) ;
		}
		else
		{
			decision = EPM_go;
		}
	}

	if ( iRetCode != ITK_ok )
	{				
		decision = EPM_nogo;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}

	SAFE_MEM_free (pcInputErrorMessage);
	SAFE_MEM_free (pcDemotedTaskName);
	SAFE_MEM_free (pcTaskResult);
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcResult);

	return decision;
}
