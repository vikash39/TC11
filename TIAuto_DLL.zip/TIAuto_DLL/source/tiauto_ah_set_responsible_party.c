/*******************************************************************************
File         : tiauto_ah_set_responsible_party.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Jan 27, 2010    1.0        Dipak Naik      Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int t1aAUTO_set_responsible_party(EPM_action_message_t msg)
{
	int				iRetCode			= ITK_ok;
	int				iNumArgs			= 0;
	int             iAttachmentCnt      = 0;
	int             i                   = 0;
	int             j                   = 0;
	int             ilov_cnt            = 0;
	int             ilov_value_cnt      = 0;

	tag_t           tRootTaskTag        = NULLTAG;
	tag_t           tTypeTag            = NULLTAG;
	tag_t           tUser               = NULLTAG;
	tag_t           tSubTask            = NULLTAG;
	tag_t           *ptLov              = NULL;
	tag_t           *ptAttachments      = NULL;

	char		    *pcValue									= NULL;
    char		    *pcFlag										= NULL;
	char			*pcTaskName									= NULL;
	char			*pcErrMsg									= NULL;
	char            *pcResponsibleParty							= NULL;
	char            **pclov_values								= NULL;
    char            szErrorString[TIAUTO_error_message_len+1]	= "";       
	char            acObjType[TCTYPE_name_size_c+1]			= "";
    char			acUserNameFromForm[SA_user_size_c+1]		= "";  
	char			acUserNameFromLov[SA_name_size_c+1]         = "";
	
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 1)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if(iRetCode == ITK_ok )
			{
				if( tc_strcasecmp(pcFlag,"task_name") == 0 && pcValue != NULL)
				{
					pcTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
					tc_strcpy( pcTaskName, pcValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			
				if( iRetCode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-set-responsible-party\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
					
				}
			}
			else
			{
				TI_sprintf(szErrorString, "Failed to read Arguments provided to \"TIAUTO-AH-set-responsible-party\" handler.\n");
				TC_write_syslog(szErrorString);
				EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString) ;
				
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;       
    }

	if(iRetCode == ITK_ok && pcTaskName != NULL)
	{
		//get the tag of the root task
		iRetCode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetCode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetCode = EPM_ask_sub_task  (  tRootTaskTag, pcTaskName,&tSubTask);
		}		
		//Get the target attachment. This will consist of the DemandForSupplier Form
		if(iRetCode == ITK_ok)
		{
			iRetCode = EPM_ask_attachments(tRootTaskTag,EPM_target_attachment,&iAttachmentCnt,&ptAttachments);
		}
		if(iRetCode == ITK_ok && iAttachmentCnt > 0)
		{
			for(i = 0; i< iAttachmentCnt;i++)
			{
				iRetCode = TCTYPE_ask_object_type(ptAttachments[i],&tTypeTag);
				if(iRetCode == ITK_ok && tTypeTag != NULLTAG)
				{
					iRetCode = TCTYPE_ask_name(tTypeTag,acObjType);
				}
				if(iRetCode == ITK_ok && tc_strcmp(acObjType,"TI_SupplierRequest")==0)
				{
					iRetCode = AOM_ask_value_string(ptAttachments[i], "t1a80approver", &pcResponsibleParty);
					tc_strcpy(acUserNameFromForm,pcResponsibleParty);
					break;
				}				
			}
			if(iRetCode == ITK_ok && pcResponsibleParty != NULL)
			{
				iRetCode = LOV_find("User Ids",&ilov_cnt,&ptLov); 
				if(iRetCode == ITK_ok && ptLov != NULL)
				{
					iRetCode = LOV_ask_values_string(ptLov[0],&ilov_value_cnt,&pclov_values);
				}
				for (j = 0; j < ilov_value_cnt && iRetCode == ITK_ok; j ++)
				{
					iRetCode = SA_find_user (pclov_values[j],&tUser);
					if(iRetCode == ITK_ok && tUser!= NULLTAG)
						iRetCode = SA_ask_user_person_name (tUser,acUserNameFromLov);
					if(iRetCode == ITK_ok && tSubTask != NULLTAG && !tc_strcmp(acUserNameFromLov,acUserNameFromForm))
					{
						iRetCode = EPM_assign_responsible_party(tSubTask,tUser);
						break;
					}
				}
				for(i=0;i< ilov_value_cnt;i++)
				{
					SAFE_MEM_free(pclov_values[i]); 
				}
				SAFE_MEM_free(ptLov);
			}
		}
	}
	if ( iRetCode != ITK_ok )
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	
	SAFE_MEM_free(pcValue);
	SAFE_MEM_free(pcFlag);
	SAFE_MEM_free(pcTaskName);
    SAFE_MEM_free(ptAttachments);
    SAFE_MEM_free(pcResponsibleParty);	
	
	return iRetCode;  
}


