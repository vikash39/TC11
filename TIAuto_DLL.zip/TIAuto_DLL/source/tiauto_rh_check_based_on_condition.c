/*******************************************************************************
File         : tiauto_rh_check_based_on_condition.c

Description  : This rule handler validates the target change revision by executing 
               the given input query in the handler argument. If the query return true result, 
			   then the decision will be EPM_go and else the output will be EPM_nogo.			   
			   If the result of the query is false, then the error message will be
			   displayed to the user.
               
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who					Description
**************************************************************************************************************
Sept 09, 2010    1.0		Nivedita Kamath		Initial Creation
Jan  19, 2011	 1.1		Dipak Naik			Fixed the bug - for some cases
												the query was not working
Jan, 11, 2013	 1.2		Dipak Naik			Modified the logic to work for other target object type. Earlier
												it was working only for the EngChange revision object type
****************************************************************************************************************/

/* includes */

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_check_based_on_condition( EPM_rule_message_t msg )
{
	int		iRetCode		= ITK_ok;
	int		iNumArgs		= 0;
	int		i				= 0;
	int		iEnttryCnt		= 0;
	int		iResultCount	= 0;
	int     iQryCount       = 0;
	int     j               = 0;
	
	char	*pcArgName								= NULL;
	char    *pcQueryNameTemp                        = NULL;
	char	*pcArgValue								= NULL;
	char	*pcErrMsg								= NULL;
	char	*pcInputErrorMessage					= NULL;
	char	*pcTargetObjectType						= NULL;
	char	acChangeId[ITEM_id_size_c+1]			= {'\0'};
	char	acChangeRevId[ITEM_id_size_c+1]			= {'\0'};
	char	acChangeRevName[ITEM_name_size_c+1]		= {'\0'};
	char	**pcQueryName                           = NULL;
	char	**pcQentries							= NULL;
	char	**pcQvalues								= NULL;
	char	**pcUserEntryvalues						= NULL;
	char     *pcTemp                                = NULL;

	tag_t	tECRev = NULLTAG;
	tag_t	tQuery = NULLTAG;
	tag_t	*ptResults = NULL;

	logical lValidChangeRev = false;

	EPM_decision_t decision = EPM_nogo;
	
	iNumArgs = TC_number_of_arguments(msg.arguments);

	pcTargetObjectType = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetObjectType,"EngChange Revision");
	
	if( (iNumArgs == 2) || (iNumArgs == 3))
	{
		for( i = 0;i < iNumArgs;i++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcArgName, &pcArgValue );
			if( ( iRetCode == ITK_ok ) && (pcArgName != NULL) && (pcArgValue != NULL) )
			{
			   
				if(tc_strcasecmp(pcArgName, "query") == 0)
				{
				    //Initialising memory for the comma separated query names.
			        pcQueryNameTemp = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
                    tc_strcpy( pcQueryNameTemp, pcArgValue);
					
				}
				else if(tc_strcasecmp(pcArgName, "error_message") == 0)
				{
					pcInputErrorMessage = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcInputErrorMessage, pcArgValue);
				}				
				else if(tc_strcasecmp(pcArgName, "target_type") == 0)
				{
					//pcTargetObjectType = (char*) MEM_alloc(( (int)tc_strlen(pcArgValue) + 1) * sizeof(char));
					tc_strcpy( pcTargetObjectType, pcArgValue);
				}
				else
				{						
					iRetCode = EPM_invalid_argument;			
				}
			}
			else
			{						
				iRetCode = EPM_invalid_argument;			
			}
		}
	}
	else
	{
		iRetCode = EPM_wrong_number_of_arguments;
	}
	//check the mandatory argument check
	if(iRetCode == ITK_ok && ((pcInputErrorMessage ==NULL) || (pcQueryNameTemp == NULL)) )
	{
		iRetCode = EPM_invalid_argument_value;
	}
	//to remove the forward and trailing space
	remove_forward_AND_trailing_space(pcQueryNameTemp);
	pcQueryName = (char **)malloc(10* sizeof(char *));
    pcTemp = tc_strtok (pcQueryNameTemp,",");
	while(pcTemp != NULL)
	{
		//to remove the forward and trailing space
		remove_forward_AND_trailing_space(pcTemp);		
		pcQueryName[iQryCount] = (char *)malloc((int)tc_strlen(pcTemp)+1);;
		tc_strcpy(pcQueryName[iQryCount],pcTemp);			
		iQryCount++;					
		pcTemp = tc_strtok(NULL,",");
	}
	if ( iRetCode == ITK_ok )
	{
		if((pcTargetObjectType == NULL ) || (tc_strcmp("EngChange Revision",pcTargetObjectType) == 0) )
		{
			//get the target change revision
			iRetCode = tiauto_get_change_item_rev (msg.task, &tECRev);
		}
		else if(pcTargetObjectType != NULL)
		{
			iRetCode = get_target_object(msg.task,pcTargetObjectType,&tECRev);
		}

		if ( iRetCode == ITK_ok  && tECRev != NULLTAG)
		{
			//get the item id, revision id nad item name
			iRetCode = tiauto_getItemRevDetails(tECRev,acChangeId, acChangeRevId, acChangeRevName);
		}
		if ( iRetCode == ITK_ok  && (tc_strcmp(acChangeId,"") != 0) && (tc_strcmp(acChangeRevId,"") != 0))
		{
			//check the given input query exist or not
			for(j = 0; j < iQryCount;j++)
			{
				iRetCode = QRY_find(pcQueryName[j],&tQuery);
				if(tQuery == NULLTAG)
				{
					//error
				    //display the error message
					iRetCode = TIAUTO_NOT_VALID_QUERY;
					TC_write_syslog(pcInputErrorMessage);
					EMH_store_error_s1( EMH_severity_error, iRetCode, pcInputErrorMessage) ;
					break;
				}
				if ( iRetCode == ITK_ok  && tQuery != NULLTAG)		
					iRetCode = QRY_find_user_entries( tQuery, &iEnttryCnt, &pcQentries, &pcQvalues );
				if ( iRetCode == ITK_ok  && tQuery != NULLTAG && iEnttryCnt >=2)
				{
					pcUserEntryvalues = (char **)MEM_alloc(sizeof(char *) * iEnttryCnt);
					for(i = 0; i <iEnttryCnt; i++)
					{					
						//assign the valule for the user entries
						if((tc_strcmp("Item Id",pcQentries[i]) == 0)||(tc_strcmp("ItemId",pcQentries[i]) == 0))
						{
							pcUserEntryvalues[i] = (char *) MEM_alloc(((int)tc_strlen(acChangeId) + 1) * sizeof(char));
							TI_sprintf(pcUserEntryvalues[i],"%s",acChangeId); 
						}
						else if((tc_strcmp("Rev Id",pcQentries[i]) == 0) || (tc_strcmp("RevId",pcQentries[i]) == 0))
						{
							pcUserEntryvalues[i] = (char *) MEM_alloc(((int)tc_strlen(acChangeRevId) + 1) * sizeof(char));
							TI_sprintf(pcUserEntryvalues[i],"%s",acChangeRevId);
						}
						else if(pcTargetObjectType != NULL && ((tc_strcasecmp("Type",pcQentries[i]) == 0) 
																|| (tc_strcasecmp("Object Type",pcQentries[i]) == 0)
																|| (tc_strcasecmp("ObjectType",pcQentries[i]) == 0) ))
						{
							pcUserEntryvalues[i] = (char *) MEM_alloc(((int)tc_strlen(pcTargetObjectType) + 1) * sizeof(char));
							TI_sprintf(pcUserEntryvalues[i],"%s",pcTargetObjectType);
						}
						else
						{
							pcUserEntryvalues[i] = (char *) MEM_alloc(((int)tc_strlen(pcQvalues[i]) + 1) * sizeof(char));
							TI_sprintf(pcUserEntryvalues[i],"%s",pcQvalues[i]);
						}
					}					
				}
				//execute the query
				if(iRetCode == ITK_ok && tQuery != NULLTAG )
				{
					iRetCode = QRY_execute(tQuery, iEnttryCnt, pcQentries, pcUserEntryvalues, &iResultCount, &ptResults);
				}
				
				//if the query result count is 1, that means the target change revision is a valid target
				if(iRetCode == ITK_ok && iResultCount == 1)
				{
					//check the target change revision tag equal to the query output
					if(ptResults[0] == tECRev)
					{
						lValidChangeRev = true;
						break;
					}
				}
				
				SAFE_MEM_free(pcUserEntryvalues);
			}
			//if the query result count is 0, that means the target change revision is not a valid target
			if(iRetCode == ITK_ok && lValidChangeRev == false)
			{
				//display the error message
				iRetCode = TIAUTO_NOT_VALID_TARGET_CHANGE_REV;
				TC_write_syslog(pcInputErrorMessage);
				EMH_store_error_s1( EMH_severity_error, iRetCode, pcInputErrorMessage) ;
			}
		}
	}
    //for error code other than custom error code, display the error message
	if ( iRetCode != ITK_ok && iRetCode != TIAUTO_NOT_VALID_TARGET_CHANGE_REV)
	{		
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	//if the target is valid, then set the decision to EPM_go
	if ( iRetCode == ITK_ok && lValidChangeRev == true)
	{
		decision = EPM_go;
	}
	//if the target is valid, then set the decision to EPM_nogo
	else if (iRetCode != ITK_ok )
	{
		decision = EPM_nogo;
	}
	SAFE_MEM_free (pcArgName);
	SAFE_MEM_free (pcArgValue);
	SAFE_MEM_free (pcInputErrorMessage);
	SAFE_MEM_free (pcTargetObjectType);
	SAFE_MEM_free (pcQentries);
	SAFE_MEM_free (pcQvalues);
	SAFE_MEM_free (ptResults);

	return decision;
}
