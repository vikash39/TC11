/*******************************************************************************
File         : tiauto_write_assgnList_info_to_audit.c

Description  : This server exit method writes the assignment list name to the
			   audit file.

Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                 Description
*******************************************************************************
Oct 01, 2010    1.0        Dipak Naik			Initial Creation
*******************************************************************************/

#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>

extern int TAUTO_AssignmentList_info_to_Audit(void *return_value)
{

	tag_t       tJob = NULLTAG;
	tag_t       tMsgTask = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
	tag_t		tChangeRev = NULLTAG;
	int         iRetCode = 0;	
	char *pcString = NULL;
	int iFail = ITK_ok;
	IMF_file_t  tFileDescriptor = NULL;
	//AUDIT_log_query_t aLogQuery;
	AUDIT_record_t aLogQuery;

    
    iFail = USERARG_get_tag_argument(&tMsgTask);
	iFail = USERARG_get_string_argument(&pcString);
	iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);

	if(tAuditFile == NULLTAG)
	{
		iRetCode = tiauto_get_change_item_rev(tMsgTask,&tChangeRev);
		if(tChangeRev != NULLTAG)
		{
			iRetCode = AOM_refresh(tChangeRev,true);
			iRetCode = AOM_set_value_string(tChangeRev,"t8_appliedassignmentlist",pcString);
			iRetCode = AOM_save(tChangeRev);
			iRetCode = AOM_refresh(tChangeRev,false);
		}
	}
	else
	{
		if (iRetCode == ITK_ok)
			iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
		if (iRetCode == ITK_ok)
			iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);
		if (iRetCode == ITK_ok)
		{		
			TC_write_syslog  ( "\n********** BEGIN OF Assignement List Info ********** : \n");
			iRetCode = IMF_write_file_line(tFileDescriptor, "\n*********************************************************************************");
			iRetCode = IMF_write_file_line(tFileDescriptor, "****** BEGIN OF Assignement List Info ******\n");
			iRetCode = IMF_write_file_line(tFileDescriptor, pcString);
		
			iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************");
			iRetCode = IMF_write_file_line(tFileDescriptor, "****** END OF Assignement List Info ******");
			iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n\n");
			TC_write_syslog  ( "\n********** END OF Assignement List Info ********** : \n");
		}
		if (iRetCode == ITK_ok)
			iRetCode = IMF_close_file(tFileDescriptor);
	}
    EMH_clear_errors();
	SAFE_MEM_free(pcString);
	
	return iRetCode;
}
