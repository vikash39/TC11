/************************************************************************************************
FILE        :   tiauto_rh_verify_masterdrawing_and_partfamily_attributes.c

DESCRIPTION :   

AUTHOR      :   Pradeep, TCS

Revision History :
Date            Revision    Who              Description
***************************************************************************************************
25 Mar, 2016    1.0        Pradeep	         Initial Creation
***************************************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

EPM_decision_t TIAUTO_RH_verify_masterdrawing_and_partfamily_attributes(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;

	return decision;
}
