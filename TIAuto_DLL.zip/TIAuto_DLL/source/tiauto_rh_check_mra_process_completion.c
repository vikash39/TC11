
/*******************************************************************************
FILE        :   tiauto_rh_check_mra_dataset_creation.c
Details     :   This is a dummy rule handler. This is used to check whether a
				perticular task is assigned to user that matches with the role
				and group name mentioned in the handler argument during apply
				assignment

REVISION HISTORY :

Date              Revision        Who						Description
Sept  2, 2011     1.0			  Dipak Naik				Initial Creation.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


/*=================================================================================
*    Implementation of Action Handler -  TIAUTO_RH_check_action_performer_role
===================================================================================*/
EPM_decision_t TIAUTO_RH_check_mra_dataset_creation(EPM_rule_message_t msg )
{
    int iFail				= ITK_ok;
	int iSolItemRevs		= 0;
	int iSecCount			= 0;
	int iIRMCount			= 0;
	int indx				= 0;
	int iCount				= 0;

	boolean bValidERPPlant		= false;
	boolean bMfgRelToBeCreated	= false;
	boolean bMfgRelCreated		= true;
	boolean	bACDCreated			= true;
	char *pcErrMsg										= NULL;
	char *pcValidReleaseStatusList						= NULL;
	char *pcMfgRelAuthCode								= NULL;
	char *pcACDCode										= NULL;
	char acObjectType[WSO_name_size_c+1]				= "";	
	char acObjectName[WSO_name_size_c+1]				= "";
	char acErrorString[TIAUTO_error_message_len+1]		= "";
	char    pszObjType[WSO_name_size_c+1]="";

	tag_t tRelationType		= NULLTAG;
	tag_t tEngChgRev		= NULLTAG;
	tag_t *ptSolItemRevs	= NULL;
	tag_t *ptIRMObj			= NULL;
	tag_t *ptSecObj			= NULL;

	EPM_decision_t decision = EPM_go;
	tag_t tRootTask = NULLTAG;
	char   acRootTaskName[WSO_name_size_c + 1] = "";

	//get the root task
	iFail = EPM_ask_root_task (msg.task, &tRootTask) ;
	if( ( iFail == ITK_ok ) && ( tRootTask != NULLTAG ) )
	{
		//get the root task name
		iFail = EPM_ask_name  (  tRootTask, acRootTaskName );
	}

	if( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0)
	{
		iFail = verify_Valid_ERP_Plant(msg.task,&bValidERPPlant,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else if(tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0 || tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0)
	{
		iFail = verify_Valid_ACD_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	else
	{
		iFail = verify_Valid_MRA_Condition(msg.task,&bMfgRelToBeCreated,&pcValidReleaseStatusList);
	}
	
	//if there are any ITK failure
	if ( iFail != ITK_ok && iFail != EPM_invalid_argument_value)
	{		
		decision = EPM_nogo;
		EMH_ask_error_text (iFail, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iFail, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	//Conditional Task result decision
	//if( bMfgRelToBeCreated == true && iFail == ITK_ok)// ( bValidERPPlant == true && bMfgRelToBeCreated == true && iFail == ITK_ok)	
	if ( iFail == ITK_ok && ( (bMfgRelToBeCreated == true && 
										( tc_strcmp(acRootTaskName,"CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"PMR - Program Mgmt Release") == 0)  ||
										( tc_strcmp(acRootTaskName,"19_00 CAP - Change Approval Process") == 0 || 
										tc_strcmp(acRootTaskName,"22_00 PMR - Program Mgmt Release") == 0) ) ||
				( ( tc_strcmp(acRootTaskName,"15_00 CAP - Change Approval Process") == 0 || 
				   tc_strcmp(acRootTaskName,"14_00 PMR - Program Mgmt Release") == 0) && 
				   bValidERPPlant == true && bMfgRelToBeCreated == true ) || (bMfgRelToBeCreated == true && ( tc_strcmp(acRootTaskName,"TPR - Technology Primary Release") == 0  )) || (bMfgRelToBeCreated == true && ( tc_strcmp(acRootTaskName,"TER - Technology Emergency Release") == 0  )) ) )
	{
		iFail = tiauto_get_change_item_rev (msg.task, &tEngChgRev);
		//get all the MRA documents & check whether PDF dataset is present with named reference
		
		iFail = WSOM_ask_object_type(tEngChgRev, pszObjType);

		if (iFail == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
		{
			tag_t tRelTemp = NULLTAG;
			iFail = GRM_find_relation_type ("CMHasSolutionItem",&tRelTemp);
			if(iFail == ITK_ok && tRelTemp!=NULLTAG)
			{
				iFail = GRM_list_secondary_objects_only(tEngChgRev,tRelTemp,&iSolItemRevs,&ptSolItemRevs);
			}
		}
		else
			iFail = ECM_get_contents (tEngChgRev,"solution_items",&iSolItemRevs,&ptSolItemRevs);
		//verify in Ref. folder
		for (iCount = 0; iCount < iSolItemRevs && (iFail == ITK_ok); iCount++)
		{
			tc_strcpy(acObjectType,"");
			/* get the object type */
			iFail = WSOM_ask_object_type (ptSolItemRevs[iCount], acObjectType);
			if(tc_strcmp(acObjectType,"T8_T_MfgRelAuth Revision") == 0)
			{
				iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptSolItemRevs[iCount],tRelationType,&iIRMCount,&ptIRMObj); 
				if(iIRMCount > 0 && ptIRMObj[0] != NULLTAG)
				{
					iFail = AOM_ask_value_string (ptIRMObj[0],"t8_150mfgrelauthnum",&pcMfgRelAuthCode);
					if(pcMfgRelAuthCode != NULL)
					{
						for(indx =0; pcMfgRelAuthCode[indx] !='\0'; indx++)
						{
							if(pcMfgRelAuthCode[indx] =='/')
							{
								pcMfgRelAuthCode[indx] = '_';
							}
						}
					}
				}
				tRelationType = NULLTAG;
				iFail = GRM_find_relation_type("IMAN_specification", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptSolItemRevs[iCount],tRelationType,&iSecCount,&ptSecObj); 
				if(iSecCount == 0)
				{
					bMfgRelCreated = false;
					break;
				}
				for(indx =0; indx < iSecCount; indx++)
				{
					tc_strcpy(acObjectType,"");
					iFail = WSOM_ask_object_type (ptSecObj[indx], acObjectType);
					if(tc_strcmp(acObjectType,"AdobeAcrobat") == 0)
					{
						iFail = WSOM_ask_name (ptSecObj[indx],acObjectName);
						if(tc_strcmp(pcMfgRelAuthCode,acObjectName) == 0)
						{
							break;
						}
						else
						{
							bMfgRelCreated = false;
						}
					}
					else
					{
						bMfgRelCreated = false;
						break;
					}
				}
				SAFE_MEM_free(ptSecObj);
				SAFE_MEM_free(pcMfgRelAuthCode);
				if(bMfgRelCreated == false)
				{
					break;
				}
			}
			else if(tc_strcmp(acObjectType,"T8_T_AdvChangeRevision") == 0)
			{
				iFail = GRM_find_relation_type("IMAN_master_form", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptSolItemRevs[iCount],tRelationType,&iIRMCount,&ptIRMObj); 
				if(iIRMCount > 0 && ptIRMObj[0] != NULLTAG)
				{
					iFail = AOM_ask_value_string (ptIRMObj[0],"t8_150acdnum",&pcACDCode);
					if(pcACDCode != NULL)
					{
						for(indx =0; pcACDCode[indx] !='\0'; indx++)
						{
							if(pcACDCode[indx] =='/')
							{
								pcACDCode[indx] = '_';
							}
						}
					}
				}
				tRelationType = NULLTAG;
				iFail = GRM_find_relation_type("IMAN_specification", &tRelationType);
				if(tRelationType != NULLTAG)
					iFail = GRM_list_secondary_objects_only(ptSolItemRevs[iCount],tRelationType,&iSecCount,&ptSecObj); 
				if(iSecCount == 0)
				{
					bACDCreated = false;
					break;
				}
				for(indx =0; indx < iSecCount; indx++)
				{
					tc_strcpy(acObjectType,"");
					iFail = WSOM_ask_object_type (ptSecObj[indx], acObjectType);
					if(tc_strcmp(acObjectType,"AdobeAcrobat") == 0)
					{
						iFail = WSOM_ask_name (ptSecObj[indx],acObjectName);
						if(tc_strcmp(pcACDCode,acObjectName) == 0)
						{
							break;
						}
						else
						{
							bACDCreated = false;
						}
					}
					else
					{
						bACDCreated = false;
						break;
					}
				}
				SAFE_MEM_free(ptSecObj);
				SAFE_MEM_free(pcACDCode);
				if(bACDCreated == false)
				{
					break;
				}
			}
		}
	}
	if(bMfgRelCreated == false)
	{
		iFail = TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED;
		decision = EPM_nogo;
		TI_sprintf(acErrorString, "The Manufacturing Release Authorisation dataset creation is currently in progress. This workflow task cannot be completed until the dataset creation process is finished. An email notification will be sent when this process is complete.");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_MRA_CREATION_PROCESS_NOT_COMPLETED, acErrorString) ;						
		TC_write_syslog(acErrorString);
	}
	
	if(bACDCreated == false)
	{
		iFail = TIAUTO_ACD_CREATION_PROCESS_NOT_COMPLETED;
		decision = EPM_nogo;
		TI_sprintf(acErrorString, "The Technology Release Authorisation dataset creation is currently in progress. This workflow task cannot be completed until the dataset creation process is finished. An email notification will be sent when this process is complete.");
		EMH_store_error_s1( EMH_severity_error, TIAUTO_ACD_CREATION_PROCESS_NOT_COMPLETED, acErrorString) ;						
		TC_write_syslog(acErrorString);
	}
	SAFE_MEM_free(ptSecObj);
	SAFE_MEM_free(pcMfgRelAuthCode);
	SAFE_MEM_free(ptSolItemRevs);
	SAFE_MEM_free(pcACDCode);
	return decision;
}
