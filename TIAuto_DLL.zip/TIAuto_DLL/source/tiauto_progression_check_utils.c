/*******************************************************************************
FILE        :   tiauto_progression_check_utils.c

DESCRIPTION : This file contains all the progression check functions.

ti_check_for_backward_progression : This function checks the backward progression.

				� Backwards Progression -  Validates the status progression of current
                  revision of item w.r.t later revisions of the same item.
				    1)  If any of the later revision of the current item revision has been released to
					    to the current target status or higher, then it is a error.

ti_check_for_item_revision_progression: This function checks the item revision progression.

				� Component Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  meet one of the following requirements:
                    1)	The item revision is not yet released.
                    2)	The item revision is at a lower status than the target status.
                    3)	The item revision is already at the target status.
					4)  If the above checks fails, its a progression error.

ti_check_for_assembly_progression: This function checks the assembly progression.

                � Assembly Item Rev Progression - A check should be performed on all
                  item revisions contained in the affected and solution folder to ensure
                  that all the child components in it�s precise BOM meet one of the
                  following requirements:
                    1)	If the child component is at at a lower status than the target release status then
					    it should be included in the affected/solution items folder of the targeted change revision.
                    2)	The component is at the target status.
                    3)	The component is at a status higher than the target status.
					5)  The component is in an on-going parallel process which has
					    same/higher target released status ( so that the task is held till the
						parallel process is complete and the child component is statused).(Its a progression warning)
					6)  If the above conditions fails, its a progression error.

ti_check_for_generic_progression: This function checks the generic progression.

                � Generic Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  that have ProAsm or ProPrt dataset and are instance items, the generic item rev
				  should meet one of the following requirements:
                    1)	If the generic is at at a lower status than the target release status then
					    it should be included in the affected/solution items folder of the targeted change revision.
                    3)	The generic is at the target status.
					4)  The generic is at a status higher than the target release status.
					5)  The generic is in an on-going parallel process which has
					    same/higher target released status ( so that the task is held till the
						parallel process is complete and the generic part is statused). (Its a progression warning)
					6)  If the above conditions fails, its a progression error.

REVISION HISTORY :

Date              Revision        Who                    Description
Apr 16, 2010      1.0            Dipak Naik				 Initial Creation.
Jun 11, 2010	  1.1			 Dipak Naik				 Added the code to validate the status of the Alternate
														 Parts w.r.t the target status of the workflow in case of
														 assembly progression check.
August 10,2010	  1.1			 Dipak Naik				 Modified the code of the assembly and generic progression
														 check for PMR workflow
Dec 05, 2013	  1.2			 Shruti Pinto			 Modified the code of generic progression check for SolidWorks.
Apr	24, 2014	  1.3			 Shruti Pinto			 Added the code to check the missing master drawing attributes
														 as per the ER#7474.
Jun	25, 2017      1.4            Ramesh				     Modified code for ER#9349					
Apr	18, 2018      1.5            Kantesh				 Modified Assembly Progression to check Advance Technology IR in BOM
Jun, 18,2019      1.6            Trisha Saha             Modified code to add check for solution items are of same state as 
                                                         target status and substitute check for PCI
*****************************************************************************************************************************/

/* includes */
#include <tiauto_progression_check_utils.h>

//Validates progression of current revision status w.r.t target release status
//of change process.
extern int ti_check_for_item_revision_progression(	tag_t						_tItemRev,
											STATUS_Struct_t				_StatusProgression,
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											int							_iPopulateErrMsgInStack,
											int							*iError_,
											TIA_ErrorMessage			**errMsgStack_, ... )

{
    int     iRetCode								  = ITK_ok;
	int		iQuickProgFlag							  = 0;
	int		iTotal									  = 0;
    char    *szItemRevId							  = NULL;
    char    szReleaseStatus[WSO_name_size_c+1]		  = "";
	char	szErrorString[TIAUTO_error_message_len+1] ="";
	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;
	iRetCode = AOM_refresh(_tItemRev,false);
	//get the release status
    iRetCode = tiauto_get_release_status( _tItemRev, szReleaseStatus );
	if(tc_strcmp(szReleaseStatus,"T8_Standard - Preliminary") == 0)
	{
		tc_strcpy(szReleaseStatus, "Standard - Preliminary");
	}
	else if(tc_strcmp(szReleaseStatus,"T8_Standard - Released") == 0)
	{
		tc_strcpy(szReleaseStatus, "Standard - Released");
	}
	else if(tc_strcmp(szReleaseStatus,"T8_Technology Prototype") == 0)
	{
		tc_strcpy(szReleaseStatus, "Technology Prototype");
	}
	else if(tc_strcmp(szReleaseStatus,"T8_Technology Released") == 0)
	{
		tc_strcpy(szReleaseStatus, "Technology Released");
	}
	if ( iRetCode == ITK_ok )
	{
		//get the item revision id string: "Item/Rev" format i. e "AR001/AA"
        iRetCode = WSOM_ask_id_string ( _tItemRev, &szItemRevId );
	}

    // If item rev status is greater than the Changege Process Target Release status
    if ( (iRetCode == ITK_ok) &&
		 (tiauto_status_progression_index (szReleaseStatus, _StatusProgression) >  _TargetReleaseStatus.iLevel) )
    {
		// Item revision is at invalid status
		*iError_ = TIAUTO_PARTREV_INVALID_STATUS;
		if (_iPopulateErrMsgInStack == 1)
		{

			TI_sprintf(szErrorString, "%s %s \"%s\"%s",szItemRevId, TIAUTO_PARTREV_INVALID_STATUS_TEXT1,
									_TargetReleaseStatus.szTargetReleaseStatus ,TIAUTO_PARTREV_INVALID_STATUS_TEXT2 );
			tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_INVALID_STATUS, szErrorString);
			////////////////////////////////////////////////////////////////////
			if(1 == iQuickProgFlag)
			{
				tiauto_Store_wsom_tags(error_list,&iTotal,_tItemRev);
			}
		}

    }
	// start of 15.02 P-check
	 else if ( (iRetCode == ITK_ok) &&
		 (tiauto_status_progression_index (szReleaseStatus, _StatusProgression) ==  _TargetReleaseStatus.iLevel) )
    {
		// Item revision is at invalid status
		*iError_ = TIAUTO_PARTREV_EQUAL_STATUS;
		if (_iPopulateErrMsgInStack == 1)
		{

			TI_sprintf(szErrorString, "%s %s \"%s\"%s",szItemRevId, TIAUTO_PARTREV_EQUAL_STATUS_TEXT1,
									_TargetReleaseStatus.szTargetReleaseStatus ,TIAUTO_PARTREV_EQUAL_STATUS_TEXT2 );
			tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_EQUAL_STATUS, szErrorString);
			////////////////////////////////////////////////////////////////////
			if(1 == iQuickProgFlag)
			{
				tiauto_Store_wsom_tags(error_list,&iTotal,_tItemRev);
			}
		}

    }

	//end of 15.02 P-check
	va_end ( vl );
	SAFE_MEM_free(szItemRevId);
    return  iRetCode;
}


//validates the existing status of each and every item revision under change folders
//for backwards status progression, In this function we will return either
//user defined error code TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR
//or teamcenter standard errorCode, based on this errorCode we will frame the error message in the
//calling function

extern int ti_check_for_backward_progression ( tag_t						_tItemRev,
										    tag_t						*_ptAffectedItems,
											int							_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression,
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											int							_iPopulateErrMsgInStack,
											int							*iError_,
											TIA_ErrorMessage			**errMsgStack_ ,...)
{
	int		iRetCode			= ITK_ok;
    int		iRevCount			= 0;
	int		indx				= 0;
	int		iQuickProgFlag		= 0;
	int		iTotal				= 0;
    tag_t	*ptItemRevList		= NULL;
    tag_t	tItem				= NULLTAG;

    char	*szItemRevInChangeId						= NULL;
	char	*szItemRevId								= NULL;
    char	szReleaseStatusName[WSO_name_size_c+1]		= "";
	char szErrorString[2048]="";
	char szItemRevIdTemp[TIAUTO_error_message_len+1] = "";
	TIA_ErrorItems  *sBOMItemRevs = NULL;
	TIA_UniqueWSOMObjects** error_list1 = NULL;
	TIA_UniqueWSOMObjects** error_list2 = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		// for error items to be removed from target folder
		error_list1 = va_arg(vl,TIA_UniqueWSOMObjects**);
		// for missing items to be copied to target folder
		error_list2 = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);
	//TI_DEBUG_PRINT1("%s\n", "Enter -> check_for_item_rev_backward_progression");

	//WSOM_ask_id_string returns the string "Item/Rev" format i. e "AR001/AA"
    iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
    if(iRetCode == ITK_ok)
	{
		//get the item tag
        iRetCode = ITEM_ask_item_of_rev(_tItemRev, &tItem);
	}

    if(iRetCode == ITK_ok)
	{
		//get all the revisions of the item
        iRetCode = ITEM_list_all_revs(tItem, &iRevCount, &ptItemRevList);
	}

	if(DEBUG_PRINT)
	{
		//printf("\n Item in Change Rev is : [%s]", szItemRevInChangeId);
	}

	//Here is an Use Case. 001/AA - no status, 001/AB - Prod Released, 001/AC - Prod Launched,
	//001/AA in in Change folder, target status is Pre-Production
	//Do we need to give the error message about AB, AC are in greater status than that of AA,
	//But I guess we can break when we find the 1st error, i. e. AB, the current code does that
    for (indx = 0; indx < iRevCount && (iRetCode == ITK_ok) && (iRevCount >1); indx++)
    {
        iRetCode = WSOM_ask_id_string(ptItemRevList[indx], &szItemRevId);
        if(iRetCode == ITK_ok)
        {
            //TI_DEBUG_PRINT1("Item Rev : %s\n", szItemRevId);

			//Compare the release staus of the itemrev in EC with the higher revs of the item
			//i.e if itemrev 001/AD is in Change then compare the release status of itemrev 001/AD
			//with AF, AG and so on. no need to check w.r.t AA, AB, AC and AD
            if(tc_strcasecmp(szItemRevId, szItemRevInChangeId) > 0)
            {
                iRetCode =  tiauto_get_release_status(ptItemRevList[indx], szReleaseStatusName);
				if(tc_strcmp(szReleaseStatusName,"T8_Standard - Preliminary") == 0)
				{
					tc_strcpy(szReleaseStatusName, "Standard - Preliminary");
				}
				else if(tc_strcmp(szReleaseStatusName,"T8_Standard - Released") == 0)
				{
					tc_strcpy(szReleaseStatusName, "Standard - Released");
				}
				else if(tc_strcmp(szReleaseStatusName,"T8_Technology Prototype") == 0)
				{
					tc_strcpy(szReleaseStatusName, "Technology Prototype");
				}
				else if(tc_strcmp(szReleaseStatusName,"T8_Technology Released") == 0)
				{
					tc_strcpy(szReleaseStatusName, "Technology Released");
				}

				if( iRetCode == ITK_ok )
				{
					//ignore this higher revision having "Cad Release Only" status; valid status
					if( tc_strcasecmp(  szReleaseStatusName, CRO ) == 0 )
					{
						continue;
					}
					else if(tiauto_status_progression_index (szReleaseStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel)
					{
						//if _iPopulateErrMsgInStack == 1 then populate the errmsg to stack
						if (_iPopulateErrMsgInStack == 1)
						{
							//I want the TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR message to be
							//printed first, because of the insert into stack logic, I'm inserting it later
							tc_strcpy(szItemRevIdTemp,"");
							//to find where this error item rev is used in the BOM
							iRetCode = ti_where_used_in_BOM(_tItemRev,_ptAffectedItems, _iNumAffectedItems,szItemRevIdTemp,&sBOMItemRevs);
							while(sBOMItemRevs != NULL)
							{
								if(tc_strcmp(szItemRevIdTemp,"") != 0)
									tc_strcat(szItemRevIdTemp,", ");
								tc_strcat(szItemRevIdTemp,sBOMItemRevs->szErrorItems);
								sBOMItemRevs = sBOMItemRevs->next;
							}
							if(!tc_strcmp(szItemRevIdTemp,""))
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s",
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);
								TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
													szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
													_TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
															szErrorString);

								// Appending the Missing Item to the error_list
								if(1 == iQuickProgFlag)
								{
									tiauto_Store_wsom_tags(error_list1,&iTotal,_tItemRev);
									tiauto_Store_wsom_tags(error_list2,&iTotal,ptItemRevList[indx]);
								}
							}
							else
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s(%s)",
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
														TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6,szItemRevIdTemp);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);
								TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
													szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
													_TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
															szErrorString);
								// Appending the Missing Item to the error_list
								if(1 == iQuickProgFlag)
								{
									tiauto_Store_wsom_tags(error_list1,&iTotal,_tItemRev);
									tiauto_Store_wsom_tags(error_list2,&iTotal,ptItemRevList[indx]);
								}
							}
							/*TI_sprintf(szErrorString, "%s %s %s %s \"%s\"%s", szItemRevInChangeId,
								                   TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT1,
												   szItemRevId, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT2,
												   _TargetReleaseStatus.szTargetReleaseStatus,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT3);
							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR ,
														szErrorString);

							TI_sprintf(szErrorString, "%s %s %s %s %s",
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT4,szItemRevId,
													TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT5,szItemRevInChangeId,
												   TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR_TEXT6);
							tiauto_writeErrorMsgToStack(errMsgStack_,
								     TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);*/

						}
                        *iError_ = TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR;
						break;
					}
				}
			}
        }
        SAFE_MEM_free (szItemRevId);
		tc_strcpy(szReleaseStatusName, "");
    }
	va_end ( vl );
	SAFE_MEM_free (szItemRevInChangeId);
    SAFE_MEM_free (ptItemRevList);

	//TI_DEBUG_PRINT1("%s\n", "Exit -> check_for_item_rev_backward_progression");

    return iRetCode;
}


//If the part is an assembly part, then this function validates the present statuses of
//each and every component part of the assembly (same rev progression w.r.t target release
//status of change process. In the present implementation, there is only ONE BOM and it should
//be PRECISE. So we are ignoring any NON-PRECISE BOMs and more than one BOMs
extern int ti_check_for_assembly_progression(	tag_t						_tItemRev,
												tag_t						*_ptAffectedItems,
												int							_iNumAffectedItems,
												STATUS_Struct_t				_StatusProgression,
												TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
												char						*pcEndOfWarningMsg,
												int							_iPopulateWarningMsgInStack,
												int							_iPopulateErrMsgInStack,
												char						*pcRootTaskName,
												int							iLevel,
												int							*iError_,
												TIA_ErrorMessage			**warningMsgStack_,
												TIA_ErrorMessage			**errMsgStack_,...)
{
    int		iRetCode				= 0;
    int		iCount					= 0;
    int		iItemRevBvrCount		= 0;
    int		iNumOccs				= 0;
	int		iFound					= 0;
	int		iSiteIid				= 0;
	int		iQuickProgFlag			= 0;
	int		iTotal					= 0;

    tag_t   *ptItemRevBvrs			= NULL;
    tag_t   *ptOccs					= NULL;
    tag_t   tChildItem				= NULLTAG;
	tag_t	tChildBomView			= NULLTAG;
	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	*szItemRevInChangeId						= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= "";

    logical lIsPrecise			= false;
	logical lIsOEM				= false;
	logical lHasAlternates		= false;

	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}

	iRetCode = AOM_refresh(_tItemRev,false);

	*iError_ = 0;
    if(iLevel != 0)
	{
		iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
		if ( iRetCode == ITK_ok)
			iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);
		if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
		{
			//As per existing implementation, there is only one BVR in the system, So always take the 1st one
			iRetCode = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
			if ( (iRetCode == ITK_ok) && (lIsPrecise == false) )
			{
				*iError_ = TIAUTO_IMPRECISE_BVR_FOUND;

				//If _iPopulateErrMsgInStack == 1, then populate error message
				if(_iPopulateErrMsgInStack == 1)
				{
					TI_sprintf(szErrorString, "%s %s", szItemRevInChangeId, TIAUTO_IMPRECISE_BVR_FOUND_TEXT);
					tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_IMPRECISE_BVR_FOUND, szErrorString);
				}
			}
		}

		//If the item doesn't have a precise BOM, we need not proceed further
		if ( (iRetCode == ITK_ok) && (*iError_ == 0) && iItemRevBvrCount > 0 )
		{
			iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
			// If the BVR does not have any child component, no need to proceed further
			for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
			{
				tChildItem = NULLTAG;
				tChildBomView = NULLTAG;
				tc_strcpy ( szChildRelStatus, "" );
				szChildItemRev = NULL;
				lHasAlternates = false;

				iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],
													 &tChildItem, &tChildBomView);
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					iRetCode = AOM_refresh(tChildItem,false);
					//get the target release status of the child component
					iRetCode = tiauto_get_release_status(tChildItem, szChildRelStatus);
					if(tc_strcmp(szChildRelStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Released");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Released");
					}
				}
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					iRetCode = WSOM_ask_id_string( tChildItem, &szChildItemRev);
				}
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					//check whether the child component is of _OEM type
					iRetCode = tiauto_check_if_itemType_isOEM(tChildItem, &lIsOEM);
					if ( iRetCode == ITK_ok )
					{
						TI_DEBUG_PRINT1("Child Item Status Type : %s\n", szChildRelStatus);

						//1. check if child item revisions have obsolete status.
						//if obsolete then error out
						if(!tc_strcmp(szChildRelStatus,OBSOLETE))
						{
							*iError_ = TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString,"%s \"%s\" %s \"%s\" %s",
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
								TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							}
							// Appending the Missing Item to the error_list
							if(1 == iQuickProgFlag)
							{
								tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
							}
						}

						else if((tc_strstr(szChildRelStatus,TECHNOLOGY) != 0) && (tc_strstr(_TargetReleaseStatus.szTargetReleaseStatus,TECHNOLOGY) == 0))
						{
							*iError_ = TIAUTO_ADVANCE_TECHNOLOGY_ITEM_INCORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString,"%s \"%s\" %s \"%s\" %s",
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
								TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
								TIAUTO_ADVANCE_TECHNOLOGY_ITEM_INCORRECT_STATUS_TEXT2);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_ADVANCE_TECHNOLOGY_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							}
							// Appending the Missing Item to the error_list
							if(1 == iQuickProgFlag)
							{
								tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
							}
						}
						//2.If the child component is OEM then it has to be in "Cad Release Only" status
						//So whenever we find the above condition, it will be considered as an ERROR,
						//no matter stacked CR exists or not, so we will not care about the flag
						else if( lIsOEM == true )
						{
							if(tc_strcasecmp(szChildRelStatus, CRO)!= 0)
							{
								if( (tc_strcmp(pcRootTaskName,"9_00 CRO - CAD Release Only") == 0) || (tc_strcmp(pcRootTaskName,"CRO - CAD Release Only") == 0) )
									IsExistInAffectedFolder( tChildItem, _ptAffectedItems, _iNumAffectedItems, &iFound );

								if( iFound == 0)
								{
									if( (tc_strcmp(pcRootTaskName,"9_00 CRO - CAD Release Only") == 0) || (tc_strcmp(pcRootTaskName,"CRO - CAD Release Only") == 0) )
									{
										//Populate the ERROR MESSAGE stack
										TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
									}
									else
									{
										*iError_ = TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR;
										if(_iPopulateErrMsgInStack == 1)
										{
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1, szChildItemRev,
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR, szErrorString);
										}
									}
								}
							}
							else
							{

								/*if( iFound == 0)
								{
									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);

								}*/
							}
						}
						//3.Verifying whether child component rev is at SAME or HIGHER status than
						//target release status of Change process.
						//If yes, accept the child component and continue to verify another child rev.
						else if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
						{
							//If not as above mentioned, verify if the child component rev is part of
							//Affected OR Solution Items folders of Change Process.
							//If yes, accept and continue to verify another child rev.
							IsExistInAffectedFolder( tChildItem, _ptAffectedItems, _iNumAffectedItems, &iFound );
							if( iFound == 0)
							{
								//if the workflow process is DAP then check for the remote stacked
								//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
								if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
								{
									iRetCode = AOM_ask_value_tag( tChildItem, "owning_site", &tOwningSite);
									if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
									{
										//In case of DAP, if the child component is a remote object then the
										// error and warning message will be different from the general format
										iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
									}
								}
								if ( _iPopulateWarningMsgInStack ==1 )
								{
									//Check if any stacked CR exists to take care of this error,
									//add them to warnings
									//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
									if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
									{
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											if(tc_strcmp(szChildRelStatus,"DAP In Process")== 0)
											{
												//if the remote item revision has "DAP In Process" status then
												//Populate the WARNING MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
															szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
												tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}
											else
											{
												//if the remote item revision has a lower status than the "DAP In Process"
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);


											}
										}
										else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
										{
											//for the local site, check for the stacked DAP
											iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tChildItem, &szStackedCRName);
											//if stacked DAP is found, then the stacked target status will be same as
											//as the current target status
											if(szStackedCRName != NULL)
											{
												szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
												tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
											}

										}
									}
									else
									{
										//In case of CR/CRB, check for the stacked scenario
										iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tChildItem,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
									}
									if(tOwningSite == NULLTAG)
									{
										if( (szStackedCRTargetStatusName != NULL) &&
											(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
										{
											//Populate the WARNING MESSAGE stack
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
										}
										else
										{
											*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

											//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
											//because, in case of error we will get out of this function and
											//will not wait in the rule handlers, even if some of the child may be
											//in stacked CR
											if ( _iPopulateErrMsgInStack == 1 )
											{
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
												// Appending the Missing Item to the error_list
												if(1 == iQuickProgFlag)
												{
													tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
												}
											}
										}
									}
									//Clean up the two variables
									SAFE_MEM_free( szStackedCRTargetStatusName );
									SAFE_MEM_free( szStackedCRName );
								}
								else
								{
									*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);

										}
										else
										{
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
											}
										}

									}
								}

							}
						}
					}
				}

				//Break if _iPopulateErrMsgInStack == 0 and *iError_ != 0
				//This will be for the Stacked CR rule handler
				//if the assembly progression error can n't be taken care of by Stacked CR then no need to wait
				//for the stacked CR as it will be reported in the next Progression action handler and
				//either the task will be demoted to 2_30 or the workflow will be rejected
				if ( (_iPopulateErrMsgInStack == 0) && (*iError_ != 0) )
				{
					break;
				}
				//check the status of the Alternates
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					//iRetCode = PS_ask_has_alternates  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates ); //Deprecated This will be obsoleted. Use PS_ask_has_substitutes
					iRetCode = PS_ask_has_substitutes  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates );
					if ( iRetCode == ITK_ok && lHasAlternates == true)
					{
						iRetCode = check_status_of_Alternates(	ptItemRevBvrs[0], ptOccs[iCount],
																tChildItem,szItemRevInChangeId,
																_ptAffectedItems,_iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,
																iLevel, iError_,
																warningMsgStack_, errMsgStack_, iQuickProgFlag, error_list);
					}
				}
				//if the "iLevel", call this recursive function again.
				//for the recursive function the "iLevel" value will be "iLevel - 1"
				if(iRetCode == ITK_ok && tChildItem != NULLTAG && (iLevel != 0) )
				{
					iRetCode = ti_check_for_assembly_progression( tChildItem, _ptAffectedItems, _iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,iLevel-1, iError_,
																warningMsgStack_, errMsgStack_, iQuickProgFlag, error_list);
				}


				// To check whether Master Drawing Reference of child component having valid status
				//if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				//{
				//	int		iIRMFCnt											= 0;
				//	int		i													= 0;

				//	tag_t	tIRMFRelationType									= NULLTAG;
				//	tag_t	tRefItemRev											= NULLTAG;
				//	tag_t	*ptIRMFList											= NULL;

				//	char    *pcItemRevId										= NULL;
				//	char    *pcRefItemRevId                                     = NULL;
				//	char    *pcTempItemRevId                                    = NULL;
				//	char    szRefItemRevReleaseStatus[WSO_name_size_c+1]		= "";
				//	char	acItemRevType[ITEM_type_size_c+1]					= "";

				//	logical     lIsPresent										= false;

				//	//get the item revision type
				//	iRetCode = ITEM_ask_rev_type(tChildItem, acItemRevType);

				//	if ( (iRetCode == 0) && (tc_strcmp(acItemRevType,"TI_Product Revision") == 0) )
				//	{
				//		//get the item revision id string: "Item/Rev" format i. e "00001/AA"
				//		iRetCode = WSOM_ask_id_string ( tChildItem, &pcItemRevId );

				//		iRetCode = GRM_find_relation_type("IMAN_master_form", &tIRMFRelationType);
				//		if (iRetCode == 0 && tIRMFRelationType != NULLTAG);
				//		{
				//			iRetCode = GRM_list_secondary_objects_only (tChildItem,tIRMFRelationType,&iIRMFCnt,&ptIRMFList);
				//		}
				//		if (iRetCode == 0 && iIRMFCnt == 1)
				//		{
				//			iRetCode = AOM_ask_value_tag (ptIRMFList[0], "t8_t1a1masterdrawingref", &tRefItemRev);
				//			if ( iRetCode == ITK_ok && tRefItemRev != NULLTAG)
				//			{
				//				//get the reference item revision id string: "Item/Rev" format i. e "AR001/AA"
				//				iRetCode = WSOM_ask_id_string ( tRefItemRev, &pcRefItemRevId );

				//				// check whether the Master Drawing Reference linked Item rev is present in the current change folder
				//				for (i=0; i<_iNumAffectedItems; i++)
				//				{
				//					iRetCode = WSOM_ask_id_string ( _ptAffectedItems[i], &pcTempItemRevId );
				//					if ( (iRetCode == 0) && (tc_strcmp(pcRefItemRevId, pcTempItemRevId) == 0) )
				//					{
				//						lIsPresent = true;
				//					}

				//				}

				//				if ( (lIsPresent == false) && (iRetCode == 0) )
				//				{
				//					//get the release status
				//					iRetCode = tiauto_get_release_status( tRefItemRev, szRefItemRevReleaseStatus );
				//					if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Preliminary") == 0)
				//					{
				//						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Preliminary");
				//					}
				//					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Released") == 0)
				//					{
				//						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Released");
				//					}
				//					// If Master Drawing Reference linked item rev has no Release status
				//					if( (iRetCode == ITK_ok) && (tc_strcasecmp(szRefItemRevReleaseStatus, "") == 0 ) )
				//					{
				//						*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
				//						if (_iPopulateErrMsgInStack == 1)
				//						{

				//							TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1,pcRefItemRevId,
				//																				TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
				//																				TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT3 );

				//							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
				//							////////////////////////////////////////////////////////////////////
				//							if(1 == iQuickProgFlag)
				//							{
				//								tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
				//							}
				//						}
				//					}

				//					// If Master Drawing Reference linked item rev status is greater than the Changege Process Target Release status
				//					if ( (iRetCode == ITK_ok) && (tiauto_status_progression_index (szRefItemRevReleaseStatus, _StatusProgression) <  _TargetReleaseStatus.iLevel) &&
				//							(tc_strcasecmp(szRefItemRevReleaseStatus, "") != 0 ) )
				//					{
				//						// Item revision is at invalid status
				//						*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
				//						if (_iPopulateErrMsgInStack == 1)
				//						{

				//							TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\".",	    TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1, pcRefItemRevId,
				//																							TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
				//																							TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT4,
				//																							_TargetReleaseStatus.szTargetReleaseStatus );

				//							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
				//							////////////////////////////////////////////////////////////////////
				//							if(1 == iQuickProgFlag)
				//							{
				//								tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
				//							}
				//						}
				//					}
				//				}
				//			}
				//		}
				//	}
				//}
			}
		}
	}

	SAFE_MEM_free(szChildItemRev);
    SAFE_MEM_free (ptItemRevBvrs);
    SAFE_MEM_free (ptOccs);
	SAFE_MEM_free(szItemRevInChangeId);
	va_end ( vl );

    return iRetCode;
}

//validates the status of the document item revision
//The output szGenItemDisplayName_ and szDocItemDisplayName_ will be used in displaying the error message, if any
extern int ti_check_for_generic_progression(	tag_t					_tItemRev,
											tag_t					*_ptAffectedItems,
											int						_iNumAffectedItems,
											STATUS_Struct_t			_StatusProgression,
											TARGET_RELEASE_Struct_t _TargetReleaseStatus,
											char					*pcEndOfWarningMsg,
											int						_iPopulateWarningMsgInStack,
											int						_iPopulateErrMsgInStack,
											char					*pcRootTaskName,
											int						*iError_,
											TIA_ErrorMessage		**warningMsgStack_,
											TIA_ErrorMessage		**errMsgStack_ ,...)
{
	int		iRetCode			= ITK_ok;
	int		iFound				= 0;
	int		iSiteIid			= 0;
	int		iQuickProgFlag		= 0;
	int		iTotal				= 0;
	logical     lIsProE			= false;
	logical		lIsSW			= false;

	tag_t	tOwningSite					= NULLTAG;
	tag_t	tGenericItemRevTag			= NULLTAG;
	tag_t	tDocumentItemRevTag			= NULLTAG;

	char	acSiteName[SA_site_size_c+1]				= "";
	char	szGenericRelStatusName[WSO_name_size_c+1]	= "";
	char	szDocumentRelStatusName[WSO_name_size_c+1]	= "";
	char	szGenItemDisplayName[80]					= "";
	char	szDocItemDisplayName[80]					= "";
	char	*szItemRevInChangeId						= NULL;
	char	*szStackedCRName							= NULL;
	char	*pszActualGenericName						= NULL;
	char	*pszActualDocumentName						= NULL;
	char	*szStackedCRTargetStatusName				= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	*pcValue									= NULL;
	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;


	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);

	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
	// check if pro/E item	isProEType
	// if instance get generic item rev
	// get status of generic item rev
	// validate status of generic item rev with targetReleaseStatus
	if (iRetCode == ITK_ok)
		iRetCode = tiauto_checkIf_affected_isA_proEInstance_getGenericPart( _tItemRev,
												&lIsProE, &tGenericItemRevTag, szGenItemDisplayName );
	if( iRetCode == ITK_ok )
	{
		pcValue = malloc(sizeof(szGenItemDisplayName));
		tc_strcpy(pcValue,szGenItemDisplayName);
		pcValue= tc_strtok ( pcValue , "-");
	}
	if ( (iRetCode == ITK_ok) && (lIsProE == true) && (tGenericItemRevTag != NULLTAG) )
	{
		iRetCode = AOM_refresh(tGenericItemRevTag,false);
		//get the release status of the generic item revision
		iRetCode = tiauto_get_release_status(tGenericItemRevTag, szGenericRelStatusName);
		if(tc_strcmp(szGenericRelStatusName,"T8_Standard - Preliminary") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Standard - Preliminary");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Standard - Released") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Standard - Released");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Technology Prototype") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Technology Prototype");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Technology Released") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Technology Released");
		}

		//If the generic is equal to or above the target release status
		if ( (iRetCode == ITK_ok) &&
			 (tiauto_status_progression_index (szGenericRelStatusName, _StatusProgression) < _TargetReleaseStatus.iLevel))
		{
			//Check if the generic is one of the affected items in the EC
			IsExistInAffectedFolder( tGenericItemRevTag, _ptAffectedItems, _iNumAffectedItems, &iFound );
			if( iFound == 0)
			{
				//get the generic's actual display name
				//because if the Alt id is used the the actual irem/rev id will be different from the alt id
				//and the Alt id is the display id
				iRetCode = WSOM_ask_id_string(tGenericItemRevTag, &pszActualGenericName);
				//if the workflow process is DAP, check for the remote stacked DAP
				//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
				if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
				{
					iRetCode = AOM_ask_value_tag( tGenericItemRevTag, "owning_site", &tOwningSite);
					if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
					{
						//In case of DAP, if the child component is a remote object then the
						// error and warning message will be different from the general format
						iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
					}
				}
				if(iRetCode == ITK_ok)
				{
					if ( _iPopulateWarningMsgInStack ==1 )
					{
						//Check if any stacked CR exists to take care of this error,
						//add them to warnings
						//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
						if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
						{
							if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
							{
								//In case of DAP, if the child component is a remote object then the
								// error and warning message will be different from the general format
								if(tc_strcmp(szGenericRelStatusName,"DAP In Process")== 0)
								{
									//if the remote generic has "DAP In Process" status then
									//Populate the WARNING MESSAGE stack
									if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, pszActualGenericName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,acSiteName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,acSiteName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualGenericName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,acSiteName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,acSiteName,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									}
								}
								else
								{
									////if the remote generic is at lower status than "DAP In Process" status then
									//populate the error message
									if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);


									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);

									}
								}

							}
							else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
							{
								//for local item revision, check for the Stacked scenario
								iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tGenericItemRevTag, &szStackedCRName);
								if(szStackedCRName != NULL)
								{
									//if the stacked DAP is found, then the target status of the stacked DAP will be
									//same as the current target status
									szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
									tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
								}

							}
						}
						else
						{
							//for CR/CRB, check for the stacked scenario
							iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tGenericItemRevTag,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
						}
						if(tOwningSite == NULLTAG)
						{
							if( (szStackedCRTargetStatusName != NULL) &&
								(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
							{
								//Populate the WARNING MESSAGE stack
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
									tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
									tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}

							}
							else
							{
								*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;

								//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
								//because, in case of error we will get out of this function and
								//will not wait in the rule handlers, even if some of the child may be
								//in stacked CR
								if ( _iPopulateErrMsgInStack == 1 )
								{
									//Populate the ERROR MESSAGE stack
									if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
										}
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
										}
									}
								}
							}
						}
						//Clean up the two variables
						SAFE_MEM_free( szStackedCRTargetStatusName );
						SAFE_MEM_free( szStackedCRName );
					}
					else
					{
						*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;

						//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
						//because, in case of error we will get out of this function and
						//will not wait in the rule handlers, even if some of the child may be
						//in stacked CR
						if ( _iPopulateErrMsgInStack == 1 )
						{
							//Populate the ERROR MESSAGE stack
							if(iRetCode == ITK_ok && tOwningSite != NULLTAG)
							{
								//Populate the ERROR MESSAGE stack
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);

								}

							}
							else
							{
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									// Appending the Missing Item to the error_list
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
									}
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									// Appending the Missing Item to the error_list
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	//to validate SolidWorks
	if(lIsProE == false)
	{
		if (iRetCode == ITK_ok)
				iRetCode = tiauto_checkIf_affected_isA_SWConfig_getDocument( _tItemRev,
													&lIsSW, &tDocumentItemRevTag, szDocItemDisplayName );
		if( iRetCode == ITK_ok )
		{
			pcValue = malloc(sizeof(szDocItemDisplayName));
			tc_strcpy(pcValue,szDocItemDisplayName);
			pcValue= tc_strtok ( pcValue , "-");
		}

		if ( (iRetCode == ITK_ok) && (lIsSW == true) && (tDocumentItemRevTag != NULLTAG) )
		{
			iRetCode = AOM_refresh(tDocumentItemRevTag,false);
			//get the release status of the document item revision
			iRetCode = tiauto_get_release_status(tDocumentItemRevTag, szDocumentRelStatusName);
			if(tc_strcmp(szDocumentRelStatusName,"T8_Standard - Preliminary") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Standard - Preliminary");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Standard - Released") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Standard - Released");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Technology Prototype") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Technology Prototype");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Technology Released") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Technology Released");
			}

			//If the document is equal to or above the target release status
			if ( (iRetCode == ITK_ok) &&
				 (tiauto_status_progression_index (szDocumentRelStatusName, _StatusProgression) < _TargetReleaseStatus.iLevel))
			{
				//Check if the document is one of the affected items in the EC
				IsExistInAffectedFolder( tDocumentItemRevTag, _ptAffectedItems, _iNumAffectedItems, &iFound );
				if( iFound == 0)
				{
					//get the document's actual display name
					//because if the Alt id is used the the actual irem/rev id will be different from the alt id
					//and the Alt id is the display id
					iRetCode = WSOM_ask_id_string(tDocumentItemRevTag, &pszActualDocumentName);
					//if the workflow process is DAP, check for the remote stacked DAP
					//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
					if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
					{
						iRetCode = AOM_ask_value_tag( tDocumentItemRevTag, "owning_site", &tOwningSite);
						if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
						{
							//In case of DAP, if the child component is a remote object then the
							// error and warning message will be different from the general format
							iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
						}
					}
					if(iRetCode == ITK_ok)
					{
						if ( _iPopulateWarningMsgInStack ==1 )
						{
							//Check if any stacked CR exists to take care of this error,
							//add them to warnings
							//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
							if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
							{
								if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
								{
									//In case of DAP, if the child component is a remote object then the
									// error and warning message will be different from the general format
									if(tc_strcmp(szDocumentRelStatusName,"DAP In Process")== 0)
									{
										//if the remote document has "DAP In Process" status then
										//Populate the WARNING MESSAGE stack
										if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										}
									}
									else
									{
										////if the remote document is at lower status than "DAP In Process" status then
										//populate the error message
										if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);


										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);

										}
									}

								}
								else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
								{
									//for local item revision, check for the Stacked scenario
									iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tDocumentItemRevTag, &szStackedCRName);
									if(szStackedCRName != NULL)
									{
										//if the stacked DAP is found, then the target status of the stacked DAP will be
										//same as the current target status
										szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
										tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
									}

								}
							}
							else
							{
								//for CR/CRB, check for the stacked scenario
								iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tDocumentItemRevTag,
											_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
							}
							if(tOwningSite == NULLTAG)
							{
								if( (szStackedCRTargetStatusName != NULL) &&
									(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
								{
									//Populate the WARNING MESSAGE stack
									if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}

								}
								else
								{
									*iError_ = TIAUTO_DOCUMENTREV_PROGRESSING_ERROR;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
											}
										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
											}
										}
									}
								}
							}
							//Clean up the two variables
							SAFE_MEM_free( szStackedCRTargetStatusName );
							SAFE_MEM_free( szStackedCRName );
						}
						else
						{
							*iError_ = TIAUTO_DOCUMENTREV_PROGRESSING_ERROR;

							//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
							//because, in case of error we will get out of this function and
							//will not wait in the rule handlers, even if some of the child may be
							//in stacked CR
							if ( _iPopulateErrMsgInStack == 1 )
							{
								//Populate the ERROR MESSAGE stack
								if(iRetCode == ITK_ok && tOwningSite != NULLTAG)
								{
									//Populate the ERROR MESSAGE stack
									if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);

									}

								}
								else
								{
									if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
										}
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	va_end ( vl );
	SAFE_MEM_free(szItemRevInChangeId);
	SAFE_MEM_free(pszActualGenericName);
	SAFE_MEM_free(pszActualDocumentName);

	return iRetCode;

}

extern void ti_writeSuccessMsgToAuditFile(tag_t tMsgTask)
{
	tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
	tag_t		tChangeRev	= NULLTAG;
	char acDateandTime[100] = "";

    int         iRetCode = 0;
	int iNum = 0;
	int indx = 0;
	int iExtCnt = 0;
	char **pcExistingValue = NULL;
    char dateStr [30];
	errno_t err;
	struct tm tim;
    time_t now;
	now = time(NULL);
	err = localtime_s(&tim,&now);
	strftime(dateStr,30,"%b %d %Y %H:%M:%S\n",&tim);

	TI_sprintf(acDateandTime,"Execution Time :  %s",dateStr);

	iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
	if(tAuditFile == NULLTAG)
	{
		iRetCode = tiauto_get_change_item_rev(tMsgTask,&tChangeRev);
		if(tChangeRev != NULLTAG)
		{
			iRetCode = AOM_ask_value_strings(tChangeRev,"t8_progressionreport",&iExtCnt,&pcExistingValue);
		}
		AOM_refresh(tChangeRev,false);
		AOM_refresh(tChangeRev,true);
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, acDateandTime);
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "*********************************************************************************");
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "There are no progression check failures.");
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "=================================================================================");
		if(iExtCnt > 0 && pcExistingValue != NULL)
			{
				for(indx = 0;indx <iExtCnt;indx++)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++,pcExistingValue[indx]);
				}
			}
			iRetCode = AOM_save(tChangeRev);
			iRetCode = AOM_refresh(tChangeRev, false);
	}
}
// This function writes parts status progression failure messages to
// Audit file of workflow process.
extern void ti_writeErrorsMsgToAuditFile(tag_t tMsgTask, TIA_ErrorMessage *backwordProgErrMsgStack,
									  TIA_ErrorMessage *itemRevProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgErrMsgStack,
									  TIA_ErrorMessage *genericProgErrMsgStack,
									  TIA_ErrorMessage *assemblyProgWarningMsgStack,
									  TIA_ErrorMessage *genericProgWarningMsgStack,
									  TIA_ErrorMessage *masterDrawingReferenceObjectWarningMsgStack,
									  TIA_ErrorMessage *masterDrawingReferenceObjectErrMsgStack)
{
	tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
	tag_t		tChangeRev	= NULLTAG;
    IMF_file_t  tFileDescriptor = NULL;
	char acDateandTime[100] = "";

    int         iRetCode = 0;
	int iNum = 0;
	int indx = 0;
	int iExtCnt = 0;
	char **pcExistingValue = NULL;
    char dateStr [30];
	errno_t err;
	struct tm tim;
    time_t now;
	now = time(NULL);
	err = localtime_s(&tim,&now);
	strftime(dateStr,30,"%b %d %Y %H:%M:%S\n",&tim);

	TI_sprintf(acDateandTime,"Execution Time :  %s",dateStr);

	iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
	if(tAuditFile == NULLTAG)
	{
		iRetCode = tiauto_get_change_item_rev(tMsgTask,&tChangeRev);
		if(tChangeRev != NULLTAG)
		{
			iRetCode = AOM_ask_value_strings(tChangeRev,"t8_progressionreport",&iExtCnt,&pcExistingValue);
		}
		AOM_refresh(tChangeRev,false);
		AOM_refresh(tChangeRev,true);
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, acDateandTime);
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "*********************************************************************************");
		iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES ******");
			iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "*********************************************************************************");
			if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
				(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL) || (masterDrawingReferenceObjectErrMsgStack != NULL))
			{
				iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************ERROR**********************************");
				if(backwordProgErrMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Backwards Progression**********************************");
					while(backwordProgErrMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, backwordProgErrMsgStack->errMsg);
						backwordProgErrMsgStack = backwordProgErrMsgStack->next;
					}
				}
				if(itemRevProgErrMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Item Revision Progression**********************************");
					while(itemRevProgErrMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, itemRevProgErrMsgStack->errMsg);
						itemRevProgErrMsgStack = itemRevProgErrMsgStack->next;
					}
				}
				if(assemblyProgErrMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Assembly Progression**********************************");
					while(assemblyProgErrMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, assemblyProgErrMsgStack->errMsg);
						assemblyProgErrMsgStack = assemblyProgErrMsgStack->next;
					}
				}
				if(genericProgErrMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Generic Progression**********************************");
					while(genericProgErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, genericProgErrMsgStack->errMsg);
						genericProgErrMsgStack = genericProgErrMsgStack->next;
					}
				}
				if(masterDrawingReferenceObjectErrMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Master Drawing Progression**********************************");
					while(masterDrawingReferenceObjectErrMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", masterDrawingReferenceObjectErrMsgStack->iRetCode, masterDrawingReferenceObjectErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", masterDrawingReferenceObjectErrMsgStack->iRetCode, masterDrawingReferenceObjectErrMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, masterDrawingReferenceObjectErrMsgStack->errMsg);
						masterDrawingReferenceObjectErrMsgStack = masterDrawingReferenceObjectErrMsgStack->next;
					}
				}
			}
			if ( (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL) || (masterDrawingReferenceObjectWarningMsgStack != NULL))
			{
				iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************WARNING**********************************");
				if(assemblyProgWarningMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Assembly Progression**********************************");
					while(assemblyProgWarningMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, assemblyProgWarningMsgStack->errMsg);
						assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
					}
				}
				if(genericProgWarningMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Generic Progression**********************************");
					while(genericProgWarningMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, genericProgWarningMsgStack->errMsg);
						genericProgWarningMsgStack = genericProgWarningMsgStack->next;
					}
				}
				if(masterDrawingReferenceObjectWarningMsgStack != NULL)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****************************Master Drawing Progression**********************************");
					while(masterDrawingReferenceObjectWarningMsgStack != NULL)
					{
						//printf( "    %6d: %s\n", masterDrawingReferenceObjectWarningMsgStack->iRetCode, masterDrawingReferenceObjectWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", masterDrawingReferenceObjectWarningMsgStack->iRetCode, masterDrawingReferenceObjectWarningMsgStack->errMsg );
						iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, masterDrawingReferenceObjectWarningMsgStack->errMsg);
						masterDrawingReferenceObjectWarningMsgStack = masterDrawingReferenceObjectWarningMsgStack->next;
					}
				}

			}

			//printf( " \n********** END OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
			iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "*********************************************************************************");
			iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "****** END OF STATUS PROGRESSION FAILURE ERROR MESSAGES ******");
			iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "*********************************************************************************");
			iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++, "=================================================================================");
			if(iExtCnt > 0 && pcExistingValue != NULL)
			{
				for(indx = 0;indx <iExtCnt;indx++)
				{
					iRetCode = AOM_set_value_string_at(tChangeRev,"t8_progressionreport",iNum++,pcExistingValue[indx]);
				}
			}
			iRetCode = AOM_save(tChangeRev);
			iRetCode = AOM_refresh(tChangeRev, false);
	}
	else
	{
		if (iRetCode == ITK_ok)
			iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
		if (iRetCode == ITK_ok)
			iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);
		if (iRetCode == ITK_ok)
		{
			printf( " \n********** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
			TC_write_syslog  ( "Status Progression Failure Error(s): \n");
			iRetCode = IMF_write_file_line(tFileDescriptor, "\n*********************************************************************************");
			iRetCode = IMF_write_file_line(tFileDescriptor, "****** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES ******");
			iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n");
			if ( (backwordProgErrMsgStack != NULL) || (itemRevProgErrMsgStack != NULL) ||
				(assemblyProgErrMsgStack != NULL) || (genericProgErrMsgStack != NULL) )
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************ERROR**********************************\n");
				if(backwordProgErrMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Backwards Progression**********************************\n");
					while(backwordProgErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", backwordProgErrMsgStack->iRetCode, backwordProgErrMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, backwordProgErrMsgStack->errMsg);
						backwordProgErrMsgStack = backwordProgErrMsgStack->next;
					}
				}
				if(itemRevProgErrMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Item Revision Progression**********************************\n");
					while(itemRevProgErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", itemRevProgErrMsgStack->iRetCode, itemRevProgErrMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, itemRevProgErrMsgStack->errMsg);
						itemRevProgErrMsgStack = itemRevProgErrMsgStack->next;
					}
				}
				if(assemblyProgErrMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Assembly Progression**********************************\n");
					while(assemblyProgErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", assemblyProgErrMsgStack->iRetCode, assemblyProgErrMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, assemblyProgErrMsgStack->errMsg);
						assemblyProgErrMsgStack = assemblyProgErrMsgStack->next;
					}
				}
				if(genericProgErrMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Generic Progression**********************************\n");
					while(genericProgErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", genericProgErrMsgStack->iRetCode, genericProgErrMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, genericProgErrMsgStack->errMsg);
						genericProgErrMsgStack = genericProgErrMsgStack->next;
					}
				}
				if(masterDrawingReferenceObjectErrMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Master Drawing Reference linked Item Revision status Check**********************************\n");
					while(masterDrawingReferenceObjectErrMsgStack != NULL)
					{
						printf( "    %6d: %s\n", masterDrawingReferenceObjectErrMsgStack->iRetCode, masterDrawingReferenceObjectErrMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", masterDrawingReferenceObjectErrMsgStack->iRetCode, masterDrawingReferenceObjectErrMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, masterDrawingReferenceObjectErrMsgStack->errMsg);
						masterDrawingReferenceObjectErrMsgStack = masterDrawingReferenceObjectErrMsgStack->next;
					}
				}
			}
			if ( (assemblyProgWarningMsgStack != NULL) || (genericProgWarningMsgStack != NULL))
			{
				iRetCode = IMF_write_file_line(tFileDescriptor, "****************************WARNING**********************************\n");
				if(assemblyProgWarningMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Assembly Progression**********************************\n");
					while(assemblyProgWarningMsgStack != NULL)
					{
						printf( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", assemblyProgWarningMsgStack->iRetCode, assemblyProgWarningMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, assemblyProgWarningMsgStack->errMsg);
						assemblyProgWarningMsgStack = assemblyProgWarningMsgStack->next;
					}
				}
				if(genericProgWarningMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Generic Progression**********************************\n");
					while(genericProgWarningMsgStack != NULL)
					{
						printf( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", genericProgWarningMsgStack->iRetCode, genericProgWarningMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, genericProgWarningMsgStack->errMsg);
						genericProgWarningMsgStack = genericProgWarningMsgStack->next;
					}
				}
				if(masterDrawingReferenceObjectWarningMsgStack != NULL)
				{
					iRetCode = IMF_write_file_line(tFileDescriptor, "****************************Master Drawing Reference linked Item Revision status Check**********************************\n");
					while(masterDrawingReferenceObjectWarningMsgStack != NULL)
					{
						printf( "    %6d: %s\n", masterDrawingReferenceObjectWarningMsgStack->iRetCode, masterDrawingReferenceObjectWarningMsgStack->errMsg );
						TC_write_syslog( "    %6d: %s\n", masterDrawingReferenceObjectWarningMsgStack->iRetCode, masterDrawingReferenceObjectWarningMsgStack->errMsg );
						iRetCode = IMF_write_file_line(tFileDescriptor, masterDrawingReferenceObjectWarningMsgStack->errMsg);
						masterDrawingReferenceObjectWarningMsgStack = masterDrawingReferenceObjectWarningMsgStack->next;
					}
				}

			}

			printf( " \n********** END OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
			iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************");
			iRetCode = IMF_write_file_line(tFileDescriptor, "****** END OF STATUS PROGRESSION FAILURE ERROR MESSAGES ******");
			iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n\n");
		}
		if (iRetCode == ITK_ok)
			iRetCode = IMF_close_file(tFileDescriptor);
	}

    EMH_clear_errors();
}


extern void IsExistInAffectedFolder( tag_t tInput, tag_t* ptArray, int iNum, int *iFound )
{
    int inx = 0;

	TI_DEBUG_PRINT1( "%s\n", "Enter - > IsExistInAffectedFolder" );

    *iFound = 0;

    if( iNum == 0 || ptArray == NULL )
    {
        return;
    }

    for( inx = 0; inx < iNum; inx++ )
    {
        if( ptArray[inx] == tInput )
        {
            *iFound = 1;
            break;
        }
    }

    TI_DEBUG_PRINT1( "%s\n", "Exit -> IsExistInAffectedFolder" );
}


//**********************************************************************************************
//Function : check_status_of_Alternates.
//This function takes in the parent item revisions and checks the
// status of the alternates, if the assembly progression errors are found in the alternates also
// the error is thrown to the user along with the remaining progression errors.
//**********************************************************************************************
int check_status_of_Alternates(		tag_t						_tParentBVR,
									tag_t						_tOccurrence,
									tag_t						_tPreferredChild,
									char						*szItemRevInChangeId,
									tag_t						*_ptAffectedItems,
									int							_iNumAffectedItems,
									STATUS_Struct_t				_StatusProgression,
									TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
									char						*pcEndOfWarningMsg,
									int							_iPopulateWarningMsgInStack,
									int							_iPopulateErrMsgInStack,
									char						*pcRootTaskName,
									int							iLevel,
									int							*iError_,
									TIA_ErrorMessage			**warningMsgStack_,
									TIA_ErrorMessage			**errMsgStack_,...)
{
	int iRetCode = ITK_ok;
	int iCount = 0;
	int iNoAlternates = 0;
	tag_t tAlternate = NULLTAG;
	tag_t *ptAltItems = NULL;
	tag_t *pAltViews = NULL;
	int		iQuickProgFlag			= 0;
	int		iFound					= 0;
	int		iSiteIid				= 0;
	int		iTotal					= 0;

	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= "";

	logical lIsOEM				= false;

	TIA_ErrorMessage			*AlternateWarningMsgStack = NULL;
	TIA_ErrorMessage			*AlternateErrMsgStack  = NULL;

	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);

	}
	else
	{
		va_end(vl);
	}

	//iRetCode = PS_list_alternates (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews); //Deprecated This will be obsoleted. Use PS_list_substitutes
	iRetCode = PS_list_substitutes (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews);
	if(iRetCode == ITK_ok && iNoAlternates > 0)
	{
		for (iCount = 0; (iCount < iNoAlternates) && (iRetCode == ITK_ok) ;iCount++)
		{
			tAlternate = ptAltItems[iCount];
			if( tAlternate != NULLTAG && _tPreferredChild != tAlternate)
			{
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = AOM_refresh(tAlternate,false);
					//get the target release status of the child component
					iRetCode = tiauto_get_release_status(tAlternate, szChildRelStatus);
					if(tc_strcmp(szChildRelStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Released");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Released");
					}
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = WSOM_ask_id_string( tAlternate, &szChildItemRev);
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					//check whether the child component is of _OEM type
					iRetCode = tiauto_check_if_itemType_isOEM(tAlternate, &lIsOEM);
					if ( iRetCode == ITK_ok )
					{
						//1.If the child component is OEM then it has to be in "Cad Release Only" status
						//So whenever we find the above condition, it will be considered as an ERROR,
						//no matter stacked CR exists or not, so we will not care about the flag
						if( lIsOEM == true )
						{
							if(tc_strcasecmp(szChildRelStatus, CRO)!= 0)
							{
								*iError_ = TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR;
								if(_iPopulateErrMsgInStack == 1)
								{
									TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s",
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1, szChildItemRev,
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR, szErrorString);
								}
							}
						}
						//2. check if child item revisions have obsolete status.
						//if obsolete then error out
						else if(!tc_strcmp(szChildRelStatus,OBSOLETE))
						{
							*iError_ = TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString,"Substitute Part Error: %s \"%s\" %s \"%s\" %s",
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
								TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							}

						}
						//3.Verifying whether child component rev is at SAME or HIGHER status than
						//target release status of Change process.
						//If yes, accept the child component and continue to verify another child rev.
						else if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
						{
							//If not as above mentioned, verify if the child component rev is part of
							//Affected OR Solution Items folders of Change Process.
							//If yes, accept and continue to verify another child rev.
							IsExistInAffectedFolder( tAlternate, _ptAffectedItems, _iNumAffectedItems, &iFound );
							if( iFound == 0)
							{
								//if the workflow process is DAP then check for the remote stacked
								//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
								if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
								{
									iRetCode = AOM_ask_value_tag( tAlternate, "owning_site", &tOwningSite);
									if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
									{
										//In case of DAP, if the child component is a remote object then the
										// error and warning message will be different from the general format
										iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
									}
								}
								if ( _iPopulateWarningMsgInStack ==1 )
								{
									//Check if any stacked CR exists to take care of this error,
									//add them to warnings
									//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
									if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
									{
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											if(tc_strcmp(szChildRelStatus,"DAP In Process")== 0)
											{
												//if the remote item revision has "DAP In Process" status then
												//Populate the WARNING MESSAGE stack
												TI_sprintf(szErrorString, "Substitute Part Warning: %s \"%s\" %s \"%s\" %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
															szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
												tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}
											else
											{
												//if the remote item revision has a lower status than the "DAP In Process"
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}
										}
										else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
										{
											//for the local site, check for the stacked DAP
											iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tAlternate, &szStackedCRName);
											//if stacked DAP is found, then the stacked target status will be same as
											//as the current target status
											if(szStackedCRName != NULL)
											{
												szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
												tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
											}
										}
									}
									else
									{
										//In case of CR/CRB, check for the stacked scenario
										iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tAlternate,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
									}
									if(tOwningSite == NULLTAG)
									{
										if( (szStackedCRTargetStatusName != NULL) &&
											(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
										{
											//Populate the WARNING MESSAGE stack
											TI_sprintf(szErrorString, "Substitute Part Warning: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
										}
										else
										{
											*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

											//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
											//because, in case of error we will get out of this function and
											//will not wait in the rule handlers, even if some of the child may be
											//in stacked CR
											if ( _iPopulateErrMsgInStack == 1 )
											{
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
												// Appending the Missing Item to the error_list
												if(1 == iQuickProgFlag)
												{
													tiauto_Store_wsom_tags(error_list,&iTotal,tAlternate);
												}
											}
										}

									}
									//Clean up the two variables
									SAFE_MEM_free( szStackedCRTargetStatusName );
									SAFE_MEM_free( szStackedCRName );

								}
								else
								{
									*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);

										}
										else
										{
											TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tAlternate);
											}
										}
									}
								}

							}
						}
					}

				}
				if ( iRetCode == ITK_ok && iLevel != 0)
				{
					iRetCode = ti_check_for_assembly_progression( tAlternate, _ptAffectedItems, _iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,iLevel-1, iError_,
																&AlternateWarningMsgStack, &AlternateErrMsgStack, iQuickProgFlag, error_list);

				}
			}
		}
	}

	if(AlternateWarningMsgStack != NULL)
	{
		while(AlternateWarningMsgStack)
		{
			if(tc_strncasecmp(AlternateWarningMsgStack->errMsg,"Substitute Part Warning:",24) != 0)
			{
				TI_sprintf(szErrorString,"Substitute Part Warning: %s",AlternateWarningMsgStack->errMsg);
			}
			else
			{
				TI_sprintf(szErrorString,"%s",AlternateWarningMsgStack->errMsg);
			}
			tiauto_writeErrorMsgToStack(warningMsgStack_,AlternateWarningMsgStack->iRetCode, szErrorString);
			AlternateWarningMsgStack = AlternateWarningMsgStack->next;
		}
	}
	if(AlternateErrMsgStack != NULL)
	{
		while(AlternateErrMsgStack)
		{
			if(tc_strncasecmp(AlternateErrMsgStack->errMsg,"Substitute Part Error:",22) != 0)
			{
				TI_sprintf(szErrorString,"Substitute Part Error: %s",AlternateErrMsgStack->errMsg);
			}
			else
			{
				TI_sprintf(szErrorString,"%s",AlternateErrMsgStack->errMsg);
			}
			tiauto_writeErrorMsgToStack(errMsgStack_,AlternateErrMsgStack->iRetCode, szErrorString);
			AlternateErrMsgStack = AlternateErrMsgStack->next;
		}
	}
	tiauto_clearErrorMsgStack(AlternateWarningMsgStack);
	AlternateWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(AlternateErrMsgStack);
	AlternateErrMsgStack = NULL;

	SAFE_MEM_free(ptAltItems);
	SAFE_MEM_free(pAltViews);
	SAFE_MEM_free(szChildItemRev);

	return iRetCode;
}

//to find out the list of the parent item revs present in the Affected & Solution item folder
//where the error item revision is used
int ti_where_used_in_BOM(	tag_t			tErrorItem,
						tag_t			*_ptAffectedItems,
						int				_iNumAffectedItems,
						char			*szItemRevs,
						TIA_ErrorItems  **sBOMItemRevs)
{
	int		iRetCode				= 0;
    int		iCount					= 0;
	int		iFound					= 0;
	int		iParents				= 0;
	int		*piLevels				= 0;
	tag_t	*ptParents				= NULL;
	char	*szItemRevInChangeId	= NULL;
	char szItemRevIdTemp[TIAUTO_error_message_len+1] = "";
	int		iPTempParents = 0;
	int		*piPTempLevels = NULL;
	tag_t	*ptPTempParents = NULL;


	tc_strcpy(szItemRevIdTemp,szItemRevs);
	//get all the parent item revisions
	iRetCode = PS_where_used_precise (tErrorItem,1,&iParents,&piLevels,&ptParents);
	for(iCount =0;iCount<iParents;iCount++)
	{
		iFound = 0;
		//check whether the parent item rev is present in the Affected & Solution item folder
		IsTagExistsInArray( ptParents[iCount], _ptAffectedItems, _iNumAffectedItems, &iFound );
		//get the parent item rev id
		iRetCode = WSOM_ask_id_string( ptParents[iCount], &szItemRevInChangeId);
		if((tc_strcmp(szItemRevs,"")==0 )&& (tc_strcmp(szItemRevIdTemp,"")!= 0) )
			tc_strcpy(szItemRevs,szItemRevIdTemp);
		if(tc_strcmp(szItemRevs,"")!=0)
		{
			tc_strcat(szItemRevs,"-->");
		}
		tc_strcat(szItemRevs,szItemRevInChangeId);

		if(iFound == 0)
		{
			//if the parent item rev not found in the Affected & Solution item folder
			iRetCode = ti_where_used_in_BOM(ptParents[iCount],_ptAffectedItems, _iNumAffectedItems,szItemRevs,sBOMItemRevs);
		}
		else if(iFound == 1)
		{
			iPTempParents = 0;
			piPTempLevels = NULL;
			ptPTempParents = NULL;

			//if the parent item rev found in the Affected & Solution item folder, then
			//store it in the stack
			tiauto_writeErrorItemsToStack(sBOMItemRevs,szItemRevs);
			iRetCode = PS_where_used_precise (tErrorItem,1,&iPTempParents,&piPTempLevels,&ptPTempParents);
			if(iPTempParents > 1)
			{
				tc_strcpy(szItemRevs,szItemRevIdTemp);
				SAFE_MEM_free(piPTempLevels);
				SAFE_MEM_free(ptPTempParents);
				continue;
			}
			SAFE_MEM_free(piPTempLevels);
			SAFE_MEM_free(ptPTempParents);
		}
		tc_strcpy(szItemRevs,"");

	}

	SAFE_MEM_free(piLevels);
    SAFE_MEM_free (ptParents);
	SAFE_MEM_free(szItemRevInChangeId);

    return iRetCode;
}

//**********************************************************************************************
//Function : check_product_rev_objects
//This function takes in the item revisions and checks type of the item revision.
// if the object is TI_Product Revision then retrieve the master drawing attributes
// if attrbutes are missing then store those items in a error list, to display it in a folder
//**********************************************************************************************
extern int ti_Verify_MasterDrawingInfo( 	tag_t					_tItemRev,
											tag_t					*_ptAffectedItems,
											int						_iNumAffectedItems,
											STATUS_Struct_t				_StatusProgression,
											TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
											int						_iPopulateErrMsgInStack,
											int						*iError_,
											TIA_ErrorMessage		**warningMsgStack_,
											TIA_ErrorMessage		**errMsgStack_, ...)
{
	int		iRetCode									= ITK_ok;
	int		iCount										= 0;
	int		ix											= 0;
	int		iQuickProgFlag								= 0;
	int		iTotal										= 0;	
	int		iItemRevBvrCount							= 0;
	int		iNumOccs									= 0;
	int		iCount1										= 0;
	int		iNoAlternates								= 0;

	char	*pcMasterDrawing							= NULL;
	char	*pcMasterDrawingRev							= NULL;	
	char	szRevType[ITEM_type_size_c+1]				= "";
	char	*szItemRevID								= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	szChildRelStatus[WSO_name_size_c+1]			= "";

	tag_t	tRelationType								= NULLTAG;
	tag_t	tMasterDrawingRef							= NULLTAG;
	tag_t	tChildItem									= NULLTAG;
	tag_t	tChildBomView								= NULLTAG;
	tag_t	tAlternate									= NULLTAG;

	tag_t	*ptSecObjects								= NULLTAG;
	tag_t	*ptItemRevBvrs = NULL;
	tag_t	*ptOccs = NULL;
	tag_t	*ptAltItems = NULL;
	tag_t	*pAltViews = NULL;

	logical lHasAlternates = false;

	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);
	//gets the item revision id
	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevID);
	if ( iRetCode == ITK_ok)
		//gets the type of the item revision
		iRetCode = ITEM_ask_rev_type( _tItemRev, szRevType);
	//if the object type is TI Product Item Revision then proceed
	if(  ( iRetCode == ITK_ok ) &&
		 ( tc_strcmp( szRevType , "TI_Product Revision" ) == 0 ) )
	{
		iRetCode = tiauto_get_release_status(_tItemRev,szChildRelStatus);
		if(tc_strcmp(szChildRelStatus,"T8_Standard - Preliminary") == 0)
		{
			tc_strcpy(szChildRelStatus, "Standard - Preliminary");
		}
		else if(tc_strcmp(szChildRelStatus,"T8_Standard - Released") == 0)
		{
			tc_strcpy(szChildRelStatus, "Standard - Released");
		}
		else if(tc_strcmp(szChildRelStatus,"T8_Technology Prototype") == 0)
		{
			tc_strcpy(szChildRelStatus, "Technology Prototype");
		}
		else if(tc_strcmp(szChildRelStatus,"T8_Technology Released") == 0)
		{
			tc_strcpy(szChildRelStatus, "Technology Released");
		}

		if(tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
		{
			//find the relation between master form and item revision
			iRetCode = GRM_find_relation_type ("IMAN_master_form", &tRelationType);
			if(tRelationType != NULLTAG)
				iRetCode = GRM_list_secondary_objects_only( _tItemRev, tRelationType, &iCount, &ptSecObjects);
			if( iRetCode == ITK_ok && ptSecObjects != NULLTAG )
			{
				for( ix = 0; ix < iCount ; ix++)
				{
					//retrieve all the master drawing attributes
					iRetCode = AOM_ask_value_string ( ptSecObjects[ix], "t8_t1a1masterdrawing", &pcMasterDrawing);
					iRetCode = AOM_ask_value_string ( ptSecObjects[ix], "t8_t1a1masterdrawingrev", &pcMasterDrawingRev);
					iRetCode = AOM_ask_value_tag ( ptSecObjects[ix], "t8_t1a1masterdrawingref", &tMasterDrawingRef);

					//attribute values are missing then display warning message
					//and store those objects in an error list
					if( ( (pcMasterDrawing == NULL ) || (tc_strcmp( pcMasterDrawing , "") == 0 ) ) &&
						( ( pcMasterDrawingRev == NULL) || (tc_strcmp( pcMasterDrawingRev, "" ) == 0)) &&
						 tMasterDrawingRef == NULLTAG )
					{
						tiauto_Store_wsom_tags(error_list,&iTotal,_tItemRev);
						//IsExistInAffectedFolder( _tItemRev, _ptAffectedItems, _iNumAffectedItems, &iFound );
						*iError_ = TIAUTO_MASTER_DRAWING_ATTRIBUTES_NOT_FOUND;

						//If _iPopulateErrMsgInStack == 1, then populate warning message
						if( _iPopulateErrMsgInStack == 1 )
						{
							TI_sprintf(szErrorString, "%s%s", TIAUTO_MASTER_DRAWING_ATTRIBUTES_WARNING_TEXT ,szItemRevID);
							tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_MASTER_DRAWING_ATTRIBUTES_NOT_FOUND, szErrorString);
						}
					}
					if ( (_iPopulateErrMsgInStack == 0) && (*iError_ != 0) )
					{
						break;
					}
				}
			}
		}
	}


	
	if ( iRetCode == ITK_ok)
			iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);
	//If the item doesn't have a precise BOM, we need not proceed further
	if ( (iRetCode == ITK_ok) && iItemRevBvrCount > 0 )
	{
		iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
		// If the BVR does not have any child component, no need to proceed further
		for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
		{
			tChildItem = NULLTAG;
			tChildBomView = NULLTAG;

			lHasAlternates = false;

			iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],&tChildItem, &tChildBomView);
			if ( tChildItem != NULLTAG)
			{
				iRetCode = ti_Verify_MasterDrawingInfo( tChildItem, _ptAffectedItems,_iNumAffectedItems, _StatusProgression,_TargetReleaseStatus,
													     _iPopulateErrMsgInStack,iError_, warningMsgStack_,
													     errMsgStack_, 1,error_list);

				//iRetCode = PS_ask_has_alternates  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates ); //Deprecated This will be obsoleted. Use PS_ask_has_substitutes
				iRetCode = PS_ask_has_substitutes  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates );
				if ( iRetCode == ITK_ok && lHasAlternates == true)
				{
					/*iRetCode = check_Master_Drawing_Info_of_Alternates(	ptItemRevBvrs[0], ptOccs[iCount],
																		tChildItem, _ptAffectedItems,_iNumAffectedItems,
																		_iPopulateErrMsgInStack,iError_, warningMsgStack_,
																		errMsgStack_, 1,&error_list);

					*/
					//iRetCode = PS_list_alternates (ptItemRevBvrs[0],ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews); //Deprecated This will be obsoleted. Use PS_list_substitutes
					iRetCode = PS_list_substitutes (ptItemRevBvrs[0],ptOccs[iCount],&iNoAlternates,&ptAltItems, &pAltViews);
					if(iRetCode == ITK_ok && iNoAlternates > 0)
					{
				
						for (iCount1 = 0; (iCount1 < iNoAlternates) && (iRetCode == ITK_ok) ;iCount1++)
						{
							tAlternate = ptAltItems[iCount1];
							if( tAlternate != NULLTAG && tChildItem != tAlternate)
							{
								iRetCode = ti_Verify_MasterDrawingInfo( tAlternate, _ptAffectedItems,_iNumAffectedItems, _StatusProgression,_TargetReleaseStatus,
																		_iPopulateErrMsgInStack,iError_, warningMsgStack_,
																		errMsgStack_, 1,error_list);
							}
						}
					}
				}
			}
		}

	}
	SAFE_MEM_free(szItemRevID);
	va_end ( vl );

	return iRetCode;
}



//If the part is an assembly part, then this function validates the present statuses of
//each and every component part of the assembly (same rev progression w.r.t target release
//status of change process. In the present implementation, there is only ONE BOM and it should
//be PRECISE. So we are ignoring any NON-PRECISE BOMs and more than one BOMs
extern int ti_check_for_assembly_progression_pci(	tag_t						_tItemRev,
												tag_t						*_ptAffectedItems,
												int							_iNumAffectedItems,
												STATUS_Struct_t				_StatusProgression,
												TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
												char						*pcEndOfWarningMsg,
												int							_iPopulateWarningMsgInStack,
												int							_iPopulateErrMsgInStack,
												char						*pcRootTaskName,
												int							iLevel,
												int							*iError_,
												TIA_ErrorMessage			**warningMsgStack_,
												TIA_ErrorMessage			**errMsgStack_,...)
{
    int		iRetCode				= 0;
    int		iCount					= 0;
    int		iItemRevBvrCount		= 0;
    int		iNumOccs				= 0;
	int		iFound					= 0;
	int		iSiteIid				= 0;
	int		iQuickProgFlag			= 0;
	int		iTotal					= 0;

    tag_t   *ptItemRevBvrs			= NULL;
    tag_t   *ptOccs					= NULL;
    tag_t   tChildItem				= NULLTAG;
	tag_t	tChildBomView			= NULLTAG;
	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
    char	szParentRelStatus[WSO_name_size_c+1]		= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	*szItemRevInChangeId						= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= "";

    logical lIsPrecise			= false;
	logical lIsOEM				= false;
	logical lHasAlternates		= false;

	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);

    if(iLevel != 0)
	{
		iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
		if ( iRetCode == ITK_ok)
			iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);
		if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
		{
			//As per existing implementation, there is only one BVR in the system, So always take the 1st one
			iRetCode = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
			if ( (iRetCode == ITK_ok) && (lIsPrecise == false) )
			{
				*iError_ = TIAUTO_IMPRECISE_BVR_FOUND;

				//If _iPopulateErrMsgInStack == 1, then populate error message
				if(_iPopulateErrMsgInStack == 1)
				{
					TI_sprintf(szErrorString, "%s %s", szItemRevInChangeId, TIAUTO_IMPRECISE_BVR_FOUND_TEXT);
					tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_IMPRECISE_BVR_FOUND, szErrorString);
				}
			}
		}
		if ( iRetCode == ITK_ok && _tItemRev != NULLTAG)
		{
			//get the target release status of the child component
			iRetCode = tiauto_get_release_status(_tItemRev, szParentRelStatus);
			if(tc_strcmp(szParentRelStatus,"T8_Standard - Preliminary") == 0)
			{
				tc_strcpy(szParentRelStatus, "Standard - Preliminary");
			}
			else if(tc_strcmp(szParentRelStatus,"T8_Standard - Released") == 0)
			{
				tc_strcpy(szParentRelStatus, "Standard - Released");
			}
			else if(tc_strcmp(szParentRelStatus,"T8_Technology Prototype") == 0)
			{
				tc_strcpy(szParentRelStatus, "Technology Prototype");
			}
			else if(tc_strcmp(szParentRelStatus,"T8_Technology Released") == 0)
			{
				tc_strcpy(szParentRelStatus, "Technology Released");
			}
		}

		//If the item doesn't have a precise BOM, we need not proceed further
		if ( (iRetCode == ITK_ok) && (*iError_ == 0) && iItemRevBvrCount > 0 )
		{
			iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
			// If the BVR does not have any child component, no need to proceed further
			for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
			{
				tChildItem = NULLTAG;
				tChildBomView = NULLTAG;
				tc_strcpy ( szChildRelStatus, "" );
				szChildItemRev = NULL;
				lHasAlternates = false;

				iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],
													 &tChildItem, &tChildBomView);
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					iRetCode = AOM_refresh(tChildItem,false);
					//get the target release status of the child component
					iRetCode = tiauto_get_release_status(tChildItem, szChildRelStatus);
					if(tc_strcmp(szChildRelStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Released");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Released");
					}
				}
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					iRetCode = WSOM_ask_id_string( tChildItem, &szChildItemRev);
				}
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					//check whether the child component is of _OEM type
					iRetCode = tiauto_check_if_itemType_isOEM(tChildItem, &lIsOEM);
					if ( iRetCode == ITK_ok )
					{
						TI_DEBUG_PRINT1("Child Item Status Type : %s\n", szChildRelStatus);

						//1. check if child item revisions have obsolete status.
						//if obsolete then error out
						if(!tc_strcmp(szChildRelStatus,OBSOLETE))
						{
							*iError_ = TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString,"%s \"%s\" %s \"%s\" %s",
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
								TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							}

						}
						//2.If the child component is OEM then it has to be in "Cad Release Only" status
						//So whenever we find the above condition, it will be considered as an ERROR,
						//no matter stacked CR exists or not, so we will not care about the flag
						else if( lIsOEM == true )
						{
							if(tc_strcasecmp(szChildRelStatus, CRO)!= 0)
							{
								//IsExistInAffectedFolder( tChildItem, _ptAffectedItems, _iNumAffectedItems, &iFound );
								if( iFound == 0)
								{
									if(tc_strcmp(pcRootTaskName,"9_00 CRO - CAD Release Only") == 0)
									{
										//Populate the ERROR MESSAGE stack
										TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
									}
									else
									{
										*iError_ = TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR;
										if(_iPopulateErrMsgInStack == 1)
										{
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1, szChildItemRev,
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
													TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR, szErrorString);
										}
									}
								}
							}
							else
							{

								/*if( iFound == 0)
								{
									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);

								}*/
							}
						}
						//3.Verifying whether child component rev is at SAME or HIGHER status than
						//target release status of Change process.
						//If yes, accept the child component and continue to verify another child rev.
						else if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
						{
							//If not as above mentioned, verify if the child component rev is part of
							//Affected OR Solution Items folders of Change Process.
							//If yes, accept and continue to verify another child rev.
							IsExistInAffectedFolder( tChildItem, _ptAffectedItems, _iNumAffectedItems, &iFound );
							if( iFound == 0)
							{
								//if the workflow process is DAP then check for the remote stacked
								//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)

									iRetCode = AOM_ask_value_tag( tChildItem, "owning_site", &tOwningSite);
									if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
									{
										//In case of DAP, if the child component is a remote object then the
										// error and warning message will be different from the general format
										iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
									}
								if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
								{
								}
								if ( _iPopulateWarningMsgInStack ==1 )
								{
									//Check if any stacked CR exists to take care of this error,
									//add them to warnings
									//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
									if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
									{
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											/*if(tc_strcmp(szChildRelStatus,"DAP In Process")== 0)
											{
												//if the remote item revision has "DAP In Process" status then
												//Populate the WARNING MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
															szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
												tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}
											else
											{
												//if the remote item revision has a lower status than the "DAP In Process"
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);


											}*/
										}
										else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
										{
											//for the local site, check for the stacked DAP
											iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tChildItem, &szStackedCRName);
											//if stacked DAP is found, then the stacked target status will be same as
											//as the current target status
											if(szStackedCRName != NULL)
											{
												szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
												tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
											}

										}
									}
									else
									{
										//In case of CR/CRB, check for the stacked scenario
										iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tChildItem,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
									}
									if(tOwningSite == NULLTAG)
									{
										if( (szStackedCRTargetStatusName != NULL) &&
											(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
										{
											//Populate the WARNING MESSAGE stack
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
										}
										else if(tc_strcmp(szParentRelStatus,szChildRelStatus) == 0)
										{
										}
										else
										{
											*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

											//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
											//because, in case of error we will get out of this function and
											//will not wait in the rule handlers, even if some of the child may be
											//in stacked CR
											if ( _iPopulateErrMsgInStack == 1 )
											{
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
												// Appending the Missing Item to the error_list
												if(1 == iQuickProgFlag)
												{
													tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
												}
											}
										}
									}
									//Clean up the two variables
									SAFE_MEM_free( szStackedCRTargetStatusName );
									SAFE_MEM_free( szStackedCRName );
								}
								else
								{
									*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											/*TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											*/
										}
										else
										{
											TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tChildItem);
											}
										}

									}
								}

							}
						}
					}
				}

				//Break if _iPopulateErrMsgInStack == 0 and *iError_ != 0
				//This will be for the Stacked CR rule handler
				//if the assembly progression error can n't be taken care of by Stacked CR then no need to wait
				//for the stacked CR as it will be reported in the next Progression action handler and
				//either the task will be demoted to 2_30 or the workflow will be rejected
				if ( (_iPopulateErrMsgInStack == 0) && (*iError_ != 0) )
				{
					break;
				}
				//check the status of the Alternates
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{
					//iRetCode = PS_ask_has_alternates  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates ); //Deprecated This will be obsoleted. Use PS_ask_has_substitutes
					iRetCode = PS_ask_has_substitutes  (  ptItemRevBvrs[0], ptOccs[iCount], &lHasAlternates );
					if ( iRetCode == ITK_ok && lHasAlternates == true)
					{
						iRetCode = check_status_of_Alternates_pci(	ptItemRevBvrs[0], ptOccs[iCount],
																tChildItem,szItemRevInChangeId,
																_ptAffectedItems,_iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,
																iLevel, iError_,
																warningMsgStack_, errMsgStack_, iQuickProgFlag, error_list);
					}
				}
				//if the "iLevel", call this recursive function again.
				//for the recursive function the "iLevel" value will be "iLevel - 1"
				if(iRetCode == ITK_ok && tChildItem != NULLTAG && (iLevel != 0) )
				{
					iRetCode = ti_check_for_assembly_progression_pci( tChildItem, _ptAffectedItems, _iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,iLevel-1, iError_,
																warningMsgStack_, errMsgStack_, iQuickProgFlag, error_list);
				}
			}
		}
	}

	SAFE_MEM_free(szChildItemRev);
    SAFE_MEM_free (ptItemRevBvrs);
    SAFE_MEM_free (ptOccs);
	SAFE_MEM_free(szItemRevInChangeId);
	va_end ( vl );

    return iRetCode;
}

//validates the status of the document item revision
//The output szGenItemDisplayName_ and szDocItemDisplayName_ will be used in displaying the error message, if any
extern int ti_check_for_generic_progression_pci(	tag_t					_tItemRev,
											tag_t					*_ptAffectedItems,
											int						_iNumAffectedItems,
											STATUS_Struct_t			_StatusProgression,
											TARGET_RELEASE_Struct_t _TargetReleaseStatus,
											char					*pcEndOfWarningMsg,
											int						_iPopulateWarningMsgInStack,
											int						_iPopulateErrMsgInStack,
											char					*pcRootTaskName,
											int						*iError_,
											TIA_ErrorMessage		**warningMsgStack_,
											TIA_ErrorMessage		**errMsgStack_ ,...)
{
	int		iRetCode			= ITK_ok;
	int		iFound				= 0;
	int		iSiteIid			= 0;
	int		iQuickProgFlag		= 0;
	int		iTotal				= 0;
	logical     lIsProE			= false;
	logical		lIsSW			= false;

	tag_t	tOwningSite					= NULLTAG;
	tag_t	tGenericItemRevTag			= NULLTAG;
	tag_t	tDocumentItemRevTag			= NULLTAG;

	char	acSiteName[SA_site_size_c+1]				= "";
	char	szGenericRelStatusName[WSO_name_size_c+1]	= "";
	char	szDocumentRelStatusName[WSO_name_size_c+1]	= "";
	char	szGenItemDisplayName[80]					= "";
	char	szDocItemDisplayName[80]					= "";
	char	*szItemRevInChangeId						= NULL;
	char	*szStackedCRName							= NULL;
	char	*pszActualGenericName						= NULL;
	char	*pszActualDocumentName						= NULL;
	char	*szStackedCRTargetStatusName				= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	*pcValue									= NULL;
	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;


	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);
	iRetCode = WSOM_ask_id_string( _tItemRev, &szItemRevInChangeId);
	// check if pro/E item	isProEType
	// if instance get generic item rev
	// get status of generic item rev
	// validate status of generic item rev with targetReleaseStatus
	if (iRetCode == ITK_ok)
		iRetCode = tiauto_checkIf_affected_isA_proEInstance_getGenericPart( _tItemRev,
												&lIsProE, &tGenericItemRevTag, szGenItemDisplayName );
	if( iRetCode == ITK_ok )
	{
		pcValue = malloc(sizeof(szGenItemDisplayName));
		tc_strcpy(pcValue,szGenItemDisplayName);
		pcValue= tc_strtok ( pcValue , "-");
	}
	if ( (iRetCode == ITK_ok) && (lIsProE == true) && (tGenericItemRevTag != NULLTAG) )
	{
		iRetCode = AOM_refresh(tGenericItemRevTag,false);
		//get the release status of the generic item revision
		iRetCode = tiauto_get_release_status(tGenericItemRevTag, szGenericRelStatusName);
		if(tc_strcmp(szGenericRelStatusName,"T8_Standard - Preliminary") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Standard - Preliminary");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Standard - Released") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Standard - Released");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Technology Prototype") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Technology Prototype");
		}
		else if(tc_strcmp(szGenericRelStatusName,"T8_Technology Released") == 0)
		{
			tc_strcpy(szGenericRelStatusName, "Technology Released");
		}
					
		//If the generic is equal to or above the target release status
		if ( (iRetCode == ITK_ok) &&
			 (tiauto_status_progression_index (szGenericRelStatusName, _StatusProgression) < _TargetReleaseStatus.iLevel))
		{
			//Check if the generic is one of the affected items in the EC
			IsExistInAffectedFolder( tGenericItemRevTag, _ptAffectedItems, _iNumAffectedItems, &iFound );
			if( iFound == 0)
			{
				//get the generic's actual display name
				//because if the Alt id is used the the actual irem/rev id will be different from the alt id
				//and the Alt id is the display id
				iRetCode = WSOM_ask_id_string(tGenericItemRevTag, &pszActualGenericName);

				iRetCode = AOM_ask_value_tag( tGenericItemRevTag, "owning_site", &tOwningSite);
				if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
				{
					//In case of DAP, if the child component is a remote object then the
					// error and warning message will be different from the general format
					iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
				}
				//if the workflow process is DAP, check for the remote stacked DAP
				//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
				if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
				{

				}
				if(iRetCode == ITK_ok)
				{
					if ( _iPopulateWarningMsgInStack ==1 )
					{
						//Check if any stacked CR exists to take care of this error,
						//add them to warnings
						//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)

						if(tOwningSite != NULLTAG)
						{
							if(tc_strcmp(szGenericRelStatusName,PRODUCTION_RELEASED) == 0)
							{

							}
							else
							{
								TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							}
						}
						else
						{
							//for CR/CRB, check for the stacked scenario
							iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tGenericItemRevTag,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
						}
						if(tOwningSite == NULLTAG)
						{
							if( (szStackedCRTargetStatusName != NULL) &&
								(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
							{
								//Populate the WARNING MESSAGE stack
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
									tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
									TIAUTO_GENREICREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
									tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}

							}
							else if(tc_strcmp(szGenericRelStatusName,PRODUCTION_RELEASED) == 0)
							{
							}
							else
							{
								*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;

								//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
								//because, in case of error we will get out of this function and
								//will not wait in the rule handlers, even if some of the child may be
								//in stacked CR
								if ( _iPopulateErrMsgInStack == 1 )
								{
									//Populate the ERROR MESSAGE stack
									if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
										}
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
										TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
										}
									}
								}
							}
						}
						//Clean up the two variables
						SAFE_MEM_free( szStackedCRTargetStatusName );
						SAFE_MEM_free( szStackedCRName );
					}
					else
					{
						*iError_ = TIAUTO_GENREICREV_PROGRESSING_ERROR;

						//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
						//because, in case of error we will get out of this function and
						//will not wait in the rule handlers, even if some of the child may be
						//in stacked CR
						if ( _iPopulateErrMsgInStack == 1 )
						{
							//Populate the ERROR MESSAGE stack
							if(iRetCode == ITK_ok && tOwningSite != NULLTAG)
							{


								if(tc_strcmp(szGenericRelStatusName,PRODUCTION_RELEASED) == 0)
								{

								}
								else
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
															TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, pszActualGenericName,
															TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
															TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
								}
							}
							else
							{
								if( tc_strcmp(pszActualGenericName, pcValue) == 0 )
								{
									TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									// Appending the Missing Item to the error_list
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
									}
								}
								else
								{
									TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT1, szGenItemDisplayName,pszActualGenericName,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
									TIAUTO_GENREICREV_PROGRESSING_ERROR_TEXT4);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									// Appending the Missing Item to the error_list
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tGenericItemRevTag);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	//to validate SolidWorks
	if(lIsProE == false)
	{
		if (iRetCode == ITK_ok)
				iRetCode = tiauto_checkIf_affected_isA_SWConfig_getDocument( _tItemRev,
													&lIsSW, &tDocumentItemRevTag, szDocItemDisplayName );
		if( iRetCode == ITK_ok )
		{
			pcValue = malloc(sizeof(szDocItemDisplayName));
			tc_strcpy(pcValue,szDocItemDisplayName);
			pcValue= tc_strtok ( pcValue , "-");
		}

		if ( (iRetCode == ITK_ok) && (lIsSW == true) && (tDocumentItemRevTag != NULLTAG) )
		{
			//get the release status of the document item revision
			iRetCode = tiauto_get_release_status(tDocumentItemRevTag, szDocumentRelStatusName);
			if(tc_strcmp(szDocumentRelStatusName,"T8_Standard - Preliminary") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Standard - Preliminary");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Standard - Released") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Standard - Released");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Technology Prototype") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Technology Prototype");
			}
			else if(tc_strcmp(szDocumentRelStatusName,"T8_Technology Released") == 0)
			{
				tc_strcpy(szDocumentRelStatusName, "Technology Released");
			}
			//If the document is equal to or above the target release status
			if ( (iRetCode == ITK_ok) &&
				 (tiauto_status_progression_index (szDocumentRelStatusName, _StatusProgression) < _TargetReleaseStatus.iLevel))
			{
				//Check if the document is one of the affected items in the EC
				IsExistInAffectedFolder( tDocumentItemRevTag, _ptAffectedItems, _iNumAffectedItems, &iFound );
				if( iFound == 0)
				{
					//get the document's actual display name
					//because if the Alt id is used the the actual irem/rev id will be different from the alt id
					//and the Alt id is the display id
					iRetCode = WSOM_ask_id_string(tDocumentItemRevTag, &pszActualDocumentName);
					//if the workflow process is DAP, check for the remote stacked DAP
					//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
					if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
					{
						iRetCode = AOM_ask_value_tag( tDocumentItemRevTag, "owning_site", &tOwningSite);
						if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
						{
							//In case of DAP, if the child component is a remote object then the
							// error and warning message will be different from the general format
							iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
						}
					}
					if(iRetCode == ITK_ok)
					{
						if ( _iPopulateWarningMsgInStack ==1 )
						{
							//Check if any stacked CR exists to take care of this error,
							//add them to warnings
							//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
							if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
							{
								if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
								{
									//In case of DAP, if the child component is a remote object then the
									// error and warning message will be different from the general format
									if(tc_strcmp(szDocumentRelStatusName,"DAP In Process")== 0)
									{
										//if the remote document has "DAP In Process" status then
										//Populate the WARNING MESSAGE stack
										if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, szGenItemDisplayName,pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,acSiteName,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										}
									}
									else
									{
										////if the remote document is at lower status than "DAP In Process" status then
										//populate the error message
										/*if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);


										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
											TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);

										}*/
									}

								}
								else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
								{
									//for local item revision, check for the Stacked scenario
									iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tDocumentItemRevTag, &szStackedCRName);
									if(szStackedCRName != NULL)
									{
										//if the stacked DAP is found, then the target status of the stacked DAP will be
										//same as the current target status
										szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
										tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
									}

								}
							}
							else
							{
								//for CR/CRB, check for the stacked scenario
								iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tDocumentItemRevTag,
											_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
							}
							if(tOwningSite == NULLTAG)
							{
								if( (szStackedCRTargetStatusName != NULL) &&
									(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
								{
									//Populate the WARNING MESSAGE stack
									if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT4,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT5,szStackedCRName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_DOCUMENTREV_PROGRESSING_WARNING_TEXT7,pcEndOfWarningMsg);
										tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}

								}
								else
								{
									*iError_ = TIAUTO_DOCUMENTREV_PROGRESSING_ERROR;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
										{
											TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
											}
										}
										else
										{
											TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
											}
										}
									}
								}
							}
							//Clean up the two variables
							SAFE_MEM_free( szStackedCRTargetStatusName );
							SAFE_MEM_free( szStackedCRName );
						}
						else
						{
							*iError_ = TIAUTO_DOCUMENTREV_PROGRESSING_ERROR;

							//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
							//because, in case of error we will get out of this function and
							//will not wait in the rule handlers, even if some of the child may be
							//in stacked CR
							if ( _iPopulateErrMsgInStack == 1 )
							{
								//Populate the ERROR MESSAGE stack
								if(iRetCode == ITK_ok && tOwningSite != NULLTAG)
								{
									//Populate the ERROR MESSAGE stack
									/*if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s \"%s\".",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);

									}*/

								}
								else
								{
									if( tc_strcmp(pszActualDocumentName, pcValue) == 0 )
									{
										TI_sprintf(szErrorString, "%s %s %s %s %s \"%s\" %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
										}
									}
									else
									{
										TI_sprintf(szErrorString, "%s %s[%s] %s %s %s \"%s\" %s",
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT1, szDocItemDisplayName,pszActualDocumentName,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_DOCUMENTREV_PROGRESSING_ERROR_TEXT4);
										tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_DOCUMENTREV_PROGRESSING_ERROR, szErrorString);
										// Appending the Missing Item to the error_list
										if(1 == iQuickProgFlag)
										{
											tiauto_Store_wsom_tags(error_list,&iTotal,tDocumentItemRevTag);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	va_end ( vl );
	SAFE_MEM_free(szItemRevInChangeId);
	SAFE_MEM_free(pszActualGenericName);
	SAFE_MEM_free(pszActualDocumentName);

	return iRetCode;

}

//**********************************************************************************************
//Function : check_status_of_Alternates.
//This function takes in the parent item revisions and checks the
// status of the alternates, if the assembly progression errors are found in the alternates also
// the error is thrown to the user along with the remaining progression errors.
//**********************************************************************************************
int check_status_of_Alternates_pci(		tag_t						_tParentBVR,
									tag_t						_tOccurrence,
									tag_t						_tPreferredChild,
									char						*szItemRevInChangeId,
									tag_t						*_ptAffectedItems,
									int							_iNumAffectedItems,
									STATUS_Struct_t				_StatusProgression,
									TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
									char						*pcEndOfWarningMsg,
									int							_iPopulateWarningMsgInStack,
									int							_iPopulateErrMsgInStack,
									char						*pcRootTaskName,
									int							iLevel,
									int							*iError_,
									TIA_ErrorMessage			**warningMsgStack_,
									TIA_ErrorMessage			**errMsgStack_,...)
{
	int iRetCode = ITK_ok;
	int iCount = 0;
	int iNoAlternates = 0;
	tag_t tAlternate = NULLTAG;
	tag_t *ptAltItems = NULL;
	tag_t *pAltViews = NULL;
	int		iQuickProgFlag			= 0;
	int		iFound					= 0;
	int		iSiteIid				= 0;
	int		iTotal					= 0;

	tag_t	tOwningSite				= NULLTAG;

    char	szChildRelStatus[WSO_name_size_c+1]			= "";
	char	*szStackedCRTargetStatusName				= NULL;
	char	*szStackedCRName							= NULL;
	char	*szChildItemRev								= NULL;
	char	szErrorString[TIAUTO_error_message_len+1]	= "";
	char	acSiteName[SA_site_size_c+1]				= "";

	logical lIsOEM				= false;

	TIA_ErrorMessage			*AlternateWarningMsgStack = NULL;
	TIA_ErrorMessage			*AlternateErrMsgStack  = NULL;

	TIA_UniqueWSOMObjects** error_list = NULL;
	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);

	}
	else
	{
		va_end(vl);
	}

	//iRetCode = PS_list_alternates (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews); //Deprecated This will be obsoleted. Use PS_list_substitutes
	iRetCode = PS_list_substitutes (_tParentBVR,_tOccurrence,&iNoAlternates,&ptAltItems, &pAltViews);
	if(iRetCode == ITK_ok && iNoAlternates > 0)
	{
		for (iCount = 0; (iCount < iNoAlternates) && (iRetCode == ITK_ok) ;iCount++)
		{
			tAlternate = ptAltItems[iCount];
			if( tAlternate != NULLTAG && _tPreferredChild != tAlternate)
			{
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = AOM_refresh(tAlternate,false);
					//get the target release status of the child component
					iRetCode = tiauto_get_release_status(tAlternate, szChildRelStatus);
					if(tc_strcmp(szChildRelStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Standard - Released");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szChildRelStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szChildRelStatus, "Technology Released");
					}
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					iRetCode = WSOM_ask_id_string( tAlternate, &szChildItemRev);
				}
				if ( iRetCode == ITK_ok && tAlternate != NULLTAG)
				{
					//check whether the child component is of _OEM type
					iRetCode = tiauto_check_if_itemType_isOEM(tAlternate, &lIsOEM);
					if ( iRetCode == ITK_ok )
					{
						//1.If the child component is OEM then it has to be in "Cad Release Only" status
						//So whenever we find the above condition, it will be considered as an ERROR,
						//no matter stacked CR exists or not, so we will not care about the flag
						if( lIsOEM == true )
						{
							if(tc_strcasecmp(szChildRelStatus, CRO)!= 0)
							{
								*iError_ = TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR;
								if(_iPopulateErrMsgInStack == 1)
								{
									TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s",
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT1, szChildItemRev,
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
											TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT3);
									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR, szErrorString);
								}
							}
						}
						//2. check if child item revisions have obsolete status.
						//if obsolete then error out
						else if(!tc_strcmp(szChildRelStatus,OBSOLETE))
						{
							*iError_ = TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR;
							if(_iPopulateErrMsgInStack == 1)
							{
								TI_sprintf(szErrorString,"Substitute Part Error: %s \"%s\" %s \"%s\" %s",
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT1 ,szChildItemRev,
								TIAUTO_OEM_NOT_IN_CORRECT_STATUS_ERROR_TEXT2,szItemRevInChangeId,
								TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_TEXT2);
								tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_OBSOLETE_ITEM_INCORRECT_STATUS_ERROR, szErrorString);
							}

						}
						//3.Verifying whether child component rev is at SAME or HIGHER status than
						//target release status of Change process.
						//If yes, accept the child component and continue to verify another child rev.
						else if ( tiauto_status_progression_index (szChildRelStatus, _StatusProgression) < _TargetReleaseStatus.iLevel )
						{
							//If not as above mentioned, verify if the child component rev is part of
							//Affected OR Solution Items folders of Change Process.
							//If yes, accept and continue to verify another child rev.
							IsExistInAffectedFolder( tAlternate, _ptAffectedItems, _iNumAffectedItems, &iFound );
							if( iFound == 0)
							{
								//if the workflow process is DAP then check for the remote stacked
								//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
								if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
								{
									iRetCode = AOM_ask_value_tag( tAlternate, "owning_site", &tOwningSite);
									if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
									{
										//In case of DAP, if the child component is a remote object then the
										// error and warning message will be different from the general format
										iRetCode = SA_ask_site_info (tOwningSite,acSiteName,&iSiteIid);
									}
								}
								if ( _iPopulateWarningMsgInStack ==1 )
								{
									//Check if any stacked CR exists to take care of this error,
									//add them to warnings
									//if(tc_strcmp(pcRootTaskName,"6_00 DAP - Design Approval") == 0)
									if(tc_strcmp(_TargetReleaseStatus.szTargetReleaseStatus,STUDY_APPROVED) == 0)
									{
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											/*if(tc_strcmp(szChildRelStatus,"DAP In Process")== 0)
											{
												//if the remote item revision has "DAP In Process" status then
												//Populate the WARNING MESSAGE stack
												TI_sprintf(szErrorString, "Alternate Part Warning: %s \"%s\" %s \"%s\" %s \"%s\" %s in \"%s\" site%s in \"%s\" site %s \"%s\" %s %s",
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
															szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,acSiteName,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,_TargetReleaseStatus.szTargetReleaseStatus,
															TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
												tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}
											else
											{
												//if the remote item revision has a lower status than the "DAP In Process"
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "Alternate Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											}*/
										}
										else if(iRetCode == ITK_ok && tOwningSite == NULLTAG)
										{
											//for the local site, check for the stacked DAP
											iRetCode = tiauto_get_stacked_DAP_changeProcess_Details(tAlternate, &szStackedCRName);
											//if stacked DAP is found, then the stacked target status will be same as
											//as the current target status
											if(szStackedCRName != NULL)
											{
												szStackedCRTargetStatusName = (char*) MEM_alloc(( (int)tc_strlen(_TargetReleaseStatus.szTargetReleaseStatus) + 1) * sizeof(char));
												tc_strcpy( szStackedCRTargetStatusName, _TargetReleaseStatus.szTargetReleaseStatus);
											}
										}
									}
									else
									{
										//In case of CR/CRB, check for the stacked scenario
										iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tAlternate,
										_StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);
									}
									if(tOwningSite == NULLTAG)
									{
										if( (szStackedCRTargetStatusName != NULL) &&
											(tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >= _TargetReleaseStatus.iLevel) )
										{
											//Populate the WARNING MESSAGE stack
											TI_sprintf(szErrorString, "Substitute Part Warning: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\"%s \"%s\" %s \"%s\" %s %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT4,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT5,szStackedCRName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT6,szStackedCRTargetStatusName,
														TIAUTO_CHILD_PART_INVALID_STATUS_WARNING_TEXT7,pcEndOfWarningMsg);
											tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
										}
										else
										{
											//start of 15.02 PCI
											/**iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

											//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
											//because, in case of error we will get out of this function and
											//will not wait in the rule handlers, even if some of the child may be
											//in stacked CR
											if ( _iPopulateErrMsgInStack == 1 )
											{
												//Populate the ERROR MESSAGE stack
												TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
												// Appending the Missing Item to the error_list
												if(1 == iQuickProgFlag)
												{
													tiauto_Store_wsom_tags(error_list,&iTotal,tAlternate);
												}
											}*/
											//end of 15.02 PCI
										}

									}
									//Clean up the two variables
									SAFE_MEM_free( szStackedCRTargetStatusName );
									SAFE_MEM_free( szStackedCRName );

								}
								else
								{
									*iError_ = TIAUTO_CHILD_PART_INVALID_STATUS;

									//_iPopulateErrMsgInStack will not be 1 in case of stacked CR RULE HANDLER
									//because, in case of error we will get out of this function and
									//will not wait in the rule handlers, even if some of the child may be
									//in stacked CR
									if ( _iPopulateErrMsgInStack == 1 )
									{
										//Populate the ERROR MESSAGE stack
										if(iRetCode == ITK_ok && tOwningSite != NULLTAG )
										{
											//In case of DAP, if the child component is a remote object then the
											// error and warning message will be different from the general format
											/*TI_sprintf(szErrorString, "Alternate Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\".",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT5, acSiteName);
												tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											*/
										}
										else
										{
											TI_sprintf(szErrorString, "Substitute Part Error: %s \"%s\" %s \"%s\" %s \"%s\" %s",
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT1,
														szChildItemRev, TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT2,szItemRevInChangeId,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT3,_TargetReleaseStatus.szTargetReleaseStatus,
														TIAUTO_CHILD_PART_INVALID_STATUS_ERROR_TEXT4);
											tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
											// Appending the Missing Item to the error_list
											if(1 == iQuickProgFlag)
											{
												tiauto_Store_wsom_tags(error_list,&iTotal,tAlternate);
											}
										}
									}
								}

							}
						}
					}

				}
				if ( iRetCode == ITK_ok && iLevel != 0)
				{
					iRetCode = ti_check_for_assembly_progression_pci( tAlternate, _ptAffectedItems, _iNumAffectedItems,
																_StatusProgression, _TargetReleaseStatus,
																pcEndOfWarningMsg, _iPopulateWarningMsgInStack,
																_iPopulateErrMsgInStack,pcRootTaskName,iLevel-1, iError_,
																&AlternateWarningMsgStack, &AlternateErrMsgStack, iQuickProgFlag, error_list);

				}
			}
		}
	}

	if(AlternateWarningMsgStack != NULL)
	{
		while(AlternateWarningMsgStack)
		{
			if(tc_strncasecmp(AlternateWarningMsgStack->errMsg,"Substitute Part Warning:",24) != 0)
			{
				TI_sprintf(szErrorString,"Substitute Part Warning: %s",AlternateWarningMsgStack->errMsg);
			}
			else
			{
				TI_sprintf(szErrorString,"%s",AlternateWarningMsgStack->errMsg);
			}
			tiauto_writeErrorMsgToStack(warningMsgStack_,AlternateWarningMsgStack->iRetCode, szErrorString);
			AlternateWarningMsgStack = AlternateWarningMsgStack->next;
		}
	}
	if(AlternateErrMsgStack != NULL)
	{
		while(AlternateErrMsgStack)
		{
			if(tc_strncasecmp(AlternateErrMsgStack->errMsg,"Substitute Part Error:",22) != 0)
			{
				TI_sprintf(szErrorString,"Substitute Part Error: %s",AlternateErrMsgStack->errMsg);
			}
			else
			{
				TI_sprintf(szErrorString,"%s",AlternateErrMsgStack->errMsg);
			}
			tiauto_writeErrorMsgToStack(errMsgStack_,AlternateErrMsgStack->iRetCode, szErrorString);
			AlternateErrMsgStack = AlternateErrMsgStack->next;
		}
	}
	tiauto_clearErrorMsgStack(AlternateWarningMsgStack);
	AlternateWarningMsgStack = NULL;
	tiauto_clearErrorMsgStack(AlternateErrMsgStack);
	AlternateErrMsgStack = NULL;

	SAFE_MEM_free(ptAltItems);
	SAFE_MEM_free(pAltViews);
	SAFE_MEM_free(szChildItemRev);

	return iRetCode;
}


//**********************************************************************************************
//Function : ti_Verify_MasterDrawingReferenceLinkedObjectStatus
// This function takes in the item revisions and checks type of the item revision.
// if the object is TI_Product Revision then checks the "master drawing reference" attribute.
// if the Master Drawing Reference linked object is AltRep then it checks the status of the object.
// if the object is not statused or has a status lower than the target release status warning message is displayed.
//**********************************************************************************************
extern int ti_Verify_MasterDrawingReferenceLinkedObjectStatus (	tag_t						_tItemRev,
																tag_t						*_ptAffectedItems,
																int							_iNumAffectedItems,
																STATUS_Struct_t				_StatusProgression,
																TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
																int                         _iPopulateWarningMsgInStack,
																int							_iPopulateErrMsgInStack,
																int							*iError_,
																TIA_ErrorMessage			**warningMsgStack_,
																TIA_ErrorMessage			**errMsgStack_,
																char						*pcEndOfWarningMsg,... )

{
    int     iRetCode											= ITK_ok;
	int		iQuickProgFlag										= 0;
	int		iTotal												= 0;
	int		iIRMFCnt											= 0;
	int     i                                                   = 0;

	tag_t	tIRMFRelationType									= NULLTAG;
	tag_t	tRefItemRev											= NULLTAG;
	tag_t	*ptIRMFList											= NULL;

	char    *pcItemRevId										= NULL;
	char    *pcRefItemRevId                                     = NULL;
	char    *pcTempItemRevId                                    = NULL;
	char	*szStackedCRTargetStatusName				        = NULL;
	char	*szStackedCRName							        = NULL;
    char    szRefItemRevReleaseStatus[WSO_name_size_c+1]		= "";
	char	szErrorString[TIAUTO_error_message_len+1]			= "";
	char	acItemRevType[ITEM_type_size_c+1]					= "";

	logical     lIsPresent										= false;
	int iItemRevBvrCount = 0;
	tag_t *ptItemRevBvrs = NULL;
	logical lIsPrecise = false;
	int  iNumOccs = 0;
	tag_t *ptOccs = NULL;
	int iCount = 0;
	tag_t tChildItem = NULLTAG;
	tag_t tChildBomView = NULLTAG;
	logical lHasAlternates = false;

	TIA_UniqueWSOMObjects** error_list							= NULL;

	va_list vl;
	va_start( vl, pcEndOfWarningMsg );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	iRetCode = AOM_refresh(_tItemRev,false);
	//get the item revision type
    iRetCode = ITEM_ask_rev_type(_tItemRev, acItemRevType);

	if ( (iRetCode == 0) && (tc_strcmp(acItemRevType,"TI_Product Revision") == 0) )
	{
		//get the item revision id string: "Item/Rev" format i. e "00001/AA"
		iRetCode = WSOM_ask_id_string ( _tItemRev, &pcItemRevId );

		iRetCode = GRM_find_relation_type("IMAN_master_form", &tIRMFRelationType);
		if (iRetCode == 0 && tIRMFRelationType != NULLTAG);
		{
			iRetCode = GRM_list_secondary_objects_only (_tItemRev,tIRMFRelationType,&iIRMFCnt,&ptIRMFList);
		}
		if (iRetCode == 0 && iIRMFCnt == 1)
		{
			iRetCode = AOM_ask_value_tag (ptIRMFList[0], "t8_t1a1masterdrawingref", &tRefItemRev);
			if ( iRetCode == ITK_ok && tRefItemRev != NULLTAG)
			{
				//get the reference item revision id string: "Item/Rev" format i. e "AR001/AA"
				iRetCode = WSOM_ask_id_string ( tRefItemRev, &pcRefItemRevId );

				// check whether the Master Drawing Reference linked Item rev is present in the current change folder
				for (i=0; i<_iNumAffectedItems; i++)
				{
					iRetCode = WSOM_ask_id_string ( _ptAffectedItems[i], &pcTempItemRevId );
					if ( (iRetCode == 0) && (tc_strcmp(pcRefItemRevId, pcTempItemRevId) == 0) )
					{
						lIsPresent = true;
						break;
					}

				}

				if ( (lIsPresent == false) && (iRetCode == 0) )
				{
					//get the release status
					iRetCode = tiauto_get_release_status( tRefItemRev, szRefItemRevReleaseStatus );
					if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Released");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Released");
					}
					
					//check master drawing reference status
					if (iRetCode == ITK_ok)
					{
						// If Master Drawing Reference linked item rev has no Release status
						if( (iRetCode == ITK_ok) && (tc_strcasecmp(szRefItemRevReleaseStatus, "") == 0 ) )
						{
							//to check if master drawing reference is in other change process
							iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tRefItemRev, _StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);

							// If Master Drawing Reference is present in other change process then throw warning msg
							if( (iRetCode== ITK_ok) && (szStackedCRName != NULL) && (tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >=  _TargetReleaseStatus.iLevel) )
							{	
								TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s %s \"%s\" %s \"%s\" %s \"%s\" %s %s",	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT1,pcRefItemRevId,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT2 ,pcItemRevId,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT3 ,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT4 ,szStackedCRName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT5 ,szStackedCRName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT6 ,szStackedCRTargetStatusName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT7 ,pcEndOfWarningMsg);

								tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
								////////////////////////////////////////////////////////////////////
								if(1 == iQuickProgFlag)
								{
									tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
								}
								//free memory
								SAFE_MEM_free( szStackedCRTargetStatusName );
								SAFE_MEM_free( szStackedCRName );
							}

							// If Master Drawing Reference linked item rev has no Release status and not present in any of change process
							else
							{
								*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
								if (_iPopulateErrMsgInStack == 1)
								{

									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1,pcRefItemRevId,
																						TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
																						TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT3 );

									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
									////////////////////////////////////////////////////////////////////
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
									}
								}
							}
						}

						// If Master Drawing Reference linked item rev status is lesser than the Change Process Target Release status
						else if ( (iRetCode == ITK_ok) && (tiauto_status_progression_index (szRefItemRevReleaseStatus, _StatusProgression) <  _TargetReleaseStatus.iLevel))
						{
							//to check if master drawing reference is in other change process
							iRetCode = tiauto_search_changeProcess_for_itemRev_getDetails( tRefItemRev, _StatusProgression, &szStackedCRTargetStatusName, &szStackedCRName);

							// If Master Drawing Reference is present in other change process then throw warning msg
							if( (iRetCode== ITK_ok) && (szStackedCRName != NULL) && (tiauto_status_progression_index (szStackedCRTargetStatusName, _StatusProgression) >=  _TargetReleaseStatus.iLevel) )
							{	
								TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\" %s \"%s\" %s %s",	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT1,pcRefItemRevId,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT2 ,pcItemRevId,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT8 ,_TargetReleaseStatus.szTargetReleaseStatus,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT4 ,szStackedCRName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT5 ,szStackedCRName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT6 ,szStackedCRTargetStatusName,
																														TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_WARNING_TEXT7 ,pcEndOfWarningMsg);

								tiauto_writeErrorMsgToStack(warningMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
								////////////////////////////////////////////////////////////////////
								if(1 == iQuickProgFlag)
								{
									tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
								}
								//free memory
								SAFE_MEM_free( szStackedCRTargetStatusName );
								SAFE_MEM_free( szStackedCRName );
							}
						
							else 
							{
								// Item revision is at invalid status
								*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
								if (_iPopulateErrMsgInStack == 1)
								{

									TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\".",	    TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1, pcRefItemRevId,
																									TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
																									TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT4,
																									_TargetReleaseStatus.szTargetReleaseStatus );

									tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
									////////////////////////////////////////////////////////////////////
									if(1 == iQuickProgFlag)
									{
										tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
									}
								}
							}
						}

						
					}
				 }
			}
		}
	}


	//check the assembly
	if ( iRetCode == ITK_ok)
		iRetCode = ITEM_rev_list_bom_view_revs ( _tItemRev, &iItemRevBvrCount, &ptItemRevBvrs);

	if ( (iRetCode == ITK_ok) && (iItemRevBvrCount > 0) )
	{
		//As per existing implementation, there is only one BVR in the system, So always take the 1st one
		iRetCode = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);
		if ( (iRetCode == ITK_ok) )
		{
			iRetCode = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &ptOccs);
			// If the BVR does not have any child component, no need to proceed further
			for (iCount = 0; (iCount < iNumOccs) && (iRetCode == ITK_ok) ; iCount++)
			{
				tChildItem = NULLTAG;
				tChildBomView = NULLTAG;
				lHasAlternates = false;

				iRetCode = PS_ask_occurrence_child (ptItemRevBvrs[0], ptOccs[iCount],&tChildItem, &tChildBomView);
				if ( iRetCode == ITK_ok && tChildItem != NULLTAG)
				{

                      ti_Verify_MasterDrawingReferenceLinkedObjectStatus( tChildItem, _ptAffectedItems, _iNumAffectedItems, _StatusProgression, _TargetReleaseStatus, _iPopulateWarningMsgInStack,
														_iPopulateErrMsgInStack, iError_, warningMsgStack_, errMsgStack_,pcEndOfWarningMsg, iQuickProgFlag,error_list	);

				}
			}
		}
	}


	va_end ( vl );
    return  iRetCode;
}

//**********************************************************************************************
//Function : ti_Verify_MasterDrawingReferenceLinkedObjectStatus
// This function takes in the item revisions and checks type of the item revision.
// if the object is TI_Product Revision then checks the "master drawing reference" attribute.
// if the Master Drawing Reference linked object is AltRep then it checks the status of the object.
// if the object is not statused or has a status lower than the target release status warning message is displayed.
//**********************************************************************************************
extern int ti_Verify_MasterDrawingReferenceLinkedObjectStatus_pci (	tag_t						_tItemRev,
																tag_t						*_ptAffectedItems,
																int							_iNumAffectedItems,
																STATUS_Struct_t				_StatusProgression,
																TARGET_RELEASE_Struct_t		_TargetReleaseStatus,
																int							_iPopulateErrMsgInStack,
																int							*iError_,
																TIA_ErrorMessage			**errMsgStack_, ... )

{
    int     iRetCode											= ITK_ok;
	int		iQuickProgFlag										= 0;
	int		iTotal												= 0;
	int		iIRMFCnt											= 0;
	int     i                                                   = 0;

	tag_t	tIRMFRelationType									= NULLTAG;
	tag_t	tRefItemRev											= NULLTAG;
	tag_t	*ptIRMFList											= NULL;

	char    *pcItemRevId										= NULL;
	char    *pcRefItemRevId                                     = NULL;
	char    *pcTempItemRevId                                    = NULL;
    char    szRefItemRevReleaseStatus[WSO_name_size_c+1]		= "";
	char	szErrorString[TIAUTO_error_message_len+1]			= "";
	char	acItemRevType[ITEM_type_size_c+1]					= "";

	logical     lIsPresent										= false;

	TIA_UniqueWSOMObjects** error_list							= NULL;

	va_list vl;
	va_start( vl, errMsgStack_ );
	iQuickProgFlag = va_arg(vl,int);

	if(1 == iQuickProgFlag)
	{
		error_list = va_arg(vl,TIA_UniqueWSOMObjects**);
	}
	else
	{
		va_end(vl);
	}
	*iError_ = 0;

	//get the item revision type
    iRetCode = ITEM_ask_rev_type(_tItemRev, acItemRevType);

	if ( (iRetCode == 0) && (tc_strcmp(acItemRevType,"TI_Product Revision") == 0) )
	{
		//get the item revision id string: "Item/Rev" format i. e "00001/AA"
		iRetCode = WSOM_ask_id_string ( _tItemRev, &pcItemRevId );

		iRetCode = GRM_find_relation_type("IMAN_master_form", &tIRMFRelationType);
		if (iRetCode == 0 && tIRMFRelationType != NULLTAG);
		{
			iRetCode = GRM_list_secondary_objects_only (_tItemRev,tIRMFRelationType,&iIRMFCnt,&ptIRMFList);
		}
		if (iRetCode == 0 && iIRMFCnt == 1)
		{
			iRetCode = AOM_ask_value_tag (ptIRMFList[0], "t8_t1a1masterdrawingref", &tRefItemRev);
			if ( iRetCode == ITK_ok && tRefItemRev != NULLTAG)
			{
				//get the reference item revision id string: "Item/Rev" format i. e "AR001/AA"
				iRetCode = WSOM_ask_id_string ( tRefItemRev, &pcRefItemRevId );

				// check whether the Master Drawing Reference linked Item rev is present in the current change folder
				for (i=0; i<_iNumAffectedItems; i++)
				{
					iRetCode = WSOM_ask_id_string ( _ptAffectedItems[i], &pcTempItemRevId );
					if ( (iRetCode == 0) && (tc_strcmp(pcRefItemRevId, pcTempItemRevId) == 0) )
					{
						lIsPresent = true;
					}

				}

				if ( (lIsPresent == false) && (iRetCode == 0) )
				{
					//get the release status
					iRetCode = tiauto_get_release_status( tRefItemRev, szRefItemRevReleaseStatus );
					if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Preliminary") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Preliminary");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Standard - Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Standard - Released");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Prototype") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Prototype");
					}
					else if(tc_strcmp(szRefItemRevReleaseStatus,"T8_Technology Released") == 0)
					{
						tc_strcpy(szRefItemRevReleaseStatus, "Technology Released");
					}


					// If Master Drawing Reference linked item rev has no Release status
					if( (iRetCode == ITK_ok) && (tc_strcasecmp(szRefItemRevReleaseStatus, "") == 0 ) )
					{
						*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
						if (_iPopulateErrMsgInStack == 1)
						{

							TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s",	TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1,pcRefItemRevId,
																				TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
																				TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT3 );

							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
							////////////////////////////////////////////////////////////////////
							if(1 == iQuickProgFlag)
							{
								tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
							}
						}
					}
					else if( (iRetCode == ITK_ok) && (tc_strcasecmp(szRefItemRevReleaseStatus, "Production Released") == 0 ) )
					{

					}
					// If Master Drawing Reference linked item rev status is greater than the Changege Process Target Release status
					else if ( (iRetCode == ITK_ok) && (tiauto_status_progression_index (szRefItemRevReleaseStatus, _StatusProgression) <  _TargetReleaseStatus.iLevel) &&
						 (tc_strcasecmp(szRefItemRevReleaseStatus, "") != 0 ) )
					{
						// Item revision is at invalid status
						*iError_ = TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS;
						if (_iPopulateErrMsgInStack == 1)
						{

							TI_sprintf(szErrorString, "%s \"%s\" %s \"%s\" %s \"%s\".",	    TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT1, pcRefItemRevId,
																							TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT2 ,pcItemRevId,
																							TIAUTO_MDR_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS_ERROR_TEXT4,
																							_TargetReleaseStatus.szTargetReleaseStatus );

							tiauto_writeErrorMsgToStack(errMsgStack_,TIAUTO_MASTER_DRAWING_REFERENCE_ATTRIBUTE_LINKED_OBJECT_INVALID_STATUS, szErrorString);
							////////////////////////////////////////////////////////////////////
							if(1 == iQuickProgFlag)
							{
								tiauto_Store_wsom_tags(error_list,&iTotal,tRefItemRev);
							}
						}
					}
				}
			}
		}
	}
	va_end ( vl );
    return  iRetCode;
}
