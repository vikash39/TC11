/*******************************************************************************
File         : tiauto_ah_create_mfgrelauthorisation_item.c

Description  : This will create Risk Assessment item under the reference folder of
               Change Revision.

Input        : None

Output       : None

Author       : TCS

Revision History :
Date           Revision    Who                         Description
*******************************************************************************
22-Nov-2018    1.0          Chandrashekar Patil			Initial Creation
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


extern int TAUTO_AH_Create_RiskAssessment_Item(EPM_action_message_t msg)
{
	tag_t		tChangeRev								= NULLTAG;	
	tag_t		tSite									= NULLTAG;
	tag_t		tItem									= NULLTAG;
	tag_t		tItemRev								= NULLTAG;
	tag_t		tRelationType							= NULLTAG;
	tag_t		tRelation								= NULLTAG;
	char		*pcItemId								= NULL;	
	char		*pcRevDesc								= NULL;
	int         iRetCode								= ITK_ok;
	
	
	if ( iRetCode == ITK_ok)
		iRetCode = tiauto_get_change_item_rev (msg.task, &tChangeRev);
	
	if ( (iRetCode == ITK_ok) && (tChangeRev != NULLTAG) )
	{
		
		TIAUTO_ITKCALL(iRetCode,NR_next_value("T8_RiskAssessmen", "item_id", NULLTAG,"", "", "", NULLTAG, ""," ", &pcItemId));
		//create the item based on the input data
		TIAUTO_ITKCALL(iRetCode,ITEM_create_item  ( pcItemId,"RiskAssessment", "T8_RiskAssessmen",NULL, &tItem,&tItemRev ));
		//set the item description
		if(tItem != NULLTAG)
			TIAUTO_ITKCALL(iRetCode,ITEM_set_description (tItem,"RiskAssessment"));
		//set the revision description
		if(tItemRev != NULLTAG)
			TIAUTO_ITKCALL(iRetCode,ITEM_set_rev_description (tItemRev,"RiskAssessment"));

		if(tItem != NULLTAG)
			TIAUTO_ITKCALL(iRetCode,ITEM_save_item (tItem));

		if(tItemRev != NULLTAG)
		{
			TIAUTO_ITKCALL(iRetCode,ITEM_save_rev (tItemRev));
		
			TIAUTO_ITKCALL(iRetCode,AOM_refresh (tItemRev,false));
		}
				
		TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type ("CMReferences",&tRelationType));
		if(iRetCode == ITK_ok && tRelationType!=NULLTAG && tItemRev != NULLTAG)
		{
			if(iRetCode == ITK_ok && tRelationType != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,GRM_create_relation (tChangeRev,tItemRev,tRelationType,NULLTAG,&tRelation));
			if(iRetCode == ITK_ok && tRelation != NULLTAG)
				TIAUTO_ITKCALL(iRetCode,GRM_save_relation (tRelation));
		}
		if(tItemRev != NULLTAG && iRetCode==ITK_ok)
		{
			char		acRevID[ITEM_id_size_c + 1]				= "";
			tag_t		tRelType								= NULLTAG;
			int			iSecObjCnt								= 0;
			int			iLoopSecObj								= 0;
			tag_t		*ptSecObj								= NULL;
			char		acObjString[WSO_name_size_c+1]			= "";
			
			TIAUTO_ITKCALL(iRetCode,GRM_find_relation_type (REL_IMAN_SPEC,&tRelType));
			TIAUTO_ITKCALL(iRetCode,ITEM_ask_rev_id(tItemRev,acRevID));
			if((tc_strlen(pcItemId) > 0) && iRetCode==ITK_ok)
				tc_strcpy(acObjString,pcItemId);
			tc_strcat(acObjString,TIAUTO_FRONT_SLASH);
			if((tc_strlen(acRevID) > 0) && iRetCode==ITK_ok)
				tc_strcat(acObjString,acRevID);			
			if(tRelType!=NULLTAG && iRetCode==ITK_ok)
			{
				TIAUTO_ITKCALL(iRetCode,GRM_list_secondary_objects_only(tItemRev,tRelType,&iSecObjCnt,&ptSecObj));				
			}
			for(iLoopSecObj = 0; iLoopSecObj < iSecObjCnt; iLoopSecObj++)
			{
				char		*pcObjType			= NULL;

				TIAUTO_ITKCALL(iRetCode,AOM_ask_value_string(ptSecObj[iLoopSecObj],TIAUTO_OBJECT_TYPE,&pcObjType));				
				if((tc_strcmp(pcObjType,TIAUTO_MSWORDX)==0) && iRetCode==ITK_ok)
				{
					
					TIAUTO_ITKCALL(iRetCode,AOM_refresh(ptSecObj[iLoopSecObj],true));					
					TIAUTO_ITKCALL(iRetCode,AOM_set_value_string(ptSecObj[iLoopSecObj],TIAUTO_OBJECT_NAME,acObjString));					
					TIAUTO_ITKCALL(iRetCode,AOM_save(ptSecObj[iLoopSecObj]));					
					TIAUTO_ITKCALL(iRetCode,AOM_refresh(ptSecObj[iLoopSecObj],false));					
				}
				SAFE_MEM_free(pcObjType);
			}
			SAFE_MEM_free(ptSecObj);
		}

	}

	if ( iRetCode != ITK_ok )
	{
		char	*pcErrMsg			= NULL;
		EMH_ask_error_text (iRetCode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetCode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	
	SAFE_MEM_free(pcItemId);	
	SAFE_MEM_free(pcRevDesc);

	return iRetCode;
}
