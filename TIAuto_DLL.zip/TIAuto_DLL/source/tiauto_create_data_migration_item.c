/*******************************************************************************
File         : tiauto_create_data_migration_item.c

Description  : This server exit method create the item based on the input.
				This method is called from the Data Migration utility.

Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                 Description
*******************************************************************************
30-Nov-2012    1.0        Dipak Naik			Initial Creation
27-Sept-2018   1.1		  Shruti Pinto			Modified the code to create item
												(As the item creation is failing with mandatory description field in Tc11,
												 added the different API to create the item ) 
*******************************************************************************/

#include <tiauto_server_exits.h>
#include <tiauto_defines.h>
#include <tiauto_utils.h>

extern int TAUTO_Create_Data_Migration_Item(void *return_value)
{

	tag_t       tItem			= NULLTAG;
	tag_t       tItemRev		= NULLTAG;
	tag_t       tItemMasterForm = NULLTAG;
	tag_t       tRevMasterForm	= NULLTAG;
	char		*pcItemId		= NULL;
	char		*pcItemName		= NULL;
	char		*pcItemType		= NULL;
	char		*pcItemRevType	= NULL;
	char		*pcRevId		= NULL;
	char		*pcItemDesc		= NULL;
	char		*pcRevDesc		= NULL;
	char		*pcRev			= " Revision";
	int			iFail			= ITK_ok;
	tag_t		tItemType		= NULLTAG;
	tag_t		tItemRevType	= NULLTAG;
	tag_t		tItemCreateInput = NULLTAG;
	tag_t		tItemRevCreateInput = NULLTAG;

	iFail = USERARG_get_string_argument(&pcItemId);
	iFail = USERARG_get_string_argument(&pcItemName);
	iFail = USERARG_get_string_argument(&pcItemType);
	iFail = USERARG_get_string_argument(&pcRevId);
	iFail = USERARG_get_string_argument(&pcItemDesc);
	iFail = USERARG_get_string_argument(&pcRevDesc);
	iFail = USERARG_get_tag_argument(&tItemMasterForm);
	iFail = USERARG_get_tag_argument(&tRevMasterForm);

	//Item revision type
	pcItemRevType = (char*) malloc(strlen(pcItemType)+strlen(pcRev)+1);
	pcItemRevType[0] = '\0';   // ensures the memory is an empty string
    strcat(pcItemRevType,pcItemType);
    strcat(pcItemRevType,pcRev);
	
	//create the item based on the input data
	iFail = TCTYPE_find_type(pcItemType,  NULL, &tItemType);
	iFail = TCTYPE_find_type(pcItemRevType,  NULL, &tItemRevType);

	
	if(tItemType != NULLTAG)
		iFail = TCTYPE_construct_create_input(tItemType,&tItemCreateInput);
	
	if(tItemRevType != NULLTAG)
		iFail = TCTYPE_construct_create_input(tItemRevType,&tItemRevCreateInput);
	
	if(tItemCreateInput != NULLTAG && tItemRevCreateInput != NULLTAG)
		iFail = AOM_set_value_tag(tItemCreateInput, "revision", tItemRevCreateInput);

	if(tItemCreateInput != NULLTAG && pcItemName != NULL)
	{
		iFail = AOM_set_value_string(tItemCreateInput, "object_name", pcItemName);
		iFail = AOM_set_value_string(tItemRevCreateInput, "object_name", pcItemName);
		iFail = AOM_set_value_string(tItemCreateInput, "item_id", pcItemId);
		iFail = AOM_set_value_string(tItemRevCreateInput, "item_revision_id", pcRevId);
		iFail = AOM_set_value_string(tItemCreateInput, "object_desc", pcItemDesc);
		iFail = AOM_set_value_string(tItemRevCreateInput, "object_desc", pcRevDesc);
		iFail = AOM_set_value_tag(tItemCreateInput, "item_master_tag", tItemMasterForm);
		iFail = AOM_set_value_tag(tItemRevCreateInput, "item_master_tag", tRevMasterForm);

		iFail = TCTYPE_create_object(tItemCreateInput, &tItem);
		printf("iFail Code = %d\n" , iFail);

		if(tItem != NULLTAG)
		{
			iFail = AOM_save_with_extensions(tItem);	
			printf("Item is created\n");
		}

	}
	
	iFail = AOM_refresh(tItem,false);

	if(tItem != NULLTAG)
	{
		iFail = ITEM_ask_latest_rev(tItem,&tItemRev);

		if(tItemRev != NULLTAG)
		{
			iFail = AOM_refresh(tItemRev,false);
			//printf("\n Testing....\n");
		}
	}

	
    EMH_clear_errors();
	SAFE_MEM_free(pcItemId);
	SAFE_MEM_free(pcItemName);
	SAFE_MEM_free(pcItemType);
	SAFE_MEM_free(pcRevId);
	SAFE_MEM_free(pcItemDesc);
	SAFE_MEM_free(pcRevDesc);
	free(pcItemRevType);

	printf("returning the item tag");
   //return the item tag
	*((tag_t *) return_value)  = tItem;

	
	return iFail;
}

