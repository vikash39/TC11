/*******************************************************************************
File         : tiauto_send_email_toall.c

Description  : This action handler sends mails to all the people involved in the
               workflow in the following manner on the complete action of task
			   process assignment list.
Sample Mail  :

Input        : None

Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Sept 10, 2009    1.0        Dipak Naik      Initial Creation
Jan  11, 2010	 1.1        Dipak Naik		Modified the code to send mail to
											all the workflow participants.
Mar  11, 2010	 1.2        Dipak Naik		Modified the code to send mail to
											all the workflow participants except the users
											mentioned in the "notify task (approval or rejection)"
											list in case of after assignment list is applied. In case
											of approval and rejection all the participants should get
											the e-mail notification.
May 19, 2014	 1.3		Manik			Updated the code to add the Rejection Details in the mail body.
Nov 04, 2016	 1.4		Dipak			Updated as per ER#8924
Nov 23,2018		 1.5		Jugunu          Updated for ER 9759 CAP3
Jun 21, 2019     1.6        Trisha Saha     Updated attachments with signoff_attachments for Mail to users
*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200

extern void tiauto_Store_TaskNames_per_User(TIA_TaskNamesAssignedPerUser **currErrMsg, tag_t tUser, char* sError);
extern int Send_Mail(tag_t tUser,char *pcAllTasks,char *pcChangeId,char *pcRevId,char *pcSubject,char *pcSiteName,char *pcInitiator,char *pcAffPrograms,char *pcAffPlants,char *pcChangeDescription);

void FreeMemoryForLinkdList(TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList);


void toLowerCase(char *pcStr)
{
	while(*pcStr)
	{
		*pcStr = tolower(*pcStr);
		pcStr++;
	}
}

extern int t1aAUTO_send_email_toAll(EPM_action_message_t msg)
{
	//variable
	int				iRetcode			= ITK_ok;
	int             iNumArgs			= 0;
    int				i					= 0;
	int				inx					= 0;
	int				iCount				= 0;
	int				iSubTaskCnt			= 0;
	int				isubTaskIndx		= 0;
	int				iNumAttachs			= 0;
	int				iAttchIndx			= 0;
	int             iSite               = 0;
	int             iSiteID             = 0;
	int             iFileOpenErrCode    = 0;
	int				iCntActionHandlers	= 0;
	int				iCnt				= 0;
	int				iReleaseStatus		= 0;
	int				iSolItemRevs		= 0;
	int				iNum				= 0;

	tag_t			tRootTaskTag		= NULLTAG;
	tag_t			tReposibleParty		= NULLTAG;
	tag_t			tTaskType			= NULLTAG;
	tag_t			tInitiatorTag		= NULLTAG;
	tag_t			tJobTag				= NULLTAG;
	tag_t			tEngChangeRev		= NULLTAG;
	tag_t			tGroupMember		= NULLTAG;
	tag_t			*ptAttachsTagList	= NULL;//to be freed
	tag_t			*ptTasks			= NULL;//to be freed
	tag_t			*ptReviewSubTasks	= NULL;//to be freed
	tag_t			tTemplate			= NULLTAG;
	tag_t           tpropTag            = NULLTAG;
	tag_t           tSitetag            = NULLTAG;
	tag_t			tHandler			= NULLTAG;
	tag_t			*pActionHandlers	= NULL;
	tag_t			*ptSolItemRevs		= NULL;
	tag_t			tRootTask			= NULLTAG;
	tag_t			tAuditFile			= NULLTAG;
	tag_t			tJob				= NULLTAG;
	tag_t			*ptBasedonEngChangeRev	= NULL;
	tag_t			tBasedonEngChangeRev	= NULLTAG;

	char			*pcUserMailId					= NULL;//to be freed
	char			*pcTaskName						= NULL;//to be freed
	char			*pcTaskTypeName					= NULL;//to be freed
	char			*pcSubTaskType					= NULL;//to be freed
	char			acSubject[1024]					= {'\0'};
	char			acChnId[ITEM_id_size_c+1]		= {'\0'};
	char			acChnRevId[ITEM_id_size_c+1]	= {'\0'};
	char			acChnName[ITEM_name_size_c+1]	= {'\0'};
	char			caTaskName[WSO_name_size_c+1]	= {'\0'};
	char            acSiteName[SA_site_size_c+1]	= {'\0'};
	char			acObjectType[WSO_name_size_c+1]	= "";

	char			*pcMailSubject							= NULL;
	char			*pcBodyMsg								= NULL;
	char		    *pcValue								= NULL;
    char		    *pcFlag									= NULL;
	char			*pcErrMsg								= NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";
	char			*pcPropValue							= NULL;
	//txt_t			the_text_server							= NULL;
    //char			*pcMsgName								= NULL;
    char			*pcComments								= NULL;
	char			*pcEmailId								= NULL;
	char			*pcMailBodyFileName						= NULL;
	char			*pcSiteName                             = NULL;
	char			*cHandlerName							= "";
	char			*pcReleaseStatusName					= NULL;
	tag_t			*ptReleaseStatusList					= NULL;
	char			*pcResult								= NULL;
	char			*pcMRAURL								= NULL;
	char			*pcMRAId								= NULL;
	char			*pcACDURL								= NULL;
	char			*pcACDId								= NULL;

	FILE		*fMailBodyFile								= NULL;

	logical		isAutomatedTask								= false ;
	logical		isRejected									= false ;
	logical		isApproved									= false;
	logical		isMRAFound									= false;
	logical		isMRADocDetails								= false;
	logical		isACDFound									= false;
	logical		isACDDetails								= false;
	char *pcRejectedTask=NULL,*pcCommentValue=NULL, *pcRespPartyName=NULL, *pcRespPartyGroupName=NULL, *pcRespPartyRoleName=NULL;
	int iAllTasks = 0;
	tag_t *ptAllTaskTags = NULL;
	tag_t tPrevbasedOnRootTaskTag = NULLTAG;

	tag_t tRelation = NULLTAG;
	int iSecondaryObjNo = 0;
	tag_t *tSecObj = NULL;
	char *pcObjectType = NULL;
	char *pcAffPrograms = NULL;
	char *pcAffPlants = NULL;
	char *pcChangeDescription = NULL;
	char *pcInitiator = NULL;

	EPM_state_t State ;

	//EPM_action_t Action = EPM_complete_action;
	TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList = NULL;//to store all the task names per user

	TIA_TaskNamesAssignedPerUser *NotifyUserList = NULL;

	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 2)
	{
		for(i = 0; i < iNumArgs; i++)
		{

			iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetcode == ITK_ok )
			{
				if (tc_strcasecmp(pcFlag, "subject") == 0 && pcValue != NULL)
				{
					pcMailSubject = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcMailSubject, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, "comment") == 0 && pcValue != NULL)
				{
					pcBodyMsg = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcBodyMsg, pcValue);
				}
				else
					iRetcode = EPM_invalid_argument;

				if( iRetcode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-send-email-to-all\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;

				}
			}
		}
		SAFE_MEM_free(pcFlag);
		SAFE_MEM_free(pcValue);
	}
	else if (iNumArgs > 2 )
	{
		iRetcode = EPM_invalid_argument;
	}

    if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the user who has initiated the task
		if(iRetcode == ITK_ok)
		{
			iRetcode = AOM_ask_owner(tRootTaskTag,&tInitiatorTag);
		}
		if(iRetcode == ITK_ok)
		{
			iRetcode = EPM_get_user_email_addr(tInitiatorTag,&pcUserMailId);
		}
		//Get the change revision details
		if(iRetcode == ITK_ok && tRootTaskTag!= NULLTAG)
		{
			iRetcode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
		}
		if(iRetcode == ITK_ok && tEngChangeRev!= NULLTAG)
		{
			iRetcode = tiauto_getItemRevDetails(tEngChangeRev, acChnId, acChnRevId, acChnName);
			iRetcode = AOM_ask_value_tags( tEngChangeRev, "release_status_list", &iReleaseStatus, &ptReleaseStatusList);
			if(iReleaseStatus>0)
			{
				AOM_ask_name(ptReleaseStatusList[iReleaseStatus-1], &pcReleaseStatusName);
				if(pcReleaseStatusName!=NULL)
				{
					toLowerCase(pcReleaseStatusName);
					pcResult = tc_strstr(pcReleaseStatusName, "rejected");
					if(pcResult!=NULL)
					{
						iRetcode = EPM_ask_job(msg.task,&tJob);
						//get the root task
						if (iRetcode == ITK_ok && tJob != NULLTAG)
							iRetcode = EPM_ask_root_task (tJob, &tRootTask);
						if (iRetcode == ITK_ok && tJob != NULLTAG)
							iRetcode = EPM_ask_audit_file(tJob, &tAuditFile);

						isRejected = true;
						if(tAuditFile != NULLTAG)
						{
							findRejectionDetails( msg.task, &pcRejectedTask, &pcCommentValue, &pcRespPartyName, &pcRespPartyGroupName, &pcRespPartyRoleName);
						}
						else
						{
							parseWorkflowAuditInfoFromDatabase( tRootTask,&pcCommentValue, &pcRespPartyName, &pcRespPartyGroupName,&pcRespPartyRoleName, &pcRejectedTask);
						}
					}
					if(tc_strstr(pcReleaseStatusName, "approved") != NULL)
					{
						isApproved = true;
					}
				}
			}
		}
		//Get the job tag
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_job(tRootTaskTag,&tJobTag);
		}
		//Get the subtasks and iterate through them.
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_sub_tasks(tRootTaskTag,&iCount,&ptTasks);
			if(iRetcode == ITK_ok && iCount > 0)
			{
				for(inx= 0;inx<iCount;inx++)
				{
					iRetcode = AOM_ask_name(ptTasks[inx],&pcTaskName);
					if(iRetcode == ITK_ok)
					{
						iRetcode = EPM_ask_state(ptTasks[inx],&State);
					}

					//if the task name contains "Incorrect Change Type", then that task will not be considered
					if(iRetcode == ITK_ok && ( tc_strstr(pcTaskName,"Incorrect Change Type") == NULL) && ( tc_strstr(pcTaskName,"Send Mandatory Screening Notification") == NULL))
					{
						if(iRetcode == ITK_ok && pcTaskName!= NULL)
						{
							iRetcode = TCTYPE_ask_object_type(ptTasks[inx],&tTaskType);
						}
						if(iRetcode == ITK_ok && tTaskType != NULLTAG)
						{
							iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
						}

						if(iRetcode == ITK_ok && pcTaskTypeName != NULL  )
						{
							//check if the task type is a ECO/Do Task/CheckList
							if( (tc_strcmp(pcTaskTypeName,"ECMPrepareECOTask")==0 ) ||
								(tc_strcmp(pcTaskTypeName,"EPMDoTask")== 0 ) ||
								(tc_strcmp(pcTaskTypeName,"ECMChecklistTask")== 0) )
							{
								//get the responsible party of the task
								iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
								if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
								{
									if(iRetcode == ITK_ok && State == EPM_pending)
									{
										//Get all the user tags and TaskNames in structure sMail WorkFlowStruc
										tiauto_Store_TaskNames_per_User(&TaskNamesPerUserList,tReposibleParty,pcTaskName);
									}
									if(pcMailSubject != NULL && pcBodyMsg != NULL)
									{
										tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
									}

								}
							}
							else if( (tc_strcmp(pcTaskTypeName,"EPMReviewTask")==0) ||
									(tc_strcmp(pcTaskTypeName,"EPMAcknowledgeTask")==0) )
							{
								//for review and acknowledge task
								iRetcode = EPM_ask_sub_tasks( ptTasks[inx], &iSubTaskCnt, &ptReviewSubTasks );
								if( iRetcode == ITK_ok && ptReviewSubTasks != NULL )
								{
									for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && iRetcode == ITK_ok; isubTaskIndx++  )
									{

										iRetcode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
										if( iRetcode == ITK_ok && pcSubTaskType != NULL &&
											(tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
										{
											iRetcode = AOM_ask_value_tag  ( ptTasks[inx], "task_template" , &tTemplate);
											if(iRetcode == ITK_ok && tTemplate != NULLTAG)
											{
												//get the task "icon_key" of the review task
												//to know whether the task is a notify task or review task
												iRetcode = AOM_UIF_ask_value ( tTemplate, "icon_key" , &pcPropValue);
											}
											// get the signoff object
											if( iRetcode == ITK_ok && ptReviewSubTasks[isubTaskIndx] != NULLTAG)
												// 15.02 Mail Notification
												//iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
												iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "signoff_attachments", &iNumAttachs,&ptAttachsTagList);
											// get the user tag from the signoff object
											for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetcode == ITK_ok; iAttchIndx++)
											{
												if( iRetcode == ITK_ok && ptAttachsTagList != NULL)
												{
													iRetcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
													if( iRetcode == ITK_ok && tGroupMember != NULLTAG)
													{
														tReposibleParty = NULLTAG;
														iRetcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
													}
													if( iRetcode == ITK_ok && tReposibleParty != NULLTAG )
													{
														if(iRetcode == ITK_ok && State == EPM_pending && (tc_strcmp(pcPropValue ,"notifyTask") != 0) )
														{
															//Get all the user tags and TaskNames in structure sMail WorkFlowStruc
															tiauto_Store_TaskNames_per_User(&TaskNamesPerUserList,tReposibleParty,pcTaskName);
														}

														if(pcMailSubject != NULL && pcBodyMsg != NULL)
														{
															if((tc_strcmp(pcPropValue ,"notifyTask") == 0) && isApproved == true &&
																((tc_strstr(pcTaskName,"Approved E-mail") != NULL) ||(tc_strstr(pcTaskName,"Approved Email") != NULL)))
															{
																tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
															}
															else if((tc_strcmp(pcPropValue ,"notifyTask") == 0) && isRejected == true &&
																( (tc_strstr(pcTaskName,"Rejected E-mail") != NULL)|| (tc_strstr(pcTaskName,"Rejected Email") != NULL)) )
															{
																tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
															}
															else if(tc_strcmp(pcPropValue ,"notifyTask") != 0)
															{
																tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
															}
														}
													}
												}
											}
											SAFE_MEM_free(ptAttachsTagList);
											SAFE_MEM_free(pcPropValue);
										}
										SAFE_MEM_free(pcSubTaskType);
									}
								}
								SAFE_MEM_free(ptReviewSubTasks);
							}
							else if(tc_strcmp(pcTaskTypeName,"EPMConditionTask")==0 )
							{
								iRetcode = AOM_ask_value_tag ( ptTasks[inx],"task_template" ,&tTemplate);
								//iRetcode = EPM_find_handler(tTemplate,EPM_action_handler_type,EPM_complete_action,cHandlerName,&tHandler);
								iRetcode = EPM_ask_action_handlers(tTemplate,EPM_start_action,&iCntActionHandlers,&pActionHandlers);
								for(iCnt = 0; iCnt < iCntActionHandlers ; iCnt++)
								{
									iRetcode = AOM_ask_name(pActionHandlers[iCnt],&cHandlerName);
									if( iRetcode == ITK_ok && (tc_strcmp(cHandlerName,"set-condition") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-verify-status-progression") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-check-status-progression") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 ||
										tc_strcmp(cHandlerName,"EPM-set-condition") == 0||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-additional-reviewers-as-resp-party") == 0||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-optedin-user-as-resp-party") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-prototype-task-result") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-check-mandatory-screening-need") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 ||
										tc_strcmp(cHandlerName,"TIAUTO-AH-set-prototype-task-result") == 0)
									  )
									{
										isAutomatedTask = true;
										break;
									}
								}
								if( isAutomatedTask == false)
								{
									iRetcode = EPM_find_handler(tTemplate,EPM_rule_handler_type,EPM_start_action,"TIAUTO-RH-check-mra-dataset-creation",&tHandler);
									if(iRetcode == ITK_ok && tHandler !=NULLTAG )
									{
										isAutomatedTask = true;
									}
									/*iRetcode = EPM_ask_rules (tTemplate,EPM_start_action,&iCntRule,&pRule);
									for(iCnt = 0; iCnt < iCntRule ; iCnt++)
									{
										iRetcode = EPM_ask_rule_handlers(pRule[iCnt],&iCntRuleHandlers,&pRuleHandlers);
										for(ix = 0; ix < iCntRuleHandlers; ix++)
										{
											iRetcode = AOM_ask_name(pRuleHandlers[ix],&cHandlerName);
											if(iRetcode == ITK_ok && tc_strcmp(cHandlerName,"TIAUTO-RH-check-mra-dataset-creation ") == 0 )
											{
												isAutomatedTask = true;
												break;
											}
										}
									}*/
								}
								if(isAutomatedTask == false )
								{

									//get the responsible party of the task
									iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
									if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
									{
										if(iRetcode == ITK_ok && State == EPM_pending)
										{
											//Get all the user tags and TaskNames in structure sMail WorkFlowStruc
											tiauto_Store_TaskNames_per_User(&TaskNamesPerUserList,tReposibleParty,pcTaskName);
										}
										if(pcMailSubject != NULL && pcBodyMsg != NULL)
										{
											tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
										}
									}
								}
							}
							isAutomatedTask = false;
						}
						SAFE_MEM_free(pcTaskTypeName);
					}
					SAFE_MEM_free(pcTaskName);
				}//for loop ends here.
			}
		}
		if(iRetcode == ITK_ok && tEngChangeRev!= NULLTAG)
		{
			iRetcode = AOM_ask_value_tag(tEngChangeRev,"owning_site",&tpropTag);
				if(iRetcode == ITK_ok && tpropTag != NULLTAG )
				{
					iRetcode = AOM_ask_name(tpropTag,&pcSiteName);
				}
				else
				{
					iRetcode = POM_site_id(&iSite);
					if(iSite != 0)
						iRetcode = SA_find_site_by_id(iSite,&tSitetag);
					if(iRetcode == ITK_ok && tSitetag!= NULLTAG)
						iRetcode = SA_ask_site_info(tSitetag,acSiteName,&iSiteID);
				}
		}
		if(iRetcode == ITK_ok && pcMailSubject != NULL && pcBodyMsg != NULL)
		{

			iRetcode = EPM_ask_name  ( msg.task , caTaskName);
			iRetcode = AOM_ask_name(tRootTaskTag,&pcTaskName);

			if(tc_strcmp(caTaskName,"17_120 Send PCI Approved Email") == 0 || tc_strcmp(caTaskName,"17_140 Send PCI Rejected Email") == 0)
			{
				//get based on change
				iRetcode = AOM_ask_value_tags( tEngChangeRev,Rel_Change_ObjectRev,&iNum,&ptBasedonEngChangeRev);
				if(iNum > 0)
				{
					tBasedonEngChangeRev = ptBasedonEngChangeRev[0];

					iRetcode = AOM_ask_value_tags(tBasedonEngChangeRev,PROP_All_Workflows,&iAllTasks, &ptAllTaskTags);
					if(iAllTasks > 0)
					{
						int iCount = 0;
						iRetcode= EPM_ask_root_task(ptAllTaskTags[0], &tPrevbasedOnRootTaskTag);
						//Get the subtasks and iterate through them.
						if(iRetcode == ITK_ok && tPrevbasedOnRootTaskTag != NULLTAG)
						{
							iRetcode = EPM_ask_sub_tasks(tPrevbasedOnRootTaskTag,&iCount,&ptTasks);
							if(iRetcode == ITK_ok && iCount > 0)
							{
								for(inx= 0;inx<iCount;inx++)
								{
									iRetcode = AOM_ask_name(ptTasks[inx],&pcTaskName);

									//if the task name contains "Incorrect Change Type", then that task will not be considered
									if(iRetcode == ITK_ok && ( tc_strstr(pcTaskName,"Incorrect Change Type") == NULL) && ( tc_strstr(pcTaskName,"Send Mandatory Screening Notification") == NULL))
									{
										if(iRetcode == ITK_ok && pcTaskName!= NULL)
										{
											iRetcode = TCTYPE_ask_object_type(ptTasks[inx],&tTaskType);
										}
										if(iRetcode == ITK_ok && tTaskType != NULLTAG)
										{
											iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
										}

										if(iRetcode == ITK_ok && pcTaskTypeName != NULL  )
										{
											//check if the task type is a ECO/Do Task/CheckList
											if( (tc_strcmp(pcTaskTypeName,"ECMPrepareECOTask")==0 ) ||
												(tc_strcmp(pcTaskTypeName,"EPMDoTask")== 0 ) ||
												(tc_strcmp(pcTaskTypeName,"ECMChecklistTask")== 0) )
											{
												//get the responsible party of the task
												iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
												if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
												{
													if(pcMailSubject != NULL && pcBodyMsg != NULL)
													{
														tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
													}

												}
											}
											else if( (tc_strcmp(pcTaskTypeName,"EPMReviewTask")==0) ||
													(tc_strcmp(pcTaskTypeName,"EPMAcknowledgeTask")==0) )
											{
												//for review and acknowledge task
												iRetcode = EPM_ask_sub_tasks( ptTasks[inx], &iSubTaskCnt, &ptReviewSubTasks );
												if( iRetcode == ITK_ok && ptReviewSubTasks != NULL )
												{
													for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && iRetcode == ITK_ok; isubTaskIndx++  )
													{

														iRetcode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
														if( iRetcode == ITK_ok && pcSubTaskType != NULL &&
															(tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
														{
															iRetcode = AOM_ask_value_tag  ( ptTasks[inx], "task_template" , &tTemplate);
															if(iRetcode == ITK_ok && tTemplate != NULLTAG)
															{
																//get the task "icon_key" of the review task
																//to know whether the task is a notify task or review task
																iRetcode = AOM_UIF_ask_value ( tTemplate, "icon_key" , &pcPropValue);
															}
															// get the signoff object
															if( iRetcode == ITK_ok && ptReviewSubTasks[isubTaskIndx] != NULLTAG)
																// 15.02 Mail Notification
																//iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
															    iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "signoff_attachments", &iNumAttachs,&ptAttachsTagList);
															// get the user tag from the signoff object
															for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetcode == ITK_ok; iAttchIndx++)
															{
																if( iRetcode == ITK_ok && ptAttachsTagList != NULL)
																{
																	iRetcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
																	if( iRetcode == ITK_ok && tGroupMember != NULLTAG)
																	{
																		tReposibleParty = NULLTAG;
																		iRetcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
																	}
																	if( iRetcode == ITK_ok && tReposibleParty != NULLTAG )
																	{


																		if(pcMailSubject != NULL && pcBodyMsg != NULL)
																		{
																			if((tc_strcmp(pcPropValue ,"notifyTask") == 0) && isApproved == true &&
																				((tc_strstr(pcTaskName,"Approved E-mail") != NULL) ||(tc_strstr(pcTaskName,"Approved Email") != NULL)))
																			{
																				tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
																			}
																			else if((tc_strcmp(pcPropValue ,"notifyTask") == 0) && isRejected == true &&
																				( (tc_strstr(pcTaskName,"Rejected E-mail") != NULL)|| (tc_strstr(pcTaskName,"Rejected Email") != NULL)) )
																			{
																				tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
																			}
																			else if(tc_strcmp(pcPropValue ,"notifyTask") != 0)
																			{
																				tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
																			}
																		}
																	}
																}
															}
															SAFE_MEM_free(ptAttachsTagList);
															SAFE_MEM_free(pcPropValue);
														}
														SAFE_MEM_free(pcSubTaskType);
													}
												}
												SAFE_MEM_free(ptReviewSubTasks);
											}
											else if(tc_strcmp(pcTaskTypeName,"EPMConditionTask")==0 )
											{
												iRetcode = AOM_ask_value_tag ( ptTasks[inx],"task_template" ,&tTemplate);
												//iRetcode = EPM_find_handler(tTemplate,EPM_action_handler_type,EPM_complete_action,cHandlerName,&tHandler);
												iRetcode = EPM_ask_action_handlers(tTemplate,EPM_start_action,&iCntActionHandlers,&pActionHandlers);
												for(iCnt = 0; iCnt < iCntActionHandlers ; iCnt++)
												{
													iRetcode = AOM_ask_name(pActionHandlers[iCnt],&cHandlerName);
													if( iRetcode == ITK_ok && (tc_strcmp(cHandlerName,"set-condition") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-verify-status-progression") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-check-status-progression") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 ||
														tc_strcmp(cHandlerName,"EPM-set-condition") == 0||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-additional-reviewers-as-resp-party") == 0||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-optedin-user-as-resp-party") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-prototype-task-result") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-check-mandatory-screening-need") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 ||
														tc_strcmp(cHandlerName,"TIAUTO-AH-set-prototype-task-result") == 0 )
													  )
													{
														isAutomatedTask = true;
														break;
													}
												}
												if( isAutomatedTask == false)
												{
													iRetcode = EPM_find_handler(tTemplate,EPM_rule_handler_type,EPM_start_action,"TIAUTO-RH-check-mra-dataset-creation",&tHandler);
													if(iRetcode == ITK_ok && tHandler !=NULLTAG )
													{
														isAutomatedTask = true;
													}
												}
												if(isAutomatedTask == false )
												{

													//get the responsible party of the task
													iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
													if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
													{
														if(pcMailSubject != NULL && pcBodyMsg != NULL)
														{
															tiauto_Store_TaskNames_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
														}
													}
												}
											}
											isAutomatedTask = false;
										}
										SAFE_MEM_free(pcTaskTypeName);
									}
									SAFE_MEM_free(pcTaskName);
								}//for loop ends here.
							}
						}
					}
				}

			}

			iRetcode = EPM_ask_name  ( msg.task , caTaskName);
			iRetcode = AOM_ask_name(tRootTaskTag,&pcTaskName);

			TI_sprintf(acSubject,"%s in %s : %s(%s)",pcMailSubject,acSiteName,pcTaskName,caTaskName);

			pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);

			iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
			fprintf(fMailBodyFile,"Change Revision      : %s/%s-%s\n",acChnId, acChnRevId, acChnName);
			fprintf(fMailBodyFile,"Process Name         : %s\n",pcTaskName);
			fprintf(fMailBodyFile,"Current Task Name    : %s\n",caTaskName);
			fprintf(fMailBodyFile,"Database             : %s\n",acSiteName);
			fprintf(fMailBodyFile,"\nInstructions : %s\n", pcBodyMsg);
			if(isRejected)
			{
				fprintf(fMailBodyFile, "\nRejection Details :\n");
				fprintf(fMailBodyFile,"----------------------\n");
				fprintf(fMailBodyFile,"\nRejected at Task        : %s",pcRejectedTask);
				fprintf(fMailBodyFile,"\nRejected By             : %s",pcRespPartyName);
				fprintf(fMailBodyFile,"\nRole Name               : %s",pcRespPartyRoleName);
				fprintf(fMailBodyFile,"\nGroup Name              : %s",pcRespPartyGroupName);
				fprintf(fMailBodyFile,"\nReason for Rejection    : %s\n",pcCommentValue);
			}
			//find MRA Details
			if(tEngChangeRev != NULLTAG)
			{
				char    pszObjType[WSO_name_size_c+1]="";
				iRetcode = WSOM_ask_object_type(tEngChangeRev, pszObjType);
				//get all the MRA documents & check whether PDF dataset is present with named reference

				if (iRetcode == ITK_ok && tc_strcmp (pszObjType, NEWCHANGE_REV) == 0 )
				{
					tag_t tRelTemp = NULLTAG;
					iRetcode = GRM_find_relation_type ("CMHasSolutionItem",&tRelTemp);
					if(iRetcode == ITK_ok && tRelTemp!=NULLTAG)
					{
						iRetcode = GRM_list_secondary_objects_only(tEngChangeRev,tRelTemp,&iSolItemRevs,&ptSolItemRevs);
					}
				}
				else
					iRetcode = ECM_get_contents (tEngChangeRev,"solution_items",&iSolItemRevs,&ptSolItemRevs);
				//verify in Ref. folder
				for (iCount = 0; iCount < iSolItemRevs ; iCount++)
				{
					tc_strcpy(acObjectType,"");
					/* get the object type */
					iRetcode = WSOM_ask_object_type (ptSolItemRevs[iCount], acObjectType);
					if(tc_strcmp(acObjectType,"T8_T_MfgRelAuth Revision") == 0)
					{
						isMRAFound = true;

						iRetcode = TC_tag_to_url(ptSolItemRevs[iCount],PORTAL,&pcMRAURL);
						WSOM_ask_id_string (ptSolItemRevs[iCount],&pcMRAId);

						if(isMRADocDetails == false)
						{
							isMRADocDetails = true;
							fprintf(fMailBodyFile,"\n\nMfgRelAuthorisation Revision(s)    : \n");
							fprintf(fMailBodyFile,"\n%-20s%s","MRA Revision Id","URL");
							fprintf(fMailBodyFile,"\n%-20s%s","---------------","----------------------------------");
						}

						if(pcMRAURL != NULL)
							fprintf(fMailBodyFile,"\n%-20s%s",pcMRAId,pcMRAURL);
					}
					if(tc_strcmp(acObjectType,"T8_T_AdvChangeRevision") == 0)
					{
						isACDFound = true;

						iRetcode = TC_tag_to_url(ptSolItemRevs[iCount],PORTAL,&pcACDURL);
						WSOM_ask_id_string (ptSolItemRevs[iCount],&pcACDId);

						if(isACDDetails == false)
						{
							isACDDetails = true;
							fprintf(fMailBodyFile,"\n\nADV Change Document Revision(s)    : \n");
							fprintf(fMailBodyFile,"\n%-20s%s","TRA Revision Id","URL");
							fprintf(fMailBodyFile,"\n%-20s%s","---------------","----------------------------------");
						}

						if(pcACDURL != NULL)
							fprintf(fMailBodyFile,"\n%-20s%s",pcACDId,pcACDURL);
					}
				}
			}
			if(fMailBodyFile != NULL)
			{
				fclose(fMailBodyFile);
			}
			while(NotifyUserList != NULL && iRetcode == ITK_ok)
			{
				iRetcode = EPM_get_user_email_addr(NotifyUserList->tUniqueUser,&pcEmailId );

				if(iRetcode == ITK_ok &&  pcEmailId != NULL)
				{
					if(pcEmailId != NULL)
						iRetcode = tiauto_sendEMail(acSubject, pcEmailId, pcMailBodyFileName);
				}
				NotifyUserList = NotifyUserList->next;
				SAFE_MEM_free(pcEmailId);
			}

			SAFE_MEM_free(pcComments);
			// delete temporary file here
			remove(pcMailBodyFileName );

		}
		else if(iRetcode == ITK_ok)
		{
			//get additional attribute information
			if(tEngChangeRev != NULLTAG)
			{
				if(tInitiatorTag != NULLTAG)
				{
					iRetcode = SA_ask_user_person_name2(tInitiatorTag, &pcInitiator);
				}

				iRetcode = GRM_find_relation_type("IMAN_specification",&tRelation);

				iRetcode = GRM_list_secondary_objects_only (tEngChangeRev,tRelation,&iSecondaryObjNo,&tSecObj);

				if(iRetcode == ITK_ok && iNumAttachs > 0)
				{
					for(i = 0; i < iSecondaryObjNo; i++)
					{
						iRetcode = AOM_ask_value_string(tSecObj[i],"object_type",&pcObjectType);
						//adding CAP3 changes
						if(tc_strcmp(pcObjectType, "T8_TI_CAP3") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedplants",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType, "T8_TI_CAP2") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190affectedplants",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a190changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_PMR") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_193affectedprogram",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_193tiplant",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_193changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "TI_PMR") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t1a84affectedprogram",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_84tiplant",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t1a84changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_CAP") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a120affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_120tiplant",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a120changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_CRO") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_146affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_146changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_PCI") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_123affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a123affectedplant",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a123implementationsumm",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "TI_DEV") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t1a51affectedprograms",&pcAffPrograms);
							break;
						}
						if(tc_strcmp(pcObjectType , "TI_OBS") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t1a52affectedprograms",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t1a52description",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_TPR") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a201changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_TER") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a205changedescription",&pcChangeDescription);
							break;
						}
						if(tc_strcmp(pcObjectType , "T8_TI_PRP") == 0)
						{
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a206affectedprogram",&pcAffPrograms);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a206tiplant",&pcAffPlants);
							iRetcode = AOM_UIF_ask_value(tSecObj[i],"t8_t1a206changedescription",&pcChangeDescription);
							break;
						}
					}
				}
			}
			//Mail sending
			//Subject of the Mail
			TI_sprintf(acSubject,"Information : %s/%s-%s(%s)",acChnId, acChnRevId, acChnName,acSiteName);
			while(TaskNamesPerUserList != NULL && iRetcode == ITK_ok)
			{
				iRetcode = Send_Mail(TaskNamesPerUserList->tUniqueUser,TaskNamesPerUserList->allTasks,
										acChnId, acChnRevId, acSubject,acSiteName, pcInitiator,pcAffPrograms,pcAffPlants,pcChangeDescription);
				TaskNamesPerUserList = TaskNamesPerUserList->next;
			}//while loop for parsing unique users ends here.
		}
		//free the memory for linked lists
		FreeMemoryForLinkdList(TaskNamesPerUserList);
		FreeMemoryForLinkdList(NotifyUserList);
		SAFE_MEM_free(pcTaskName);
		SAFE_MEM_free(pcTaskTypeName);
		SAFE_MEM_free(ptTasks);
		SAFE_MEM_free(pcTaskTypeName);
	}
	if ( iRetcode != ITK_ok )
	{
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	SAFE_MEM_free(pcSiteName);
	SAFE_MEM_free(pcMailSubject);
	SAFE_MEM_free(pcBodyMsg);
	SAFE_MEM_free(pcMailSubject);

	return iRetcode;
}

/*=====================================================================================
*  FreeMemoryForLinkdList()
*\param				TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList
*\return void
* Description:
*			To free the structure.
=====================================================================================*/
void FreeMemoryForLinkdList(TIA_TaskNamesAssignedPerUser *TaskNamesPerUserList)
{
	TIA_TaskNamesAssignedPerUser *tempFree1 = NULL;
	while(TaskNamesPerUserList != NULL)
	{
		tempFree1 = TaskNamesPerUserList->next;
		free (TaskNamesPerUserList);
		TaskNamesPerUserList = tempFree1;
		tempFree1 = NULL;
	}
	return;
}
/*=====================================================================================
*   tiauto_Store_TaskNames_per_User()
*\param				TIA_TaskNamesAssignedPerUser	**TaskNamesPerUserList, <I>
*					tag_t							tUser,					<I>
*					char							*pcTaskName				<I>
*\return void
* Description:
*			To store all the tasks per user(unique).
=====================================================================================*/
extern void tiauto_Store_TaskNames_per_User(TIA_TaskNamesAssignedPerUser **TaskNamesPerUserList, tag_t tUser, char* pcTaskName)
{
	TIA_TaskNamesAssignedPerUser *temp;
    logical isPresent = false;
	temp = *TaskNamesPerUserList;

	if( (*TaskNamesPerUserList == NULL) || (temp == NULL) )
	{
		*TaskNamesPerUserList=malloc(sizeof(TIA_TaskNamesAssignedPerUser));
		temp = *TaskNamesPerUserList;
		TI_sprintf(temp->allTasks, "");
	}
	else
	{
		for(;;)
		{
			if( temp->tUniqueUser == tUser )
			{
				isPresent = true;
				TI_sprintf(temp->allTasks,"%s\n%s",temp->allTasks,pcTaskName);
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_TaskNamesAssignedPerUser));
			temp=temp->next;
			TI_sprintf(temp->allTasks, "");
		}
	}
	if ( isPresent == false )
	{
		temp->tUniqueUser = tUser;
		TI_sprintf(temp->allTasks,"%s",pcTaskName);
		temp->next  = NULL;
	}

	//free ( temp );
	temp = NULL;
}

/*=====================================================================================
*   Send_Mail()
*\param				tag_t	tUser,			<I>
					char	*pcAllTasks,	<I>
					char	*pcChangeId,	<I>
					char	*pcRevId,		<I>
					char	*pcSubject		<I>
*\return int
* Description:
*			To send the mails.
=====================================================================================*/
int Send_Mail(tag_t tUser,char *pcAllTasks,char *pcChangeId,char *pcRevId,char *pcSubject,char *pcSiteName,
							char *pcInitiator,char *pcAffPrograms,char *pcAffPlants,char *pcChangeDescription)
{
	int iRetCode = ITK_ok;
	//txt_t		the_text_server								= NULL;
	int         iFileOpenErrCode                            = 0;
    //char		*pcMsgName									= NULL;
    char		*pcComments									= NULL;
	char		*pcUserName									= NULL;
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	FILE		*fMailBodyFile								= NULL;

	iRetCode = EPM_get_user_email_addr(tUser,&pcEmailId );
	if(iRetCode == ITK_ok)
		iRetCode = SA_ask_user_person_name2 (tUser,&pcUserName );
	if(iRetCode == ITK_ok &&  pcEmailId != NULL)
	{
		//Initialize TextServer here
		//the_text_server = txt_ctor( "iman_text.xml" );
		//pcMsgName = "User_Comments";
		//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
		//txt_destructor(the_text_server);
		pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);

		iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
		fprintf(fMailBodyFile,"Dear %s,\n\n",pcUserName);

		if(pcChangeDescription != NULL)
			fprintf(fMailBodyFile,"Change Description  : %s,\n",pcChangeDescription);
		if(pcAffPrograms != NULL)
			fprintf(fMailBodyFile,"Affected Programs   : %s,\n",pcAffPrograms);
		if(pcAffPlants != NULL)
			fprintf(fMailBodyFile,"Affected Plants     : %s,\n",pcAffPlants);
		if(pcInitiator != NULL)
			fprintf(fMailBodyFile,"Change Initiator    : %s,\n",pcInitiator);

		fprintf(fMailBodyFile,"\n%s %s/%s in %s%s\n%s\n\n%s",
								TIAUTO_ASSIGNMENT_EMAIL_TEXT1,pcChangeId,pcRevId,pcSiteName,
								TIAUTO_ASSIGNMENT_EMAIL_TEXT2,pcAllTasks,
								TIAUTO_ASSIGNMENT_EMAIL_TEXT3 );

		if(fMailBodyFile != NULL)
		{
			fclose(fMailBodyFile);
		}
		if(pcEmailId != NULL)
			iRetCode = tiauto_sendEMail(pcSubject, pcEmailId, pcMailBodyFileName);
	}

	SAFE_MEM_free(pcComments);
	SAFE_MEM_free(pcUserName);
	SAFE_MEM_free(pcEmailId);
	// delete temporary file here
    remove(pcMailBodyFileName );
	return iRetCode;
}

int findRejectionDetails(tag_t tTask, char **pcRejectedTask, char **pcCommentValue, char **pcRespPartyName, char **pcRespPartyGroupName, char **pcRespPartyRoleName)
{
	int iRetCode = ITK_ok, i=0, j=0, inx=0, iCnt=0, iCheckReviewsubTaskIndx=0;
	int iAuditfile_linecnt = 0;
	int iSubTasksCount = 0;
	int iCntActionHandlers = 0;
	int iReviewSubTaskCount = 0;
	int iNumAttachs = 0;
	int iAttchIndx =0;
	long sz = 0;
	//const char  *cnew_Auditfile_pathname = "Audit.txt";
	char  cnew_Auditfile_pathname[500]="";
	char *pcActionName  = NULL;
	char *pcTaskName  = NULL;
	char *pcDateNTime  = NULL;
	char *pcUserName	 = NULL;
	char *pcSurrUserName	 = NULL;
	char *pcSubTaskName = NULL;
	char acBuffer[200] = "";
	char cRespPartyRoleName[SA_name_size_c+1] = {'\0'};
	char cRespPartyGroupName[SA_name_size_c+1] = {'\0'};
	char cRespPartyName[SA_person_name_size_c+1] = {'\0'};
	char *ret = NULL;
	char *pcSubTaskTypeName = NULL;
	char *pccomment_value = NULL;
	char *pcTempRejectTaskName = NULL;
	char* pcHandlerName = NULL;
	char *pcReviewSubTaskName = NULL;
	char *pcReviewSubTaskType = NULL;
	char *auditFileName = NULL;
	FILE *auditFilefp = NULL;
	tag_t tJob = NULLTAG;
	tag_t tRootTask = NULLTAG;
	tag_t tAuditFile = NULLTAG;
	tag_t *ptSubTasksTags = NULL;
	tag_t tRespParty = NULLTAG;
	tag_t tRespPartyGroup = NULLTAG;
	tag_t tRespPartyRole = NULLTAG;
	tag_t tTemplate = NULLTAG;
	tag_t tHandler = NULLTAG;
	tag_t tSubTaskType = NULLTAG;
	tag_t tGroupMember = NULLTAG;
	tag_t *ptActionHandlers = NULL;
	tag_t *ptReviewSubTaskTags = NULL;
	tag_t *ptAttachsTagList = NULL;
	char *tempStr = NULL;
	//EPM_state_t tSubTaskState;

	logical isAutomatedTask = false;
	logical bIsValid = false;
	char        sztemp[200];
	time_t ltime;
	errno_t err;
    struct tm Tm;

	DWORD        aa = GetTempPath(200, sztemp);
    ltime=time(NULL);
    //Tm=localtime(&ltime);
	err = localtime_s(&Tm,&ltime);

	if(tTask!=NULLTAG)
	{
		iRetCode = EPM_ask_job(tTask,&tJob);
		if (iRetCode == ITK_ok && tJob != NULLTAG)
			iRetCode = EPM_ask_root_task (tJob, &tRootTask);
		if (iRetCode == ITK_ok && tJob != NULLTAG)
			iRetCode = EPM_ask_audit_file(tJob, &tAuditFile);
		//if (iRetCode == ITK_ok)
			//iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
		if (iRetCode == ITK_ok)
		{
			iRetCode = AOM_ask_value_string(tAuditFile,"original_file_name",&tempStr );
			//auditFileName = (char *) malloc(sizeof(char)*tc_strlen(tempStr));
			//tc_strncpy(auditFileName, tempStr, tc_strlen(tempStr)-4);
			//*(auditFileName+ tc_strlen(tempStr)-4) = '\0';
			TI_sprintf(cnew_Auditfile_pathname,"%s%s_%d%d%d%d%d%d.txt",sztemp,tempStr,Tm.tm_mday,Tm.tm_mon,Tm.tm_year,Tm.tm_hour,Tm.tm_min, Tm.tm_sec);
			iRetCode = IMF_export_file (tAuditFile,cnew_Auditfile_pathname);
			//iRetCode = IMF_get_file_access (   tAuditFile,0, &file_data);
		}
		if (iRetCode == ITK_ok)
		{
			//if(file_data != 0)
			//	iRetCode =  IMF_get_filename (file_data, &cnew_Auditfile_pathname);
			if(tc_strlen(cnew_Auditfile_pathname)>0)
				iRetCode  = fopen_s(&auditFilefp,cnew_Auditfile_pathname, "rb");
		}
		if (auditFilefp == NULL)
		{
			 //printf("Error! Could not open file\n");
			//if(file_data != 0)
				//iRetCode =  IMF_release_file_access(&file_data);

			 return 0; // must include stdlib.h
		}
		sz = fsize(auditFilefp);

		if (sz > 0)
		{
			char buf[256];
			fseek(auditFilefp, sz, SEEK_SET);
			while (fgetsr(buf, sizeof(buf), auditFilefp) != NULL)
			{
				//printf("%s", buf);
				iAuditfile_linecnt++;
				if( iRetCode == ITK_ok )
				{
					if( tc_strlen(buf) > 0 )
					{

						if( ( (buf[0] >= 'A') && (buf[0] <= 'Z') ) || ( (buf[0] >= 'a') && (buf[0] <= 'z') ) )
						{
							tc_strcpy(acBuffer,"");
							//memset(&acBuffer[0], 0, sizeof(acBuffer));  //Clearing the acBuffer array
							for(i = 0,j = 0;  (i < 17) && (buf[i] != '\0'); i++, j++)
							{
								acBuffer[j] = buf[i];
							}
							RemoveTrailingBlanks(acBuffer);
							if (tc_strcmp(acBuffer,"Complete") == 0)
							{
								iRetCode = GetTaskNameDateAndUserInfo(buf, &pcActionName, &pcTaskName, &pcDateNTime, &pcUserName, &pcSurrUserName);

								if(iRetCode == ITK_ok && tRootTask != NULLTAG)
								{
									iRetCode = EPM_ask_sub_tasks(tRootTask,&iSubTasksCount,&ptSubTasksTags);
									if(iRetCode == ITK_ok && iSubTasksCount > 0)
									{
										for(inx= 0;inx<iSubTasksCount;inx++)
										{
											iRetCode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
											if(iRetCode == ITK_ok)
												ret = tc_strstr(pcSubTaskName, pcTaskName);
											if (ret != NULL)
											{
												iRetCode = TCTYPE_ask_object_type(ptSubTasksTags[inx],&tSubTaskType);
												if(iRetCode == ITK_ok && tSubTaskType != NULLTAG)
												{
													iRetCode = AOM_ask_name(tSubTaskType,&pcSubTaskTypeName);
												}

												if( (tc_strcmp(pcSubTaskTypeName,"ECMPrepareECOTask")==0 ) ||
												(tc_strcmp(pcSubTaskTypeName,"EPMDoTask")== 0 ) ||
												(tc_strcmp(pcSubTaskTypeName,"ECMChecklistTask")== 0) )
												{
													//Get the comment passed by the responsible party
													iRetCode = AOM_ask_value_string( ptSubTasksTags[inx], "comments", &pccomment_value );
													if( iRetCode==ITK_ok && pccomment_value!=NULL)
													{
														//*pcCommentValue = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
														*pcCommentValue = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
														tc_strcpy(*pcCommentValue, pccomment_value);
													}
													//Get the Task at which the change was rejected
													iRetCode = AOM_ask_name(ptSubTasksTags[inx],&pcTempRejectTaskName);
													if( iRetCode==ITK_ok && pcTempRejectTaskName!=NULL)
													{
														//*pcRejectedTask = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);
														*pcRejectedTask = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
														tc_strcpy(*pcRejectedTask, pcTempRejectTaskName);
													}
													//get the responsible party of the task
													iRetCode = EPM_ask_responsible_party(ptSubTasksTags[inx],&tRespParty);
													if(iRetCode == ITK_ok && tRespParty != NULLTAG)
													{
														/*Get task responsinble party's role and group*/
														if (iRetCode == ITK_ok)
															iRetCode = SA_ask_user_person_name(tRespParty, cRespPartyName) ;
														if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyName,"") != 0))
														{
															//*pcRespPartyName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyName)+1);
															*pcRespPartyName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyName)+1));
															tc_strcpy(*pcRespPartyName, cRespPartyName);
															iRetCode = SA_ask_user_login_group(tRespParty,&tRespPartyGroup );
														}
														if (iRetCode == ITK_ok && tRespPartyGroup!= NULLTAG)
															iRetCode = SA_ask_group_name (tRespPartyGroup, cRespPartyGroupName);
														if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyGroupName,"") != 0))
														{
															//*pcRespPartyGroupName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyGroupName)+1);
															*pcRespPartyGroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyGroupName)+1));
															tc_strcpy(*pcRespPartyGroupName, cRespPartyGroupName);
															iRetCode = SA_ask_user_default_role_in_group(tRespParty,tRespPartyGroup,&tRespPartyRole);
														}
														if (iRetCode == ITK_ok && tRespPartyRole!=NULLTAG)
															iRetCode = SA_ask_role_name(tRespPartyRole, cRespPartyRoleName);
														if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyRoleName,"") != 0))
														{
															//*pcRespPartyRoleName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyRoleName)+1);
															*pcRespPartyRoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyRoleName)+1));
															tc_strcpy(*pcRespPartyRoleName, cRespPartyRoleName);
														}
														fclose(auditFilefp);
														iRetCode = remove(cnew_Auditfile_pathname);
														//if(file_data != 0)
															//iRetCode =  IMF_release_file_access(&file_data);
														if( iRetCode == 0 )
															printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);
														SAFE_MEM_free(ptSubTasksTags);
														return iRetCode;
													}
												}
												else if(tc_strcmp(pcSubTaskTypeName,"EPMConditionTask")==0 )
												{
													iRetCode = AOM_ask_value_tag ( ptSubTasksTags[inx],"task_template" ,&tTemplate);
													iRetCode = EPM_ask_action_handlers(tTemplate,EPM_start_action,&iCntActionHandlers,&ptActionHandlers);
													for(iCnt = 0; iCnt < iCntActionHandlers ; iCnt++)
													{
														iRetCode = AOM_ask_name(ptActionHandlers[iCnt],&pcHandlerName);
														if( iRetCode == ITK_ok && (tc_strcmp(pcHandlerName,"set-condition") == 0 ||
															tc_strcmp(pcHandlerName,"TIAUTO-AH-verify-status-progression") == 0 ||
															tc_strcmp(pcHandlerName,"TIAUTO-AH-check-status-progression") == 0 ||
															tc_strcmp(pcHandlerName,"TIAUTO-AH-set-conditional-based-on-reviewer-list") == 0 )
														  )
														{
															isAutomatedTask = true;
															break;
														}
													}
													SAFE_MEM_free( ptActionHandlers);
													if( isAutomatedTask == false)
													{
														iRetCode = EPM_find_handler(tTemplate,EPM_rule_handler_type,EPM_start_action,"TIAUTO-RH-check-mra-dataset-creation",&tHandler);
														if(iRetCode == ITK_ok && tHandler !=NULLTAG )
														{
															isAutomatedTask = true;
														}
													}
													if(isAutomatedTask == false )
													{
														//Get the comment passed by the responsible party
														iRetCode = AOM_ask_value_string( ptSubTasksTags[inx], "comments", &pccomment_value );
														if( iRetCode==ITK_ok && pccomment_value!=NULL)
														{
															//*pcCommentValue = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
															*pcCommentValue = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
															tc_strcpy(*pcCommentValue, pccomment_value);
														}

														//Get the Task at which the change was rejected
														iRetCode = AOM_ask_name(ptSubTasksTags[inx],&pcTempRejectTaskName);
														if( iRetCode==ITK_ok && pcTempRejectTaskName!=NULL)
														{
															//*pcRejectedTask = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);
															*pcRejectedTask = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
															tc_strcpy(*pcRejectedTask, pcTempRejectTaskName);
														}
														//get the responsible party of the task
														iRetCode = EPM_ask_responsible_party(ptSubTasksTags[inx],&tRespParty);
														if(iRetCode == ITK_ok && tRespParty != NULLTAG)
														{
															/*Get task responsinble party's role and group*/
															if (iRetCode == ITK_ok)
																iRetCode = SA_ask_user_person_name(tRespParty, cRespPartyName) ;
															if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyName,"") != 0))
															{
																//*pcRespPartyName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyName)+1);
																*pcRespPartyName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyName)+1));
																tc_strcpy(*pcRespPartyName, cRespPartyName);
																iRetCode = SA_ask_user_login_group(tRespParty,&tRespPartyGroup );
															}
															if (iRetCode == ITK_ok && tRespPartyGroup!= NULLTAG)
																iRetCode = SA_ask_group_name (tRespPartyGroup, cRespPartyGroupName);
															if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyGroupName,"") != 0))
															{
																//*pcRespPartyGroupName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyGroupName)+1);
																*pcRespPartyGroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyGroupName)+1));
																tc_strcpy(*pcRespPartyGroupName, cRespPartyGroupName);
																iRetCode = SA_ask_user_default_role_in_group(tRespParty,tRespPartyGroup,&tRespPartyRole);
															}
															if (iRetCode == ITK_ok && tRespPartyRole!=NULLTAG)
																iRetCode = SA_ask_role_name(tRespPartyRole, cRespPartyRoleName);
															if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyRoleName,"") != 0))
															{
																//*pcRespPartyRoleName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyRoleName)+1);
																*pcRespPartyRoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyRoleName)+1));
																tc_strcpy(*pcRespPartyRoleName, cRespPartyRoleName);
															}
														}
														fclose(auditFilefp);
														iRetCode = remove(cnew_Auditfile_pathname);
														//if(file_data != 0)
															//iRetCode =  IMF_release_file_access(&file_data);

														if( iRetCode == 0 )
															printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);
														//printf("iretcode = %d", iRetCode);
														return iRetCode;
													}
												}
												SAFE_MEM_free(pcSubTaskTypeName);
												isAutomatedTask = false;
												break;
											}
											SAFE_MEM_free(pcSubTaskName);
										}
									}
								}
							}
							else if (tc_strcmp(acBuffer,"Reject") == 0)
							{
								iRetCode = GetTaskNameDateAndUserInfo(buf, &pcActionName, &pcTaskName, &pcDateNTime, &pcUserName, &pcSurrUserName);
								//Get the subtasks and iterate through them.
								if(iRetCode == ITK_ok && tRootTask != NULLTAG)
								{
									iRetCode = EPM_ask_sub_tasks(tRootTask,&iSubTasksCount,&ptSubTasksTags);
									if(iRetCode == ITK_ok && iSubTasksCount > 0)
									{
										for(inx= 0;inx<iSubTasksCount;inx++)
										{
											iRetCode = AOM_ask_name(ptSubTasksTags[inx],&pcSubTaskName);
											if(iRetCode == ITK_ok)
											{
												//iRetCode = EPM_ask_state(ptSubTasksTags[inx],&tSubTaskState);
											}
											if(iRetCode == ITK_ok && pcSubTaskName!= NULL)
											{
												iRetCode = TCTYPE_ask_object_type(ptSubTasksTags[inx],&tSubTaskType);
											}
											if(iRetCode == ITK_ok && tSubTaskType != NULLTAG)
											{
												iRetCode = AOM_ask_name(tSubTaskType,&pcSubTaskTypeName);
											}
											if( iRetCode == ITK_ok && (tc_strcmp(pcSubTaskTypeName,"EPMReviewTask")==0) || (tc_strcmp(pcSubTaskTypeName,"EPMAcknowledgeTask")==0) )
											{
												iRetCode = EPM_ask_sub_tasks( ptSubTasksTags[inx], &iReviewSubTaskCount, &ptReviewSubTaskTags );
												if( iRetCode == ITK_ok && ptReviewSubTaskTags != NULL )
												{
													for(iCheckReviewsubTaskIndx=0; iRetCode == ITK_ok && iCheckReviewsubTaskIndx < iReviewSubTaskCount ; iCheckReviewsubTaskIndx++  )
													{
														bIsValid = false;
														iRetCode = AOM_ask_name(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],&pcReviewSubTaskName);
														if(tc_strstr(pcReviewSubTaskName, pcTaskName) != NULL)
														{
															bIsValid = true;
														}
														SAFE_MEM_free(pcReviewSubTaskName);
													}
													SAFE_MEM_free(pcReviewSubTaskName);
													for(iCheckReviewsubTaskIndx=0;bIsValid == true && iCheckReviewsubTaskIndx < iReviewSubTaskCount && iRetCode == ITK_ok; iCheckReviewsubTaskIndx++  )
													{
														iRetCode = AOM_ask_value_string( ptReviewSubTaskTags[iCheckReviewsubTaskIndx], "task_type", &pcReviewSubTaskType);
														//iRetCode = AOM_ask_name(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],&pcReviewSubTaskName);
														if( iRetCode == ITK_ok && pcReviewSubTaskType != NULL && (tc_strcmp(pcReviewSubTaskType, "EPMSelectSignoffTask") == 0) )
														{
															// get the signoff object
															if( iRetCode == ITK_ok && ptReviewSubTaskTags[iCheckReviewsubTaskIndx] != NULLTAG)
															{
																// 15.02 Mail Notification
																//iRetCode = AOM_ask_value_tags(ptReviewSubTaskTags[iCheckReviewsubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
																iRetCode = AOM_ask_value_tags(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],"signoff_attachments", &iNumAttachs,&ptAttachsTagList);
																for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetCode == ITK_ok; iAttchIndx++)
																{
																	if( iRetCode == ITK_ok && ptAttachsTagList != NULL)
																	{
																		iRetCode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
																		if( iRetCode == ITK_ok && tGroupMember != NULLTAG)
																		{
																			iRetCode = AOM_ask_value_tag(tGroupMember, "user", &tRespParty);
																			if (iRetCode == ITK_ok && tRespParty!=NULLTAG)
																				iRetCode = SA_ask_user_identifier (tRespParty, cRespPartyName) ;
																			if(tc_strcmp(cRespPartyName,"")!=0)
																			{
																				if(tc_strcmp(cRespPartyName,pcUserName)!=0)
																					continue;
																				// found the rejection signoff
																				if ((iRetCode == ITK_ok) && tRespParty!=NULLTAG)
																				{
																					iRetCode = SA_ask_user_person_name(tRespParty, cRespPartyName) ;
																					//*pcRespPartyName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyName)+1);
																					*pcRespPartyName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyName)+1));
																					tc_strcpy(*pcRespPartyName, cRespPartyName);
																				}
																				iRetCode = AOM_ask_value_string( ptAttachsTagList[iAttchIndx], "comments", &pccomment_value );
																				if( iRetCode==ITK_ok && pccomment_value!=NULL)
																				{
																					//*pcCommentValue = (char*)malloc(sizeof(char)*tc_strlen(pccomment_value)+1);
																					*pcCommentValue = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pccomment_value)+1));
																					tc_strcpy(*pcCommentValue, pccomment_value);
																				}
																				if ((iRetCode == ITK_ok))
																					iRetCode = SA_ask_user_login_group(tRespParty,&tRespPartyGroup );
																				if (iRetCode == ITK_ok)
																					iRetCode = SA_ask_group_name (tRespPartyGroup, cRespPartyGroupName);
																				if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyGroupName,"") != 0))
																				{
																					//*pcRespPartyGroupName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyGroupName)+1);
																					*pcRespPartyGroupName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyGroupName)+1));
																					tc_strcpy(*pcRespPartyGroupName, cRespPartyGroupName);
																				}
																				if (iRetCode == ITK_ok)
																					iRetCode = SA_ask_user_default_role_in_group(tRespParty,tRespPartyGroup,&tRespPartyRole);
																				if (iRetCode == ITK_ok)
																					iRetCode = SA_ask_role_name(tRespPartyRole, cRespPartyRoleName);
																				if ((iRetCode == ITK_ok) && (tc_strcmp(cRespPartyRoleName,"") != 0))
																				{
																					//*pcRespPartyRoleName = (char*)malloc(sizeof(char)*tc_strlen(cRespPartyRoleName)+1);
																					*pcRespPartyRoleName = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(cRespPartyRoleName)+1));
																					tc_strcpy(*pcRespPartyRoleName, cRespPartyRoleName);
																				}
																			}
																		}
																	}
																}
																SAFE_MEM_free( ptAttachsTagList);
															}
														}
														if( iRetCode == ITK_ok && pcReviewSubTaskType != NULL &&
														(tc_strcmp(pcReviewSubTaskType, "EPMPerformSignoffTask") == 0) )
														{
															//Get the Task at which the change was rejected
															iRetCode = AOM_ask_name(ptReviewSubTaskTags[iCheckReviewsubTaskIndx],&pcTempRejectTaskName);
															if( iRetCode==ITK_ok && pcTempRejectTaskName!=NULL)
															{
																//*pcRejectedTask = (char*)malloc(sizeof(char)*tc_strlen(pcTempRejectTaskName)+1);
																*pcRejectedTask = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcTempRejectTaskName)+1));
																tc_strcpy(*pcRejectedTask, pcTempRejectTaskName);
															}
														}
														SAFE_MEM_free(pcReviewSubTaskType);
													}
													SAFE_MEM_free(ptReviewSubTaskTags);
													if(bIsValid)
													{
														fclose(auditFilefp);
														iRetCode = remove(cnew_Auditfile_pathname);
														//if(file_data != 0)
															//iRetCode =  IMF_release_file_access(&file_data);
														if( iRetCode == 0 )
															printf("%s Audit file deleted successfully.\n",cnew_Auditfile_pathname);
														return iRetCode;
													}
												}
											}
											SAFE_MEM_free(pcSubTaskTypeName);
											SAFE_MEM_free(pcSubTaskName);
										}
										SAFE_MEM_free(ptSubTasksTags);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return iRetCode;
}