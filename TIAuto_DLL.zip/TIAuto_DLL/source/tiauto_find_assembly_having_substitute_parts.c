#include <tiauto_find_assembly_having_substitute_parts.h>

extern int find_assembly_having_substitute_parts(const char* Keyword_ItemID,const char* Keyword_RevisionID,const char* Keyword_Name,const char* Keyword_ItemType,
												 const char* Keyword_CAD,const char* Keyword_CBD, const char* Keyword_MAD, const char* Keyword_MBD,
												 int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
    date_t aDate,bDate,cDate,dDate;

	/*create a query*/
		ifail = POM_enquiry_create ("findsubstituteitems");

    /*create pseudo alias*/
		ifail = POM_enquiry_set_pseudo_calias ("findsubstituteitems","ItemRevision","structure_revisions","STRUCTURE");
		ifail = POM_enquiry_set_pseudo_calias ("findsubstituteitems","PSAlternateList","alt_items","CLASS_ALT_ITEMS");

	//initialise the outputs
		ifail = POM_enquiry_add_select_attrs ( "findsubstituteitems", "ItemRevision", 1, select_attr_list1);

	//set join expression
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_1","PSOccurrence","parent_bvr",POM_enquiry_equal,"STRUCTURE","pval");
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_2","PSOccurrence","alternate_etc_ref",POM_enquiry_equal,"PSAlternateList","puid");
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_3","PSAlternateList","puid",POM_enquiry_equal,"CLASS_ALT_ITEMS","puid");
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_4","ItemRevision","puid",POM_enquiry_equal,"STRUCTURE","puid");
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_5","STRUCTURE","pval",POM_enquiry_equal,"PSBomViewRevision","puid");
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_6","ItemRevision","items_tag",POM_enquiry_equal,"Item","puid");
		
	//set join expression for dates, objectname and objecttype
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_7","ItemRevision","puid",POM_enquiry_equal,"WorkSpaceObject","puid"); 
		ifail = POM_enquiry_set_join_expr ("findsubstituteitems","auniqueExprId_8","WorkSpaceObject", "puid", POM_enquiry_equal, "Pom_application_object", "puid");

	//join the expression
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_9","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_3");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_4");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_5");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_6");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_14","auniqueExprId_13",POM_enquiry_and,"auniqueExprId_7");
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_15","auniqueExprId_14",POM_enquiry_and,"auniqueExprId_8");

//=======================================================================
     //setting all the keyword to uniquevalueID
//=======================================================================

		if (strcmp (Keyword_ItemID ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findsubstituteitems", "aunique_value_id1", 1,&Keyword_ItemID, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems","auniqueExprId_16","Item","item_id",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findsubstituteitems","auniqueExprId_16",POM_case_insensitive);
	  }

	 if (strcmp (Keyword_RevisionID ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findsubstituteitems", "aunique_value_id2", 1,&Keyword_RevisionID, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems","auniqueExprId_17","ItemRevision","item_revision_id",POM_enquiry_like,"aunique_value_id2");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findsubstituteitems","auniqueExprId_17",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_Name ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findsubstituteitems", "aunique_value_id3", 1,&Keyword_Name, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems","auniqueExprId_18","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id3");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findsubstituteitems","auniqueExprId_18",POM_case_insensitive);
	  }

	 if (strcmp (Keyword_ItemType ,"") != 0)

	 {
		ifail = POM_enquiry_set_string_value ("findsubstituteitems", "aunique_value_id4", 1,&Keyword_ItemType, POM_enquiry_bind_value );
        ifail = POM_enquiry_set_attr_expr ("findsubstituteitems","auniqueExprId_19","WorkspaceObject","object_type",POM_enquiry_equal,"aunique_value_id4");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findsubstituteitems","auniqueExprId_19",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_CAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_CAD, &aDate);

		ifail = POM_enquiry_set_date_value ("findsubstituteitems", "aunique_value_id5", 1, &aDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems", "auniqueExprId_20","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id5");
	  }

	 if (strcmp (Keyword_CBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_CBD, &bDate);
		 
		ifail = POM_enquiry_set_date_value ("findsubstituteitems", "aunique_value_id6", 1, &bDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems", "auniqueExprId_21","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id6");	

	  }

	 if (strcmp (Keyword_MAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_MAD, &cDate);

		ifail = POM_enquiry_set_date_value ("findsubstituteitems", "aunique_value_id7", 1, &cDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems", "auniqueExprId_22","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id7");	
	  }

	 if (strcmp (Keyword_MBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_MBD, &dDate);

		ifail = POM_enquiry_set_date_value ("findsubstituteitems", "aunique_value_id8", 1, &dDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findsubstituteitems", "auniqueExprId_23","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id8");
	  }
//===============================================================================================
                                          //join the main expression 
//===============================================================================================
	 if (strcmp (Keyword_ItemID ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_24","auniqueExprId_15",POM_enquiry_and,"auniqueExprId_16");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_24","auniqueExprId_15",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_RevisionID ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_25","auniqueExprId_24",POM_enquiry_and,"auniqueExprId_17");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_25","auniqueExprId_24",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_Name ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_26","auniqueExprId_25",POM_enquiry_and,"auniqueExprId_18");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_26","auniqueExprId_25",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ItemType ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_27","auniqueExprId_26",POM_enquiry_and,"auniqueExprId_19");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_27","auniqueExprId_26",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_CAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_28","auniqueExprId_27",POM_enquiry_and,"auniqueExprId_20");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_28","auniqueExprId_27",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_CBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_29","auniqueExprId_28",POM_enquiry_and,"auniqueExprId_21");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_29","auniqueExprId_28",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_MAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_30","auniqueExprId_29",POM_enquiry_and,"auniqueExprId_22");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_30","auniqueExprId_29",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_MBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_31","auniqueExprId_30",POM_enquiry_and,"auniqueExprId_23");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findsubstituteitems","auniqueExprId_31","auniqueExprId_30",POM_enquiry_and,"auniqueExprId_1");
	}

	//set where expression
	ifail = POM_enquiry_set_where_expr("findsubstituteitems","auniqueExprId_31");
	//set distinct vale
	ifail = POM_enquiry_set_distinct("findsubstituteitems", true);
	//execute the wuery
	ifail = POM_enquiry_execute ("findsubstituteitems",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("findsubstituteitems");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}	

	return ifail;
	
}
		

