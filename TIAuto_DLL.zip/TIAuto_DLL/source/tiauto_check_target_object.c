/*****************************************************************************************************************
FILE        :   tiauto_check_target_object.c

DESCRIPTION :   This file contains the implementation for 
                "TIAUTO-check-target-object" Custom Rule Handler. This handler
                validates release status of the change item revision and all the
                other item revisions present in the affected items and solution
                items change folders. This handler prevents the change process 
                to proceed further when status of any item revision does not match
                the specified allowed statuses in the argument.

                This rule handler should be configured with only - one argument.
                It can be configured with:
                "-lov"  - which takes name of the LOV as value OR
                "-status_allow" - which takes no. of allowed statuses with comma(,)
                separated. 

AUTHOR      :   Srikanth Pulluri, TCS

Revision History :
Date            Revision    Who              Description
July 17, 2007    1.0        Srikanth Pulluri  Initial Creation
March 23,2009	 1.1		Dipak Naik		  Modified to show all the error message 
											  in a single dialog.
March 23,2012	 1.2		Dipak Naik		  Modified to show the error message for the
											  WIP document revisions even though WIP
											  i.e. NONE parsed in the handler argument.
Nov 12, 2012	 1.3		Dipak Naik		  Modified to work for the other target object type i.e.
											  other than EngChange Revision.
*****************************************************************************************************************/
/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <lov/lov.h>

//#define TIAUTO_NO_ARGS_REQUIRED     (EMH_USER_error_base + 02)

/* static function prototypes */
static  int get_status_array_from_VALUES (char  *pszValue,
                                          STATUS_Struct_t    *AllowedStatus);

static  int get_status_array_from_LOV (char  *pszLovName,
                                       STATUS_Struct_t    *AllowedStatus);

static  int check_status_of_change_item_rev (tag_t   tEngChangeRev,
                                             STATUS_Struct_t AllowedStatus);

static  int check_status_of_affected_irs(tag_t   tEngChangeRev,
                                         STATUS_Struct_t AllowedStatus,
										 char *pcStatusAgainstType,
										 TIA_ErrorMessage **currErrMsg);

static int get_allowed_statuses (EPM_rule_message_t msg,
                                 STATUS_Struct_t      *AllowedStatus,
								 char **pcTargetTypeName,
								 char **pcStatusAgainstType); 

static int check_status_of_target_object(tag_t   tTargetObject,STATUS_Struct_t AllowedStatus );
//static int get_target_object(tag_t tTask,char *pcTargetTypeName,tag_t *tTargetObject);
/*==============================================================================
*    Implementation of RULE Handler -  t1aAUTO_check_target_object
===============================================================================*/
EPM_decision_t t1aAUTO_check_target_object(EPM_rule_message_t msg)
{
    int					indx										= 0;
    int					iRetCode									= ITK_ok;

    tag_t				tEngChangeRev								= NULLTAG;
    tag_t				tUser										= NULLTAG;
    tag_t				tTaskType									= NULLTAG;
	
	char				*pcUserName									= NULL;
	char				*pcTaskTypeName								= NULL;
	char				*pcTargetTypeName							= NULL;
	char				*pcStatusAgainstType						= NULL;
    char				acErrorString[TIAUTO_error_message_len+1]	= "";
    EPM_decision_t		decision									= EPM_nogo;
	TIA_ErrorMessage	*currErrMsg									= NULL;
	TIA_ErrorMessage	*tempErrMsg									= NULL;
	
	STATUS_Struct_t		AllowedStatus;
	if(msg.proposed_action == EPM_perform_action)
	{
		decision = EPM_go;
		return decision;
	}
	//get current logged in user    	
	iRetCode = POM_get_user (&pcUserName, &tUser);
	if(iRetCode == ITK_ok && (msg.task != NULLTAG) )
	{
		iRetCode = TCTYPE_ask_object_type(msg.task,&tTaskType);
	}
	if(iRetCode == ITK_ok && tTaskType != NULLTAG)
	{
		iRetCode = AOM_ask_name(tTaskType,&pcTaskTypeName);
	}
    tiauto_initialize_status_progression_stuct(&AllowedStatus);
	pcTargetTypeName = (char*) MEM_alloc(33 * sizeof(char));
	tc_strcpy(pcTargetTypeName,NEWCHANGE_REV);//"EngChange Revision");
	
	pcStatusAgainstType = (char*) MEM_alloc(120 * sizeof(char));
	tc_strcpy(pcStatusAgainstType,"");

    iRetCode = get_allowed_statuses(msg, &AllowedStatus,&pcTargetTypeName,&pcStatusAgainstType);
    if( DEBUG_PRINT )
    {
        for (indx = 0; indx < AllowedStatus.iCount; indx++ )
            printf("\n Allowed Status[%d]: %s\n", indx,AllowedStatus.StatusArray[indx]);
    }
      
    /* NOW we got list of allowed statuses, so validate status of the objects(item revisions)
       to be attached to change process as targets. */
    if (iRetCode == ITK_ok) 
    {
		if((pcTargetTypeName == NULL ) || (tc_strcmp("EngChange Revision",pcTargetTypeName) == 0) )
		{
			iRetCode = tiauto_get_change_item_rev (msg.task, &tEngChangeRev);
			// If there is no change item rev, just ignore further processing & exit.
			if (tEngChangeRev != NULLTAG) 
			{
				if (iRetCode == ITK_ok ) 
					iRetCode = check_status_of_change_item_rev (tEngChangeRev, AllowedStatus); 
				if (iRetCode == ITK_ok) 
					iRetCode = check_status_of_affected_irs (tEngChangeRev, AllowedStatus,pcStatusAgainstType,&currErrMsg);
			}
		}
		else if(pcTargetTypeName != NULL && (tc_strcmp(NEWCHANGE_REV,pcTargetTypeName) == 0))
		{
			iRetCode = tiauto_get_newchange_item_rev (msg.task, &tEngChangeRev);
			// If there is no change item rev, just ignore further processing & exit.
			if (tEngChangeRev != NULLTAG) 
			{
				if (iRetCode == ITK_ok ) 
					iRetCode = check_status_of_change_item_rev (tEngChangeRev, AllowedStatus); 
				if (iRetCode == ITK_ok) 
					iRetCode = check_status_of_affected_irs (tEngChangeRev, AllowedStatus,pcStatusAgainstType,&currErrMsg);
			}
		}
		else if(pcTargetTypeName != NULL)
		{
			iRetCode = get_target_object(msg.task,pcTargetTypeName,&tEngChangeRev);
			if(iRetCode == ITK_ok && tEngChangeRev != NULLTAG)
				iRetCode = check_status_of_target_object(tEngChangeRev,AllowedStatus);
		}
    }
    if(iRetCode != ITK_ok)
        decision = EPM_nogo;
    else
        decision = EPM_go;
	if( currErrMsg != NULL)
	{
		decision = EPM_nogo;	
		if(pcTaskTypeName != NULL && (tc_strcmp(pcTaskTypeName,"EPMPerformSignoffTask") == 0) )
		{
			iRetCode = EPM_set_decision (msg.task,tUser,CR_no_decision,"",false);
		}
		TI_sprintf( acErrorString, "To fix this problem, Please remove the above item revisions from the change folder."  );	
		EMH_store_error_s1(EMH_severity_error, TIAUTO_ITEM_REV_INVALID_STATUS , acErrorString );
		
		while(currErrMsg)
		{	           
			EMH_store_error_s1(EMH_severity_error, currErrMsg->iRetCode, currErrMsg->errMsg);
			TC_write_syslog(currErrMsg->errMsg);
			TC_write_syslog("\n");

			tempErrMsg = currErrMsg;
         	currErrMsg = currErrMsg->next;
			free ( tempErrMsg ); // Free memory 
			tempErrMsg = NULL;
		}
		 
	}
    // free up allocated memory
    SAFE_MEM_free (AllowedStatus.StatusArray);
	SAFE_MEM_free (pcTaskTypeName);
	SAFE_MEM_free (pcUserName);
	//SAFE_MEM_free (currErrMsg);
    return decision;
}
/* This parses the handler arguments, values and calls appropriate function
   to get list of allowed statuses */
static int get_allowed_statuses (EPM_rule_message_t msg,
                                 STATUS_Struct_t      *AllowedStatus,
								 char	**pcTargetTypeName,
								 char **pcStatusAgainstType)   
{
    int     iRetCode = ITK_ok;
	int indx = 0;
    int     iNumArgs = 0;
    char    *pszArg  = NULL;
    char    *pszValue   = NULL;

    iNumArgs = TC_number_of_arguments(msg.arguments);
    if ( ( iNumArgs == 1 ) || ( iNumArgs == 2 ) )
    {
		for(indx = 0; indx < iNumArgs; indx++)
		{
			iRetCode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pszArg, &pszValue );
			if ( iRetCode == ITK_ok ) 
			{
				if (tc_strcasecmp(pszArg, TIAUTO_ALLOWED_STATUS) == 0)
				{
					if ( pszValue != NULL )
						iRetCode = get_status_array_from_VALUES(pszValue, AllowedStatus );
				}
				else if (tc_strcasecmp(pszArg, TIAUTO_LOV) == 0)
				{
					if ( pszValue != NULL )
						iRetCode = get_status_array_from_LOV(pszValue, AllowedStatus );
				}
				else if (tc_strcasecmp(pszArg, "type") == 0)
				{
					tc_strcpy( *pcTargetTypeName, pszValue);
				}
				else if (tc_strcasecmp(pszArg, "status_against_type") == 0)
				{
					tc_strcpy( *pcStatusAgainstType, pszValue);
				}
				else
					iRetCode = EPM_invalid_argument;
			}
		}
    }
    else if ( iNumArgs < 1 )
        iRetCode = EPM_missing_req_arg;
    else 
       iRetCode = EPM_wrong_number_of_arguments;
    
    SAFE_MEM_free (pszArg);
    SAFE_MEM_free (pszValue);

    return iRetCode;
}
/* Validating the status of item revisions in the affected and solution items folder */
static  int check_status_of_affected_irs(tag_t   tEngChangeRev,
                                         STATUS_Struct_t AllowedStatus,
										 char *pcStatusAgainstType,
										 TIA_ErrorMessage **currErrMsg )
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumAffected = 0;
    tag_t   *ptAffectedItems = NULL;
    char    *pszClassName = NULL;
    char    *pszAffectedItemRevObjectID = NULL;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]=""; 
	char    acObjectType[WSO_name_size_c+1]  = "";
	logical lIsDoc = false;
	char    *pszTempStr = NULL;
	char    *buffer = NULL;
	char	*pcItemType= NULL;
	char	*pcStatusType = NULL;

	if(pcStatusAgainstType != NULL && tc_strlen(pcStatusAgainstType) > 1)
	{
		pszTempStr = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pcStatusAgainstType)+1));
		tc_strcpy(pszTempStr, pcStatusAgainstType);
		if ( pszTempStr != NULL )
		{
			buffer = NULL;
			buffer = tc_strtok( pszTempStr , ":");
			if ( buffer !=NULL)
			{
				pcItemType = (char*) MEM_alloc(( sizeof (char)*WSO_name_size_c) + 1);
				tc_strcpy(pcItemType,buffer);
				
				buffer = tc_strtok( NULL , "," );
				if ( buffer !=NULL)
				{
					pcStatusType = (char*) MEM_alloc(( sizeof (char)*WSO_name_size_c) + 1);
					tc_strcpy(pcStatusType,buffer);
				}
			}
		}
	}
    iRetCode = ECM_get_affected_items (tEngChangeRev, &iNumAffected, &ptAffectedItems); 
    for (indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++)
    {
		char	*pcTargetClass					= NULL;	

		tc_strcpy(acObjectType,"");
		iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
        //getting parent class if the class name is NOT ITEMREVISION or FORM
		if(tc_strcasecmp (pszClassName , TIAUTO_ITEMREVISION)!= 0 && (iRetCode == ITK_ok) )
		{	
			tag_t		tTargetType						= NULLTAG;
			tag_t		tParentType						= NULLTAG;
			
			iRetCode = TCTYPE_ask_object_type(ptAffectedItems[indx],&tTargetType);			
			if(iRetCode == ITK_ok && tTargetType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_parent_type(tTargetType,&tParentType));
			}
			if(tParentType != NULLTAG)
			{
				TIAUTO_ITKCALL(iRetCode,TCTYPE_ask_class_name2(tParentType,&pcTargetClass));
			}
		}
		// check if the classname of the targeted object pseudo folder is ItemRevision or Document Revision
        if(((tc_strcasecmp (pszClassName ,TIAUTO_ITEMREVISION)== 0) || (tc_strcasecmp (pcTargetClass ,TIAUTO_TI_DOCUMENTREVISION)== 0))  && (iRetCode == ITK_ok) )        
        {
            iRetCode = tiauto_get_release_status (ptAffectedItems[indx], szReleaseStatus);
            if (iRetCode == ITK_ok)
            {
				lIsDoc = false;
				iRetCode = tiauto_check_if_itemType_isDOC(ptAffectedItems[indx],&lIsDoc);
				if( (lIsDoc == true) && (tc_strcmp (szReleaseStatus,"") == 0 ))
				{
				}
                else if(tc_strcmp (szReleaseStatus,"") == 0 )
                {
                     /* "NONE" string used for comparing WIP status/No STATUS items.*/
                    tc_strcpy (szReleaseStatus, "NONE" );
                }
                if ( tiauto_status_progression_index(szReleaseStatus, AllowedStatus) < 0 )
                {					
                    iRetCode = WSOM_ask_object_id_string(ptAffectedItems[indx], &pszAffectedItemRevObjectID);
                    if( (lIsDoc == true) && (tc_strcmp (szReleaseStatus,"") == 0 ))
					{
						TI_sprintf(szErrorString, "Error: Document Revision - '%s' is at WIP status, which is invalid for this change process.",
                                pszAffectedItemRevObjectID); 
						tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
					}
					else if(tc_strcasecmp (szReleaseStatus,"NONE") == 0 )
                    {
                        TI_sprintf(szErrorString, "Error: Item Revision - '%s' does not have valid release status for this change process.",
                                pszAffectedItemRevObjectID); 
						tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
                    }
                    else
                    { 
						iRetCode = WSOM_ask_object_type(ptAffectedItems[indx],acObjectType);
						if(pcStatusAgainstType != NULL && tc_strlen(pcStatusAgainstType) > 1 && tc_strcmp(pcItemType,acObjectType) == 0)
						{
							if(tc_strcmp(pcStatusType,szReleaseStatus) != 0)
							{
								TI_sprintf(szErrorString, "Error: Item Revision - '%s' is at \"%s\" status, which is invalid for this change process.",
									pszAffectedItemRevObjectID, szReleaseStatus);
								tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
							}
						}
						else
						{
							TI_sprintf(szErrorString, "Error: Item Revision - '%s' is at \"%s\" status, which is invalid for this change process.",
									pszAffectedItemRevObjectID, szReleaseStatus);
							tiauto_writeErrorMsgToStack(currErrMsg, TIAUTO_ITEM_REV_INVALID_STATUS , szErrorString);
						}
                    }
                    
                    SAFE_MEM_free ( pszAffectedItemRevObjectID );
                   
                }
            }
        } 
		SAFE_MEM_free(pcTargetClass);
    }
	
    SAFE_MEM_free ( pszClassName );
    SAFE_MEM_free ( ptAffectedItems );
    return iRetCode;
}

/* Validating the status of current change item revision */
static  int check_status_of_change_item_rev (tag_t   tEngChangeRev,
                                             STATUS_Struct_t AllowedStatus )
{
    int     iRetCode = ITK_ok;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]=""; 
    char    *pszChangeItemObjectID = NULL;

    if (iRetCode == ITK_ok) 
        iRetCode = tiauto_get_release_status (tEngChangeRev, szReleaseStatus);

    if (iRetCode == ITK_ok)
    {
        if(tc_strcmp (szReleaseStatus,"") == 0 )
        {
            /* "NONE" string used for comparing WIP status/No STATUS items.*/
            tc_strcpy (szReleaseStatus, "NONE" );
        }
        if ( tiauto_status_progression_index (szReleaseStatus, AllowedStatus) < 0 )
        {
            iRetCode = WSOM_ask_object_id_string (tEngChangeRev, &pszChangeItemObjectID);
            if(tc_strcasecmp (szReleaseStatus,"NONE") == 0 )
            {
                TI_sprintf (szErrorString, "Error: Change Object Rev - '%s' does not have valid release status for this change process.",
                         pszChangeItemObjectID); 
            }
            else
            {                 
                TI_sprintf (szErrorString, "Error: Change Object Rev - '%s' is at \"%s\" status, which is invalid for this change process.",
                         pszChangeItemObjectID, szReleaseStatus);
            } 
            TC_write_syslog (szErrorString);
            EMH_store_error_s1 (EMH_severity_error, TIAUTO_CHANGE_ITEM_REV_INVALID_STATUS, szErrorString);
            iRetCode = TIAUTO_CHANGE_ITEM_REV_INVALID_STATUS;
            SAFE_MEM_free (pszChangeItemObjectID );
        }
    }
    return iRetCode;
}
/* This function gets the allowed status list from given LOV */
static  int get_status_array_from_LOV(char  *pszLovName,
                                      STATUS_Struct_t    *AllowedStatus)
{
    int     indx = 0;
    int     iRetCode = ITK_ok;
    int     iNumLOVs = 0;
    int     iNumValues = 0;
    tag_t   *ptLOVs = NULL;
    PROP_value_type_t   value_type = PROP_untyped;
    char    **pszStatuses = NULL;
    char    szErrorString[TIAUTO_error_message_len+1]=""; 

    iRetCode = LOV_find (pszLovName, &iNumLOVs, &ptLOVs);
     
    if (iRetCode == ITK_ok && iNumLOVs > 0)
    {
        for (indx = 0; indx < iNumLOVs; indx++)
        {
            iRetCode = LOV_ask_value_type (ptLOVs[indx], &value_type); 
            if (iRetCode == ITK_ok && value_type == PROP_string)
            {
                iRetCode = LOV_ask_values_string (ptLOVs[indx], &iNumValues, &pszStatuses);
                AllowedStatus->iCount = iNumValues;
                AllowedStatus->StatusArray = pszStatuses;
                break;  //There should be only one LOV of given type
            }
        }
    }
    else
    {
		TI_sprintf (szErrorString, "Error: LOV - %s was not found in the database.", pszLovName);
        TC_write_syslog (szErrorString);
        EMH_store_error_s1(EMH_severity_error, TIAUTO_SPECIFIED_LOV_NOT_FOUND, szErrorString);
        iRetCode = TIAUTO_SPECIFIED_LOV_NOT_FOUND;
    }
    
    SAFE_MEM_free (ptLOVs);
    return iRetCode;
}
/* This function gets the allowed status list from given argument values */
static  int get_status_array_from_VALUES (char  *pszValue,
                                          STATUS_Struct_t    *AllowedStatus)
{
    int     iRetCode = ITK_ok;
    int     iNumStatus = 0;
    char    *pszLocalStr = NULL;
    char    *buffer = NULL;
    char    **pszStatuses = NULL;

    pszLocalStr = (char *) MEM_alloc(sizeof (char)* ((int)tc_strlen(pszValue)+1));
    tc_strcpy(pszLocalStr, pszValue);
    if ( pszLocalStr != NULL )
    {
        buffer = NULL;
        buffer = tc_strtok( pszLocalStr , ",");
        while ( buffer !=NULL)
        {
            if (pszStatuses == NULL)
            {
                pszStatuses = (char**) MEM_alloc ( sizeof (char *) );
            }
            else
            {
                pszStatuses = (char**) MEM_realloc ( pszStatuses, (iNumStatus+1) * sizeof(char*));
            }
            pszStatuses[iNumStatus] = (char*) MEM_alloc(( sizeof (char)*WSO_name_size_c) + 1);
            tc_strcpy(pszStatuses[iNumStatus],buffer);
            iNumStatus++;
            buffer = tc_strtok( NULL , "," );
        }
        AllowedStatus->iCount = iNumStatus;
        AllowedStatus->StatusArray = pszStatuses;
    }

    if ( pszLocalStr) MEM_free (pszLocalStr);
    return  iRetCode;
}

//validates the status of the given input target object
int check_status_of_target_object(tag_t   tTargetObject,STATUS_Struct_t AllowedStatus )
{
	int     iRetCode = ITK_ok;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]=""; 
    char    *pszChangeItemObjectID = NULL;

    if (iRetCode == ITK_ok) 
        iRetCode = tiauto_get_release_status (tTargetObject, szReleaseStatus);

    if (iRetCode == ITK_ok)
    {
        if(tc_strcmp (szReleaseStatus,"") == 0 )
        {
            /* "NONE" string used for comparing WIP status/No STATUS items.*/
            tc_strcpy (szReleaseStatus, "NONE" );
        }
        if ( tiauto_status_progression_index (szReleaseStatus, AllowedStatus) < 0 )
        {
            iRetCode = WSOM_ask_object_id_string (tTargetObject, &pszChangeItemObjectID);
            if(tc_strcasecmp (szReleaseStatus,"NONE") == 0 )
            {
                TI_sprintf (szErrorString, "Error: The targeted item revision \"%s\" does not have valid release status for this process.",
                         pszChangeItemObjectID); 
            }
            else
            {                 
                TI_sprintf (szErrorString, "Error: The targeted item revision \"%s\" is at \"%s\" status, which is invalid for this process.",
                         pszChangeItemObjectID, szReleaseStatus);
            } 
            TC_write_syslog (szErrorString);
            EMH_store_error_s1 (EMH_severity_error, TIAUTO_CHANGE_ITEM_REV_INVALID_STATUS, szErrorString);
            iRetCode = TIAUTO_CHANGE_ITEM_REV_INVALID_STATUS;
            SAFE_MEM_free (pszChangeItemObjectID );
        }
    }
    return iRetCode;
}