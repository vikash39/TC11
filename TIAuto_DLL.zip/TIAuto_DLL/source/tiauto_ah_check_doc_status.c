/*******************************************************************************
File         : tiauto_ah_check_doc_status.c

Description  : This handler is configured for checking the document revision status.
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
*******************************************************************************
20 Mar 2010     1.0        Dipak Naik		Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200


extern int TIAUTO_AH_check_doc_status(EPM_action_message_t msg)
{
   int iRetcode = ITK_ok;
	
	return iRetcode;  
}