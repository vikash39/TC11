/*******************************************************************************
File         : tiauto_send_email_toall.c

Description  : This action handler sends mails to all stakeholders of the workflow.
			   The subject and the content of the email will be taken from the 
			   handler argument values
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who                  Description
March 1, 2010    1.0        Nivedita Kamath      Initial Creation
March 9, 2010	 1.1		Dipak Naik			 Modified the content of the mail body.
Dec 19, 2011	 1.2		Dipak Naik			 Modified the code to send the mail to the workflow initiator
Jun 21,2019      1.3        Trisha Saha     Updated attachments with signoff_attachments for Mail to users
*****************************************************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


#define INIT_LIST_SIZE         200

extern void tiauto_Store_TaskNames_Details_per_User(TIA_TaskNamesAssignedPerSupplier **currErrMsg, tag_t tUser, char *sError);

void FreeMemoryForLinkdListSupplier(TIA_TaskNamesAssignedPerSupplier *TaskNamesPerUserList);

extern int t1aAUTO_send_email(EPM_action_message_t msg)
{
	int				iRetcode			= ITK_ok;
	int             iNumArgs		= 0; 
    int				i = 0;
	int				inx					= 0;
	int				iCount				= 0;
	int				iSubTaskCnt			= 0;
	int				isubTaskIndx		= 0;
	int				iNumAttachs			= 0;
	int				iAttchIndx			= 0;
	int             iFileOpenErrCode    = 0;

	tag_t			tRootTaskTag		= NULLTAG;
	tag_t			tReposibleParty		= NULLTAG;
	tag_t			tTaskType			= NULLTAG;
	tag_t			tInitiatorTag		= NULLTAG;
	tag_t			tJobTag				= NULLTAG;
	tag_t			tGroupMember		= NULLTAG;
	tag_t			*ptAttachsTagList	= NULL;//to be freed
	tag_t			*ptTasks			= NULL;//to be freed
	tag_t			*ptReviewSubTasks	= NULL;//to be freed

	char			*pcUserMailId					= NULL;//to be freed
	char			*pcTaskName						= NULL;//to be freed
	char			*pcTaskTypeName					= NULL;//to be freed
	char			*pcSubTaskType					= NULL;//to be freed
	char			acSubject[1024]					= {'\0'};
	char			caTaskName[WSO_name_size_c+1]	= {'\0'};
	char			acObjectName[WSO_name_size_c+1] = {'\0'};
	char			acObjectType[WSO_name_size_c+1] = {'\0'};
	char			*pcMailSubject					= NULL;
	char			*pcBodyMsg						= NULL;
	char		    *pcValue						= NULL;
    char		    *pcFlag							= NULL;
	char			*pcErrMsg						= NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";

	//txt_t		the_text_server								= NULL;
    //char		*pcMsgName									= NULL;
    char		*pcComments									= NULL;	
	char		*pcEmailId									= NULL;
	char		*pcMailBodyFileName							= NULL;
	FILE		*fMailBodyFile								= NULL;
	
	logical lInitiator = false;

	EPM_state_t State ;

	TIA_TaskNamesAssignedPerSupplier *TaskNamesPerUserList = NULL;//to store all the task names per user
	
	TIA_TaskNamesAssignedPerSupplier *NotifyUserList = NULL;

	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs == 2)
	{
		for(i = 0; i < iNumArgs; i++)
		{
			
			iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetcode == ITK_ok )
			{
				if (tc_strcasecmp(pcFlag, "subject") == 0 && pcValue != NULL)
				{
					pcMailSubject = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcMailSubject, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, "comment") == 0 && pcValue != NULL)
				{
					pcBodyMsg = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcBodyMsg, pcValue);
				}
				else
					iRetcode = EPM_invalid_argument;
			
				if( iRetcode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"TIAUTO-AH-send-email-to-all\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;
					
				}
			}
		}
		SAFE_MEM_free(pcFlag);
		SAFE_MEM_free(pcValue);
	}
	else
	{
		iRetcode = EPM_invalid_argument;
	}

    if(iRetcode == ITK_ok)
	{
		//Get the root task
		iRetcode =  EPM_ask_root_task( msg.task, &tRootTaskTag);
		//Get the user who has initiated the task
		if(iRetcode == ITK_ok)
		{
			iRetcode = AOM_ask_owner(tRootTaskTag,&tInitiatorTag);
		}
		if(iRetcode == ITK_ok)
		{
			iRetcode = EPM_get_user_email_addr(tInitiatorTag,&pcUserMailId);
		}
		
		//Get the job tag
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_job(tRootTaskTag,&tJobTag);
		}
		//Get the subtasks and iterate through them.
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			iRetcode = EPM_ask_sub_tasks(tRootTaskTag,&iCount,&ptTasks);
			if(iRetcode == ITK_ok && iCount > 0)
			{
				for(inx= 0;inx<iCount;inx++)
				{
					iRetcode = AOM_ask_name(ptTasks[inx],&pcTaskName);
					if(iRetcode == ITK_ok)
					{
						iRetcode = EPM_ask_state(ptTasks[inx],&State);
					}
					if(iRetcode == ITK_ok)
					{					
						if(iRetcode == ITK_ok && pcTaskName!= NULL)
						{
							iRetcode = TCTYPE_ask_object_type(ptTasks[inx],&tTaskType);
						}
						if(iRetcode == ITK_ok && tTaskType != NULLTAG)
						{
							iRetcode = AOM_ask_name(tTaskType,&pcTaskTypeName);
						}
						if(iRetcode == ITK_ok && pcTaskTypeName != NULL)
						{
							//check if the task type is a ECO/Do Task/CheckList
							if( (tc_strcmp(pcTaskTypeName,"ECMPrepareECOTask")==0 ) ||
								(tc_strcmp(pcTaskTypeName,"EPMDoTask")== 0 ) ||
								(tc_strcmp(pcTaskTypeName,"ECMChecklistTask")== 0) )
							{
								//get the responsible party of the task
								iRetcode = EPM_ask_responsible_party(ptTasks[inx],&tReposibleParty);
								if(iRetcode == ITK_ok && tReposibleParty != NULLTAG)
								{
									if(pcMailSubject != NULL && pcBodyMsg != NULL)
									{
										tiauto_Store_TaskNames_Details_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
									}
								}
							}			
							else if( (tc_strcmp(pcTaskTypeName,"EPMReviewTask")==0) ||
									(tc_strcmp(pcTaskTypeName,"EPMAcknowledgeTask")==0) )
							{
								//for review and acknowledge task					
								iRetcode = EPM_ask_sub_tasks( ptTasks[inx], &iSubTaskCnt, &ptReviewSubTasks );
								if( iRetcode == ITK_ok && ptReviewSubTasks != NULL )
								{
									for(isubTaskIndx=0; isubTaskIndx < iSubTaskCnt && iRetcode == ITK_ok; isubTaskIndx++  )
									{
										
										iRetcode = AOM_ask_value_string( ptReviewSubTasks[isubTaskIndx], "task_type", &pcSubTaskType);
										if( iRetcode == ITK_ok && pcSubTaskType != NULL && 
											(tc_strcmp(pcSubTaskType, "EPMSelectSignoffTask") == 0) )
										{
											// get the signoff object
											if( iRetcode == ITK_ok && ptReviewSubTasks[isubTaskIndx] != NULLTAG)
												// 15.02 Mail Notification
												//iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "attachments", &iNumAttachs, &ptAttachsTagList);
											    iRetcode = AOM_ask_value_tags(ptReviewSubTasks[isubTaskIndx], "signoff_attachments", &iNumAttachs, &ptAttachsTagList);
											// get the user tag from the signoff object
											for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetcode == ITK_ok; iAttchIndx++)
											{
												if( iRetcode == ITK_ok && ptAttachsTagList != NULL)
												{
													iRetcode = AOM_ask_value_tag( ptAttachsTagList[iAttchIndx], "group_member", &tGroupMember );
													if( iRetcode == ITK_ok && tGroupMember != NULLTAG)
													{
														tReposibleParty = NULLTAG;
														iRetcode = AOM_ask_value_tag(tGroupMember, "user", &tReposibleParty);
													}
													if( iRetcode == ITK_ok && tReposibleParty != NULLTAG )
													{
														if(pcMailSubject != NULL && pcBodyMsg != NULL)
														{
															tiauto_Store_TaskNames_Details_per_User(&NotifyUserList,tReposibleParty,pcTaskName);
														}
													}												
												}
											}
											SAFE_MEM_free(ptAttachsTagList);
										}
										SAFE_MEM_free(pcSubTaskType);
									}
								}
								SAFE_MEM_free(ptReviewSubTasks);
							}
						}
						SAFE_MEM_free(pcTaskTypeName);
					}
					SAFE_MEM_free(pcTaskName);
				}//for loop ends here.
			}
		}
		
		if(iRetcode == ITK_ok && pcMailSubject != NULL && pcBodyMsg != NULL)
		{			
			iRetcode = EPM_ask_name  ( msg.task , caTaskName);
			iRetcode = AOM_ask_name(tJobTag,&pcTaskName);
			TI_sprintf(acSubject,"%s : %s(%s)",pcMailSubject,pcTaskName,caTaskName);
			//Initialize TextServer here 
			//the_text_server = txt_ctor( "iman_text.xml" );
			//pcMsgName = "User_Comments";
			//pcComments = txt_noSubText(the_text_server, pcMsgName, (int)true);
			//txt_destructor(the_text_server);
			pcMailBodyFileName = USER_new_file_name("cr_notify_dset","TEXT","dat",1);
			iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );
			fprintf(fMailBodyFile,"Process Name         : %s\n",pcTaskName);
			fprintf(fMailBodyFile,"Current Task Name    : %s\n",caTaskName);
			fprintf(fMailBodyFile,"\nComments : %s\n", pcBodyMsg);
			fprintf(fMailBodyFile,"\n Attachment:       Name                             Type\n");
			fprintf(fMailBodyFile,"---------------    -------------------------------- -------------------------------- \n");
			fprintf(fMailBodyFile,"    Target : \n");
			//get the target attachments
			iRetcode = EPM_ask_attachments(tRootTaskTag ,EPM_target_attachment,&iNumAttachs, &ptAttachsTagList); 
			for(iAttchIndx=0; iAttchIndx < iNumAttachs && iRetcode == ITK_ok; iAttchIndx++)
			{
				iRetcode = WSOM_ask_name (ptAttachsTagList[iAttchIndx],acObjectName);
				if(iRetcode == ITK_ok)
					iRetcode = WSOM_ask_object_type (ptAttachsTagList[iAttchIndx],acObjectType);
				if(iRetcode == ITK_ok)
					fprintf(fMailBodyFile,"                    %s                                %s\n",acObjectName,acObjectType);
			}			
			fprintf(fMailBodyFile,"------------------------------------------------------------------------------------ \n");
			if(fMailBodyFile != NULL)
			{
				fclose(fMailBodyFile);
			}
			while(NotifyUserList != NULL && iRetcode == ITK_ok)
			{			
				iRetcode = EPM_get_user_email_addr(NotifyUserList->tUniqueUser,&pcEmailId );
				if(NotifyUserList->tUniqueUser == tInitiatorTag)
				{
					lInitiator = true;
				}
				if(iRetcode == ITK_ok &&  pcEmailId != NULL)
				{					
					if(pcEmailId != NULL)
						iRetcode = tiauto_sendEMail(acSubject, pcEmailId, pcMailBodyFileName);
				}
				NotifyUserList = NotifyUserList->next;
				SAFE_MEM_free(pcEmailId);
			} 
		
			if(lInitiator == false)
			{
				if(pcUserMailId != NULL)
					iRetcode = tiauto_sendEMail(acSubject, pcUserMailId, pcMailBodyFileName);
			}
			SAFE_MEM_free(pcComments);				
			// delete temporary file here
			remove(pcMailBodyFileName );				
			SAFE_MEM_free(ptAttachsTagList);
		}

		//free the memory for linked lists		
		FreeMemoryForLinkdListSupplier(TaskNamesPerUserList);
		FreeMemoryForLinkdListSupplier(NotifyUserList);
		SAFE_MEM_free(pcTaskName);
		SAFE_MEM_free(pcTaskTypeName);
		SAFE_MEM_free(ptTasks);
		SAFE_MEM_free(pcTaskTypeName);
	}
	if ( iRetcode != ITK_ok )
	{		
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		TC_write_syslog(pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);		
	}
	SAFE_MEM_free(pcMailSubject);
	SAFE_MEM_free(pcBodyMsg);
	SAFE_MEM_free(pcMailSubject);

	return iRetcode;  
}

/*=====================================================================================
*  FreeMemoryForLinkdList()
*\param				TIA_TaskNamesAssignedPerSupplier *TaskNamesPerUserList				
*\return void				
* Description:
*			To free the structure.
=====================================================================================*/
void FreeMemoryForLinkdListSupplier(TIA_TaskNamesAssignedPerSupplier *TaskNamesPerUserList)
{
	TIA_TaskNamesAssignedPerSupplier *tempFree1 = NULL;
	while(TaskNamesPerUserList != NULL)
	{
		tempFree1 = TaskNamesPerUserList->next;
		free (TaskNamesPerUserList);
		TaskNamesPerUserList = tempFree1;
		tempFree1 = NULL;
	}
	return;
}
/*=====================================================================================
*   tiauto_Store_TaskNames_per_User_supplier_info()
*\param				TIA_TaskNamesAssignedPerSupplier	**TaskNamesPerUserList, <I>
*					tag_t							tUser,					<I>
*					char							*pcTaskName				<I>
*\return void				
* Description:
*			To store all the tasks per user(unique).
=====================================================================================*/
void tiauto_Store_TaskNames_Details_per_User(TIA_TaskNamesAssignedPerSupplier **TaskNamesPerUserList, tag_t tUser, char *pcTaskName)
{	
	TIA_TaskNamesAssignedPerSupplier *temp;
    logical isPresent = false;
	temp = *TaskNamesPerUserList;

	if( (*TaskNamesPerUserList == NULL) || (temp == NULL) )
	{
		*TaskNamesPerUserList=malloc(sizeof(TIA_TaskNamesAssignedPerSupplier));
		temp = *TaskNamesPerUserList;
		TI_sprintf(temp->allTasks, "");
	}
	else
	{	
		for(;;)
		{
			if( temp->tUniqueUser == tUser )
			{
				isPresent = true;
				TI_sprintf(temp->allTasks,"%s\n%s",temp->allTasks,pcTaskName);
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else 
				break;
		}
		if ( isPresent == false )
		{
			temp->next = malloc(sizeof(TIA_TaskNamesAssignedPerSupplier));
			temp=temp->next;
			TI_sprintf(temp->allTasks, "");
		}
	}
	if ( isPresent == false )
	{
		temp->tUniqueUser = tUser;
		TI_sprintf(temp->allTasks,"%s",pcTaskName);
		temp->next  = NULL;
	}	
	
	//free ( temp );
	temp = NULL;
}
