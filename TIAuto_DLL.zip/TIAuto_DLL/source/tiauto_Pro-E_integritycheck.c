/*******************************************************************************
File         : tiauto_Pro-E_integritycheck.c

Description  : This rule handler validates the release status of  generic item of the ProPart and ProAsm datasets
               in the affected items folder and also verifies the release status of all the instances of the dataset.               

Input        : None

Output       : None

Author       : Arun Kumar,TCS

Revision History :
Date            Revision      Who				Description
Jan	  10, 2007    1.0         Arun Kumar	    Initial Creation
Dec   15, 2008	  2.0		  Dipak Naik		Fixed errors
March 10, 2009    3.0         Dipak Naik		Modified the code to display the Alt Id of the 
												generic item revision and search the Alt id.
March 17, 2009    3.1         Garima Dewangan	Modified the code to for memory handling while 
												getting generic item revision and search the Alt id.
Oct	 12, 2009	  3.2		  Dipak Naik		Modified the code to check whether the status of the 
												generic is same or higher than the "Study Approved" status.
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
//#include <list>
#include <ae/ae.h>
#include<tccore/idcxt.h>


EPM_decision_t t1aAUTO_ProE_integritycheck(EPM_rule_message_t message)
{
    int						iRetCode								= ITK_ok;
    int						iNumAffected							= 0;
	int						num_attachments							= 0;
	int						indx									= 0;
	int						j										= 0;
	int						inx										= 0;
	int						secObjCount								= 0;
	int						is_released								= FALSE;

	tag_t					tRootTask								= NULLTAG;
	tag_t					genItem									= NULLTAG;
	tag_t					relationType							= NULLTAG;
	tag_t					affectedItem							= NULLTAG;
	tag_t					datasettype								= NULLTAG;
	tag_t					dataset									= NULLTAG;	
	tag_t					tClassDSTag								= NULLTAG;
	tag_t					*ptAffectedItems						= NULL;
	tag_t					*attachment_tags						= NULL;
    tag_t					*secondary_object_tags					= NULL;

	
	char					*sClassDSName									= NULL;
	char					*pszClassName									= NULL;
	char					*propName										= "IPEM_master_dependency";	
	char                    *pcRelSts                                       = NULL;
	char					szErrorString[TIAUTO_error_message_len+1]		= "";
	char					revId[ITEM_id_size_c+1]							= "";
	char					itemid[ITEM_id_size_c+1]						= "";
	char					itemRevId[ITEM_id_size_c + ITEM_id_size_c + 1]	= "";
	char					type_name[TCTYPE_name_size_c+1]				= "";
	char					datasetTypeName[AE_datasettype_name_size_c+1]	= "";

	EPM_decision_t decision								= EPM_go;
	
	GRM_relation_t *secondaryList						= 0;
	
	TIA_ErrorMessage *currErrMsg						= NULL;	
	//variables to check status progression
	STATUS_Struct_t			StatusProgression;
    TARGET_RELEASE_Struct_t StudyAppStatus;
	tiauto_initialize_status_progression_stuct(&StatusProgression); 
	iRetCode = tiauto_get_status_progression_array (&StatusProgression);
	StudyAppStatus.iLevel = tiauto_status_progression_index ("Study Approved", StatusProgression);
	

	iRetCode = GRM_find_relation_type  (  "IMAN_specification", &relationType );
	if (iRetCode == ITK_ok)
		iRetCode = EPM_ask_root_task(message.task , &tRootTask);
	else
	{
		TI_sprintf( szErrorString, "Failed while finding relation.\n");
		EMH_store_error_s1(EMH_severity_error,iRetCode, szErrorString);
		decision = EPM_nogo;
		return decision;
	}
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_attachments(tRootTask,EPM_target_attachment,
                                      &num_attachments,&attachment_tags);
    if (iRetCode == ITK_ok && attachment_tags[0] != NULLTAG )
            iRetCode = tiauto_get_object_name (attachment_tags[0], type_name);
	if(iRetCode != ITK_ok)
	{
		TI_sprintf( szErrorString, "Failed while getting the attachment items.\n");
		EMH_store_error_s1(EMH_severity_error,iRetCode, szErrorString);
		decision = EPM_nogo;
		SAFE_MEM_free( attachment_tags );
		return decision;
	}
	if(tc_strcasecmp (type_name , CHANGE_REV)== 0 )
	{
        iRetCode = ECM_get_affected_items(attachment_tags[0], &iNumAffected, &ptAffectedItems);
		if(iRetCode != ITK_ok)
		{
			TI_sprintf( szErrorString, "Failed while finding affected items.\n");			
			EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
			decision = EPM_nogo;
		}
        for (indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++)
        {
			iRetCode = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
			if(iRetCode != ITK_ok)
			{
				TI_sprintf( szErrorString, "Failed while getting affected items information.\n");
				EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
				decision = EPM_nogo;
			}
			else if(tc_strcasecmp (pszClassName , "ItemRevision")== 0 )
			{
				dataset = NULLTAG;
				iRetCode =  GRM_list_secondary_objects  (  ptAffectedItems[indx] , relationType,
															&secObjCount, &secondaryList );		        
				
				ITEM_ask_rev_id(ptAffectedItems[indx], revId);
				ITEM_ask_item_of_rev(ptAffectedItems[indx], &affectedItem);
	            ITEM_ask_id(affectedItem, itemid);
				if( (itemid == NULL) || (revId == NULL) )
                    tc_strcpy(itemRevId, "");
				else				
					TI_sprintf(itemRevId, "%s/%s",itemid,revId);
				
				if( iRetCode != ITK_ok )
				{
					TI_sprintf( szErrorString, "Failed while finding the secondary objects for the %s item revision.\n", itemRevId);
					EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
					decision = EPM_nogo;
				}
				for(j =0 ;(j < secObjCount) && ( iRetCode == ITK_ok ) ;j++)
				{
					iRetCode = POM_class_of_instance(secondaryList[j].secondary,&tClassDSTag );
					if(iRetCode == ITK_ok)
						iRetCode = POM_name_of_class( tClassDSTag , &sClassDSName );
					if( iRetCode != ITK_ok )
					{
						TI_sprintf( szErrorString, "Failed while finding the objects type for  %s .\n", itemRevId);
						EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
						decision = EPM_nogo;
					}
					if( (iRetCode==ITK_ok) && (tc_strcasecmp( sClassDSName , "Dataset") == 0) )
					{
						iRetCode =  AE_ask_dataset_datasettype( secondaryList[j].secondary, &datasettype );
						if( iRetCode != ITK_ok )
						{
							TI_sprintf( szErrorString, "Failed while finding the dataset type for  %s .\n", itemRevId);
							EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
							decision = EPM_nogo;
						}
						iRetCode =  AE_ask_datasettype_name( datasettype , datasetTypeName );
						if( iRetCode != ITK_ok )
						{
							TI_sprintf( szErrorString, "Failed while finding the dataset type name for  %s .\n", itemRevId);
							EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
							decision = EPM_nogo;
						}
						else if( (datasetTypeName != NULL) && ( (tc_strcmp("ProPrt" , datasetTypeName)==0) || (tc_strcmp("ProAsm" , datasetTypeName) ==0)) )
						{
							dataset = secondaryList[j].secondary;
							break;
						}
					}
				}
				if( ( dataset != NULLTAG ) && ( iRetCode == ITK_ok ) )
				{
					char		*value								= NULL ;
					char		**pcItemId							= NULL;					
					char		**pcRevId							= NULL;
					char		cActItemRev[ITEM_id_size_c + 1]	    = "";


					int			numIds								= 0;
					int			numRevs								= 0;
					int			iAttrNumArg							= 0;
					int         iRelCount                           = 0;
					int         iGenItemCount                       = 0;
					
					tag_t		*tvalues							= NULL;
					tag_t       *ptRelStsTags                       = NULL;
					
					//to get the display name
					iRetCode = AOM_UIF_ask_value(  dataset, propName, &value );
					value = tc_strtok ( value , "-");

					if( (iRetCode == ITK_ok) && (value != NULL) && ((int)tc_strlen(value) > 0) )
					{
						//to get the actual value tag of the display ID 					  
						iRetCode = AOM_ask_value_tags(dataset,propName,&iAttrNumArg,&tvalues);
						
						//to get the Item ID
						if( (iRetCode == ITK_ok) && (tvalues != NULL) && (tvalues[0] != NULLTAG) )
						{
							iRetCode = AOM_ask_value_strings(tvalues[0],"item_id",&numIds,&pcItemId);
						//to get the Revision ID
						if(iRetCode == ITK_ok ) 
							iRetCode = AOM_ask_value_strings(tvalues[0],"item_revision_id",&numRevs,&pcRevId);
						}

						if( iRetCode != ITK_ok )
						{
							TI_sprintf( szErrorString, "Failed to find if the %s item revision is generic.\n", value);
							EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
							decision = EPM_nogo;
						}
						else if( ( value !=NULL ) && (iRetCode == ITK_ok )  )
						{
							if( ( pcItemId != NULL )  && ( pcItemId[0] != NULL ) &&
								( pcRevId != NULL )  && ( pcRevId[0] != NULL ) )
							{
								TI_sprintf(cActItemRev,"%s/%s",pcItemId[0],pcRevId[0]);
								//to get the tag of the item revision
								iRetCode = ITEM_find_rev(pcItemId[0],pcRevId[0],&genItem);
							}
							if( ( iRetCode==ITK_ok ) && (genItem != NULLTAG) )
							{
								//to check whether the item revision is released or not
								iRetCode = CR_ask_if_released(  genItem , &is_released );
								//to check if the release status is greater than or equal to study approved.
								iRetCode = WSOM_ask_release_status_list(genItem,&iRelCount,&ptRelStsTags);
								if(iRetCode == ITK_ok && iRelCount > 0 )
								{
									iRetCode = AOM_ask_name(ptRelStsTags[0],&pcRelSts);
								}
								
								if( iRetCode==ITK_ok  )
								{
									if(is_released==FALSE)
									{
										for(inx = 0; (inx < iNumAffected) && ( is_released == FALSE ); inx++)
										{
											if( ptAffectedItems[inx] == genItem )
												is_released = TRUE;
										}
									}
									if(is_released==FALSE)
									{
										if( tc_strcmp(value,cActItemRev)!=0 )
										{
											TI_sprintf( szErrorString, "Generic item revision %s[%s] of Instance ID %s is not released or included in the change folder.", value,cActItemRev, itemRevId);
											tiauto_writeErrorMsgToStack(&currErrMsg, TIAUTO_STATUS__CHECK_ERROR , szErrorString);
										}
										else
										{
											TI_sprintf( szErrorString, "Generic item revision %s of Instance ID %s is not released or included in the change folder.", value, itemRevId);
											tiauto_writeErrorMsgToStack(&currErrMsg, TIAUTO_STATUS__CHECK_ERROR , szErrorString);
										}
										decision = EPM_nogo;
									}
									
									//In case the generic is released ,to check if the release status is "study approved" or 
									//higher
									else if(is_released == TRUE && tiauto_status_progression_index (pcRelSts, StatusProgression) < StudyAppStatus.iLevel && pcRelSts != NULL)
									{
										//if in case the generic item already added in the affected folder then no error message should be printed.
										for(inx = 0; inx < iNumAffected ; inx++)
										{
											if( ptAffectedItems[inx] == genItem )
												iGenItemCount += 1;		
										}
										if( iGenItemCount == 0 )//if in case the generic item is not in the affected folder then error message should be printed.
										{
											TI_sprintf( szErrorString, "Generic item revision %s of Instance ID %s is released but it is at a status lower than Study Approved status.", value, itemRevId);
											tiauto_writeErrorMsgToStack(&currErrMsg, TIAUTO_STATUS__CHECK_ERROR , szErrorString);
											decision = EPM_nogo;
										}
									}
								}
								else
								{
									if( tc_strcmp(value,cActItemRev)==0 )
									{
										TI_sprintf( szErrorString, "Failed while finding released status of generic %s item of instance item %s.\n", value, itemRevId);
										EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
									}
									else
									{
										TI_sprintf( szErrorString, "Failed while finding released status of generic item revision %s[%s] of instance item %s.\n", value,cActItemRev, itemRevId);
										EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
									}
									decision = EPM_nogo;
								}
							}
							else if ( (iRetCode == ITK_ok) && (genItem == NULLTAG) )
							{
								if( tc_strcmp(value,cActItemRev)==0 )
								{
									TI_sprintf( szErrorString, "Error: The generic item revision %s is not available in Teamcenter Database.\n", value);
									EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
								}
								else
								{
									TI_sprintf( szErrorString, "Error:  The generic item revision %s[%s] is not available in Teamcenter Database.\n", value,cActItemRev);
									EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
								}
								decision = EPM_nogo;
							}
							else
							{
								if( tc_strcmp(value,cActItemRev)==0 )
								{
									TI_sprintf( szErrorString, "Failed while finding generic item %s.\n", value);
									EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
								}
								else
								{
									TI_sprintf( szErrorString, "Failed while finding generic item %s[%s].\n", value,cActItemRev);
									EMH_store_error_s1(EMH_severity_error, iRetCode, szErrorString);
								}
								decision = EPM_nogo;
							}

							for(j =0; j<numIds; j++)
								SAFE_MEM_free (pcItemId[j]);
							pcItemId = NULL;
							for(j =0; j<numRevs; j++)
								SAFE_MEM_free (pcRevId[j]);
							pcRevId = NULL;						
							SAFE_MEM_free (tvalues);
							SAFE_MEM_free (value);							
						}
					}
				}
			}					
		}
		if(decision == EPM_nogo )
		{
			TIA_ErrorMessage *tempErrMsg = NULL; 
			if(currErrMsg)
			{
				EMH_store_error_s1(EMH_severity_error,TIAUTO_STATUS__CHECK_ERROR,"Please add these generic item revisions to the change folder.");				
				while(currErrMsg)
				{
                   	EMH_store_error_s1(EMH_severity_error,currErrMsg->iRetCode,currErrMsg->errMsg);
					tempErrMsg = currErrMsg;
					currErrMsg = currErrMsg->next;
					free ( tempErrMsg ); // Freeing memory 
					tempErrMsg = NULL;
				}
			}
		}
	}
	SAFE_MEM_free (attachment_tags);
	SAFE_MEM_free (ptAffectedItems);
	SAFE_MEM_free (pszClassName);
	SAFE_MEM_free (secondary_object_tags);
	SAFE_MEM_free (secondaryList);
	SAFE_MEM_free(pcRelSts);
	// SAFE_MEM_free (currErrMsg); Will cause mem leak	
	currErrMsg = NULL;
	return decision;
}
