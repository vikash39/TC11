/*******************************************************************************
/*******************************************************************************
File         : tiauto_ah_set_additional_reviewers_as_resp_party.c

Description  : Read the signoff user list from the task mentioned in the "from_review_task" agument.
	Then set the responsible party of the task mentioned in the argument "responsible_task" based on the signoff user position mentioned in the count value.

  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who          Description
May 10, 2016    1.0        Shilpa      Initial Creation
Feb 15, 2017	1.1		   Kantesh	   Code Cleanup
*******************************************************************************/

#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>
#include <epm/signoff.h>

extern int t1aAUTO_AH_set_additional_reviewers_as_resp_party(EPM_action_message_t msg)
{
	int				iRetcode			= ITK_ok;
	int             iNumArgs			= 0; 
	int				iLoopNumArgs		= 0;
	int				iValue				= 0;
	char			*pcFlag				= NULL;
	char			*pcValue			= NULL;
	char			*pcRespTask			= NULL;
	char			*pcInputTaskName	= NULL;
	char			*pcErrMsg			= NULL;
	char            szErrorString[TIAUTO_error_message_len+1]="";
	
	//getting no. of arguments
	iNumArgs = TC_number_of_arguments(msg.arguments);
    if (iNumArgs >=2 && iNumArgs < 4)
	{
		for(iLoopNumArgs = 0; iLoopNumArgs < iNumArgs; iLoopNumArgs++)
		{
			iRetcode = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &pcFlag, &pcValue );
			if ( iRetcode == ITK_ok )
			{
				if (tc_strcasecmp(pcFlag, "from_review_task") == 0 && pcValue != NULL)
				{
					pcInputTaskName = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcInputTaskName, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, "responsible_task") == 0 && pcValue != NULL)
				{
					pcRespTask = (char*) MEM_alloc(( (int)tc_strlen(pcValue) + 1) * sizeof(char));
                    tc_strcpy( pcRespTask, pcValue);
				}
				else if (tc_strcasecmp(pcFlag, "count") == 0 && pcValue != NULL)
				{
					iValue = atoi(pcValue);
				}				
						
				if( iRetcode != ITK_ok )
				{
					TI_sprintf(szErrorString, "Invalid Arguments provided to \"tiauto_ah_set_additional_reviewers_as_resp_party\" handler.\n");
					TC_write_syslog(szErrorString);
					EMH_store_error_s1( EMH_severity_error, iRetcode, szErrorString) ;
				}
			}
		}
		//To free the memory
		SAFE_MEM_free(pcFlag);
		SAFE_MEM_free(pcValue);
	}
	//invalid argument
	else if (iNumArgs > 4 )
	{
		iRetcode = EPM_invalid_argument;
	}	

    if(iRetcode == ITK_ok)
	{
		int				iSignOffUser		= 0;
		int				iAllCondTasks		= 0;
		tag_t			*ptSignOffUsers		= NULL;
		tag_t			tTaskType			= NULLTAG;
		tag_t			ptAllTaskTags		= NULLTAG;
		tag_t			tRootTaskTag		= NULLTAG;
		tag_t			*ptAllCondTaskTags	= NULL;
		char			*pcTaskTypeName		= NULL;
		//char			*pcTaskName			= NULL;

		//Getting the root task
		iRetcode = EPM_ask_root_task( msg.task, &tRootTaskTag);
		if(iRetcode == ITK_ok && tRootTaskTag != NULLTAG)
		{
			//Getting subtask name and typename of the -from_review_task
			TIAUTO_ITKCALL(iRetcode,EPM_ask_sub_task(tRootTaskTag,(const char*)pcInputTaskName,&ptAllTaskTags));
			if(iRetcode == ITK_ok && ptAllTaskTags != NULLTAG)
			{
				//TIAUTO_ITKCALL(iRetcode,EPM_ask_name2(ptAllTaskTags,&pcTaskName));
				TIAUTO_ITKCALL(iRetcode,TCTYPE_ask_object_type(ptAllTaskTags,&tTaskType));
				if(iRetcode == ITK_ok && tTaskType != NULLTAG)
				{
					TIAUTO_ITKCALL(iRetcode,AOM_ask_name(tTaskType,&pcTaskTypeName));
				}
				
				//if sub task -from_review_task is EPMReviewTask
				if((tc_strcmp(pcTaskTypeName,EPM_Review_Task)==0)  && iRetcode == ITK_ok)
				{
					int			iAllSubTasks				= 0;
					int			iLoopSubTasks				= 0;
					tag_t		*ptAllSubTasks				= NULL;
					tag_t		tSubTaskType				= NULLTAG;
					tag_t		*ptSignOffMemTags			= NULL;	
					char		*pcSubTaskTypeName			= NULL;

					//getting all subtasks of -from_review_task
					TIAUTO_ITKCALL(iRetcode,EPM_ask_sub_tasks(ptAllTaskTags,&iAllSubTasks,&ptAllSubTasks));
					if(iRetcode == ITK_ok && ptAllSubTasks != NULL)
					{
						for(iLoopSubTasks =0; iLoopSubTasks < iAllSubTasks && (iRetcode == ITK_ok); iLoopSubTasks++)
						{
							//getting tasktype of each subtask
							TIAUTO_ITKCALL(iRetcode,TCTYPE_ask_object_type(ptAllSubTasks[iLoopSubTasks],&tSubTaskType));
							if(iRetcode == ITK_ok && tSubTaskType != NULLTAG)
							{
								TIAUTO_ITKCALL(iRetcode,AOM_ask_name(tSubTaskType,&pcSubTaskTypeName));
							}
							
							//if sub task of -from_review_task is EPMPerformSignoffTask
							if((tc_strcmp(pcSubTaskTypeName,EPM_Perform_Signoff_Task)==0) && iRetcode == ITK_ok)
							{
								int		iSignOffGrpMem		= 0;
								
								//getting signoff members for the EPMPerformSignoffTask
								TIAUTO_ITKCALL(iRetcode,EPM_ask_reviewers(ptAllSubTasks[iLoopSubTasks],&iSignOffGrpMem,&ptSignOffMemTags));
								if(iRetcode == ITK_ok && ptSignOffMemTags != NULL && iSignOffGrpMem != 0)
								{
									TIAUTO_ITKCALL(iRetcode,EPM_get_users_for_group_members(iSignOffGrpMem,ptSignOffMemTags,&iSignOffUser,&ptSignOffUsers));
								}
							}
						}
					}
					
					//To free the memory
					SAFE_MEM_free(ptAllSubTasks)
					SAFE_MEM_free(pcSubTaskTypeName);
					SAFE_MEM_free(ptSignOffMemTags);
				}
				
				if(iRetcode == ITK_ok && ptSignOffUsers != NULL && iSignOffUser != 0)
				{
					//getting all subtasks
					TIAUTO_ITKCALL(iRetcode,EPM_ask_sub_tasks(tRootTaskTag,&iAllCondTasks,&ptAllCondTaskTags));
					if(iRetcode == ITK_ok && ptAllCondTaskTags != NULL)
					{
						int		iLoopAllCondTasks		= 0;
						
						for(iLoopAllCondTasks =0; iLoopAllCondTasks < iAllCondTasks && (iRetcode == ITK_ok); iLoopAllCondTasks++)
						{	
							char		*pcCondTaskName			= NULL;
							char		*pcCondTaskTypeName		= NULL;
							tag_t		 tCondTaskType			= NULLTAG;
							
							//getting tasktype name of each subtask
							TIAUTO_ITKCALL(iRetcode,TCTYPE_ask_object_type(ptAllCondTaskTags[iLoopAllCondTasks],&tCondTaskType));
							TIAUTO_ITKCALL(iRetcode,EPM_ask_name2(ptAllCondTaskTags[iLoopAllCondTasks],&pcCondTaskName));
							
							if(iRetcode == ITK_ok && tCondTaskType != NULLTAG)
							{
								TIAUTO_ITKCALL(iRetcode,AOM_ask_name(tCondTaskType,&pcCondTaskTypeName));
							}

							//if sub task is EPMTask
							if((tc_strcmp(pcCondTaskTypeName,EPM_Task)==0)  && iRetcode == ITK_ok)
							{
								int			iAllSysSubTasks					= 0;
								int			iLoopAllSysSubTasks				= 0;
								tag_t		*ptAllSysSubTasks				= NULL;
								tag_t		tSubSysTaskType					= NULLTAG;
								char		*pcSubSysTaskName				= NULL;
								char		*pcSubSysTaskTypeName			= NULL;

								//getting all subtasks if tasktype is EPMTask
								TIAUTO_ITKCALL(iRetcode,EPM_ask_sub_tasks(ptAllCondTaskTags[iLoopAllCondTasks],&iAllSysSubTasks,&ptAllSysSubTasks));
								if(iRetcode == ITK_ok && ptAllSysSubTasks != NULL)
								{
									for(iLoopAllSysSubTasks =0; iLoopAllSysSubTasks < iAllSysSubTasks && (iRetcode == ITK_ok); iLoopAllSysSubTasks++)
									{
										//getting tasktype of each subtask
										TIAUTO_ITKCALL(iRetcode,TCTYPE_ask_object_type(ptAllSysSubTasks[iLoopAllSysSubTasks],&tSubSysTaskType));
										TIAUTO_ITKCALL(iRetcode,EPM_ask_name2(ptAllSysSubTasks[iLoopAllSysSubTasks],&pcSubSysTaskName));
										
										if(iRetcode == ITK_ok && tSubSysTaskType != NULLTAG)
										{
											TIAUTO_ITKCALL(iRetcode,AOM_ask_name(tSubSysTaskType,&pcSubSysTaskTypeName));
										}
										
										//if sub task of EPMTask is EPMConditionTask and -responsible_task name and Conditional task name is same
										if((tc_strcmp(pcSubSysTaskTypeName,EPM_Condition_Task)==0) && (tc_strcmp(pcSubSysTaskName,pcRespTask)==0) && iRetcode == ITK_ok)
										{
											if(iSignOffUser >= iValue)
											{
												//Assigning responible party
												TIAUTO_ITKCALL(iRetcode,EPM_assign_responsible_party(ptAllSysSubTasks[iLoopAllSysSubTasks],ptSignOffUsers[iValue-1]));
												if(iRetcode == ITK_ok)
												{	
													//set the condition to true if number of signoff users are greater than input users
													iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_TRUE);
												}
											}
											else 
											{
												//set the condition to false
												iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
											}
										}
										//if sub task of EPMTask is not EPMConditionTask
										else if((tc_strcmp(pcSubSysTaskTypeName,EPM_Condition_Task)!=0) && (tc_strcmp(pcSubSysTaskName,pcRespTask)==0) && (iSignOffUser >=iValue) && (iRetcode == ITK_ok))
										{
											//Assigning responible party
											TIAUTO_ITKCALL(iRetcode,EPM_assign_responsible_party(ptAllSysSubTasks[iLoopAllSysSubTasks],ptSignOffUsers[iValue-1]));
										}
									}
								}
								
								//To free the memory
								SAFE_MEM_free(pcSubSysTaskName);
								SAFE_MEM_free(pcSubSysTaskTypeName);
								SAFE_MEM_free(ptAllSysSubTasks);
							}
							//if sub task of EPMTask is EPMConditionTask and -responsible_task name and Conditional task name is same
							else if((tc_strcmp(pcCondTaskTypeName,EPM_Condition_Task)==0) && (tc_strcmp(pcCondTaskName,pcRespTask)==0) && iRetcode == ITK_ok)
							{
								if(iSignOffUser >= iValue)
								{
									//Assigning responible party
									TIAUTO_ITKCALL(iRetcode,EPM_assign_responsible_party(ptAllCondTaskTags[iLoopAllCondTasks],ptSignOffUsers[iValue-1]));
									if(iRetcode == ITK_ok)
									{			
										//set the condition to true if number of signoff users are greater than input users
										iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_TRUE);
									}
								}	
								else 
								{
									//set the condition to false
									iRetcode = EPM_set_condition_task_result(msg.task,EPM_RESULT_FALSE);
								}							
							}
							//if sub task of EPMTask is not EPMConditionTask
							else if((tc_strcmp(pcCondTaskTypeName,EPM_Condition_Task)!=0) && (tc_strcmp(pcCondTaskName,pcRespTask)==0) && (iSignOffUser >=iValue) && (iRetcode == ITK_ok))
							{
								TIAUTO_ITKCALL(iRetcode,EPM_assign_responsible_party(ptAllCondTaskTags[iLoopAllCondTasks],ptSignOffUsers[iValue-1]));
							}
							
							//To free the memory
							SAFE_MEM_free(pcCondTaskName);
							SAFE_MEM_free(pcCondTaskTypeName);
						}
					}
				}
			}
		}
		
		//To free the memory
		//SAFE_MEM_free(pcTaskName);
		SAFE_MEM_free(ptSignOffUsers);
		SAFE_MEM_free(pcTaskTypeName);
		SAFE_MEM_free(ptAllCondTaskTags);
	}
	
	else if ( iRetcode != ITK_ok )
	{				
		EMH_ask_error_text (iRetcode, &pcErrMsg);
		EMH_store_error_s1( EMH_severity_error, iRetcode, pcErrMsg) ;
		SAFE_MEM_free (pcErrMsg);
	}
	
	//To free the memory
	SAFE_MEM_free(pcRespTask);
	SAFE_MEM_free(pcInputTaskName);

	return iRetcode;
}