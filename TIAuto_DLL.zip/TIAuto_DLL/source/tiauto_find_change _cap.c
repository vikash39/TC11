/*******************************************************************************************************************
File         : tiauto_find_change_cap.c

Description  : These are functions related to the user query - " TI Change"
			   This function will search for Change objects.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
19 Nov 2015		1.0			Pradeep				Initial Creation   
26 Jun 2016     1.1         Pradeep             Updated code to implement logic for 
												NEW_CAP, NEW_CCR, NEW_PMR and STD forms, also included new property "ProductGroup".
Nov 23 2018		1.2		    Jugunu              Updated for ER 9759 CAP3
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		TIAUTO_find_Change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "Change Affected programs" user query.
================================================================================================================*/
extern int find_change_cap (const char* pcChangeID,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags)
{
	int				iFail = ITK_ok;
	const char		*select_attr_list1[] = {"puid"};
	const char		*pcItemType[] = {"EngChange","T8_TI_Change"};
	int				iRows		= 0;
	int				i			= 0;
	int				iCols		= 0;
	void			***paReport;
	tag_t			tChItem	= NULLTAG;
	date_t dMBD, dSuggChangeImpDateAfter,dSuggChangeImpDateBefore,dRFQIssuedAfter,dRFQIssuedBefore=NULLDATE;
	//char	*pcForm = "T8_t1a120CAP";
	char	*pcFormAttr_AffPgms						= NULL;
	char	*pcFormAttr_Div							= NULL;
	char	*pcFormAttr_ProductGroup				= NULL;
	char	*pcFormAttr_AffPlant					= NULL;
	char	*pcFormAttr_ChangeDesc					= NULL;
	char	*pcFormAttr_ChangeDriver				= NULL;
	char	*pcFormAttr_TargetReleaseStatus			= NULL;
	char	*pcFormAttr_ReqGroup					= NULL;
	char	*pcFormAttr_CustTrackingNum				= NULL;
	char	*pcFormAttr_SuppTrackingNum				= NULL;
	char	*pcFormAttr_IsProdImpacted				= NULL;
	char	*pcFormAttr_SuggChangeImpDate			= NULL;
	char	*pcFormAttr_DesignWorkReq				= NULL;
	char	*pcFormAttr_LevelOfReq					= NULL;
	char	*pcFormAttr_MaterialImpacted			= NULL;
	char	*pcFormAttr_TypeOfChange				= NULL;
	char	*pcFormAttr_BillableCompType			= NULL;
	char	*pcFormAttr_BillableComp				= NULL;
	char	*pcFormAttr_CustAuthNum					= NULL;
	char	*pcFormAttr_CustName					= NULL;
	char	*pcFormAttr_CustNameType				= NULL;
	char	*pcFormAttr_CustAppReq					= NULL;
	char	*pcFormAttr_RFQIssued					= NULL;
			
	logical isCAP = false;
	logical isCCR = false;
	logical isNewECR = false;

	char acCAPForm_ClassName[64] = "";
	char acCCRForm_ClassName[64] = "";
	char acNewECRForm_ClassName[64] = "";
	//char acFormClassName[64] = "";
	//Manage attributes...
	//if (tc_strcmp(pcForm,"t8_t1a120cap") == 0)
	if (tc_strcasecmp(pcForm,"cap") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a120affectedprograms";
		pcFormAttr_Div								= "t8_120tidivisions";
		pcFormAttr_ProductGroup						= "t8_120productgroup";
		pcFormAttr_AffPlant							= "t8_120tiplant";
		pcFormAttr_ChangeDesc						= "t8_t1a120changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a120changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a120targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a120requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a120custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a120suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a120isproductimacted";		
		pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t1a41billablecompanytype";
		pcFormAttr_BillableComp						= "t1a41billablecompany";
		pcFormAttr_CustAppReq						= "t1a41customerapprovalreq";
		pcFormAttr_CustAuthNum						= "t1a41customerauthno";
		pcFormAttr_CustName							= "t1a41customername";
		pcFormAttr_CustNameType						= "t1a41customernametype";
		pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";

		tc_strcpy(acCAPForm_ClassName,"t8_t1a120cap");
		tc_strcpy(acCCRForm_ClassName,"t1a41CCR");
		tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}
	if (tc_strcasecmp(pcForm,"cap2") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t8_t1a191billablecompanytyp";
		pcFormAttr_BillableComp						= "t8_t1a191billablecompany";
		pcFormAttr_CustAppReq						= "t8_t1a191customerapprovalre";
		pcFormAttr_CustAuthNum						= "t8_t1a191customerauthno";
		//pcFormAttr_CustName							= "t8_t1a191customername";
		//pcFormAttr_CustNameType						= "t8_t1a191customernametype";
		//pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";

		tc_strcpy(acCAPForm_ClassName,"T8_t1a190CAP2");
		tc_strcpy(acCCRForm_ClassName,"T8_t1a191CCR2");
		tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}

	//adding CAP3 Changes
	if (tc_strcasecmp(pcForm,"cap3") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t8_t1a191billablecompanytyp";
		pcFormAttr_BillableComp						= "t8_t1a191billablecompany";
		pcFormAttr_CustAppReq						= "t8_t1a191customerapprovalre";
		pcFormAttr_CustAuthNum						= "t8_t1a191customerauthno";
		//pcFormAttr_CustName							= "t8_t1a191customername";
		//pcFormAttr_CustNameType						= "t8_t1a191customernametype";
		//pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";

		tc_strcpy(acCAPForm_ClassName,"T8_t1a190CAP3");
		tc_strcpy(acCCRForm_ClassName,"T8_t1a191CCR2");
		tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}

	//*********************************************************************
	if ( (isCAP == true) && (isCCR == true) && (isNewECR == false) )
	{
		//if (tc_strcasecmp(pcForm,"cap") == 0)
		//{
		//	tc_strcpy(acCAPForm_ClassName,"t8_t1a120cap");
		//	tc_strcpy(acCCRForm_ClassName,"t1a41CCR");
		//}
		//else
		//{
		//	//char acCAPForm_ClassName[64] = "T8_t1a190CAP2";
		//	//char acCCRForm_ClassName[64] = "T8_t1a191CCR2";
		//	tc_strcpy(acCAPForm_ClassName,"T8_t1a190CAP2");
		//	tc_strcpy(acCCRForm_ClassName,"T8_t1a191CCR2");
		//}

		//Create the main query
		iFail = POM_enquiry_create ("Find_change");

		//select output attribute for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "Item", 1, select_attr_list1));
	
		//craete alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "ImanRelation", 1, "ImanRelation_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "Form", 1, "Form_alias"));	
	
		//start query expression for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_7","Form","data_file",POM_enquiry_equal,acCAPForm_ClassName,"puid"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","itemrevision","puid",POM_enquiry_equal,"ImanRelation_alias","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_9","ImanRelation_alias","secondary_object",POM_enquiry_equal,"Form_alias","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form_alias","data_file",POM_enquiry_equal,acCCRForm_ClassName,"puid"));
		

		/*Filter for EngChange items only*/
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_11", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

		//****************************************************CAP FORM ATTRIBUTES***********************************//
		/*Affected Program*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPgms,"class_affected")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_12",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_affected","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcAffPgms, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id2" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPlant,"class_plant")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_14",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_plant","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1, &pcAffPlant, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15", "class_plant","pval",POM_enquiry_equal ,"aunique_value_id4" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcTIDiv, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16", acCAPForm_ClassName, pcFormAttr_Div,POM_enquiry_like ,"aunique_value_id3" ));
		}
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id5", 1, &pcTIChangeDesc, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_17", acCAPForm_ClassName, pcFormAttr_ChangeDesc,POM_enquiry_like ,"aunique_value_id5" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_17",POM_case_insensitive));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{	
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id6", 1, &pcChangeDriver, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", acCAPForm_ClassName, pcFormAttr_ChangeDriver,POM_enquiry_like ,"aunique_value_id6" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id7", 1, &pcTargetReleaseStatus, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_19", acCAPForm_ClassName, pcFormAttr_TargetReleaseStatus,POM_enquiry_like ,"aunique_value_id7" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id8", 1, &pcReqGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", acCAPForm_ClassName, pcFormAttr_ReqGroup,POM_enquiry_like ,"aunique_value_id8" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcCustTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21", acCAPForm_ClassName, pcFormAttr_CustTrackingNum,POM_enquiry_like ,"aunique_value_id9" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcSuppTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", acCAPForm_ClassName, pcFormAttr_SuppTrackingNum,POM_enquiry_like ,"aunique_value_id10" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcIsProdImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_23", acCAPForm_ClassName, pcFormAttr_IsProdImpacted,POM_enquiry_like ,"aunique_value_id11" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateAfter, &dSuggChangeImpDateAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id12", 1, &dSuggChangeImpDateAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_24", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_greater_than_or_eq ,"aunique_value_id12" ));
		}
		//****************************************************CAP FORM ATTRIBUTES***********************************//
		

		//****************************************************CCR FORM ATTRIBUTES***********************************//
		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id13", 1, &pcBillableCompType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_25", acCCRForm_ClassName, pcFormAttr_BillableCompType,POM_enquiry_like ,"aunique_value_id13" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcBillableComp, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_26", acCCRForm_ClassName, pcFormAttr_BillableComp,POM_enquiry_like ,"aunique_value_id14" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcCustAuthNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_27", acCCRForm_ClassName, pcFormAttr_CustAuthNum,POM_enquiry_like ,"aunique_value_id15" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcCustName, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_28", acCCRForm_ClassName, pcFormAttr_CustName,POM_enquiry_like ,"aunique_value_id16" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id17", 1, &pcCustNameType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_29", acCCRForm_ClassName, pcFormAttr_CustNameType,POM_enquiry_like ,"aunique_value_id17" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcCustAppReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_30", acCCRForm_ClassName, pcFormAttr_CustAppReq,POM_enquiry_like ,"aunique_value_id18" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedAfter, &dRFQIssuedAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id19", 1, &dRFQIssuedAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_31", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_greater_than_or_eq ,"aunique_value_id19" ));
		}
		//****************************************************CCR FORM ATTRIBUTES***********************************//

		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateBefore, &dSuggChangeImpDateBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id20", 1, &dSuggChangeImpDateBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_62", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_less_than_or_eq ,"aunique_value_id20" ));
		}
		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedBefore, &dRFQIssuedBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id21", 1, &dRFQIssuedBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_63", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_less_than_or_eq ,"aunique_value_id21" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id22", 1, &pcProductGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_200", acCAPForm_ClassName, pcFormAttr_ProductGroup,POM_enquiry_like ,"aunique_value_id22" ));
		}

		//join the expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_32","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_33","auniqueExprId_32",POM_enquiry_and, "auniqueExprId_3" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_34","auniqueExprId_33",POM_enquiry_and, "auniqueExprId_4" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_35","auniqueExprId_34",POM_enquiry_and, "auniqueExprId_5" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_36","auniqueExprId_35",POM_enquiry_and, "auniqueExprId_6" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_37","auniqueExprId_36",POM_enquiry_and, "auniqueExprId_7" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_38","auniqueExprId_37",POM_enquiry_and, "auniqueExprId_8" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_39","auniqueExprId_38",POM_enquiry_and, "auniqueExprId_9" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_40","auniqueExprId_39",POM_enquiry_and, "auniqueExprId_10" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_41","auniqueExprId_40",POM_enquiry_and, "auniqueExprId_11" ));
	
		/*Affected Programs*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_12" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_13" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_14" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_15" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_16" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_1" ));
		}
		
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_17" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_18" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_19" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_20" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_1" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_21" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_22" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_23" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_24" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_1" ));
		}



		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_25" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_26" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_27" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_28" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_29" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_30" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_31" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_1" ));
		}


		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_62" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_63" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_200" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_1" ));
		}

		
		//set where expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_66" ));	
	
		//set distinct value
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
		//execute the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
		//delete the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
		//process result	
		if(iRows > 0)
		{
			//allocate memory
			*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
			*iNumFound = iRows;
			for(i=0;i<iRows;i++)
			{
				tChItem = NULLTAG;
				tChItem = *(tag_t *)paReport[i][0];
				(*foundTags)[i] = tChItem;
			}
			SAFE_MEM_free(paReport);
		}
	}

	//***********************************************************
	if ( (isCAP == true) && (isNewECR == true)  && (isCCR == false))
	{
		/*if (tc_strcasecmp(pcForm,"cap") == 0)
		{
			tc_strcpy(acCAPForm_ClassName,"t8_t1a120cap");
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		}
		else
		{
			tc_strcpy(acCAPForm_ClassName,"T8_t1a190CAP2");
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		}*/
		//char acCAPForm_ClassName[64] = "t8_t1a120cap";
		//char acNewECRForm_ClassName[64] = "t8_t1a133ecr";

		//Create the main query
		iFail = POM_enquiry_create ("Find_change");

		//select output attribute for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "Item", 1, select_attr_list1));
	
		//craete alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "ImanRelation", 1, "ImanRelation_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "Form", 1, "Form_alias"));	
	
		//start query expression for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_7","Form","data_file",POM_enquiry_equal,acCAPForm_ClassName,"puid"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","itemrevision","puid",POM_enquiry_equal,"ImanRelation_alias","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_9","ImanRelation_alias","secondary_object",POM_enquiry_equal,"Form_alias","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form_alias","data_file",POM_enquiry_equal,acNewECRForm_ClassName,"puid"));
		

		/*Filter for EngChange items only*/
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_11", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

		//****************************************************CAP FORM ATTRIBUTES***********************************//
		/*Affected Program*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPgms,"class_affected")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_12",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_affected","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcAffPgms, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id2" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPlant,"class_plant")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_14",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_plant","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1, &pcAffPlant, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15", "class_plant","pval",POM_enquiry_equal ,"aunique_value_id4" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcTIDiv, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16", acCAPForm_ClassName, pcFormAttr_Div,POM_enquiry_like ,"aunique_value_id3" ));
		}
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id5", 1, &pcTIChangeDesc, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_17", acCAPForm_ClassName, pcFormAttr_ChangeDesc,POM_enquiry_like ,"aunique_value_id5" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_17",POM_case_insensitive));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{	
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id6", 1, &pcChangeDriver, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", acCAPForm_ClassName, pcFormAttr_ChangeDriver,POM_enquiry_like ,"aunique_value_id6" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id7", 1, &pcTargetReleaseStatus, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_19", acCAPForm_ClassName, pcFormAttr_TargetReleaseStatus,POM_enquiry_like ,"aunique_value_id7" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id8", 1, &pcReqGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", acCAPForm_ClassName, pcFormAttr_ReqGroup,POM_enquiry_like ,"aunique_value_id8" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcCustTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21", acCAPForm_ClassName, pcFormAttr_CustTrackingNum,POM_enquiry_like ,"aunique_value_id9" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcSuppTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", acCAPForm_ClassName, pcFormAttr_SuppTrackingNum,POM_enquiry_like ,"aunique_value_id10" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcIsProdImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_23", acCAPForm_ClassName, pcFormAttr_IsProdImpacted,POM_enquiry_like ,"aunique_value_id11" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateAfter, &dSuggChangeImpDateAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id12", 1, &dSuggChangeImpDateAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_24", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_greater_than_or_eq ,"aunique_value_id12" ));
		}
		//****************************************************CAP FORM ATTRIBUTES***********************************//
		

		//****************************************************New ECR FORM ATTRIBUTES***********************************//
		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id13", 1, &pcDesignWorkReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_25", acNewECRForm_ClassName, pcFormAttr_DesignWorkReq,POM_enquiry_like ,"aunique_value_id13" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcLevelOfReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_26", acNewECRForm_ClassName, pcFormAttr_LevelOfReq,POM_enquiry_like ,"aunique_value_id14" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcMaterialImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_27", acNewECRForm_ClassName, pcFormAttr_MaterialImpacted,POM_enquiry_like ,"aunique_value_id15" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcTypeOfChange, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_28", acNewECRForm_ClassName, pcFormAttr_TypeOfChange,POM_enquiry_like ,"aunique_value_id16" ));
		}
		//****************************************************New ECR FORM ATTRIBUTES***********************************//
		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateBefore, &dSuggChangeImpDateBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id17", 1, &dSuggChangeImpDateBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_100", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_less_than_or_eq ,"aunique_value_id17" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcProductGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_200", acCAPForm_ClassName, pcFormAttr_ProductGroup,POM_enquiry_like ,"aunique_value_id18" ));
		}

		//join the expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_32","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_33","auniqueExprId_32",POM_enquiry_and, "auniqueExprId_3" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_34","auniqueExprId_33",POM_enquiry_and, "auniqueExprId_4" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_35","auniqueExprId_34",POM_enquiry_and, "auniqueExprId_5" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_36","auniqueExprId_35",POM_enquiry_and, "auniqueExprId_6" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_37","auniqueExprId_36",POM_enquiry_and, "auniqueExprId_7" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_38","auniqueExprId_37",POM_enquiry_and, "auniqueExprId_8" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_39","auniqueExprId_38",POM_enquiry_and, "auniqueExprId_9" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_40","auniqueExprId_39",POM_enquiry_and, "auniqueExprId_10" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_41","auniqueExprId_40",POM_enquiry_and, "auniqueExprId_11" ));
	
		/*Affected Programs*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_12" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_13" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_14" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_15" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_16" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_1" ));
		}
		
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_17" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_18" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_19" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_20" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_1" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_21" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_22" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_23" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_24" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_1" ));
		}


		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_25" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_26" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_27" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_28" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_1" ));
		}

		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_100" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_200" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_1" ));
		}
		
	
		//set where expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_60" ));	
	
		//set distinct value
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
		//execute the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
		//delete the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
		//process result	
		if(iRows > 0)
		{
			//allocate memory
			*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
			*iNumFound = iRows;
			for(i=0;i<iRows;i++)
			{
				tChItem = NULLTAG;
				tChItem = *(tag_t *)paReport[i][0];
				(*foundTags)[i] = tChItem;
			}
			SAFE_MEM_free(paReport);
		}
	}

	//*************************************************
	if ( (isNewECR == true) && (isCCR == true) && (isCAP == false)  )
	{
		//char acNewECRForm_ClassName[64] = "t8_t1a133ecr";
		//char acCCRForm_ClassName[64] = "t1a41CCR";

		/*if (tc_strcasecmp(pcForm,"cap") == 0)
		{
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
			tc_strcpy(acCCRForm_ClassName,"t1a41CCR");
		}
		else
		{
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
			tc_strcpy(acCCRForm_ClassName,"T8_t1a191CCR2");
		}*/

		//Create the main query
		iFail = POM_enquiry_create ("Find_change");

		//select output attribute for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "Item", 1, select_attr_list1));
	
		//craete alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "ImanRelation", 1, "ImanRelation_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "Form", 1, "Form_alias"));	
	
		//start query expression for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_7","Form","data_file",POM_enquiry_equal,acNewECRForm_ClassName,"puid"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","itemrevision","puid",POM_enquiry_equal,"ImanRelation_alias","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_9","ImanRelation_alias","secondary_object",POM_enquiry_equal,"Form_alias","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form_alias","data_file",POM_enquiry_equal,acCCRForm_ClassName,"puid"));
		

		/*Filter for EngChange items only*/
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_11", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

		
		//****************************************************CCR FORM ATTRIBUTES***********************************//
		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcBillableCompType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_12", acCCRForm_ClassName, pcFormAttr_BillableCompType,POM_enquiry_like ,"aunique_value_id2" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcBillableComp, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13", acCCRForm_ClassName, pcFormAttr_BillableComp,POM_enquiry_like ,"aunique_value_id3" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1, &pcCustAuthNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_14", acCCRForm_ClassName, pcFormAttr_CustAuthNum,POM_enquiry_like ,"aunique_value_id4" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id5", 1, &pcCustName, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15", acCCRForm_ClassName, pcFormAttr_CustName,POM_enquiry_like ,"aunique_value_id5" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id6", 1, &pcCustNameType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16", acCCRForm_ClassName, pcFormAttr_CustNameType,POM_enquiry_like ,"aunique_value_id6" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id7", 1, &pcCustAppReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_17", acCCRForm_ClassName, pcFormAttr_CustAppReq,POM_enquiry_like ,"aunique_value_id7" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedAfter, &dRFQIssuedAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id8", 1, &dRFQIssuedAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_greater_than_or_eq ,"aunique_value_id8" ));
		}
		//****************************************************CCR FORM ATTRIBUTES***********************************//

		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcDesignWorkReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_19", acNewECRForm_ClassName, pcFormAttr_DesignWorkReq,POM_enquiry_like ,"aunique_value_id9" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcLevelOfReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", acNewECRForm_ClassName, pcFormAttr_LevelOfReq,POM_enquiry_like ,"aunique_value_id10" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcMaterialImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21", acNewECRForm_ClassName, pcFormAttr_MaterialImpacted,POM_enquiry_like ,"aunique_value_id11" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id12", 1, &pcTypeOfChange, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", acNewECRForm_ClassName, pcFormAttr_TypeOfChange,POM_enquiry_like ,"aunique_value_id12" ));
		}

		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedBefore, &dRFQIssuedBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id13", 1, &dRFQIssuedBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_100", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_less_than_or_eq ,"aunique_value_id13" ));
		}



		//join the expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_32","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_33","auniqueExprId_32",POM_enquiry_and, "auniqueExprId_3" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_34","auniqueExprId_33",POM_enquiry_and, "auniqueExprId_4" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_35","auniqueExprId_34",POM_enquiry_and, "auniqueExprId_5" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_36","auniqueExprId_35",POM_enquiry_and, "auniqueExprId_6" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_37","auniqueExprId_36",POM_enquiry_and, "auniqueExprId_7" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_38","auniqueExprId_37",POM_enquiry_and, "auniqueExprId_8" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_39","auniqueExprId_38",POM_enquiry_and, "auniqueExprId_9" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_40","auniqueExprId_39",POM_enquiry_and, "auniqueExprId_10" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_41","auniqueExprId_40",POM_enquiry_and, "auniqueExprId_11" ));
	
		
		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_12" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_13" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_14" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_15" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_16" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_17" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_18" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_1" ));
		}


		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_19" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_20" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_21" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_22" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_100" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_1" ));
		}	

		//set where expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_53" ));	
	
		//set distinct value
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
		//execute the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
		//delete the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
		//process result	
		if(iRows > 0)
		{
			//allocate memory
			*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
			*iNumFound = iRows;
			for(i=0;i<iRows;i++)
			{
				tChItem = NULLTAG;
				tChItem = *(tag_t *)paReport[i][0];
				(*foundTags)[i] = tChItem;
			}
			SAFE_MEM_free(paReport);
		}
	}

	//*********************************************************************
	if ( (isCAP == true) && (isCCR == true) && (isNewECR == true) )
	{
		//char acCAPForm_ClassName[64] = "t8_t1a120cap";
		//char acCCRForm_ClassName[64] = "t1a41CCR";
		//char acNewECRForm_ClassName[64] = "t8_t1a133ecr";

		/*if (tc_strcasecmp(pcForm,"cap") == 0)
		{
			tc_strcpy(acCAPForm_ClassName,"t8_t1a120cap");
			tc_strcpy(acCCRForm_ClassName,"t1a41CCR");
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		}
		else
		{
			tc_strcpy(acCAPForm_ClassName,"T8_t1a190CAP2");
			tc_strcpy(acCCRForm_ClassName,"T8_t1a191CCR2");
			tc_strcpy(acNewECRForm_ClassName,"t8_t1a133ecr");
		}*/

		//Create the main query
		iFail = POM_enquiry_create ("Find_change");

		//select output attribute for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "Item", 1, select_attr_list1));
	
		//craete alias
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "ImanRelation", 1, "ImanRelation_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "ImanRelation", 1, "ImanRelation_alias_2"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "Form", 1, "Form_alias"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "Form", 1, "Form_alias_2"));	
	
		//start query expression for main query
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_7","Form","data_file",POM_enquiry_equal,acCAPForm_ClassName,"puid"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","itemrevision","puid",POM_enquiry_equal,"ImanRelation_alias","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_9","ImanRelation_alias","secondary_object",POM_enquiry_equal,"Form_alias","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form_alias","data_file",POM_enquiry_equal,acCCRForm_ClassName,"puid"));

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_11","itemrevision","puid",POM_enquiry_equal,"ImanRelation_alias_2","primary_object"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_12","ImanRelation_alias_2","secondary_object",POM_enquiry_equal,"Form_alias_2","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_13","Form_alias_2","data_file",POM_enquiry_equal,acNewECRForm_ClassName,"puid"));
		

		/*Filter for EngChange items only*/
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_14", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

		//****************************************************CAP FORM ATTRIBUTES***********************************//
		/*Affected Program*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPgms,"class_affected")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_15",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_affected","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcAffPgms, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id2" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acCAPForm_ClassName, pcFormAttr_AffPlant,"class_plant")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_17",acCAPForm_ClassName,"puid",POM_enquiry_equal,"class_plant","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1, &pcAffPlant, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", "class_plant","pval",POM_enquiry_equal ,"aunique_value_id4" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcTIDiv, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_19", acCAPForm_ClassName, pcFormAttr_Div,POM_enquiry_like ,"aunique_value_id3" ));
		}
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id5", 1, &pcTIChangeDesc, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", acCAPForm_ClassName, pcFormAttr_ChangeDesc,POM_enquiry_like ,"aunique_value_id5" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_20",POM_case_insensitive));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{	
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id6", 1, &pcChangeDriver, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_21", acCAPForm_ClassName, pcFormAttr_ChangeDriver,POM_enquiry_like ,"aunique_value_id6" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id7", 1, &pcTargetReleaseStatus, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", acCAPForm_ClassName, pcFormAttr_TargetReleaseStatus,POM_enquiry_like ,"aunique_value_id7" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id8", 1, &pcReqGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_23", acCAPForm_ClassName, pcFormAttr_ReqGroup,POM_enquiry_like ,"aunique_value_id8" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id9", 1, &pcCustTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_24", acCAPForm_ClassName, pcFormAttr_CustTrackingNum,POM_enquiry_like ,"aunique_value_id9" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcSuppTrackingNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_25", acCAPForm_ClassName, pcFormAttr_SuppTrackingNum,POM_enquiry_like ,"aunique_value_id10" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcIsProdImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_26", acCAPForm_ClassName, pcFormAttr_IsProdImpacted,POM_enquiry_like ,"aunique_value_id11" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateAfter, &dSuggChangeImpDateAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id12", 1, &dSuggChangeImpDateAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_27", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_greater_than_or_eq ,"aunique_value_id12" ));
		}
		//****************************************************CAP FORM ATTRIBUTES***********************************//
		

		//****************************************************CCR FORM ATTRIBUTES***********************************//
		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id13", 1, &pcBillableCompType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_28", acCCRForm_ClassName, pcFormAttr_BillableCompType,POM_enquiry_like ,"aunique_value_id13" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcBillableComp, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_29", acCCRForm_ClassName, pcFormAttr_BillableComp,POM_enquiry_like ,"aunique_value_id14" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcCustAuthNum, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_30", acCCRForm_ClassName, pcFormAttr_CustAuthNum,POM_enquiry_like ,"aunique_value_id15" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcCustName, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_31", acCCRForm_ClassName, pcFormAttr_CustName,POM_enquiry_like ,"aunique_value_id16" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id17", 1, &pcCustNameType, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_32", acCCRForm_ClassName, pcFormAttr_CustNameType,POM_enquiry_like ,"aunique_value_id17" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcCustAppReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_33", acCCRForm_ClassName, pcFormAttr_CustAppReq,POM_enquiry_like ,"aunique_value_id18" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedAfter, &dRFQIssuedAfter));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id19", 1, &dRFQIssuedAfter, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_34", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_greater_than_or_eq ,"aunique_value_id19" ));
		}
		//****************************************************CCR FORM ATTRIBUTES***********************************//

		//****************************************************New ECR FORM ATTRIBUTES***********************************//
		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id20", 1, &pcDesignWorkReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_35", acNewECRForm_ClassName, pcFormAttr_DesignWorkReq,POM_enquiry_like ,"aunique_value_id20" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id21", 1, &pcLevelOfReq, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_36", acNewECRForm_ClassName, pcFormAttr_LevelOfReq,POM_enquiry_like ,"aunique_value_id21" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id22", 1, &pcMaterialImpacted, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_37", acNewECRForm_ClassName, pcFormAttr_MaterialImpacted,POM_enquiry_like ,"aunique_value_id22" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id23", 1, &pcTypeOfChange, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_38", acNewECRForm_ClassName, pcFormAttr_TypeOfChange,POM_enquiry_like ,"aunique_value_id23" ));
		}
		//****************************************************New ECR FORM ATTRIBUTES***********************************//
		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateBefore, &dSuggChangeImpDateBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id24", 1, &dSuggChangeImpDateBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_100", acCAPForm_ClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_less_than_or_eq ,"aunique_value_id24" ));
		}
		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedBefore, &dRFQIssuedBefore));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id25", 1, &dRFQIssuedBefore, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_101", acCCRForm_ClassName, pcFormAttr_RFQIssued,POM_enquiry_less_than_or_eq ,"aunique_value_id25" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id26", 1, &pcProductGroup, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_200", acCAPForm_ClassName, pcFormAttr_ProductGroup,POM_enquiry_like ,"aunique_value_id26" ));
		}


		//join the expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_39","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_40","auniqueExprId_39",POM_enquiry_and, "auniqueExprId_3" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_41","auniqueExprId_40",POM_enquiry_and, "auniqueExprId_4" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_42","auniqueExprId_41",POM_enquiry_and, "auniqueExprId_5" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_43","auniqueExprId_42",POM_enquiry_and, "auniqueExprId_6" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_44","auniqueExprId_43",POM_enquiry_and, "auniqueExprId_7" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and, "auniqueExprId_8" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and, "auniqueExprId_9" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_10" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_11" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_12" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_13" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_14" ));
	
		/*Affected Programs*/
		if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_15" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_16" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Plant*/
		if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_17" ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_18" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*TI Division*/
		if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_19" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_1" ));
		}
		
		/*TI Change Description*/
		if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_20" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Change Driver*/
		if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_21" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Target Release Status*/
		if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_22" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Requesting Group*/
		if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_23" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_1" ));
		}

		/*Customer Tracking Number*/
		if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_24" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Supplier Tracking Number*/
		if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_25" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Is Product Impacted*/
		if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_26" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Suggested Change Implementation Date After*/
		if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_27" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_1" ));
		}



		/*Billable Company Type*/
		if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_28" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Billable Company*/
		if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_29" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Authorization Number*/
		if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_30" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name*/
		if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_31" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Name Type*/
		if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_32" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Customer Approval Required*/
		if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_33" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued After*/
		if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_34" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_1" ));
		}


		/*Design Work Required*/
		if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and, "auniqueExprId_35" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Level of Request*/
		if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_36" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Material Impacted*/
		if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_37" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Type of Change*/
		if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_38" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_1" ));
		}
		
		/*Suggested Change Implementation Date Before*/
		if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_100" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*RFQ Issued Before*/
		if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_101" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_1" ));
		}
		/*Product Group*/
		if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and, "auniqueExprId_200" ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and, "auniqueExprId_1" ));
		}
		

		//set where expression
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_78" ));	
	
		//set distinct value
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
		//execute the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
		//delete the query
		TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
		//process result	
		if(iRows > 0)
		{
			//allocate memory
			*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
			*iNumFound = iRows;
			for(i=0;i<iRows;i++)
			{
				tChItem = NULLTAG;
				tChItem = *(tag_t *)paReport[i][0];
				(*foundTags)[i] = tChItem;
			}
			SAFE_MEM_free(paReport);
		}
	}

	return iFail;
}