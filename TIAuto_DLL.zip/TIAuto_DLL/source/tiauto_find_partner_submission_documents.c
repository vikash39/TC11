
#include <tiauto_find_partner_submission_functions.h>

//==============================================================================================
extern int find_partner_submission_data(const char* Keyword_DocumentID,const char* Keyword_RevisionID,const char* Keyword_Name,const char* Keyword_DocumentType,
										const char* Keyword_CAD,const char* Keyword_CBD, const char* Keyword_MAD, const char* Keyword_MBD,
										const char* Keyword_PdeJobNumber,const char* Keyword_SendingCompanyName,const char* Keyword_SendingCountry,
										const char* Keyword_SendingCity,const char* Keyword_SenderName,const char* Keyword_SenderEmailAddr,
										const char* Keyword_ReceivingCompanyName,const char* Keyword_ReceivingCountry,
										const char* Keyword_ReceivingCity,const char* Keyword_ReceiverName,const char* Keyword_ReceiverDept,
										const char* Keyword_ReceiverMailAddr,const char* Keyword_ReceiverFax,const char* Keyword_ReceivingLocation,
										const char* Keyword_ReceivingPostalCode,const char* Keyword_ReceivingStreet,const char* Keyword_ReceiverContactNum,const char* Keyword_SenderContactNum,
										const char* Keyword_SenderDept,const char* Keyword_SenderFax,const char* Keyword_SenderPostalcode,
										const char* Keyword_SendingLocation,const char* Keyword_SendingStreet, const char* Keyword_Action,
										const char* Keyword_DocumentDesc, const char* Keyword_DocumentNum, const char* Keyword_Information,
										const char* Keyword_PartNum, const char* Keyword_PartRev, const char* Keyword_State,
										int *iNumFound,tag_t **foundTags, char *pcClassName)
{

	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	void *** report;
	tag_t tItemRev = NULLTAG;
	const char* select_attr_list1[] = { "puid"};
    date_t aDate,bDate,cDate,dDate;

	/*create a query*/
	ifail = POM_enquiry_create ("findpartnersubmissiondocument");

	//initialise the outputs
	ifail = POM_enquiry_add_select_attrs ( "findpartnersubmissiondocument", "Item", 1, select_attr_list1);

	//craete alias
	ifail = POM_enquiry_create_class_alias ("findpartnersubmissiondocument", "WorkSpaceObject", 1, "WorkSpaceObject_alias");	

	//set join expression for attributes
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_1","Item","puid",POM_enquiry_equal,"ItemRevision","items_tag");
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_2","ItemRevision","puid",POM_enquiry_equal,"ImanRelation","primary_object");
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid");	
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_4","Form","data_file",POM_enquiry_equal,pcClassName,"puid");
	
   //set join expression for dates, objectname and objecttype
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_5","ItemRevision","puid",POM_enquiry_equal,"WorkSpaceObject","puid"); 
	    ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_6","ItemRevision","items_tag",POM_enquiry_equal,"WorkSpaceObject_alias","puid"); 
		ifail = POM_enquiry_set_join_expr ("findpartnersubmissiondocument","auniqueExprId_7","WorkSpaceObject", "puid", POM_enquiry_equal, "Pom_application_object", "puid");
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_99",pcClassName,"t8_pdejobnumber",POM_enquiry_is_not_null,NULL);

	//join the expression for attributes
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_8","auniqueExprId_1",POM_enquiry_and,"auniqueExprId_2");
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_9","auniqueExprId_8",POM_enquiry_and,"auniqueExprId_3");
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_10","auniqueExprId_9",POM_enquiry_and,"auniqueExprId_4");

   //set join expression for dates, objectname and objecttype
        ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_11","auniqueExprId_10",POM_enquiry_and,"auniqueExprId_5");
        ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_12","auniqueExprId_11",POM_enquiry_and,"auniqueExprId_6");
        ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_13","auniqueExprId_12",POM_enquiry_and,"auniqueExprId_7");

//=======================================================================
     //setting all the keyword to uniquevalueID
//=======================================================================

	 if (strcmp (Keyword_DocumentID ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id1", 1,&Keyword_DocumentID, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_14","Item","item_id",POM_enquiry_like,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_14",POM_case_insensitive);
	  }

	 if (strcmp (Keyword_RevisionID ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id2", 1,&Keyword_RevisionID, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_15","ItemRevision","item_revision_id",POM_enquiry_like,"aunique_value_id2");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_15",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_Name ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id3", 1,&Keyword_Name, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_16","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id3");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_16",POM_case_insensitive);
	  }

	 if (strcmp (Keyword_DocumentType ,"") != 0)

	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id4", 1,&Keyword_DocumentType, POM_enquiry_bind_value );
        ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_17","WorkSpaceObject_alias","object_type",POM_enquiry_equal,"aunique_value_id4");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_17",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_CAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_CAD, &aDate);

		ifail = POM_enquiry_set_date_value ("findpartnersubmissiondocument", "aunique_value_id5", 1, &aDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument", "auniqueExprId_18","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id5");
	  }

	 if (strcmp (Keyword_CBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_CBD, &bDate);
		 
		ifail = POM_enquiry_set_date_value ("findpartnersubmissiondocument", "aunique_value_id6", 1, &bDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument", "auniqueExprId_19","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id6");	

	  }

	 if (strcmp (Keyword_MAD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_MAD, &cDate);

		ifail = POM_enquiry_set_date_value ("findpartnersubmissiondocument", "aunique_value_id7", 1, &cDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument", "auniqueExprId_20","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id7");	
	  }

	 if (strcmp (Keyword_MBD ,"") != 0)
	 {
		 /* a date value object using local time zone time */
		ifail = ITK_string_to_date(Keyword_MBD, &dDate);

		ifail = POM_enquiry_set_date_value ("findpartnersubmissiondocument", "aunique_value_id8", 1, &dDate, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument", "auniqueExprId_21","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id8");
	  }

	 if (strcmp (Keyword_PdeJobNumber ,"") != 0)

	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id9", 1,&Keyword_PdeJobNumber, POM_enquiry_bind_value );
        ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_22",pcClassName,"t8_pdejobnumber",POM_enquiry_like,"aunique_value_id9");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_22",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SendingCompanyName ,"") != 0)
	 {
		 ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id10", 1,&Keyword_SendingCompanyName, POM_enquiry_bind_value );
         ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_23",pcClassName,"t8_sendingcompanyname",POM_enquiry_like,"aunique_value_id10");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_23",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SendingCountry ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id11", 1,&Keyword_SendingCountry, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_24",pcClassName,"t8_sendingcountry",POM_enquiry_like,"aunique_value_id11");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_24",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SendingCity ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id12", 1,&Keyword_SendingCity, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_25",pcClassName,"t8_sendingcity",POM_enquiry_like,"aunique_value_id12");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_25",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderName ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id13", 1,&Keyword_SenderName, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_26",pcClassName,"t8_sendername",POM_enquiry_like,"aunique_value_id13");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_26",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderEmailAddr ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id14", 1,&Keyword_SenderEmailAddr, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_27",pcClassName,"t8_senderemailaddr",POM_enquiry_like,"aunique_value_id14");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_27",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingCompanyName ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id15", 1,&Keyword_ReceivingCompanyName, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_28",pcClassName,"t8_receivingcompanyname",POM_enquiry_like,"aunique_value_id15");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_28",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingCountry ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id16", 1,&Keyword_ReceivingCountry, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_29",pcClassName,"t8_receivingcountry",POM_enquiry_like,"aunique_value_id16");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_29",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingCity ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id17", 1,&Keyword_ReceivingCity, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_30",pcClassName,"t8_receivingcity",POM_enquiry_like,"aunique_value_id17");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_30",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceiverName ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id18", 1,&Keyword_ReceiverName, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_31",pcClassName,"t8_receivername",POM_enquiry_like,"aunique_value_id18");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_31",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceiverDept ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id19", 1,&Keyword_ReceiverDept, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_32",pcClassName,"t8_receiverdept",POM_enquiry_like,"aunique_value_id19");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_32",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceiverMailAddr ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id20", 1,&Keyword_ReceiverMailAddr, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_33",pcClassName,"t8_receivermailaddr",POM_enquiry_like,"aunique_value_id20");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_33",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceiverFax ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id21", 1,&Keyword_ReceiverFax, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_34",pcClassName,"t8_receiverfax",POM_enquiry_like,"aunique_value_id21");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_34",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingLocation ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id22", 1,&Keyword_ReceivingLocation, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_35",pcClassName,"t8_receivinglocation",POM_enquiry_like,"aunique_value_id22");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_35",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingPostalCode ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id23", 1,&Keyword_ReceivingPostalCode, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_36",pcClassName,"t8_receiverpostalcode",POM_enquiry_like,"aunique_value_id23");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_36",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceivingStreet ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id24", 1,&Keyword_ReceivingStreet, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_37",pcClassName,"t8_receivingstreet",POM_enquiry_like,"aunique_value_id24");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_37",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderContactNum ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id25", 1,&Keyword_SenderContactNum, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_38",pcClassName,"t8_sendercontactnum",POM_enquiry_like,"aunique_value_id25");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_38",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderDept ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id26", 1,&Keyword_SenderDept, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_39",pcClassName,"t8_senderdept",POM_enquiry_like,"aunique_value_id26");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_39",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderFax ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id27", 1,&Keyword_SenderFax, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_40",pcClassName,"t8_senderfax",POM_enquiry_like,"aunique_value_id27");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_40",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SenderPostalcode ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id28", 1,&Keyword_SenderPostalcode, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_41",pcClassName,"t8_senderspostalcode",POM_enquiry_like,"aunique_value_id28");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_41",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SendingLocation ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id29", 1,&Keyword_SendingLocation, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_42",pcClassName,"t8_sendinglocation",POM_enquiry_like,"aunique_value_id29");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_42",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_SendingStreet ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id30", 1,&Keyword_SendingStreet, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_43",pcClassName,"t8_sendingstreet",POM_enquiry_like,"aunique_value_id30");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_43",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_ReceiverContactNum ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id31", 1,&Keyword_ReceiverContactNum, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_431",pcClassName,"t8_receivercontactnum",POM_enquiry_like,"aunique_value_id31");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_431",POM_case_insensitive);
	 }
	 
	 /*adding attributes to the search query (ER#7855)*/
	 if (strcmp (Keyword_Action ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id32", 1,&Keyword_Action, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_432",pcClassName,"t8_action",POM_enquiry_like,"aunique_value_id32");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_432",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_DocumentDesc ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id33", 1,&Keyword_DocumentDesc, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_433",pcClassName,"t8_documentdescription",POM_enquiry_like,"aunique_value_id33");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_433",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_DocumentNum ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id34", 1,&Keyword_DocumentNum, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_434",pcClassName,"t8_documentnumber",POM_enquiry_like,"aunique_value_id34");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_434",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_Information,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id35", 1,&Keyword_Information, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_435",pcClassName,"t8_information",POM_enquiry_like,"aunique_value_id35");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_435",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_PartNum ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id36", 1,&Keyword_PartNum, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_436",pcClassName,"t8_partnumber",POM_enquiry_like,"aunique_value_id36");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_436",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_PartRev ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id37", 1,&Keyword_PartRev, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_437",pcClassName,"t8_partrevision",POM_enquiry_like,"aunique_value_id37");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_437",POM_case_insensitive);
	 }

	 if (strcmp (Keyword_State ,"") != 0)
	 {
		ifail = POM_enquiry_set_string_value ("findpartnersubmissiondocument", "aunique_value_id38", 1,&Keyword_State, POM_enquiry_bind_value );
		ifail = POM_enquiry_set_attr_expr ("findpartnersubmissiondocument","auniqueExprId_438",pcClassName,"t8_state",POM_enquiry_like,"aunique_value_id38");
			if(ifail == ITK_ok)
				ifail = POM_enquiry_set_expr_proprety ("findpartnersubmissiondocument","auniqueExprId_438",POM_case_insensitive);
	 }

	 
//===============================================================================================
                                          //join the main expression 
//===============================================================================================
	if (strcmp (Keyword_DocumentID ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_44","auniqueExprId_13",POM_enquiry_and,"auniqueExprId_14");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_44","auniqueExprId_13",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_RevisionID ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and,"auniqueExprId_15");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_45","auniqueExprId_44",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_Name ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and,"auniqueExprId_16");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_46","auniqueExprId_45",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_DocumentType ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and,"auniqueExprId_17");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_CAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and,"auniqueExprId_18");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_CBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and,"auniqueExprId_19");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_MAD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and,"auniqueExprId_20");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_MBD ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and,"auniqueExprId_21");
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and,"auniqueExprId_1");
	}


 
    if (strcmp (Keyword_PdeJobNumber ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and,"auniqueExprId_22");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SendingCompanyName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and,"auniqueExprId_23");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SendingCountry ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and,"auniqueExprId_24");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SendingCity ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and,"auniqueExprId_25");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and,"auniqueExprId_26");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderEmailAddr ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and,"auniqueExprId_27");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingCompanyName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and,"auniqueExprId_28");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingCountry ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and,"auniqueExprId_29");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingCity ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and,"auniqueExprId_30");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceiverName ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and,"auniqueExprId_31");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceiverDept ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and,"auniqueExprId_32");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceiverMailAddr ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and,"auniqueExprId_33");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceiverFax ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and,"auniqueExprId_34");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingLocation ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and,"auniqueExprId_35");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingPostalCode ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and,"auniqueExprId_36");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceivingStreet ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and,"auniqueExprId_37");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderContactNum ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and,"auniqueExprId_38");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderDept ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and,"auniqueExprId_39");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderFax ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and,"auniqueExprId_40");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SenderPostalcode ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and,"auniqueExprId_41");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SendingLocation ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and,"auniqueExprId_42");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_SendingStreet ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and,"auniqueExprId_43");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_ReceiverContactNum ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and,"auniqueExprId_431");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and,"auniqueExprId_1");
	}

	/*join the expressions to main expression (ER#7855)*/

	if (strcmp (Keyword_Action ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and,"auniqueExprId_432");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_DocumentDesc ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and,"auniqueExprId_433");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_DocumentNum ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and,"auniqueExprId_434");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_Information ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and,"auniqueExprId_435");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_PartNum ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_79","auniqueExprId_78",POM_enquiry_and,"auniqueExprId_436");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_79","auniqueExprId_78",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_PartRev ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_80","auniqueExprId_79",POM_enquiry_and,"auniqueExprId_437");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_80","auniqueExprId_79",POM_enquiry_and,"auniqueExprId_1");
	}

	if (strcmp (Keyword_State ,"") != 0)
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_81","auniqueExprId_80",POM_enquiry_and,"auniqueExprId_438");
		
	}
	else
	{
		ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_81","auniqueExprId_80",POM_enquiry_and,"auniqueExprId_1");
	}




	//ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and,"auniqueExprId_99");
	ifail = POM_enquiry_set_expr("findpartnersubmissiondocument","auniqueExprId_82","auniqueExprId_81",POM_enquiry_and,"auniqueExprId_99");
	
	//set where expression
	ifail = POM_enquiry_set_where_expr("findpartnersubmissiondocument","auniqueExprId_82");
	//set distinct vale
	//ifail = POM_enquiry_set_distinct("findpartnersubmissiondocument", true);
	//execute the wuery
	ifail = POM_enquiry_execute ("findpartnersubmissiondocument",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("findpartnersubmissiondocument");
    if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tItemRev = *(tag_t *)report[i][0];
			(*foundTags)[i] = tItemRev;
		}
		MEM_free(report);
	}	

	return ifail;
	
}