/*******************************************************************************************************************
File         : tiauto_find_change_rev.c

Description  : These are functions related to the user query - " TI Change Rev"
			   This function will search for Change Rev objects.

Input				: None

Output				: None

Author				: TCS

Revision History	:
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
19 Nov 2015		1.0			Pradeep				Initial Creation    
26 Jun 2016     1.1         Pradeep             Updated code to implement logic for 
												NEW_CAP, NEW_CCR, NEW_PMR and STD forms, also included new property "ProductGroup".
Nov 23,2018		1.2		    Jugunu          Updated for ER 9759 CAP3
******************************************************************************************************************/
#include <tiauto_find_change.h>

/*=============================================================================================================
*		TIAUTO_find_Change_affected_programs(const char *name, int num_args, char **names, char **values,
                                              int *num_found, tag_t **found /*<OF num_found>
*return int				
* Description:
*			Implements the the logic for the "Change Affected programs" user query.
================================================================================================================*/
extern int find_change_rev (const char* pcChangeID,const char* pcChangeRev,const char* pcChangeName,const char* pcObjDesc,const char* pcCAD,const char* pcCBD,const char* pcMAD,
						const char* pcMBD,const char* pcOwningUser,const char* pcOwningGroup, const char* pcOwningSite, const char* pcLastModUser,
						const char* pcReleaseStatus,const char* pcCurrentTask,const char* pcAffPgms,const char* pcTIDiv,const char* pcProductGroup,const char* pcAffPlant,
						const char* pcTIChangeDesc,const char* pcChangeDriver,const char* pcTargetReleaseStatus,const char* pcReqGroup,
						const char* pcCustTrackingNum,const char* pcSuppTrackingNum,const char* pcIsProdImpacted,const char* pcSuggChangeImpDateAfter,const char* pcSuggChangeImpDateBefore,
						const char* pcDesignWorkReq,const char* pcLevelOfReq,const char* pcMaterialImpacted,const char* pcTypeOfChange,
						const char* pcBillableCompType,const char* pcBillableComp,const char* pcCustAuthNum,const char* pcCustName,
						const char* pcCustNameType,const char* pcCustAppReq,const char* pcRFQIssuedAfter,const char* pcRFQIssuedBefore,const char* pcNewBusiness,
						const char* pcIsEnggAppReq,const char* pcDesignValReq,const char* pcInventoryStatus,const char* pcPMRReason,
						char* pcForm,
						int *iNumFound,tag_t **foundTags)
{
	int				iFail = ITK_ok;
	const char		*select_attr_list1[] = {"puid"};
	const char		*pcRelationTypeName = "IMAN_specification";
	const char		*pcItemType[] = {"EngChange","T8_TI_Change"};
	int				iRows		= 0;
	int				i			= 0;
	int				iCols		= 0;
	void			***paReport;
	tag_t			tChItem	= NULLTAG;
	date_t dCAD,dCBD,dMAD,dMBD, dSuggChangeImpDateAfter,dSuggChangeImpDateBefore,dRFQIssuedAfter,dRFQIssuedBefore=NULLDATE;
	//char	*pcForm = "T8_t1a120CAP";
	char	*pcFormAttr_AffPgms						= NULL;
	char	*pcFormAttr_Div							= NULL;
	char	*pcFormAttr_ProductGroup				= NULL;
	char	*pcFormAttr_AffPlant					= NULL;
	char	*pcFormAttr_ChangeDesc					= NULL;
	char	*pcFormAttr_ChangeDriver				= NULL;
	char	*pcFormAttr_TargetReleaseStatus			= NULL;
	char	*pcFormAttr_ReqGroup					= NULL;
	char	*pcFormAttr_CustTrackingNum				= NULL;
	char	*pcFormAttr_SuppTrackingNum				= NULL;
	char	*pcFormAttr_IsProdImpacted				= NULL;
	char	*pcFormAttr_SuggChangeImpDate			= NULL;
	char	*pcFormAttr_DesignWorkReq				= NULL;
	char	*pcFormAttr_LevelOfReq					= NULL;
	char	*pcFormAttr_MaterialImpacted			= NULL;
	char	*pcFormAttr_TypeOfChange				= NULL;
	char	*pcFormAttr_BillableCompType			= NULL;
	char	*pcFormAttr_BillableComp				= NULL;
	char	*pcFormAttr_CustAuthNum					= NULL;
	char	*pcFormAttr_CustName					= NULL;
	char	*pcFormAttr_CustNameType				= NULL;
	char	*pcFormAttr_CustAppReq					= NULL;
	char	*pcFormAttr_RFQIssued					= NULL;
	char	*pcFormAttr_NewBusiness					= NULL;
	char	*pcFormAttr_IsEnggAppReq				= NULL;
	char	*pcFormAttr_DesignValReq				= NULL;
	char	*pcFormAttr_InventoryStatus				= NULL;
	char	*pcFormAttr_PMRReason					= NULL;
	
	logical isCAP = false;
	logical isCCR = false;
	logical isNewECR = false;
	logical isPurchasedPart = false;
	logical isCRO = false;
	logical isOBS = false;
	logical isPMR = false;
	logical isOldECR = false;
	logical isCRBypass = false;
	logical isDEV = false;
	logical isPCI = false;
	logical isCAP2 = false;
	logical isCAP3 = false;
	logical isCCR2 = false;
	logical isPMR2 = false;
	logical isSTD = false;

	char acFormClassName[64] = "";
	//Manage attributes...
	//if (tc_strcmp(pcForm,"t8_t1a120cap") == 0)
	if (tc_strcasecmp(pcForm,"cap") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a120affectedprograms";
		pcFormAttr_Div								= "t8_120tidivisions";
		pcFormAttr_ProductGroup						= "t8_120productgroup";
		pcFormAttr_AffPlant							= "t8_120tiplant";
		pcFormAttr_ChangeDesc						= "t8_t1a120changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a120changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a120targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a120requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a120custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a120suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a120isproductimacted";		
		pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t1a41billablecompanytype";
		pcFormAttr_BillableComp						= "t1a41billablecompany";
		pcFormAttr_CustAppReq						= "t1a41customerapprovalreq";
		pcFormAttr_CustAuthNum						= "t1a41customerauthno";
		pcFormAttr_CustName							= "t1a41customername";
		pcFormAttr_CustNameType						= "t1a41customernametype";
		pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}
	if (tc_strcasecmp(pcForm,"cap2") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t8_t1a191billablecompanytyp";
		pcFormAttr_BillableComp						= "t8_t1a191billablecompany";
		pcFormAttr_CustAppReq						= "t8_t1a191customerapprovalre";
		pcFormAttr_CustAuthNum						= "t8_t1a191customerauthno";
		//pcFormAttr_CustName							= "t8_t1a191customername";
		//pcFormAttr_CustNameType						= "t8_t1a191customernametype";
		//pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR2 = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP2 = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}
	if (tc_strcasecmp(pcForm,"cap3") == 0)
	{
		pcFormAttr_AffPgms							= "t8_t1a190affectedprograms";
		pcFormAttr_Div								= "t8_t1a190tidivision";
		pcFormAttr_ProductGroup						= "t8_t1a190productgroup";
		pcFormAttr_AffPlant							= "t8_t1a190affectedplants";
		pcFormAttr_ChangeDesc						= "t8_t1a190changedescription";	
		pcFormAttr_ChangeDriver						= "t8_t1a190changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_t1a190targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_t1a190requestinggroup";	
		pcFormAttr_CustTrackingNum					= "t8_t1a190custtrackingnum";		
		pcFormAttr_SuppTrackingNum					= "t8_t1a190suppltrackingnum";		
		pcFormAttr_IsProdImpacted					= "t8_t1a190isproductimacted";		
		//pcFormAttr_SuggChangeImpDate				= "t8_t1a120sugchangeimpldate";		

		pcFormAttr_BillableCompType					= "t8_t1a191billablecompanytyp";
		pcFormAttr_BillableComp						= "t8_t1a191billablecompany";
		pcFormAttr_CustAppReq						= "t8_t1a191customerapprovalre";
		pcFormAttr_CustAuthNum						= "t8_t1a191customerauthno";
		//pcFormAttr_CustName							= "t8_t1a191customername";
		//pcFormAttr_CustNameType						= "t8_t1a191customernametype";
		//pcFormAttr_RFQIssued						= "t1a41rfqissued";

		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";
		
		if((tc_strcmp(pcBillableCompType,"") != 0) || (tc_strcmp(pcBillableComp,"") != 0) || (tc_strcmp(pcCustAuthNum,"") != 0)|| (tc_strcmp(pcCustName,"") != 0)
			|| (tc_strcmp(pcCustNameType,"") != 0)|| (tc_strcmp(pcRFQIssuedAfter,"") != 0) || (tc_strcmp(pcRFQIssuedBefore,"") != 0) || (tc_strcmp(pcCustAppReq,"") != 0))
		{
			isCCR2 = true;
		}
		if((tc_strcmp(pcAffPgms,"") != 0) || (tc_strcmp(pcTIDiv,"") != 0) || (tc_strcmp(pcProductGroup,"") != 0) || (tc_strcmp(pcAffPlant,"") != 0)|| (tc_strcmp(pcTIChangeDesc,"") != 0)
			|| (tc_strcmp(pcChangeDriver,"") != 0) || (tc_strcmp(pcTargetReleaseStatus,"") != 0)|| (tc_strcmp(pcReqGroup,"") != 0) 
			|| (tc_strcmp(pcCustTrackingNum,"") != 0) || (tc_strcmp(pcSuppTrackingNum,"") != 0) || (tc_strcmp(pcIsProdImpacted,"") != 0) || (tc_strcmp(pcSuggChangeImpDateAfter,"") != 0) || (tc_strcmp(pcSuggChangeImpDateBefore,"") != 0) )
		{
			isCAP3 = true;
				
		}
		if((tc_strcmp(pcDesignWorkReq,"") != 0) || (tc_strcmp(pcLevelOfReq,"") != 0) || (tc_strcmp(pcMaterialImpacted,"") != 0)|| (tc_strcmp(pcTypeOfChange,"") != 0))
		{
			isNewECR = true;
		}
	}
	if (tc_strcasecmp(pcForm,"pmr") == 0)
	{
		pcFormAttr_AffPgms							= "t1A84affectedprogram";
		pcFormAttr_Div								= "t8_84tidivisions";
		pcFormAttr_ProductGroup						= "t8_84productgroup";
		pcFormAttr_AffPlant							= "t8_84tiplant";
		pcFormAttr_ChangeDesc						= "t1a84changedescription";	
		pcFormAttr_ChangeDriver						= "t1a84changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t1a84targetreleasestate";	
		pcFormAttr_ReqGroup							= "t1a84requestinggroup";
		pcFormAttr_SuppTrackingNum					= "t1a84suppliertrackingnum";
		pcFormAttr_LevelOfReq						= "t1a84levelofrequest";
		pcFormAttr_TypeOfChange						= "t1a84typeofchange";
		pcFormAttr_BillableCompType					= "t1a84billablecompanytype";
		pcFormAttr_BillableComp						= "t1a84billablecompany";    
		pcFormAttr_CustAuthNum						= "t1a84customerauthno"; 
		pcFormAttr_CustName							= "t1a84customername";     
		pcFormAttr_CustNameType						= "t1a84customernametype"; 
		pcFormAttr_RFQIssued						= "t1a84rfqissued";
		pcFormAttr_PMRReason						= "t8_84pmrreason";

		isPMR = true;
		
	}
	if (tc_strcasecmp(pcForm,"pmr2") == 0)
	{
		pcFormAttr_AffPgms							= "t8_193affectedprogram";
		pcFormAttr_Div								= "t8_193tidivision";
		pcFormAttr_ProductGroup						= "t8_193productgroup";
		pcFormAttr_AffPlant							= "t8_193tiplant";
		pcFormAttr_ChangeDesc						= "t8_193changedescription";	
		pcFormAttr_ChangeDriver						= "t8_193changedriver";	
		pcFormAttr_TargetReleaseStatus				= "t8_193targetreleasestate";	
		pcFormAttr_ReqGroup							= "t8_193requestinggroup";
		pcFormAttr_SuppTrackingNum					= "t8_193suppliertrackingnum";
		pcFormAttr_LevelOfReq						= "t8_193levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_193typeofchange";
		pcFormAttr_BillableCompType					= "t8_193billablecompanytype";
		pcFormAttr_BillableComp						= "t8_193billablecompany";    
		pcFormAttr_CustAuthNum						= "t8_193customerauthno"; 
		//pcFormAttr_CustName							= "t8_193customername";     
		//pcFormAttr_CustNameType						= "t8_193customernametype"; 
		//pcFormAttr_RFQIssued						= "t1a84rfqissued";
		pcFormAttr_PMRReason						= "t8_193pmrreason";

		isPMR2 = true;	
	}
	/*
	if (tc_strcmp(pcForm,"t1a40ecr") == 0)
	{
		pcFormAttr_AffPgms							= "t1a40affectedprograms";
		pcFormAttr_ChangeDesc						= "t1a40changedescription";
		pcFormAttr_TargetReleaseStatus				= "t1a40targetreleasestate";
		pcFormAttr_LevelOfReq						= "t1a40levelofrequest";
		pcFormAttr_TypeOfChange						= "t1a40typeofchange";
		pcFormAttr_DesignWorkReq					= "t1a40designworkrequired";
		pcFormAttr_DesignValReq						= "t1a40designvalidationreq";
	}*/
	/*if (tc_strcmp(pcForm,"t1a37CI") == 0)
	{
		pcFormAttr_AffPgms							= "t1a37affectedprograms";   
		pcFormAttr_ChangeDesc						= "t1a37changedescription";  
		pcFormAttr_ChangeDriver						= "t1a37changedriver";       
		pcFormAttr_CustTrackingNum					= "t1a37customertrackingnum";
		pcFormAttr_NewBusiness						= "t1a37newbusiness";       
		pcFormAttr_ReqGroup							= "t1a37requestinggroup";  
		pcFormAttr_SuggChangeImpDate				= "t1a37suggestedchangeimpl";
		pcFormAttr_SuppTrackingNum					= "t1a37suppliertrackingnum";
	}*/
	if (tc_strcasecmp(pcForm,"obs") == 0)
	{
		pcFormAttr_AffPgms							= "t1a52affectedprograms";
		pcFormAttr_ChangeDriver						= "t1a52changedriver";    
		pcFormAttr_ChangeDesc						= "t1a52description";     
		pcFormAttr_InventoryStatus					= "t1a52inventorystatus"; 
		pcFormAttr_ReqGroup							= "t1a52requestinggroup";

		isOBS = true;
	}
	if (tc_strcasecmp(pcForm,"dev") == 0)
	{
		pcFormAttr_AffPgms							= "t1a51affectedprograms"; 
		pcFormAttr_ChangeDriver						= "t1a51changedriver"; 
		pcFormAttr_ReqGroup							= "t1a51requestinggroup"; 
		pcFormAttr_CustTrackingNum					= "t1a51customertrackingnum"; 
		pcFormAttr_SuppTrackingNum					= "t1a51suppliertrackingnum"; 
		pcFormAttr_BillableCompType					= "t1a51billablecompanytype"; 
		pcFormAttr_BillableComp						= "t1a51billablecompany";

		isDEV = true;
	}
	/*if (tc_strcmp(pcForm,"t1a41CCR") == 0)
	{
		pcFormAttr_BillableCompType					= "t1a41billablecompanytype";
		pcFormAttr_BillableComp						= "t1a41billablecompany";
		pcFormAttr_CustAppReq						= "t1a41customerapprovalreq";
		pcFormAttr_CustAuthNum						= "t1a41customerauthno";
		pcFormAttr_CustName							= "t1a41customername";
		pcFormAttr_CustNameType						= "t1a41customernametype";
		pcFormAttr_RFQIssued						= "t1a41rfqissued";
	}*/
	/*if (tc_strcmp(pcForm,"t8_t1a133ecr") == 0)
	{
		pcFormAttr_DesignWorkReq					= "t8_t1a133designworkrequired";
		pcFormAttr_LevelOfReq						= "t8_t1a133levelofrequest";
		pcFormAttr_TypeOfChange						= "t8_t1a133typeofchange";
		pcFormAttr_MaterialImpacted					= "t8_t1a133materialimpacted";
	}*/
	if (tc_strcasecmp(pcForm,"pci") == 0)
	{
		pcFormAttr_AffPgms							= "t8_123affectedprograms";
		pcFormAttr_AffPlant							= "t8_t1a123affectedplant";

		isPCI = true;
	}
	if (tc_strcasecmp(pcForm,"cro") == 0)
	{
		pcFormAttr_AffPgms							= "t8_146affectedprograms";    
		pcFormAttr_Div								= "t8_146tidivisions";   
		pcFormAttr_ProductGroup						= "t8_146productgroup";
		pcFormAttr_ChangeDesc						= "t8_146changedescription";    
		pcFormAttr_IsEnggAppReq						= "t8_t1a146isengapprvrequired";

		isCRO = true;
	}
	if (tc_strcasecmp(pcForm,"std") == 0)
	{  
		pcFormAttr_Div								= "t8_189tidivision";   
		pcFormAttr_ProductGroup						= "t8_189productgroup";
		pcFormAttr_ChangeDesc						= "t8_189changedesc";    
		pcFormAttr_ChangeDriver						= "t8_189changedriver";
		pcFormAttr_TargetReleaseStatus				= "t8_189targetreleasestate";  

		isSTD = true;
	}

	//Create the main query
	iFail = POM_enquiry_create ("Find_change");

	//select output attribute for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_add_select_attrs ("Find_change", "ItemRevision", 1, select_attr_list1));
	
	//craete alias
	TIAUTO_ITKCALL(iFail, POM_enquiry_create_class_alias ("Find_change", "user", 1, "user_alias"));	
	
	//start query expression for main query
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_1","Item","puid",POM_enquiry_equal,"itemrevision","items_tag"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_2","itemrevision","puid",POM_enquiry_equal,"ImanRelation","primary_object"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_3","ImanRelation","secondary_object",POM_enquiry_equal,"Form","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_4","Item","puid",POM_enquiry_equal,"WorkspaceObject","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_5","WorkspaceObject","puid",POM_enquiry_equal,"Pom_application_object","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_6","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));

	/*Filter for EngChange items only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id1", 2, pcItemType, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_7", "WorkspaceObject","object_type",POM_enquiry_in ,"aunique_value_id1" ));

	/*Filter for Secondary object Relation Type i,e(IMAN_specification) only*/
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_8","ImanRelation","relation_type",POM_enquiry_equal,"imantype","puid"));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id2", 1, &pcRelationTypeName, POM_enquiry_bind_value ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_9", "imantype","type_name",POM_enquiry_equal ,"aunique_value_id2" ));

	/*if ( (strcmp (pcAffPgms ,"") != 0) || (strcmp (pcTIDiv ,"") != 0) || (strcmp (pcAffPlant ,"") != 0) || (strcmp (pcTIChangeDesc ,"") != 0) ||
		 (strcmp (pcChangeDriver ,"") != 0)  || (strcmp (pcTargetReleaseStatus ,"") != 0)  || (strcmp (pcReqGroup ,"") != 0) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_10","Form","data_file",POM_enquiry_equal,pcForm,"puid"));
	}*/

	/*Change ID*/
	if (tc_strcmp(pcChangeID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id3", 1, &pcChangeID, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_10","Item", "item_id",POM_enquiry_like,"aunique_value_id3"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_10",POM_case_insensitive));
	}
	/*Change Name*/
	if (strcmp (pcChangeName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id4", 1,&pcChangeName, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change","auniqueExprId_11","WorkspaceObject","object_name",POM_enquiry_like,"aunique_value_id4"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_11",POM_case_insensitive));
	}
	/*Object Desc*/
	if (strcmp (pcObjDesc ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id5", 1,&pcObjDesc, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change","auniqueExprId_12","WorkspaceObject","object_desc",POM_enquiry_like,"aunique_value_id5"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_12",POM_case_insensitive));
	}
	/*Created after date*/		
	if (strcmp (pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCAD, &dCAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id6", 1, &dCAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_13","Pom_application_object","creation_date",POM_enquiry_greater_than_or_eq,"aunique_value_id6"));	
	}
	/*Created before date*/
	if (strcmp (pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcCBD, &dCBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id7", 1, &dCBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_14","Pom_application_object","creation_date",POM_enquiry_less_than_or_eq,"aunique_value_id7"));
	}	
	/*Modified after date*/
	if (strcmp (pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMAD, &dMAD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id8", 1, &dMAD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_15","Pom_application_object","last_mod_date",POM_enquiry_greater_than_or_eq,"aunique_value_id8"));
	}
	/*Modified before date*/
	if (strcmp (pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcMBD, &dMBD));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id9", 1, &dMBD, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_16","Pom_application_object","last_mod_date",POM_enquiry_less_than_or_eq,"aunique_value_id9"));
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_17","Pom_application_object","owning_user",POM_enquiry_equal,"user","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id10", 1, &pcOwningUser, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_18", "user","os_username",POM_enquiry_like ,"aunique_value_id10" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_19","Pom_application_object","owning_group",POM_enquiry_equal,"pom_group","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id11", 1, &pcOwningGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_20", "pom_group","name",POM_enquiry_like ,"aunique_value_id11" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		/*If Owning site & Logged in site are same*/
		if (strcmp (pcOwningSite ,"Local") == 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_21","Pom_application_object","puid",POM_enquiry_equal,"pom_object","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22","pom_object","owning_site",POM_enquiry_is_null, NULL  ));
		}
		else
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_21","pom_object","owning_site",POM_enquiry_equal, "pom_imc", "puid"  ));		
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id12", 1, &pcOwningSite, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_22", "pom_imc","name",POM_enquiry_like ,"aunique_value_id12" ));
		}
	}
	/*last modified user*/
	if (strcmp (pcLastModUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_23","Pom_application_object","last_mod_user",POM_enquiry_equal,"user_alias","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id13", 1, &pcLastModUser, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_24", "user_alias","os_username",POM_enquiry_like ,"aunique_value_id13" ));	
	}
	/*Release status*/
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_25","itemrevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id14", 1, &pcReleaseStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_26", "ReleaseStatus", "name",POM_enquiry_like ,"aunique_value_id14" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_27","itemrevision","process_stage_list",POM_enquiry_equal,"epmtask","puid"));	
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_28","epmtask","task_template",POM_enquiry_equal,"epmtasktemplate","puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id15", 1, &pcCurrentTask, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_29", "epmtasktemplate", "template_name",POM_enquiry_like ,"aunique_value_id15"));
	}
	/*Affected Program*/
	if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
	{
		tc_strcpy(acFormClassName,"");

		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		//create pseudo class alias
		if(tc_strcmp (acFormClassName ,"") != 0)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acFormClassName, pcFormAttr_AffPgms,"class_affected")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_30","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_31",acFormClassName,"puid",POM_enquiry_equal,"class_affected","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id16", 1, &pcAffPgms, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_32", "class_affected","pval",POM_enquiry_equal ,"aunique_value_id16" ));
		}
	}
	/*TI Division*/
	if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isSTD)
		{
			tc_strcpy(acFormClassName,"T8_t1a189standard");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_33","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id17", 1, &pcTIDiv, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_34", acFormClassName, pcFormAttr_Div,POM_enquiry_like ,"aunique_value_id17" ));
	}
	/*Affected Plant*/
	if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}

		if(isPCI)
		{
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_35","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_36","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcAffPlant, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_37", acFormClassName,pcFormAttr_AffPlant,POM_enquiry_like ,"aunique_value_id18"));
		}
		else
		{
			//create pseudo class alias
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_pseudo_calias( "Find_change", acFormClassName, pcFormAttr_AffPlant,"class_plant")); 

			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_35","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_36",acFormClassName,"puid",POM_enquiry_equal,"class_plant","puid"));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id18", 1, &pcAffPlant, POM_enquiry_bind_value ));
			TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_37", "class_plant","pval",POM_enquiry_equal ,"aunique_value_id18" ));
		}
	}
	/*TI Change Description*/
	if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isSTD)
		{
			tc_strcpy(acFormClassName,"T8_t1a189standard");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_38","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id19", 1, &pcTIChangeDesc, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_39", acFormClassName, pcFormAttr_ChangeDesc,POM_enquiry_like ,"aunique_value_id19" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr_proprety ("Find_change","auniqueExprId_39",POM_case_insensitive));
	}
	/*Change Driver*/
	if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
	{	
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isSTD)
		{
			tc_strcpy(acFormClassName,"T8_t1a189standard");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_40","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id20", 1, &pcChangeDriver, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_41", acFormClassName, pcFormAttr_ChangeDriver,POM_enquiry_like ,"aunique_value_id20" ));
	}
	/*Target Release Status*/
	if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isSTD)
		{
			tc_strcpy(acFormClassName,"T8_t1a189standard");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_42","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id21", 1, &pcTargetReleaseStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_43", acFormClassName, pcFormAttr_TargetReleaseStatus,POM_enquiry_like ,"aunique_value_id21" ));
	}
	/*Requesting Group*/
	if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_44","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id22", 1, &pcReqGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_45", acFormClassName, pcFormAttr_ReqGroup,POM_enquiry_like ,"aunique_value_id22" ));
	}

	/*Customer Tracking Number*/
	if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_90","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id23", 1, &pcCustTrackingNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_91", acFormClassName, pcFormAttr_CustTrackingNum,POM_enquiry_like ,"aunique_value_id23" ));
	}
	/*Supplier Tracking Number*/
	if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_92","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id24", 1, &pcSuppTrackingNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_93", acFormClassName, pcFormAttr_SuppTrackingNum,POM_enquiry_like ,"aunique_value_id24" ));
	}
	/*Is Product Impacted*/
	if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_94","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id25", 1, &pcIsProdImpacted, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_95", acFormClassName, pcFormAttr_IsProdImpacted,POM_enquiry_like ,"aunique_value_id25" ));
	}
	/*Suggested Change Implementation Date After*/
	if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateAfter, &dSuggChangeImpDateAfter));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_96","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id26", 1, &dSuggChangeImpDateAfter, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_97", acFormClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_greater_than_or_eq ,"aunique_value_id26" ));
	}
	/*Design Work Required*/
	if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isNewECR)
		{
			tc_strcpy(acFormClassName,"t8_t1a133ecr");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_98","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id27", 1, &pcDesignWorkReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_99", acFormClassName, pcFormAttr_DesignWorkReq,POM_enquiry_like ,"aunique_value_id27" ));
	}
	/*Level of Request*/
	if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isNewECR)
		{
			tc_strcpy(acFormClassName,"t8_t1a133ecr");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_100","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id28", 1, &pcLevelOfReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_101", acFormClassName, pcFormAttr_LevelOfReq,POM_enquiry_like ,"aunique_value_id28" ));
	}
	/*Material Impacted*/
	if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isNewECR)
		{
			tc_strcpy(acFormClassName,"t8_t1a133ecr");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_102","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id29", 1, &pcMaterialImpacted, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_103", acFormClassName, pcFormAttr_MaterialImpacted,POM_enquiry_like ,"aunique_value_id29" ));
	}
	/*Type of Change*/
	if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isNewECR)
		{
			tc_strcpy(acFormClassName,"t8_t1a133ecr");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_104","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id30", 1, &pcTypeOfChange, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_105", acFormClassName, pcFormAttr_TypeOfChange,POM_enquiry_like ,"aunique_value_id30" ));
	}
	/*Billable Company Type*/
	if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_106","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id31", 1, &pcBillableCompType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_107", acFormClassName, pcFormAttr_BillableCompType,POM_enquiry_like ,"aunique_value_id31" ));
	}
	/*Billable Company*/
	if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_108","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id32", 1, &pcBillableComp, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_109", acFormClassName, pcFormAttr_BillableComp,POM_enquiry_like ,"aunique_value_id32" ));
	}
	/*Customer Authorization Number*/
	if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_110","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id33", 1, &pcCustAuthNum, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_111", acFormClassName, pcFormAttr_CustAuthNum,POM_enquiry_like ,"aunique_value_id33" ));
	}
	/*Customer Name*/
	if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_112","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id34", 1, &pcCustName, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_113", acFormClassName, pcFormAttr_CustName,POM_enquiry_like ,"aunique_value_id34" ));
	}
	/*Customer Name Type*/
	if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_114","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id35", 1, &pcCustNameType, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_115", acFormClassName, pcFormAttr_CustNameType,POM_enquiry_like ,"aunique_value_id35" ));
	}
	/*Customer Approval Required*/
	if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_116","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id36", 1, &pcCustAppReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_117", acFormClassName, pcFormAttr_CustAppReq,POM_enquiry_like ,"aunique_value_id36" ));
	}
	/*RFQ Issued After*/
	if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedAfter, &dRFQIssuedAfter));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_118","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id37", 1, &dRFQIssuedAfter, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_119", acFormClassName, pcFormAttr_RFQIssued,POM_enquiry_greater_than_or_eq ,"aunique_value_id37" ));
	}
	/*New Business*/
	if ( (strcmp (pcNewBusiness ,"") != 0) && (pcFormAttr_NewBusiness != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_120","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id38", 1, &pcNewBusiness, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_121", acFormClassName, pcFormAttr_NewBusiness,POM_enquiry_like ,"aunique_value_id38" ));
	}
	/*Is Engineering Approval Required*/
	if ( (strcmp (pcIsEnggAppReq ,"") != 0) && (pcFormAttr_IsEnggAppReq != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_122","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id39", 1, &pcIsEnggAppReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_123", acFormClassName, pcFormAttr_IsEnggAppReq,POM_enquiry_like ,"aunique_value_id39" ));
	}
	/*Design Validation Required*/
	if ( (strcmp (pcDesignValReq ,"") != 0) && (pcFormAttr_DesignValReq != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isNewECR)
		{
			tc_strcpy(acFormClassName,"T8_t1a133ecr");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_124","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id40", 1, &pcDesignValReq, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_125", acFormClassName, pcFormAttr_DesignValReq,POM_enquiry_like ,"aunique_value_id40" ));
	}
	/*Inventory Status*/
	if ( (strcmp (pcInventoryStatus ,"") != 0) && (pcFormAttr_InventoryStatus != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_126","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id41", 1, &pcInventoryStatus, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_127", acFormClassName, pcFormAttr_InventoryStatus,POM_enquiry_like ,"aunique_value_id41" ));
	}
	/*PMR Reason*/
	if ( (strcmp (pcPMRReason ,"") != 0) && (pcFormAttr_PMRReason != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_128","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id42", 1, &pcPMRReason, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_129", acFormClassName, pcFormAttr_PMRReason,POM_enquiry_like ,"aunique_value_id42" ));
	}
	
	/*Suggested Change Implementation Date Before*/
	if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			//tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcSuggChangeImpDateBefore, &dSuggChangeImpDateBefore));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_170","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id43", 1, &dSuggChangeImpDateBefore, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_171", acFormClassName, pcFormAttr_SuggChangeImpDate,POM_enquiry_less_than_or_eq ,"aunique_value_id43" ));
	}
	
	/*RFQ Issued Before*/
	if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			//tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			//tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isCCR)
		{
			tc_strcpy(acFormClassName,"t1a41CCR");
		}
		if(isCCR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a191CCR2");
		}

		TIAUTO_ITKCALL(iFail, ITK_string_to_date(pcRFQIssuedBefore, &dRFQIssuedBefore));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_172","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_date_value ("Find_change", "aunique_value_id44", 1, &dRFQIssuedBefore, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_173", acFormClassName, pcFormAttr_RFQIssued,POM_enquiry_less_than_or_eq ,"aunique_value_id44" ));
	}
	/*Change Rev*/
	if (tc_strcmp(pcChangeRev ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id45", 1, &pcChangeRev, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_200","ItemRevision", "item_revision_id",POM_enquiry_like,"aunique_value_id45"));	
	}
	/*Product Group*/
	if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
	{
		tc_strcpy(acFormClassName,"");
		if(isCAP)
		{
			tc_strcpy(acFormClassName,"t8_t1a120cap");
		}
		if(isCAP2)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP2");
		}
		if(isCAP3)
		{
			tc_strcpy(acFormClassName,"T8_t1a190CAP3");
		}
		if(isPMR)
		{
			tc_strcpy(acFormClassName,"t1a84pmr");
		}
		if(isPMR2)
		{
			tc_strcpy(acFormClassName,"T8_t1a193pmr2");
		}
		if(isOBS)
		{
			//tc_strcpy(acFormClassName,"t1a52obs");
		}
		if(isDEV)
		{
			//tc_strcpy(acFormClassName,"t1a51dev");
		}
		if(isPCI)
		{
			//tc_strcpy(acFormClassName,"t8_t1a123pci");
		}
		if(isCRO)
		{
			tc_strcpy(acFormClassName,"t8_t1a146cro");
		}
		if(isSTD)
		{
			tc_strcpy(acFormClassName,"T8_t1a189standard");
		}

		TIAUTO_ITKCALL(iFail, POM_enquiry_set_join_expr ("Find_change", "auniqueExprId_201","Form","data_file",POM_enquiry_equal,acFormClassName,"puid"));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_string_value ("Find_change", "aunique_value_id46", 1, &pcProductGroup, POM_enquiry_bind_value ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_attr_expr ("Find_change", "auniqueExprId_202", acFormClassName, pcFormAttr_ProductGroup,POM_enquiry_like ,"aunique_value_id46" ));
	}

	//join the expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_46","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_47","auniqueExprId_46",POM_enquiry_and, "auniqueExprId_3" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_4" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_49","auniqueExprId_48",POM_enquiry_and, "auniqueExprId_5" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_50","auniqueExprId_49",POM_enquiry_and, "auniqueExprId_6" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_51","auniqueExprId_50",POM_enquiry_and, "auniqueExprId_7" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_52","auniqueExprId_51",POM_enquiry_and, "auniqueExprId_8" ));
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_53","auniqueExprId_52",POM_enquiry_and, "auniqueExprId_9" ));
	
	////Filter for Change form type
	//if ( (strcmp (pcAffPgms ,"") != 0) || (strcmp (pcTIDiv ,"") != 0) || (strcmp (pcAffPlant ,"") != 0) || (strcmp (pcTIChangeDesc ,"") != 0) ||
	//	 (strcmp (pcChangeDriver ,"") != 0)  || (strcmp (pcTargetReleaseStatus ,"") != 0)  || (strcmp (pcReqGroup ,"") != 0) )
	//{
	//	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_10" ));
	//}
	//else
	//{
	//	TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_48","auniqueExprId_47",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	//}
	/*Change ID*/
	if (tc_strcmp(pcChangeID ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_10" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_54","auniqueExprId_53",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Change Name*/
	if (tc_strcmp(pcChangeName ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_11" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_55","auniqueExprId_54",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Object Desc*/
	if (tc_strcmp(pcObjDesc ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_12" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_56","auniqueExprId_55",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created after date*/		
	if (tc_strcmp(pcCAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_13" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_57","auniqueExprId_56",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Created before date*/
	if (tc_strcmp(pcCBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_14" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_58","auniqueExprId_57",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified after date*/
	if (tc_strcmp(pcMAD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_15" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_59","auniqueExprId_58",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}	
	/*Modified before date*/
	if (tc_strcmp(pcMBD ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_16" ));		
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_60","auniqueExprId_59",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Owning user*/
	if (strcmp (pcOwningUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_61","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_17" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_62","auniqueExprId_61",POM_enquiry_and, "auniqueExprId_18" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_62","auniqueExprId_60",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning Group*/
	if (strcmp (pcOwningGroup ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_63","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_19" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_63",POM_enquiry_and, "auniqueExprId_20" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_64","auniqueExprId_62",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Owning site*/
	if (strcmp (pcOwningSite ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_65","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_21" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_65",POM_enquiry_and, "auniqueExprId_22" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_66","auniqueExprId_64",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*last modified user*/
	if (strcmp (pcLastModUser ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_67","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_23" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_67",POM_enquiry_and, "auniqueExprId_24" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_68","auniqueExprId_66",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Release status*/
	if (strcmp (pcReleaseStatus ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_69","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_25" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_69",POM_enquiry_and, "auniqueExprId_26" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_70","auniqueExprId_68",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Current task*/
	if (strcmp (pcCurrentTask ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_71","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_27" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_72","auniqueExprId_71",POM_enquiry_and, "auniqueExprId_28" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_73","auniqueExprId_72",POM_enquiry_and, "auniqueExprId_29" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_73","auniqueExprId_70",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Affected Programs*/
	if ( (strcmp (pcAffPgms ,"") != 0) && (pcFormAttr_AffPgms != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_74","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_30" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_75","auniqueExprId_74",POM_enquiry_and, "auniqueExprId_31" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_75",POM_enquiry_and, "auniqueExprId_32" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_76","auniqueExprId_73",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*TI Division*/
	if ( (strcmp (pcTIDiv ,"") != 0) && (pcFormAttr_Div != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_77","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_33" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_77",POM_enquiry_and, "auniqueExprId_34" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_78","auniqueExprId_76",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*TI Plant*/
	if ( (strcmp (pcAffPlant ,"") != 0) && (pcFormAttr_AffPlant != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_79","auniqueExprId_78",POM_enquiry_and, "auniqueExprId_35" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_80","auniqueExprId_79",POM_enquiry_and, "auniqueExprId_36" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_81","auniqueExprId_80",POM_enquiry_and, "auniqueExprId_37" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_81","auniqueExprId_78",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*TI Change Description*/
	if ( (strcmp (pcTIChangeDesc ,"") != 0) && (pcFormAttr_ChangeDesc != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_82","auniqueExprId_81",POM_enquiry_and, "auniqueExprId_38" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_83","auniqueExprId_82",POM_enquiry_and, "auniqueExprId_39" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_83","auniqueExprId_81",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Change Driver*/
	if ( (strcmp (pcChangeDriver ,"") != 0) && (pcFormAttr_ChangeDriver != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_84","auniqueExprId_83",POM_enquiry_and, "auniqueExprId_40" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_85","auniqueExprId_84",POM_enquiry_and, "auniqueExprId_41" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_85","auniqueExprId_83",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Target Release Status*/
	if ( (strcmp (pcTargetReleaseStatus ,"") != 0) && (pcFormAttr_TargetReleaseStatus != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_86","auniqueExprId_85",POM_enquiry_and, "auniqueExprId_42" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_87","auniqueExprId_86",POM_enquiry_and, "auniqueExprId_43" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_87","auniqueExprId_85",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Requesting Group*/
	if ( (strcmp (pcReqGroup ,"") != 0) && (pcFormAttr_ReqGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_88","auniqueExprId_87",POM_enquiry_and, "auniqueExprId_44" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_89","auniqueExprId_88",POM_enquiry_and, "auniqueExprId_45" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_89","auniqueExprId_87",POM_enquiry_and, "auniqueExprId_1" ));
	}

	/*Customer Tracking Number*/
	if ( (strcmp (pcCustTrackingNum ,"") != 0) && (pcFormAttr_CustTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_130","auniqueExprId_89",POM_enquiry_and, "auniqueExprId_90" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_131","auniqueExprId_130",POM_enquiry_and, "auniqueExprId_91" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_131","auniqueExprId_89",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Supplier Tracking Number*/
	if ( (strcmp (pcSuppTrackingNum ,"") != 0) && (pcFormAttr_SuppTrackingNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_132","auniqueExprId_131",POM_enquiry_and, "auniqueExprId_92" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_133","auniqueExprId_132",POM_enquiry_and, "auniqueExprId_93" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_133","auniqueExprId_131",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Is Product Impacted*/
	if ( (strcmp (pcIsProdImpacted ,"") != 0) && (pcFormAttr_IsProdImpacted != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_134","auniqueExprId_133",POM_enquiry_and, "auniqueExprId_94" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_135","auniqueExprId_134",POM_enquiry_and, "auniqueExprId_95" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_135","auniqueExprId_133",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Suggested Change Implementation Date After*/
	if ( (strcmp (pcSuggChangeImpDateAfter ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_136","auniqueExprId_135",POM_enquiry_and, "auniqueExprId_96" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_137","auniqueExprId_136",POM_enquiry_and, "auniqueExprId_97" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_137","auniqueExprId_135",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Design Work Required*/
	if ( (strcmp (pcDesignWorkReq ,"") != 0) && (pcFormAttr_DesignWorkReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_138","auniqueExprId_137",POM_enquiry_and, "auniqueExprId_98" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_139","auniqueExprId_138",POM_enquiry_and, "auniqueExprId_99" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_139","auniqueExprId_137",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Level of Request*/
	if ( (strcmp (pcLevelOfReq ,"") != 0) && (pcFormAttr_LevelOfReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_140","auniqueExprId_139",POM_enquiry_and, "auniqueExprId_100" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_141","auniqueExprId_140",POM_enquiry_and, "auniqueExprId_101" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_141","auniqueExprId_139",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Material Impacted*/
	if ( (strcmp (pcMaterialImpacted ,"") != 0) && (pcFormAttr_MaterialImpacted != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_142","auniqueExprId_141",POM_enquiry_and, "auniqueExprId_102" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_143","auniqueExprId_142",POM_enquiry_and, "auniqueExprId_103" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_143","auniqueExprId_141",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Type of Change*/
	if ( (strcmp (pcTypeOfChange ,"") != 0) && (pcFormAttr_TypeOfChange != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_144","auniqueExprId_143",POM_enquiry_and, "auniqueExprId_104" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_145","auniqueExprId_144",POM_enquiry_and, "auniqueExprId_105" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_145","auniqueExprId_143",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Billable Company Type*/
	if ( (strcmp (pcBillableCompType ,"") != 0) && (pcFormAttr_BillableCompType != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_146","auniqueExprId_145",POM_enquiry_and, "auniqueExprId_106" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_147","auniqueExprId_146",POM_enquiry_and, "auniqueExprId_107" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_147","auniqueExprId_145",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Billable Company*/
	if ( (strcmp (pcBillableComp ,"") != 0) && (pcFormAttr_BillableComp != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_148","auniqueExprId_147",POM_enquiry_and, "auniqueExprId_108" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_149","auniqueExprId_148",POM_enquiry_and, "auniqueExprId_109" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_149","auniqueExprId_147",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Authorization Number*/
	if ( (strcmp (pcCustAuthNum ,"") != 0) && (pcFormAttr_CustAuthNum != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_150","auniqueExprId_149",POM_enquiry_and, "auniqueExprId_110" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_151","auniqueExprId_150",POM_enquiry_and, "auniqueExprId_111" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_151","auniqueExprId_149",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Name*/
	if ( (strcmp (pcCustName ,"") != 0) && (pcFormAttr_CustName != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_152","auniqueExprId_151",POM_enquiry_and, "auniqueExprId_112" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_153","auniqueExprId_152",POM_enquiry_and, "auniqueExprId_113" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_153","auniqueExprId_151",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Name Type*/
	if ( (strcmp (pcCustNameType ,"") != 0) && (pcFormAttr_CustNameType != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_154","auniqueExprId_153",POM_enquiry_and, "auniqueExprId_114" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_155","auniqueExprId_154",POM_enquiry_and, "auniqueExprId_115" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_155","auniqueExprId_153",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Customer Approval Required*/
	if ( (strcmp (pcCustAppReq ,"") != 0) && (pcFormAttr_CustAppReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_156","auniqueExprId_155",POM_enquiry_and, "auniqueExprId_116" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_157","auniqueExprId_156",POM_enquiry_and, "auniqueExprId_117" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_157","auniqueExprId_155",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Issued After*/
	if ( (strcmp (pcRFQIssuedAfter ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_158","auniqueExprId_157",POM_enquiry_and, "auniqueExprId_118" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_159","auniqueExprId_158",POM_enquiry_and, "auniqueExprId_119" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_159","auniqueExprId_157",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*New Business*/
	if ( (strcmp (pcNewBusiness ,"") != 0) && (pcFormAttr_NewBusiness != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_160","auniqueExprId_159",POM_enquiry_and, "auniqueExprId_120" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_161","auniqueExprId_160",POM_enquiry_and, "auniqueExprId_121" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_161","auniqueExprId_159",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Is Engineering Approval Required*/
	if ( (strcmp (pcIsEnggAppReq ,"") != 0) && (pcFormAttr_IsEnggAppReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_162","auniqueExprId_161",POM_enquiry_and, "auniqueExprId_122" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_163","auniqueExprId_162",POM_enquiry_and, "auniqueExprId_123" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_163","auniqueExprId_161",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Design Validation Required*/
	if ( (strcmp (pcDesignValReq ,"") != 0) && (pcFormAttr_DesignValReq != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_164","auniqueExprId_163",POM_enquiry_and, "auniqueExprId_124" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_165","auniqueExprId_164",POM_enquiry_and, "auniqueExprId_125" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_165","auniqueExprId_163",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Inventory Status*/
	if ( (strcmp (pcInventoryStatus ,"") != 0) && (pcFormAttr_InventoryStatus != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_166","auniqueExprId_165",POM_enquiry_and, "auniqueExprId_126" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_167","auniqueExprId_166",POM_enquiry_and, "auniqueExprId_127" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_167","auniqueExprId_165",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*PMR Reason*/
	if ( (strcmp (pcPMRReason ,"") != 0) && (pcFormAttr_PMRReason != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_168","auniqueExprId_167",POM_enquiry_and, "auniqueExprId_128" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_169","auniqueExprId_168",POM_enquiry_and, "auniqueExprId_129" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_169","auniqueExprId_167",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Suggested Change Implementation Date Before*/
	if ( (strcmp (pcSuggChangeImpDateBefore ,"") != 0) && (pcFormAttr_SuggChangeImpDate != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_174","auniqueExprId_169",POM_enquiry_and, "auniqueExprId_170" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_175","auniqueExprId_174",POM_enquiry_and, "auniqueExprId_171" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_175","auniqueExprId_169",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*RFQ Issued Before*/
	if ( (strcmp (pcRFQIssuedBefore ,"") != 0) && (pcFormAttr_RFQIssued != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_176","auniqueExprId_175",POM_enquiry_and, "auniqueExprId_172" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_177","auniqueExprId_176",POM_enquiry_and, "auniqueExprId_173" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_177","auniqueExprId_175",POM_enquiry_and, "auniqueExprId_1" ));
	}
	/*Change Rev*/
	if (tc_strcmp(pcChangeRev ,"") != 0)
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_178","auniqueExprId_177",POM_enquiry_and, "auniqueExprId_200" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_178","auniqueExprId_177",POM_enquiry_and, "auniqueExprId_1" ));//dummy
	}
	/*Product Group*/
	if ( (strcmp (pcProductGroup ,"") != 0) && (pcFormAttr_ProductGroup != NULL) )
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_179","auniqueExprId_178",POM_enquiry_and, "auniqueExprId_201" ));
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_180","auniqueExprId_179",POM_enquiry_and, "auniqueExprId_202" ));
	}
	else
	{
		TIAUTO_ITKCALL(iFail, POM_enquiry_set_expr("Find_change","auniqueExprId_180","auniqueExprId_178",POM_enquiry_and, "auniqueExprId_1" ));
	}


	//set where expression
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_where_expr ("Find_change","auniqueExprId_180" ));	
	
	//set distinct value
	TIAUTO_ITKCALL(iFail, POM_enquiry_set_distinct("Find_change", true));
	
	//execute the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_execute ("Find_change",&iRows,&iCols,&paReport));
	
	//delete the query
	TIAUTO_ITKCALL(iFail, POM_enquiry_delete ("Find_change" ));
	
	//process result	
	if(iRows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(iRows * sizeof(tag_t));
		*iNumFound = iRows;
		for(i=0;i<iRows;i++)
		{
			tChItem = NULLTAG;
			tChItem = *(tag_t *)paReport[i][0];
			(*foundTags)[i] = tChItem;
		}
		SAFE_MEM_free(paReport);
	}

	return iFail;
}