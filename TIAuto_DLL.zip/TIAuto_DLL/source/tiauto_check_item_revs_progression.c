/*******************************************************************************
FILE        :   tiauto_check_item_revs_progression.c

DESCRIPTION :   This file contains the implementation for
                "TIAUTO-check-item-revs-progression" Custom Action Handler.
                This handler validates release status of the of the all item revisions
                for correct status progression. There are three different types of
                status progression checks are added in this handler. If any one check
                is failed, task will be demoted to application engieer for modifications.

                Status Progression Checks:
                � Backwards Progression -  Validates the status progression of current
                  revision of item w.r.t later revisions of the same item. Earlier
                  revision of an item will not be released to a status when a newer/later
                  version has been released to this status or higher.

                � Assembly Item Rev Progression - A check should be performed on all
                  item revisions contained in the affected and solution folder to ensure
                  that all first level components in it�s precise BOM meet one of the
                  following requirements:
                    1)	The component is included in the affected folder.
                    2)	The component is included in the solution folder.
                    3)	The component is at the target status.
                    4)	The component is at a status higher than the target status.

                � Component Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  meet one of the following requirements:
                    1)	The item revision is not yet released.
                    2)	The item revision is at a lower status than the target status.
                    3)	The item revision is already at the target status.
					

                � Generic Item Rev Progression - A check should be performed to ensure
                  that all item revisions contained in the solution and affected folders
                  that have ProAsm or ProPrt dataset and are instance items, the generic item rev
				  should meet one of the following requirements:
                    1)	The generic is included in the affected folder.
                    2)	The generic is included in the solution folder.
                    3)	The generic is at the target status.
					4)  The generic is at a status higher than the target release status.


AUTHOR      :   Srikanth Pulluri, TCS

REVISION HISTORY :

Date              Revision        Who                    Description
April 20, 2007    1.0           Srikanth Pulluri     Initial Creation
July  26, 2007    1.1           Srikanth Pulluri     Modified code for child/assembly
                                                     item same rev progression
Jan   12, 2009	  1.2		    Garima Dewangan		 Modified code for Generic Item
													 progression check and get all 
													 failure items in one error message
Feb 15, 2009	 1.3			Dipak Naik			 Modified code for allowing item revisions
													 having "Cad release Only" staus. 
March 10,2009	 1.4			Dipak Naik			 Modified the code to show both the generic
													 item revision and the Alternet id(if used)
Mar   17, 2009	 1.5		    Garima Dewangan		 Modified code for memory handling for Generic Item
													 progression check and allowing only OEM item revisions
													 to have "Cad release Only" staus as a valid status in 
													 assembly progression check.
*******************************************************************************/

/* includes */
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>


typedef struct errMessages
{
	char errMsg[TIAUTO_error_message_len + 1];
	int iRetCode;
	struct errMessages * next;
}ErrorMessages;


/* static function prototypes */
static int  check_for_assy_progression (tag_t   tEngChangeRev,
                                        STATUS_Struct_t StatusProgression,
                                        tag_t   tAffectedItem,
                                        TARGET_RELEASE_Struct_t TargetReleaseStatus,
										ErrorMessages **currErrMsg,
                                        logical *lStatus);

static int  check_for_item_rev_valid_status (tag_t  tAffectedItem,
                                             STATUS_Struct_t    StatusProgression,
                                             TARGET_RELEASE_Struct_t    TargetReleaseStatus,
											 ErrorMessages **currErrMsg,
                                             logical    *lStatus);

static int  check_for_item_same_rev_progression (tag_t  tEngChangeRev,
                                                 STATUS_Struct_t    StatusProgression,
												 ErrorMessages **currErrMsg,
                                                 logical    *lValidStatus);

static int  check_for_item_rev_backwards_progression (tag_t     tEngChangeRev,
                                                      STATUS_Struct_t   StatusProgression,
													  ErrorMessages **currErrMsg,
                                                      logical   *lValidStatus );

static int  verify_each_affected_item (tag_t    affected_item_tag,
                                       char     *szTargetReleaseStatus,
                                       STATUS_Struct_t    StatusProgression,
									   ErrorMessages **currErrMsg,
                                       logical   *lStatus);

logical isComponentPartOfAffectedItems (tag_t    tChildItem,
                                        tag_t    tEngChangeRev);

static int isComponentProEInstanceGetGeneric(tag_t    tItem,
											 logical *lProE,
											 tag_t   *genItemRevTag,
											 char	 *pcvalue);

static int  check_for_item_rev_generic_progression (tag_t     tEngChangeRev,
                                                    STATUS_Struct_t   StatusProgression,
													ErrorMessages **currErrMsg,
                                                    logical   *lValidStatus );

static void writeErrorsToAuditFile(tag_t tMsgTask);

static void writeErrorsMsgToAuditFile(tag_t tMsgTask, 
									  ErrorMessages *errMsg);

static void writeErrorMsgToStack(ErrorMessages **currErrMsg, 
								 int iFail, 
								 char* sError);

static int get_item_rev_tag (char*    sItemIdRevId,
							 tag_t*   tItemRev);

/*==================================================================
*    Implementation of ACTION Handler -  t1aAUTO_validate_status
====================================================================*/
extern int t1aAUTO_validate_status(EPM_action_message_t msg )
{
    int             indx = 0;
    int             iRetCode = ITK_ok;
    int             iSts = ITK_ok;
    int             iNumArgs = 0;
    int             iNumAttachments = 0;
    tag_t           *ptAttachments = NULL;
    logical         lValidStatus = true;
    logical         lStatus = true;
    char            object_type[WSO_name_size_c+1]="";
    char            szErrorString[TIAUTO_error_message_len+1]="";
    STATUS_Struct_t StatusProgression;

	ErrorMessages *currErrMsg = NULL;
	

    tiauto_initialize_status_progression_stuct(&StatusProgression);

    iNumArgs = TC_number_of_arguments(msg.arguments);
    if( DEBUG_PRINT ) printf("\n TIAUTO-validate-status-progression - Arguments : %d\n", iNumArgs);

    if(iNumArgs != 0)
    {
        TI_sprintf(szErrorString, "No Arguments allowed to \"TIAUTO-validate-status-progression\" handler.\n");
        TC_write_syslog(szErrorString);
        EMH_store_error_s1( EMH_severity_error, TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER, szErrorString) ;
        iRetCode = TIAUTO_NO_ARGS_ALLOWED_TO_HANDLER;
		//writeErrorsToAuditFile(msg.task);
		writeErrorMsgToStack(&currErrMsg, iRetCode, szErrorString);
    }
    else
    {
        iRetCode = tiauto_get_status_progression_array (&StatusProgression);
				
        //for (indx = 0; indx < StatusProgression.iCount; indx++ )
        //    printf("\n Progression Status: %s\n", StatusProgression.StatusArray[indx]);

        if (iRetCode == ITK_ok)
        {
            iRetCode = tiauto_get_task_attachments (msg, EPM_target_attachment,
                                                    &iNumAttachments, &ptAttachments);
            for (indx = 0; indx < iNumAttachments && (iRetCode == ITK_ok); indx++)
            {
                iRetCode = WSOM_ask_object_type(ptAttachments[indx], object_type);
                if (iRetCode == ITK_ok && tc_strcmp (object_type, CHANGE_REV) == 0 )
                {
                    // Validating item rev  for (assembly/component part) status progression
                    iSts = check_for_item_same_rev_progression (ptAttachments[indx],
                                                                StatusProgression,
																&currErrMsg,
                                                                &lStatus );
					if( iSts != ITK_ok )
						iRetCode = iSts;
					if(lStatus == false)
						lValidStatus = lStatus;

                    // Validating item rev for backwards progression
                    //if (iSts == ITK_ok && lValidStatus)
                    iSts = check_for_item_rev_backwards_progression (ptAttachments[indx],
                                                                     StatusProgression,
																	 &currErrMsg,
                                                                     &lStatus );
					if( iSts != ITK_ok )
						iRetCode = iSts;
					if(lStatus == false)
						lValidStatus = lStatus;

					// check for generic progression
					//if (iSts == ITK_ok && lValidStatus)
					iSts = check_for_item_rev_generic_progression(ptAttachments[indx],
                                                                  StatusProgression,
																  &currErrMsg,
                                                                  &lStatus );
					if( iSts != ITK_ok )
						iRetCode = iSts;
					if(lStatus == false)
						lValidStatus = lStatus;

                    break;  // there should be only one change rev as target attachments.
                }
            }
        }
    }
	
    //free up allocated memory
    SAFE_MEM_free (StatusProgression.StatusArray);
    SAFE_MEM_free (ptAttachments);

    if ( (iRetCode != ITK_ok) ||  (!lValidStatus) )
    {
        // Writing failure reason in the workflow Audit File
        //writeErrorsToAuditFile(msg.task);
		writeErrorsMsgToAuditFile(msg.task, currErrMsg);
    }
    if (iRetCode == ITK_ok)
    {
        if (lValidStatus) // When status is valid, set to true to continue the process.
            iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_TRUE);
        else // When status is invalid, set to false - for demoting the task to application engineer.
            iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
    }
    else if (iRetCode > EMH_USER_error_base)
    {
        // When there is a error set to false - for demoting the task to application engineer..
        iRetCode = EPM_set_condition_task_result (msg.task, EPM_RESULT_FALSE);
    }
	
	currErrMsg = NULL;
    return iRetCode;
}
										
													
/* main function for validates  status progression of item revision in the change folders
  w.r.t to target release status of change process */
static int  check_for_item_same_rev_progression (tag_t   tEngChangeRev,
                                                 STATUS_Struct_t     StatusProgression,
												 ErrorMessages **currErrMsg,
                                                 logical   *lValidStatus)
{
    int         indx = 0;
    int         iRetCode = ITK_ok;
    int         iSts = ITK_ok;
    int         iNumAffected = 0;
    tag_t       *ptAffectedItems = NULL;
    char		*pszAffectedName = NULL;
    logical     lIsAssembly = false;
    logical     lStatus = true;
    char        *pszClassName = NULL;
    char        szErrorString[TIAUTO_error_message_len+1]="";
    TARGET_RELEASE_Struct_t TargetReleaseStatus;

    iRetCode = tiauto_get_target_release_status(tEngChangeRev, TargetReleaseStatus.szTargetReleaseStatus);
    if ( iRetCode == ITK_ok )
    {
        TargetReleaseStatus.iLevel = tiauto_status_progression_index (TargetReleaseStatus.szTargetReleaseStatus,
                                                                      StatusProgression);
        if (TargetReleaseStatus.iLevel != -1)
        {
            iRetCode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);
            //for (indx = 0; indx < iNumAffected && (iRetCode == ITK_ok) ; indx++)
			if ( iRetCode == ITK_ok )
			for (indx = 0; indx < iNumAffected ; indx++)
            {
                iSts = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);

                if( (iSts == ITK_ok) && (tc_strcasecmp (pszClassName , "ItemRevision")== 0 ) )
                {
                    iSts = tiauto_check_if_affected_is_an_assembly(ptAffectedItems[indx], &lIsAssembly);
                    if(iSts == ITK_ok)
					{
						if (lIsAssembly)
							iSts = check_for_assy_progression (tEngChangeRev, StatusProgression,
																ptAffectedItems[indx],
																TargetReleaseStatus, currErrMsg, &lStatus);
						else
							iSts = check_for_item_rev_valid_status (ptAffectedItems[indx],StatusProgression,
																	TargetReleaseStatus, currErrMsg, &lStatus);

						if( (!lStatus) || ( iSts != ITK_ok ) )
						{
							*lValidStatus = lStatus; // break;
							if(iSts != ITK_ok)
								iRetCode = iSts;
						}
					}
					else
					{
						iRetCode = iSts;
						*lValidStatus = false;
                        iSts = WSOM_ask_id_string(ptAffectedItems[indx], &pszAffectedName);
                        TI_sprintf(szErrorString, "Error while checking if Part %s has a BOM.\n", pszAffectedName);
                        TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString);
						writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
						SAFE_MEM_free(pszAffectedName);
					}
                } // Verify this for break when lStatus = false
            }
        }
        else
        {
            //TI_sprintf(szErrorString, "Target Release Status \"%s\" is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n", TargetReleaseStatus.szTargetReleaseStatus);
			TI_sprintf(szErrorString, "Target Release Status is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n");
            TC_write_syslog(szErrorString);
            EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE, szErrorString);
	        iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
			writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
        }
    }
    SAFE_MEM_free (pszClassName);
    SAFE_MEM_free (ptAffectedItems);

    *lValidStatus = lStatus;
    return iRetCode;
}
										
/* If the part is an assembly part, then this function validates the present statuses of
   each and every component part of the assembly (same rev progression w.r.t target release
   status of change process. In the present implementation, there is only ONE BOM and it should
   be PRECISE. So we are ignoring any NON-PRECISE BOMs and more than one BOMs */
static int  check_for_assy_progression(tag_t  tEngChangeRev,
                                       STATUS_Struct_t     StatusProgression,
                                       tag_t  tAffectedItem,
                                       TARGET_RELEASE_Struct_t TargetReleaseStatus,
									   ErrorMessages **currErrMsg,
                                       logical   *lStatus)

{
    int     iRetCode = 0;
	int     iSts = 0;
    int     iCount = 0;
    int     iItemBvrCount = 0;
    int     iNumOccs = 0;
    tag_t   *ptItemRevBvrs = NULL;
    char    *pszTypeName = NULL;
    tag_t   *tOccs = NULL;
    tag_t   tChildIem = NULLTAG;
	tag_t	tChildBomView = NULLTAG;
    char    szChildRelStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]="";
    logical lIsPrecise = false;
    logical lIsOEM = false;
    char    *pszAffectedName = NULL;

    iRetCode = ITEM_rev_list_bom_view_revs (tAffectedItem, &iItemBvrCount, &ptItemRevBvrs);
    if (iRetCode == ITK_ok && iItemBvrCount > 0)
    {
        // As per existing implementation, there is only one BVR in the system.
        iSts = PS_ask_is_bvr_precise (ptItemRevBvrs[0], &lIsPrecise);

        if (lIsPrecise && iSts == ITK_ok)
        {
            iSts = PS_list_occurrences_of_bvr (ptItemRevBvrs[0], &iNumOccs, &tOccs);
			if( iSts == ITK_ok )
            for (iCount = 0; iCount < iNumOccs ; iCount++)
            {
                iSts = PS_ask_occurrence_child (ptItemRevBvrs[0], tOccs[iCount],
                                                    &tChildIem, &tChildBomView);
				if ( iSts == ITK_ok )
					iSts = tiauto_get_release_status(tChildIem, szChildRelStatus);
                if (iSts == ITK_ok)
                {
                    if(DEBUG_PRINT) printf("\n Child Item Status Type : %s", szChildRelStatus);

                    // Verifying whether child component rev is at SAME or HIGHER status than target release status
                    //  of Change process. If yes, accept the child component and continue to verify another child rev.
                    if ( tc_strcasecmp (szChildRelStatus, TargetReleaseStatus.szTargetReleaseStatus) == 0 ||
                            tiauto_status_progression_index (szChildRelStatus, StatusProgression) > TargetReleaseStatus.iLevel)
                    {
                        continue;
                    }
                    // If not as above mentioned, verify if the child component rev is part of Affected OR Solution
                    // Items folders of Change Process. If yes, accept and continue to verify another child rev.
                    else if(isComponentPartOfAffectedItems(tChildIem, tEngChangeRev))
                    {
                        continue;
                    }
					//If the child component has "Cad Release Only" status
					else if ( tc_strcasecmp (szChildRelStatus, CRO )== 0)
					{
						iSts = tiauto_check_if_itemType_isOEM(tChildIem, &lIsOEM);
						if(iSts != ITK_ok) // failed to get child item type
						{
							iRetCode = iSts;
							iSts = WSOM_ask_id_string(tChildIem, &pszAffectedName);
							TI_sprintf(szErrorString, "Failed to verify the item type of Child Component Part %s.\n", pszAffectedName);
							TC_write_syslog(szErrorString);
							EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString);							
							writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
							SAFE_MEM_free ( pszAffectedName );
						}
						else if(lIsOEM == false)
						{
							*lStatus = false;
							iSts = WSOM_ask_id_string(tChildIem, &pszAffectedName);
							TI_sprintf(szErrorString, "Child Component Part %s is at Lower status than Target Release State AND also not part of present change process. Please add part %s to change folders.\n", pszAffectedName, pszAffectedName);
							TC_write_syslog(szErrorString);
							EMH_store_error_s1( EMH_severity_error, TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
							iRetCode = TIAUTO_CHILD_PART_INVALID_STATUS;
							writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
							SAFE_MEM_free ( pszAffectedName );
						}
						else
							continue; // the child component is OEM and has valid status
					}
                    else // If not, then child component part rev is at INVALID Release status for the current change process.
                    {
                        *lStatus = false;
                        iSts = WSOM_ask_id_string(tChildIem, &pszAffectedName);
                        TI_sprintf(szErrorString, "Child Component Part %s is at Lower status than Target Release State AND also not part of present change process. Please add part %s to change folders.\n", pszAffectedName, pszAffectedName);
                        TC_write_syslog(szErrorString);
                        EMH_store_error_s1( EMH_severity_error, TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
                        iRetCode = TIAUTO_CHILD_PART_INVALID_STATUS;
						writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
                        SAFE_MEM_free ( pszAffectedName );
                        //break;
                    }
                }
				else
				{
					*lStatus = false;
                    iSts = WSOM_ask_id_string(tChildIem, &pszAffectedName);
                    TI_sprintf(szErrorString, "Failed to get Child Component Part %s status.\n", pszAffectedName);
                    TC_write_syslog(szErrorString);
                    EMH_store_error_s1( EMH_severity_error, TIAUTO_CHILD_PART_INVALID_STATUS, szErrorString);
                    iRetCode = TIAUTO_CHILD_PART_INVALID_STATUS;
					writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
					SAFE_MEM_free ( pszAffectedName );
				}
			}
        }
        else
        {
			iSts = WSOM_ask_id_string(tAffectedItem, &pszAffectedName);
            TI_sprintf(szErrorString, "%s Part does not have Precise BOM. So it is Invalid BOM.\n", pszAffectedName);
            TC_write_syslog(szErrorString);
            EMH_store_error_s1( EMH_severity_error, TIAUTO_IMPRECISE_BVR_FOUND, szErrorString);
            iRetCode = TIAUTO_IMPRECISE_BVR_FOUND;
			writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
            SAFE_MEM_free ( pszAffectedName ); // ???
            //break;
        }
    }
	//SAFE_MEM_free ( pszAffectedName );
    SAFE_MEM_free (ptItemRevBvrs);
    SAFE_MEM_free (pszTypeName);
    SAFE_MEM_free (tOccs);

    return iRetCode;
}
							
/* If the part in the change folders is not a assembly part, but just component part -
   then this function is used for validating component part progression check.
   This validates progression of current revision status w.r.t target release status
   of change process. */
static int  check_for_item_rev_valid_status(tag_t  tAffectedItem,
                                            STATUS_Struct_t     StatusProgression,
                                            TARGET_RELEASE_Struct_t TargetReleaseStatus,
											ErrorMessages **currErrMsg,
                                            logical   *lStatus)

{
    int     iRetCode = ITK_ok;
    char    szReleaseStatus[WSO_name_size_c+1] = "";
    char    szErrorString[TIAUTO_error_message_len+1]="";
    char    *pszAffectedName = NULL;

    iRetCode = tiauto_get_release_status(tAffectedItem, szReleaseStatus);

    // If component part rev is already at Change Process Target Release status OR at WIP status OR
    // at a lower status than Target Release Status, then accept part rev.
    if ( tc_strcasecmp (szReleaseStatus, TargetReleaseStatus.szTargetReleaseStatus) == 0 ||
         tc_strcasecmp (szReleaseStatus, "") == 0 ||
         tiauto_status_progression_index (szReleaseStatus, StatusProgression) < TargetReleaseStatus.iLevel )
    {
        *lStatus = true;    // Item revision is at valid status
    }
    else // If not ( not satisfying above mentioned criteria), then component part is currently at invalid status .
    {
        *lStatus = false;   //Item revision is at invalid status
        iRetCode = WSOM_ask_id_string(tAffectedItem, &pszAffectedName);
        TI_sprintf(szErrorString, "Component Part %s Revision is at a Higher status than Target Release State. This Revision is not allowed as a Affected OR Solutions Item.\n", pszAffectedName);
        TC_write_syslog(szErrorString);
        EMH_store_error_s1( EMH_severity_error, TIAUTO_PARTREV_INVALID_STATUS, szErrorString);
        iRetCode = TIAUTO_PARTREV_INVALID_STATUS;
		writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
        SAFE_MEM_free ( pszAffectedName );
    }
    return  iRetCode;
}
									
/* main function of backwards progression check  - validates current revision against
   later revisions of the same item*/
static int  check_for_item_rev_backwards_progression (tag_t     tEngChangeRev,
                                                      STATUS_Struct_t    StatusProgression,
													  ErrorMessages **currErrMsg,
                                                      logical   *lStatus )
{
    int         indx = 0;
    int         iNumAffected = 0;
    int         iRetCode = ITK_ok;
    int         iSts = ITK_ok;
    tag_t       *ptAffectedItems = NULL;
    char        *pszClassName = NULL;
    char        szTargetReleaseStatus[WSO_name_size_c+1]="";
    char        *pszAffectedName = NULL;
    char        szErrorString[TIAUTO_error_message_len+1]="";
	int			iLevel = -1;

    iRetCode = tiauto_get_target_release_status(tEngChangeRev, szTargetReleaseStatus);
	if(iRetCode == ITK_ok)
	{
		iLevel = tiauto_status_progression_index(szTargetReleaseStatus, StatusProgression );
		if (iLevel == -1)
		{
			//TI_sprintf(szErrorString, "Target Release Status \"%s\" is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n", szTargetReleaseStatus);
			TI_sprintf(szErrorString, "Target Release Status is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n");
			TC_write_syslog(szErrorString);
			EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE, szErrorString);
			iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
			writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
		}
	}
    if(iRetCode == ITK_ok)
        iRetCode = ECM_get_affected_items (tEngChangeRev, &iNumAffected, &ptAffectedItems);
    if(DEBUG_PRINT) printf("\n No. Affected/Solution Items : %d", iNumAffected);
	if(iRetCode == ITK_ok)
    for (indx = 0; indx < iNumAffected ; indx++)
    {
        iSts = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);
		if(iSts != ITK_ok)
			iRetCode = iSts;
        else if( tc_strcasecmp (pszClassName , "ItemRevision")== 0 )
        {
            iSts = verify_each_affected_item(ptAffectedItems[indx],
                                                 szTargetReleaseStatus,
                                                 StatusProgression,
												 currErrMsg,
                                                 lStatus);
			
            if( (*lStatus == false) || (iSts != ITK_ok) )
            {
				iRetCode = TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR;
#if 0
  //              iSts = WSOM_ask_id_string(ptAffectedItems[indx], &pszAffectedName);
  //              TI_sprintf(szErrorString, "%s is Progressing backwards w.r.t later revisions of same Item. You can not proceed further.\n",pszAffectedName);
    //            TC_write_syslog(szErrorString);
      //          EMH_store_error_s1( EMH_severity_error, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR, szErrorString);
     //           iRetCode = TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR;
		//		writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);				
                //SAFE_MEM_free ( pszAffectedName );
                //break;
#endif
            }
        }
    }
	SAFE_MEM_free ( pszAffectedName );
    SAFE_MEM_free ( pszClassName );
    SAFE_MEM_free ( ptAffectedItems );
    return iRetCode;
}
							
/* validates the existing status of each and every item revision under change folders,
   for backwards status progression .*/
static int  verify_each_affected_item (tag_t    affected_item_tag,
                                       char     *szTargetReleaseStatus,
                                       STATUS_Struct_t    StatusProgression,
									   ErrorMessages **currErrMsg,
                                       logical   *lStatus)
{
    int         indx = 0;
    int         iRetCode = 0;
    int         iLevel = -1;
    int         rev_count = 0;
    tag_t       *item_rev_list = NULL;
    tag_t       item_tag = NULLTAG;
    char        *item_change_rev_name = NULL, *item_other_rev_name = NULL;
    char        release_status_name[WSO_name_size_c+1]="";
    char        szErrorString[TIAUTO_error_message_len+1]="";


	iLevel = tiauto_status_progression_index(szTargetReleaseStatus, StatusProgression );
	*lStatus = true;
	/*
	if (iLevel == -1)
    {
        TI_sprintf(szErrorString, "Target Release Status is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n");
        TC_write_syslog(szErrorString);
        EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE, szErrorString);
        iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
    }
    else // this check is moved to "check_for_item_rev_backwards_progression"
	*/
    {
        iRetCode = WSOM_ask_id_string(affected_item_tag, &item_change_rev_name);
        if(iRetCode == ITK_ok)
            iRetCode = ITEM_ask_item_of_rev(affected_item_tag, &item_tag);
        if(iRetCode == ITK_ok)
            iRetCode = ITEM_list_all_revs(item_tag, &rev_count, &item_rev_list);
        for  ( indx = 0; indx < rev_count && (iRetCode == ITK_ok); indx++)
        {
            iRetCode = WSOM_ask_id_string(item_rev_list[indx], &item_other_rev_name);
            if(iRetCode == ITK_ok && rev_count > 1)
            {
                if(DEBUG_PRINT) printf("\n Item Change Rev  : %s", item_change_rev_name);
                if(DEBUG_PRINT) printf("\n Item Other Rev : %s", item_other_rev_name);
				// i.e check for higher rev only
                if(tc_strcasecmp(item_other_rev_name, item_change_rev_name) > 0)
                {
                    iRetCode =  tiauto_get_release_status(item_rev_list[indx], release_status_name);
					if( tc_strcasecmp(  release_status_name, CRO )==0)
					{
						// continue; // ignore this higher revision having "Cad Release Only" status; valid status
					}
                    else if (tiauto_status_progression_index (release_status_name, StatusProgression) >= iLevel)
                    {
                        *lStatus = false;
                        //start of 11March2009 modifications
                        //TI_sprintf(szErrorString, "%s is Progressing backwards w.r.t later revisions of same Item. You can not proceed further.\n",item_change_rev_name);
						TI_sprintf(szErrorString, "%s is Progressing backwards w.r.t later revision %s of same Item. You can not proceed further.\n",item_change_rev_name, item_other_rev_name );
                        TC_write_syslog(szErrorString);
                        EMH_store_error_s1( EMH_severity_error, TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR, szErrorString);
                        // iRetCode = TIAUTO_PARTREV_PROGRESSING_BACKWARDS_ERROR;
				        writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
                        //end of start of 11March2009 modifications
                        TI_sprintf(szErrorString, "%s is already at SAME or GREATER status w.r.t current target release status: %s.\n",item_other_rev_name, szTargetReleaseStatus);
                        TC_write_syslog(szErrorString);
                        EMH_store_error_s1( EMH_severity_error, TIAUTO_COMPONENT_INVALID_STATUS, szErrorString);
                       // iRetCode = TIAUTO_COMPONENT_INVALID_STATUS;
						writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
                        break; // verify this -> this is required. if any one higher rev has a higher or equal release status, we needn't check with other revisions
                    }
                }
            }
            SAFE_MEM_free (item_other_rev_name);
        }
		if(iRetCode != ITK_ok)
		{
			TI_sprintf(szErrorString, "Failed to verify if the part %s is Progressing backwards w.r.t later revisions of same Item.\n",item_change_rev_name);
			TC_write_syslog(szErrorString);
			EMH_store_error_s1( EMH_severity_error, iRetCode, szErrorString);				
			writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
		}
        SAFE_MEM_free (item_other_rev_name);
        SAFE_MEM_free (item_rev_list);
        SAFE_MEM_free (item_change_rev_name);
    }
    return iRetCode;
}
								
/* verifies whether the given component part is added to the change folders (solution/affected items) */
logical isComponentPartOfAffectedItems(tag_t    tChildItem,
                                       tag_t    tEngChangeRev)
{
    int     iRetCode = ITK_ok;
    int     iCount = 0;
    int     iNumAffected = 0;
    tag_t   *ptAffectedItems = NULL;
    logical lAffected = false;

    iRetCode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);
    for (iCount = 0; iCount < iNumAffected && (iRetCode == ITK_ok); iCount++)
    {
        if (tChildItem == ptAffectedItems[iCount])
        {
            lAffected = true;
            break;
        }
    }

    SAFE_MEM_free (ptAffectedItems);
    return lAffected;
}
									
/* main function of backwards progression check  - validates current revision against
   later revisions of the same item*/
static int  check_for_item_rev_generic_progression(tag_t			tEngChangeRev,
                                                   STATUS_Struct_t	StatusProgression,
												   ErrorMessages **currErrMsg,
                                                   logical			*lStatus )
{
    int         indx = 0;
    int         iNumAffected = 0;
    int         iRetCode = ITK_ok;
    int         iSts = ITK_ok;
    char        *pszClassName = NULL;
	tag_t		*ptAffectedItems = NULL;
    char        *pszAffectedName = NULL;
    char        *pszGenericName = NULL;
	char		pcvalue[80]		= "";
    char        szErrorString[TIAUTO_error_message_len+1]="";
	logical     lIsProE = false;
	tag_t		genericItemRevTag = NULLTAG;
	char        genReleaseStatusName[WSO_name_size_c+1]="";

	TARGET_RELEASE_Struct_t TargetReleaseStatus;

    iRetCode = tiauto_get_target_release_status(tEngChangeRev, TargetReleaseStatus.szTargetReleaseStatus);
    if ( iRetCode == ITK_ok )
    {
        TargetReleaseStatus.iLevel = tiauto_status_progression_index (TargetReleaseStatus.szTargetReleaseStatus,
                                                                      StatusProgression);
        if (TargetReleaseStatus.iLevel != -1)
		{
			iRetCode = ECM_get_affected_items(tEngChangeRev, &iNumAffected, &ptAffectedItems);

			if ( iRetCode == ITK_ok )
			for (indx = 0; indx < iNumAffected ; indx++)
			{
				iSts = tiauto_get_class_name_of_instance (ptAffectedItems[indx], &pszClassName);

				if( (iSts == ITK_ok) && ( tc_strcasecmp (pszClassName , "ItemRevision")== 0 ) )
				{
					// check if pro/E item	isProEType
						// if instance
							// get generic item rev
							// get status of generic item rev
							// validate status of generic item rev with targetReleaseStatus					
					iSts = isComponentProEInstanceGetGeneric(ptAffectedItems[indx], &lIsProE, &genericItemRevTag,pcvalue);
					if(iSts != ITK_ok )
					{
						iRetCode = iSts;
						iSts = WSOM_ask_id_string(ptAffectedItems[indx], &pszAffectedName);
						TI_sprintf(szErrorString, "Failed to check if the Part %s is an Instance Part of ProE Type.\n", pszAffectedName);
						TC_write_syslog(szErrorString);
						EMH_store_error_s1( EMH_severity_error, TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
						iRetCode = TIAUTO_GENREICREV_PROGRESSING_ERROR;
						writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);

						SAFE_MEM_free ( pszAffectedName );
					}
					else if( lIsProE == true )
					{
						if( genericItemRevTag != NULLTAG )
						{
							iRetCode = tiauto_get_release_status(genericItemRevTag, genReleaseStatusName);
							if (tiauto_status_progression_index (genReleaseStatusName, StatusProgression) >= TargetReleaseStatus.iLevel)
							{
								continue;
							}
							else if(isComponentPartOfAffectedItems(genericItemRevTag, tEngChangeRev))
							{
								continue;
							}
							else
							{
								*lStatus = false;
								iSts = WSOM_ask_id_string(ptAffectedItems[indx], &pszAffectedName);
								iSts = WSOM_ask_id_string(genericItemRevTag, &pszGenericName);
								if( tc_strcmp(pszGenericName, pcvalue)==0)
								{
									TI_sprintf(szErrorString, "The Generic Part %s of Instance Part %s is at Lower status than Target Release State AND also not added to the change folder. Please add the part to the change folder.\n", pszGenericName, pszAffectedName);
									TC_write_syslog(szErrorString);
									EMH_store_error_s1( EMH_severity_error, TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									iRetCode = TIAUTO_GENREICREV_PROGRESSING_ERROR;
									writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
								}
								else
								{
									TI_sprintf(szErrorString, "The Generic Part %s[%s] of Instance Part %s is at Lower status than Target Release State AND also not added to the change folder. Please add the part to the change folder.\n", pcvalue, pszGenericName, pszAffectedName);
									TC_write_syslog(szErrorString);
									EMH_store_error_s1( EMH_severity_error, TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
									iRetCode = TIAUTO_GENREICREV_PROGRESSING_ERROR;
									writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
								}
								SAFE_MEM_free ( pszAffectedName );
								SAFE_MEM_free ( pszGenericName );
							}
						}
						else
						{
							// Error: Failed to get generic item details for Instance %s

							iSts = WSOM_ask_id_string(ptAffectedItems[indx], &pszAffectedName);

							TI_sprintf(szErrorString, "Failed to get the Generic Part details of Instance Part %s.\n", pszAffectedName);
							TC_write_syslog(szErrorString);
							EMH_store_error_s1( EMH_severity_error, TIAUTO_GENREICREV_PROGRESSING_ERROR, szErrorString);
							iRetCode = TIAUTO_GENREICREV_PROGRESSING_ERROR;
							writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);

							SAFE_MEM_free ( pszAffectedName );
						}
					}
					TI_sprintf(pcvalue, "");
				}
			}
		}
        else
        {
            //TI_sprintf(szErrorString, "Target Release Status \"%s\" is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n", TargetReleaseStatus.szTargetReleaseStatus);
			TI_sprintf(szErrorString, "Target Release Status is not found in the site Preference \"TI_Progression_Path\". Please update your site preference values.\n");
            TC_write_syslog(szErrorString);
            EMH_store_error_s1( EMH_severity_error, TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE, szErrorString);
            iRetCode = TIAUTO_INCORRECT_PROGRESSION_PATH_PREFERENCE_VALUE;
			writeErrorMsgToStack(currErrMsg, iRetCode, szErrorString);
        }
	}

    SAFE_MEM_free ( pszClassName );
  	SAFE_MEM_free ( ptAffectedItems );
    return iRetCode;
}
												
/* verifies whether the given component part is added to the change folders (solution/affected items) */
static int isComponentProEInstanceGetGeneric(	tag_t     tItem,
												logical  *lProE,
												tag_t    *genericItemRevTag,
												char	 *pcvalue )
{
    int			iRetCode		= ITK_ok;
	int			iSts			= ITK_ok;
	int			iAttrNumArg		= 0;
	int			numIds			= 0;	
	int			numRevs			= 0;
	int			secObjCount		= 0;
	int			j				= 0;
	
	tag_t		tClassDSTag		= NULLTAG;
	tag_t		relationType	=  NULLTAG;
	tag_t		datasettype		=  NULLTAG;
	tag_t		dataset			=  NULLTAG;
	tag_t		*tvalues		= NULL;

	char		datasetTypeName[AE_datasettype_name_size_c+1]	= "";
	char		*value											= NULL;
	char		*propName										= "IPEM_master_dependency";
	char		**pcItemId										= NULL;					
	char		**pcRevId										= NULL;
	
	GRM_relation_t *secondaryList								= 0;

    *lProE = false;
	*genericItemRevTag = NULLTAG;
	iRetCode = GRM_find_relation_type  (  "IMAN_specification", &relationType );
	if( iRetCode == ITK_ok )
		iRetCode =  GRM_list_secondary_objects  (  tItem , relationType,
											   &secObjCount, &secondaryList );
	if( iRetCode == ITK_ok )
	for(j =0 ; j < secObjCount ;j++)
	{
		iSts = POM_class_of_instance(secondaryList[j].secondary,&tClassDSTag );
		if(iSts == ITK_ok)
			iSts = POM_name_of_class( tClassDSTag , &value );
		if( ( iSts==ITK_ok )	&&
			( value !=NULL )	&&
			( tc_strcasecmp( value , "Dataset" ) == 0 ) )
		{
			iSts =  AE_ask_dataset_datasettype( secondaryList[j].secondary, &datasettype );
			if(iSts==ITK_ok)
				iSts =  AE_ask_datasettype_name( datasettype , datasetTypeName );
			if(   ( iSts == ITK_ok ) &&
				  ( datasetTypeName != NULL ) &&
				( ( tc_strcmp("ProPrt" , datasetTypeName)==0 ) ||
				  ( tc_strcmp("ProAsm" , datasetTypeName) ==0 )   )  )
			{
				dataset = secondaryList[j].secondary;
				SAFE_MEM_free ( value );
				break;
			}
		}
		SAFE_MEM_free ( value );
		if(iSts != ITK_ok )
			iRetCode = iSts;
	}
	if( (iRetCode == ITK_ok ) && (dataset != NULLTAG) )
	{
		iRetCode = AOM_UIF_ask_value(  dataset, propName, &value );
		if( value != NULL )
			value= tc_strtok ( value , "-");
		if( value != NULL )
			TI_sprintf(pcvalue, "%s", value);
		if( ( iRetCode == ITK_ok )	&& ( value != NULL ) && ( tc_strlen(value) >0 ) )
		{
			*lProE = true; // generic part
			//to get the actual value tag of the display ID 					  
			iRetCode = AOM_ask_value_tags(dataset,propName,&iAttrNumArg,&tvalues);
			
			if( (iRetCode == ITK_ok) && (tvalues != NULL) && (tvalues[0] != NULLTAG) )
			{
				//to get the Item ID
				iRetCode = AOM_ask_value_strings(tvalues[0],"item_id",&numIds,&pcItemId);
				//to get the Revision ID
				if( iRetCode == ITK_ok )
					iRetCode = AOM_ask_value_strings(tvalues[0],"item_revision_id",&numRevs,&pcRevId);
				//to get the tag of the item revision
				if( ( iRetCode == ITK_ok ) && 
					( pcItemId != NULL )  && ( pcItemId[0] != NULL ) &&
					( pcRevId != NULL )  && ( pcRevId[0] != NULL ) )
					iRetCode = ITEM_find_rev(pcItemId[0],pcRevId[0],genericItemRevTag);
			}				
            						
			for(j=0; j<numIds; j++)
				SAFE_MEM_free (pcItemId[j]);
			pcItemId = NULL;
			for(j=0; j<numRevs; j++)
				SAFE_MEM_free (pcRevId[j]);
			pcRevId = NULL;
			SAFE_MEM_free (tvalues);
			SAFE_MEM_free (value);
		}
	}
	SAFE_MEM_free ( secondaryList );
    return iRetCode;
}
												
// This function writes parts status progression failure messages to
// Audit file of workflow process.
static void writeErrorsToAuditFile(tag_t tMsgTask)
{
    tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
    IMF_file_t  tFileDescriptor = NULL;
    int         indx = 0;
    int         iRetCode = 0;
    int         n_errors = 0;
    int         *severities = NULL;
    int         *statuses = NULL;
    char        **messages = NULL;
    char        *pszErrorStr = NULL;

    iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);

    if (iRetCode == ITK_ok)
    {
        iRetCode = EMH_ask_errors(&n_errors, &severities, &statuses, &messages );
        printf( " \n********** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        TC_write_syslog  ( "Status Progression Failure Error(s): \n");
        iRetCode = IMF_write_file_line(tFileDescriptor, "\n*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n");
        for (indx = 0; indx < n_errors; indx++)
        {
            if(messages[indx]!= NULL)
            {
                printf( "    %6d: %s\n", statuses[indx], messages[indx] );
                TC_write_syslog( "    %6d: %s\n", statuses[indx], messages[indx] );
                iRetCode = IMF_write_file_line(tFileDescriptor, messages[indx]);
            }		
        }
        printf( " \n********** END OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** END OF STATUS PROGRESSION FAILURE ERROR MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n\n");
    }
    if (iRetCode == ITK_ok)
        iRetCode = IMF_close_file(tFileDescriptor);

    EMH_clear_errors();
    SAFE_MEM_free (pszErrorStr);
}
																
static void writeErrorsMsgToAuditFile(tag_t tMsgTask, 
									  ErrorMessages *errMsg)
{
	tag_t       tJob = NULLTAG;
    tag_t       tAuditFile = NULLTAG;
    IMF_file_t  tFileDescriptor = NULL;
	ErrorMessages *tempErrMsg;
	
    int         iRetCode = 0;
	    
	iRetCode = EPM_ask_job ( tMsgTask, &tJob );
    if (iRetCode == ITK_ok)
        iRetCode = EPM_ask_audit_file (tJob, &tAuditFile);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_ask_file_descriptor(tAuditFile, &tFileDescriptor);
    if (iRetCode == ITK_ok)
        iRetCode = IMF_open_file(tFileDescriptor, SS_APPEND);
	if (iRetCode == ITK_ok)
	{
		printf( " \n********** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        TC_write_syslog  ( "Status Progression Failure Error(s): \n");
        iRetCode = IMF_write_file_line(tFileDescriptor, "\n*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** BEGIN OF STATUS PROGRESSION FAILURE MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n");
        
		while(errMsg != NULL)
		{
			printf( "    %6d: %s\n", errMsg->iRetCode, errMsg->errMsg );
			TC_write_syslog( "    %6d: %s\n", errMsg->iRetCode, errMsg->errMsg );	
			iRetCode = IMF_write_file_line(tFileDescriptor, errMsg->errMsg);
			tempErrMsg = errMsg;
			errMsg = errMsg->next;
			free ( tempErrMsg );
			tempErrMsg = NULL;
		}	

		printf( " \n********** END OF STATUS PROGRESSION FAILURE MESSAGES **********\n" );
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************");
        iRetCode = IMF_write_file_line(tFileDescriptor, "****** END OF STATUS PROGRESSION FAILURE ERROR MESSAGES ******");
        iRetCode = IMF_write_file_line(tFileDescriptor, "*********************************************************************************\n\n");   
	}
	if (iRetCode == ITK_ok)
        iRetCode = IMF_close_file(tFileDescriptor);

    EMH_clear_errors();
}
											
static void writeErrorMsgToStack(ErrorMessages **currErrMsg, 
								 int iFail, 
								 char* sError)
{
	ErrorMessages *temp;
	logical isPresent = false;
	temp = *currErrMsg;

	if( (*currErrMsg == NULL) || (temp == NULL) )
	{
		*currErrMsg=malloc(sizeof(ErrorMessages));
		temp = *currErrMsg;
	}
	else
	{
		for(;;)
		{
			if ( tc_strcmp(temp->errMsg, sError) == 0 )
			{
				isPresent = true;
				break;
			}
			if ( (temp->next)!= NULL )
				temp=temp->next;
			else 
				break;
		}
		if( isPresent == false )
		{
			temp->next = malloc(sizeof(ErrorMessages));
			temp=temp->next;
		}
	}
	if( isPresent == false)
	{
		temp->iRetCode = iFail;
		TI_sprintf(temp->errMsg,"%s",sError);
		temp->next  = NULL;
	}
}
												

static int get_item_rev_tag (char*    sValue,
							 tag_t*   tItemRev)
{
	int     iRetCode = ITK_ok;
	char *itemId = NULL;
	char    *itemRevId = NULL;

	itemId = tc_strtok(sValue,"/");
	itemRevId = tc_strtok(NULL,"-");

	iRetCode = ITEM_find_rev(itemId,itemRevId,tItemRev);

	return  iRetCode;
}
														
