/*******************************************************************************
File         : tiauto_ah_unset_conditional_task.c

Description  : 
  
Input        : None
                        
Output       : None

Author       : TCS

Revision History :
Date            Revision    Who              Description
Feb 24, 2010    1.0        Rajesh Natesan    Initial Creation

*******************************************************************************/
#include <tiauto_custom_handlers.h>
#include <tiauto_utils.h>
#include <tiauto_defines.h>

extern int tiauto_ah_unset_conditional_task(EPM_action_message_t msg)
{
   int iFail = ITK_ok;
   tag_t tTaskTag = NULLTAG;
   tTaskTag = msg.task;
   iFail = EPM_set_condition_task_result(tTaskTag,2);
   return iFail;  
}