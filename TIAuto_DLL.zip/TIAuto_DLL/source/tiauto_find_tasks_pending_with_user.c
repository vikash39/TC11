/*******************************************************************************************************************
File         : tiauto_user_query.c

Description  : These are functions related to the user query - "Tasks by Assigned User"
			   This function will find the tasks pending with a user. The root tasks(in process only)  i.e. the
			   running workflows will be taken into consideration. The sub tasks in the 
			   workflow can be completed/pending/started

Input        : None

Output       : None

Author       : TCS

Revision History :
-----------------------------------------------------------------------------------------------------------------
Date			Revision	Who					Description
-----------------------------------------------------------------------------------------------------------------
28 Mar 2012		1.0			Nivedita K			Initial Creation     
20 Apr 2012		1.1			Dipak Naik			Modified the code to list only the open tasks i.e.
												started and pending tasks of all active workflow processes
												that are assigned to the given input user.
******************************************************************************************************************/
#include <tiauto_user_query.h>

/*==========================================================================================================*/
/* 
* This function will return the task where the given user is the responsible party of the task.
*
/*===========================================================================================================*/
extern int find_tasks_assigned_to_users(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	tag_t tEPMTask = NULLTAG;
	int state_values[] = {4};
	int state_values1[] = {8,4,2};
	void *** report;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("TasksPendingWithUser");	
	//select output attribute
	if(ifail == ITK_ok)
		ifail = POM_enquiry_add_select_attrs ( "TasksPendingWithUser", "EPMTask", 1, select_attr_list1);
	//craete alias
	if(ifail == ITK_ok)
		ifail = POM_enquiry_create_class_alias ( "TasksPendingWithUser", "EPMTaskTemplate",1,"EPMTaskTemplate_alias");
	//craete alias
	if(ifail == ITK_ok)
		ifail = POM_enquiry_create_class_alias ( "TasksPendingWithUser", "EPMTask",1,"EPMTask_alias");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_1","EPMTask","task_template",POM_enquiry_equal,"EPMTaskTemplate","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_2","EPMTask","parent_process",POM_enquiry_equal,"EPMJob","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_3","EPMJob","process_template",POM_enquiry_equal,"EPMTaskTemplate_alias","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_4","EPMJob","root_task",POM_enquiry_equal,"EPMTask_alias","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_int_value("TasksPendingWithUser", "aunique_value_id3", 1, state_values, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithUser","auniqueExprId_5","EPMTask_alias","state_value",POM_enquiry_in,"aunique_value_id3");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_6","EPMJob","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithUser","auniqueExprId_7","EPMTask","responsible_party",POM_enquiry_equal,"POM_user","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value("TasksPendingWithUser", "aunique_value_id1", 1, &Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithUser","auniqueExprId_8","POM_user","user_id",POM_enquiry_equal,"aunique_value_id1");  	
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_int_value("TasksPendingWithUser", "aunique_value_id4", 3, state_values1, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithUser","auniqueExprId_9","EPMTask","state_value",POM_enquiry_in,"aunique_value_id4");
	//join the query expressions
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_15","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_16","auniqueExprId_15",POM_enquiry_and, "auniqueExprId_3");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_17","auniqueExprId_16",POM_enquiry_and, "auniqueExprId_4");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_18","auniqueExprId_17",POM_enquiry_and, "auniqueExprId_5");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_19","auniqueExprId_18",POM_enquiry_and, "auniqueExprId_6");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_20","auniqueExprId_19",POM_enquiry_and, "auniqueExprId_7");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_21","auniqueExprId_20",POM_enquiry_and, "auniqueExprId_8");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithUser","auniqueExprId_22","auniqueExprId_21",POM_enquiry_and, "auniqueExprId_9");

	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_where_expr("TasksPendingWithUser","auniqueExprId_22");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_distinct("TasksPendingWithUser", true);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_execute ( "TasksPendingWithUser",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("TasksPendingWithUser");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tEPMTask = NULLTAG;
			tEPMTask = *(tag_t *)report[i][0];
			(*foundTags)[i] = tEPMTask;
		}

		MEM_free(report);
	}
	
	return ifail;
}
/*==========================================================================================================*/
/* 
* This function will return the task where the given user is the signoff user.
*
/*===========================================================================================================*/
extern int find_tasks_assigned_to_signoff_users(const char* Keyword ,int *iNumFound,tag_t **foundTags)
{
	int ifail = ITK_ok;
	int rows = 0;
	int cols = 0;
	int i=0;
	tag_t tEPMTask = NULLTAG;
	int state_values[] = {4};
	int state_values1[] = {2,4,8};
	const char *pcTaskType[] = {"EPMSelectSignoffTask","EPMPerformSignoffTask"};
	void *** report;
	const char* select_attr_list1[] = { "puid"};
	ifail = POM_enquiry_create ("TasksPendingWithSignOffUser");	
	//select output attribute
	if(ifail == ITK_ok)
		ifail = POM_enquiry_add_select_attrs ( "TasksPendingWithSignOffUser", "EPMTask", 1, select_attr_list1);
	//craete alias
	if(ifail == ITK_ok)
		ifail = POM_enquiry_create_class_alias ( "TasksPendingWithSignOffUser", "EPMTaskTemplate",1,"EPMTaskTemplate_alias");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_create_class_alias ( "TasksPendingWithSignOffUser", "WorkspaceObject",1,"WorkspaceObject_alias");
	//craete alias
	if(ifail == ITK_ok)
		ifail = POM_enquiry_create_class_alias ( "TasksPendingWithSignOffUser", "EPMTask",1,"EPMTask_alias");
	//create psuedo class
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_pseudo_calias("TasksPendingWithSignOffUser","EPMTask","Attachments","attach_val");
	
	//query expressions
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_1","EPMTask","task_template",POM_enquiry_equal,"EPMTaskTemplate","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_2","EPMTask","parent_process",POM_enquiry_equal,"EPMJob","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_3","EPMJob","process_template",POM_enquiry_equal,"EPMTaskTemplate_alias","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_4","EPMJob","root_task",POM_enquiry_equal,"EPMTask_alias","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_int_value("TasksPendingWithSignOffUser", "aunique_value_id1", 1, state_values, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithSignOffUser","auniqueExprId_5","EPMTask_alias","state_value",POM_enquiry_equal,"aunique_value_id1");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_6","EPMTask","puid",POM_enquiry_equal,"WorkspaceObject","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value("TasksPendingWithSignOffUser", "aunique_value_id2", 2, pcTaskType, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithSignOffUser","auniqueExprId_7","WorkspaceObject","object_type",POM_enquiry_in,"aunique_value_id2");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_8","EPMJob","puid",POM_enquiry_equal,"WorkspaceObject_alias","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_9","EPMTask","puid",POM_enquiry_equal,"attach_val","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_10","attach_val","PVAL",POM_enquiry_equal,"SignOff","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_11","SignOff","group_member",POM_enquiry_equal,"GroupMember","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_12","GroupMember","puid",POM_enquiry_equal,"POM_member","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_join_expr("TasksPendingWithSignOffUser","auniqueExprId_13","POM_member","user",POM_enquiry_equal,"POM_user","puid");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_string_value("TasksPendingWithSignOffUser", "aunique_value_id3", 1, &Keyword, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithSignOffUser","auniqueExprId_14","POM_user","user_id",POM_enquiry_equal,"aunique_value_id3");  	
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_int_value("TasksPendingWithSignOffUser", "aunique_value_id5", 3, state_values1, POM_enquiry_bind_value );
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_attr_expr("TasksPendingWithSignOffUser","auniqueExprId_15","EPMTask","state_value",POM_enquiry_in,"aunique_value_id5");

	//join the query expressions
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_20","auniqueExprId_1",POM_enquiry_and, "auniqueExprId_2");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_21","auniqueExprId_20",POM_enquiry_and, "auniqueExprId_3");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_22","auniqueExprId_21",POM_enquiry_and, "auniqueExprId_4");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_23","auniqueExprId_22",POM_enquiry_and, "auniqueExprId_5");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_24","auniqueExprId_23",POM_enquiry_and, "auniqueExprId_6");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_25","auniqueExprId_24",POM_enquiry_and, "auniqueExprId_7");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_26","auniqueExprId_25",POM_enquiry_and, "auniqueExprId_8");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_27","auniqueExprId_26",POM_enquiry_and, "auniqueExprId_9");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_28","auniqueExprId_27",POM_enquiry_and, "auniqueExprId_10");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_29","auniqueExprId_28",POM_enquiry_and, "auniqueExprId_11");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_30","auniqueExprId_29",POM_enquiry_and, "auniqueExprId_12");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_31","auniqueExprId_30",POM_enquiry_and, "auniqueExprId_13");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_32","auniqueExprId_31",POM_enquiry_and, "auniqueExprId_14");
	if(ifail == ITK_ok)
		ifail =  POM_enquiry_set_expr("TasksPendingWithSignOffUser","auniqueExprId_33","auniqueExprId_32",POM_enquiry_and, "auniqueExprId_15");

	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_where_expr("TasksPendingWithSignOffUser","auniqueExprId_33");
	if(ifail == ITK_ok)
		ifail = POM_enquiry_set_distinct("TasksPendingWithSignOffUser", true);
	if(ifail == ITK_ok)
		ifail = POM_enquiry_execute ( "TasksPendingWithSignOffUser",&rows,&cols,&report);
	//delete the query
	ifail = POM_enquiry_delete ("TasksPendingWithSignOffUser");
	
	if(rows > 0)
	{
		//allocate memory
		*foundTags = (tag_t *)MEM_alloc(rows * sizeof(tag_t));
		*iNumFound = rows;
		for(i=0;i<rows;i++)
		{
			tEPMTask = NULLTAG;
			tEPMTask = *(tag_t *)report[i][0];
			(*foundTags)[i] = tEPMTask;
		}

		MEM_free(report);
	}
	
	return ifail;
}