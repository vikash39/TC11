# ifndef TI_COST_DATA_IMPORT_HEADER
# define TI_COST_DATA_IMPORT_HEADER

/*************************************************
* System Header Files
**************************************************/
//#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <conio.h>

//#include "TI_StandardCost.hxx"
/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tc\tc.h>
#include <tccore\grm.h>
#include <tc\tc_startup.h>
#include <tccore\item.h>
#include <tccore\aom_prop.h>
#include <tccore\aom.h>
#include <sa\group.h>
#include <fclasses\tc_date.h>
#include <sa\groupmember.h>
#include <user_exits\epm_toolkit_utils.h>
#include <lov\lov.h>
#include <tc\folder.h>

//using namespace std;

#define SUCCESS_STATUS                       "Success"
#define ERR_FAIL_STATUS                      "Fail"
#define PART_NUM_NOT_PASSED_AS_ARG           "Unable to find the partNumber as a input"
#define EXCP_ERR                             "EXCEPTION::ERROR: Unknown failure occurred"
#define ERP_PLM_ATTRI_MAPPING                "EXCEPTION::ERROR: While getting the ERP_PLM_Attribute_Mapping values."
#define EXCP_PARSE_CASCADEING_LOV            "EXCEPTION::ERROR: While getting parsingCascadingLOV from tc-"
#define EXCP_PARSE_FACTY_MAP_LOV             "EXCEPTION::ERROR: While getting the Facility Mapping Lov from tc-"
#define EXCP_ERR_TO_GET_FACTY_AND_LOC        "EXCEPTION::ERROR: While getting facilityName & facilityLoc"
#define FACILITY_NAME_IS_NULL                "Facility name is empty.."
#define FACILITY_LOC_IS_NULL                 "Facility location is empty.."
#define FACILITY__LOC_MAP_SIZE               "Unable to parse LOV to get the mapping for the facility"
#define EXCP_ERR_CREATE_NEW_SCF              "EXCEPTION::ERROR: While creating new standard cost form.."
#define EXCP_ERR_REVISE_SCF                  "EXCEPTION::ERROR:While revising the existing cost form.."
#define PART_ID_NOT_FOUND_IN_TC              "ERROR: PartId not found in tc"
#define REV_ID_NOT_FOUND_IN_TC               "ERROR: RevId not found in tc"

#endif

#define ERROR_CALL(x) { \
	int stat; \
	char *err_string = NULL; \
	if( (stat = (x)) != ITK_ok) \
{ \
	EMH_ask_error_text (stat, &err_string); \
	if(err_string != NULL) {\
	printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string); \
	printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__); \
	TC_write_syslog("TI CostDataImport Error [%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
	MEM_free (err_string);\
	err_string=NULL;\
	}\
} \
}