#include "TI_Common.hxx"
#include "TI_StandardCost.hxx"

using namespace std;

/****************************************************************
//
//  Function Name:   getCurrentSiteID
//
//  Description:     Get the current site id.
//                   
//  Parameters:     none

//  Return Value:    iSiteID
//                   
*****************************************************************/

int  getCurrentSiteID(){

	int iFail = ITK_ok;
	int  iSite    = 0;
	int  iSiteID  = 0;

	tag_t  tSitetag = NULLTAG;

	char    acSiteName[SA_site_size_c+1]    = {'\0'};

	ERROR_CALL(iFail = POM_site_id(&iSite));

	if(iSite != 0)
		ERROR_CALL(iFail = SA_find_site_by_id(iSite,&tSitetag));

	if(tSitetag!= NULLTAG)
		ERROR_CALL(iFail = SA_ask_site_info(tSitetag,acSiteName,&iSiteID));

	if(iSiteID != 0)
		return iSiteID;

	return iSiteID;
}

/****************************************************************
//
//  Function Name:   getAttributeMappingValues()
//
//  Description:     Getting the attribute mapping values from TI_StandardCost.hxx file.
//                   
//  Parameters:     stdCostResponse -> passing the stdCostResponseInfo structure.

//  Return Value:    stdCostAttrMap
//                   
*****************************************************************/

map<string, string>  getAttributeMappingValues(TITCERPIntegration::GetStandardCostResponse &stdCostResponse) {

	map<string, string> stdCostAttrMap;

	try{
		stringstream sss(STANDARD_PROPERTY);

		while (sss.good()) {
			string substrs;
			getline(sss, substrs, ',');

			stringstream ss(substrs);
			int iCnt=0;
			string plmAttrName ="";
			string erpAttrName ="";

			while(ss.good()){
				string substr;

				getline(ss, substr, ':');
				if(iCnt==0){
					erpAttrName =substr;
					iCnt++;
				}else
					plmAttrName = substr;
			}
			stdCostAttrMap.insert(pair<string, string>(erpAttrName, plmAttrName));
		}
		if(stdCostAttrMap.size()>0)
			sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS);

	}catch(...){
		TC_write_syslog(ERP_PLM_ATTRI_MAPPING);
		sendResponseInfo(1, stdCostResponse,  ERP_PLM_ATTRI_MAPPING);
	}

	return stdCostAttrMap;
}

/****************************************************************
//
//  Function Name:   processStandardCostData()
//
//  Description:     Process the input standard cost data, after process it's giving the tempStdCostRecord.
//                   
//  Parameters:     stdCostResponse -> passing the stdCostResponseInfo structure.
vcStdCostRecords -> input records

//  Return Value:    none
//                   
*****************************************************************/


void  processStandardCostData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, vector<struct TIAStandardCostRecords> vcStdCostRecords,vector<struct TIAStandardCostRecords> &tempStdCostRecords) {

	try{
		map<string, string> facilityCodeNameMap = parseFacilityMappingLOV(FACILITY_CODE_NAME_MAPPING_LOV,stdCostResponse);
		map<string, string> facilityLocationMap =  parseCascadingLOV(COMPANY_LOV_NAME,"TI",stdCostResponse);

		tempStdCostRecords.push_back(TIAStandardCostRecords());
		tempStdCostRecords.erase(tempStdCostRecords.begin());

		for(int iCnt=0; iCnt<vcStdCostRecords.size(); iCnt++) {
			int index = iCnt;
			
			TIAStandardCostRecords tempStdCostRecord = vcStdCostRecords.at(index);
			

			while(true) {
				if(index <vcStdCostRecords.size() && stdCostRecordCompare(tempStdCostRecord , vcStdCostRecords.at(index))==0) {

					if(vcStdCostRecords.at(index).costBucket =="000")
					{
						//tempStdCostRecord.totalCost = vcStdCostRecords.at(index+1).currentCost;
						tempStdCostRecord.totalCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].totalCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="001")
					{
						//tempStdCostRecord.materialCost = vcStdCostRecords.at(index+1).currentCost;
						tempStdCostRecord.materialCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].materialCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="002")
					{
						//tempStdCostRecord.scrapPercentage = vcStdCostRecords.at(index+1).currentCost;
						tempStdCostRecord.scrapPercentage = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].scrapPercentage = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="003")
					{
						//tempStdCostRecord.laborCost = vcStdCostRecords.at(index+1).currentCost;
						tempStdCostRecord.laborCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].laborCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="004")
					{
						tempStdCostRecord.variableOverHeadCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].variableOverHeadCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="005")
					{
						tempStdCostRecord.fixedOverHeadCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].fixedOverHeadCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="007")
					{
						tempStdCostRecord.dutyCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].dutyCost = vcStdCostRecords.at(index).currentCost;
					}
					else if(vcStdCostRecords.at(index).costBucket =="008")
					{
						tempStdCostRecord.freightCost = vcStdCostRecords.at(index).currentCost;
						//tempStdCostRecords[index].freightCost = vcStdCostRecords.at(index).currentCost;
					}
					if(vcStdCostRecords.at(index).facility == vcStdCostRecords.at(index+1).facility){
						//vcStdCostRecords.erase(vcStdCostRecords.begin()+index+1);
						vcStdCostRecords.erase(vcStdCostRecords.begin());
						//index++;
					}
					else
						index++;
						//vcStdCostRecords.erase(vcStdCostRecords.begin()+index);
					//tempStdCostRecords.push_back(tempStdCostRecord);
				}
				else 
					break;
			} 
			/*for (int i = 0; i < vcStdCostRecords.size(); i++) 
			cout <<"Cost Bucket = "<< vcStdCostRecords[i].costBucket << " "; */

			try{
				string facilityName = "";
				string facility   ="";
				if(facilityCodeNameMap.size() != 0)
					facility = tempStdCostRecord.facility;
				for (auto it = facilityCodeNameMap.begin(); it != facilityCodeNameMap.end(); ++it){
					if(facility==(it->first))
						facilityName = it->second;
				}

				if(facilityName != "")
				{
					string facilityLoc = "";
					if(facilityLocationMap.size() != 0){
						map<string, string>::iterator it ;
						it = facilityLocationMap.find(facilityName);
						facilityLoc = it->second;
					}
					else
						sendResponseInfo(1, stdCostResponse,  FACILITY__LOC_MAP_SIZE);

					if(facilityLoc!="")
					{
						int tempIndex = 0;
						string companyType ="";
						string companyName ="";
						string country ="";
						//std::string s = "TI::TI Automotive::Poland";
						std::string delimiter = "::";

						int index = 0;
						size_t pos = 0;
						std::string token;
						while ((pos = facilityLoc.find(delimiter)) != std::string::npos) {
							token = facilityLoc.substr(0, pos);
							if(index ==0){
								companyType=token;
							}

							facilityLoc.erase(0, pos + delimiter.length());
							if(index ==1){
								companyName=token;
							}
							index++;
						}
						if(index >1){
							country = facilityLoc;
						}

						tempStdCostRecord.toCompanyType=companyType;
						tempStdCostRecord.toCompany=companyName;
						tempStdCostRecord.toCountry=country;
						tempStdCostRecord.toCity=facilityName;
						tempStdCostRecords.push_back(tempStdCostRecord);
					}
					else
						sendResponseInfo(1, stdCostResponse,  FACILITY_LOC_IS_NULL);
				}
				else
				{
					sendResponseInfo(1, stdCostResponse,  FACILITY_NAME_IS_NULL);
				}
			}catch (const std::out_of_range& error) {
				std::cerr << error.what() << std::endl;
				sendResponseInfo(1, stdCostResponse,  error.what());
			}
			catch(...){
				sendResponseInfo(1, stdCostResponse,  EXCP_ERR_TO_GET_FACTY_AND_LOC);
			}
		} 

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_ERR);
	}
}

//Compare with the two same input facility records
int  stdCostRecordCompare(TIAStandardCostRecords r1, TIAStandardCostRecords r2) {
	if(r1.facility == r2.facility){
		return 0;
	}
	else
		return -1;	
}

/****************************************************************
//
//  Function Name: parseFacilityMappingLOV()
//
//  Description:  Getting the facilityName & facilityCode from tc. based on lov name.
//                   
//  Parameters:  lovName -> T8_t1aERPPLMFacilityCodeMapping
                 stdCostResponse -> passing the stdCostResponseInfo structure.					

//  Return Value:  facilityCodeNameMap
//                   
*****************************************************************/

map<string, string>  parseFacilityMappingLOV(string lovName, TITCERPIntegration::GetStandardCostResponse &stdCostResponse){

	int iFail      = ITK_ok;
	int iNumCunt   = 0;
	int iReturnCnt = 0;

	tag_t* tLov		  = NULLTAG;
	tag_t tlovObject  = NULLTAG;

	char** cLovValues = NULL;

	map<string, string> facilityCodeNameMap;

	try{
		ERROR_CALL(iFail = LOV_find(lovName.c_str(), &iNumCunt, &tLov));

		for(int i=0; i<iNumCunt; i++) {

			ERROR_CALL(iFail = LOV_ask_values_string(tLov[i], &iReturnCnt, &cLovValues));
		}

		char **values = NULL;

		values = (char **)malloc(sizeof(char *) * 4);

		values[0] = (char *)malloc(sizeof(char) * 100);
		values[1] = (char *)malloc(sizeof(char) * 100);
		values[2] = (char *)malloc(sizeof(char) * 100);
		values[3] = (char *)malloc(sizeof(char) * 100);

		strcpy(values[0],"Caro:Caro/Aftermarket:BPCS 8.2:42:North America:Pump and Module Systems:ABCD:Prototype");
		//strcpy(values[1],"argentina:Caro/Aftermarket:BPCS 8.2:43:North America:Pump and Module Systems:ABCD:Prototype");
		strcpy(values[2],"Ossian:Ossian:BPCS 8.2:47:North America:Tank Systems:IJKL:Production Released,Production Launched");
		//strcpy(values[3],"Greeneville:Greeneville:BPCS 8.2:50:North America:Pump and Module Systems:Toyota - 321A/322A,Toyota - 953A,Toyota - 767L:Prototype,Production Released,Production Launched");

		std::string facilityName ="";
		std::string facilityCode ="";
		for(int i=0; i<4; i++){

			char * pch;
			pch = strtok (values[i],":");

			int index = 0;
			while (pch != NULL)
			{
				//printf ("%s\n",pch);
				if(index==0) {
					facilityName = pch;
				}  
				if(index==3){
					facilityCode = pch;
				}

				pch = strtok (NULL, ":");
				index++;
			}

			facilityCodeNameMap.insert(pair<string, string>(facilityCode,
				facilityName));
			free(values[i]);
		}

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_PARSE_FACTY_MAP_LOV);
		//TC_write_syslog(EXCEPTION_PARSE_FACILITY_MAPPING_LOV);
	}

	return facilityCodeNameMap;
}

/****************************************************************
//
//  Function Name: parseCascadingLOV()
//
//  Description:  Getting the facilityLocationMap values from tc. based on lov name.
//                   
//  Parameters: sLovName -> t1aTICompanies
                sParent -> TI 
                stdCostResponse -> passing the stdCostResponseInfo structure.

// Return Value: facilityInfoMap
//                   
*****************************************************************/

map<string, string>  parseCascadingLOV(string sLovName,string sParent, TITCERPIntegration::GetStandardCostResponse &stdCostResponse){

	int iFail      = ITK_ok;
	int iNumCunt   = 0;

	tag_t* tLov		   = NULLTAG;
	int count=0;

	map<string, string> facilityInfoMap;

	try{
		ERROR_CALL(iFail = LOV_find(sLovName.c_str(), &iNumCunt, &tLov));

		if(iNumCunt !=0) {

			for(int i=0; i<iNumCunt; i++) {
				parsingCascadingLOV(tLov[0], sParent,facilityInfoMap, stdCostResponse);
			}
		}

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_PARSE_CASCADEING_LOV);
	}

	return facilityInfoMap;
}


map<string, string>  parsingCascadingLOV(tag_t tLov, string sParent,map<string, string> &facilityInfoMap, TITCERPIntegration::GetStandardCostResponse &stdCostResponse) {

	int iFail           = ITK_ok;
	int iFilterReCont   = 0;
	int *iFilterArryCnt = 0;
	int iNumValuesCnt   = 0;

	tag_t *tListOFFilterObj = NULLTAG;

	char** listOfValues        = NULL;

	try{
		ERROR_CALL(iFail = LOV_ask_values_string(tLov, &iNumValuesCnt, &listOfValues));

		ERROR_CALL(iFail = LOV_ask_value_filters(tLov,&iFilterReCont, &iFilterArryCnt, &tListOFFilterObj));

		for(int i=0; i<iNumValuesCnt; i++) {
			if(iFilterReCont == 0) {

				facilityInfoMap.insert(pair<string, string>(listOfValues[i],sParent ));
			}
			else{
				if(sParent != ""){
					parsingCascadingLOV( tListOFFilterObj[i],  sParent+"::"+listOfValues[i],facilityInfoMap, stdCostResponse);

				}else{
					parsingCascadingLOV( tListOFFilterObj[i], listOfValues[i],facilityInfoMap,stdCostResponse);
				}
			}
		}
	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_PARSE_CASCADEING_LOV);
		TC_write_syslog(EXCP_PARSE_CASCADEING_LOV);
	}
	return facilityInfoMap;
}


vector<TIAStandardCostRecords>  standardCostRecords(vector<TIAStandardCostRecords> vcStdCostRecords){

	StandardCostImportInputInfo costImportInfo;
	costImportInfo.sCostID="11223366";
	costImportInfo.sItemID="000035";
	costImportInfo.sItemRevID="AC";
	costImportInfo.sBPCSItemID="DNAB0001AAF60";
	costImportInfo.sItemDesc="SLEEVE";
	costImportInfo.sExtraDesc="Insert- Post";
	costImportInfo.addVectorStruct=vcStdCostRecords;


	//Main Structure
	StandardCostImportInputMain costImportInfoMain;
	//adding structures in Vector(structures)
	costImportInfoMain.vcStdCostRecordsMain.push_back(costImportInfo);


	vcStdCostRecords.push_back(TIAStandardCostRecords());
	vcStdCostRecords[0].costSet="02";
	vcStdCostRecords[0].facility="42";
	vcStdCostRecords[0].currentCost="22.28009";
	vcStdCostRecords[0].quantity="1.000";
	vcStdCostRecords[0].costBucket="000";
	vcStdCostRecords[0].stockingUofM="EA";
	vcStdCostRecords[0].RecordId="CF";
	vcStdCostRecords[0].currency="USD";
	vcStdCostRecords[0].partNumber="000035";
	vcStdCostRecords[0].partRevision="AC";

	vcStdCostRecords.push_back(TIAStandardCostRecords());
	vcStdCostRecords[1].costSet="02";
	vcStdCostRecords[1].facility="42";
	vcStdCostRecords[1].currentCost="0.00000";
	vcStdCostRecords[1].quantity="1.000";
	vcStdCostRecords[1].costBucket="001";
	vcStdCostRecords[1].stockingUofM="EA";
	vcStdCostRecords[1].RecordId="CF";
	vcStdCostRecords[1].currency="USD";
	vcStdCostRecords[1].partNumber="000035";
	vcStdCostRecords[1].partRevision="AC";


	vcStdCostRecords.push_back(TIAStandardCostRecords());
	vcStdCostRecords[2].costSet="02";
	vcStdCostRecords[2].facility="47";
	vcStdCostRecords[2].currentCost="1.89723";
	vcStdCostRecords[2].quantity="1.000";
	vcStdCostRecords[2].costBucket="002";
	vcStdCostRecords[2].stockingUofM="EA";
	vcStdCostRecords[2].RecordId="CF";
	vcStdCostRecords[2].currency="USD";
	vcStdCostRecords[2].partNumber="000039";
	vcStdCostRecords[2].partRevision="AA";


	vcStdCostRecords.push_back(TIAStandardCostRecords());
	vcStdCostRecords[3].costSet="02";
	vcStdCostRecords[3].facility="47";
	vcStdCostRecords[3].currentCost="1.87483";
	vcStdCostRecords[3].quantity="1.000";
	vcStdCostRecords[3].costBucket="003";
	vcStdCostRecords[3].stockingUofM="EA";
	vcStdCostRecords[3].RecordId="CF";
	vcStdCostRecords[3].currency="USD";
	vcStdCostRecords[3].partNumber="000039";
	vcStdCostRecords[3].partRevision="AA";

	vcStdCostRecords.push_back(TIAStandardCostRecords());
	vcStdCostRecords[4].costSet="02";
	vcStdCostRecords[4].facility="45";
	vcStdCostRecords[4].currentCost="1.15023";
	vcStdCostRecords[4].quantity="1.000";
	vcStdCostRecords[4].costBucket="004";
	vcStdCostRecords[4].stockingUofM="EA";
	vcStdCostRecords[4].RecordId="CF";
	vcStdCostRecords[4].currency="USD";
	vcStdCostRecords[0].partNumber="000035";
	vcStdCostRecords[0].partRevision="AC";

	return vcStdCostRecords;
}

/****************************************************************
//
//  Function Name: importData()
//
//  Description: This function, searching the part number & rev id in tc based on the input.
                 then checking corresponding itemRevId, standardCostForm existing or not.
                 if it's not existing then create new standardCostForm, else revise standardCostForm.
//                   
//  Parameters: stdCostResponse -> passing the stdCostResponseInfo structure.

//  Return Value:    none
//                   
*****************************************************************/
void  importData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, vector<TIAStandardCostRecords> tempStdCostRecords) {

	int iFail             = ITK_ok,
		itemRevisionCount = 0,
		iSecObjCunt       = 0;

	tag_t tItemRevisionQuery  = NULLTAG,
		*tItemRevList        = NULLTAG,
		tRelationType        = NULLTAG,
		*tSecondaryObjects   = NULLTAG,
		tItemID              = NULLTAG;

	/*char *partNumber  = "000039", //000035
	*partRev     = "AA",
	*cSiteName   = NULL;*/

	//cout<<"partNumber"<<partNumber;
	//tc_strncpy(partNumber,"000035",ITEM_id_size_c + 1);

	//char itemRevisionName[ITEM_name_size_c + 1] = "";
	//char itemRevisionID[ITEM_id_size_c + 1] = "";

	//string partNumber =costImportInfo.sItemID;
	//string partRev =costImportInfo.sItemRevID;

	try{

		/*map<char*, char*> mTestInputParts = mapTestInput();

		for (auto itr = mTestInputParts.begin(); itr != mTestInputParts.end(); ++itr) {
			char* partNumber = itr->first;
			char* partRev = itr->second;*/
		for (int iCnt = 0; iCnt < tempStdCostRecords.size(); iCnt++) {

			string partNum =tempStdCostRecords[iCnt].partNumber;
			string revId = (tempStdCostRecords[iCnt].partRevision);

			 char* partNumber = (char*)partNum.c_str();
			 char* partRev  = (char*)revId.c_str();
			//----------------------------------------------------------------------
			char *attributeNames[3] = {"Item ID","Revision","Type"},
				*attributeValues[3] =  {partNumber,partRev,ITEM_REVISION_TYPE_COST_FORM_CREATION}; 

			ERROR_CALL(iFail = QRY_find2("Item Revision...", &tItemRevisionQuery));

			//checking part number inside the Teamcenter
			if(partNumber != NULL){

				if(partRev != NULL){

					ERROR_CALL(iFail = ITEM_find_item(partNumber, &tItemID));

					if(tItemID != NULLTAG && iFail == 0) {

						ERROR_CALL(iFail = ITEM_find_revisions(tItemID,partRev,&itemRevisionCount,&tItemRevList));
						/*cout<<"error before executing qry======"<<iFail<<endl;
						TC_write_syslog("error before executing qry ");
						ERROR_CALL(iFail = QRY_execute(tItemRevisionQuery, 1, attributeNames, attributeValues, &itemRevisionCount, &tItemRevList));
						TC_write_syslog("error after executing qry======== ");
						cout<<"error======"<<iFail<<endl;*/
						if(itemRevisionCount !=0 && iFail == 0) {

							//ERROR_CALL(iFail = AOM_ask_value_string(tItemRevList[0],"owning_site", &cSiteName));

							//if(cSiteName != NULL){

							ERROR_CALL(iFail = GRM_find_relation_type(TI_COST_FORMS, &tRelationType));
							ERROR_CALL(iFail = GRM_list_secondary_objects_only(tItemRevList[0],tRelationType, &iSecObjCunt,  &tSecondaryObjects ));

							if(iSecObjCunt>0){
								//saveAS
								costFormRevise(iSecObjCunt, tSecondaryObjects, stdCostResponse);
								sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS);
								//stdCostResponse.itemID = partNumber;
								//stdCostResponse.itemRevID = partRev;

							}else{

								createNewForm(tRelationType, tItemRevList[0],stdCostResponse, tempStdCostRecords, iCnt);
								sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS);
								//stdCostResponse.itemID = partNumber;
								//stdCostResponse.itemRevID = partRev;
							}

							//}
							//else{
							//TC_write_syslog("Unable to update Cost data for the Part \""/* partNumber*/"\": Remote Object");
							//}
						}
						else{
							sendResponseInfo(1, stdCostResponse,  REV_ID_NOT_FOUND_IN_TC);
							//stdCostResponse.itemID = partNumber;
							//stdCostResponse.itemRevID = partRev;
						}
					}
					else{
						sendResponseInfo(1, stdCostResponse,  PART_ID_NOT_FOUND_IN_TC);
						//stdCostResponse.itemID = partNumber;
						//stdCostResponse.itemRevID = partRev;
					}


				}
				else{
					//checking the part number against alternate id                
				}
			}
			else{
				/*string sImportStatus = "Fail";
				string sReasonForFailure = "Unable to find the partNumber as a input";
				getResponseInfo(stdCostResponse,  sImportStatus,  sReasonForFailure, partNumber, partRev);*/

				sendResponseInfo(1, stdCostResponse,  PART_NUM_NOT_PASSED_AS_ARG);
			}
			//--------------------------------------------------------------------
		} //For loop


	}
	catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_ERR);
	}

	MEM_free(tSecondaryObjects);
	MEM_free(tItemRevList);
}

/****************************************************************
//
//  Function Name: createNewForm()
//
//  Description:  Creating the New StandardCost Form...

//  Parameters:   tRelationType -> TI_CostForms
                  tItemRev -> three type of itemRev
                  stdCostResponse -> passing the stdCostResponseInfo structure.				
//                   
*****************************************************************/


int  createNewForm(tag_t tRelationType, tag_t tItemRev,TITCERPIntegration::GetStandardCostResponse &stdCostResponse,vector<TIAStandardCostRecords> tempStdCostRecords, int index) {

	int iFail = ITK_ok;

	tag_t   tForm      = NULLTAG,
		tFormInput = NULLTAG,
		tFormObj   = NULLTAG,
		tGrmRelation = NULLTAG;

	try {
		ERROR_CALL(iFail = TCTYPE_find_type(STANDARD_COST_FORM_TYPE,FORM_CLASS,&tForm));

		ERROR_CALL(iFail = TCTYPE_construct_create_input(tForm, &tFormInput));
		/*
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,ATTRIBUTE_NAME,"StandardCostForm1"));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COMPANY_TYPE,"TI"));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COMPANY,"TI Automotive"));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COUNTRY,"Brazil"));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_CITY,"Juatuaba")); */
		
		//ERROR_CALL(iFail = AOM_set_value_string(tFormInput,ATTRIBUTE_NAME,"StandardCostForm"));
		char* toCompanyType = (char*)tempStdCostRecords[index].toCompanyType.c_str();
		char* toCompany = (char*)tempStdCostRecords[index].toCompany.c_str();
		char* toCountry = (char*)tempStdCostRecords[index].toCountry.c_str();
		char* toCity =(char*)tempStdCostRecords[index].toCity.c_str();
		char* laborCost =(char*)tempStdCostRecords[index].laborCost.c_str();
		char* materialCost =(char*)tempStdCostRecords[index].materialCost.c_str();
		char* totalCost = (char*)tempStdCostRecords[index].totalCost.c_str();
		char* scrapPercentage = (char*)tempStdCostRecords[index].scrapPercentage.c_str();

		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COMPANY_TYPE,toCompanyType));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COMPANY,toCompany));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_COUNTRY,toCountry));
		ERROR_CALL(iFail = AOM_set_value_string(tFormInput,TO_CITY,toCity)); 
	/*	if(laborCost != NULL)
			ERROR_CALL(iFail = AOM_set_value_string(tFormInput,"t8_t1a149laborcost",laborCost));
		if(materialCost != NULL)
			ERROR_CALL(iFail = AOM_set_value_string(tFormInput,"t8_t1a149materialcost",materialCost));
		if(totalCost != NULL)
			ERROR_CALL(iFail = AOM_set_value_string(tFormInput,"t8_t1a149totalcost",totalCost));
		if(scrapPercentage != NULL)
			ERROR_CALL(iFail = AOM_set_value_string(tFormInput,"t8_t1a149scrappercentage",scrapPercentage));*/

		ERROR_CALL(iFail = TCTYPE_create_object(tFormInput, &tFormObj)); 

		ERROR_CALL(iFail = AOM_save(tFormObj));
		ERROR_CALL(iFail = AOM_refresh(tFormObj,0));

		ERROR_CALL(iFail = GRM_create_relation(tItemRev,tFormObj,tRelationType,NULLTAG,&tGrmRelation));
		ERROR_CALL(iFail = GRM_save_relation(tGrmRelation));
		ERROR_CALL(iFail = AOM_refresh(tGrmRelation,0));

		TI_add_rev_status_to_secondary(tItemRev,tFormObj,NULL);

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_ERR_CREATE_NEW_SCF);
	}

	if(iFail == ITK_ok)
		sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS);


	return iFail;
}

/****************************************************************
//
//  Function Name:   costFormRevise()
//
//  Description:      it's revising the existing StandardCost Form...

//  Parameters:      iSecObjCunt -> stdCostForm count
                     tSecondaryObjects -> stdCostForm
                     stdCostResponse -> passing the stdCostResponseInfo structure.				

//  Return Value:    none
//                   
*****************************************************************/

int  costFormRevise(int iSecObjCunt, tag_t *tSecondaryObjects, TITCERPIntegration::GetStandardCostResponse &stdCostResponse) {

	int iFail = ITK_ok,
		iFCount = 0;

	tag_t	tForm			 = NULLTAG,
		tSaveAsInput         = NULLTAG,
		tTargetCopyObj       = NULLTAG,
		tObjectType          = NULLTAG,
		tHistoryRelationType = NULLTAG,
		tHistoryForm         = NULLTAG,
		tClass		         = NULLTAG,
		tObjName	       	 = NULLTAG,
		*tSecFormObject      = NULLTAG;

	char *cObjectType      = NULL,
		*pcClassName	   = NULL,
		*cFormName         = NULL,
		*retainReleaseDate = NULL;;

	logical verdict		= false;

	try{
		ERROR_CALL(iFail = TCTYPE_find_type(STANDARD_COST_FORM_TYPE,FORM_CLASS,&tForm));

		for(int iCnt=0; iCnt<iSecObjCunt; iCnt++){

			ERROR_CALL(iFail = TCTYPE_ask_object_type(tForm, &tObjectType));
			ERROR_CALL(iFail = TCTYPE_construct_saveasinput(tForm, &tSaveAsInput));

			ERROR_CALL(iFail = WSOM_ask_object_type2(tSecondaryObjects[iCnt], &cObjectType));

			if(tc_strcmp(cObjectType,STANDARD_COST_FORM_TYPE)==0) {

				logical bExisting = costFormReviseCondition(tSecondaryObjects[iCnt]/*,tempRecords*/);

				if(bExisting == true) {

					ERROR_CALL(iFail = TCTYPE_saveas_object(tSecondaryObjects[iCnt],tSaveAsInput,0,NULL, &tTargetCopyObj));
					ERROR_CALL(iFail = AOM_save(tTargetCopyObj));
					ERROR_CALL(iFail = AOM_refresh(tTargetCopyObj,0));

					ERROR_CALL(iFail = GRM_find_relation_type(FORM_HISTORY_RELATION, &tHistoryRelationType));

					ERROR_CALL(iFail = GRM_list_secondary_objects_only(tSecondaryObjects[0],tHistoryRelationType, &iFCount,  &tSecFormObject));
					ERROR_CALL(iFail = AOM_ask_value_string(tTargetCopyObj,STD_COST_FORM_TO_CITY_ATTR,&cFormName));

					ERROR_CALL(iFail = POM_is_loaded(tTargetCopyObj, &verdict));
					if (verdict == TRUE && iFail == ITK_ok)
					{
						ERROR_CALL(iFail = POM_unload_instances(1, &tTargetCopyObj));
					}

					ERROR_CALL(iFail = POM_load_instances_any_class(1, &tTargetCopyObj, POM_modify_lock));
					ERROR_CALL(iFail = POM_class_of_instance (tTargetCopyObj, &tClass));
					ERROR_CALL(iFail = POM_name_of_class (tClass, &pcClassName));
					ERROR_CALL(iFail = POM_attr_id_of_attr(ATTRIBUTE_NAME, pcClassName, &tObjName));

					string s = to_string(iFCount);
					char const *pchar = s.c_str();
					char* str = ";";
					char * strTemp = (char *) malloc(1 + strlen(cFormName)+ strlen(str)+strlen(pchar));
					strcpy(strTemp, cFormName);
					strcat(strTemp, str);
					strcat(strTemp, pchar);

					ERROR_CALL(iFail = POM_set_attr_string(1, &tTargetCopyObj, tObjName, strTemp ));
					ERROR_CALL(iFail = POM_save_instances(1, &tTargetCopyObj, FALSE));
					ERROR_CALL(iFail = POM_refresh_instances_any_class(1, &tTargetCopyObj, POM_no_lock));

					ERROR_CALL(iFail = GRM_create_relation(tSecondaryObjects[iCnt],tTargetCopyObj,tHistoryRelationType,NULLTAG,&tHistoryForm));
					ERROR_CALL(iFail = GRM_save_relation(tHistoryForm));
					ERROR_CALL(iFail = AOM_refresh(tHistoryForm,0));

					ERROR_CALL(iFail = AOM_ask_value_string(tTargetCopyObj,"date_released", &retainReleaseDate));

					TI_add_rev_status_to_secondary(tSecondaryObjects[iCnt],  tHistoryForm, retainReleaseDate);
				}	
			}
		}

		MEM_free(tSecFormObject);

	}catch(...){
		sendResponseInfo(1, stdCostResponse,  EXCP_ERR_REVISE_SCF);
	}
	if(iFail == ITK_ok)
		sendResponseInfo(0, stdCostResponse,  SUCCESS_STATUS);

	return iFail;
}

/****************************************************************
//
//  Function Name:   costFormReviseCondition()
//
//  Description:      To checking condation for revising StandardCost Form.

//  Parameters:     tSecondaryObjects -> stdCostForm
                   vcTempRecordList -> after process data.

//  Return Value:    formExistPro = true or false
//                   
*****************************************************************/


logical  costFormReviseCondition(tag_t tSecondaryObjects /*vector<TIAStandardCostRecords> vcTempRecordList */ ){
	logical formExistPro = false;

	int iFail = ITK_ok;
	char *erpIntegration = NULL,
		*toCity         = NULL;
	try{
		//ERROR_CALL(iFail = AOM_ask_value_string(tSecondaryObjects, ERP_INTEGATION_ATTR_STD_PART, &erpIntegration));
		ERROR_CALL(iFail = AOM_ask_value_string(tSecondaryObjects, STD_COST_FORM_TO_CITY_ATTR, &toCity));

		if(tc_strcasecmp(toCity,"Kilburn")==0 /*&& tc_strcasecmp(erpIntegration,"")==0*/){   //Juatuaba  , Gravatai, Kilburn
			return formExistPro = true;
		}
	}catch(...){
	}
	return formExistPro;
}


/****************************************************************
//
//  Function Name:   TI_add_rev_status_to_secondary()
//
//  Description:     setting the release status to new form of the existing form

//  Parameters:     tag_t tItemRev,
                    tag_t tCostForm,
                    char* retainReleaseDate 							

//  Return Value:    none
//                   
*****************************************************************/

int  TI_add_rev_status_to_secondary(tag_t tItemRev, tag_t tCostForm, char* retainReleaseDate) {

	int	iNoOfRelStatus		= 0,
		iFail			    = ITK_ok;

	char   *classid_s			= NULL;

	tag_t *ptReleaseStatus	 = NULLTAG,
		object_classID		 = NULLTAG,
		object_reldateID     = NULLTAG,
		object_relStatListID = NULLTAG;

	logical	lValid_date = true,
		verdict     = false;

	date_t dateVal = NULLDATE;
	time_t rawtime;
	struct tm * timeinfo;
	SYSTEMTIME str_t;
	time_t timeObj;


	time ( &rawtime );
	timeinfo = localtime ( &rawtime );

	//create the item based on the input data
	ERROR_CALL(iFail = ITK_set_bypass(true));
	ERROR_CALL(iFail = AOM_ask_value_tags(tItemRev,"release_status_list",&iNoOfRelStatus,&ptReleaseStatus));

	if(iNoOfRelStatus>=0 && ptReleaseStatus != NULL)
	{

		if(retainReleaseDate== NULL)
		{
			ERROR_CALL(iFail = POM_class_of_instance(tCostForm, &object_classID));
			if ( iFail == ITK_ok && object_classID!=NULLTAG)
			{
				ERROR_CALL(iFail = POM_name_of_class(object_classID,&classid_s));
			}
			if ( iFail == ITK_ok )
			{
				//iFail = AOM_ask_value_date(tItemRev,"date_released", &dateVal);
				//printf(asctime(timeinfo));

				dateVal.day = timeinfo->tm_mday;
				dateVal.hour = timeinfo->tm_hour;
				dateVal.minute = timeinfo->tm_min;
				dateVal.month = timeinfo->tm_mon;
				dateVal.second = timeinfo->tm_sec;
				dateVal.year = timeinfo->tm_year+1900;

				//printf(" IFail=%d",iFail);
				ERROR_CALL(iFail = POM_attr_id_of_attr("date_released",classid_s,&object_reldateID));
				ERROR_CALL(iFail = POM_attr_id_of_attr("release_status_list",classid_s,&object_relStatListID));

				if ( iFail == ITK_ok )
				{
					ERROR_CALL(iFail = POM_is_loaded(tCostForm, &verdict));
				}
				if (verdict == TRUE && iFail == ITK_ok)
				{
					ERROR_CALL(iFail=POM_unload_instances(1, &tCostForm));
				}
				//Modifying the values of the new form
				if (iFail == ITK_ok)
				{
					ERROR_CALL(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				}
				ERROR_CALL(iFail = POM_clear_attr	( 1, &tCostForm, object_relStatListID));
				ERROR_CALL(iFail = EPM_add_release_status(ptReleaseStatus[0],1,&tCostForm,false));
				ERROR_CALL(iFail = POM_unload_instances(1, &tCostForm));
				ERROR_CALL(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				ERROR_CALL(iFail = POM_set_attr_date(1, &tCostForm, object_reldateID, dateVal));

				if (iFail == ITK_ok)
				{
					ERROR_CALL(iFail = POM_save_instances(1, &tCostForm, FALSE));
				}
			}
		}
		else
		{
			ERROR_CALL(iFail = AOM_ask_value_date(tItemRev,"date_released", &dateVal));
			ERROR_CALL(iFail = POM_class_of_instance(tCostForm, &object_classID));
			if ( iFail == ITK_ok && object_classID!=NULLTAG)
			{
				ERROR_CALL(iFail = POM_name_of_class(object_classID,&classid_s));
			}
			if ( iFail == ITK_ok )
			{
				ERROR_CALL(iFail = POM_attr_id_of_attr("date_released",classid_s,&object_reldateID));
				ERROR_CALL(iFail = POM_attr_id_of_attr("release_status_list",classid_s,&object_relStatListID));
				if ( iFail == ITK_ok )
				{
					ERROR_CALL(iFail = POM_is_loaded(tCostForm, &verdict));
				}
				if (verdict == TRUE && iFail == ITK_ok)
				{
					ERROR_CALL(iFail=POM_unload_instances(1, &tCostForm));
				}
				//Modifying the values of the new form
				if (iFail == ITK_ok)
				{
					ERROR_CALL(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				}
				ERROR_CALL(iFail = POM_clear_attr	( 1, &tCostForm, object_relStatListID));
				ERROR_CALL(iFail = EPM_add_release_status(ptReleaseStatus[0],1,&tCostForm,false));
				ERROR_CALL(iFail = POM_unload_instances(1, &tCostForm));
				ERROR_CALL(iFail = POM_load_instances_any_class(1, &tCostForm, POM_modify_lock));
				ERROR_CALL(iFail = POM_set_attr_date(1, &tCostForm, object_reldateID, dateVal));

				if (iFail == ITK_ok)
				{
					ERROR_CALL(iFail = POM_save_instances(1, &tCostForm, FALSE));
				}
			}
		}

	}
	EMH_clear_errors();
	MEM_free(ptReleaseStatus);
	return iFail;
}

/*
void  getResponseInfo(TITCERPExtension::GetStandardCostResponse &stdCostResponse, string sImportStatus, string sReasonForFailure, char* cItemID, char* cItemRevID) {

stdCostResponse.importStatus = sImportStatus;
stdCostResponse.reasonForFailure = sReasonForFailure;
stdCostResponse.itemID = "";
stdCostResponse.itemRevID = "";
stdCostResponse.costID ="";
stdCostResponse.bpcsItemID ="";

}*/


/****************************************************************
//
//  Function Name:   sendResponseInfo()
//
//  Description:     it's sending the success & failure responseInfo to the server.

//  Parameters:     iStatusCode -> 0 -> success & 1-> failure
                    stdCostResponse -> passing the stdCostResponseInfo structure 
                    sReasonForFailure -> reason for failure(msg).							

//  Return Value:    none
//                   
*****************************************************************/

void  sendResponseInfo(int iStatusCode, TITCERPIntegration::GetStandardCostResponse &stdCostResponse, string sReasonForFailure){
	
	TITCERPIntegration::StandardCostResponse localCostResponse;
	stdCostResponse.standardCostResponse.push_back(localCostResponse);

	if(iStatusCode == 0) {
		localCostResponse.importStatus = SUCCESS_STATUS;
		localCostResponse.reasonForFailure ="";
	}else{
		localCostResponse.importStatus = ERR_FAIL_STATUS;
		localCostResponse.reasonForFailure = sReasonForFailure;
	}

}

map<char*, char*> mapTestInput()
{

	map<char*, char*> mTestInputPart;
	mTestInputPart.insert(pair<char*, char*>("000035","AC"));
	mTestInputPart.insert(pair<char*, char*>("000039","AA"));
	return mTestInputPart;
}