# ifndef TI_STANDARD_COST_DATA_IMPORT_HEADER
# define TI_STANDARD_COST_DATA_IMPORT_HEADER

//#include <titcerpextension1811.hxx> //Add the header file name in BMIDE
#include<titcerpintegration1811.hxx>
#include "TI_Common.hxx"
#include "TI_StandardCostRecord.cxx"

#ifdef _WIN32
#define EXTERN_DLL extern __declspec(dllexport)
#define EXTERNCLASS __declspec(dllexport)
#else
#define EXTERN_DLL extern
#define EXTERNCLASS
#endif


using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server; //Use the namespace from BMIDE code

EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration ::GetStandardCostResponse tiStandardCostTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost);
//EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration ::GetStandardCostResponse importStandardCostInfo(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost);




#define FACILITY_CODE_NAME_MAPPING_LOV                   "T8_t1aERPPLMFacilityCodeMapping"
#define COMPANY_LOV_NAME                                 "t1aTICompanies"
#define ITEM_REVISION_TYPE_COST_FORM_CREATION            "TI_Product Revision,TI_Prg_Variant Revision,TI_Material Revision"
#define STANDARD_COST_FORM_TYPE                          "T8_TI_StandardCost"
#define ERP_INTEGATION_ATTR_STD_PART                     "t8_t1a149erpintegration"
#define STD_COST_FORM_TO_CITY_ATTR                       "t8_t1a149tocity"
#define FORM_HISTORY_RELATION                            "TI_FormHistory"
#define STANDARD_COST_FORM                               "StandardCostForm"
#define TI_COST_FORMS                                    "TI_CostForms"
#define FORM_CLASS                                       "Form"
#define ATTRIBUTE_NAME                                   "object_name"

#define TO_COMPANY_TYPE                                  "t8_t1a149tocompanytype"
#define TO_COMPANY                                      "t8_t1a149tocompany"
#define TO_COUNTRY                                      "t8_t1a149tocountry"
#define TO_CITY                                         "t8_t1a149tocity"


#define STANDARD_PROPERTY "MaterialCost:t8_t1a149materialcost<overwrite>,LaborCost:t8_t1a149laborcost<overwrite>,VariableOverHeadCost:t8_t1a149varoverheadcost<overwrite>,ScrapPercentage:t8_t1a149scrappercentage<overwrite>,\
ERPIntegration:t8_t1a149erpintegration<overwrite>,Currency:t8_t1a149currency<overwrite>,FixedOverHeadCost:t8_t1a149fixedoverheadcost<overwrite>,TotalCost:t8_t1a149totalcost<overwrite>,DutyCost:t8_t1a149dutycost<overwrite>,\
FreightCost:t8_t1a149freightcost<overwrite>,ToCompanyName:t8_t1a149tocompany<overwrite>,ToCountry:t8_t1a149tocountry<overwrite>,ToCity:t8_t1a149tocity<overwrite>,ToCompanyType:t8_t1a149tocompanytype<overwrite>,Description:object_desc<overwrite>"



int  getCurrentSiteID();
map<string, string>  getAttributeMappingValues(TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
void  processStandardCostData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, vector<struct TIAStandardCostRecords> vcStdCostRecords, vector<struct TIAStandardCostRecords> &tempStdCostRecords);
map<string, string>  parseFacilityMappingLOV(string lovName,TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
int  stdCostRecordCompare(TIAStandardCostRecords r1, TIAStandardCostRecords r2);
map<string, string>  parseCascadingLOV(string sLovName,string sParent, TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
map<string, string>  parsingCascadingLOV(tag_t tLov, string sParent,map<string, string> &facilityInfoMap, TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
int  createNewForm(tag_t tRelationType, tag_t tLatestRevItem,TITCERPIntegration::GetStandardCostResponse &stdCostResponse, vector<TIAStandardCostRecords> tempStdCostRecords, int index);
int  costFormRevise(int iSecObjCunt, tag_t *tSecondaryObjects,TITCERPIntegration::GetStandardCostResponse &stdCostResponse);
logical  costFormReviseCondition(tag_t tSecondaryObjects /*vector<TIAStandardCostRecords> vcTempRecordList */ );
int  TI_add_rev_status_to_secondary(tag_t tItemRev, tag_t tCostForm, char* retainReleaseDate) ;
vector<TIAStandardCostRecords>  standardCostRecords(vector<TIAStandardCostRecords> vcStdCostRecords);

void  importData(TITCERPIntegration::GetStandardCostResponse &stdCostResponse, vector<TIAStandardCostRecords> tempStdCostRecords);
//TITCERPExtension::GetStandardCostResponse stdCostResponse;
//vector<TITCERPExtension::GetStandardCostResponse> static getResponseInfo();
//void static getResponseInfo(TITCERPExtension::GetStandardCostResponse &stdCostResponse, string sImportStatus, string sReasonForFailure, char* sItemID, char* sItemRevID);
void  sendResponseInfo(int iStatusCode, TITCERPIntegration::GetStandardCostResponse &stdCostResponse, string sReasonForFailure);

map<char*, char*> mapTestInput();

#endif