#ifndef TI_STANDARD_COST_DATA_IMPORT
#define TI_STANDARD_COST_DATA_IMPORT

#include "TI_StandardCost.hxx"
#include "TI_Common.hxx"


TITCERPIntegration::GetStandardCostResponse stdCostResponse;

EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostResponse tiStandardCostTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost)
//EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostResponse importStandardCostInfo(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost)
{
	/*TITCERPIntegration::StandardCostResponse localCostResponse;
	localCostResponse.itemID ="000035";
	stdCostResponse.standardCostResponse.push_back(localCostResponse);*/
	// getCurrentSiteID();


	//Getting StandartCost mapping attributes from header file
	map<string, string> stdCostAttrMap = getAttributeMappingValues(stdCostResponse);

	vector<TIAStandardCostRecords> vcStdCostRecords;

	//Getting StandardCost records from input.
	vcStdCostRecords = standardCostRecords(vcStdCostRecords);

	vector<TIAStandardCostRecords> tempStdCostRecords;
	//Processing the input data & parsing the lov values.
	try{
		if(vcStdCostRecords.size() !=0){
			processStandardCostData(stdCostResponse, vcStdCostRecords, tempStdCostRecords);
		}
	}catch(...){}

	//Creating, revising & updating the cost form.
	importData(stdCostResponse, tempStdCostRecords );


	return stdCostResponse;
}

#endif