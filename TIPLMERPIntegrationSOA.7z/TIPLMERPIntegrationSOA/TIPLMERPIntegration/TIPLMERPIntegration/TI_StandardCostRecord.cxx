#include"TI_Common.hxx"



using namespace std;


struct TIAStandardCostRecords {

	string partNumber;
	string partRevision;
	string RecordId;
	string facility ;
	string costSet;
	string costBucket;
	string currentCost;
	string quantity;
	string stockingUofM;
	string currency ;
	string toCompanyType;
	string toCompany ; 
	string toCountry; 
	string toCity; 
	string totalCost;
	string materialCost;
	string laborCost;
	string variableOverHeadCost;
	string fixedOverHeadCost;
	string scrapPercentage;
	string dutyCost;
	string freightCost;
};

struct StandardCostImportInputInfo
{
	string  sCostID;
    string  sItemID;
	string  sItemRevID;
	string  sBPCSItemID;
	string  sItemDesc;
	string  sExtraDesc;
	vector< TIAStandardCostRecords >  addVectorStruct;

};

struct StandardCostImportInputMain
{
	
	vector< StandardCostImportInputInfo >  vcStdCostRecordsMain;

};

/*
struct stdCostImportResponseInfo { 

string  costID; 
string  itemID;
string  itemRevID; 
string  BPCSItemID; 
string  importStatus; 
string  reasonForFailure; 

}stdCostImpResponseStatus;*/

//TITCERPExtension::GetStandardCostResponse stdCostResponse;


struct TIAUpdatedCostRecord {

	string partNumber;
	string partRevision;
	string RecordId;
	string facility ;
	string costSet;
	string costBucket;
	string currentCost;
	string quantity;
	string stockingUofM;
	string currency ;
	string toCompanyType;
	string toCompany ; 
	string toCountry; 
	string toCity; 
	string totalCost;
	string materialCost;
	string laborCost;
	string variableOverHeadCost;
	string fixedOverHeadCost;
	string scrapPercentage;
	string dutyCost;
	string freightCost;
};
