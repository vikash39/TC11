
#ifndef TERADYNE_CONSTANTS_H
#define TERADYNE_CONSTANTS_H

#define TD_DATE_YMD_CONSTANT												"%Y-%m-%d %H:%M:%S"
#define TD_OBJECT_STRING												    "object_string"

#define TD_ITEM_ID_ATTR														"item_id"
#define TD_ITEM_REV_ID_ATTR													"item_revision_id"
#define TD_DESC_ATTR														"td4Description"
#define TD_STD_DESC_ATTR													"td4StandardDescription"
#define TD_COMM1_ATTR														"td4CommodityLevel1"
#define TD_ITEM_STATUS_ATTR													"td4ItemStatus"
#define TD_CBU_ATTR															"td4ControllingBussUnit"
#define TD_UNIT_TYPE														"uom_tag"
#define TD_PROJECT_NAME														"td4ProjectName"
#define TD_DATE_CREATED														"creation_date"
#define TD_DATE_MODIFIED													"last_mod_date"
#define TD_LSD																"lsd"
#define TD_HTS																"td4ECCN"
#define TD_ECCN																"td4HTS"
#define TD_INFODBA_USERNAME                                                 "infodba" 
#define TD_INFODBA_PASSWORD                                                  "p1m4ster" 
#define TD_INFODBA_GROUP                                                     "dba" 
#define TD_CONSUMER_LICENSE_LEVEL_TASK                                       "Consumer Access Level" 
#define TD_CONSUMER_LICENSE_TASK			                                 "Consumer Access" 

#define ES_URL																"http://127.0.0.1:2113/streams/part-test09"

//Constants for Error base
#define TERADYNE_ERROR_BASE													(EMH_USER_error_base+100)
#define TERADYNE_UNKNOWN_ERROR												(TERADYNE_ERROR_BASE + 1)

#endif