#include<query.h>
#include<teradyne_trace.h>
#include<teradyne_constants.h>
#include<teradyne_common.h>
#include<iostream>
#include <epm/epm.h>

int checkPendingTask(tag_t doTask, EPM_task_state_t currentState, tag_t tUser);
int ITK_user_main(int argc, char* argv[])
{
	int iStatus = ITK_ok;
	int iDoTaskCount =0;
	int nSignOffs =0;
	char *pcUserName =NULL;
	char *pcTaskName=NULL;
	tag_t tUser   = NULLTAG;
	tag_t tjobTag =NULLTAG;
	tag_t *tDoTasks ={NULLTAG};
	tag_t *signOffs =NULL;
    char* stringJobTag =NULL;
	char* stringState =NULL;
	bool foundTask=false;
    EPM_state_t taskState =EPM_unassigned;
	char *errorMessageString;
	char* __function__ = "ITK_user_main";
	TERADYNE_TRACE_ENTER();

	try {
		
		ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
        
		if((iStatus=ITK_init_module(TD_INFODBA_USERNAME,TD_INFODBA_PASSWORD,TD_INFODBA_GROUP)) == ITK_ok){
		  TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
		  printf("Login User => %s\n",pcUserName);
		  stringJobTag = ITK_ask_cli_argument("-zo=");

		  if(!stringJobTag){
			  printf("No process tag string passed\n");
			  ITK_exit_module(true);
			  return 1;
		  }

		  printf("Processing tag string passed ==> %s\n",stringJobTag);
		  if((iStatus = POM_string_to_tag(stringJobTag,&tjobTag)) !=ITK_ok){
		     printf("Error converting POM_string to tag \n");
			 return iStatus;
		  }
		

		
		     TERADYNE_TRACE_CALL(iStatus = EPM_get_type_tasks(tjobTag,eEPMDoTask,&iDoTaskCount,&tDoTasks), TD_LOG_ERROR_AND_THROW);
			  printf("Number of do tasks found %d \n",iDoTaskCount);
			  POM_AM__set_application_bypass(true);
			  for(int i=0; i<iDoTaskCount; i++)
			  {
				 TERADYNE_TRACE_CALL(iStatus = EPM_ask_name2(tDoTasks[i],&pcTaskName), TD_LOG_ERROR_AND_THROW);
				 printf("Name of Task ==> %s\n",pcTaskName); 

				 if(tc_strcmp(pcTaskName, TD_CONSUMER_LICENSE_LEVEL_TASK) ==0  || tc_strcmp(pcTaskName, TD_CONSUMER_LICENSE_TASK)==0)
				 {
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_state(tDoTasks[i],&taskState), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_state_string2(taskState,&stringState), TD_LOG_ERROR_AND_THROW); 
                     printf("Name of Task(either) ==> %s\n",pcTaskName);
					 printf("State of Task ==> %s\n",stringState);

					 int checker = checkPendingTask(tDoTasks[i], taskState, tUser);
					 printf("[checker value:] %d\n", checker);

					 if (checker == ITK_ok)
					 {
						 printf("Under the checker... \n");
						 //rechecking the State
						 TERADYNE_TRACE_CALL(iStatus = EPM_ask_state(tDoTasks[i], &taskState), TD_LOG_ERROR_AND_THROW);
						 TERADYNE_TRACE_CALL(iStatus = EPM_ask_state_string2(taskState, &stringState), TD_LOG_ERROR_AND_THROW);
						 printf("State of Task ==> %s\n", stringState);
						 if (taskState == EPM_started && taskState != EPM_completed)
						 {

							 printf("Performing complete task as infodba \n");
							 TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(tDoTasks[i], EPM_RESULT_Completed), TD_LOG_ERROR_AND_THROW);

							 TERADYNE_TRACE_CALL(iStatus = EPM_trigger_action(tDoTasks[i], EPM_complete_action, pcTaskName), TD_LOG_ERROR_AND_THROW);
							 printf("Successfully performing complete task ... \n");
							 break;
						 }
					 }
				 }
		  
			  }
			  POM_AM__set_application_bypass(false);
			  Custom_free(tDoTasks);
		  
		
		
		}
			
	}
	catch(...){
		printf("Unhandled exception occured %s",__function__);
		printf("Error Status Code  ==> %d\n",iStatus);

		EMH_ask_error_text(iStatus,&errorMessageString);
		printf("Error Message  ==> %s\n",errorMessageString);

		if(iStatus == ITK_ok){
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	iStatus=ITK_exit_module(true);
	return iStatus;
}

//check if the Pending task is successfully being started
int checkPendingTask( tag_t doTask, EPM_task_state_t currentState, tag_t tUser)
{
	int iStatus = ITK_ok;
	try
	{ 

		if (currentState != EPM_started && currentState != EPM_completed)
		{
			printf("[checkPendingTask] Starting the task \n");

			TERADYNE_TRACE_CALL(iStatus = EPM_assign_responsible_party(doTask, tUser), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = EPM_trigger_action(doTask, EPM_start_action, " "), TD_LOG_ERROR_AND_THROW);
			printf("[checkPendingTask] Successfully started task... \n");
			iStatus = ITK_ok;
		}
	}
	catch (...)
	{
		iStatus = TERADYNE_UNKNOWN_ERROR;
	}
		
	return iStatus;
}

