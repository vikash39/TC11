#include<teradyne_common.h>

bool gNULLPropertyExecution = false;

bool teradyne_is_workspace_object(tag_t tObjectTag)
{
	int   iStatus  = ITK_ok;
	tag_t tCalssId = NULLTAG ;
	tag_t tWSOTag = NULLTAG ;
	bool  isWSOMObject = false;

	const char * __function__    = "teradyne_is_workspace_object" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = POM_class_of_instance(tObjectTag,&tCalssId), TD_LOG_ERROR_AND_THROW);		
		TERADYNE_TRACE_CALL(iStatus = POM_class_id_of_class( "WorkspaceObject", &tWSOTag ), TD_LOG_ERROR_AND_THROW);   
		TERADYNE_TRACE_CALL(iStatus = POM_is_descendant( tWSOTag, tCalssId, &isWSOMObject ), TD_LOG_ERROR_AND_THROW);		
	}
	catch(...)
	{

	}
    return isWSOMObject;
}

int teradyne_ask_object_type(tag_t tObject, char** pcTypeName)
 {
	int iStatus                 = ITK_ok;
	tag_t tagObjType            = NULLTAG;

	const char * __function__    = "teradyne_ask_object_type" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_object_type( tObject,&tagObjType),TD_LOG_ERROR_AND_THROW );

			if (tagObjType != NULLTAG)
			{
				TERADYNE_TRACE_CALL ( iStatus = TCTYPE_ask_name2( tagObjType, pcTypeName ),TD_LOG_ERROR_AND_THROW );
			}			
		}
	}
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}

int teradyne_getproperty_values(tag_t tRevTag,std::list<string> strAttr,std::map<string,string> &strPropNameValueMap) 
 {
	//Declartion and Initialization of Local Variables
	int   iStatus           = ITK_ok,
          iValCount			= 0,
          iAttribute		= 0,
          iPropVals         = 0;

	char cValue				= NULL,
	     *cValues			= NULL,
	     *pcAttrValue       = NULL,
	     *pcTypeName        = NULL,
	     **pcStrAttrVals    = NULL,
	     *pcObjectString    = NULL;

	double dblAttribute     = 0.0;

	date_t dtAttribute;

	bool isWSO              = false;
	bool isContinue			= true;

        tag_t tagAttribute     = NULL,
	      *tpAttributes    = NULL;;

        PROP_value_type_t  valtype;

	char* __function__ = "teradyne_getproperty_values";
	TERADYNE_TRACE_ENTER();
			
	try
	{
		if (!strPropNameValueMap.empty())
			strPropNameValueMap.clear();

		if ( tRevTag != NULLTAG )
		{
			for (std::list<string>::iterator it = strAttr.begin(); it != strAttr.end(); it++)
			{
				if( ((string)*it).empty() )
					continue;

				if (tc_strcmp(((string)*it).c_str(), "NULL") == 0)
               	{
					isContinue = false;						
					pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
					strcpy(pcAttrValue,"");
				}
				
				if((gNULLPropertyExecution) && (tc_strcmp(((string)*it).c_str(), "NULL") != 0))
               	{
					iStatus = AOM_ask_max_num_elements(tRevTag, ((string)*it).c_str(), &iPropVals);
				    if(iStatus != ITK_ok)
					{
						iStatus = 0;
						isContinue = false;
						pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
						strcpy(pcAttrValue,"");
					} 
					else 
						isContinue = true;
				}
				if(isContinue)
               	{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_max_num_elements(tRevTag, ((string)*it).c_str(), &iPropVals),TD_LOG_ERROR_AND_THROW);
				
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_type(tRevTag,((string)*it).c_str(),&valtype,&pcTypeName),TD_LOG_ERROR_AND_THROW);
					if(iPropVals == 1)
					{			  
						//check if string
						if(valtype == PROP_string)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag,((string)*it).c_str(),&pcAttrValue),TD_LOG_ERROR_AND_THROW);						
						}
						 //check if char
						else if(valtype == PROP_char)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_char(tRevTag,((string)*it).c_str(),&cValue),TD_LOG_ERROR_AND_THROW);
							pcAttrValue = (char *) MEM_alloc(sizeof(char) * 2);
							sprintf(pcAttrValue,"%c",cValue);
						}
						//check if date
						else if(valtype == PROP_date)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(tRevTag,((string)*it).c_str(), &dtAttribute),TD_LOG_ERROR_AND_THROW);	
							TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( dtAttribute, TD_DATE_YMD_CONSTANT, &pcAttrValue),TD_LOG_ERROR_AND_THROW);	
    					}
						//check if double or float
						else if(valtype == PROP_double || valtype == PROP_float)
						{		
							char pcBuffer[1024];
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevTag,((string)*it).c_str(),&dblAttribute),TD_LOG_ERROR_AND_THROW);
							sprintf(pcBuffer,"%f",dblAttribute);
							pcAttrValue = (char *) MEM_alloc(sizeof(char) * (int)(tc_strlen(pcBuffer)+ 1) );
							sprintf(pcAttrValue,"%f",dblAttribute);
						}
						//Check if logical
						else if(valtype == PROP_logical)
						{
							logical isLogicalAttribute = false;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tRevTag,((string)*it).c_str(),&isLogicalAttribute),TD_LOG_ERROR_AND_THROW);	
							pcAttrValue = (char *) MEM_alloc(sizeof(char)*5);
							if(isLogicalAttribute)
								sprintf(pcAttrValue,"%s","true");
							else
								sprintf(pcAttrValue,"%s","false");
						}
						//check if int or short
						else if(valtype == PROP_int || valtype == PROP_short)
						{
							char pcBuffer[1024];
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_int(tRevTag,((string)*it).c_str(), &iAttribute),TD_LOG_ERROR_AND_THROW);					
							sprintf(pcBuffer,"%d",iAttribute);
							pcAttrValue = (char *) MEM_alloc(sizeof(char)* (int)(tc_strlen(pcBuffer)+ 1));
							sprintf(pcAttrValue,"%d",iAttribute);
						}
				
						//check if typed reference          
						else if(valtype == PROP_typed_reference || valtype == PROP_untyped_reference)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tRevTag,((string)*it).c_str(),&tagAttribute),TD_LOG_ERROR_AND_THROW);					
							isWSO = teradyne_is_workspace_object(tagAttribute);
							if(isWSO == true)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_id_string(tagAttribute, &pcAttrValue),TD_LOG_ERROR_AND_THROW);	
							}						
							else 
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tagAttribute,TD_OBJECT_STRING,&pcAttrValue),TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					else if(iPropVals == -1 || iPropVals > 1)
					{
						//check if string
						if(valtype == PROP_string)
						{
							std::string strAttributeVals("");
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tRevTag,((string)*it).c_str(), &iValCount, &pcStrAttrVals),TD_LOG_ERROR_AND_THROW);				
							for(int iCount = 0; iCount < iValCount; iCount++)
							{
								if(iCount == 0)
								{
									strAttributeVals.assign(pcStrAttrVals[iCount]);
								}
								else
								{
									strAttributeVals.append(",");
									strAttributeVals.append(pcStrAttrVals[iCount]);
								}
							}

							pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int) (strAttributeVals.length() + 1));
							sprintf(pcAttrValue,"%s",strAttributeVals.c_str());
							Custom_free(pcStrAttrVals);
						}
						//check if char
						else if(valtype == PROP_char)
						{
							char pcBuffer[1];
							std::string strAttrVals("");

							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_chars(tRevTag, ((string)*it).c_str(), &iValCount, &cValues),TD_LOG_ERROR_AND_THROW);
							for(int iCount = 0; iCount < iValCount; iCount++)
							{
								sprintf(pcBuffer,"%c",cValues[iCount]);
								if(iCount == 0)
								{
									strAttrVals.assign(pcBuffer);
								}
								else
								{
									strAttrVals.append(",");
									strAttrVals.append(pcBuffer);
								}
							}
							pcAttrValue = (char*) MEM_alloc(sizeof(char) * (int)(strAttrVals.length() + 1));
							sprintf(pcAttrValue,"%s",strAttrVals.c_str());
							Custom_free(pcStrAttrVals);
							Custom_free(cValues);
						}
						else if(valtype == PROP_typed_reference || valtype == PROP_untyped_reference)
						{
							std::string strAttrVals("");
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tRevTag, ((string)*it).c_str(), &iValCount, &tpAttributes),TD_LOG_ERROR_AND_THROW);
						
							for(int iCount = 0; iCount < iValCount; iCount++)
							{							
								isWSO = teradyne_is_workspace_object(tpAttributes[iCount]);							
								if(isWSO == true)
								{
									TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_id_string(tpAttributes[iCount], &pcObjectString),TD_LOG_ERROR_AND_THROW);
								}
								else
								{
									TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tpAttributes[iCount],TD_OBJECT_STRING, &pcObjectString),TD_LOG_ERROR_AND_THROW);
								}

								if(iCount == 0)
								{
									strAttrVals.assign(pcObjectString);
								}
								else
								{
									strAttrVals.append(",");
									strAttrVals.append(pcObjectString);
								}
								Custom_free(pcObjectString);
							}
							pcAttrValue = (char*)MEM_alloc(sizeof(char) * (int)(strAttrVals.length() +1 ));
							sprintf(pcAttrValue,"%s",strAttrVals.c_str());
							Custom_free(tpAttributes);
						}
					}
					Custom_free(pcTypeName);
				}				
				strPropNameValueMap.insert(::make_pair((string)*it,(string)pcAttrValue));
				Custom_free(pcAttrValue);				
			}
		}
	}		
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcAttrValue);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}