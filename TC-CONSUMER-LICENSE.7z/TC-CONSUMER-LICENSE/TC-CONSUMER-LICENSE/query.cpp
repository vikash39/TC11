#include<query.h>
#include<teradyne_common.h>
#include<iostream>


int divpart_get(const char *createdAfter, const char *createdBefore) 
{
	int iStatus = ITK_ok;
	
	auto rows=0,cols=0;
	void ***results = NULL;
	TERADYNE_TRACE_CALL(iStatus = query_terpart_rev("get_divparts", "TD4DivPart", TD_LSD, createdAfter, createdBefore, &rows, &cols, &results),TD_LOG_ERROR_AND_THROW);
	
	string szObjAttr[] ={TD_ITEM_ID_ATTR, TD_ITEM_REV_ID_ATTR, TD_STD_DESC_ATTR, TD_COMM1_ATTR, TD_ITEM_STATUS_ATTR, TD_CBU_ATTR,TD_PROJECT_NAME, TD_DATE_CREATED, TD_DATE_MODIFIED, TD_HTS, TD_ECCN};
	std::list<std::string> strAttr(szObjAttr,szObjAttr+sizeof(szObjAttr)/sizeof(string));
	
	if(rows > 0 )
	{
		printf("Date %s %s \t\t rows %d",createdAfter, createdBefore,rows);
		for ( int i= 0; i< rows; i++)
		{
			tag_t tag=*((tag_t *)results[i][0]);
				
			if(tag!=NULLTAG) 
			{
				char *itemType = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tag,&itemType),TD_LOG_ERROR_AND_THROW);
					 
				if(strcmp("TD4DivPart",itemType)==0) 
				{
					string szUnitOfMeasure;

					char **pcUnitOfMeasure = NULL;
					int numValues = 0;
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_displayable_values(tag,TD_UNIT_TYPE,&numValues,&pcUnitOfMeasure),TD_LOG_ERROR_AND_THROW);	
					if(numValues == 1) {
						szUnitOfMeasure.append(pcUnitOfMeasure[0]);
					} else {
						szUnitOfMeasure.append("");
					}

					tag_t tagRev = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tag,&tagRev),TD_LOG_ERROR_AND_THROW);

					map<string,string> strPropNameValueMap;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tagRev, strAttr, strPropNameValueMap),TD_LOG_ERROR_AND_THROW);
					if ( strPropNameValueMap.size() > 0)
					{
						
						string szItemId  = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;
						string szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
						string szDesc    = strPropNameValueMap.find(TD_STD_DESC_ATTR)->second;
						string szCommLevel1 = strPropNameValueMap.find(TD_COMM1_ATTR)->second;
						string szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
						string szCBU = strPropNameValueMap.find(TD_CBU_ATTR)->second;

						if (szCBU.compare("NXT") == 0) {
							string szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME)->second;
							string szDateCreated = strPropNameValueMap.find(TD_DATE_CREATED)->second;
							string szDateModified = strPropNameValueMap.find(TD_DATE_MODIFIED)->second;
							string szHTS = strPropNameValueMap.find(TD_HTS)->second;
							string szECCN= strPropNameValueMap.find(TD_ECCN)->second;

							JSON_Value *root_value = json_value_init_object();
							JSON_Object *root_object = json_value_get_object(root_value);
					
							json_object_set_string(root_object, "projectName", szProjectName.c_str());
							json_object_set_string(root_object, "cbu", szCBU.c_str());
							json_object_set_string(root_object, "commodityLevel", szCommLevel1.c_str());
							json_object_set_string(root_object, "partType", "DivisionalPart");
							json_object_set_string(root_object, "itemStatus", szItemStatus.c_str());
							json_object_set_string(root_object, "partNumber", szItemId.c_str());
							json_object_set_string(root_object, "revision", szItemRev.c_str());
							json_object_set_string(root_object, "description", szDesc.c_str());
							json_object_set_string(root_object, "uom", szUnitOfMeasure.c_str());
							json_object_set_string(root_object, "dateCreated", szDateCreated.c_str());
							json_object_set_string(root_object, "dateModified", szDateModified.c_str());
							json_object_set_string(root_object, "ecn", "");
							json_object_set_string(root_object, "effDate", "");

							json_object_set_string(root_object, "eccn", szHTS.c_str());
							json_object_set_string(root_object, "hts", szECCN.c_str());

							char *serialized_string = json_serialize_to_string(root_value);

							publishEvent("PartModifiedFound",serialized_string);
							json_free_serialized_string(serialized_string);
							json_value_free(root_value);
						}
					}

					Custom_free(pcUnitOfMeasure);
				}			
			}
		}
	
	}
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_delete("get_divparts"),TD_LOG_ERROR_AND_THROW);
		
	Custom_free(results);
		
	return iStatus;
}

int commpart_get(const char *createdAfter, const char *createdBefore) 
{
	int iStatus = ITK_ok;
	
	auto rows=0,cols=0;
	void ***results = NULL;
	TERADYNE_TRACE_CALL(iStatus = query_terpart_rev("get_commparts", "TD4CommPart", TD_LSD, createdAfter, createdBefore, &rows, &cols, &results),TD_LOG_ERROR_AND_THROW);
	
	string szObjAttr[] ={TD_ITEM_ID_ATTR, TD_ITEM_REV_ID_ATTR, TD_DESC_ATTR, TD_COMM1_ATTR, TD_ITEM_STATUS_ATTR, TD_CBU_ATTR,TD_PROJECT_NAME, TD_DATE_CREATED, TD_DATE_MODIFIED, TD_HTS, TD_ECCN};
	std::list<std::string> strAttr(szObjAttr,szObjAttr+sizeof(szObjAttr)/sizeof(string));
	
	if(rows > 0 )
	{
		printf("Date %s %s \t\t %d",createdAfter, createdBefore,rows);
		for ( int i= 0; i< rows; i++)
		{
			tag_t tag=*((tag_t *)results[i][0]);
				
			if(tag!=NULLTAG) 
			{
				char *itemType = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tag,&itemType),TD_LOG_ERROR_AND_THROW);
				
				if(strcmp("TD4CommPart",itemType)==0) 
				{
					
					string szUnitOfMeasure;

					char **pcUnitOfMeasure = NULL;
					int numValues = 0;
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_displayable_values(tag,TD_UNIT_TYPE,&numValues,&pcUnitOfMeasure),TD_LOG_ERROR_AND_THROW);	
					if(numValues == 1) {
						szUnitOfMeasure.append(pcUnitOfMeasure[0]);
					} else {
						szUnitOfMeasure.append("");
					}

					tag_t tagRev = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tag,&tagRev),TD_LOG_ERROR_AND_THROW);

					map<string,string> strPropNameValueMap;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tagRev, strAttr, strPropNameValueMap),TD_LOG_ERROR_AND_THROW);
					if ( strPropNameValueMap.size() > 0)
					{
						
						string szItemId  = strPropNameValueMap.find(TD_ITEM_ID_ATTR)->second;
						string szItemRev = strPropNameValueMap.find(TD_ITEM_REV_ID_ATTR)->second;
						string szDesc    = strPropNameValueMap.find(TD_DESC_ATTR)->second;
						string szCommLevel1 = strPropNameValueMap.find(TD_COMM1_ATTR)->second;
						string szItemStatus = strPropNameValueMap.find(TD_ITEM_STATUS_ATTR)->second;
						string szCBU = strPropNameValueMap.find(TD_CBU_ATTR)->second;
						string szProjectName = strPropNameValueMap.find(TD_PROJECT_NAME)->second;
						string szDateCreated = strPropNameValueMap.find(TD_DATE_CREATED)->second;
						string szDateModified = strPropNameValueMap.find(TD_DATE_MODIFIED)->second;
						string szHTS = strPropNameValueMap.find(TD_HTS)->second;
						string szECCN= strPropNameValueMap.find(TD_ECCN)->second;

						JSON_Value *root_value = json_value_init_object();
						JSON_Object *root_object = json_value_get_object(root_value);
					
						json_object_set_string(root_object, "PartType", "CommercialPart");
						json_object_set_string(root_object, "PartNumber", szItemId.c_str());
						json_object_set_string(root_object, "Revision", szItemRev.c_str());
						json_object_set_string(root_object, "Description", szDesc.c_str());
						json_object_set_string(root_object, "CommodityCode", szCommLevel1.c_str());
						json_object_set_string(root_object, "ItemStatus", szItemStatus.c_str());
						json_object_set_string(root_object, "CBU", szCBU.c_str());

						json_object_set_string(root_object, "UnitOfMeasure", szUnitOfMeasure.c_str());
						json_object_set_string(root_object, "ProjectName", szProjectName.c_str());
						json_object_set_string(root_object, "DateCreated", szDateCreated.c_str());
						json_object_set_string(root_object, "DateModified", szDateModified.c_str());
						json_object_set_string(root_object, "ECCN", szHTS.c_str());
						json_object_set_string(root_object, "HTS", szECCN.c_str());

						char *serialized_string = json_serialize_to_string(root_value);

						publishEvent("TCPartModified",serialized_string);
						json_free_serialized_string(serialized_string);
						json_value_free(root_value);
					}

					Custom_free(pcUnitOfMeasure);
				}			
			}
		}
	
	}
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_delete("get_commparts"),TD_LOG_ERROR_AND_THROW);
		
	Custom_free(results);
		
	return iStatus;
}

int query_terpart_rev(const char *enq_id, const char *aclass, const char *filter_type, const char *createdAfter,  const char *createdBefore, int *rows, int *cols, void **** results)
{
	int iStatus = ITK_ok;
	
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_create(enq_id),TD_LOG_ERROR_AND_THROW);
		
	const char * select_attr_list[] = {"puid"};
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_add_select_attrs(enq_id,aclass,1,select_attr_list),TD_LOG_ERROR_AND_THROW);
		
	const char * pItemType[] = {aclass};
		
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(enq_id,"val1",1,pItemType,POM_enquiry_const_value),TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(enq_id,"expr1",aclass,"object_type",POM_enquiry_equal,"val1"),TD_LOG_ERROR_AND_THROW);
	
	date_t createdAfterTag;
	TERADYNE_TRACE_CALL(iStatus = DATE_convert_iso_date_to_date_t(createdAfter,&createdAfterTag),TD_LOG_ERROR_AND_THROW);
		
	const date_t * constAfterT = &createdAfterTag;
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_date_value(enq_id,"val2",1,constAfterT,POM_enquiry_bind_value ),TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(enq_id,"expr2",aclass,filter_type,POM_enquiry_greater_than_or_eq,"val2"),TD_LOG_ERROR_AND_THROW);

	date_t createdBeforeTag;
	TERADYNE_TRACE_CALL(iStatus = DATE_convert_iso_date_to_date_t(createdBefore,&createdBeforeTag),TD_LOG_ERROR_AND_THROW);
	
	const date_t * constBeforeT = &createdBeforeTag;
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_date_value(enq_id,"val3",1,constBeforeT,POM_enquiry_bind_value ),TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(enq_id,"expr3",aclass,filter_type,POM_enquiry_less_than_or_eq,"val3"),TD_LOG_ERROR_AND_THROW);
												   
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(enq_id, "and_expr2", "expr1", POM_enquiry_and, "expr2"),TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(enq_id, "and_expr3", "and_expr2", POM_enquiry_and, "expr3"),TD_LOG_ERROR_AND_THROW);
	
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_where_expr(enq_id,"and_expr3"),TD_LOG_ERROR_AND_THROW);
		
	TERADYNE_TRACE_CALL(iStatus = POM_enquiry_execute(enq_id, rows,cols,results),TD_LOG_ERROR_AND_THROW);
	
	return iStatus;
}

int publishEvent(const char *eventType, char *serializedString)
{
	GUID uuid;
	::ZeroMemory(&uuid, sizeof(UUID));

	int status = 0;

	RPC_STATUS ret_val = ::UuidCreate(&uuid);
	if(ret_val == RPC_S_OK)
	{
		curl_global_init(CURL_GLOBAL_ALL);

		CURL *curl = curl_easy_init();
		if(curl) 
		{
			curl_easy_setopt(curl, CURLOPT_URL, ES_URL);

			std::string eventHeader = "ES-EventType: ";
			eventHeader.append(eventType);

			struct curl_slist *headers = NULL;
			headers = curl_slist_append(headers, "Content-Type: application/json");
			headers = curl_slist_append(headers, eventHeader.c_str());

			char *uuidString;
			UuidToStringA(&uuid, (RPC_CSTR*)&uuidString);
			std::string esEventIdHeader;
			esEventIdHeader.append("ES-EventId: ");
			esEventIdHeader.append(uuidString);
			RpcStringFreeA((RPC_CSTR*)&uuidString);

			headers = curl_slist_append(headers, esEventIdHeader.c_str());

			CURLcode curlRes = curl_easy_setopt(curl, CURLOPT_HTTPHEADER,headers);

			curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)strlen(serializedString));
			curl_easy_setopt(curl, CURLOPT_POSTFIELDS, serializedString);
			//curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
			
			curlRes = curl_easy_perform(curl);

			if(curlRes != CURLE_OK)
			{
				fprintf(stderr, "curl_easy_perform() failed: %s\n",
							 curl_easy_strerror(curlRes));
			}
  
			curl_easy_cleanup(curl);
		}
		else 
		{
			printf("CURL error, something went wrong and curl cannot be used.");
			status = 1;
		}
		curl_global_cleanup();
	} else {
		printf("CURL error, something went wrong and curl cannot be used.");
		status = 1;
	}
	return status;
}

int created_per_hour_get( char *createdAfter,  char *createdBefore) 
{
	int status = 0;
	
	time_t base = time(NULL);
	struct tm* before = localtime(&base);
	
	sprintf(createdBefore,"%04d-%02d-%02dT%02d:%02d:59",before->tm_year + 1900, before->tm_mon +1, before->tm_mday, before->tm_hour, before->tm_min);
	
	before->tm_hour -= 1;
	
	time_t baseAfter = mktime(before);
	struct tm* after = localtime(&baseAfter);
	
	sprintf(createdAfter,"%04d-%02d-%02dT%02d:%02d:00",after->tm_year + 1900, after->tm_mon +1, after->tm_mday, after->tm_hour -1 , after->tm_min);
	
	return status;
}