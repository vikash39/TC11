
#ifndef TERADYNE_COMMON_H
#define TERADYNE_COMMON_H

#include<tc\tc_startup.h>
#include<tccore\aom.h>
#include<tccore\aom_prop.h>
#include<tccore\tctype.h>
#include<teradyne_trace.h>
#include<teradyne_constants.h>
#include<list>
#include<map>
#include<string>
using namespace std;

// Use to free mem
#define Custom_free(p) {\
    if ( p != NULL ) {\
        MEM_free(p); \
        p = NULL;\
    }\
}

#ifdef __cplusplus
         extern "C"{
#endif
extern void POM_AM__set_application_bypass(bool b);
bool teradyne_is_workspace_object(tag_t tObjectTag);
int teradyne_ask_object_type(tag_t tObject, char** pcTypeName);
int teradyne_getproperty_values(tag_t tRevTag,std::list<string> strAttr,std::map<string,string> &strPropNameValueMap);


#ifdef __cplusplus
		 }
#endif

#endif