#ifndef TERADYNE_TRACE_H
#define TERADYNE_TRACE_H

#include <time.h>
#include <sys/timeb.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>

using namespace std;

#ifdef __cplusplus
         extern "C"{
#endif

#define TD_LOG_ERROR					10001
#define TD_LOG_INFORMATION				10003
#define TD_LOG_WARNING					10005
#define TD_LOG_ERROR_AND_THROW			10007
#define TD_LOG_ERROR_AND_RETURN			10009

void teradyne_log_local_time(void);

void teradyne_change_indent ( const char cChange );

void teradyne_printIndent();

int teradyne_get_error_text( int iErrorCode, char** msg );

void teradyne_write_trace_log(int stat,int clog);

bool td4_is_trace_handler_on ( void );


#define TERADYNE_TRACE_ENTER() \
do { \
		if ( td4_is_trace_handler_on() ) \
		{ \
			teradyne_log_local_time(); \
			teradyne_printIndent() ; \
			TC_write_syslog("--> %s()" , __function__) ; \
			teradyne_change_indent ( '+' ) ; \
		} \
} while(0)

#define TERADYNE_TRACE_LEAVE(iRetval) \
do { \
		if ( td4_is_trace_handler_on() ) \
		{ \
			teradyne_change_indent ( '-' ) ; \
			teradyne_log_local_time(); \
			teradyne_printIndent() ; \
			TC_write_syslog("<-- %s() returns %d" , __function__,iRetval) ; \
		} \
} while(0)

#define TERADYNE_TRACE_CALL(function,clog) \
do { \
		int stat = (function) ; \
		if ( td4_is_trace_handler_on() ) \
		{ \
			char * pc = NULL ; \
			pc=(char*)strchr(#function,'=');if(pc){do pc++;while(*pc==' ');}else pc=#function;\
			teradyne_log_local_time();\
			teradyne_printIndent() ; \
			TC_write_syslog("*** %s" , pc) ; \
			if(stat != ITK_ok)	\
			{	\
				teradyne_log_local_time();\
				teradyne_printIndent() ; \
				char* error_msg = NULL;	\
				teradyne_get_error_text( stat, &error_msg ); \
				if(clog == TD_LOG_ERROR) \
				{ \
					TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
				} \
				else if(clog == TD_LOG_ERROR_AND_RETURN) \
                { \
					TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
	            } \
				else if(clog == TD_LOG_ERROR_AND_THROW) \
				{ \
					TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
			    } \
				else if(clog == TD_LOG_INFORMATION) \
				{ \
					TC_write_syslog("[TERADYNE_INFORMATION_MSG] : %s" , error_msg) ; \
				} \
				else if(clog == TD_LOG_WARNING) \
				{ \
					TC_write_syslog("[TERADYNE_WARNING_MSG] : %s" , error_msg) ; \
				} \
				else \
				{ \
					TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
				} \
				if(error_msg != NULL) \
				{ \
					MEM_free(error_msg); \
					error_msg = NULL; \
                } \
			} \
		}	\
		if(stat != ITK_ok)	\
		{	\
			TC_write_syslog("ERROR:");\
			teradyne_log_local_time();\
			teradyne_printIndent() ; \
			char* error_msg = NULL;	\
			teradyne_get_error_text( stat, &error_msg ); \
			TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
			if(clog == TD_LOG_ERROR_AND_THROW) \
			{ \
				throw iStatus; \
            } \
			else if(clog == TD_LOG_INFORMATION) \
			{ \
				EMH_clear_errors(); \
            } \
			else if(clog == TD_LOG_WARNING) \
			{ \
				iStatus = ITK_ok; \
            } \
			else \
			{ \
				throw iStatus; \
			} \
		} \
} while(0)

#define TERADYNE_ITKCALL_F(function) {\
	int stat = (function) ; \
	if (stat != ITK_ok) { \
			teradyne_log_local_time();\
			teradyne_printIndent() ; \
			char* error_msg = NULL;	\
			teradyne_get_error_text( stat, &error_msg ); \
			TC_write_syslog("[TERADYNE_ERROR_MSG] : %s" , error_msg) ; \
			if(error_msg != NULL) \
			{ \
				MEM_free(error_msg); \
				error_msg = NULL; \
			} \
	}\
}

#define TERADYNE_TRACE(function) \
do { \
		if ( td4_is_trace_handler_on() ) \
		{ \
			char * pc = NULL ; \
			pc=(char*)strchr(#function,'=');if(pc){do pc++;while(*pc==' ');}else pc=#function; \
			teradyne_log_local_time();\
			teradyne_printIndent() ; \
			TC_write_syslog("*** %s" , pc) ; \
		}	\
		(function) ; \
} while(0)
		 
#ifdef __cplusplus 
		 }
#endif

#endif