#include<tc/tc.h>
#include<bom/bom.h>
#include<cm/cm.h>
#include<fclasses/tc_date.h>
#include<tccore/tctype.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tccore/grm.h>
#include<tccore/item.h>
#include<tccore/releasestatus.h>
#include<pom/enq/enq.h>
#include<string.h>
#include<time.h>
#include<curl\curl.h>
#include<parson.h>
#pragma comment(lib, "rpcrt4.lib")
#include<rpc.h>
#include<string>

int divpart_get(const char *createdAfter, const char *createdBefore);

int commpart_get(const char *createdAfter, const char *createdBefore);

int query_terpart_rev(const char *enq_id, const char *aclass, const char *filter_type, const char *createdAfter,  const char *createdBefore, int *rows, int *cols, void **** results);

int publishEvent(const char *eventType, char *serializedString);

int created_per_hour_get( char *createdAfter,  char *createdBefore);
