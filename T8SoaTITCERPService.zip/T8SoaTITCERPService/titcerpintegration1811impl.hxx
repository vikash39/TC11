/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_TITCERPSERVICE_2018_11_TITCERPINTEGRATION_IMPL_HXX 
#define TEAMCENTER_SERVICES_TITCERPSERVICE_2018_11_TITCERPINTEGRATION_IMPL_HXX


#include <titcerpintegration1811.hxx>

#include <TITCERPService_exports.h>

namespace T8
{
    namespace Soa
    {
        namespace TITCERPService
        {
            namespace _2018_11
            {
                class TITCERPIntegrationImpl;
            }
        }
    }
}


class SOATITCERPSERVICE_API T8::Soa::TITCERPService::_2018_11::TITCERPIntegrationImpl : public T8::Soa::TITCERPService::_2018_11::TITCERPIntegration

{
public:

    virtual TITCERPIntegrationImpl::GetPartTransferResponse getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs );
    virtual TITCERPIntegrationImpl::GetContractedCostResponse importContractedCostInfo ( const GetContractedCostInput& getContractedCostInputs );
    virtual TITCERPIntegrationImpl::GetCurrencyConversionImportResponse importCurrencyConversionInfo ( const GetCurrencyConversionInput& getCurrencyConversionInput );
    virtual TITCERPIntegrationImpl::GetSellingPriceResponse importSellingPriceInfo ( const GetSellingPriceInput& getSellingPriceInputs );
    virtual TITCERPIntegrationImpl::GetStandardCostResponse importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs );
    virtual TITCERPIntegrationImpl::GetPartSyncTransferResponse savePartSyncInfo ( const GetPartSyncTransferInput& getPartSyncTransferInputs );


};

#include <TITCERPService_undef.h>
#endif
