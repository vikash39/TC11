/*
 * TI_std_cost_error.hxx
 *
 *  Created on: 31-Dec-2020
 *      Author: 10677
 */

#ifndef TI_STD_COST_ERROR_HXX_
#define TI_STD_COST_ERROR_HXX_


#define SUCCESS_STATUS                       "Succeeded"
#define ERR_FAIL_STATUS                      "Failed"
#define PART_NUM_NOT_PASSED_AS_ARG           "TI ERROR: Unable to find the partNumber as a input"
#define EXCP_ERR                             "TI ERROR: Please provide the same facility code for one record.."
#define ERP_PLM_ATTRI_MAPPING                "TI ERROR: While getting the ERP_PLM_Attribute_Mapping values."
#define EXCP_PARSE_CASCADEING_LOV            "TI ERROR: While getting parsingCascadingLOV from tc-"
#define EXCP_PARSE_FACTY_MAP_LOV             "TI ERROR: While getting the Facility Mapping Lov from tc-"
#define EXCP_ERR_TO_GET_FACTY_AND_LOC        "TI ERROR: While getting facilityName & facilityLoc"
#define FACILITY_NAME_IS_NULL                "TI ERROR: Facility name is empty. did not find in tc."
#define FACILITY_LOC_IS_NULL                 "TI ERROR: Facility location is empty. did not find in tc."
#define FACILITY__LOC_MAP_SIZE               "TI ERROR: Unable to parse LOV to get the mapping for the facilityMapLocation is empty"
#define EXCP_ERR_CREATE_NEW_SCF              "TI ERROR: While creating new standard cost form.."
#define EXCP_ERR_REVISE_SCF                  "TI ERROR: While revising the existing cost form.."
#define PART_ID_NOT_FOUND_IN_TC              "TI ERROR: PartId not found in tc"
#define PART_NUM_NOT_FOUND_IN_TC             "TI ERROR: Part number not found in tc"
#define ERR_ADD_REVISION_STATUS              "TI ERROR: Unable to set existing Form status to new Form"
#define CHANGE_OWNERSHIP                     "TI ERROR: Unable to change the ownership of stdCostForm"
#define FACILITY_CODE_NAME_MAP               "TI ERROR: Unable to parse LOV, to get the mapping for the facility name & facility codes are empty"
#define IMPORT_DATA_FUN_ERR                  "TI ERROR: While executing importData() function, error occurred"
#define LOV_INPUT_ERROR                      "TI ERROR: Please validate the lov values. "
#define ERR_UPDATE_COST_FORM_ATTR            "TI ERROR: While updating sdtCost form attributes value."
#define ERR_MAIL_NOTIFICATION                "\nTI ERROR: While sending email notification \n"
#define ENV_VAR_NOT_FOUND                    "\nTI ERROR: TC_ROOT -- environment variable is not found\n"
#define NOT_FOUND_PLM_NOTIFIERS_MAIL_ID      "\nTI ERROR: PLM_Notifiers -- email id is not found\n"
#define EXCP_TO_GETTING_CURRENCY             "\nTI ERROR: Unable to find the currency value\n"
#define PART_EXIST_IN_EXCLUSION_LIST         "part is present in the Exclusion List. So this part will not be processed further."




#endif /* TI_STD_COST_ERROR_HXX_ */
