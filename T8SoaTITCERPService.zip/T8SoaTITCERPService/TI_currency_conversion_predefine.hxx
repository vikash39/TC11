# ifndef TI_CURRENCY_CONVERSION_TRANSFER_HEADER
# define TI_CURRENCY_CONVERSION_TRANSFER_HEADER

//#include <titcerpextension1811.hxx> //Add the header file name in BMIDE
#include<titcerpintegration1811.hxx>
#include "TI_currency_conversion_header.hxx"

#ifdef _WIN32
#define EXTERN_DLL extern __declspec(dllexport)
#define EXTERNCLASS __declspec(dllexport)
#else
#define EXTERN_DLL extern
#define EXTERNCLASS
#endif


using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server; //Use the namespace from BMIDE code

EXTERN_DLL T8::Soa::TITCERPService::_2018_11::TITCERPIntegration ::GetStandardCostResponse tiStandardCostTransfer(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetStandardCostInput getStandardCost);


#define PREF_CURRENCY_COUNTRY_MAPPING "TI_Currency_Conversion_List"
#define PREF_CURRENCY_ITEM_ID         "TI_Currency_Item_ID"
#define TI_MASTER_FORM_REL            "IMAN_master_form"
#define ATTRIBUTE_GBP_MPR             "t8_pannualmprvalues"
#define ATTRIBUTE_EUR_MPR             "t8_eannualmprvalues"
#define ATTRIBUTE_USD_MPR             "t8_uannualmprvalues"
#define ATTRIBUTE_EUR_MONTHEND        "t8_emonthendvalues"
#define ATTRIBUTE_GBP_MONTHEND        "t8_gmonthendvalues"
#define ATTRIBUTE_USD_MONTHEND        "t8_umonthendvalues"




int add_release_status(tag_t *tObjectList,int NoOfObjs, string sValue);
int set_owner(tag_t *tObjectList,int NoOfObjs, tag_t tTarget);
void eMailNotification_currency(/*vector<TITCERPIntegration::CurrencyConversionResponseInfo>*/TITCERPIntegration::GetCurrencyConversionImportResponse vResponse ,char* siteName);
//void eMailNotification_currency(vector<TITCERPIntegration::CurrencyConversionResponseInfo> vResponse ,char* siteName);

#endif
