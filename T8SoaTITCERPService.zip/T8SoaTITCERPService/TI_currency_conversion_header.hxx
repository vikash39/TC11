# ifndef TI_CURRENCY_CONVERSION_HEADER
# define TI_CURRENCY_CONVERSION_HEADER

/*************************************************
* System Header Files
**************************************************/
//#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <cstring>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

//#include "TI_StandardCost.hxx"
/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tc\tc.h>
#include <tccore\grm.h>
#include <tc\tc_startup.h>
#include <tccore\item.h>
#include <tccore\aom_prop.h>
#include <tccore\aom.h>
#include <sa\group.h>
#include <fclasses\tc_date.h>
#include <sa\groupmember.h>
#include <user_exits\epm_toolkit_utils.h>
#include <lov\lov.h>
#include <tc\folder.h>
#include <res\res_itk.h>
#include <tc\preferences.h>

using namespace std;



#endif
