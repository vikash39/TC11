/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <titcerpintegration1811impl.hxx>
#include "TI_std_cost_header.hxx"
#include "TI_std_cost_predefine.hxx"
#include "TI_currency_conversion_predefine.hxx"


using namespace T8::Soa::TITCERPService::_2018_11;
using namespace Teamcenter::Soa::Server;

extern T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetCurrencyConversionImportResponse tiCurrencyImport(T8::Soa::TITCERPService::_2018_11::TITCERPIntegration::GetCurrencyConversionInput getCurrencyInput);

TITCERPIntegrationImpl::GetPartTransferResponse TITCERPIntegrationImpl::getPartTransferInfo ( const GetPartTransferInput& getPartTransferInputs )
{
	TC_write_syslog("getPartTransferInputs ",getPartTransferInputs.changeItemID);
		TITCERPIntegrationImpl::GetPartTransferResponse sellingPriceRes;
		return sellingPriceRes;
}


TITCERPIntegrationImpl::GetContractedCostResponse TITCERPIntegrationImpl::importContractedCostInfo ( const GetContractedCostInput& getContractedCostInputs )
{
	TC_write_syslog("getStandardCostInputs ",getContractedCostInputs.contractedCostInputData);
	TITCERPIntegrationImpl::GetContractedCostResponse contractCostRes;
	return contractCostRes;
}


TITCERPIntegrationImpl::GetCurrencyConversionImportResponse TITCERPIntegrationImpl::importCurrencyConversionInfo ( const GetCurrencyConversionInput& getCurrencyConversionInput )
{
	TITCERPIntegration::GetCurrencyConversionImportResponse localcurrImportRes;

	int iFail=ITK_ok,
				iFormCnt = 0 ,
			    iNoOfObjs = 0;
   tag_t tCurrencyItemRev = NULLTAG,
		 tCurrencyLastRev  = NULLTAG,
		 tCurrencyItem = NULLTAG,
		 tRelation  = NULLTAG,
		 *tFormTags = NULL,
		 *tObjectList = NULL;

	int prefCnt = 0;
	char ** prefValues = NULL;

	logical lCurrencyExists = true;

	string sCurrencyItem = "";
	map<string, string> mTypeCntryCode;
	map<string, string> mAttributeValues;
	set <string> stCountryCode;

	map<string, string>::iterator mItr;
	tObjectList = (tag_t *)MEM_alloc (2 * sizeof(tag_t));

	TITCERPIntegration::CurrencyConversionResponseInfo result;
	//vector<TITCERPIntegration::CurrencyConversionResponseInfo> response;

	try
	{
		//Reading the preference values and storing in a vector
		TC_write_syslog("\n\n Reading Preferences\n\n");

		ERROR_CALL(iFail = PREF_ask_char_values(PREF_CURRENCY_COUNTRY_MAPPING, &prefCnt, &prefValues));
		int parseCnt = 0;
		//ITK_set_bypass(true);
		char **parsedStr =NULL;
		for(int q=0; q<prefCnt; q++)
		{
			EPM__parse_string(prefValues[q],":",&parseCnt,&parsedStr);
			if(parseCnt == 3)
			{
				string sTransferType = parsedStr[0];
				string sCountryCode = parsedStr[1];
				stCountryCode.insert(parsedStr[1]);
				mTypeCntryCode[(sTransferType +"_"+ sCountryCode)]=parsedStr[2];
			}
				if(parseCnt > 0) SAFE_SM_FREE(parsedStr);
		}
		if(prefCnt >0 ) SAFE_SM_FREE(prefValues);

				prefCnt = 0;
				ERROR_CALL(iFail = PREF_ask_char_values(PREF_CURRENCY_ITEM_ID, &prefCnt, &prefValues));
				for(int q=0; q<prefCnt; q++)
				{
					sCurrencyItem = prefValues[q];
					TC_write_syslog("\nFinding Currency Item : %s \n",prefValues[q]);

					ERROR_CALL(iFail = ITEM_find_item(sCurrencyItem.c_str(), &tCurrencyItem));
					if(tCurrencyItem != NULLTAG)
					{
						ERROR_CALL(iFail = ITEM_ask_latest_rev(tCurrencyItem, &tCurrencyLastRev));
					}
					break;
				}
				if(prefCnt >0 ) SAFE_SM_FREE(prefValues);

				vector<TITCERPIntegration::CurrencyConversionInputInfo>::iterator it;
				vector<TITCERPIntegration::CurrencyConversionInputInfo> vCurrencyInput = getCurrencyConversionInput.currencyConversionInputInfo;


				for (it = vCurrencyInput.begin() ; it != vCurrencyInput.end() && tCurrencyLastRev != NULLTAG; ++it)
				{
					TITCERPIntegration::CurrencyConversionInputInfo inputInfo = *it;
					result.conversionID ="";
					result.conversionMode = "";
					result.importStatus = "";
					result.yearMonth = "";
					result.reasonForFailure = "";

					string sConversionID = inputInfo.conversionID;
					string sConversionMode = inputInfo.conversionMode;
					string sYearMonth = inputInfo.yearMonth;
					string sMissingCurrencies = "";

					//Building response
					result.conversionID = inputInfo.conversionID;
					result.conversionMode = inputInfo.conversionMode;
					result.yearMonth = inputInfo.yearMonth;

					vector <TITCERPIntegration::CurrencyConversionRecord> vCurrencyRecords= inputInfo.currencyConversionRecords;

					for (vector<TITCERPIntegration::CurrencyConversionRecord>::iterator iter = vCurrencyRecords.begin() ; iter != vCurrencyRecords.end() ; ++iter)
					{
						TITCERPIntegration::CurrencyConversionRecord structRecords = *iter;
					   string  sCountry = structRecords.country;
					   string  sCurrencyCode= structRecords.currencyCode;
			           string  sUSD = structRecords.usd;
					   string  sEUR = structRecords.eur;
			           string  sGBP = structRecords.gbp;
					   //Checking if the country exists in the teamcenter
						//if exists then update teamcenter
						if((stCountryCode.count(sCurrencyCode) != 0))
						{

				             string sRealName_USD = sConversionMode + "_USD_" +  sCurrencyCode;
							 string sRealName_EUR = sConversionMode + "_EUR_" +  sCurrencyCode;
							 string sRealName_GBP = sConversionMode + "_GBP_" +  sCurrencyCode;

							 if(mTypeCntryCode.count(sRealName_USD))
							 {
								auto itr = mTypeCntryCode.find(sRealName_USD);
								mAttributeValues[itr->second] = sUSD;
							 }
							 if(mTypeCntryCode.count(sRealName_EUR))
							 {
								auto itr = mTypeCntryCode.find(sRealName_EUR);
								mAttributeValues[itr->second] = sEUR;
							 }
							 if(mTypeCntryCode.count(sRealName_GBP))
							 {
								auto itr = mTypeCntryCode.find(sRealName_GBP);
								mAttributeValues[itr->second] = sGBP;
							 }
						}
						else//if not exists then send an alert or ticket
						{
							result.importStatus = ERR_FAIL_STATUS;
							if(sMissingCurrencies.size() > 0)
							{
								sMissingCurrencies = sMissingCurrencies + " , " + sCurrencyCode;
							}
							else
							{
								sMissingCurrencies = sCurrencyCode;
							}
							lCurrencyExists = false;
							//break;
						}

					}
					//Revise and update properties if all the currency type exists in teamcenter
					if(lCurrencyExists)
					{
						ERROR_CALL(iFail = ITEM_ask_latest_rev(tCurrencyItem, &tCurrencyLastRev));
						ERROR_CALL(iFail = ITEM_copy_rev(tCurrencyLastRev, NULL, &tCurrencyItemRev));
						if(tCurrencyItemRev != NULLTAG)
						{
							char * revId = NULL;
							ERROR_CALL(iFail = ITEM_ask_rev_id2(tCurrencyItemRev, &revId));
							TC_write_syslog("Finding rev ID: %s\n" ,revId);
							iNoOfObjs = 0;
							tObjectList[iNoOfObjs++] = tCurrencyItemRev;
							ERROR_CALL(iFail = GRM_find_relation_type(TI_MASTER_FORM_REL, &tRelation));
							ERROR_CALL(iFail = GRM_list_secondary_objects_only(tCurrencyItemRev, tRelation, &iFormCnt, &tFormTags));
							if(iFormCnt > 0 && tRelation != NULLTAG)
							{
								tObjectList[iNoOfObjs++] = tFormTags[0];
								ERROR_CALL(iFail = AOM_refresh(tFormTags[0], true));
								double value = 0;
								TC_write_syslog("\nCount of attributes : %d", mAttributeValues.size());
								for (mItr = mAttributeValues.begin(); mItr != mAttributeValues.end(); ++mItr)
								{
									if((mItr->second).size() > 0)
									{
										value = stod(mItr->second);
									}
									else
									{
										value = 0.0;
									}
									ERROR_CALL(iFail = AOM_set_value_double(tFormTags[0] ,mItr->first.c_str(), value));
									TC_write_syslog("%s: %s\n" ,mItr->first.c_str(),mItr->second.c_str());
								}
								/*ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_EUR_MPR, sConversionMode.c_str()));
								ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_GBP_MPR, sConversionMode.c_str()));
								ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_USD_MPR, sConversionMode.c_str()));
								ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_EUR_MONTHEND, sYearMonth.c_str()));
								ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_GBP_MONTHEND, sYearMonth.c_str()));
								ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_USD_MONTHEND, sYearMonth.c_str()));*/

								if(!tc_strcmp(sConversionMode.c_str(),"Annual")){

									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_EUR_MPR, sYearMonth.c_str()));
									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_GBP_MPR, sYearMonth.c_str()));
									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_USD_MPR, sYearMonth.c_str()));

								}
								if(!tc_strcmp(sConversionMode.c_str(),"Monthly")){

									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_EUR_MONTHEND, sYearMonth.c_str()));
									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_GBP_MONTHEND, sYearMonth.c_str()));
									ERROR_CALL(iFail = AOM_set_value_string(tFormTags[0], ATTRIBUTE_USD_MONTHEND, sYearMonth.c_str()));

								}

								ERROR_CALL(iFail = AOM_save(tFormTags[0]));
								if(iFail != ITK_ok)
								{
									result.importStatus = ERR_FAIL_STATUS;
									result.reasonForFailure = "Master form save failed. Please contact PLM Admin";
								}
								ERROR_CALL(iFail = AOM_refresh(tFormTags[0], false));

								set_owner(tObjectList, iNoOfObjs, tCurrencyItem);
							    add_release_status(tObjectList, iNoOfObjs, "Released" );

								if(result.importStatus != ERR_FAIL_STATUS)
									result.importStatus = SUCCESS_STATUS;
							}
							else
							{
								result.importStatus = ERR_FAIL_STATUS;
								result.reasonForFailure = "Master form not found";
							}

							ERROR_CALL(iFail = AOM_refresh(tCurrencyItemRev , false));
						}
						else
						{
							result.importStatus = ERR_FAIL_STATUS;
							result.reasonForFailure = "Revise Operation failed";
						}
					}
					else // place holder to reset currency required to true if required
					{
						result.importStatus = ERR_FAIL_STATUS;
					    result.reasonForFailure= "Currency Code(s) " + sMissingCurrencies + " not present in TC datamodel. Please contact PLM Admin ";

						lCurrencyExists = true;
					}

					localcurrImportRes.currencyConversionResponseInfo.push_back(result);
				}
			}

			catch(...) {

				TC_write_syslog( "\n ##### In catch block \n");
				result.importStatus = "";
				result.reasonForFailure = "Exception Occured. Please refer TC syslog";
				localcurrImportRes.currencyConversionResponseInfo.push_back(result);
			}

			eMailNotification_currency(localcurrImportRes,"SITE LOCAL");
			TC_write_syslog("\n Currency Transfer Completed");
			return localcurrImportRes;
	}

TITCERPIntegrationImpl::GetSellingPriceResponse TITCERPIntegrationImpl::importSellingPriceInfo ( const GetSellingPriceInput& getSellingPriceInputs )
{
	TC_write_syslog("getStandardCostInputs ",getSellingPriceInputs.sellingPriceInputData);
		TITCERPIntegrationImpl::GetSellingPriceResponse sellingPriceRes;
		return sellingPriceRes;
}


TITCERPIntegrationImpl::GetStandardCostResponse TITCERPIntegrationImpl::importStandardCostInfo ( const GetStandardCostInput& getStandardCostInputs )
{
	/*TC_write_syslog("getStandardCostInputs ",getStandardCostInputs.standardCostInputData);
		TITCERPIntegrationImpl::GetStandardCostResponse sellingPriceRes;
		return sellingPriceRes;*/
	/*TC_write_syslog("getStandardCostInputs ",getStandardCostInputs.standardCostInputData);
		TITCERPIntegrationImpl::GetStandardCostResponse stdCostResponse;

		////TITCERPIntegrationImpl::StandardCostInputData =  getStandardCostInputs.standardCostInputData;

		stdCostResponse = tiStandardCostTransfer(getStandardCostInputs);

		return stdCostResponse;*/


		TITCERPIntegration::GetStandardCostResponse stdCostResponse;
		std::vector<StandardCostInputData>::iterator vcStdCostDataMainIter;

		//Getting StandardCost records from input.
		std::vector<StandardCostInputData> vcStdCostDataMain = getStandardCostInputs.standardCostInputData;

			std::vector<StandardCostInputData>::iterator costDataitr;

		//for( vcStdCostDataMainIter=vcStdCostDataMain.begin();vcStdCostDataMainIter != vcStdCostDataMain.end();vcStdCostDataMainIter++){

			//vector<TIStandardCostData> vcStdCostData = (*vcStdCostDataMainIter).tiStdCostDataMain;
			std::vector<StandardCostInputData> vcStdCostData  = getStandardCostInputs.standardCostInputData;

			for( costDataitr=vcStdCostData.begin();costDataitr != vcStdCostData.end();costDataitr++){
				string sItemID = (*costDataitr).itemID;
				string sBPCSItemID = (*costDataitr).bpcsItemID;
				/*string sItemRevID = (*costDataitr).itemRevID;
				string sCostID = (*costDataitr).costID;
				string sBPCSItemID = (*costDataitr).bpcsItemID;
				string sItemDesc = (*costDataitr).itemDesc;
				string sExtraDesc = (*costDataitr).extraDesc;*/
				logical bExcPartExist = false;
				if(sItemID !=""){
					bExcPartExist = readExclusionPartsList(sItemID);
				}
				else if(sBPCSItemID != ""){
					bExcPartExist = readExclusionPartsList(sBPCSItemID);
				}


				if(bExcPartExist == false){

					vector<StandardCostRecord> vectorTIStandardCostRecord = (*costDataitr).standardCostRecords;

					vector<TIStandardCostRecord> tempStdCostRecords;

					if(vectorTIStandardCostRecord.size() !=0){
						tempStdCostRecords = processStandardCostData(stdCostResponse, *costDataitr);
					}

					//Creating, revising & updating the cost form.
					if(tempStdCostRecords.size() !=0){
						importData(stdCostResponse, (*costDataitr), tempStdCostRecords);
						tempStdCostRecords.clear();
					}
				}else{
					sendResponseInfo(1, stdCostResponse,  PART_EXIST_IN_EXCLUSION_LIST,(*costDataitr).costID,(*costDataitr).itemID,(*costDataitr).itemRevID,(*costDataitr).bpcsItemID);
				}

			}

		//}
			if(stdCostResponse.standardCostResponse.size()!=0){
				char* cSiteName = getCurrentSiteID();
				eMailNotification(stdCostResponse, cSiteName /*  erpSystemName*/);
			}


		return stdCostResponse;
}


TITCERPIntegrationImpl::GetPartSyncTransferResponse TITCERPIntegrationImpl::savePartSyncInfo ( const GetPartSyncTransferInput& getPartSyncTransferInputs )
{
	TC_write_syslog("getPartSyncTransferInputs ",getPartSyncTransferInputs.partSyncInputData);
		TITCERPIntegrationImpl::GetPartSyncTransferResponse sellingPriceRes;
		return sellingPriceRes;
}

void eMailNotification_currency(TITCERPIntegration::GetCurrencyConversionImportResponse vResponse ,char* siteName) {

	int iFail = ITK_ok;
	int  iFileOpenErrCode    = 0;

	char *pcMailBodyFileName	= NULL;

	FILE *fMailBodyFile			= NULL;

	logical bExistFailResponse = false;

		string sSiteName(siteName);
		string sMailSub =sSiteName+" - [ERP-PLM]  Currency data import failed -";
		if(vResponse.currencyConversionResponseInfo.size() > 0){
		//if(stdCostResponse.standardCostResponse.size()>0){

			pcMailBodyFileName = USER_new_file_name("cr_mail_body","TEXT","dat",1);
			TC_write_syslog("\npcMailBodyFileName : %s",pcMailBodyFileName);
			iFileOpenErrCode = fopen_s(&fMailBodyFile,pcMailBodyFileName, "w" );

			fprintf(fMailBodyFile,"\nDear user\n");
			fprintf(fMailBodyFile,"\nStatus of updating currency data for the following conversion IDs(s):\n\n");

			fprintf(fMailBodyFile,"\n--------------------------------------------------------------------------------\n");
			fprintf(fMailBodyFile,"%s\t\t\t\t%s ", "Conversion ID","Reason For Failure\n");

			for( int iCnt = 0; iCnt <vResponse.currencyConversionResponseInfo.size();iCnt++) {
				string sErrorStr ="";

				string sImportStatus = vResponse.currencyConversionResponseInfo[iCnt].importStatus;

				if(tc_strcmp(sImportStatus.c_str(),ERR_FAIL_STATUS)==0){

					string sConversionID =vResponse.currencyConversionResponseInfo[iCnt].conversionID;
					string sConversionMode =vResponse.currencyConversionResponseInfo[iCnt].conversionMode;
					string sReasonForFailure = vResponse.currencyConversionResponseInfo[iCnt].reasonForFailure;
					sErrorStr =sErrorStr+"\n"+sConversionID +"\t\t\t\t"+sReasonForFailure+"\n";
					if(sErrorStr !="")
						fprintf(fMailBodyFile,"  %s\n",sErrorStr.c_str());

					bExistFailResponse = true;
				}
			}

			fprintf(fMailBodyFile,"\n--------------------------------------------------------------------------------\n");
			fprintf(fMailBodyFile,"\nThanks\n");
			fprintf(fMailBodyFile,"PLM Admin\n");

			if(fMailBodyFile != NULL && bExistFailResponse == true)
			{
				fclose(fMailBodyFile);
				iFail = sendEMail( sMailSub,  pcMailBodyFileName);
				if(iFail != ITK_ok)
					TC_write_syslog(ERR_MAIL_NOTIFICATION);
			}
			else{
				TC_write_syslog("\nAll Currency values are updated successfully\n");
			}
		}

	//	remove(pcMailBodyFileName );
}

int add_release_status(tag_t *tObjectList,int NoOfObjs, string sValue)
{
	int iFail = ITK_ok;
	tag_t	tStatus = NULLTAG;

	ERROR_CALL(iFail = RELSTAT_create_release_status(sValue.c_str(), &tStatus));
	ERROR_CALL(iFail = RELSTAT_add_release_status(tStatus, NoOfObjs, tObjectList, true));

	return ITK_ok;
}


int set_owner(tag_t *tObjectList,int NoOfObjs, tag_t tTarget)
{
    int		iFail	= ITK_ok;
    tag_t ownerTag = NULLTAG,
        groupTag = NULLTAG;
	try
	{
		ERROR_CALL(iFail = AOM_ask_value_tag(tTarget, "owning_user", &ownerTag));

		ERROR_CALL(iFail = AOM_ask_value_tag(tTarget, "owning_group", &groupTag));
		for (int i = 0; i < NoOfObjs; i++)
		{
			ERROR_CALL(iFail = AOM_refresh(tObjectList[i], true));
			ERROR_CALL(iFail = AOM_set_ownership(tObjectList[i], ownerTag, groupTag));
			ERROR_CALL(iFail = AOM_save(tObjectList[i]));
			ERROR_CALL(iFail = AOM_refresh (tObjectList[i] , false));

		}

    	}catch(...) {
			TC_write_syslog(" add_release_status Unhandled Exception");
    }
    return iFail;
}



