
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_updatevendorpart_materialinfo
 * Description				: Updates the vendor part based on material substance declaration revision data
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *							
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_updatevendorpart_materialinfo(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iReferences             = 0,
		iReturnedVParts			= 0;
	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL;
		
	char *pcObjectType			= NULL,
		 *pcPartType			= NULL;

	string strPropNamesArr[]	= {TD_ATTACHMENT_FINISH_ATTR, TD_DURATION_MAX_ATTR, TD_MAX_PROCESS_ATTR, TD_MOISTURE_SENSITIVITY_ATTR};
	
	map<string,string> strPropNameValueMap;
	list<string> strAttrList( strPropNamesArr, strPropNamesArr + sizeof(strPropNamesArr) / sizeof(string) );
	
	const char * __function__ = "teradyne_updatevendorpart_materialinfo";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
		
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_PART_MSD_DECL_REV)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttaches[i], strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
					if(strPropNameValueMap.size() > 0) {

					   TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iReferences, &tReferences), TD_LOG_ERROR_AND_THROW);

						for(int ref=0;ref<iReferences;ref++){
						  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReferences[ref], &pcPartType), TD_LOG_ERROR_AND_THROW);
						 
						    if(!tc_strcmp(pcPartType, TD_MFG_PART)) {

							    TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tReferences[ref], TD_ATTACHMENT_FINISH_ATTR, strPropNameValueMap.find(TD_ATTACHMENT_FINISH_ATTR)->second), TD_LOG_ERROR_AND_THROW);
							    TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tReferences[ref], TD_DURATION_MAX_ATTR, strPropNameValueMap.find(TD_DURATION_MAX_ATTR)->second), TD_LOG_ERROR_AND_THROW);
							    TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tReferences[ref], TD_MAX_PROCESS_ATTR, strPropNameValueMap.find(TD_MAX_PROCESS_ATTR)->second), TD_LOG_ERROR_AND_THROW);
					   	    	TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tReferences[ref], TD_MOISTURE_SENSITIVITY_ATTR, strPropNameValueMap.find(TD_MOISTURE_SENSITIVITY_ATTR)->second), TD_LOG_ERROR_AND_THROW);
							
								logical isCheckOut=false;

								POM_AM__set_application_bypass(true);

								TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tReferences[ref], TD_CHNG_RESN_ATTR, "Teradyne-UpdateVendorPartMaterialInformation"), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = RES_is_checked_out(tReferences[ref], &isCheckOut), TD_LOG_ERROR_AND_THROW);
								if (isCheckOut)
								{
									TERADYNE_TRACE_CALL(iStatus = RES_checkin(tReferences[ref]), TD_LOG_ERROR_AND_THROW);
								}
								else
								{
									TERADYNE_TRACE_CALL(iStatus = RES_checkout2(tReferences[ref], " ", NULL, TD_TEMP_PATH, RES_EXCLUSIVE_RESERVE), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = RES_checkin(tReferences[ref]), TD_LOG_ERROR_AND_THROW);
								}
								POM_AM__set_application_bypass(false);
							}
						}
					}
				}
				Custom_free(pcObjectType);
				Custom_free(pcPartType);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttaches);
	Custom_free(tReferences);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}