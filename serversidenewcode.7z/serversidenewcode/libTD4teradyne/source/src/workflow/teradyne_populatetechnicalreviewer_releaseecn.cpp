/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_populatetechnicalreviewer_releaseecn.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-PopulateTechReviewerRelease action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  18-Mar-2015                       Haripriya                    	    Initial Creation
#  20-Apr-2015                       Haripriya                          Modified teradyne_get_primary_imapacted_project_values as per UE Errors
#  29-Apr-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  07-May-2015                       Haripriya                    	    Modified code to update Change Admin Value on Release ECN
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
/*******************************************************************************
 * Function Name			: teradyne_populatetechnicalreviewer_releaseecn
 * Description				: This function will Update Required Technical Reviewer and DesignDocCoordinator in ReleaseECN Revision 
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Searches the DivpartRevision in Solution Items Folder
 *							  2. If DivpartRevision is Found ,Gets the PartType Value and creates the Preference as TD4_$PartType_ReviewerMatrix.
 *							  3. Gets the Primary Project and Other impacted Projects value in ReleaseECNRevision and Searches the Reviewer as 
 *                               per the role,if mandatory field is empty need to throw an error.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_populatetechnicalreviewer_releaseecn(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iFound              = 0;

	 bool bGCSValue         = false,
		  bcheck            = false;

	tag_t *tAttachtag       = {NULLTAG};
	char *pcObjectType		= NULL;
	tag_t projectTag        =NULLTAG; 
	
	vector<string> CBreviewerValues,impprojValues;

	std::map<string,string> strPropNameValueMap;

	const char * __function__    = "teradyne_populatetechnicalreviewer_releaseecn" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment,&iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE)) {
				
					//calling function to primaryproject and Impacted Project values
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_primary_imapacted_project_values( tAttachtag[i],impprojValues),TD_LOG_ERROR_AND_THROW);
					//calling function to set ReqTechnicalreviewerList Value.
					TERADYNE_TRACE_CALL(iStatus = teradyne_set_techreviewer_value( tAttachtag[i], impprojValues),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(tAttachtag[i],strPropNameValueMap,TD_CHANGE_ADMIN_ATTR),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tAttachtag[i],TD_CHANGE_ADMIN_ATTR,strPropNameValueMap.find(TD_CHANGE_ADMIN_ATTR)->second),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttachtag[i],TD_DESIGN_DOC_WORK_REQ_ATTR,&bGCSValue),TD_LOG_ERROR_AND_THROW);
 
					if(bGCSValue)
					{
						for(int k=0;k<impprojValues.size();++k)
						{
							//Finding the project and getting the Reviewer Values as in the Preference
							TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(impprojValues.at(k).c_str(),TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_DESIGN_DOC_COORDINATOR_ATTR,CBreviewerValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
		               
							
						}	
					}
					char **pcCBreviewerarray   = NULL;

					//Converting vector to char** array and Setting Value on release ECN Revision
					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( CBreviewerValues,&pcCBreviewerarray),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_DESIGN_DOC_COORDINATOR_RELEASE_ATTR,(int)CBreviewerValues.size(),pcCBreviewerarray),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcCBreviewerarray);	
				}
				Custom_free(pcObjectType);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttachtag);
	CBreviewerValues.clear();
	impprojValues.clear();
	
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_primary_imapacted_project_values
 * Description				: Gets the Value of primary and impacted project lists
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tAttachtag   (I)	  - vector<string>
 *							  vimpprojValues  (O) - vector<string>
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_primary_imapacted_project_values( tag_t tAttachtag,vector<string> &vimpprojValues)
{
	int iStatus					= ITK_ok;

	char *pcProjAttr            = NULL;

	bool bcheck                 = false;

	const char * __function__ = "teradyne_get_primary_imapacted_project_values";
	TERADYNE_TRACE_ENTER();

	try 
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag,TD_PRIMARY_PROJ_ATTR,&pcProjAttr),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(tAttachtag,TD_IMPACTED_PROJS_ATTR,vimpprojValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
		vimpprojValues.push_back(pcProjAttr);
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(pcProjAttr);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_propname_from_Preference
 * Description				: checking the property read from preference value is mandatory or not
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : szvalue   (I)	          - string
 *							  techreviewerValues  (O) - vector<string>
 *                            szPropname (O)          - string
 *                            bcheck (O)              - bool
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_propname_from_Preference( string szvalue,vector<string> &techreviewerValues,string &szPropname,bool &bcheck)
{
	int iStatus					= ITK_ok;

	char *pcProjAttr            = NULL;

	string szTempvalue          = "";

	const char * __function__ = "teradyne_get_propname_from_Preference";
	TERADYNE_TRACE_ENTER();

	try 
	{
		int n=(int)szvalue.find("*");
		if(n!= -1)
		{
			szPropname = szvalue.substr(0,n);
			szTempvalue = szvalue.substr(0,n);
			bcheck=true;
		}
		else
		{
			szPropname=szvalue;
			szTempvalue=szvalue;
			bcheck=false;
		}
		techreviewerValues.push_back(szTempvalue.erase(0,3).append(":"));
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(pcProjAttr);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

		