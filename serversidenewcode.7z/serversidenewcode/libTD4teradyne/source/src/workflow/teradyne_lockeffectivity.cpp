/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_lockeffectivity.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-LockEffectivity action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Apr-2015                       Vijayasekhar                    	Added function definitions teradyne_lockeffectivity
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  28-May-2015                       Haripriya                    	    Modified the function  to overcome instance locked error
#  10-Jun-2015                       Haripriya                    	    Modified teradyne_set_protection function  to overcome instance locked error
#  19-Aug-2015                       Haripriya                    	    Modified teradyne_set_protection function to perform refresh operstion after checking the object is modifiable
#  26-Aug-2015                       Haripriya                    	    Modified teradyne_set_protection and added  teradyne_lock_effectivities_divpart function to lock and unlock the Solution Item effectivity
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_lockeffectivity
 * Description				: Locks the effectivity for the relase status of the part revision                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_lockeffectivity(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL;
	char *pcObjectType			= NULL;

	const char * __function__ = "teradyne_lockeffectivity";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE)) {
				
					//Locks the effectivity
					TERADYNE_TRACE_CALL(iStatus = teradyne_set_protection(tAttaches[i], true,pcObjectType), TD_LOG_ERROR_AND_THROW);
				}
				Custom_free(pcObjectType);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_set_protection
 * Description				: Sets the protection for the effectivity of Release status
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject          (I) - Object tag tag_t
 *							  bLock            (I) - lock if true or unlock if false bool
 *                            pcObjectType     (I) - object type
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:If lock is true then set protection or release protection
 ******************************************************************************/
int teradyne_set_protection(tag_t tObject, bool bLock,char *pcObjectType) {

	int iStatus					= ITK_ok,
		ieffectivities			= 0;
	tag_t *tEffectivities		= NULL, 
		  tRelStatus			= NULLTAG,
		  tECNtag               = NULLTAG;
	bool bIsProtected			= false,
		 bitemMod               = true,
		 bitemRevMod            = true;

	const char * __function__ = "teradyne_set_protection";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_effectivities(tObject, &ieffectivities, &tEffectivities, &tRelStatus), TD_LOG_ERROR_AND_THROW);
		if(tRelStatus != NULLTAG) {
		
			for(int i = 0; i < ieffectivities; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_is_protected(tRelStatus, tEffectivities[i], &bIsProtected), TD_LOG_ERROR_AND_THROW);
				if((!bIsProtected && bLock) || (bIsProtected && !bLock)) {
					POM_AM__set_application_bypass(true);
				    TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tObject,&tECNtag),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tECNtag,&bitemMod),TD_LOG_ERROR_AND_THROW);
					if(!bitemMod)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tECNtag ,true) ,TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tObject,&bitemRevMod),TD_LOG_ERROR_AND_THROW);
					if(!bitemRevMod)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject ,true) ,TD_LOG_ERROR_AND_THROW);
					}
					if(!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE))
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_lock_effectivities_divpart(tObject,true), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus = WSOM_eff_set_protection(tRelStatus, tEffectivities[i], bLock), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tRelStatus), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE))
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_lock_effectivities_divpart(tObject,false), TD_LOG_ERROR_AND_THROW);
					}
					if(!bitemMod)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tECNtag,false), TD_LOG_ERROR_AND_THROW);
					}
					if(!bitemRevMod)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject,false), TD_LOG_ERROR_AND_THROW);
					}
					POM_AM__set_application_bypass(false);
				}
				bIsProtected = false;
			}	
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tEffectivities);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_effectivities
 * Description				: Get the effectivities and release status for the effectivity
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject          (I) - Object tag tag_t
 *							  iEffectivities   (O) - Effectivity Count int*
 *                            tEffectivities   (OF)- Effectivity tags tag_t*
 *                            tRelStat		   (O) - Release status tag tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: Assuming that only one release status and one effectivity
 ******************************************************************************/
int teradyne_get_effectivities(tag_t tObject, int* iEffectivities, tag_t** tEffectivities, tag_t* tRelStat)  {

	int iStatus					= ITK_ok,
		iRelStatus				= 0;
	tag_t *tRelStatus			= NULL;
	char *pcRelStatusType		= NULL;

	const char * __function__ = "teradyne_get_effectivities";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tObject, &iRelStatus, &tRelStatus), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iRelStatus; i++) {
		
			TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tRelStatus[i], &pcRelStatusType) ,TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcRelStatusType, TD_REL_STATUS_NAME) == 0) {
			
				TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tRelStatus[i], iEffectivities, tEffectivities), TD_LOG_ERROR_AND_THROW);
				*tRelStat = tRelStatus[i];
				break;
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tRelStatus);
	Custom_free(pcRelStatusType);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_lock_effectivities_divpart
 * Description				: Loads the part in  Solution Item after checking the instance.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject          (I) - Object tag tag_t
 *							  bRefresh         (I) - whether to refresh or not boolean
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: Assuming that only one release status and one effectivity
 ******************************************************************************/
int teradyne_lock_effectivities_divpart(tag_t tObject,bool bRefresh) 
{

	int iStatus					= ITK_ok,
		iRefCount				= 0;
	tag_t *tRefListTag			= NULL;
	char *pcRelStatusType		= NULL;

	const char * __function__ = "teradyne_lock_effectivities_divpart";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tObject, TD_SOLUTION_ITEMS_REL_NAME, &iRefCount, &tRefListTag), TD_LOG_ERROR_AND_THROW);

		for(int j = 0; j < iRefCount; j++)
		{
			bool bDivMod  = true,bDivRevMod= true;
			tag_t tdivtag=NULLTAG;

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRefListTag[j],&tdivtag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tRefListTag[j],&bDivRevMod),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tdivtag,&bDivMod),TD_LOG_ERROR_AND_THROW);
			if(!bDivRevMod)
			{
				TERADYNE_TRACE_CALL(iStatus = POM_load_instances_any_class(1,&tRefListTag[j] ,POM_no_lock) ,TD_LOG_ERROR_AND_THROW);
			}
			if(!bDivMod)
			{
				TERADYNE_TRACE_CALL(iStatus = POM_load_instances_any_class(1, &tdivtag, POM_no_lock), TD_LOG_ERROR_AND_THROW);
				//TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tdivtag ,bRefresh) ,TD_LOG_ERROR_AND_THROW);
			}
		}
		Custom_free(tRefListTag);
	} 
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}