/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_genECNSafetyReport.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-GenerateECNSafetyReport action handler,
#								   which is used to create ECN Safety report.
#      Project         :           libTD4teradyne          
#      Author          :           Selvanayaki          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  23-May-2019                       Marjorie                    	Added function definitions teradyne_genECNSafetyReport
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>


typedef map<string,string> MapProcessHistory;

struct ProcessHistoryComparator {
   bool operator()(MapProcessHistory processOne, MapProcessHistory processTwo){
      return (processOne.find(TD_ECN_PROCESS_END_DATE_VAL)->second < processTwo.find(TD_ECN_PROCESS_END_DATE_VAL)->second);
   }
};


string cHtMLFileContentSafety = "";
/*******************************************************************************
 * Function Name			: teradyne_genECNSafetyReport
 * Description				: This function will populates the action handler 
 *							  Teradyne-GenerateECNSafetyReport                           
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to workflow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:  
 *
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_genECNSafetyReport(EPM_action_message_t msg) 
{
	int iStatus						= ITK_ok;	
	int	iImpObjCount				= 0;
	int	iSolObjCount				= 0;
	int	iAttachCount				= 0;

	tag_t *ptAttaches				= NULL;
	tag_t tSecObjs					= NULLTAG;
	tag_t *tImpObjFoundTag			= NULL;
	tag_t *tSolObjFoundTag			= NULL;
	
	char *pcTypeName                = NULL;																																																																																																																																																																																																
	char *pcECNClosureStsValue		= NULL;

	string szECNName				= "";	
	string strSafetyReportAttr[]	= {TD_DIFFITEM_RESULT, TD_DIFFITEM_PART,TD_IMPSOL_REV, TD_PART_WARNINGS, TD_IMPSOL_DESC, TD_IMPSOL_TYPE};

	string strImpandSolItmColVal[]	= {TD_ITEM_ID_ATTR,TD_OBJECT_DESC_ATTR,TD_OBJECT_TYPE_ATTR,TD_ITEM_REV_ID_ATTR, TD_PART_REV_STAMP, TD_PART_MIN_SHIPPABLE_REV};
	string strECNAttr[]				= {TD_ITEM_ID_ATTR,TD_OBJECT_TYPE_ATTR,TD_ECN_OWN_USER,TD_START_DATE,TD_CLOSURE_DATE_ATTR,TD_ECN_SYNOP,TD_ECN_PRIMARY_PRJ,TD_ECN_DESC};
	 
	std::map<string,string> strECNPropNameValueMap;
								
	vector<string> resPropValVec;
	vector<string> resImpValVec;
	vector<string> resSolValVec;
	vector<string> resECNDocValVec;
	vector<string> resECNProcessVec;
	vector<string> resECNEffVec;

	const char * __function__    = "teradyne_genECNSafetyReport" ;
	TERADYNE_TRACE_ENTER();

	try{
		if(msg.task != NULLTAG) 
		{		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{	
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				
				//request will be processed for the below specified item revisions
				if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) ||(tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)))
				{		
					
					std::list<string> strAttrList( strECNAttr, strECNAttr + sizeof(strECNAttr) / sizeof(string) );
					
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[i],strAttrList,strECNPropNameValueMap),TD_LOG_ERROR_AND_THROW);
					setgNULLPropertyExecution(false);
					if( strECNPropNameValueMap.size() > 0 )
					{						
						szECNName.assign(strECNPropNameValueMap.find(TD_ITEM_ID_ATTR)->second);	
					}

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i],TD_ECN_CLOSURE_STATUS_ATTR,&pcECNClosureStsValue),TD_LOG_ERROR_AND_THROW);
		
					std::list<string> strECNRelationAttrList( strImpandSolItmColVal, strImpandSolItmColVal + sizeof(strImpandSolItmColVal) / sizeof(string) );

					if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0)))
					{
						//calling functions to get list of Impacted Items
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrCount(ptAttaches[i], TD_ECR_IMPREL_NAME, &iImpObjCount, &tImpObjFoundTag), TD_LOG_ERROR_AND_THROW);					
					}

					//calling functions to get list of Solution Items
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrCount(ptAttaches[i], TD_ECR_SOLREL_NAME, &iSolObjCount, &tSolObjFoundTag), TD_LOG_ERROR_AND_THROW);			
					
					//functions to create and write content in Excel file.
					TERADYNE_TRACE_CALL(iStatus = teradyne_write_excelfile_safety(ptAttaches[i],(char *)szECNName.c_str(),iImpObjCount, iSolObjCount, tImpObjFoundTag, tSolObjFoundTag, pcECNClosureStsValue), TD_LOG_ERROR_AND_THROW);							
				   
					Custom_free(tImpObjFoundTag);
					Custom_free(tSolObjFoundTag);			
					Custom_free(pcTypeName);	
					Custom_free(pcECNClosureStsValue);
				}
				szECNName.clear();
				strECNPropNameValueMap.clear();
				resPropValVec.clear();
				resImpValVec.clear();
				resSolValVec.clear();
				resECNProcessVec.clear();
				resECNEffVec.clear();
			}
			Custom_free(ptAttaches);
		}		
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	    
	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_get_ECNRelationPropertyattrCount
* Description		: Returns the number of Impacted and Solution Items and their corresponding tags
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_ECNRelationPropertyattrCount(tag_t ptAttaches, char *cECNRelName, int *iImpObjCount, tag_t **tImpObjFoundTag)
{
	int iStatus                     = ITK_ok;  
	int iObjCount		            = 0;

	tag_t tRelationTag	            = NULLTAG;

	char *pcPartCategoryValue		= NULL;
	char *pcAttrValue				= NULL;

	std::map<string,string> strECNRelationPropValueMap;

	vector<string> resPropVec;
	vector<string> vecRelString;

	char* __function__ = "teradyne_get_ECNRelationPropertyattrCount";
	TERADYNE_TRACE_ENTER();

	try
	{	
		vecRelString = teradyne_generate_tokens(cECNRelName, ",");
	    if(vecRelString.size() > 0)
        {
			for( int iVector=0; iVector<vecRelString.size(); iVector++ )			
			{
				tag_t *tObjFoundTag	 = {NULLTAG};
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(vecRelString[iVector].c_str(),&tRelationTag),TD_LOG_ERROR_AND_THROW);			
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches,tRelationTag,&iObjCount,&tObjFoundTag),TD_LOG_ERROR_AND_THROW);
				if (iObjCount > 0 )
				{					
					*iImpObjCount = iObjCount;
					*tImpObjFoundTag = tObjFoundTag;
				}
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)  
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_write_excelfile_safety
* Description		: Validating PartCategory & PartSubcategory
*                     attribute in DivPartRevision
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : Gets the PartCategory & PartSubcategory Value
*                     from DivisionalPartRevision and checks 
*                     whether the value has NOTLISTED AND UNKNOWN Value
*                     and ifnot concatenates the value with hypen .
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_write_excelfile_safety(tag_t tTargetObject, char *pcECNID, int iImpObjCount, int iSolObjCount, tag_t *tImpObjFoundTag, tag_t *tSolObjFoundTag, char *pcECNClosureStsValue)
{	
	int iStatus								= ITK_ok;  
	int iAttrCnt							= 0;
	int iTypesize							= 0;
		
	char *cHtLFilePath						= NULL;
	//char *cHtMLFileContentSafety					= NULL;		
	char *pcECNProcess						= NULL;
	char *pcSolItemid						= NULL;
	char *pcImpItemid						= NULL;
	char *pcDatasetID						= NULL;
	char *pcECNReportFileLoc			    = NULL;
	char *pcTypeName						= NULL;	

	string strCurTimeStamp					= "";
	string pcChangeID						= "";
	string pcObjectID						= "";
	string strOutXlsxPath					= "";
		
	FILE *fHtMLFile							= NULL;
	
	string strImpandSolItmColName[]			= {TD_IMPSOL_NAME,TD_IMPSOL_DESC,TD_IMPSOL_TYPE,TD_IMPSOL_REV,TD_IMPSOL_REV_STAMP,TD_IMPSOL_MIN_SHIPPABLE_REV};
	string strImpandSolItmColNameWidth[]	= {TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2};
	
	string strBOMChangesColAttr[]			= {TD_DIFFITEM_RESULT, TD_DIFFITEM_PART, TD_PART_WARNINGS, TD_IMPSOL_DESC, TD_IMPSOL_TYPE};								
	string strChangesColAttrWidth[]			= {TD_DIFFITEM_RESULT_WIDTH,TD_DIFFITEM_NAME_WIDTH,TD_DIFFITEM_SEQNO_WIDTH,TD_DIFFITEM_DESC_WIDTH,TD_DIFFITEM_QTY_WIDTH};
	
	string strConvrtXlsCmd					= "";

	tag_t tImpitemtag						= NULLTAG;
	tag_t tSolitemtag						= NULLTAG; 
	bool bNoticeFlag						= "true";
	date_t curdate;
		
	vector<string> resBLDiffValue, resImpValVec;
	
	bool  bObjectfound = false;

	char* __function__ = "teradyne_write_excelfile_safety";
	TERADYNE_TRACE_ENTER();
	
	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetObject, &pcTypeName), TD_LOG_ERROR_AND_THROW);

		// MEM allocation of File
		cHtLFilePath = (char*)MEM_alloc(FILE_LEN * sizeof(char));
		pcObjectID.assign(TD_ECN_SAFETY_TITLE_VAL); pcObjectID.append(": "); pcObjectID.append(pcECNID);	
		//getting current date and time
		TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp(TD_DATE_YMD_CONSTANT, strCurTimeStamp,curdate), TD_LOG_ERROR_AND_THROW);
			
		//Frame Html file content
		cHtMLFileContentSafety.assign("<HTML xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\">\n<HEAD>\n</HEAD>\n<BODY><CENTER><FONT></FONT></CENTER><BR>");
		std::list<string> strImpandSolItmRAttrList( strImpandSolItmColName, strImpandSolItmColName + sizeof(strImpandSolItmColName) / sizeof(string) );
		std::list<string> strImpandSolItmColWidthList( strImpandSolItmColNameWidth, strImpandSolItmColNameWidth + sizeof(strImpandSolItmColNameWidth) / sizeof(string) );	
		if (!resImpValVec.empty())
			resImpValVec.clear();	

		//updating Main Block in file
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock_safety((char*)pcObjectID.c_str(), TD_HEADING_TYPE_1),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_safety("",false),TD_LOG_ERROR_AND_THROW);		
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety(TD_ECN_TITLE, TD_ECN_SAFETY_TITLE_VAL, TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList,resImpValVec),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety(TD_ECN_REPORT_TITLE, (char*)strCurTimeStamp.c_str(), TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec),TD_LOG_ERROR_AND_THROW);
		
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_safety(false),TD_LOG_ERROR_AND_THROW);
		
	
		//updating BOM Line information related to difference between impacted and solution Item
		if ((iImpObjCount > 0) || (iSolObjCount > 0))
		{
			std::list<string> strchangesColAttrList( strBOMChangesColAttr, strBOMChangesColAttr + sizeof(strBOMChangesColAttr) / sizeof(string) );
			std::list<string> strchangesColWidthList( strChangesColAttrWidth, strChangesColAttrWidth + sizeof(strChangesColAttrWidth) / sizeof(string) );			
			
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock_safety(TD_DIFFITEM_TITLE,  TD_HEADING_TYPE_1),TD_LOG_ERROR_AND_THROW);			
			for( int jCnt=0; jCnt < iSolObjCount; jCnt++ )		                
			{
				//getting item tag and id of Solution Item
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolObjFoundTag[jCnt], &tSolitemtag),TD_LOG_ERROR_AND_THROW);     			
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2( tSolitemtag, &pcSolItemid),TD_LOG_ERROR_AND_THROW);

				char *pcSolitemTypeName = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSolObjFoundTag[jCnt], &pcSolitemTypeName), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(pcSolitemTypeName,TD_DIV_PART_REV) != 0) {
					Custom_free(pcSolitemTypeName);
					continue;
				}
				Custom_free(pcSolitemTypeName);
				
				if (!pcChangeID.empty())
					pcChangeID.clear();	

				pcChangeID.assign(TD_DIFFITEM_HEADER_1);
				
				pcChangeID.append(pcSolItemid);				
				bObjectfound = false;
				for( int iCnt = 0; iCnt < iImpObjCount; iCnt++ )		
				{	
					 //getting item tag and id of Impacted Item
					 TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tImpObjFoundTag[iCnt], &tImpitemtag),TD_LOG_ERROR_AND_THROW);
					 TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2( tImpitemtag, &pcImpItemid),TD_LOG_ERROR_AND_THROW);	
					 if (tc_strcmp(pcImpItemid, pcSolItemid) == 0) 
				     {
						char *pcImpitemTypeName = NULL;
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tImpObjFoundTag[iCnt], &pcImpitemTypeName), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(pcImpitemTypeName,TD_DIV_PART_REV) != 0) {
							Custom_free(pcImpitemTypeName);
							continue;
						}
						Custom_free(pcImpitemTypeName);

						if (!resBLDiffValue.empty())
							resBLDiffValue.clear();		

						iStatus = teradyne_list_bvr_diffs_safety(tImpObjFoundTag[iCnt], tSolObjFoundTag[jCnt], resBLDiffValue);						
					    if (iStatus == 1)
						{
							iStatus = 0;
							TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_safety("",false),TD_LOG_ERROR_AND_THROW);	
							TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety((char *)pcChangeID.c_str(),  TD_NO_BOM_CHANGE_TEXT, TD_NO_BOM_CHANGE, strchangesColAttrList,strchangesColWidthList, resBLDiffValue),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_safety(false),TD_LOG_ERROR_AND_THROW);
						}
						if (resBLDiffValue.size() <= 0)
						{	
							Custom_free(pcImpItemid); 
							bObjectfound = true;
							break;
						}
						
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_safety("",false),TD_LOG_ERROR_AND_THROW);	
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety((char *)pcChangeID.c_str(), "", TD_TABLE_HEADER, strchangesColAttrList,strchangesColWidthList, resBLDiffValue),TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety("", "",  TD_TABLE_COL_HEADER_VALUE, strchangesColAttrList,strchangesColWidthList, resBLDiffValue),TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_safety(false),TD_LOG_ERROR_AND_THROW);
					
						bObjectfound = true;
						Custom_free(pcImpItemid);
						break;
					} 
                    Custom_free(pcImpItemid);
				}
				//updating BOM Line information related to solution Item which is not available in Impacted Item Folder
				if(!bObjectfound)
				{
					if (!resBLDiffValue.empty())
						resBLDiffValue.clear();

					char *pcECNTypeName = NULL;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetObject, &pcECNTypeName), TD_LOG_ERROR_AND_THROW);
					if(tc_strcmp(pcECNTypeName, TD_REL_ECN_REV_TYPE) != 0) {
						tag_t tPrevRev = NULLTAG;
						bool bStatus = false;
						TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tSolObjFoundTag[jCnt], &tPrevRev),TD_LOG_ERROR_AND_THROW);
						if (tPrevRev != NULLTAG) {
							//Compare with previous revision if there is an assembly in the solution items folder of Release ECN
							iStatus = teradyne_list_bvr_diffs_safety(tPrevRev, tSolObjFoundTag[jCnt], resBLDiffValue);
							if (iStatus == 1)
							{
								iStatus = 0;
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_safety("",false),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety((char *)pcChangeID.c_str(),  TD_NO_BOM_CHANGE_TEXT, TD_NO_BOM_CHANGE, strchangesColAttrList,strchangesColWidthList, resBLDiffValue),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_safety(false),TD_LOG_ERROR_AND_THROW);
								bStatus = true;
							}
						} else {
							TERADYNE_TRACE_CALL(iStatus = teradyne_update_solitem_BL_only_safety(tSolObjFoundTag[jCnt], resBLDiffValue),TD_LOG_ERROR_AND_THROW);
						}
						if (!bStatus) {
							if (resBLDiffValue.size() > 0)
							{
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_safety("",false),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety((char *)pcChangeID.c_str(), TD_DIFFITEM_HEADER_2, TD_TABLE_HEADER, strchangesColAttrList, strchangesColWidthList,resBLDiffValue),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_safety("", "",  TD_TABLE_COL_HEADER_VALUE, strchangesColAttrList, strchangesColWidthList,resBLDiffValue),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_safety(false),TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					Custom_free(pcECNTypeName);
				}
				Custom_free(pcSolItemid);
			}
		} 
		
		
		//write html content in xls file,
		TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ECN_REPORT_TEMP_DIR_PREF,TC_preference_site,0,&pcECNReportFileLoc),TD_LOG_ERROR_AND_THROW);
		pcDatasetID = (char *)MEM_alloc( (int)(tc_strlen(pcECNID)+ 20) * sizeof(char) );		
		sprintf(pcDatasetID, "%s-%s", pcECNID, TD_ECN_SAFETY_FILE_NAME);			
		sprintf(cHtLFilePath, "%s\\%s-%s.%s", pcECNReportFileLoc,pcECNID,TD_ECN_SAFETY_FILE_NAME,TD_ECN_REPORT_XLS_FILE_EXT);		

		fHtMLFile = fopen( cHtLFilePath, "w");				
		fprintf( fHtMLFile, "%s", cHtMLFileContentSafety.c_str());		
		fprintf( fHtMLFile, "\n</HTML>");		
		fclose(fHtMLFile);

		//converting the report to xlsx by using vb script
		if(tc_strlen(cHtLFilePath) > 0)
		{		
			//Create and attach dataset under ECN Revision
			TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_create_dataset(cHtLFilePath,tTargetObject, pcDatasetID),TD_LOG_ERROR_AND_THROW);
			DeleteFileA(cHtLFilePath);
		}
		Custom_free(cHtLFilePath);	
		Custom_free(pcECNProcess);
		Custom_free(pcDatasetID);
		Custom_free(pcECNReportFileLoc);
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	
	TERADYNE_TRACE_LEAVE(iStatus);	
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_list_bvr_diffs_safety
* Description		: Function used to create report of Bomline Comaprison
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_list_bvr_diffs_safety (tag_t  tImprevtag, tag_t  tSolrevtag, vector<string> &resDiffVec)
{
	int  iStatus							= ITK_ok,
		 NO_BOM_CHNAGES						= 1,
		 iDiffCount1						= 0,
		 iDiffCount2						= 0,
	     *iDiffflags1						= 0,
	     *iDiffflags2						= 0,	
	     iReportlength						= 0,
		 ichildCount1						= 0,
		 ichildCount2						= 0;
	
	tag_t tWindow1							= NULLTAG, 
		  tWindow2							= NULLTAG, 
		  tImpitemtag						= NULLTAG, 
		  tSolitemtag						= NULLTAG, 
		  tline1							= NULLTAG, 
	      tline2							= NULLTAG,
		  tCompare							= NULLTAG,
		  tdesc								= NULLTAG,
		  *tDiffLines1						= NULLTAG,
		  *tDiffLines2						= NULLTAG,
		  *tReportitems						= NULLTAG,
		  *tchildLines1						= NULL,
		  *tchildLines2						= NULL;    
	 
	 char **cReportlines					= NULL;		     
											

	 string strBomLineAttr[]			    = {TD_BL_ITEM_ID_ATTR, TD_BL_ITEMREV, TD_BL_OBJECT_TYPE};

	 std::map<string,string> strBomLineValueMap;

	 vector<string> resDiffVecs;
 
     char* __function__ = "teradyne_list_bvr_diffs_safety";
     TERADYNE_TRACE_ENTER();

     try
     {	
		 if (!resDiffVec.empty())
			resDiffVec.clear();

		 //Getting rev tag of Impacted and Solution Item
		 TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tImprevtag, &tImpitemtag),TD_LOG_ERROR_AND_THROW);
		 TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolrevtag, &tSolitemtag),TD_LOG_ERROR_AND_THROW);

		 //Create BOM windows and set their top lines
		 TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow1),TD_LOG_ERROR_AND_THROW);	
		 TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow1, tImpitemtag, tImprevtag, NULLTAG, &tline1),TD_LOG_ERROR_AND_THROW);	
		 TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow2),TD_LOG_ERROR_AND_THROW);	 
		 TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow2, tSolitemtag, tSolrevtag, NULLTAG, &tline2),TD_LOG_ERROR_AND_THROW);	

		 //Ask Child lines of top lines
		 TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline1, &ichildCount1, &tchildLines1),TD_LOG_ERROR_AND_THROW);
		 TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline2, &ichildCount2, &tchildLines1),TD_LOG_ERROR_AND_THROW);

		  if((ichildCount1 <= 0) && (ichildCount2 <= 0))
		  {  
			  TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow1),TD_LOG_ERROR_AND_THROW);	 
			  TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow2),TD_LOG_ERROR_AND_THROW);
			  return iStatus;
		  }
		 
		 /* compare */
		 TERADYNE_TRACE_CALL(iStatus = BOM_compare_execute(NULLTAG, tline1, tline2, "IMAN_bcm_single_level_ref", BOM_compare_output_report),TD_LOG_ERROR_AND_THROW);
		 iStatus = BOM_compare_report(tCompare, &iReportlength, &cReportlines, &tReportitems);
		 if(iStatus == 46059)
		 {
			EMH_clear_errors();
			Custom_free(tchildLines1);
			Custom_free(tchildLines2);
			Custom_free(tReportitems);
			Custom_free(cReportlines);
			return NO_BOM_CHNAGES;
		 }
	
		TERADYNE_TRACE_CALL(iStatus = BOM_compare_list_diffs(tline1, &iDiffCount1, &tDiffLines1, &iDiffflags1),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_compare_list_diffs(tline2, &iDiffCount2, &tDiffLines2, &iDiffflags2),TD_LOG_ERROR_AND_THROW);

		if ((iDiffCount1 > 0) || (iDiffCount2 > 0))
		{
			char  *pcDiffLines1ID			= NULL;
			char  *pcDiffLines2ID			= NULL;

			vector<string> itemIDVec;

			for (int j = 0; j < iDiffCount1; j++) {
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDiffLines1[j], TD_BL_ITEM_ID_ATTR, &pcDiffLines1ID),TD_LOG_ERROR_AND_THROW);
				itemIDVec.push_back(pcDiffLines1ID);
			}
			Custom_free(pcDiffLines1ID);

			std::list<string> strBomLineAttrList( strBomLineAttr, strBomLineAttr + sizeof(strBomLineAttr) / sizeof(string) );
			for (int i=0; i<iDiffCount2; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDiffLines2[i], TD_BL_ITEM_ID_ATTR, &pcDiffLines2ID),TD_LOG_ERROR_AND_THROW);

				bool itemFound = false;

				if(itemIDVec.size() > 0) {
					for (int k = 0; k < itemIDVec.size(); k++) {
						if (tc_strcmp(pcDiffLines2ID, itemIDVec[k].c_str()) == 0)  {
							itemFound = true;
							break;
						}
					}
				}
				Custom_free(pcDiffLines2ID);

				//Getting Added Item
				if (BOM_cmp_added(iDiffflags2[i]) && !itemFound) 
				{				
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tDiffLines2[i],strBomLineAttrList,strBomLineValueMap),TD_LOG_ERROR_AND_THROW);

					char *pcDescription = NULL, *pcObjectType = NULL, *pcSafetyLicense = NULL, *objType=NULL;
					tag_t tItemRev = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(tDiffLines2[i], &pcDescription), TD_LOG_ERROR_AND_THROW);

					
					if( strBomLineValueMap.size() > 0 )
					{
						/*Warnings*/
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tDiffLines2[i], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_SAFETY_LICENSE_ATTR, &pcSafetyLicense),TD_LOG_ERROR_AND_THROW);

						if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0 || tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0) 
						{
							if(pcSafetyLicense != NULL && tc_strcmp(pcSafetyLicense, TD_ECN_VALUE_FOR_TRUE) == 0)
							{
								resDiffVec.push_back(TD_DIFFITEM_ADD); //Action
								resDiffVec.push_back(strBomLineValueMap.find(TD_BL_ITEM_ID_ATTR)->second); //Part
								resDiffVec.push_back(pcSafetyLicense);//Warnings
								resDiffVec.push_back(pcDescription);//Description	
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tItemRev, TD_OBJECT_TYPE_ATTR, &objType),TD_LOG_ERROR_AND_THROW);
								resDiffVec.push_back(objType);//Type
							}
						}
						
						Custom_free(objType);
						Custom_free(pcObjectType);
						Custom_free(pcSafetyLicense);
						Custom_free(pcDescription);

					}
				}			 
			}
			//Getting Changed and Deleted Item
			if (iDiffCount1 > 0)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_bomline_attr_value_safety (iDiffCount1, iDiffCount2, tDiffLines1,tDiffLines2,strBomLineAttrList, resDiffVecs),TD_LOG_ERROR_AND_THROW);
				resDiffVec.insert( resDiffVec.end(), resDiffVecs.begin(), resDiffVecs.end() );
			}
		}
		
	TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow1),TD_LOG_ERROR_AND_THROW);	 
	TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow2),TD_LOG_ERROR_AND_THROW);	 
	}
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}	
    }

	TERADYNE_TRACE_LEAVE(iStatus);

	Custom_free(cReportlines);
	Custom_free(tDiffLines1);
	Custom_free(tDiffLines2);
	Custom_free(tchildLines1);
	Custom_free(tchildLines2);
	Custom_free(tReportitems);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_update_solitem_BL_only_safety
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_solitem_BL_only_safety (tag_t  tSolrevtag, vector<string> &resDiffVec)
{
	int  iStatus				= ITK_ok,
		 ichildCount            = 0,
		 iChildIncr				= 0;

	tag_t tWindow				= NULLTAG, 		
		  tSolitemtag			= NULLTAG, 
		  tline  				= NULLTAG,
		  *tchildLines			= NULL;
								
	string strBomLineAttr[]		= {TD_BL_ITEM_ID_ATTR, TD_BL_ITEMREV, TD_BL_OBJECT_TYPE};

	std::map<string,string> strBomLineValueMap;
	
	 char* __function__ = "teradyne_update_solitem_BL_only_safety";
     TERADYNE_TRACE_ENTER();

     try
     {	
		 if (!resDiffVec.empty())
			resDiffVec.clear();

		 TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolrevtag, &tSolitemtag),TD_LOG_ERROR_AND_THROW);
		 
		 TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow),TD_LOG_ERROR_AND_THROW);	 
		 TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow, tSolitemtag, tSolrevtag, NULLTAG, &tline),TD_LOG_ERROR_AND_THROW);	

		 TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline, &ichildCount, &tchildLines),TD_LOG_ERROR_AND_THROW);

		 if (ichildCount == 0)
		 {	TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW); return iStatus;}

		 std::list<string> strBomLineAttrList( strBomLineAttr, strBomLineAttr + sizeof(strBomLineAttr) / sizeof(string) );

		 for(iChildIncr = 0; iChildIncr < ichildCount; iChildIncr++)
		 {
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tchildLines[iChildIncr],strBomLineAttrList,strBomLineValueMap),TD_LOG_ERROR_AND_THROW);

			char *pcDescription = NULL, *pcObjectType = NULL, *pcSafetyLicense = NULL, *objType = NULL;
			tag_t tItemRev = NULLTAG;

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(tchildLines[iChildIncr], &pcDescription), TD_LOG_ERROR_AND_THROW);
			
			if( strBomLineValueMap.size() > 0 )
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tchildLines[iChildIncr], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

				if(tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0 || tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0) 
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_SAFETY_LICENSE_ATTR, &pcSafetyLicense),TD_LOG_ERROR_AND_THROW);
						
					if(pcSafetyLicense!=NULL && tc_strcmp(pcSafetyLicense, TD_ECN_VALUE_FOR_TRUE) == 0 )
					{
						resDiffVec.push_back(TD_DIFFITEM_ADD); //Action	
						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_ITEM_ID_ATTR)->second); //Part 
						resDiffVec.push_back(pcSafetyLicense); //Warnings	
						resDiffVec.push_back(pcDescription);//Description
						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tItemRev, TD_OBJECT_TYPE_ATTR, &objType),TD_LOG_ERROR_AND_THROW);
						resDiffVec.push_back(objType);//Type
					}				
				}
				Custom_free(pcDescription);
				Custom_free(pcObjectType);
				Custom_free(pcSafetyLicense);
				Custom_free(objType);
			}
		}
		 TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);

		 Custom_free(tchildLines);
	 }
	
    catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
		
	//Custom_free(tchildLines);
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_get_bomline_attr_value_safety
* Description		: Getting Bom line Attribute value
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_bomline_attr_value_safety (int iChildrenCount1, int iChildrenCount2, tag_t *ptChildrens1, tag_t *ptChildrens2, std::list<string> strBomLineAttrList, vector<string> &resDiffVec)
{
	int iStatus                 = ITK_ok;
	int iChildIncr1				= 0;
	int iChildIncr2				= 0;

	char  *pcBLItemID1			= NULL;
	char  *pcBLItemID2			= NULL;	
	string  strQty				= "";
	
	logical isLogicalAttribute = false;

	std::map<string,string> strBomLineValueMap1, strBomLineValueMap2;
		  
    char* __function__ = "teradyne_get_bomline_attr_value_safety";
    TERADYNE_TRACE_ENTER();
  
     try
     {		
		 if (!resDiffVec.empty())
			resDiffVec.clear();

		 if (!strBomLineValueMap1.empty())
			strBomLineValueMap1.clear();

		 if (!strBomLineValueMap2.empty())
			strBomLineValueMap2.clear();

		  for(iChildIncr1 = 0; iChildIncr1 < iChildrenCount1; iChildIncr1++)
		  {
			 isLogicalAttribute = false;
			 TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens1[iChildIncr1], TD_BL_ITEM_ID_ATTR, &pcBLItemID1),TD_LOG_ERROR_AND_THROW);			
			 for(iChildIncr2 = 0; iChildIncr2 < iChildrenCount2; iChildIncr2++)
			 {
				 strQty = "";
				  TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens2[iChildIncr2], TD_BL_ITEM_ID_ATTR, &pcBLItemID2),TD_LOG_ERROR_AND_THROW);
				  if (tc_strcmp(pcBLItemID1, pcBLItemID2) == 0) 
				  {						
					   TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens1[iChildIncr1],strBomLineAttrList,strBomLineValueMap1),TD_LOG_ERROR_AND_THROW);
					   TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens2[iChildIncr2],strBomLineAttrList,strBomLineValueMap2),TD_LOG_ERROR_AND_THROW);

					   char *pcDescription=NULL, *pcObjectType = NULL, *pcSafetyLicense = NULL, *objType = NULL;
					   tag_t tItemRev = NULLTAG;

					   TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(ptChildrens2[iChildIncr2], &pcDescription), TD_LOG_ERROR_AND_THROW);

					   //Getting changed BOM Lines attributes
					   if( (strBomLineValueMap2.size() > 0)  && (strBomLineValueMap1.size() > 0))
					   {
						   if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0 || tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0) 
						   {	
							   //Warnings
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(ptChildrens2[iChildIncr2], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_SAFETY_LICENSE_ATTR, &pcSafetyLicense),TD_LOG_ERROR_AND_THROW); 

								if(pcSafetyLicense != NULL && tc_strcmp(pcSafetyLicense, TD_ECN_VALUE_FOR_TRUE) == 0)
								{
									resDiffVec.push_back(TD_DIFFITEM_CHANGE); //Action
									resDiffVec.push_back(strBomLineValueMap2.find(TD_BL_ITEM_ID_ATTR)->second); //Part
									resDiffVec.push_back(pcSafetyLicense);//Warnings
									resDiffVec.push_back(pcDescription);//Description										
									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tItemRev, TD_OBJECT_TYPE_ATTR, &objType),TD_LOG_ERROR_AND_THROW);
									resDiffVec.push_back(objType);//Type
								}
							}

						   isLogicalAttribute = true;
						   Custom_free(pcBLItemID2);
						   break;
					   }
					   Custom_free(objType);
					   Custom_free(pcDescription);
					   Custom_free(pcObjectType);
					   Custom_free(pcSafetyLicense);
				  }	
				  Custom_free(pcBLItemID2);	
			 }			
			 if (!isLogicalAttribute)
			 {
				 //Getting Deleted BOM Lines attributes
				 TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens1[iChildIncr1],strBomLineAttrList,strBomLineValueMap1),TD_LOG_ERROR_AND_THROW);



				 if(strBomLineValueMap1.size() > 0)
				 {
					char *pcDescription=NULL, *pcObjectType = NULL, *pcSafetyLicense = NULL, *objType = NULL;
					tag_t tItemRev = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(ptChildrens1[iChildIncr1], &pcDescription), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0 || tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0) 
					{												
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(ptChildrens1[iChildIncr1], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_SAFETY_LICENSE_ATTR, &pcSafetyLicense),TD_LOG_ERROR_AND_THROW);

						if(pcSafetyLicense != NULL && tc_strcmp(pcSafetyLicense, TD_ECN_VALUE_FOR_TRUE) == 0 )
						{
							resDiffVec.push_back(TD_DIFFITEM_DEL); //Action
							resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_ITEM_ID_ATTR)->second ); //Part
							resDiffVec.push_back(pcSafetyLicense);//Warnings
							resDiffVec.push_back(pcDescription); //Description
							TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tItemRev, TD_OBJECT_TYPE_ATTR, &objType),TD_LOG_ERROR_AND_THROW);
							resDiffVec.push_back(objType);//Type
						}
					}
					 Custom_free(pcObjectType);
					 Custom_free(pcSafetyLicense);	
					 Custom_free(objType);
			     }
			 }
			 Custom_free(pcBLItemID1);
		 }
     }    
     catch(...)
     {
		 if(iStatus == ITK_ok)
		 {
			 TC_write_syslog("%s: Unhandled Exception",__function__);
			 iStatus = TERADYNE_UNKNOWN_ERROR;
		 }
     }

	TERADYNE_TRACE_LEAVE(iStatus);
	
	return iStatus; 
}  


/*******************************************************************************
* Function Name  	: teradyne_update_htmlcontentPair_safety
* Description		: will update html table content with value
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  columname   (I)	   - Column
*					   columvalue	(I)	   - Property value vector
*					   cHtMLFileContentSafety  (I)    - Propery value array
*					   value  (I)    - Propery value array
*					   strColAttr  (I)    - Propery value array
*					   resValVec (I)	   - Response vector of property values
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_htmlcontentPair_safety(char *columname, char *columvalue, char* value, std::list<string> strColAttr, std::list<string> strColwidthAttr,std::vector<string> resValVec)
{
	//Declartion and Initialization of Local Variables
	int iColHeaderSize  = 0;
	int iTypesize		= 0;
	int iStart			= 0;
	int iStatus         = ITK_ok;  
	
	string columvalue1;
	
	char* __function__ = "teradyne_update_htmlcontentPair_safety";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tc_strcmp(value, TD_TABLE_ROW_HEADER_VALUE) == 0 )
		{
			cHtMLFileContentSafety.append("\n<TR>");
			cHtMLFileContentSafety.append("\n<TD bgcolor=#C0C0C0><B>"); 
			cHtMLFileContentSafety.append(columname); cHtMLFileContentSafety.append("<B></TD>");			
			cHtMLFileContentSafety.append("\n<TD align=\"left\">");

			if (tc_strcasecmp (columvalue, TD_ECN_VALUE_FOR_TRUE) ==0)
				cHtMLFileContentSafety.append(TD_ECN_VALUE_FOR_TRUE);
			else if (tc_strcasecmp (columvalue, TD_BOOL_VALUE_FALSE) ==0)
				cHtMLFileContentSafety.append(TD_ECN_VALUE_FOR_FALSE);
			else 
				cHtMLFileContentSafety.append(columvalue);

			cHtMLFileContentSafety.append("</TD>");			
			cHtMLFileContentSafety.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_NO_BOM_CHANGE) == 0 )
		{
			cHtMLFileContentSafety.append("\n<TR> \n<TH align=\"left\" COLSPAN=1 bgcolor=#C0C0C0><B>"); cHtMLFileContentSafety.append(columname); cHtMLFileContentSafety.append("<B></TH>");
			cHtMLFileContentSafety.append("\n</TR>");
			cHtMLFileContentSafety.append("\n<TR> \n<TD align=\"left\" nowrap>"); cHtMLFileContentSafety.append(columvalue); cHtMLFileContentSafety.append("</TD>");
			cHtMLFileContentSafety.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_HEADER) == 0 )
		{
			cHtMLFileContentSafety.append("\n<TR>");
			cHtMLFileContentSafety.append("\n<TH align=\"left\" COLSPAN=5 bgcolor=#C0C0C0><B>"); cHtMLFileContentSafety.append(columname); cHtMLFileContentSafety.append("<B></TH>");
			cHtMLFileContentSafety.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_STATIC_TEXT) == 0 )
		{
			cHtMLFileContentSafety.append("\n<TABLE border=\"2\" align=\"Top\" width=\"90%\">");
			cHtMLFileContentSafety.append("\n<TR>");
			cHtMLFileContentSafety.append("\n<TD COLSPAN=3 nowrap><B>"); cHtMLFileContentSafety.append(columvalue); cHtMLFileContentSafety.append("<B></TD>");
			cHtMLFileContentSafety.append("\n</TR>");
			cHtMLFileContentSafety.append("\n</TABLE>");
			if (tc_strcasecmp (columvalue,TD_ECN_REPORT_STEXT_BOMCHANGES) == 0)
				cHtMLFileContentSafety.append("\n<BR><BR>");
		}
		else if (tc_strcmp(value, TD_TABLE_NONE_VALUE) == 0 )
		{
			cHtMLFileContentSafety.append("\n<H3>"); cHtMLFileContentSafety.append(columname); cHtMLFileContentSafety.append("<BR>"); cHtMLFileContentSafety.append(columvalue);  cHtMLFileContentSafety.append("</H3>");	
		}
		else
		{	
			cHtMLFileContentSafety.append("\n<TR>");
			iColHeaderSize = (int)strColAttr.size();
			for (std::list<string>::iterator it = strColAttr.begin(), itwidth=strColwidthAttr.begin(); it!= strColAttr.end(), itwidth!= strColwidthAttr.end(); it++,itwidth++)
			{
				if( ((string)*it).empty() )
					continue;

				cHtMLFileContentSafety.append("\n<TH bgcolor=#C0C0C0 height=\"40%\" width=\""); 
				cHtMLFileContentSafety.append(((string)*itwidth).c_str()); 
				cHtMLFileContentSafety.append("%\">"); 
				cHtMLFileContentSafety.append(((string)*it).c_str());  
				cHtMLFileContentSafety.append("</TH>");
			}
			cHtMLFileContentSafety.append("\n</TR>");			
			if( resValVec.size() > 0 )
			{
				iTypesize = (int)resValVec.size();	
				iStart = 0;
				for (int iAttrCnt=iStart; iAttrCnt<iTypesize; iAttrCnt++)
				{			
					cHtMLFileContentSafety.append("\n<TR>");
					for (int iAttrCnt1=0; iAttrCnt1<iColHeaderSize; iAttrCnt1++)	
					{					
						cHtMLFileContentSafety.append("\n<TD align=\"left\">");
						cHtMLFileContentSafety.append(resValVec[iStart].c_str()); cHtMLFileContentSafety.append("</TD>");
						iStart++;	
					}
					iAttrCnt = iStart;
					cHtMLFileContentSafety.append("\n</TR>");						
				}
			}
		}		
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_headingblock_safety
* Description		: Function used to create html heading block
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_headingblock_safety(char* HeadingValue, int iHeadingType)
{
	//Declartion and Initialization of Local Variables
	int   iStatus                     = ITK_ok;  
		
	char* __function__ = "teradyne_html_headingblock_safety";
	TERADYNE_TRACE_ENTER();
	
	try
	{		
		if ( iHeadingType == 3 ) 
		{	
			cHtMLFileContentSafety.append("\n<H3>");
			cHtMLFileContentSafety.append(HeadingValue);
			//cHtMLFileContentSafety.append("</H3>"); 
		}
		else 
		{ 
			cHtMLFileContentSafety.append("\n<H2>"); 
			cHtMLFileContentSafety.append(HeadingValue);
			cHtMLFileContentSafety.append("</H2>"); 
		}
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagopen_safety
* Description		: Function used to open the table tag of html 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagopen_safety(char* HeadingValue, bool bAddHeader)
{
	//Declartion and Initialization of Local Variables
	int   iStatus                     = ITK_ok; 
	
	char* __function__ = "teradyne_html_tabletagopen_safety";
	TERADYNE_TRACE_ENTER();

	try
	{	
		if (bAddHeader)
		{
			cHtMLFileContentSafety.append("\n<H3>"); 
			cHtMLFileContentSafety.append(HeadingValue);
			cHtMLFileContentSafety.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
		else 
        {
		    cHtMLFileContentSafety.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagclose_safety
* Description		: Function used to close the table tag of html
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagclose_safety(bool bAddHeaderclose)
{
	//Declartion and Initialization of Local Variables
	int   iStatus                     = ITK_ok;  
	
	char* __function__ = "teradyne_html_tabletagclose";
	TERADYNE_TRACE_ENTER();

	try
	{		
		if (!bAddHeaderclose)
		{
			cHtMLFileContentSafety.append("\n</TABLE>\n<BR>\n<BR>\n<BR>");
		}
		else
		{
			cHtMLFileContentSafety.append("\n</H3></TABLE>\n<BR>\n<BR>\n<BR>");
		}
    }
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	return iStatus;
}

