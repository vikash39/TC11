/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_convert_semicolon_to_csv.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SemicolonToCSVConverter action handler
#      Project         :           libTD4teradyne          
#      Author          :           Rodji / Marjorie          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

#include <sa/tcfile_cache.h>

/*******************************************************************************
 * Function Name			: teradyne_convert_semicolon_to_csv
 * Description				: This function converts semi-colon delimeter to comma
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_convert_semicolon_to_csv(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
	iAttachCount        = 0,
	    iPrefCount	= 0,
		iFound              = 0;
		
	string strErrMsg        = "",
           strFilePath      = "",
		   line             = "";
	string strInputFilePath = "";
	string tmpReplacedPath=""; 
	
	tag_t *tAttachtag       = {NULLTAG},
          *tagReferencedObj	= {NULLTAG};
		   
	char  *pcobjname          = NULL,
		  *extname            = NULL;
	char **sPrefValues = NULL;
	ifstream fcsv;

	const char * __function__    = "teradyne_convert_semicolon_to_csv" ;
	TERADYNE_TRACE_ENTER();
	
	
	try{
		
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
		if ( iAttachCount == 1 ){
		   TERADYNE_TRACE_CALL (iStatus = AE_ask_dataset_named_refs(tAttachtag[0],&iFound,&tagReferencedObj), TD_LOG_ERROR_AND_THROW);
		   if(iFound ==1){
		      TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tagReferencedObj[0],TD_FILE_EXT_ATTR,&extname), TD_LOG_ERROR_AND_THROW); 
			  
			  if ( tc_strcmp(extname, "csv") == 0){
			    //Export the file to temp
				TERADYNE_TRACE_CALL(iStatus = teradyne_export_file_to_temp(tAttachtag[0], tagReferencedObj[0], TD_CSV_REFNAME, strInputFilePath) , TD_LOG_ERROR_AND_THROW);
				fcsv.open(strInputFilePath.c_str());
				bool replace=false;
				if(fcsv.is_open()){
				     // Read the first line
						getline(fcsv,line);
						if(line != "" && line.length() > 0 ){
						      //Check header if has semicolon delimiter
								int hasSemicolon  = line.find(";");
								if(hasSemicolon != std::string::npos)
									replace = true;
						}


						if(replace )
						{
                             char* pcTEMP_env = getenv ( "TEMP" );
							  if ( pcTEMP_env == NULL ){
								 pcTEMP_env = getenv("TMP");
							  }
						      if(pcTEMP_env != NULL){
		                   		tmpReplacedPath.assign(pcTEMP_env); 
							  }
							  if(tmpReplacedPath == "" ||tmpReplacedPath.length() <= 0)
								  tmpReplacedPath.assign(TD_TEMP_PATH);
							  tmpReplacedPath.append("/").append("tmpReplacedSemiColon.csv");

							  std::ofstream temp_file(tmpReplacedPath) ;

							  string replacedSemiColon = "";

							  //header
							  replacedSemiColon =replaceLine(line,";",",");
							  temp_file << replacedSemiColon <<'\n';

							  //bomlines
							  while(getline(fcsv,line))
							  {
								if(line != "" && line.length() >= 0)
								{
									replacedSemiColon = "";
									int comma = line.find(",");
									if(comma!= std::string::npos)
									{
										string::size_type i = line.find(";");
										int j;
										for(j = 1; j < 4; ++j)
											i = line.find(";", i+1);

										//for refdes 
										if(j == 4) 
										{
											string refdesStart = line.substr(0, i);
											if(refdesStart.find(",") != std::string::npos)
											{
												int refdesEnd = refdesStart.find_last_of(";")+1;
												line.insert(refdesEnd, "\"");
												line.insert(refdesStart.length()+1, "\"");
											}
										}

										//for remarks
										string temp = line.substr(line.find_last_of(";"));
										if(temp.find(",") != std::string::npos)
										{
											line.insert(line.find_last_of(";") + 1, "\"");
											line.insert(line.length(), "\"");
										}
									
									}
									replacedSemiColon =replaceLine(line,";",",");
									temp_file << replacedSemiColon <<'\n';
								}
							  }
							  temp_file.close();
							
							  // overwrite the original file with the temporary file
							std::ifstream tmp_file(tmpReplacedPath) ;
							std::ofstream original_file(strInputFilePath) ;

							if(original_file.is_open())
							{
								original_file << tmp_file.rdbuf() ;
								original_file.close();
							}


							IMF_file_data_p_t file_data;
							TERADYNE_TRACE_CALL(iStatus = IMF_get_file_access(tagReferencedObj[0], 0, &file_data), TD_LOG_ERROR_AND_THROW); 

							tag_t new_file_tag = NULLTAG;
							TERADYNE_TRACE_CALL(iStatus = AOM_lock(tagReferencedObj[0]), TD_LOG_ERROR_AND_THROW); 
							TERADYNE_TRACE_CALL(iStatus = IMF_replace_file_and_get_new_tag(tagReferencedObj[0],strInputFilePath.c_str() , FALSE, &new_file_tag), TD_LOG_ERROR_AND_THROW); 


							TERADYNE_TRACE_CALL(iStatus = AOM_lock(tAttachtag[0]), TD_LOG_ERROR_AND_THROW); 
							TERADYNE_TRACE_CALL(iStatus = AE_replace_dataset_named_ref2(tAttachtag[0], tagReferencedObj[0], TD_CSV_REFNAME, AE_PART_OF, new_file_tag), TD_LOG_ERROR_AND_THROW); 

							TERADYNE_TRACE_CALL(iStatus = AE_save_myself(tAttachtag[0]), TD_LOG_ERROR_AND_THROW); 
							TERADYNE_TRACE_CALL(iStatus = AOM_unload(tAttachtag[0]), TD_LOG_ERROR_AND_THROW); 
							TERADYNE_TRACE_CALL(iStatus = IMF_release_file_access(&file_data), TD_LOG_ERROR_AND_THROW); 
			  
							TERADYNE_TRACE_CALL(iStatus = AOM_lock_for_delete(tagReferencedObj[0]), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_delete(tagReferencedObj[0]), TD_LOG_ERROR_AND_THROW);
			  

							
						}
				} 
				fcsv.close();
				remove(strInputFilePath.c_str());
				remove(tmpReplacedPath.c_str()) ;
			  }
		   }
		}

	}catch(...){
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

std::string replaceLine( std::string line, const std::string& substr,const std::string& replace_with )
{
    std::string::size_type pos = 0 ;
    while( ( pos = line.find( substr, pos ) ) != std::string::npos )
    {
        line.replace( pos, substr.size(), replace_with ) ;
        pos += replace_with.size() ;
    }
    return line ;
}