/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_releaseECNrevstampcalculation.cpp   
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ReleaseECNRevStampCalculation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-May-2015                       Vijayasekhar                    	Added function definitions teradyne_releaseECNrevstampcalculation
#  15-Jul-2015                       Haripriya                      	Modified function to set MinimumShippable Revision to set RevStamp value
#  14-Sep-2017						 Karl Reimann						Added check if MinShipRev is null before updating it when RevStamp is not null
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_releaseECNrevstampcalculation
 * Description				: Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ECN and on the required attributes
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:1. Will get all the parts in SolutionItems folder
 *							 2. Will get the Date range effectivity of release status Part revisions and translate the to Week number format.
 *							 3. For the Part Type of any item in solution items is HLA(instrument) or PCBA then will update Rev Stamp attribute on ECN and Change Admin Form
 * NOTES					: 
 ******************************************************************************/
int teradyne_releaseECNrevstampcalculation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iTerParts				= 0;
	tag_t tChgAdmin				= NULLTAG,
		  *tAttaches			= NULL,
		  *tTerParts			= NULL;
	char *pcAttachType			= NULL,
		 *pcPartType			= NULL,
		 *pcPartTypeAttr		= NULL,
		 *pcRevStampAttr		= NULL,
		 *pcMinShipRevAttr		= NULL,
		 *pcEffDateRange		= NULL;
	string strStartDate			= "",
		   strYearWeekDate		= "";

	const char * __function__ = "teradyne_releaseECNrevstampcalculation";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE)) { 
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_effective_date_range(tAttaches[i], &pcEffDateRange), TD_LOG_ERROR_AND_THROW);
					if(pcEffDateRange != NULL) {
					
						string strEffDateRange(pcEffDateRange);
						strStartDate = strEffDateRange.substr(0,strEffDateRange.find(" ")); // Gets the start date in the date range "dd-Mon-yyyy"
						//Gets the year week format from the given date
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_week_from_date(strStartDate, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iTerParts, &tTerParts), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iTerParts; j++) {
					
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTerParts[j], &pcPartType), TD_LOG_ERROR_AND_THROW);
						if(tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0) { //checking for Div part revision since solution items can have disign documents also
						
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTerParts[j], TD_PART_TYPE_ATTR, &pcPartTypeAttr), TD_LOG_ERROR_AND_THROW);
							if(!tc_strcmp(pcPartTypeAttr, "HLA(Instrument)") || !tc_strcmp(pcPartTypeAttr, "PCBA")) {
								
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTerParts[j], TD_PART_REV_STAMP, &pcRevStampAttr), TD_LOG_ERROR_AND_THROW);
								if(pcRevStampAttr == NULL || tc_strlen(pcRevStampAttr) == 0) {
									
									POM_AM__set_application_bypass(true);
									//setting the yearweek date format on REV STAMP property on ECN revision
									TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tAttaches[i], TD_REV_STAMP_ATTR, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
									//setting the yearweek date format on Rev Stamp property on change admin form of the part revision
									TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tTerParts[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tChgAdmin), TD_LOG_ERROR_AND_THROW);
									if(tChgAdmin != NULLTAG) {
									
										TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgAdmin, TD_PART_REV_STAMP, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
										//setting the yearweek date format on Min ship Rev property on change admin form of the part revision
										TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgAdmin, TD_PART_MIN_SHIPPABLE_REV, strYearWeekDate), TD_LOG_ERROR_AND_THROW);
									}
									POM_AM__set_application_bypass(false);
								} else {
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTerParts[j], TD_PART_MIN_SHIPPABLE_REV, &pcMinShipRevAttr), TD_LOG_ERROR_AND_THROW);
									if(pcMinShipRevAttr == NULL || tc_strlen(pcMinShipRevAttr) == 0) {
										POM_AM__set_application_bypass(true);
										TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tTerParts[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tChgAdmin), TD_LOG_ERROR_AND_THROW);
										if(tChgAdmin != NULLTAG) {
											TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgAdmin, TD_PART_MIN_SHIPPABLE_REV, pcRevStampAttr), TD_LOG_ERROR_AND_THROW);
										}
										Custom_free(pcMinShipRevAttr);
									}
									POM_AM__set_application_bypass(false);
								}
							}
						}
						Custom_free(pcPartType);
						Custom_free(pcPartTypeAttr);
						Custom_free(pcRevStampAttr);
					}
				}
				Custom_free(tTerParts);
				Custom_free(pcEffDateRange);
			}
			Custom_free(pcAttachType);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
