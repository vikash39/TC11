#include <workflow/teradyne_handlers.h>

EPM_decision_t ter_ecn_validation(EPM_rule_message_t msg)
{

	int iStatus = ITK_ok,
		iAttaches = 0,
		iSecCount = 0,
		iBvrCount = 0,
		BomChildCount = 0,
		C1 = 0,
		argnumber = 0;

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		root_task = NULLTAG,
		*attachments = NULLTAG,
		trelation = NULLTAG,
		*tSecObjects = NULLTAG,
		*tBvr = NULLTAG,
		t_window = NULLTAG,
		revruletag = NULLTAG,
		tTopBomLine = NULLTAG,
		*tChilds = NULLTAG;

	char *pcObjectType = NULL,
		*pcSolutionObjectType = NULL,
		*childId = NULL,
		*pcObjectString = NULL,
		*pcSecObjString = NULL,
		*arg_name = NULL,
		*arg_value = NULL;



	EPM_decision_t epmDecision = EPM_go;


	const char * __function__ = "ter_ecn_validation";


	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &iAttaches, &attachments), TD_LOG_ERROR_AND_THROW);
	for (int i = 0; i < iAttaches; i++)
	{
		
		TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &pcObjectString), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

		if ((tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0))
		{
			
			argnumber = TC_number_of_arguments(msg.arguments);

			
			for (int arg = 0; arg < argnumber; arg++)
			{
				TERADYNE_TRACE_CALL(iStatus = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &arg_name, &arg_value), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(arg_name, "Check_multiple_BOMLines") == 0)
				{
					if ((tc_strcmp(arg_value, "true") == 0) || (tc_strcmp(arg_value, "TRUE") == 0))
					{
						//Duplicate BOM Lines � Should not allow ECN to continue if a BOM contains the same part number/rev multiple times. 
						if ((tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0))
						{

							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &trelation), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], trelation, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);

							for (int j = 0; j < iSecCount; j++)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSecObjects[j], &pcSolutionObjectType), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSecObjects[j], "object_string", &pcSecObjString), TD_LOG_ERROR_AND_THROW);
								if ((tc_strcmp(pcSolutionObjectType, TD_DIV_PART_REV) == 0) || (tc_strcmp(pcSolutionObjectType, TD_COMM_PART_REV) == 0))
								{
									TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tSecObjects[j], &iBvrCount, &tBvr), TD_LOG_ERROR_AND_THROW);

									if (iBvrCount > 0)
									{
										for (int k = 0; k < iBvrCount; k++)
										{

											TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window, revruletag), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window, NULLTAG, tSecObjects[j], tBvr[k], &tTopBomLine), TD_LOG_ERROR_AND_THROW);

											TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(tTopBomLine, &BomChildCount, &tChilds), TD_LOG_ERROR_AND_THROW);

											char* strcat = (char*)MEM_alloc(100);
											char* str = (char*)MEM_alloc(100);
											tc_strcpy(str, "");

											if (BomChildCount > 0)
											{

												for (int l = 0; l < BomChildCount; l++)
												{
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds[l], "bl_item_item_id", &childId), TD_LOG_ERROR_AND_THROW);

													tag_t *tChilds1 = NULLTAG;
													int BomChildCount1 = 0, c = 0;
													char *childId1 = NULL,
														*childIdCType = NULL,
														*childIdPType = NULL;


													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds[l], "fnd0bl_line_object_type", &childIdPType), TD_LOG_ERROR_AND_THROW);

													TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(tTopBomLine, &BomChildCount1, &tChilds1), TD_LOG_ERROR_AND_THROW);

													for (int m = 0; m < BomChildCount1; m++)
													{
														TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds1[m], "bl_item_item_id", &childId1), TD_LOG_ERROR_AND_THROW);
														TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds1[m], "fnd0bl_line_object_type", &childIdCType), TD_LOG_ERROR_AND_THROW);
														if (tc_strcmp(childIdPType, childIdCType) == 0)
														{
															if (tc_strcmp(childId, childId1) == 0)
															{
																c++;

															}
														}
														Custom_free(childId1);
														Custom_free(childIdCType);
													}
													if (c > 1)
													{
														tc_strcpy(strcat, "");
														tc_strcpy(strcat, childId);
														tc_strcat(str, " ");
														tc_strcat(str, strcat);
														C1++;

													}
													Custom_free(childIdPType);
													Custom_free(childId);
													Custom_free(tChilds1);
												}
												// for printing the duplicate Item ID once
												if (tc_strcmp(str, "") != 0)
												{

													char words[100][100];
													int p = 0, q = 0, r, length, pcount;

													for (r = 0; str[r] != '\0'; r++)
													{
														if (str[r] != ' ' && str[r] != '\0')
														{
															words[p][q++] = tolower(str[r]);
														}
														else
														{
															words[p][q] = '\0';
															p++;
															q = 0;
														}
													}
													length = p + 1;
													for (p = 0; p < length; p++)
													{
														pcount = 1;
														for (q = p + 1; q < length; q++)
														{
															if (strcmp(words[p], words[q]) == 0 && (strcmp(words[q], "0") != 0))
															{
																pcount++;
																strcpy(words[q], "0");
															}
														}
														if (pcount > 1)
														{
															TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_Child_UESD_MULTIPLE_TIMES, words[p]), TD_LOG_ERROR_AND_THROW);

														}
													}
												}

											}
											else
											{


												TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, pcObjectString, pcSecObjString), TD_LOG_ERROR_AND_THROW);
												C1++;
											}
											Custom_free(tChilds);
										}


									}
									Custom_free(tBvr);
								}
								Custom_free(pcSolutionObjectType);
								Custom_free(pcSecObjString);
							}
							Custom_free(tSecObjects);
						}

					}

					if ((tc_strcmp(arg_value, "false") == 0) || (tc_strcmp(arg_value, "FALSE") == 0))
					{
						epmDecision = EPM_go;

					}
				}




				if (tc_strcmp(arg_name, "Check_REFDES_QTY") == 0)
				{
					if ((tc_strcmp(arg_value, "true") == 0) || (tc_strcmp(arg_value, "TRUE") == 0))
					{
						// REF DES locations vs the QTY mismatch � Should not allow ECN to continue if there is a BOM with quantity and reference designator mismatch. 
						tag_t tSolutionRelation = NULLTAG,
							*tSolutionSecObjects = NULLTAG,
							*tBvr3 = NULLTAG,
							t_window3 = NULLTAG,
							revruletag3 = NULLTAG,
							tTopBomLine3 = NULLTAG,
							*tChilds3 = NULLTAG;

						char *pcSolutionObjectType3 = NULL,
							*CBomQuantity = NULL,
							*CECNObjString = NULL,
							*CSecObjString = NULL,
							*CChildObjString = NULL,
							*CRefDesignator = NULL;

						int iSolutionSecCount = 0,
							iBvrCount3 = 0,
							BomChildCount3 = 0;


						char *token = NULL,
							*htoken = NULL,
							*NewToken = NULL;


						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &CECNObjString), TD_LOG_ERROR_AND_THROW);
						if ((tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0))
						{

							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &tSolutionRelation), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], tSolutionRelation, &iSolutionSecCount, &tSolutionSecObjects), TD_LOG_ERROR_AND_THROW);
							for (int i1 = 0; i1 < iSolutionSecCount; i1++)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects[i1], &pcSolutionObjectType3), TD_LOG_ERROR_AND_THROW);
								// iStatus = AOM_UIF_ask_value(tSecObjects[j], "object_string", &pcSecObjString);
								if ((tc_strcmp(pcSolutionObjectType3, TD_DIV_PART_REV) == 0) || (tc_strcmp(pcSolutionObjectType3, TD_COMM_PART_REV) == 0))
								{


									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects[i1], "object_string", &CSecObjString), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tSolutionSecObjects[i1], &iBvrCount3, &tBvr3), TD_LOG_ERROR_AND_THROW);

									if (iBvrCount3 > 0)
									{
										for (int i2 = 0; i2 < iBvrCount3; i2++)
										{

											TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window3), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag3), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window3, revruletag3), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window3, NULLTAG, tSolutionSecObjects[i1], tBvr3[i2], &tTopBomLine3), TD_LOG_ERROR_AND_THROW);

											TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(tTopBomLine3, &BomChildCount3, &tChilds3), TD_LOG_ERROR_AND_THROW);

											if (BomChildCount3 > 0)
											{

												for (int i3 = 0; i3 < BomChildCount3; i3++)
												{
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds3[i3], "bl_quantity", &CBomQuantity), TD_LOG_ERROR_AND_THROW);
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds3[i3], "bl_ref_designator", &CRefDesignator), TD_LOG_ERROR_AND_THROW);
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tChilds3[i3], "object_string", &CChildObjString), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(CRefDesignator, "") != 0)
													{

														if (tc_strcmp(CBomQuantity, "") == 0)
														{
															char* CBomQuant = (char*)MEM_alloc(1024);
															tc_strcpy(CBomQuant, "1");
															tc_strcpy(CBomQuantity, CBomQuant);

														}




														int Total = 0;
														char *temp = NULL,
															*Temp1 = NULL,
															*Temp2 = NULL,
															*RefDesignatorValue = NULL;
														temp = tc_strstr(CRefDesignator, ",");



														vector<char*> ReferenceDesiTokens;

														if (temp != NULL)
														{


															token = tc_strtok(CRefDesignator, ",");


															while (token != NULL)
															{
																ReferenceDesiTokens.push_back(token);
																token = tc_strtok(NULL, ",");


															}

															for (int zz = 0; zz < ReferenceDesiTokens.size(); zz++)
															{

																int Refcount1 = 0, Refcount2 = 0, c = 0;
																char *inputStr = NULL, *CRefDesignator1 = NULL;

																Temp2 = tc_strstr(ReferenceDesiTokens[zz], "-");
																if (Temp2 != NULL)
																{

																	token = tc_strtok(ReferenceDesiTokens[zz], "-");

																	int  b = 0;


																	for (int ii = 0; token[ii]; ii++)
																	{

																		if (token[ii] >= '0' && token[ii] <= '9')
																		{
																			token[b] = token[ii];
																			b++;
																		}
																	}

																	token[b] = '\0';

																	Refcount1 = atoi(token);

																	token = tc_strtok(NULL, "-");

																	int  bb = 0;
																	for (int ii = 0; token[ii]; ii++)
																	{

																		if (token[ii] >= '0' && token[ii] <= '9')
																		{
																			token[bb] = token[ii];
																			bb++;
																		}
																	}
																	token[bb] = '\0';
																	Refcount2 = atoi(token);

																	c = Refcount2 - Refcount1 + 1;

																	Total = Total + c;

																}
																else
																{

																	c = 1;
																	Total = Total + c;
																}
															}



															char pcBuffer[1024];
															int valuelength = 0;

															sprintf(pcBuffer, "%d", Total);

															valuelength = tc_strlen(pcBuffer);
															RefDesignatorValue = (char*)MEM_alloc(valuelength);
															tc_strcpy(RefDesignatorValue, "");
															tc_strcpy(RefDesignatorValue, pcBuffer);

															if (tc_strcmp(CBomQuantity, RefDesignatorValue) != 0)
															{

																TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_QUANTITY_REFERENCE_DESIGNATOR, CChildObjString), TD_LOG_ERROR_AND_THROW);
																C1++;
															}

														}
														else
														{
															int Refcount1 = 0, Refcount2 = 0, c = 0;
															char *inputStr = NULL;

															Temp1 = tc_strstr(CRefDesignator, "-");
															if (Temp1 != NULL)
															{

																token = tc_strtok(CRefDesignator, "-");

																int  b = 0;


																for (int ii = 0; token[ii]; ii++)
																{

																	if (token[ii] >= '0' && token[ii] <= '9')
																	{
																		token[b] = token[ii];
																		b++;
																	}
																}

																token[b] = '\0';

																Refcount1 = atoi(token);

																token = tc_strtok(NULL, "-");

																int  bb = 0;
																for (int ii = 0; token[ii]; ii++)
																{

																	if (token[ii] >= '0' && token[ii] <= '9')
																	{
																		token[bb] = token[ii];
																		bb++;
																	}
																}
																token[bb] = '\0';
																Refcount2 = atoi(token);

																c = Refcount2 - Refcount1 + 1;
																char pcBuffer[1024];


																sprintf(pcBuffer, "%d", c);
																int valuelength = 0;
																valuelength = tc_strlen(pcBuffer);
																RefDesignatorValue = (char*)MEM_alloc(valuelength);
																tc_strcpy(RefDesignatorValue, "");
																tc_strcpy(RefDesignatorValue, pcBuffer);

															}
															else
															{
																RefDesignatorValue = (char*)MEM_alloc(100);
																tc_strcpy(RefDesignatorValue, "1");

															}

															if (tc_strcmp(CBomQuantity, RefDesignatorValue) != 0)
															{

																TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_BOM_QUANTITY_REFERENCE_DESIGNATOR, CChildObjString), TD_LOG_ERROR_AND_THROW);

																C1++;
															}
														}

													}


													Custom_free(CBomQuantity);
													Custom_free(CRefDesignator);
													Custom_free(CChildObjString);
												}

											}
											else
											{
												TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, CECNObjString, CSecObjString), TD_LOG_ERROR_AND_THROW);
												C1++;
											}
											Custom_free(tChilds3);
										}
									}
									Custom_free(CSecObjString);
									Custom_free(tBvr3);
								}
								Custom_free(pcSolutionObjectType3);
							}

						}
						Custom_free(tSolutionSecObjects);
						Custom_free(CECNObjString);
					}
					if ((tc_strcmp(arg_value, "false") == 0) || (tc_strcmp(arg_value, "FALSE") == 0))
					{
						epmDecision = EPM_go;
					}
				}





				if (tc_strcmp(arg_name, "Check_parts_documents") == 0)
				{
					if ((tc_strcmp(arg_value, "true") == 0) || (tc_strcmp(arg_value, "TRUE") == 0))
					{
						//Check for revised documents are attached to the specifications of the part � Should not allow ECN to proceed if the new document revision is not attached to the new corresponding part revision.  

						tag_t tSolutionRelation2 = NULLTAG,
							*tSolutionSecObjects2 = NULLTAG,
							tSpecificationRelation = NULLTAG,
							*tSpecificationSecObjects = NULLTAG;

						int iSolutionSecCount2 = 0,
							iSecificationSecCount = 0;

						char *pcSolutionObjectType2 = NULL,
							*pcSecObjString2 = NULL,
							*pcSolObjectType2 = NULL,
							*cSpecificationSecObjString = NULL,
							*tSpecificationSecObjeType = NULL,
							*pcSecDivObjString = NULL;

						if (tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0)
						{

							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &tSolutionRelation2), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], tSolutionRelation2, &iSolutionSecCount2, &tSolutionSecObjects2), TD_LOG_ERROR_AND_THROW);
							for (int j1 = 0; j1 < iSolutionSecCount2; j1++)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects2[j1], &pcSolutionObjectType2), TD_LOG_ERROR_AND_THROW);

								if ((tc_strcmp(pcSolutionObjectType2, TD_DESIGN_DOC_REV_TYPE) == 0))
								{

									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[j1], "object_string", &pcSecObjString2), TD_LOG_ERROR_AND_THROW);

									for (int j2 = 0; j2 < iSolutionSecCount2; j2++)
									{
										TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects2[j2], &pcSolObjectType2), TD_LOG_ERROR_AND_THROW);

										if (tc_strcmp(pcSolObjectType2, TD_DIV_PART_REV) == 0)
										{

											TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[j2], "object_string", &pcSecDivObjString), TD_LOG_ERROR_AND_THROW);

											TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("IMAN_specification", &tSpecificationRelation), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tSolutionSecObjects2[j2], tSpecificationRelation, &iSecificationSecCount, &tSpecificationSecObjects), TD_LOG_ERROR_AND_THROW);

											if (iSecificationSecCount != 0)
											{
												int icount = 0;

												for (int j3 = 0; j3 < iSecificationSecCount; j3++)
												{
													TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSpecificationSecObjects[j3], &tSpecificationSecObjeType), TD_LOG_ERROR_AND_THROW);
													if (tc_strcmp(tSpecificationSecObjeType, TD_DESIGN_DOC_REV_TYPE) == 0)
													{

														TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSpecificationSecObjects[j3], "object_string", &cSpecificationSecObjString), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(cSpecificationSecObjString, pcSecObjString2) == 0)
														{
															icount++;
														}
														Custom_free(cSpecificationSecObjString);
													}


													Custom_free(tSpecificationSecObjeType);
												}
												if (icount == 0)
												{
													TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DOC_REVISION_ATTACHED, pcSecObjString2, pcSecDivObjString), TD_LOG_ERROR_AND_THROW);
													C1++;
												}

											}
											else
											{
												TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DOC_REVISION_ATTACHED, pcSecObjString2, pcSecDivObjString), TD_LOG_ERROR_AND_THROW);
												C1++;
											}
											Custom_free(tSpecificationSecObjects);
											Custom_free(pcSecDivObjString);
										}
										Custom_free(pcSolObjectType2);
									}
									Custom_free(pcSecObjString2);
								}
								if ((tc_strcmp(pcSolutionObjectType2, TD_GENERAL_DOC_REV_TYPE) == 0))
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[j1], "object_string", &pcSecObjString2), TD_LOG_ERROR_AND_THROW);

									for (int j2 = 0; j2 < iSolutionSecCount2; j2++)
									{
										TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects2[j2], &pcSolObjectType2), TD_LOG_ERROR_AND_THROW);
										if (tc_strcmp(pcSolObjectType2, TD_DIV_PART_REV) == 0)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[j2], "object_string", &pcSecDivObjString), TD_LOG_ERROR_AND_THROW);

											TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("IMAN_specification", &tSpecificationRelation), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tSolutionSecObjects2[j2], tSpecificationRelation, &iSecificationSecCount, &tSpecificationSecObjects), TD_LOG_ERROR_AND_THROW);

											if (iSecificationSecCount != 0)
											{
												int icount = 0;

												for (int j3 = 0; j3 < iSecificationSecCount; j3++)
												{
													TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSpecificationSecObjects[j3], &tSpecificationSecObjeType), TD_LOG_ERROR_AND_THROW);
													if (tc_strcmp(tSpecificationSecObjeType, TD_GENERAL_DOC_REV_TYPE) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSpecificationSecObjects[j3], "object_string", &cSpecificationSecObjString), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(cSpecificationSecObjString, pcSecObjString2) == 0)
														{
															icount++;
														}
														Custom_free(cSpecificationSecObjString);
													}


													Custom_free(tSpecificationSecObjeType);
												}
												if (icount == 0)
												{
													TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DOC_REVISION_ATTACHED, pcSecObjString2, pcSecDivObjString), TD_LOG_ERROR_AND_THROW);
													C1++;
												}

											}
											else
											{
												TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DOC_REVISION_ATTACHED, pcSecObjString2, pcSecDivObjString), TD_LOG_ERROR_AND_THROW);
												C1++;
											}

											Custom_free(pcSecDivObjString);
											Custom_free(tSpecificationSecObjects);
										}
										Custom_free(pcSolObjectType2);
									}
									Custom_free(pcSecObjString2);
								}
								Custom_free(pcSolutionObjectType2);
							}
							Custom_free(tSolutionSecObjects2);
						}
						int cou = 0, z = 0, n_references = 0, *levels = 0;
						tag_t *revs = NULLTAG,
							*reference_tags = NULLTAG,
							tItem = NULLTAG,
							latestRev = NULLTAG,
							tNewItem = NULLTAG,
							tRelType = NULLTAG;


						char *d_value = NULL,
							**relation_type_name = NULL,
							*d_value1 = NULL,
							*ReferenceType = NULL,
							*d_value2 = NULL,
							*pcSolObjType = NULL,
							*d_value3 = NULL,
							*DocSolItem = NULL;


						if ((tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0))
						{
							TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &tSolutionRelation2), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], tSolutionRelation2, &iSolutionSecCount2, &tSolutionSecObjects2), TD_LOG_ERROR_AND_THROW);
							for (int k1 = 0; k1 < iSolutionSecCount2; k1++)
							{
								TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects2[k1], &pcSolutionObjectType2), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[k1], "object_string", &DocSolItem), TD_LOG_ERROR_AND_THROW);
								if ((tc_strcmp(pcSolutionObjectType2, TD_DESIGN_DOC_REV_TYPE) == 0) || (tc_strcmp(pcSolutionObjectType2, TD_GENERAL_DOC_REV_TYPE) == 0))
								{

									TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolutionSecObjects2[k1], &tItem), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = ITEM_list_all_revs(tItem, &cou, &revs), TD_LOG_ERROR_AND_THROW);
									z = cou;
									z = z - 2;

									int  ImanCount = 0;
									tag_t *tImansecobj = NULLTAG;
									for (int H1 = 0; H1 < cou; H1++)
									{
										if (z == H1)
										{
											//geting previsious revision of doc and find where references
											TERADYNE_TRACE_CALL(iStatus = WSOM_where_referenced2(revs[H1], 1, &n_references, &levels, &reference_tags, &relation_type_name), TD_LOG_ERROR_AND_THROW);
											for (int H2 = 0; H2 < n_references; H2++)
											{
												TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(reference_tags[H2], &ReferenceType), TD_LOG_ERROR_AND_THROW);
												if (tc_strcmp(ReferenceType, TD_DIV_PART_REV) == 0)
												{
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(reference_tags[H2], "object_string", &d_value2), TD_LOG_ERROR_AND_THROW);


													int H5 = 0;
													char *d_value4 = NULL, *d_value5 = NULL;
													for (int H3 = 0; H3 < iSolutionSecCount2; H3++)
													{
														TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tSolutionSecObjects2[H3], &pcSolObjType), TD_LOG_ERROR_AND_THROW);
														if (tc_strcmp(pcSolObjType, TD_DIV_PART_REV) == 0)
														{

															TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[H3], "object_string", &d_value3), TD_LOG_ERROR_AND_THROW);
															if ((tc_strcmp(d_value3, d_value2) == 0))
															{
																TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("IMAN_specification", &tRelType), TD_LOG_ERROR_AND_THROW);
																TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tSolutionSecObjects2[H3], tRelType, &ImanCount, &tImansecobj), TD_LOG_ERROR_AND_THROW);
																for (int H4 = 0; H4 < ImanCount; H4++)
																{
																	TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tSolutionSecObjects2[k1], "object_string", &d_value4), TD_LOG_ERROR_AND_THROW);
																	TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tImansecobj[H4], "object_string", &d_value5), TD_LOG_ERROR_AND_THROW);
																	if ((tc_strcmp(d_value4, d_value5) == 0))
																	{

																		H5++;
																	}
																	Custom_free(d_value4);
																	Custom_free(d_value5);
																}

																if (H5 == 0)
																{
																	TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DOC_REVISION_ATTACHED, DocSolItem, d_value3), TD_LOG_ERROR_AND_THROW);
																	C1++;
																}
																Custom_free(tImansecobj);
															}
															Custom_free(d_value3);

														}
														Custom_free(pcSolObjType);
													}
													Custom_free(d_value2);

												}
												Custom_free(ReferenceType);
											}
											Custom_free(reference_tags);
											Custom_free(relation_type_name);
										}

									}
									Custom_free(revs);
								}
								Custom_free(pcSolutionObjectType2);
								Custom_free(DocSolItem);
							}
							Custom_free(tSolutionSecObjects2);
						}


					}
					if ((tc_strcmp(arg_value, "false") == 0) || (tc_strcmp(arg_value, "FALSE") == 0))
					{
						epmDecision = EPM_go;
					}
				}

			}
		}
		Custom_free(pcObjectString);
		Custom_free(pcObjectType);
	}
	if (C1 > 0)
	{
		epmDecision = EPM_nogo;
	}

	Custom_free(attachments);


	return epmDecision;
}