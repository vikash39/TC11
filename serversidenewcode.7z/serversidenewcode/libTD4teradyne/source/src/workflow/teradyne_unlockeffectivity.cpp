/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_unlockeffectivity.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UnLockEffectivity action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Apr-2015                       Vijayasekhar                    	Added function definitions teradyne_unlockeffectivity
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  26-Aug-2015                       Haripriya                    	    Modified arguments for teradyne_set_protection function.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_unlockeffectivity
 * Description				: UnLocks the effectivity for the relase status of the part revision                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_unlockeffectivity(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL;
	char *pcObjectType			= NULL;

	const char * __function__ = "teradyne_unlockeffectivity";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_set_protection(tAttaches[i], false,pcObjectType), TD_LOG_ERROR_AND_THROW);
				}
				Custom_free(pcObjectType);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}