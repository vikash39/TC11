/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_populatedynamicURL.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne_PopulateDynamicURL action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Nov-2014                       Vijayasekhar                    	Added function definitions teradyne_populatedynamicURL and teradyne_get_logical_values
#  08-Jan-2015						 Kameshwaran 						Updated the Form Type																	
#  12-Feb-2015                       Vijayasekhar                    	Added condition to update the Distrubute model with Dynamic URL with RequestID, JobType and Assignee name
#																		Added teradyne_get_assignee_name function definition and Removed teradyne_get_logical_values function definition
#  13-Feb-2015                       Vijayasekhar                    	Added changes to get the UserID.
#  19-Feb-2015						 Kameshwaran D						Added typecasting to avoid warnings while compiling source code
#  04-Mar-2015                       Vijayasekhar                    	Added changes to get the User Name and added teradyne_replace_url_spacecharacter function definition.
#  12-Mar-2015                       Vijayasekhar                    	Changed arguments for teradyne_get_attachments
#  01-Apr-2015                       Haripriya                    	    Added changes to get the MapForm based on type.
#  23-Jun-2015                       Haripriya                    	    Modified teradyne_replace_url_spacecharacter function.
#  24-Mar-2016						 Kameshwaran D						Added code to set Dynamic Url Group value.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_populatedynamicURL
 * Description				: This function will pupates the action handler 
 *							  Teradyne-PopulateDynamicURL                            
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the dynamic URL values from the preference
 *							  2. Will check whether the operation is performing on TD4CommPartReqRevision,TD4TAGModlCreReqRevision,
 *								 TD4DTGModlModReqRevision and TD4TAGModlModReqRevision Item revisions.
 *							  3. Updating the td4Url attribute of forms TD4CADModlForm,TD4CAEModlForm,TD4SimulModlForm,TD4PADStackModlForm
 *								 and TD4MAPModlForm with the resultant dynamic Url values.
 *
 * NOTES					: The DoTask names where this action hadler exists should contain key words(CAD, CAE, MAP, PADSTACK, SIMULATION)
 ******************************************************************************/
extern "C"
int teradyne_populatedynamicURL(EPM_action_message_t msg) 
{
	int iStatus							= ITK_ok,
		iAttachCount					= 0;

	bool bFlag							= false,
		 bIsCreate						= false,
		 bIsMap                         = false;
	
	tag_t *ptAttaches					= NULL,
		  tObjFound						= NULLTAG; 

	char *pcTaskName					= NULL,
		 *pcBaseURL						= NULL,
		 *pcSubURL						= NULL,
		 *pcUserName					= NULL,
		 *pcTypeName					= NULL,
		 *pcTaskNameUpr					= NULL,
		 *pcItemId						= NULL;
		
	string strFormType					= "",
		   strFormAttr					= "",
		   strJobType					= "",
		   strTaskName					= "",
		   strUserName					= "";
	
	const char * __function__    = "teradyne_populatedynamicURL" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG && msg.action == EPM_assign_action) {
		
			//Getting the dynamic url from the preferences values
			TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_DYNC_SVR_URL, TC_preference_site, 0, &pcBaseURL), TD_LOG_ERROR_AND_THROW);
			if(pcBaseURL != NULL) {
		
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_DYNC_URL_STR, TC_preference_site, 0, &pcSubURL), TD_LOG_ERROR_AND_THROW);
				if(pcSubURL != NULL) {
				
					string strBaseURL(pcBaseURL);
					strBaseURL.append(pcSubURL); 
					//Getting the resposible pary for the task
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_assignee_name(msg.task, &pcUserName), TD_LOG_ERROR_AND_THROW); 
					//replacing the user name space characters with %20 to append it it URL
					TERADYNE_TRACE_CALL(iStatus = teradyne_replace_url_spacecharacter(pcUserName, strUserName), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = EPM_ask_name2(msg.task, &pcTaskName), TD_LOG_ERROR_AND_THROW);
					if(pcTaskName != NULL) {
						//getting the key value from the dotask name, tasks names should contain the key values (cad, cae, padstack, simulation and map)
						tc_strupr(pcTaskName, &pcTaskNameUpr);
						strTaskName = pcTaskNameUpr;
					}
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
					for(int i = 0; i < iAttachCount; i++) { 
					
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
						//request will be processed for the below specified item revisions
						if(pcTypeName != NULL && tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0 || tc_strcmp(pcTypeName, TD_TAG_MDL_CRE_REQ_REV) == 0 
							|| tc_strcmp(pcTypeName, TD_DTG_MDL_MOD_REQ_REV) == 0 || tc_strcmp(pcTypeName, TD_TAG_MDL_MOD_REQ_REV) == 0) { 
						
							if(tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0 || tc_strcmp(pcTypeName, TD_TAG_MDL_CRE_REQ_REV) == 0) { 
								
								bIsCreate = true;
							}
							if(tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0 || tc_strcmp(pcTypeName, TD_DTG_MDL_MOD_REQ_REV) == 0) { 
								
								bIsMap = true;
							}
							// finding the for the key values present in the corresponding DoTasks
							if(strTaskName.find("CAD") != string::npos) { 
							
								strFormType = (bIsCreate == true) ? TD_CAD_MODL_CRE_FORM_TYPE : TD_CAD_MODL_MDF_FORM_TYPE;
								strFormAttr = TD_CAD_MDL_NEED_ATTR;
								strJobType  = "CAD";
							} else if (strTaskName.find("CAE") != string::npos) { 
							
								strFormType = (bIsCreate == true) ? TD_CAE_MODL_CRE_FORM_TYPE : TD_CAE_MODL_MDF_FORM_TYPE;
								strFormAttr = TD_CAE_MDL_NEED_ATTR;
								strJobType  = "CAE";
							} else if (strTaskName.find("SIMULATION") != string::npos) { 
							
								strFormType = (bIsCreate == true) ? TD_SIMUL_MODL_CRE_FORM_TYPE : TD_SIMUL_MODL_MDF_FORM_TYPE;
								strFormAttr = TD_SMLN_MDL_NEED_ATTR;
								strJobType  = "SIMULATION";
							} else if (strTaskName.find("MAP") != string::npos) { 
							
								strFormType = (bIsMap == true) ? TD_MAP_MODL_CRE_FORM_TYPE : TD_MAP_MODL_FORM_TYPE;
								strFormAttr = TD_MAP_NEED_ATTR; 
								strJobType  = "MAP";
							} else if (strTaskName.find("PADSTACK") != string::npos) { 
							
								strFormType = (bIsCreate == true) ? TD_PAD_STACK_MODL_CRE_FORM_TYPE : TD_PAD_STACK_MODL_MDF_FORM_TYPE;
								strFormAttr = TD_PAD_STK_NEED_ATTR;
								strJobType  = "PADSTACK";
							}
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(ptAttaches[i], &pcItemId), TD_LOG_ERROR_AND_THROW);//Getting the Item ID from Revision Tag
							if(strFormAttr.length() > 0 && strFormAttr.compare("") != 0) {
							
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(ptAttaches[i], strFormAttr.c_str(), &bFlag), TD_LOG_ERROR_AND_THROW);
								if(bFlag && strFormType.length() > 0 && strFormType.compare("") != 0) {
								
									TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(ptAttaches[i], TD_IMAN_SPEC_REL_NAME, strFormType.c_str(), 0, &tObjFound), TD_LOG_ERROR_AND_THROW);
									if(tObjFound != NULLTAG) {
							
										string strUrlTmp = strBaseURL;

										/*To set group tag value in URL*/
										string strGrpTag ="";
										if( tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0) strGrpTag = "DTG";
										else if( tc_strcmp(pcTypeName, TD_DTG_MDL_MOD_REQ_REV) == 0 ) strGrpTag = "DTG";
										else if( tc_strcmp(pcTypeName, TD_TAG_MDL_CRE_REQ_REV) == 0 ) strGrpTag = "TAG";
										else if(tc_strcmp(pcTypeName, TD_TAG_MDL_MOD_REQ_REV) == 0) strGrpTag = "TAG";

										//Building the dynamic URL
										if(pcItemId != NULL && strJobType.length() > 0 && strUserName.length()> 0) {
				
											int pos = (int)(strUrlTmp.find("RequestId=") + strlen("RequestId="));
											strUrlTmp.replace(pos, tc_strlen("%s"), pcItemId);
											pos = (int)(strUrlTmp.find("JobType=") + strlen("JobType="));
											strUrlTmp.replace(pos, tc_strlen("%s"), strJobType);
											pos = (int)(strUrlTmp.find("Assignee=") + strlen("Assignee="));
											strUrlTmp.replace(pos, tc_strlen("%s"), strUserName);
											pos = (int)(strUrlTmp.find("Group=") + strlen("Group="));
											strUrlTmp.replace(pos, tc_strlen("%s"), strGrpTag);

											TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObjFound, TD_URL, strUrlTmp), TD_LOG_ERROR_AND_THROW);
										}
									}
								}
							}
						}
						bIsCreate = false;
					}
				}
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	
	Custom_free(pcTaskName);
	Custom_free(pcBaseURL);
	Custom_free(pcSubURL);
	Custom_free(ptAttaches);
	Custom_free(pcUserName);
	Custom_free(pcItemId);
	Custom_free(pcTypeName);
	
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_assignee_name
 * Description				: Will get assigned user name for the performing task
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tTask   (I)			- task tag
 *							  pcAssingeeName (OF)   - Assignee name char pointer
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: Will get the name of the user for the assigned task.
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_assignee_name(tag_t tTask, char** pcAssingeeName) {

	int iStatus					= ITK_ok;

	tag_t tAssignee				= NULLTAG;

	char* __function__ = "teradyne_get_assignee_name";
	TERADYNE_TRACE_ENTER();

	try {

		if(tTask != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = EPM_ask_responsible_party(tTask, &tAssignee), TD_LOG_ERROR_AND_THROW);
			if(tAssignee != NULLTAG) {
			
				TERADYNE_TRACE_CALL(POM_ask_user_name(tAssignee, pcAssingeeName), TD_LOG_ERROR_AND_THROW);
			}
		}
	} catch(...) {
	
		if ( iStatus == ITK_ok )
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_replace_url_spacecharacter
 * Description				: Will encode the space character in a string to %20
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcUrl   (I)			- char*
 *							  strUrl  (O)   - string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_replace_url_spacecharacter(char *pcUrl, string& strUrl) {

	int iStatus					= ITK_ok;
	size_t pos					= 0;

	const char * __function__ = "teradyne_replace_url_spacecharacter";
	TERADYNE_TRACE_ENTER();

	try 
	{
		strUrl = pcUrl; //assigning url value to string
		for(int i=0;i<strUrl.length();i++)
		{
			char c=strUrl[i];
			if(isspace(c))
			{
				//replacing spaces with %20 in the username
				strUrl.replace(i, 1, "%20");
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}