/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assigndynamicparticipant.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignDynamicParticipant action handler
#      Project         :           libTD4teradyne          
#      Author          :           Selvi          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Feb-2015                       Selvi                    	        Initial Code	
#  12-Mar-2015                       Vijayasekhar                    	Changed arguments for teradyne_get_attachments and Removed unused variable declarations
#  26-Mar-2015                       Haripriya                          Added four more arguments for handler
#  22-Apr-2015                       Haripriya                          Modified the handler to remove participant member if the given property has empty value
#  23-Apr-2015                       Haripriya                    	    Modified the function to Split Multiple values.
#  29-Apr-2015						 Haripriya                          Modified the code to work only for first target object
#  04-May-2015						 Haripriya                          Modified clearing the map function.
#  07-May-2015                       Haripriya                    	    Modified code to check for Release ECN Primary Project
#  10-Jul-2015                       Haripriya                    	    Modified teradyne_assigndynamicparticipant fn in getting Change Admin value
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assigndynamicparticipant
 * Description				: This function will populates the action handler 
 *							  Teradyne-AssignDynamicParticipant                            
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Read the arguments "-assignee","-name","-from_include_type","-from_attach","-from_relation","-from_include_related_type"  in task.
 *							  2. Read attribute name given in -assignee argument from target object and get corresponding user id for assignee and assigned to the current task.
 *							
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_assigndynamicparticipant(EPM_action_message_t msg) 
{
	int iStatus							= ITK_ok,
		iAttachCount					= 0,
		iUsers							= 0,
		iGrpMemCount					= 0,
		iParticipantCount				= 0,
		iSecObjCount					= 0;

	tag_t tRootTask						= NULLTAG,
		  *ptAttaches					= NULL,
		  tCurrentTask					= NULLTAG,
		  tResponsibleUser				= NULLTAG,
		  tResponsiblePerson			= NULLTAG,
		  *tUsers						= NULL,
		  tParticipantType              = NULLTAG,
		  tParticipant					= NULLTAG,
		  *tGrpMem						= NULL,
		  *tParticipantlist				= NULL,
		  tGroup						= NULLTAG,
			roleTag						=NULLTAG,
		  tRelation						= NULLTAG,
		  targetObjTag                  = NULLTAG, 
		  *tSecObj						= NULL;
		  
	char *pcTypeName					= NULL,
		 *pcAssignee					= NULL,
		 *pcAssigneevalue				= NULL,
		 *pcPersonname					= NULL,
		 *roleName						= NULL,
		 *grpName						= NULL,
		 *usrID							= NULL,
		 *pcAssignParticipants			= NULL,
		 *pcfromtype					= NULL,
		 *pcfromattach					= NULL,
		 *pcrelation					= NULL,
		 *pcreltype						= NULL;

		 vector<string> TechreviewerValues;
	
	const char *strProp[]				= {TD_ASSIGN_CMD_SUP_ENGG_ATTR};

	const char * __function__    = "teradyne_assigndynamicparticipant" ;
	TERADYNE_TRACE_ENTER();

	try
	  {		
		//read the handler arguments
		teradyne_get_handler_opts(msg.arguments,
		"-assigneevalue", &pcAssignee,
		"-assignparticipant", &pcAssignParticipants, 
		"-from_include_type", &pcfromtype,
		"-from_attach", &pcfromattach,
		"-from_relation", &pcrelation,
		"-from_include_related_type", &pcreltype,
		NULL);
		
		string szDivRevAttr[] ={pcAssignee};
		
	std::map<string,string> strPropNameValueMap;
	std::list<std::string> strAttr(szDivRevAttr,szDivRevAttr+sizeof(szDivRevAttr)/sizeof(string));

		//check if given arguments
		if((pcAssignee != NULL &&  tc_strcmp(pcAssignee, "") != 0) && (pcAssignParticipants != NULL && tc_strcmp(pcAssignParticipants, "") != 0))
        {		
			//get the attachment based on "-from_attach" argument
			if( pcfromattach != NULL && tc_strcmp(pcfromattach,"reference") == 0)
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
			else 
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);			
			
			for(int i = 0; i < iAttachCount; i++) 
			{	
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				
				//Get target object for retrieving expected properties; These are the target objects that this handler is currently used in a workflow tasks
				if( pcTypeName != NULL && (tc_strcmp(pcTypeName,TD_STD_ECN_REV_TYPE) == 0 ) || tc_strcmp(pcTypeName,TD_PROTOBOM_ECN_REV_TYPE)==0 || tc_strcmp(pcTypeName,TD_REL_ECN_REV_TYPE)==0  || tc_strcmp(pcTypeName,TD_PCN_REQ_REV_TYPE)==0 || tc_strcmp(pcTypeName,TD_COMM_PART_REQ_REV)==0 || tc_strcmp(pcTypeName,TD_PROTOPART_ECN_REV_TYPE)==0 ){
								
							targetObjTag  =ptAttaches[i];	
			    }
				
				
				//Both -from_relation and -from_include_related_type need to be given
				if ( ( pcreltype != NULL ) && (pcrelation != NULL) )
				{
					if( tc_strcmp(pcreltype, TD_PROJECT_FORM_TYPE) == 0 ) 
					{
						if( (tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0)  || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0))
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(ptAttaches[i],strPropNameValueMap,pcAssignee),TD_LOG_ERROR_AND_THROW);
						}
					}
					else
					{
				 		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type (pcrelation, &tRelation), TD_LOG_ERROR_AND_THROW);
				 		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches[i], tRelation, &iSecObjCount , &tSecObj), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type( tSecObj[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
						for(int i=0;i< iSecObjCount;i++)
						{
							if( pcTypeName != NULL && tc_strcmp(pcTypeName, pcreltype) == 0 ) 
							{
								
								TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tSecObj[i],strAttr,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);
								targetObjTag  =ptAttaches[i];	
							}
						}
					}
	
				}
				if ( (pcfromtype != NULL )  && (tc_strcmp(pcTypeName, pcfromtype) == 0) )
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[i],strAttr,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);
					targetObjTag  =ptAttaches[i];	
				}



				if ( ( pcfromtype == NULL ) && ( pcreltype == NULL ) && (pcrelation == NULL) && (targetObjTag != NULLTAG) )
				{
					//request will be processed for the below specified item revisions
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(targetObjTag,strAttr,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);

				}
				if(!strPropNameValueMap.empty())
				{
					string szassigneevalue=strPropNameValueMap.find(pcAssignee)->second;
					pcAssigneevalue=(char*)szassigneevalue.c_str();
					//Removing Participants
					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype(pcAssignParticipants,&tParticipantType),TD_LOG_ERROR_AND_THROW );
					TERADYNE_TRACE_CALL(iStatus = ITEM_rev_ask_participants(targetObjTag,tParticipantType,&iParticipantCount, &tParticipantlist),TD_LOG_ERROR_AND_THROW );
					for(int k = 0; k < iParticipantCount; k++) 
					{	
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_remove_participant(targetObjTag,tParticipantlist[k]),TD_LOG_ERROR_AND_THROW );
					}
					if(pcAssigneevalue != NULL)
					{
						//Getting Person tag
						TERADYNE_TRACE_CALL(iStatus = SA_find_person2(pcAssigneevalue, &tResponsiblePerson),TD_LOG_ERROR_AND_THROW );
						//Getting list of users available in TC
						TERADYNE_TRACE_CALL(iStatus = SA_extent_user(&iUsers, &tUsers),TD_LOG_ERROR_AND_THROW );
						for(int j = 0; j < iUsers; j++) 
						{
							//comparing user's person name with assignee value
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUsers[j], &pcPersonname),TD_LOG_ERROR_AND_THROW );
							if(tc_strcmp(pcPersonname, pcAssigneevalue) == 0)
							{
								tResponsibleUser = tUsers[j];
								Custom_free(pcPersonname);
								break;
							}

						}	
						TERADYNE_TRACE_CALL(iStatus = SA_ask_user_login_group(tResponsibleUser, &tGroup),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = SA_ask_user_default_role_in_group(tResponsibleUser, tGroup, &roleTag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(roleTag, &roleName), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tGroup, &grpName), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = SA_ask_user_identifier2(tResponsibleUser, &usrID), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = SA_find_groupmember_by_rolename(roleName, grpName, usrID, &iGrpMemCount, &tGrpMem), TD_LOG_ERROR_AND_THROW);
						//TERADYNE_TRACE_CALL(iStatus = SA_find_groupmembers (tResponsibleUser, tGroup, &iGrpMemCount, &tGrpMem),TD_LOG_ERROR_AND_THROW ); 
						if(iGrpMemCount > 0) 
						{
							////Assign assignee as responsible party of current task
							for(int g=0;g<iGrpMemCount;g++){
							   TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tGrpMem[g],tParticipantType,&tParticipant),TD_LOG_ERROR_AND_THROW );
							   POM_AM__set_application_bypass(true);
							   TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,true),TD_LOG_ERROR_AND_THROW );
							   TERADYNE_TRACE_CALL(iStatus = ITEM_rev_add_participant(targetObjTag,tParticipant),TD_LOG_ERROR_AND_THROW );
							   TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(targetObjTag),TD_LOG_ERROR_AND_THROW );
							   TERADYNE_TRACE_CALL(iStatus = AOM_refresh(targetObjTag,false),TD_LOG_ERROR_AND_THROW );
							   POM_AM__set_application_bypass(false);
							   break;
							}
						}
						Custom_free(tUsers);
						Custom_free(roleName);
						Custom_free(grpName);
						Custom_free(usrID);
				      }	
					break;
				}
				if(strPropNameValueMap.empty() && (targetObjTag != NULLTAG))
				{
					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype(pcAssignParticipants,&tParticipantType),TD_LOG_ERROR_AND_THROW );
					TERADYNE_TRACE_CALL(iStatus = ITEM_rev_ask_participants(targetObjTag,tParticipantType,&iParticipantCount, &tParticipantlist),TD_LOG_ERROR_AND_THROW );
					for(int k = 0; k < iParticipantCount; k++) 
					{	
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_remove_participant(targetObjTag,tParticipantlist[k]),TD_LOG_ERROR_AND_THROW );
					}
					break;
				}
				strPropNameValueMap.clear();
				Custom_free(pcTypeName);
				
			}		
		}			
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(ptAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}