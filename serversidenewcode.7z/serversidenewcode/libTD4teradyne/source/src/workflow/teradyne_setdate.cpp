/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_setdate.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SetDate action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  30-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_setdate
#  13-Apr-2015                       Vijayasekhar                    	Added changes to get the require attributes from the workflow handler arguments
#  15-Apr-2015                       Vijayasekhar                    	Removed the code to free memory for the handler arguments
#  28-Apr-2015                       Vijayasekhar                    	Added condition to process only for ECN
#  29-Apr-2015                       Vijayasekhar                    	Setting bypass while setting the date 
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_setdate
 * Description				: Sets the timestamp of the task
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_setdate(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL,
		  tAttrId				= NULLTAG,
		  tClassId				= NULLTAG;
	bool bIsNull				= false,
		 bIsEmpty				= false;
	string strTimeStamp			= "";
	char *pcPropName			= NULL,
		 *pcClassName			= NULL,
		 *pcAttachType			= NULL;
	date_t dDate;
	date_t curDate;

	const char * __function__ = "teradyne_setdate";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
			
			teradyne_get_handler_opts(msg.arguments,"-property", &pcPropName, NULL);
			if(pcPropName != NULL && tc_strcmp(pcPropName, "") != 0) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttaches; i++) {

					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)) {
					
						TERADYNE_TRACE_CALL(iStatus = POM_class_of_instance(tAttaches[i], &tClassId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = POM_name_of_class(tClassId, &pcClassName), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = POM_attr_id_of_attr(pcPropName, pcClassName, &tAttrId), TD_LOG_ERROR_AND_THROW);
						if(tAttrId != NULLTAG) {
							//Gets the auther sign off date
							TERADYNE_TRACE_CALL(iStatus = POM_ask_attr_date(tAttaches[i], tAttrId, &dDate, &bIsNull, &bIsEmpty), TD_LOG_ERROR_AND_THROW);
							if(bIsNull) {
								//set the current date
								TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("", strTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
								POM_AM__set_application_bypass(true);
								TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i], true), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_set_value_date(tAttaches[i], pcPropName, curDate), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tAttaches[i]), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tAttaches[i], false), TD_LOG_ERROR_AND_THROW);
								POM_AM__set_application_bypass(false);
							}
						}
					}
					Custom_free(pcAttachType);
					Custom_free(pcClassName);
				}
			}	
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
