#include <workflow/teradyne_handlers.h>



EPM_decision_t ur_ecn_validation_bomcheck(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t *t_SecObj = NULL, *attachments = NULL, root_task = NULL, t_relation = NULL, *t_SecObj1 = NULL, t_window = NULL, t_TopBomLine = NULL, *t_Childs = NULL;
	tag_t *t_bvr = NULLTAG, revruletag = NULLTAG;
	int iStatus, count = 0, i = 0, i1 = 0, BChild_Count = 0, j = 0, count1 = 0, count2 = 0, k = 0, BomChildCount = 0, b_count = 0, m = 0, C = 0, argnumber = 0, n = 0, valuelength = 0, c3 = 0;
	char *c_Pvalue1 = NULL, *sec_obj_type = NULL, *value = NULL, *t_ObjType = NULL, *c_Pvalue = NULL, *c_Pvalue2 = NULL;
	char *PchildCheck = NULL, *arg_name = NULL, *arg_value = NULL, *parentBusinessUnit, *newtoken, *c_childId = NULL, *childBusinessUnit;
	int l = 0, bvr_count = 0, m1 = 0, pro_count = 0, i2 = 0;
	tag_t t_bom = NULLTAG, tagObjType = NULLTAG, *t_bvr1 = NULL, t_window1 = NULL, revruletag1 = NULL, t_TopBomLine1 = NULL, *t_BChilds = NULL;
	char *bomType = NULL, *c_PContUnit = NULL, *c_CContUnit = NULL, *c_PObjString = NULL, **obj_props = NULL, *c_Partvalue = NULL;



	decision = EPM_go;
	map<string, vector<string>> controlUnitRulesMap;

	argnumber = TC_number_of_arguments(msg.arguments);
	for (n = 0; n < argnumber; n++)
	{

		TERADYNE_TRACE_CALL(iStatus = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &arg_name, &arg_value), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(arg_name, "Parent-Child-check") == 0)
		{
			valuelength = tc_strlen(arg_value);
			PchildCheck = (char*)MEM_alloc(valuelength);
			tc_strcpy(PchildCheck, "");
			tc_strcpy(PchildCheck, arg_value);

			parentBusinessUnit = tc_strtok(PchildCheck, ":");
			newtoken = tc_strtok(NULL, ":");

			childBusinessUnit = tc_strtok(newtoken, ",");
			vector<string> childTokens;
			while (childBusinessUnit != NULL)
			{
				childTokens.push_back(childBusinessUnit);

				childBusinessUnit = tc_strtok(NULL, ",");
			}

			controlUnitRulesMap.insert(pair<string, vector<string>>(parentBusinessUnit, childTokens));

		}


	}
	Custom_free(arg_name);
	Custom_free(arg_value);

	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if ((tc_strcmp(sec_obj_type, "TD4ReleaseECNRevision") == 0) || (tc_strcmp(sec_obj_type, "TD4StandardECNRevision") == 0))
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &c_Pvalue2), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation, &count2, &t_SecObj1), TD_LOG_ERROR_AND_THROW);




			// check the PartType having Intengible Value and if BVR present then check child component
			for (i1 = 0; i1 < count2; i1++)
			{
				TERADYNE_TRACE_CALL(AOM_ask_prop_names(t_SecObj1[i1], &pro_count, &obj_props), TD_LOG_ERROR_AND_THROW);
				for (i2 = 0; i2 < pro_count; i2++)
				{

					if ((tc_strcmp(obj_props[i2], "td4PartType") == 0))
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[i1], "td4PartType", &c_Partvalue), TD_LOG_ERROR_AND_THROW);
						if ((tc_strcmp(c_Partvalue, "Intangible") == 0))
						{
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(t_SecObj1[i1], &bvr_count, &t_bvr1), TD_LOG_ERROR_AND_THROW);
							if (bvr_count > 0)
							{
								for (m1 = 0; m1 < bvr_count; m1++)
								{

									TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window1), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag1), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window1, revruletag1), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window1, NULLTAG, t_SecObj1[i1], t_bvr1[m1], &t_TopBomLine1), TD_LOG_ERROR_AND_THROW);


									TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(t_TopBomLine1, &BChild_Count, &t_BChilds), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[i1], "object_string", &c_PObjString), TD_LOG_ERROR_AND_THROW);
									if (BChild_Count == 0)
									{
										TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, c_Pvalue2, c_PObjString), TD_LOG_ERROR_AND_THROW);
										C++;
									}

									TERADYNE_TRACE_CALL(iStatus = BOM_close_window(t_window1), TD_LOG_ERROR_AND_THROW);
								}
							}

						}
					}

				}
			}
			Custom_free(obj_props);
			Custom_free(c_Partvalue);
			Custom_free(t_bvr1);
			Custom_free(t_BChilds);
			Custom_free(c_PObjString);


			for (k = 0; k < count2; k++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[k], &t_ObjType), TD_LOG_ERROR_AND_THROW);

				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[k], "td4PartType", &c_Pvalue), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[k], "object_string", &c_Pvalue1), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[k], "td4ControllingBussUnit", &c_PContUnit), TD_LOG_ERROR_AND_THROW);

					if ((tc_strcmp(c_Pvalue, "Semi-Finished") == 0) || (tc_strcmp(c_Pvalue, "Finished Good") == 0))
					{
						TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(t_SecObj1[k], &b_count, &t_bvr), TD_LOG_ERROR_AND_THROW);
						if (b_count > 0)
						{
							for (m = 0; m < b_count; m++)
							{
								TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window, revruletag), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window, NULLTAG, t_SecObj1[k], t_bvr[m], &t_TopBomLine), TD_LOG_ERROR_AND_THROW);


								TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(t_TopBomLine, &BomChildCount, &t_Childs), TD_LOG_ERROR_AND_THROW);
								if (BomChildCount > 0)
								{

									for (l = 0; l < BomChildCount; l++)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "object_string", &c_childId), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(t_Childs[l], "bl_revision", &t_bom), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_object_type(t_bom, &tagObjType), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_name2(tagObjType, &bomType), TD_LOG_ERROR_AND_THROW);
										if (tc_strcmp(bomType, "TD4CommPartRevision") == 0 || tc_strcmp(bomType, "TD4DivPartRevision") == 0)
										{
											map<string, vector<string>>::iterator it;
											vector<string> childBusinessUnitList;
											it = controlUnitRulesMap.find(c_PContUnit);

											string szChildBusinessUnit;

											if (it != controlUnitRulesMap.end())
											{
												childBusinessUnitList = it->second;



												for (int ii = 0; ii < childBusinessUnitList.size(); ii++)
												{
													szChildBusinessUnit = childBusinessUnitList[ii];
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "bl_TD4CommPartRevision_td4ControllingBussUnit", &c_CContUnit), TD_LOG_ERROR_AND_THROW);
													if ((tc_strcmp(c_CContUnit, szChildBusinessUnit.c_str()) == 0))
													{
														c3++;
													}

												}
												Custom_free(c_CContUnit);
												if (c3 == 0)
												{
													decision = EPM_nogo;
													TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_VALUE, c_Pvalue1, c_childId), TD_LOG_ERROR_AND_THROW);
													C++;
												}
												c3 = 0;

											}

										}
										else
										{
											decision = EPM_nogo;
											TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE, c_childId, c_Pvalue1), TD_LOG_ERROR_AND_THROW);
											C++;
										}


									}
									Custom_free(c_childId);
									Custom_free(bomType);
								}
								else
								{

									TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, c_Pvalue2, c_Pvalue1), TD_LOG_ERROR_AND_THROW);
									C++;
								}

							}
							Custom_free(t_Childs);
						}
						else
						{

							TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, c_Pvalue2, c_Pvalue1), TD_LOG_ERROR_AND_THROW);
							C++;
						}
					}
					Custom_free(t_bvr);
				}
				Custom_free(c_Pvalue);
				Custom_free(c_Pvalue1);

			}
		}

	}
	Custom_free(c_Pvalue2);
	Custom_free(sec_obj_type);
	Custom_free(t_SecObj1);
	if (C > 0)
	{
		decision = EPM_nogo;
	}
	Custom_free(attachments);
	return decision;
}