
#include <workflow/teradyne_handlers.h>
EPM_decision_t ur_ecn_validation_statuscheck(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t root_task, *attachments = NULLTAG, t_relation1 = NULLTAG, *t_SecObj1 = NULLTAG;
	int iStatus, count1 = 0, i = 0, count2 = 0, j = 0, C = 0;
	char *sec_obj_type = NULL, *t_ObjType = NULL, *c_Itemstatus = NULL, *c_ECNType = NULL, 
		*c_ECNFor = NULL, *c_FastTrack = NULL, *c_ECNObjString = NULL, *c_PartObjString = NULL;
	decision = EPM_go;

	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count1, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count1; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &c_ECNObjString), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(sec_obj_type, "TD4ReleaseECNRevision") == 0)
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation1, &count2, &t_SecObj1), TD_LOG_ERROR_AND_THROW);
			for (j = 0; j < count2; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[j], &t_ObjType), TD_LOG_ERROR_AND_THROW);
				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "td4ItemStatus", &c_Itemstatus), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4ECNType", &c_ECNType), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4ECNFor", &c_ECNFor), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4FastTrack", &c_FastTrack), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &c_PartObjString), TD_LOG_ERROR_AND_THROW);
					
					if (tc_strcmp(c_ECNFor, "Intangible") == 0)
					{
						decision = EPM_go;
					}
					else if (tc_strcmp(c_FastTrack, "False") == 0)
					{
						if ((tc_strcmp(c_ECNType, "Prototype Release") == 0) && (tc_strcmp(c_Itemstatus, "Concept") == 0))
						{
							decision = EPM_go;
						}
						else if ((tc_strcmp(c_ECNType, "Prototype Release") == 0) && (tc_strcmp(c_Itemstatus, "Prototype") == 0))
						{
							decision = EPM_go;
						}
						else if ((tc_strcmp(c_ECNType, "PreProduction Release") == 0) && (tc_strcmp(c_Itemstatus, "Prototype") == 0))
						{
							decision = EPM_go;
						}
						else if ((tc_strcmp(c_ECNType, "PreProduction Release") == 0) && (tc_strcmp(c_Itemstatus, "Pre-Production") == 0))
						{
							decision = EPM_go;
						}
						else if ((tc_strcmp(c_ECNType, "Production Release") == 0) && (tc_strcmp(c_Itemstatus, "Pre-Production") == 0))
						{
							decision = EPM_go;
						}
						else if ((tc_strcmp(c_ECNType, "Production Release") == 0) && (tc_strcmp(c_Itemstatus, "Production") == 0))
						{
							decision = EPM_go;
						}
						else
						{
							decision = EPM_nogo;
							TERADYNE_TRACE_CALL(EMH_store_error_s4(EMH_severity_error, TD_Diff_Status, c_ECNObjString, c_PartObjString, c_Itemstatus, c_ECNType), TD_LOG_ERROR_AND_THROW);
							C++;
						}
					}
					else
					{
						decision = EPM_go;
					}
					Custom_free(c_ECNType);
					Custom_free(c_ECNFor);
					Custom_free(c_FastTrack);
					Custom_free(c_PartObjString);
				}
				Custom_free(c_Itemstatus);
			}

		}

		Custom_free(t_SecObj1);
	}
	Custom_free(sec_obj_type);
	Custom_free(c_ECNObjString);
	if (C > 0)
	{
		decision = EPM_nogo;
	}
	Custom_free(attachments);
	return decision;
}