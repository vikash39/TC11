/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_createandcopydseforms.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CreateAndCopyDSEForms action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  24-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_createandcopydseforms and teradyne_copy_forms_into_relation
#  24-Apr-2015                       Vijayasekhar                    	Added code changes to get the reviced parts from Solution Items folder
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_createandcopydseforms
 * Description				: This function will copy all the DSE forms of the previous Part Revision to the current part revison if current part revision is being released
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
int teradyne_createandcopydseforms(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iOriForms				= 0,
		iRevs					= 0,
		iSolutionItems			= 0;
	tag_t *tAttaches			= NULL,
		  tRevTag				= NULLTAG,
		  tDisSpecRelTag		= NULLTAG,
		  *tOriForms			= NULL,
		  tNewForm				= NULLTAG,
		  tRelation				= NULLTAG,
		  *tRevs				= NULL,
		  *tSolutionItems		= NULL;
	char *pcFormType			= NULL, 
		 *pcAttachType			= NULL;
	string strFormName			= "";

	const char * __function__ = "teradyne_createandcopydseforms";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSolutionItems, &tSolutionItems), TD_LOG_ERROR_AND_THROW);
					
					char *pcObjectType = NULL;
					for (int l = 0; l < iSolutionItems; l++) {

						iStatus = WSOM_ask_object_type2(tSolutionItems[l], &pcObjectType);
						if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0) {
							TERADYNE_TRACE_CALL(iStatus = teradyne_list_all_revisions_from_revtag(tSolutionItems[l], &iRevs, &tRevs), TD_LOG_ERROR_AND_THROW);
							for (int j = 0; j < iRevs && iRevs > 1; j++) {

								if (tRevs[j] == tSolutionItems[l]) {

									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tRevs[j - 1], TD_DIS_SPEC_REL_NAME, &iOriForms, &tOriForms), TD_LOG_ERROR_AND_THROW);
									tag_t *tOriFormsTemp = tOriForms;
									for (int k = 0; k < iOriForms; k++) {

										if (pcFormType != NULL) { pcFormType = NULL; }
										strFormName = "";
										TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(*tOriFormsTemp, &pcFormType), TD_LOG_ERROR_AND_THROW);
										if (!tc_strcmp(pcFormType, TD_CHANGEADMIN_FORM_TYPE)) {

											strFormName = "Change Admin Form";
										}
										else if (!tc_strcmp(pcFormType, TD_TRADE_COMPL_FORM_TYPE)) {

											strFormName = "Trade Compliance Form";
										}
										else if (!tc_strcmp(pcFormType, TD_SAFETY_FORM_TYPE)) {

											strFormName = "Safety Form";
										}
										else if (!tc_strcmp(pcFormType, TD_SBM_FORM_TYPE)) {

											strFormName = "SBM Form";
										}
										else if (!tc_strcmp(pcFormType, TD_DFM_FORM_TYPE)) {

											strFormName = "DFM Form";
										}
										else {

											tOriFormsTemp++;
											continue;
										}
										TERADYNE_TRACE_CALL(iStatus = teradyne_copy_forms_into_relation(strFormName, tSolutionItems[l], tOriFormsTemp, TD_DIS_SPEC_REL_NAME), TD_LOG_ERROR_AND_THROW);
										tOriFormsTemp++;
										Custom_free(pcFormType);
									}
									break;
								}
								Custom_free(tOriForms);
							}
							Custom_free(tRevs);
						}
						Custom_free(pcObjectType);
					}
				}
				Custom_free(pcAttachType);
				Custom_free(tSolutionItems);
			}
		}
	}
	catch (...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_copy_forms_into_relation
 * Description				: This function will launch the workflow process for the given
 *                            object and attach it as target or reference attachment
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strNewFormName          (I) - Name of the new form string
 *							  tPrimary                (I) - Primary object tag_t
 *                            tOldForm		          (I) - Old form tag_t*
 *                            strRelName		      (I) - Relation name string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
int teradyne_copy_forms_into_relation(string strNewFormName, tag_t tPrimary, tag_t* tOldForm, string strRelName ) {

	int iStatus					= ITK_ok;
	tag_t tNewForm				= NULLTAG,
		  tDisSpecRelTag		= NULLTAG,
		  tRelation				= NULLTAG;

	const char * __function__ = "teradyne_copy_forms_into_relation";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(strRelName.c_str(),&tDisSpecRelTag),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = FORM_copy2(strNewFormName.c_str(), tOldForm, &tNewForm), TD_LOG_ERROR_AND_THROW);
		if(tNewForm != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tNewForm), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewForm, false), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimary, tNewForm, tDisSpecRelTag, &tRelation), TD_LOG_ERROR_AND_THROW);
			if(tRelation == NULLTAG) {
			
				TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tPrimary, tNewForm, tDisSpecRelTag, NULLTAG, &tRelation), TD_LOG_ERROR_AND_THROW);
			}
			if(tRelation != NULLTAG) {
				
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimary, true), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tRelation), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimary, false), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch (...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}