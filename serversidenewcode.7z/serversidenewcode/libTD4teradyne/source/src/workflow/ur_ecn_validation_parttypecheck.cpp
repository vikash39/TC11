
#include <workflow/teradyne_handlers.h>
EPM_decision_t ur_ecn_validation_parttypecheck(EPM_rule_message_t msg)
{

	EPM_decision_t decision;

	tag_t *t_SecObj = NULLTAG, *attachments = NULLTAG, root_task = NULLTAG,
		t_relation = NULLTAG, *t_SecObj1 = NULLTAG, t_rev = NULLTAG;

	int iStatus, count = 0, i = 0, count2 = 0, k = 0, c = 0,
		n1 = 0, argnumber = 0, valuelength = 0;

	char *sec_obj_type = NULL, *value = NULL, *t_ObjType = NULL,
		*d_PartType = NULL, *c_ECNFor = NULL, *d_value2 = NULL,
		*c_ECNObjString = NULL, *strcat1 = NULL, *strcat2 = NULL,
		*arg_name = NULL, *arg_value = NULL, *ArgValue = NULL,
		*ECNForTokens = NULL, *newtoken = NULL, *PartType = NULL,
		*s_cat = NULL, *s_cpy = NULL;

	decision = EPM_go;

	// Get the all handler argument Name and Value

	map<string, vector<string>> ECNForPartTypeMap;

	argnumber = TC_number_of_arguments(msg.arguments);
	for (n1 = 0; n1 < argnumber; n1++)
	{

		TERADYNE_TRACE_CALL(iStatus = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &arg_name, &arg_value), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(arg_name, "ECN-For-Part-Type") == 0)
		{
			valuelength = tc_strlen(arg_value);
			ArgValue = (char*)MEM_alloc(valuelength);
			tc_strcpy(ArgValue, "");
			tc_strcpy(ArgValue, arg_value);

			ECNForTokens = tc_strtok(ArgValue, ":");
			newtoken = tc_strtok(NULL, ":");

			PartType = tc_strtok(newtoken, ",");
			vector<string> PartTypeTokens;
			while (PartType != NULL)
			{
				PartTypeTokens.push_back(PartType);

				PartType = tc_strtok(NULL, ",");
			}

			ECNForPartTypeMap.insert(pair<string, vector<string>>(ECNForTokens, PartTypeTokens));

		}


	}
	Custom_free(arg_name);
	Custom_free(arg_value);


	// checking the ECN For and Part Type Value 

	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(sec_obj_type, "TD4ReleaseECNRevision") == 0)
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation, &count2, &t_SecObj1), TD_LOG_ERROR_AND_THROW);

			for (k = 0; k < count2; k++)
			{

				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[k], &t_ObjType), TD_LOG_ERROR_AND_THROW);

				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[k], "td4PartType", &d_PartType), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4ECNFor", &c_ECNFor), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[k], "object_string", &d_value2), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &c_ECNObjString), TD_LOG_ERROR_AND_THROW);

					map<string, vector<string>>::iterator it;
					vector<string> ArgumentPartType;
					int ccount = 0;
					it = ECNForPartTypeMap.find(c_ECNFor);
					string szArgumentPartType;

					if (it != ECNForPartTypeMap.end())
					{
						ArgumentPartType = it->second;

						for (int ii = 0; ii < ArgumentPartType.size(); ii++)
						{
							szArgumentPartType = ArgumentPartType[ii];
							if ((tc_strcmp(d_PartType, szArgumentPartType.c_str()) == 0))
							{
								++ccount;

							}

						}
						if (ccount == 0)
						{
							TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_Diff_Value_than_ECN, d_value2, c_ECNObjString), TD_LOG_ERROR_AND_THROW);
							c++;
						}
					}
					Custom_free(d_PartType);
					Custom_free(c_ECNFor);
					Custom_free(d_value2);

				}

			}

		}

	}
	if (c > 0)
	{
		decision = EPM_nogo;

	}
	Custom_free(c_ECNObjString);
	Custom_free(sec_obj_type);
	Custom_free(t_SecObj1);
	Custom_free(attachments);
	return decision;
}