/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_protobomecnvalidations.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ProtoBOMECNValidations action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_protobomecnvalidations
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  05-May-2015					     Vijayasekhar                    	Changed the validation rules
#  01-Oct-2015                       Manimaran                          Modified the code to allow single parts (w/o BOMs) to be revised within ProtoBOM ECN.
#  15-Oct-2015                       Manimaran                          Modified the code to not to allow single parts (w/o BOMs) to be revised within ProtoBOM ECN.
#  14-Dec-2015						 Kameshwaran D						Added condition to restrict if all impacted items(DivPart) are not revised.
#  23-Dec-2015                       Manimaran                          Modified the code to throw error if no items present under Impacted Items Folder of ECN.
#  18-Jan-2016                       Manimaran                          Modified the code to skip the Impacted Items check for ProtoBOM ECN.
#  25-Mar-2016                       Haripriya                          Modified the code to check childlines object type because Divisional and commercial Part Revisions are allowed and changed teradyne_get_bomline_children arguments.
#  04-May-2016                       Haripriya                          Modified the teradyne_check_if_new_revision_exists_in_solutionitemsfolder function to check same revision is present in impacted and solution item folder
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_protobomecnvalidations
 * Description				: This function will validates the Assembly/Itemstatus on ProtoBOMECN
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the parts attached to the relation Solution Items
 *							  2. Will check the part is an assembly if not stops the tast
 *							  3. Will check the Item status for the part revision is "Prototype if not stops the tast
 * NOTES					: 
 ******************************************************************************/
int teradyne_protopartecnvalidations(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0,
		iPartCount				= 0,
		iBvrCount				= 0,
		iDataset				= 0 ;
	tag_t *tAttachList			= NULL,
		  *tPartList			= NULL,
		  *tBvrList				= NULL,
		  *tChildLine			= NULL,
		  *tDataset				= NULL,
		  tPrevRev				= NULLTAG;
	char *pcPartType			= NULL,
		 *pcItemStatus			= NULL,
		 *pcObjectType			= NULL,
		 *pcECNId				= NULL,
		 *pcItemId				= NULL;

	bool bIsBomError			= false;
	bool bisDatasetExist		= false,
		 bisDesignDocExist		= false,
		 bIsStatusError			= false;
	std::map<string,string> mapDocMissingDataSet;
	int iDocMissingDataSet=0;

	const char * __function__ = "teradyne_protopartecnvalidations";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &tAttachList), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachList[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_PROTOPART_ECN_REV_TYPE)) {
				
					//Gets the ECN number for the error messages reference
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i],TD_ITEM_ID_ATTR, &pcECNId), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachList[i], TD_SOLUTION_ITEMS_REL_NAME, &iPartCount, &tPartList), TD_LOG_ERROR_AND_THROW);
					//Validate if new revision exists in solution item folder
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_if_new_revision_exists_in_solutionitemsfolder(tAttachList[i], tPartList, iPartCount, pcObjectType), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iPartCount; j++) {
				
						bIsBomError = false;
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tPartList[j], &pcItemId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPartList[j], &pcPartType), TD_LOG_ERROR_AND_THROW);


						if(tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0) { //checking for Div part revision since solution items can also have Design Documents also
						
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPartList[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
							if(pcItemStatus == NULL) {
								//Check for the attribute in previous revision
								if(tPrevRev != NULLTAG) tPrevRev = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tPartList[j], &tPrevRev),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
							}
							//Check the item status on part revision is Prototype or not
							if(tc_strcmp(pcItemStatus, TD_PROTO_TYPE_ATTR)) {
						
								char *pcECNId = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_ITEM_STATUS_ERROR_PROTOBOM, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_ITEM_STATUS_ERROR_PROTOBOM;
								Custom_free(pcECNId);
								throw iStatus;
							}
							iBvrCount = 0;
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tPartList[j], &iBvrCount, &tBvrList), TD_LOG_ERROR_AND_THROW); 
							//Check the part revision has BOM
							if(iBvrCount > 0) { 
								bIsBomError = true;
								
							} 
							if(bIsBomError) {
							
								char *pcECNId = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachList[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_PROTO_PART_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus =  TD_PROTO_PART_ERROR;
								Custom_free(pcECNId);
								throw iStatus;
							}
						
						
							TERADYNE_TRACE_CALL(iStatus = teradyne_check_designdocument(tPartList[j],tAttachList[i],bisDesignDocExist,mapDocMissingDataSet) , TD_LOG_ERROR_AND_THROW);
						
							if (!bisDesignDocExist)
							{
								//checks the part has dataset
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tPartList[j], TD_REF_MATERIAL_REL, &iDataset, &tDataset), TD_LOG_ERROR_AND_THROW);
								if (iDataset > 0)
								{
									bisDatasetExist = true;
									Custom_free(tDataset);
								}
							}


							if (!bisDatasetExist && !bisDesignDocExist)
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_DESIGNDOC_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_DATASET_DESIGNDOC_ERROR;
								throw iStatus;
							}

							// Docs missing ITAR/Datasets....
							if (!mapDocMissingDataSet.empty()) {
								for (map<string, string>::iterator it = mapDocMissingDataSet.begin(); it != mapDocMissingDataSet.end(); it++) {
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC, it->first.c_str(), it->second.c_str()), TD_LOG_ERROR_AND_THROW);
								}
								iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
							}
						
						
						}
						Custom_free(pcPartType);
						Custom_free(tBvrList);
						Custom_free(pcItemStatus);
						Custom_free(pcItemId);
						Custom_free(pcECNId);
					}
				}
				Custom_free(pcObjectType);
				Custom_free(tPartList);
			}

			if(iDocMissingDataSet > 0){
				iStatus=iDocMissingDataSet;
		       throw iDocMissingDataSet;
		}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttachList);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

