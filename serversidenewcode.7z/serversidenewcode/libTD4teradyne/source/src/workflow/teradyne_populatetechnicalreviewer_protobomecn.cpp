/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_populatetechnicalreviewer_protobomecn.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne_PopulateTechReviewerProtobom action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  18-Mar-2015                       Haripriya                    	    Initial Creation
#  15-Apr-2015                       Haripriya                          Modified the function teradyne_get_prop_value_from_primary_project
#  27-Apr-2015						 Haripriya						    Removed the extra space while tokenising string.
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  23-Jun-2015                       Haripriya                    	    Added Error if the planner value is empty
#  10-Jul-2015                       Haripriya                    	    Modified teradyne_populatetechnicalreviewer_protobomecn in getting planner value
#  17-Jun-2019						 Marjorie							Modified teradyne_populatetechnicalreviewer_protobomecn in assigning td4ObserversList from project form td4Observers
#  04-Sep-2019						 Marjorie							Modified teradyne_populatetechnicalreviewer_protobomecn to include td4SpecializedReviewers to TechReviewers from project form
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
/*******************************************************************************
 * Function Name			: teradyne_populatetechnicalreviewer_protobomecn
 * Description				: This function will Update Required Technical Reviewer in ProtobomECN Revision 
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Gets the Primary Project value in Protobom ECN Revision
 *							  2. Gets the planner Valuefrom the found project form and update
 *							     Required Technical Reviewer in ProtobomECN Revision 
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_populatetechnicalreviewer_protobomecn(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0;

	char *pcObjectType		= NULL,
		**pcObserversarray  = NULL, 
	**pcSpecializedReviewersArray = NULL, 
		 *pcProjAttr		= NULL,  
	**pcTechreviewerarray   = NULL;

	tag_t *tAttachtag       = {NULLTAG}, projectTag = NULLTAG;

	string szPropertyName = " "; 

	vector<string> TechreviewerValues, observersValues, specializedReviewersValues, holderReviewers, technicalReviewers;
	 std::map<string,string> strPropNameValueMap;

	
	bool bcheck = false;

	const char * __function__    = "teradyne_populatetechnicalreviewer_protobomecn" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment,&iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) || !tc_strcmp(pcObjectType, TD_PROTOPART_ECN_REV_TYPE)) 
				{
				
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[i],TD_PRIMARY_PROJ_ATTR,&pcProjAttr),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(pcProjAttr,TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
					
					//Adding Specialized Reviewers to Tech Reviewers list
					szPropertyName=" ";
					bcheck = false;
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_arrayproperty_value(projectTag,TD_SPECIALIZED_REVIEWERS_ATTR,specializedReviewersValues,szPropertyName,bcheck),TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < specializedReviewersValues.size() ; j++)
						holderReviewers.push_back(specializedReviewersValues[j]);

					//Getting the project value
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(tAttachtag[i],strPropNameValueMap,TD_PLANNER_ATTR),TD_LOG_ERROR_AND_THROW);
					if(strPropNameValueMap.find(TD_PLANNER_ATTR)->second.length() > 0)
					{
						char *pc=(char *)strPropNameValueMap.find(TD_PLANNER_ATTR)->second.c_str();
						holderReviewers.push_back(pc);
					}
					else
					{
						char *pcECNId = NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[i],TD_ITEM_ID_ATTR, &pcECNId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error,TD_PROTOBOM_ECN_PLANNER_ERROR,pcECNId),TD_LOG_ERROR_AND_THROW);
						iStatus = TD_PROTOBOM_ECN_PLANNER_ERROR;
						Custom_free(pcECNId);
						throw iStatus;
					}

					//validate if there are duplicates
					std:sort(holderReviewers.begin(), holderReviewers.end());
					holderReviewers.erase(std::unique(holderReviewers.begin(), holderReviewers.end()), holderReviewers.end());

					for(int k = 0; k < holderReviewers.size() ; k++)
					{
							TechreviewerValues.push_back(holderReviewers[k]);
						TC_write_syslog("TechReviewers: %s:",holderReviewers[k]);
					}
					
					//Converting vector to char** array and Setting Value on Protobom ECN Revision
					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array(TechreviewerValues,&pcTechreviewerarray),TD_LOG_ERROR_AND_THROW);
					
					//Setting td4ReqTechReviewersList 
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_REQ_TECH_REVIEWERS_ATTR,(int)TechreviewerValues.size(),pcTechreviewerarray),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcTechreviewerarray);

					// Setting Observers from Project Form
					observersValues.push_back("Observer:");
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttachtag[i],TD_PRIMARY_PROJ_ATTR,&pcProjAttr),TD_LOG_ERROR_AND_THROW);

					string szPropertyName=" ";
					TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(pcProjAttr,TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_OBSERVER_ATTR,observersValues,szPropertyName,bcheck),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array(observersValues,&pcObserversarray),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_OBSERVERS_LIST_ATTR,(int)observersValues.size(),pcObserversarray),TD_LOG_ERROR_AND_THROW);
                    Custom_free(pcObserversarray);
				}	
				Custom_free(pcObjectType);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttachtag);
	TechreviewerValues.clear();
	
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_prop_value_from_primary_project
 * Description				: Gets the Planner attr value from Primary Project value saved in ECNRevision
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObjTag   (I)	          -  tag_t
 *							  TechreviewerValues  (O) - vector<string>
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_prop_value_from_primary_project( tag_t tObjTag,std::map<string,string> &strPropNameValueMap,string szpropname)
{
	int iStatus					= ITK_ok,
		iFound                  = 0;

	char *pcProjAttr            = NULL;

	tag_t projectTag        =NULLTAG; 

	string szProjAttr[] ={szpropname};

	const char * __function__ = "teradyne_get_prop_value_from_primary_project";
	TERADYNE_TRACE_ENTER();

	try 
	{
		std::list<std::string> strAttr(szProjAttr,szProjAttr+sizeof(szProjAttr)/sizeof(string));
		//Getting the project value
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjTag,TD_PRIMARY_PROJ_ATTR,&pcProjAttr),TD_LOG_ERROR_AND_THROW);				   

		if(tc_strlen(pcProjAttr) > 0)
		{
		
			TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(pcProjAttr,TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(projectTag,strAttr,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);
			
		}
					
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(pcProjAttr);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}