/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_releaseECNvalidation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ReleaseECNValidation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                                 Name                               Description of Change
#  18-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_validations and teradyne_find_relation
#  13-Apr-2015                       Vijayasekhar                    	Changed the handler name to Teradyne-ReleaseECNValidation
#  29-Apr-2015					     Vijayasekhar                    	Added condition to check the suitable target objects
#  05-May-2015					     Vijayasekhar                    	Changed the validation rules and error messages
#  13-May-2015					     Vijayasekhar                    	Removed the error condition for ECN type for non Production status
#  14-May-2015					     Haripriya                    	    Modified teradyne_releaseECNvalidation function and Dataset relation name to DesignDocument
#  15-May-2015					     Haripriya                    	    Added teradyne_validate_all_child_lines function.
#  19-May-2015					     Haripriya                    	    Removed teradyne_validate_all_child_lines function and validation happens for first level child.
#  20-May-2015					     Haripriya                    	    Modified teradyne_get_bomline_children arguments.
#  21-May-2015					     Haripriya                    	    Modified the function as per the tech spec,added release status check on Design Document Revision.
#  03-Jul-2015					     Haripriya                    	    Modified the function to check validation for Pre-Production release also.
#  04-Aug-2015					     Haripriya                    	    Modified the function to Perform ITAR Form validation in Revision.
#  18-Aug-2015					     Haripriya                    	    Modified the validation to work for DesignDocument Revision.
#  25-Aug-2015					     Haripriya                    	    validating ITARREL has ITAR Form
#  25-Feb-2016                       Manimaran                          Modified the code to set the revision id to "A" if "*" revision is found at the solution items folder of Release ECN.
#  03-Mar-2016                       Haripriya                          Modified the code to set the BomViewrevision id to "A" if "*" revision is found at the solution items folder of Release ECN and bypassing to check ItarForm Objecttype.
#  25-Mar-2016                       Haripriya                          Modified the code to check childlines object type because Divisional and commercial Part Revisions are allowed.Added teradyne_check_designdocument function to check designdocument.
#  02-Jun-2021					     Marjorie                    	    BT252 Add validation for Production and Pre-Production Item Status of parts to Production/Pre-Production Release ECN
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_releaseECNvalidation
 * Description				: This function will validates the Production status on BOM and its children
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the parts attached to the relation Solution Items
 *							  2. Will check the part is an assembly and status is 'Production'
 *							  3. If the part is not an assembly checks for the Dataset with named reference if not throws the error
 *							  4. If the part has the dataset checks for the design document with file associated if not throws the error
 * NOTES					: 
 ******************************************************************************/
int teradyne_releaseECNvalidation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iParts					= 0,
		iBomCount				= 0,
		iChildCount				= 0,
		iDataset				= 0,
		iDocDataset				= 0,
		iDesignDoc				= 0,
		iItarFrmCnt             = 0;
	tag_t *tAttaches			= NULL,
		  *tParts				= NULL,
		  *tBomViewRevs			= NULL,
		  *tChildLine			= NULL,
		  tItemRev				= NULLTAG,
		  tRelation				= NULLTAG,
		  *tDataset				= NULL,
		  *tDesignDoc			= NULL,
		  *tDocDataset			= NULL,
		  *tItarFrmTag          = NULL,
		  tPrevRev				= NULLTAG;
	char *pcRevId				= NULL,
		 *pcEcnType				= NULL,
		 *pcPartType			= NULL,
		 *pcDesignDoc			= NULL,
		 *pcAttachType			= NULL,
		 *pcItemId				= NULL,
		 *pcBomType				= NULL,
		 *pcChildPropVal		= NULL,
		 *pcECNId				= NULL;
	bool bisDatasetExist		= false,
		 bisDesignDocExist		= false,
		 bIsStatusError			= false;
	std::map<string,string> mapDocMissingDataSet;
	int iDocMissingDataSet=0;

	const char * __function__ = "teradyne_releaseECNvalidation";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE)) 
				{ 
					//Gets the ECN number for the error messages reference
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i],TD_ITEM_ID_ATTR, &pcECNId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_ECN_TYPE_ATTR, &pcEcnType),TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcEcnType, "Inactive Release") != 0)
					{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iParts, &tParts), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iParts; j++) 
					{
						bisDatasetExist = false;
						bisDesignDocExist = false;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_ITEM_REV_ID_ATTR, &pcRevId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tParts[j], &pcPartType), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tParts[j], &pcItemId), TD_LOG_ERROR_AND_THROW);
						if(pcRevId != NULL && (tc_strcmp(pcRevId, "*") == 0) && (tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0)) {
							//Set the revision id to "A" if "*" revision is found at the solution items folder of Release ECN
							int iBomCountCheck     = 0;
							tag_t *tBomViewRevions = NULL;

							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus = ITEM_set_rev_id(tParts[j], "A"), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tParts[j]), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tParts[j], &iBomCountCheck, &tBomViewRevions), TD_LOG_ERROR_AND_THROW); 
							if(iBomCountCheck > 0)
							{
		    					for(int z = 0; z < iBomCountCheck;z++) 
								{
									//Set the BomViewRevision id to "A" if "*" revision is found at the solution items folder of Release ECN
									char *pcBomViewRev=NULL;
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tBomViewRevions[z],TD_OBJECT_NAME_ATTR,&pcBomViewRev),TD_LOG_ERROR_AND_THROW);
									string szBomViewRev = string(pcBomViewRev);
									int ifnd = (int)szBomViewRev.find_last_of("-");
									string szBomViewRevName = string(pcItemId)+"/"+"A"+string(szBomViewRev.substr(ifnd,szBomViewRev.length()));
									TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tBomViewRevions[z],TD_OBJECT_NAME_ATTR,szBomViewRevName),TD_LOG_ERROR_AND_THROW);
									Custom_free(pcBomViewRev);
								}
							}
							Custom_free(tBomViewRevions);
							POM_AM__set_application_bypass(false);

							char *pcNewRevID = NULL;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_ITEM_REV_ID_ATTR, &pcNewRevID), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(pcNewRevID, "*") == 0) {
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_NO_REV_ID_ERROR, pcECNId), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_NO_REV_ID_ERROR;
								Custom_free(pcNewRevID);
								throw iStatus;
							}
						}
				        Custom_free(pcRevId);
						if((tc_strcmp(pcPartType, TD_DIV_PART_REV) == 0)) 
						{
							//if part item status is Production OR Pre-Production
							char *pcItemStatus = NULL;

							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_ITEM_STATUS_ATTR, &pcItemStatus), TD_LOG_ERROR_AND_THROW);
						if ((tc_strcmp(pcItemStatus, "Inactive") != 0))
						{
							if ((tc_strcmp(pcItemStatus, TD_PRODUCTION_TYPE_ATTR) == 0) ) {
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_PRODUCTION_ON_RELEASE_ECN_ERROR, pcItemId, ""), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_PRODUCTION_ON_RELEASE_ECN_ERROR;
								throw iStatus;
							}

							if ((tc_strcmp(pcItemStatus, TD_PRE_PRODUCTION_TYPE_ATTR) == 0) && (tc_strcmp(pcEcnType, "PreProduction Release") == 0)) {
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_PRE_PRODUCTION_ON_PRE_PROD_RELEASE_ECN_ERROR, pcItemId, ""), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_PRE_PRODUCTION_ON_PRE_PROD_RELEASE_ECN_ERROR;
								throw iStatus;
							}
							Custom_free(pcItemStatus);



							TERADYNE_TRACE_CALL(iStatus = teradyne_check_designdocument(tParts[j],tAttaches[i],bisDesignDocExist,mapDocMissingDataSet) , TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tParts[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW); 
							if( iBomCount > 0 )
							{
								for(int k = 0; k < iBomCount; k++) 
								{
									tag_t tWindow = NULLTAG;
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_bomline_children(tParts[j], tBomViewRevs[k], &iChildCount, &tChildLine, &tWindow,pcEcnType), TD_LOG_ERROR_AND_THROW);
									if(tc_strcmp(pcEcnType, "Production Release") == 0)
									{
										if(iChildCount > 0) 
										{
											for(int l = 0; l < iChildCount; l++)
											{ 
												if(tItemRev != NULLTAG) { tItemRev = NULLTAG; }
												TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tChildLine[l], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
												if(tItemRev != NULLTAG)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tItemRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcChildPropVal), TD_LOG_ERROR_AND_THROW);
													if(pcChildPropVal == NULL)
													{
														TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tItemRev, &tPrevRev),TD_LOG_ERROR_AND_THROW);
														TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcChildPropVal), TD_LOG_ERROR_AND_THROW);
													}
													//Commercial Parts are assumed always in production status
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcBomType), TD_LOG_ERROR_AND_THROW);
													if((!tc_strcmp(pcBomType, TD_DIV_PART_REV)))
													{
														if(((!tc_strcmp(pcChildPropVal, "Pre-Production") || !tc_strcmp(pcChildPropVal, "Prototype"))))
														{
															//Check whether the part is related to ReleaseECN with solution items relation
															if(tRelation != NULLTAG) { tRelation = NULLTAG; }
															TERADYNE_TRACE_CALL(iStatus = teradyne_find_relation(tAttaches[i], tItemRev, TD_SOLUTION_ITEMS_REL_NAME, &tRelation), TD_LOG_ERROR_AND_THROW);	
															if(tRelation == NULLTAG) 
															{ //part is not attached to the solution items relation
																bIsStatusError = true;
															}
														}
													}
													else if((tc_strcmp(pcBomType, TD_DIV_PART_REV)!=0) && (tc_strcmp(pcBomType, TD_COMM_PART_REV)!=0))
													{
														char *pcChildId = NULL;
														TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcChildId), TD_LOG_ERROR_AND_THROW);
														TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE_ERROR, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW);
														iStatus = TD_BOM_INVALID_CHILD_TYPE_ERROR;
														Custom_free(pcChildId);
														throw iStatus;
													}
													if(bIsStatusError) 
													{ 
															
														char *pcChildId = NULL;
														if(tWindow != NULLTAG) {
														
															TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);
														}
														TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcChildId), TD_LOG_ERROR_AND_THROW);
														TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_PRODUCTION_STATUS_ERROR, pcECNId, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW); 
														iStatus = TD_PRODUCTION_STATUS_ERROR;
														Custom_free(pcChildId);
														throw iStatus;
													}
												}
												Custom_free(pcChildPropVal);
												Custom_free(pcBomType);
											}
											Custom_free(tChildLine);
											if(tWindow != NULLTAG) {
														
												TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);
											}
										}
										else
										{
											TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_CHILDREN_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
											iStatus = TD_BOM_CHILDREN_ERROR;
											throw iStatus;
										}
								    }
								}
							}
															
							
							if(!bisDesignDocExist) { 
									//checks the part has dataset
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tParts[j], TD_REF_MATERIAL_REL, &iDataset, &tDataset), TD_LOG_ERROR_AND_THROW);
								 if(iDataset > 0){
											bisDatasetExist = true;
											Custom_free(tDataset);
									}  
								}
								
							if(!bisDatasetExist && !bisDesignDocExist && iBomCount == 0){
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_DESIGNDOC_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
									iStatus = TD_DATASET_DESIGNDOC_ERROR;
									throw iStatus;
								}

							// Docs missing ITAR/Datasets....
						   if(!mapDocMissingDataSet.empty()){
						      for ( map<string, string>::iterator it = mapDocMissingDataSet.begin( ); it != mapDocMissingDataSet.end( ); it++ ){
									 TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC,it->first.c_str(),it->second.c_str()), TD_LOG_ERROR_AND_THROW);
							}
						      iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
						   }

						}
								else if (tc_strcmp(pcItemStatus, "Inactive") == 0)
								{
									if (iDocMissingDataSet == 0) {
										iStatus == ITK_ok;
									}
								}			
							Custom_free(tBomViewRevs);
						}


						//check here for design documents if has datasets
						if((tc_strcmp(pcPartType, TD_DESIGN_DOC_REV_TYPE) == 0)) 
						{		
							int iDesignErr = 0,	iItarFrmCnt = 0;
							bool bisItarFrmExist = false;
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tParts[j], TD_ITAR_REL, &iItarFrmCnt, &tItarFrmTag), TD_LOG_ERROR_AND_THROW);
							if (iItarFrmCnt > 0)
							{
								for (int iITarCnt = 0; iITarCnt < iItarFrmCnt; iITarCnt++)
								{
									char *pcItarFrm = NULL;
									//Bypassing to read Itar Form Object type
									POM_AM__set_application_bypass(true);
									TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItarFrmTag[iITarCnt], &pcItarFrm), TD_LOG_ERROR_AND_THROW);
									POM_AM__set_application_bypass(false);
									if (tc_strcmp(pcItarFrm, TD_ITAR_FORM_TYPE) == 0)
									{
										iDesignErr++;
										bisItarFrmExist = true;
										break;
									}
									Custom_free(pcItarFrm);
								}
								Custom_free(tItarFrmTag);
							}
							if (!bisItarFrmExist)
							{
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tParts[j], TD_REF_MATERIAL_REL, &iDocDataset, &tDocDataset), TD_LOG_ERROR_AND_THROW);
								if (iDocDataset > 0)
								{
									iDesignErr++;
									Custom_free(tDocDataset);
								}
							}
							
							if(!bisItarFrmExist && iDocDataset==0)
							{
								string pcDocumentMissingDataSet="";
								char *pcItemId = NULL;
								char *pcRevId  = NULL;
								char *pcDocumentType = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_ITEM_ID_ATTR, &pcItemId),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_ITEM_REV_ID_ATTR, &pcRevId),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tParts[j], TD_DOCUMENT_TYPE_ATTR, &pcDocumentType),TD_LOG_ERROR_AND_THROW);
					
								pcDocumentMissingDataSet.append(pcItemId).append("_").append(pcDocumentType);
								mapDocMissingDataSet.insert(::make_pair((string)pcDocumentMissingDataSet,(string)pcRevId));

								
								Custom_free(pcItemId);
								Custom_free(pcRevId);
								Custom_free(pcDocumentType);
							}

							// Docs missing ITAR/Datasets....
						   if(!mapDocMissingDataSet.empty()){
						      for ( map<string, string>::iterator it = mapDocMissingDataSet.begin( ); it != mapDocMissingDataSet.end( ); it++ ){
									 TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC,it->first.c_str(),it->second.c_str()), TD_LOG_ERROR_AND_THROW);
							  }
						      iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
						   }

						}	
						Custom_free(tDocDataset);
						Custom_free(pcItemId);
						Custom_free(pcPartType);
					}
					Custom_free(tParts);
					Custom_free(pcEcnType);
					}
					// ECN is release ecn and ECN type is inactive
					else if (tc_strcmp(pcEcnType, "Inactive Release") == 0)
					{
						if (iDocMissingDataSet == 0) {
							iStatus == ITK_ok;
						}
					}
				}
				Custom_free(pcECNId);
				Custom_free(pcAttachType);
			}

			if(iDocMissingDataSet > 0){
			   iStatus=iDocMissingDataSet;
		       throw iDocMissingDataSet;
		    }

			Custom_free(tAttaches);
		}							
	} 
	catch(...) 
	{
		POM_AM__set_application_bypass(false);
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tChildLine);
	Custom_free(tDocDataset);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_find_relation
 * Description				: Will find the ralation tag
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tPrimary (I)   - Primary tag
 *							: tSecondary (I) - Secondary tag
 *							: strRelTypeName (I) - Ralation type name string
 *							: tRelation (O)		 - Ralation tag
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_find_relation(tag_t tPrimary, tag_t tSecondary, string strRelTypeName, tag_t* tRelation) {

	int iStatus					= ITK_ok;
	tag_t tRelType				= NULLTAG;

	const char * __function__ = "teradyne_find_relation";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(strRelTypeName.c_str(), &tRelType), TD_LOG_ERROR_AND_THROW);
		if(tRelType != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimary, tSecondary, tRelType, tRelation), TD_LOG_ERROR_AND_THROW);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_check_designdocument
 * Description				: Checking whether the Design document has dataset or Itar form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObjectTag (I)   - Object Tag
 *							: tEcnTag (I)      - ECN Object Tag
 *							: bisDesignDocExist (O) - Returns true or false
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_check_designdocument(tag_t tObjectTag,tag_t tEcnTag,bool &bisDesignDocExist,std::map<string,string> &mapDocMissingDataSet) 
{

	int iStatus					= ITK_ok,
		iDocDataset				= 0,
		iDesignDoc				= 0,
		iDesignErr				= 0,
		iItarFrmCnt				= 0,
		iDesigndocCnt			= 0;

	char *pcDesignDoc           = NULL;

	tag_t  *tItarFrmTag         = {NULLTAG},
		   *tDocDataset         = {NULLTAG},
		   *tDesignDoc          = {NULLTAG};

	const char * __function__ = "teradyne_check_designdocument";
	TERADYNE_TRACE_ENTER();

	try {
		  if(!mapDocMissingDataSet.empty()){
			  mapDocMissingDataSet.clear();
		  }
		
			//Checks the part have design document 
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tObjectTag, TD_IMAN_SPEC_REL_NAME, &iDesignDoc, &tDesignDoc), TD_LOG_ERROR_AND_THROW);
			for(int n = 0; n < iDesignDoc; n++) 
			{
				bool bisItarFrmExist = false;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tDesignDoc[n], &pcDesignDoc), TD_LOG_ERROR_AND_THROW);
				if(tc_strcmp(pcDesignDoc, TD_DESIGN_DOC_REV_TYPE) == 0) {
					char *pcAttachType=NULL;
					iDesigndocCnt++;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tEcnTag, &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE)) 
					{
						tag_t tRelStatusTag = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tDesignDoc[n],&tRelStatusTag), TD_LOG_ERROR_AND_THROW);
						if(tRelStatusTag == NULLTAG)
						{
							tag_t SolRel=NULLTAG,PCBRel=NULLTAG;
							TERADYNE_TRACE_CALL(iStatus = teradyne_find_relation(tEcnTag, tDesignDoc[n], TD_SOLUTION_ITEMS_REL_NAME, &SolRel), TD_LOG_ERROR_AND_THROW);	
							TERADYNE_TRACE_CALL(iStatus = teradyne_find_relation(tEcnTag, tDesignDoc[n], TD_PCBA_DESIGN_DOC_REL_NAME, &PCBRel), TD_LOG_ERROR_AND_THROW);	
							if((SolRel == NULLTAG) && (PCBRel == NULLTAG)) 
							{
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_DESIGNDOC_REL_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_DESIGNDOC_REL_ERROR;
								throw iStatus;
							}
						}
						Custom_free(pcAttachType);

					}
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tDesignDoc[n],TD_ITAR_REL, &iItarFrmCnt, &tItarFrmTag), TD_LOG_ERROR_AND_THROW);
					if(iItarFrmCnt > 0)  
					{
						for(int iITarCnt = 0;iITarCnt < iItarFrmCnt;iITarCnt++)
						{
							char *pcItarFrm = NULL;
							//Bypassing to read Itar Form Object type
							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItarFrmTag[iITarCnt], &pcItarFrm), TD_LOG_ERROR_AND_THROW);
							POM_AM__set_application_bypass(false);
							if(tc_strcmp(pcItarFrm, TD_ITAR_FORM_TYPE) == 0)
							{
								iDesignErr++;
								bisItarFrmExist = true;
								break;
							}
							Custom_free(pcItarFrm);
						}
						Custom_free(tItarFrmTag);
					}
					if (!bisItarFrmExist)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tDesignDoc[n],TD_REF_MATERIAL_REL, &iDocDataset, &tDocDataset), TD_LOG_ERROR_AND_THROW);
						if(iDocDataset > 0)
						{
							iDesignErr++;
							Custom_free(tDocDataset);
						}
					}
												
				if(!bisItarFrmExist && iDocDataset==0){
					string pcDocumentMissingDataSet="";
					char *pcItemId = NULL;
				    char *pcRevId  = NULL;
					char *pcDocumentType = NULL;
				    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDesignDoc[n], TD_ITEM_ID_ATTR, &pcItemId),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDesignDoc[n], TD_ITEM_REV_ID_ATTR, &pcRevId),TD_LOG_ERROR_AND_THROW);
				    TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDesignDoc[n], TD_DOCUMENT_TYPE_ATTR, &pcDocumentType),TD_LOG_ERROR_AND_THROW);
					
					pcDocumentMissingDataSet.append(pcItemId).append("_").append(pcDocumentType);
					mapDocMissingDataSet.insert(::make_pair((string)pcDocumentMissingDataSet,(string)pcRevId));

				}
			 }


				Custom_free(pcDesignDoc);
			}
			if(iDesignDoc>0)
			{
				bisDesignDocExist = true;
			}
			Custom_free(tDesignDoc);

			
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
