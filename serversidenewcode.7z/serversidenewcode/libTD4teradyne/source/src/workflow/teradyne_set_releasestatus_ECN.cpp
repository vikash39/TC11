/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_set_releasestatus_ECN.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SetReleaseStatus action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Mar-2015						Kameshwaran D						Intital creation
#  29-Apr-2015						Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_set_releasestatus_ECN
 * Description				: This function set the release status to all Part and documentation of object
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_set_releasestatus_ECN(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iCount					= 0;

	tag_t *tAttaches			= NULL,
		  *tObjects				= NULL;
	char *pcAttachType			= NULL;

	const char * __function__ = "teradyne_set_releasestatus_ECN";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) {

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE)) {
				
					//Getting the all the items from the solution folder to add Release status to it.
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					if(iCount > 0) { 
						//relasing the design documets associated with solution
						TERADYNE_TRACE_CALL(iStatus = teradyne_add_release_status_to_objects(iCount, tObjects), TD_LOG_ERROR_AND_THROW);
					}
				}
				Custom_free(pcAttachType);
				Custom_free(tObjects);
			}
		}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}