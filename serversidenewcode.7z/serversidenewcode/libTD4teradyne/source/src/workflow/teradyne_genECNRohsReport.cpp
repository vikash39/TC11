/*=================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_genECNRohsReport.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-GenerateECNRohsReport action handler,
#								   which is used to create ECN Rohs report.
#      Project         :           libTD4teradyne
#      Author          :           Gurunathan
#  =================================================================================================
#  Date                              Name                               Description of Change
#  26-July-2021                      Gurunathan                    	Added function definitions teradyne_genECNRohsReport
#  $HISTORY$
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


typedef map<string, string> MapProcessHistory;

struct ProcessHistoryComparator {
	bool operator()(MapProcessHistory processOne, MapProcessHistory processTwo) {
		return (processOne.find(TD_ECN_PROCESS_END_DATE_VAL)->second < processTwo.find(TD_ECN_PROCESS_END_DATE_VAL)->second);
	}
};


string cHtMLFileContentRohs = "";
/*******************************************************************************
 * Function Name			: teradyne_genECNRohsReport
 * Description				: This function will populates the action handler
 *							  Teradyne-Generate-RohsReport
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to workflow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_genECNRohsReport(EPM_action_message_t msg)
{
	int iStatus = ITK_ok;
	int	iSolObjCount = 0;
	int	iAttachCount = 0;

	tag_t *ptAttaches = NULL;
	tag_t tSecObjs = NULLTAG;
	tag_t *tSolObjFoundTag = NULL;

	char *pcTypeName = NULL;
	char *pcECNClosureStsValue = NULL;

	string szECNName = "";
	string strRohsReportAttr[] = { TD_DIFFITEM_PART,TD_IMPSOL_REV, TD_IMPSOL_DESC, TD_IMPSOL_TYPE };

	string strImpandSolItmColVal[] = { TD_ITEM_ID_ATTR,TD_OBJECT_DESC_ATTR,TD_OBJECT_TYPE_ATTR,TD_ITEM_REV_ID_ATTR, TD_PART_REV_STAMP, TD_PART_MIN_SHIPPABLE_REV };
	string strECNAttr[] = { TD_ITEM_ID_ATTR,TD_OBJECT_TYPE_ATTR,TD_ECN_OWN_USER,TD_START_DATE,TD_CLOSURE_DATE_ATTR,TD_ECN_SYNOP,TD_ECN_PRIMARY_PRJ,TD_ECN_DESC };

	std::map<string, string> strECNPropNameValueMap;

	vector<string> resPropValVec;
	vector<string> resImpValVec;
	vector<string> resSolValVec;
	vector<string> resECNDocValVec;
	vector<string> resECNProcessVec;
	vector<string> resECNEffVec;

	const char * __function__ = "teradyne_genECNRohsReport";
	TERADYNE_TRACE_ENTER();

	try {
		if (msg.task != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
			for (int i = 0; i < iAttachCount; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);

				//request will be processed for the below specified item revisions
				if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)))
				{

					std::list<string> strAttrList(strECNAttr, strECNAttr + sizeof(strECNAttr) / sizeof(string));

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[i], strAttrList, strECNPropNameValueMap), TD_LOG_ERROR_AND_THROW);
					setgNULLPropertyExecution(false);
					if (strECNPropNameValueMap.size() > 0)
					{
						szECNName.assign(strECNPropNameValueMap.find(TD_ITEM_ID_ATTR)->second);
					}

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i], TD_ECN_CLOSURE_STATUS_ATTR, &pcECNClosureStsValue), TD_LOG_ERROR_AND_THROW);

					std::list<string> strECNRelationAttrList(strImpandSolItmColVal, strImpandSolItmColVal + sizeof(strImpandSolItmColVal) / sizeof(string));

					if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0)))


						//calling functions to get list of Solution Items
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrCount(ptAttaches[i], TD_ECR_SOLREL_NAME, &iSolObjCount, &tSolObjFoundTag), TD_LOG_ERROR_AND_THROW);

					//functions to create and write content in Excel file.
					TERADYNE_TRACE_CALL(iStatus = teradyne_write_excelfile_Rohs(ptAttaches[i], (char *)szECNName.c_str(), iSolObjCount, tSolObjFoundTag, pcECNClosureStsValue), TD_LOG_ERROR_AND_THROW);


					Custom_free(tSolObjFoundTag);
					Custom_free(pcTypeName);
					Custom_free(pcECNClosureStsValue);
				}
				szECNName.clear();
				strECNPropNameValueMap.clear();
				resPropValVec.clear();
				resImpValVec.clear();
				resSolValVec.clear();
				resECNProcessVec.clear();
				resECNEffVec.clear();
			}
			Custom_free(ptAttaches);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_write_excelfile_Rohs
* Description		: Fetch data from BOM and write it in Excel
*                     
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tTargetObject  (I)               - objecttag
*                      pcECNID (I) 						- char
						iSolObjCount(I)					- int
						tSolObjFoundTag(I)  			- tag
						pcECNClosureStsValue(I)         - char
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
*
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_write_excelfile_Rohs(tag_t tTargetObject, char *pcECNID, int iSolObjCount, tag_t *tSolObjFoundTag, char *pcECNClosureStsValue)
{
	int iStatus = ITK_ok;
	int iAttrCnt = 0;
	int iTypesize = 0;

	char *cHtLFilePath = NULL;
	char *pcECNProcess = NULL;
	char *pcSolItemid = NULL;
	char *pcDatasetID = NULL;
	char *pcECNReportFileLoc = NULL;
	char *pcTypeName = NULL;

	string strCurTimeStamp = "";
	string pcChangeID = "";
	string pcObjectID = "";
	string strOutXlsxPath = "";

	FILE *fHtMLFile = NULL;

	string strImpandSolItmColName[] = { TD_IMPSOL_NAME,TD_IMPSOL_DESC,TD_IMPSOL_ROHS_STATUS };
	string strImpandSolItmColNameWidth[] = { TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1 };

	string strBOMChangesColAttr[] = { " ",TD_DIFFITEM_PART, TD_IMPSOL_DESC, TD_IMPSOL_ROHS_STATUS };
	string strChangesColAttrWidth[] = { TD_DIFFITEM_RESULT_WIDTH,TD_DIFFITEM_NAME_WIDTH,TD_DIFFITEM_SEQNO_WIDTH,TD_DIFFITEM_DESC_WIDTH };

	string strConvrtXlsCmd = "";


	tag_t tSolitemtag = NULLTAG;
	bool bNoticeFlag = "true";
	date_t curdate;

	vector<string> resBLDiffValue, resImpValVec;



	char* __function__ = "teradyne_write_excelfile_Rohs";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetObject, &pcTypeName), TD_LOG_ERROR_AND_THROW);

		// MEM allocation of File
		cHtLFilePath = (char*)MEM_alloc(FILE_LEN * sizeof(char));
		pcObjectID.assign(TD_ECN_ROHS_TITLE_VAL); pcObjectID.append(": "); pcObjectID.append(pcECNID);
		//getting current date and time
		TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curdate), TD_LOG_ERROR_AND_THROW);

		//Frame Html file content
		cHtMLFileContentRohs.assign("<HTML xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\">\n<HEAD>\n</HEAD>\n<BODY><CENTER><FONT></FONT></CENTER><BR>");
		std::list<string> strImpandSolItmRAttrList(strImpandSolItmColName, strImpandSolItmColName + sizeof(strImpandSolItmColName) / sizeof(string));
		std::list<string> strImpandSolItmColWidthList(strImpandSolItmColNameWidth, strImpandSolItmColNameWidth + sizeof(strImpandSolItmColNameWidth) / sizeof(string));
		if (!resImpValVec.empty())
			resImpValVec.clear();

		//updating Main Block in file
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock_Rohs((char*)pcObjectID.c_str(), TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_Rohs("", false), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs(TD_ECN_TITLE, TD_ECN_ROHS_TITLE_VAL, TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs(TD_ECN_REPORT_TITLE, (char*)strCurTimeStamp.c_str(), TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_Rohs(false), TD_LOG_ERROR_AND_THROW);


		if (iSolObjCount > 0)
		{
			std::list<string> strchangesColAttrList(strBOMChangesColAttr, strBOMChangesColAttr + sizeof(strBOMChangesColAttr) / sizeof(string));
			std::list<string> strchangesColWidthList(strChangesColAttrWidth, strChangesColAttrWidth + sizeof(strChangesColAttrWidth) / sizeof(string));


			for (int jCnt = 0; jCnt < iSolObjCount; jCnt++)
			{
				//getting item tag and id of Solution Item
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolObjFoundTag[jCnt], &tSolitemtag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2(tSolitemtag, &pcSolItemid), TD_LOG_ERROR_AND_THROW);

				char *pcSolitemTypeName = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSolObjFoundTag[jCnt], &pcSolitemTypeName), TD_LOG_ERROR_AND_THROW);

				if (!pcChangeID.empty())
					pcChangeID.clear();
				if (tc_strcmp(pcSolitemTypeName, TD_DIV_PART_REV) == 0)
				{


					pcChangeID.assign(TD_ADDITEM_HEADER_1);

					pcChangeID.append(pcSolItemid);

					//getting Solution Item BOM Info

					iStatus = teradyne_list_soln_child_Rohs(tSolObjFoundTag[jCnt], resBLDiffValue, pcChangeID);

					if (iStatus == 1)
					{
						iStatus = 0;
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_Rohs("", false), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs((char *)pcChangeID.c_str(), TD_NO_BOM_CHANGE_TEXT, TD_NO_BOM_CHANGE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_Rohs(false), TD_LOG_ERROR_AND_THROW);
					}
					if (resBLDiffValue.size() != 0)
					{


						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_Rohs("", false), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs((char *)pcChangeID.c_str(), "", TD_TABLE_HEADER, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs("", "", TD_TABLE_COL_HEADER_VALUE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_Rohs(false), TD_LOG_ERROR_AND_THROW);

					}
				}

				Custom_free(pcSolitemTypeName);
				Custom_free(pcSolItemid);

			}
		}

		//write html content in xls file,
		TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_ECN_REPORT_TEMP_DIR_PREF, TC_preference_site, 0, &pcECNReportFileLoc), TD_LOG_ERROR_AND_THROW);
		pcDatasetID = (char *)MEM_alloc((int)(tc_strlen(pcECNID) + 20) * sizeof(char));
		sprintf(pcDatasetID, "%s-%s", pcECNID, TD_ECN_ROHS_FILE_NAME);
		sprintf(cHtLFilePath, "%s\\%s-%s.%s", pcECNReportFileLoc, pcECNID, TD_ECN_ROHS_FILE_NAME, TD_ECN_REPORT_XLS_FILE_EXT);

		fHtMLFile = fopen(cHtLFilePath, "w");
		fprintf(fHtMLFile, "%s", cHtMLFileContentRohs.c_str());
		fprintf(fHtMLFile, "\n</HTML>");
		fclose(fHtMLFile);

		//converting the report to xlsx by using vb script
		if (tc_strlen(cHtLFilePath) > 0)
		{
			//Create and attach dataset under ECN Revision
			TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_create_dataset(cHtLFilePath, tTargetObject, pcDatasetID), TD_LOG_ERROR_AND_THROW);
			DeleteFileA(cHtLFilePath);
		}
		Custom_free(cHtLFilePath);
		Custom_free(pcECNProcess);
		Custom_free(pcDatasetID);
		Custom_free(pcECNReportFileLoc);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
* Function Name  	: teradyne_list_soln_child_Rohs
* Description		: Function used to get child lines from BOM
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tSolrevtag  (I)                  - objecttag
*                      resDiffVec (I)       			- Attribute value in Vector
					   pcChangeID (I) 						- string
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*

*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_list_soln_child_Rohs(tag_t  tSolrevtag, vector<string> &resDiffVec, string pcChangeID)
{
	int  iStatus = ITK_ok,
		ichildCount2 = 0;

	tag_t tWindow2 = NULLTAG,
		tSolitemtag = NULLTAG,
		tline2 = NULLTAG,
		tdesc = NULLTAG,
		*tchildLines2 = NULL;



	string strBomLineAttr[] = { TD_BL_ITEM_ID_ATTR, TD_BL_ITEMREV, TD_BL_OBJECT_TYPE };

	std::map<string, string> strBomLineValueMap;

	vector<string> resDiffVecs;

	char* __function__ = "teradyne_list_bvr_diffs_Rohs";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resDiffVec.empty())
			resDiffVec.clear();


		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolrevtag, &tSolitemtag), TD_LOG_ERROR_AND_THROW);

		//Create BOM windows and set their top lines

		TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow2), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow2, tSolitemtag, tSolrevtag, NULLTAG, &tline2), TD_LOG_ERROR_AND_THROW);

		//Ask Child lines of top lines
		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline2, &ichildCount2, &tchildLines2), TD_LOG_ERROR_AND_THROW);

		if (ichildCount2 <= 0)
		{
			string strBOMChangesColAttr[] = { " ",TD_DIFFITEM_PART, TD_IMPSOL_DESC, TD_IMPSOL_ROHS_STATUS };
			string strChangesColAttrWidth[] = { TD_DIFFITEM_RESULT_WIDTH,TD_DIFFITEM_NAME_WIDTH,TD_DIFFITEM_SEQNO_WIDTH,TD_DIFFITEM_DESC_WIDTH };
			std::list<string> strchangesColAttrList(strBOMChangesColAttr, strBOMChangesColAttr + sizeof(strBOMChangesColAttr) / sizeof(string));
			std::list<string> strchangesColWidthList(strChangesColAttrWidth, strChangesColAttrWidth + sizeof(strChangesColAttrWidth) / sizeof(string));

			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen_Rohs("", false), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair_Rohs((char *)pcChangeID.c_str(), TD_NO_BOM, TD_NO_BOM, strchangesColAttrList, strchangesColWidthList, resDiffVec), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose_Rohs(false), TD_LOG_ERROR_AND_THROW);
			return iStatus;
		}
		//Function to ask Child lines for child
		else {
			for (int ibcount = 0; ibcount < ichildCount2; ibcount++) {
				teradyne_TraverseBOM(tWindow2, tchildLines2[ibcount], resDiffVec);
			}


		}
		TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow2), TD_LOG_ERROR_AND_THROW);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	
	Custom_free(tchildLines2);
	

	return iStatus;
}


/*******************************************************************************
* Function Name  	: teradyne_TraverseBOM
* Description		: Function used to traverse BOM lines
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tchildrevtag  (I)             - objecttag
                       tWindow2(I)                   - tag
					   resDiffVec(I)                 - Attribute value in vector
					   
* RETURN VALUE		: int iStatus - Error Code or Success Code

*------------------------------------------------------------------------------*/


int teradyne_TraverseBOM(tag_t tWindow2, tag_t tchildrevtag, vector<string> &resDiffVec)
{
	int  iStatus = ITK_ok,
		isubchildcount = 0;


	tag_t tSolitemtag = NULLTAG,
		*tsubchild = NULLTAG;
	char  *pcLinesID = NULL;

	vector<string> itemIDVec;
	string strBomLineAttr[] = { TD_BL_ITEM_ID_ATTR, TD_BL_ITEMREV, TD_BL_OBJECT_TYPE };

	std::map<string, string> strBomLineValueMap;



	char* __function__ = "teradyne_TraverseBOM";
	TERADYNE_TRACE_ENTER();


	try
	{

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tchildrevtag, TD_BL_ITEM_ID_ATTR, &pcLinesID), TD_LOG_ERROR_AND_THROW);
		itemIDVec.push_back(pcLinesID);


		std::list<string> strBomLineAttrList(strBomLineAttr, strBomLineAttr + sizeof(strBomLineAttr) / sizeof(string));

		TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tchildrevtag, strBomLineAttrList, strBomLineValueMap), TD_LOG_ERROR_AND_THROW);

		char *pcDescription = NULL, *pcObjectType = NULL, *pcRohsStaus = NULL, *objType = NULL;
		tag_t tItemRev = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(tchildrevtag, &pcDescription), TD_LOG_ERROR_AND_THROW);


		if (strBomLineValueMap.size() > 0)
		{
			/*Warnings*/
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tchildrevtag, TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_ROHS_COMPLIANT_STATUS_ATTR, &pcRohsStaus), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0 || tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
			{

				resDiffVec.push_back(TD_DIFFITEM_ADD); //Action
				resDiffVec.push_back(strBomLineValueMap.find(TD_BL_ITEM_ID_ATTR)->second); //Part
				resDiffVec.push_back(pcDescription);//Description
				resDiffVec.push_back(pcRohsStaus);//RohsCompliantStatus


			}


			Custom_free(pcObjectType);
			Custom_free(pcRohsStaus);
			Custom_free(pcDescription);

		}

		//Ask Child lines for child

		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tchildrevtag, &isubchildcount, &tsubchild), TD_LOG_ERROR_AND_THROW);
		if (isubchildcount != 0)
		{
			for (int subchild = 0; subchild < isubchildcount; subchild++)
			{
				teradyne_TraverseBOM(tWindow2, tsubchild[subchild], resDiffVec);
			}

		}


		Custom_free(pcLinesID);
		Custom_free(tsubchild);


	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}





/*******************************************************************************
* Function Name  	: teradyne_update_htmlcontentPair_Rohs
* Description		: will update html table content with value
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  columname   (I)	   - Column
*					   columvalue	(I)	   - Property value vector
*					   cHtMLFileContentSafety  (I)    - Propery value array
*					   value  (I)    - Propery value array
*					   strColAttr  (I)    - Propery value array
*					   resValVec (I)	   - Response vector of property values
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_htmlcontentPair_Rohs(char *columname, char *columvalue, char* value, std::list<string> strColAttr, std::list<string> strColwidthAttr, std::vector<string> resValVec)
{
	//Declartion and Initialization of Local Variables
	int iColHeaderSize = 0;
	int iTypesize = 0;
	int iStart = 0;
	int iStatus = ITK_ok;

	string columvalue1;

	char* __function__ = "teradyne_update_htmlcontentPair_safety";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tc_strcmp(value, TD_TABLE_ROW_HEADER_VALUE) == 0)
		{
			cHtMLFileContentRohs.append("\n<TR>");
			cHtMLFileContentRohs.append("\n<TD bgcolor=#C0C0C0><B>");
			cHtMLFileContentRohs.append(columname); cHtMLFileContentRohs.append("<B></TD>");
			cHtMLFileContentRohs.append("\n<TD align=\"left\">");

			if (tc_strcasecmp(columvalue, TD_ECN_VALUE_FOR_TRUE) == 0)
				cHtMLFileContentRohs.append(TD_ECN_VALUE_FOR_TRUE);
			else if (tc_strcasecmp(columvalue, TD_BOOL_VALUE_FALSE) == 0)
				cHtMLFileContentRohs.append(TD_ECN_VALUE_FOR_FALSE);
			else
				cHtMLFileContentRohs.append(columvalue);

			cHtMLFileContentRohs.append("</TD>");
			cHtMLFileContentRohs.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_NO_BOM_CHANGE) == 0)
		{
			cHtMLFileContentRohs.append("\n<TR> \n<TH align=\"left\" COLSPAN=1 bgcolor=#C0C0C0><B>"); cHtMLFileContentRohs.append(columname); cHtMLFileContentRohs.append("<B></TH>");
			cHtMLFileContentRohs.append("\n</TR>");
			cHtMLFileContentRohs.append("\n<TR> \n<TD align=\"left\" nowrap>"); cHtMLFileContentRohs.append(columvalue); cHtMLFileContentRohs.append("</TD>");
			cHtMLFileContentRohs.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_HEADER) == 0)
		{
			cHtMLFileContentRohs.append("\n<TR>");
			cHtMLFileContentRohs.append("\n<TH align=\"left\" COLSPAN=4 bgcolor=#C0C0C0><B>"); cHtMLFileContentRohs.append(columname); cHtMLFileContentRohs.append("<B></TH>");
			cHtMLFileContentRohs.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_STATIC_TEXT) == 0)
		{
			cHtMLFileContentRohs.append("\n<TABLE border=\"2\" align=\"Top\" width=\"90%\">");
			cHtMLFileContentRohs.append("\n<TR>");
			cHtMLFileContentRohs.append("\n<TD COLSPAN=3 nowrap><B>"); cHtMLFileContentRohs.append(columvalue); cHtMLFileContentRohs.append("<B></TD>");
			cHtMLFileContentRohs.append("\n</TR>");
			cHtMLFileContentRohs.append("\n</TABLE>");
			if (tc_strcasecmp(columvalue, TD_ECN_REPORT_STEXT_BOMCHANGES) == 0)
				cHtMLFileContentRohs.append("\n<BR><BR>");
		}
		else if (tc_strcmp(value, TD_TABLE_NONE_VALUE) == 0)
		{
			cHtMLFileContentRohs.append("\n<H3>"); cHtMLFileContentRohs.append(columname); cHtMLFileContentRohs.append("<BR>"); cHtMLFileContentRohs.append(columvalue);  cHtMLFileContentRohs.append("</H3>");
		}

		else if (tc_strcmp(value, TD_NO_BOM) == 0)
		{
			cHtMLFileContentRohs.append("\n<TR> \n<TH align=\"left\" COLSPAN=1 bgcolor=#C0C0C0><B>"); cHtMLFileContentRohs.append(columname); cHtMLFileContentRohs.append("<B></TH>");
			cHtMLFileContentRohs.append("\n</TR>");
			cHtMLFileContentRohs.append("\n<TR> \n<TD align=\"left\" nowrap>"); cHtMLFileContentRohs.append(columvalue); cHtMLFileContentRohs.append("</TD>");
			cHtMLFileContentRohs.append("\n</TR>");
		}
		else
		{
			cHtMLFileContentRohs.append("\n<TR>");
			iColHeaderSize = (int)strColAttr.size();
			for (std::list<string>::iterator it = strColAttr.begin(), itwidth = strColwidthAttr.begin(); it != strColAttr.end(), itwidth != strColwidthAttr.end(); it++, itwidth++)
			{
				if (((string)*it).empty())
					continue;

				cHtMLFileContentRohs.append("\n<TH bgcolor=#C0C0C0 height=\"40%\" width=\"");
				cHtMLFileContentRohs.append(((string)*itwidth).c_str());
				cHtMLFileContentRohs.append("%\">");
				cHtMLFileContentRohs.append(((string)*it).c_str());
				cHtMLFileContentRohs.append("</TH>");
			}
			cHtMLFileContentRohs.append("\n</TR>");
			if (resValVec.size() > 0)
			{
				iTypesize = (int)resValVec.size();
				iStart = 0;
				for (int iAttrCnt = iStart; iAttrCnt < iTypesize; iAttrCnt++)
				{
					cHtMLFileContentRohs.append("\n<TR>");
					for (int iAttrCnt1 = 0; iAttrCnt1 < iColHeaderSize; iAttrCnt1++)
					{
						cHtMLFileContentRohs.append("\n<TD align=\"left\">");
						cHtMLFileContentRohs.append(resValVec[iStart].c_str()); cHtMLFileContentRohs.append("</TD>");
						iStart++;
					}
					iAttrCnt = iStart;
					cHtMLFileContentRohs.append("\n</TR>");
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_html_headingblock_Rohs
* Description		: Function used to create html heading block
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_headingblock_Rohs(char* HeadingValue, int iHeadingType)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_headingblock_safety";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (iHeadingType == 3)
		{
			cHtMLFileContentRohs.append("\n<H3>");
			cHtMLFileContentRohs.append(HeadingValue);
			//cHtMLFileContentSafety.append("</H3>"); 
		}
		else
		{
			cHtMLFileContentRohs.append("\n<H2>");
			cHtMLFileContentRohs.append(HeadingValue);
			cHtMLFileContentRohs.append("</H2>");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagopen_Rohs
* Description		: Function used to open the table tag of html
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagopen_Rohs(char* HeadingValue, bool bAddHeader)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_tabletagopen_safety";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (bAddHeader)
		{
			cHtMLFileContentRohs.append("\n<H3>");
			cHtMLFileContentRohs.append(HeadingValue);
			cHtMLFileContentRohs.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
		else
		{
			cHtMLFileContentRohs.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagclose_Rohs
* Description		: Function used to close the table tag of html
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagclose_Rohs(bool bAddHeaderclose)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_tabletagclose";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!bAddHeaderclose)
		{
			cHtMLFileContentRohs.append("\n</TABLE>\n<BR>\n<BR>\n<BR>");
		}
		else
		{
			cHtMLFileContentRohs.append("\n</H3></TABLE>\n<BR>\n<BR>\n<BR>");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}

