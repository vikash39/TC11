/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_findLatestResult.cpp       
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-FindLatestResult action handler
#      Project         :           libTD4teradyne          
#      Author          :           Selvi        
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  27-Apr-2015						 Selvi       						Intital creation
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/***************************************************************************************************
 * Function Name			: teradyne_findLatestResult
 * Description				: This function to find the Latest SubstanceCompilanceResult
 *								and attach under Reference folder of EPM Process
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tVendorTag (Tag)			 -  vendor part tag
 *							 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. To all Vendor part attribute value
 * NOTES					: 
 ******************************************************************************************************/
int teradyne_findLatestResult (EPM_action_message_t msg)
{
	int iStatus				= ITK_ok;
	int	iAttachCount		= 0;
	int iObjCount			= 0;
	int iAttachmentType		= EPM_reference_attachment;
	
	char *pcTypeName		= NULL;
	char *pcSubCmplResult	= NULL;

	tag_t *ptAttaches		= NULL;
	tag_t *tWSOtags			= NULL;
	tag_t tRootTask			= NULLTAG;
	tag_t tRelationTag		= NULLTAG;
	tag_t *tObjFoundTag		= NULLTAG;

	string strVPAttrList[] = {TD_SUBCMPL_LATEST_RESULT};
	std::map<string,string> strVPAttrValueMap;

	const char * __function__		   = "teradyne_findLatestResult";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttachCount; i++) 
		{			
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(pcTypeName != NULL && (tc_strcmp(pcTypeName, TD_MFG_PART) == 0))
			{
			    //Reading LatestResult Attribute of VendorPart.
				std::list<string> strAttrList( strVPAttrList, strVPAttrList + sizeof(strVPAttrList) / sizeof(string) );														
				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[i],strAttrList,strVPAttrValueMap),TD_LOG_ERROR_AND_THROW);
								
				if (tc_strlen(strVPAttrValueMap.find(TD_SUBCMPL_LATEST_RESULT)->second.c_str()) <= 0) 
				{	Custom_free(pcTypeName);continue;}

				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PART_SUBCMPL_RESULT_REL,&tRelationTag),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches[i],tRelationTag,&iObjCount,&tObjFoundTag),TD_LOG_ERROR_AND_THROW);
				
				//Searching for SubstanceCompilanceResult object.
				for( int i=0; i<iObjCount; i++ )			
				{	
					//Reading LatestResult.
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i],TD_OBJECT_STRING,&pcSubCmplResult),TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcSubCmplResult, strVPAttrValueMap.find(TD_SUBCMPL_LATEST_RESULT)->second.c_str()) == 0)
					{			
						//Add SubstanceCompilanceResult objects under Reference Folder of EPM Task.	
						tag_t *tResult = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
						tResult[0] = tObjFoundTag[i];
					
						TERADYNE_TRACE_CALL(iStatus = EPM_add_attachments(tRootTask, 1, tResult, &iAttachmentType), TD_LOG_ERROR_AND_THROW);
						Custom_free(tResult);
					}
					Custom_free(pcSubCmplResult);
				}
				Custom_free(tObjFoundTag);
				Custom_free(tWSOtags);
			}
			Custom_free(pcTypeName);
		}
		Custom_free(ptAttaches);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}