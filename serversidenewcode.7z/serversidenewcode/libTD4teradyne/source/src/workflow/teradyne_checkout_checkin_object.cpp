/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_checkout_checkin_object        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CheckoutCheckinObject action handler
#      Project         :           libTD4teradyne          
#      Author          :                    
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_checkout_checkin_object
 * Description				: 
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_checkout_checkin_object(EPM_action_message_t msg) 
{
	int iStatus					= ITK_ok,
		iReferences             = 0,
		iItemCount        =0,
		iCount					= 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tObjects				= NULL;
	
	char *pcAttachType			= NULL,
		 *pcProjAttr			= NULL,
	     *pcItemStatus				= NULL;

	bool isItemStatusProtoType = false;

	const char * __function__ = "teradyne_checkout_checkin_object";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(msg.task != NULLTAG) 
		{ 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_PART_MOD_REQ_REV))
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_PART_TO_BE_MODIFIED_REL, &iItemCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					 for(int jj = 0; jj < iItemCount; jj++) 
					 {
						pcAttachType = "";
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjects[jj], &pcAttachType), TD_LOG_ERROR_AND_THROW);
						if(!tc_strcmp(pcAttachType, TD_DIV_PART_REV) || !tc_strcmp(pcAttachType, TD_COMM_PART_REV)) 
						{
							
								logical isCheckOut=false;
								POM_AM__set_application_bypass(true);
								//updating the change reason attribute with empty value
				                TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObjects[jj], TD_CHNG_RESN_ATTR, "Part Modify Request"), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = RES_is_checked_out(tObjects[jj],&isCheckOut), TD_LOG_ERROR_AND_THROW);
								if(isCheckOut)
								{
									TERADYNE_TRACE_CALL(iStatus = RES_checkin(tObjects[jj]), TD_LOG_ERROR_AND_THROW);
								} 
								else 
								{
									TERADYNE_TRACE_CALL(iStatus = RES_checkout2(tObjects[jj]," ",NULL,TD_TEMP_PATH, RES_EXCLUSIVE_RESERVE), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = RES_checkin(tObjects[jj]), TD_LOG_ERROR_AND_THROW);
								}
								POM_AM__set_application_bypass(false);
						
						
						}
					 }
				}
			}

			
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcItemStatus);
	Custom_free(pcProjAttr);
	Custom_free(pcAttachType);
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}