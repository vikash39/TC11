/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_standardECNvalidation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-StandardECNValidation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  12-Mar-2015                       Vijayasekhar                    	Initial Creation
#  13-Apr-2015                       Vijayasekhar                    	Added changes to through the error for the BOM doesnot have children and changed the handler name to Teradyne-StandardECNValidation
#  20-Apr-2015						 Haripriya						    Added DesignDoc to check ITAR Form.
#  22-Apr-2015						 Haripriya						    Removed NamedReference check for Dataset.
#  28-Apr-2015                       Vijayasekhar                    	Added errors for the failure cases
#  29-Apr-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  05-May-2015					     Vijayasekhar                    	Changed the definition teradyne_get_bomline_children and Added condition to skip the item status rule check for commercial parts in BOM structure
#																		Changed the error message to disply the part number
#  12-May-2015					     Vijayasekhar                    	Removed the definiion teradyne_get_itemrev_from_bomline
#  20-May-2015					     Haripriya                    	    Modified teradyne_get_bomline_children fn to set revision rule
#  22-May-2015					     Haripriya                    	    Modified the function to check Design Document has file or itar form even if dataset is there
#  04-Aug-2015					     Haripriya                    	    Modified the function to Perform ITAR Form validation in Revision.
#  07-Aug-2015					     Haripriya                    	    Modified teradyne_get_bomline_children fn to set revision rule as TER_LatestReleased.
#  18-Aug-2015					     Haripriya                    	    Modified the validation to work for DesignDocument Revision.
#  25-Aug-2015					     Haripriya                    	    validating ITARREL has ITAR Form
#  15-Sep-2015                       Haripriya                    	    Modified the fn to check the itemstatus for DivPartRevision alone.
#  14-Dec-2015						 Kameshwaran D						Added condition to restrict if all impacted items(DivPart) are not revised.
#  18-Jan-2016                       Manimaran                          Modified the code to skip the Impacted Items check for ProtoBOM ECN.
#  03-Mar-2016                       Haripriya                          Modified the code to check ItarForm Objecttype.
#  25-Mar-2016                       Haripriya                          Modified the code to check childlines object type because Divisional and commercial Part Revisions are allowed and designdocument has dataset
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_standardECNvalidation
 * Description				: This function will validates the Production status on BOM and its children
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the parts attached to the relation Solution Items
 *							  2. Will check the part is an assembly and status is 'Production'
 *							  3. If the part is not an assembly checks for the Dataset with named reference if not throws the error
 *							  4. If the part has the dataset checks for the design document with file associated if not throws the error
 * NOTES					: 
 ******************************************************************************/
int teradyne_standardECNvalidation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iCount					= 0,
		iSecCount				= 0,
		iBomCount				= 0,
		iChildCount				= 0,
		iDataset				= 0,
		iDesignDoc				= 0,
		iDocDataset				= 0,
		iItarFrmCnt             = 0;
	tag_t *tAttaches			= NULL,
		  *tSecObjects			= NULL,
		  *tBomViewRevs			= NULL,
		  *tChildLine			= NULL,
		  tItemRev				= NULLTAG,
		  *tDataSet				= NULL,
		  *tDesignDoc			= NULL,
		  *tDocDataset			= NULL,
		  *tItarFrmTag          = NULL,
		  tPrevRev				= NULLTAG;
	char *pcPropVal				= NULL,
		 *pcChildPropVal		= NULL,
		 *pcSecObjType			= NULL,
		 *pcDesignDoc			= NULL,
		 *pcItemId				= NULL,
		 *pcObjectType			= NULL,
		 *pcBomType				= NULL,
		 *pcECNId				= NULL,
		 *pcPCNClass			= NULL;
	bool bisDatasetExist		= false,
		 bisDesignDocExist		= false;
	std::map<string,string> mapDocMissingDataSet;
	int iDocMissingDataSet=0;
	const char * __function__ = "teradyne_standardECNvalidation";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			
			for(int i = 0; i < iCount; i++) { 

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE)) {
				
					//Gets the ECN number for the error messages reference
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i],TD_ITEM_ID_ATTR,&pcECNId), TD_LOG_ERROR_AND_THROW);
					//getting all the parts in 'Solution Items'
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);
					//Validate if new revision exists in solution item folder
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_if_new_revision_exists_in_solutionitemsfolder(tAttaches[i], tSecObjects, iSecCount, pcObjectType), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iSecCount; j++) {

						bisDatasetExist = false;
						bisDesignDocExist = false;
						if(pcPropVal != NULL) pcPropVal = NULL;
					
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tSecObjects[j], &pcItemId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &pcSecObjType), TD_LOG_ERROR_AND_THROW);
						if(tc_strcmp(pcSecObjType, TD_DIV_PART_REV) == 0) { //checking for Div part revision since solution items can also have Design Documents also
							//checking the part has item_status as Production
							TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcPropVal), TD_LOG_ERROR_AND_THROW);
							if(pcPropVal == NULL) {
								//Check for the attribute in previous revision
								if(tPrevRev != NULLTAG) tPrevRev = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tSecObjects[j], &tPrevRev),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcPropVal), TD_LOG_ERROR_AND_THROW);
							}
							if(pcPropVal != NULL && (!tc_strcmp(pcPropVal, "Production") || !tc_strcmp(pcPropVal, "Pre-Production"))) {
								
								TERADYNE_TRACE_CALL(iStatus = teradyne_check_designdocument(tSecObjects[j],tAttaches[i],bisDesignDocExist,mapDocMissingDataSet) , TD_LOG_ERROR_AND_THROW);
								//verifing the part is an assembly
								TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tSecObjects[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW); 
								if(iBomCount > 0) {
							
									for(int k = 0; k < iBomCount; k++) {
										//Gets the BOM line children
										tag_t tWindow = NULLTAG;
										TERADYNE_TRACE_CALL(iStatus = teradyne_get_bomline_children(tSecObjects[j], tBomViewRevs[k], &iChildCount, &tChildLine, &tWindow,pcPropVal), TD_LOG_ERROR_AND_THROW);
										if(iChildCount > 0)
										{
											if(tc_strcmp(pcPropVal, "Production") == 0)
											{	
					                        for(int l = 0; l < iChildCount; l++) {
										
												if(tItemRev != NULLTAG) { tItemRev = NULLTAG; }
												if(tPrevRev != NULLTAG) tPrevRev = NULLTAG;
												//checks the production status for each child line
												TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tChildLine[l], TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcBomType), TD_LOG_ERROR_AND_THROW);
												if(tc_strcmp(pcBomType, TD_DIV_PART_REV)==0)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tItemRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcChildPropVal), TD_LOG_ERROR_AND_THROW);
													if(pcChildPropVal == NULL) {

														TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tItemRev, &tPrevRev),TD_LOG_ERROR_AND_THROW);
														TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, TD_ITEM_STATUS_ATTR, &pcChildPropVal), TD_LOG_ERROR_AND_THROW);
													}
													if(tc_strcmp(pcChildPropVal, "Production") != 0) { 
												
													char *pcChildId = NULL;
													if(tWindow != NULLTAG) {
												
														TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);
													} 
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcChildId), TD_LOG_ERROR_AND_THROW);
													TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_BOM_PRODUCTION_ERROR, pcECNId, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW);
													iStatus = TD_BOM_PRODUCTION_ERROR;
													Custom_free(pcChildId);
													throw iStatus;
													}
													Custom_free(pcChildPropVal);
												}
												else if((tc_strcmp(pcBomType, TD_DIV_PART_REV)!=0) && (tc_strcmp(pcBomType, TD_COMM_PART_REV)!=0))
												{
													char *pcChildId = NULL;
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcChildId), TD_LOG_ERROR_AND_THROW);
													TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE_ERROR, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW);
													iStatus = TD_BOM_INVALID_CHILD_TYPE_ERROR;
													Custom_free(pcChildId);
													throw iStatus;
												}
												Custom_free(pcBomType);
											}
											if(tWindow != NULLTAG) {
												
												TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW);
											}
										 
											}
										} else {
											
											TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_CHILDREN_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
											iStatus = TD_BOM_CHILDREN_ERROR;
											throw iStatus;
										}
										Custom_free(tChildLine);
									}
								} 
									
								if(!bisDesignDocExist) { 
										//checks the part has dataset
										TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tSecObjects[j], TD_REF_MATERIAL_REL, &iDataset, &tDataSet), TD_LOG_ERROR_AND_THROW);
										if(iDataset > 0) {
											 bisDatasetExist = true;
											 Custom_free(tDataSet);
										}
									}
									
								if(!bisDatasetExist && !bisDesignDocExist && iBomCount == 0) {
										TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_DESIGNDOC_ERROR, pcECNId, pcItemId), TD_LOG_ERROR_AND_THROW);
										iStatus = TD_DATASET_DESIGNDOC_ERROR;
										throw iStatus;
									}		
									
							    // Docs missing ITAR/Datasets....
							    if(!mapDocMissingDataSet.empty()){
									for ( map<string, string>::iterator it = mapDocMissingDataSet.begin( ); it != mapDocMissingDataSet.end( ); it++ ){
										TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_DATASET_MISSING_FOR_DESIGN_DOC,it->first.c_str(),it->second.c_str()), TD_LOG_ERROR_AND_THROW);
								}
									iDocMissingDataSet = TD_DATASET_MISSING_FOR_DESIGN_DOC;
								}
						
							} else { // Production / PreProd Checking
						
								const char* err1 = "Production or Pre-Production";
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s3(EMH_severity_error, TD_ITEM_STATUS_ERROR, pcECNId, pcItemId, err1), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_ITEM_STATUS_ERROR;
								throw iStatus;
							}
						}
						
						
						Custom_free(pcSecObjType);
						Custom_free(tBomViewRevs);
						Custom_free(tDesignDoc);
						Custom_free(pcPropVal);
					}
				}
				Custom_free(tSecObjects);
				Custom_free(pcObjectType);
				Custom_free(pcECNId);
			}
			
			if(iDocMissingDataSet > 0){
			   iStatus=iDocMissingDataSet;
		       throw iDocMissingDataSet;
		}
			
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	
	Custom_free(tAttaches);
	Custom_free(tSecObjects);
	Custom_free(pcSecObjType);
	Custom_free(tBomViewRevs);
	Custom_free(tDesignDoc);
	Custom_free(pcPropVal);
	Custom_free(pcItemId);
	Custom_free(tChildLine);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_associated_objects
 * Description				: Will get the list of objects in a part with specific relation
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject (I)          - Workflow task tag where the handler placed
 *							: strRelTypeName (I) - Relation name string
 *							: iObjCount (O)	     - Object count int
 *							: tObjects (OF)		 - List of objects tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_associated_objects(tag_t tObject, string strRelTypeName, int *iObjCount, tag_t **tObjects) {

	int iStatus					= ITK_ok;
	tag_t tRelType				= NULLTAG;

	const char * __function__ = "teradyne_get_associated_objects";
	TERADYNE_TRACE_ENTER();

	try {
		
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(strRelTypeName.c_str(), &tRelType), TD_LOG_ERROR_AND_THROW); 
		if(tRelType != NULLTAG) {
			
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tObject, tRelType, iObjCount, tObjects), TD_LOG_ERROR_AND_THROW);
		}
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_pri_sec_object_propvalue
 * Description				: Will get the attribute string value of the secondary or primary objects
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRefObj (I)        - Reference object tag_t
 *							: strRelName (I)     - Relation name string
 *							: strObjType (I)	 - Object type string
 *							: iIsPriOrSec (I)	 - primary or secondary objects to get int
 *							: strPropName (I)	 - Property name string
 *							: pcPropVal (OF)	 - Property value char**
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 1. Gets the primary of secondary objects related to the input tag
 *							: 2. Gets the string property value
 * NOTES					: 
 ******************************************************************************/
int teradyne_pri_sec_object_propvalue(tag_t tRefObj, string strRelName, string strObjType, int iIsPriOrSec, string strPropName, char** pcPropVal) {

	int iStatus					= ITK_ok;
	tag_t tChgAdmForm			= NULLTAG;

	const char * __function__ = "teradyne_pri_sec_object_propvalue";
	TERADYNE_TRACE_ENTER();

	try {
		//list the secondary or primary objects
		TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRefObj, strRelName, strObjType, iIsPriOrSec, &tChgAdmForm), TD_LOG_ERROR_AND_THROW);
		if(tChgAdmForm != NULLTAG) {
			//gets the property values
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tChgAdmForm, strPropName.c_str(), pcPropVal), TD_LOG_ERROR_AND_THROW);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_bomline_children
 * Description				: Will get the BOM line children
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tItemRev (I)       - Item revision tag_t
 *							: tBomViewRev (I)    - BOM view revision tag_t
 *							: iChildCount (O)	 - No of childern int*
 *							: tChildLine (OF)	 - List of children tag_t**
 *                          : strEcntype(I)      - ECN Type string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_bomline_children(tag_t tItemRev, tag_t tBomViewRev, int* iChildCount, tag_t** tChildLine, tag_t* tWindow,string strEcntype) {

	int iStatus					= ITK_ok;
	tag_t revruletag            = NULLTAG,
		  tTopLine				= NULLTAG;
	const char * __function__ = "teradyne_get_bomline_children";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = BOM_create_window(tWindow), TD_LOG_ERROR_AND_THROW);
		*iChildCount = 0;
		if(tWindow != NULLTAG) {
		    TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased",&revruletag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule (*tWindow,revruletag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(*tWindow, NULLTAG, tItemRev, tBomViewRev, &tTopLine), TD_LOG_ERROR_AND_THROW);
			if(tTopLine != NULLTAG) 
			{
				TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tTopLine, iChildCount, tChildLine), TD_LOG_ERROR_AND_THROW);
				if((strEcntype.length()>0) && ((strEcntype.compare("Production Release")!=0) && (strEcntype.compare("Production") != 0)))
				{
					char *pcItemId=NULL;
					
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRev, &pcItemId), TD_LOG_ERROR_AND_THROW);
				
					//Validating child objecttype
					for(int l = 0; l < *iChildCount; l++) 
					{
						tag_t tItemRevision=NULLTAG;
						char *pcBomType= NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tChildLine[0][l], TD_REV_TAG_ATTR, &tItemRevision), TD_LOG_ERROR_AND_THROW);
		
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRevision, &pcBomType), TD_LOG_ERROR_AND_THROW);
						if((tc_strcmp(pcBomType, TD_DIV_PART_REV)!=0) && (tc_strcmp(pcBomType, TD_COMM_PART_REV)!=0))
						{
							char *pcChildId = NULL;
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tItemRevision, &pcChildId), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE_ERROR, pcChildId, pcItemId), TD_LOG_ERROR_AND_THROW);
							iStatus = TD_BOM_INVALID_CHILD_TYPE_ERROR;
							Custom_free(pcChildId);
							throw iStatus;
						}
						Custom_free(pcBomType);
					}
					Custom_free(*tChildLine);
					Custom_free(pcItemId);
					if(tWindow != NULLTAG) {
									
						TERADYNE_TRACE_CALL(iStatus = BOM_close_window(*tWindow),TD_LOG_ERROR_AND_THROW);
					}
				}
			}
			if(iChildCount <= 0 && tWindow != NULLTAG) {
				
				TERADYNE_TRACE_CALL(iStatus = BOM_close_window(*tWindow),TD_LOG_ERROR_AND_THROW);
			}
			
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

