/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_effectivitypropagation.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-EffectivityPropagation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  10-Mar-2015                       Haripriya                    	    Initial Creation
#  15-Apr-2015                       Haripriya                    	    Modified the function to set effectivity even the part is component and for ECNRevision.
#  23-Apr-2015                       Haripriya                    	    Modified the function to set effectivity for the Impacted Item Folder.
#  24-Apr-2015                       Haripriya                    	    Modified the function not to set effectivity for the Impacted Item Folder.
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  15-Oct-2015                       Manimaran                          Modified the code to skip effectivity assignment for single parts if it has already effectivity date set.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_effectivitypropagation
 * Description				: This function will Assign Effectivity for the Assemblies.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Searches the DivpartRevision in Solution Items Folder
 *							  2. If DivpartRevision is Found ,checks whether the part is Assembly or not.
 *							  3. If the part is Assembly,Sets the Effectivity as in ECNRevision.
 *                            4. Searches the Previous Revision in Impacted Items Folder and if found sets the end 
 *                               date in effectivity.
 *                            5.If the part is Component,Sets the Effectivity as todays date.
 *                            6. Searches the Previous Revision in Impacted Items Folder and if found sets the end 
 *                               date in effectivity.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_effectivitypropagation(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iRefCount           = 0,
		iBomCount           = 0;

	tag_t *tAttachtag       = {NULLTAG},
	      *tRefListTag      = {NULLTAG},
		  *tBomViewRevs     = {NULLTAG},
		  tprevTag          = NULLTAG,
		  tECNStatusTag     = NULLTAG,
		  tImpRelStatusTag  = NULLTAG;
	char *pcAttachType		= NULL;
	char *pcRangeTxt        = NULL;

	const char * __function__    = "teradyne_effectivitypropagation" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)) {
				
					//Getting Parts from Solution Item Folder
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachtag[i], TD_SOLUTION_ITEMS_REL_NAME, &iRefCount, &tRefListTag), TD_LOG_ERROR_AND_THROW);
					//Getting Release Status and Effectivity of that Status
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tAttachtag[i],&tECNStatusTag), TD_LOG_ERROR_AND_THROW);
					if(tECNStatusTag != NULLTAG)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_effectivity_range( tECNStatusTag,&pcRangeTxt), TD_LOG_ERROR_AND_THROW);
						if(pcRangeTxt == NULL)
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tAttachtag[i],tECNStatusTag,"","",false), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_effectivity_range( tECNStatusTag,&pcRangeTxt), TD_LOG_ERROR_AND_THROW);
						}
						for(int j = 0; j < iRefCount; j++)
						{      
							tag_t  tRelStatusTag     = NULLTAG;
							char *pcPartEffRangeTxt  = NULL;
							//checking the part is Assembly or not
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tRefListTag[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW); 
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tRefListTag[j],&tRelStatusTag), TD_LOG_ERROR_AND_THROW);
							if(tRelStatusTag != NULLTAG)
							{
								if(iBomCount > 0)
								{	
    								//Setting Effectivity for Assembly Part
									TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tRefListTag[j],tRelStatusTag,pcRangeTxt,""), TD_LOG_ERROR_AND_THROW);
						
								}
								else
								{
									TERADYNE_TRACE_CALL(iStatus = teradyne_ask_effectivity_range( tRelStatusTag, &pcPartEffRangeTxt), TD_LOG_ERROR_AND_THROW);
									if (pcPartEffRangeTxt == NULL) {
										//Setting Effectivity for Component Part
										TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tRefListTag[j], tRelStatusTag,"",""), TD_LOG_ERROR_AND_THROW);
									}
						
								}	
							}
							Custom_free(tBomViewRevs);
							Custom_free(pcPartEffRangeTxt);
						}
						Custom_free(pcRangeTxt);
					}
					Custom_free(tRefListTag);
				}
				Custom_free(pcAttachType);
			}
			Custom_free(tAttachtag);
		
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_ask_effectivity_range
 * Description				: Gets the Effectivity date from the given status tag
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRelStatusTag   (I)	- tag_t
 *							  pcRangeTxt  (OF)      - char **
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_ask_effectivity_range( tag_t tRelStatusTag,char **pcRangeTxt)
{
	int iStatus					= ITK_ok,
		iEffCnt                 = 0;

	tag_t *tEffectivityTags     = {NULLTAG};

	const char * __function__ = "teradyne_ask_effectivity_range";
	TERADYNE_TRACE_ENTER();

	try 
	{
		TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tRelStatusTag, &iEffCnt, &tEffectivityTags), TD_LOG_ERROR_AND_THROW);
		if(iEffCnt > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_date_range(tRelStatusTag,tEffectivityTags[0],pcRangeTxt), TD_LOG_ERROR_AND_THROW);		
		}
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tEffectivityTags);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_effectivity_start_end_date
 * Description				: Gives the Start or End Date value in Effectivity range.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcdaterange   (I)	  - char *
 *							  szvalue  (I)        - string
 *                            szeffdate (O)       - string
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_effectivity_start_end_date( char *pcdaterange,string szvalue,string &szeffdate)
{
	int iStatus					= ITK_ok;

	const char * __function__ = "teradyne_effectivity_start_end_date";
	TERADYNE_TRACE_ENTER();

	try 
	{
		string szEffdaterange =pcdaterange;
			size_t n= szEffdaterange.find("to");
			if(n!=-1)
			{
				if(szvalue.compare("Start")==0)
				{
					szeffdate = szEffdaterange.substr(0,n-1);
				}
				else if(szvalue.compare("End")==0)
				{
					szeffdate = szEffdaterange.substr(n+3,szEffdaterange.length());
				}
			}
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
