/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_protobomecnsetrevstamp.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ProtoBOMECNSetRevStamp action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_protobomecnsetrevstamp.
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_protobomecnsetrevstamp
 * Description				: Will translate the effectivity date into TER format and populate it on Rev Stamp attribute on ProtoBOMECN and the Change Admin Form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:1. Will get all the parts in SolutionItems folder
 *							 2. Will get the Date range effectivity of release status Part revisions and translate the to Week number format.
 *							 3. For the Part Type of any item in solution items is HLA(instrument) or PCBA then will update Rev Stamp attribute on ECN and Change Admin Form
 * NOTES					: 
 ******************************************************************************/
int teradyne_protobomecnsetrevstamp(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL;
	char *pcObjectType			= NULL;

	const char * __function__ = "teradyne_protobomecnsetrevstamp";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_translate_and_set_effective_date(tAttaches[i]), TD_LOG_ERROR_AND_THROW);
				}
				Custom_free(pcObjectType);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}