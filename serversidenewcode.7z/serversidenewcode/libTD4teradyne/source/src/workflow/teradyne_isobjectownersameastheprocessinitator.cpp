/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_isobjectownersameastheprocessinitator.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-IsObjectOwnerSameAsTheProcessInitator rule handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_isobjectownersameastheprocessinitator.
#  15-Jun-2015                       Vijayasekhar                    	Added condition to pass the validation for the objects other than General Document.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_isobjectownersameastheprocessinitator
 * Description				: Validate Object Owner is same as WF initiator
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
EPM_decision_t teradyne_isobjectownersameastheprocessinitator(EPM_rule_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL,
		  tUser					= NULLTAG,
		  tOwningUser			= NULLTAG,
		tGroupMember			= NULLTAG,
		tRoleTag				= NULLTAG;
	char *pcDocType				= NULL,
		 *pcCurrUser			= NULL,
		*pcCurrRole				= NULL;


	EPM_decision_t epmDecision  = EPM_nogo;

	const char * __function__ = "teradyne_isobjectownersameastheprocessinitator";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttaches; i++) {

			if(tUser != NULLTAG) { tUser = NULLTAG; }
			if(tOwningUser != NULLTAG) { tOwningUser = NULLTAG; }
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcDocType), TD_LOG_ERROR_AND_THROW);
			if(!tc_strcmp(pcDocType, TD_GENERAL_DOC_REV_TYPE)) {
			
				TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcCurrUser, &tUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(tAttaches[i], &tOwningUser), TD_LOG_ERROR_AND_THROW);
				if(tOwningUser != NULLTAG && tOwningUser == tUser) {

					epmDecision = EPM_go;
				} else {
				
					epmDecision = EPM_nogo;
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_CURRUSER_OWNUSER_ERROR), TD_LOG_ERROR_AND_THROW);
					throw (EPM_decision_t)TD_CURRUSER_OWNUSER_ERROR;
				}
			}
			else if (tc_strcmp(pcDocType, TD_COMM_PART_REV) == 0 || tc_strcmp(pcDocType, TD_DIV_PART_REV) == 0) {

				TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcCurrUser, &tUser), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(tAttaches[i], &tOwningUser), TD_LOG_ERROR_AND_THROW);

				if (tOwningUser != NULLTAG && tOwningUser == tUser) {

					TERADYNE_TRACE_CALL(iStatus = SA_ask_current_groupmember(&tGroupMember), TD_LOG_ERROR_AND_THROW);

					if (tGroupMember != NULLTAG) {

						TERADYNE_TRACE_CALL(iStatus = SA_ask_groupmember_role(tGroupMember, &tRoleTag), TD_LOG_ERROR_AND_THROW);

						if (tRoleTag != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(tRoleTag, &pcCurrRole), TD_LOG_ERROR_AND_THROW);

							if (tc_strcmp(pcCurrRole, TD_CONSUMER_ROLE) == 0) {
								epmDecision = EPM_nogo;
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_CONSUMER_ROLE_ERROR), TD_LOG_ERROR_AND_THROW);
								throw (EPM_decision_t)TD_CONSUMER_ROLE_ERROR;
							}
							else {
								epmDecision = EPM_go;
							}
						}
						else {
							epmDecision = EPM_go;
						}
					}
					else {
						epmDecision = EPM_go;
					}
				}
				else {

					epmDecision = EPM_nogo;
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_CURRUSER_OWNUSER_ERROR), TD_LOG_ERROR_AND_THROW);
					throw (EPM_decision_t)TD_CURRUSER_OWNUSER_ERROR;
				}
				

			}
			else {
			
				epmDecision = EPM_go;
			}
			Custom_free(pcDocType);
			Custom_free(pcCurrUser);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return epmDecision;
}