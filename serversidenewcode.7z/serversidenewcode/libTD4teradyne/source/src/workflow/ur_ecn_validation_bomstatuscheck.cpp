#include <workflow/teradyne_handlers.h>


EPM_decision_t ur_ecn_validation_bomstatuscheck(EPM_rule_message_t msg)
{
	tag_t *t_SecObj = NULL, *attachments = NULL, root_task = NULL, *t_SecObj1 = NULL, t_rev = NULL, t_relation1 = NULL;
	tag_t *t_SecObj2 = NULL, t_item = NULLTAG, *t_bvr = NULLTAG, t_window = NULLTAG, revruletag = NULLTAG, t_TopBomLine = NULLTAG, *t_Childs = NULLTAG, attribute = NULLTAG;
	char *t_ObjType = NULL, *c_objValue2 = NULL, *bomType = NULL, *c_objValue3 = NULL, *c_objValue1 = NULL, *c_objValue4 = NULL, *c_objValue5 = NULL;
	tag_t t_bom = NULLTAG, tagObjType = NULLTAG, t_relation2 = NULLTAG, *t_SecObj3 = NULLTAG, t_item2 = NULLTAG, t_rev1 = NULLTAG;
	char *c_Pvalue1 = NULL, *c_Pvalue2 = NULL, *c_Pvalue3 = NULL, *c_Pvalue5 = NULL, *c_Pvalue7 = NULL, *c_objValue8 = NULL, *c_objValue9 = NULL, *c_objValue10 = NULL;
	char *c_objValue11 = NULL, *c_objValue12 = NULL, *c_objValue13 = NULL, *sec_obj_type = NULL, *ECN_OBJName = NULL;
	int iStatus, i = 0, count = 0, count1 = 0, j = 0, e = 0, count2 = 0, q = NULL, k = 0, propvalue = 0, b_count = 0, BomChildCount = 0, l = 0, y = 0, count3 = 0, b = 0, c = 0;
	EPM_decision_t decision;

	decision = EPM_go;
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &root_task), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(root_task, EPM_target_attachment, &count, &attachments), TD_LOG_ERROR_AND_THROW);
	for (i = 0; i < count; i++)
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &ECN_OBJName), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(attachments[i], &sec_obj_type), TD_LOG_ERROR_AND_THROW);
		if ((tc_strcmp(sec_obj_type, "TD4StandardECNRevision") == 0))
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation1, &count1, &t_SecObj1), TD_LOG_ERROR_AND_THROW);
			for (j = 0; j < count1; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[j], &t_ObjType), TD_LOG_ERROR_AND_THROW);

				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &c_objValue13), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "td4ItemStatus", &c_objValue2), TD_LOG_ERROR_AND_THROW);

					if (tc_strcmp(c_objValue2, "") != 0)
					{
						TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(t_SecObj1[j], &b_count, &t_bvr), TD_LOG_ERROR_AND_THROW);
						if (b_count > 0)
						{

							for (y = 0; y < b_count; y++)
							{
								TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window, revruletag), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window, NULLTAG, t_SecObj1[j], t_bvr[y], &t_TopBomLine), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(t_TopBomLine, &BomChildCount, &t_Childs), TD_LOG_ERROR_AND_THROW);
								if (BomChildCount > 0)
								{
									for (l = 0; l < BomChildCount; l++)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "object_string", &c_objValue12), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(t_Childs[l], "bl_revision", &t_bom), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_object_type(t_bom, &tagObjType), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_name2(tagObjType, &bomType), TD_LOG_ERROR_AND_THROW);
										if (tc_strcmp(bomType, "TD4CommPartRevision") == 0 || tc_strcmp(bomType, "TD4DivPartRevision") == 0)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "td4ItemStatus", &c_objValue3), TD_LOG_ERROR_AND_THROW);


											if ((tc_strcmp(c_objValue2, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Prototype") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_objValue2, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Pre-Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_objValue2, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_objValue2, "Pre-Production") == 0) && (tc_strcmp(c_objValue3, "Pre-Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_objValue2, "Pre-Production") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_objValue2, "Production") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
											{
												decision = EPM_go;
											}
											else
											{
												decision = EPM_nogo;
												TERADYNE_TRACE_CALL(EMH_store_error_s4(EMH_severity_error, TD_BOM_Status, c_objValue12, c_objValue3, c_objValue13, c_objValue2), TD_LOG_ERROR_AND_THROW);
												e++;
											}
										}
										else
										{
											decision = EPM_nogo;
											TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE, c_objValue12, c_objValue13), TD_LOG_ERROR_AND_THROW);
											e++;
										}
										Custom_free(c_objValue12);
									}
								}
								else
								{
									TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, ECN_OBJName, c_objValue13), TD_LOG_ERROR_AND_THROW);
									e++;
								}
								Custom_free(t_Childs);
							}
						}
						Custom_free(t_bvr);
					}
					else
					{
						//z = AOM_UIF_ask_value(t_rev1, "object_string", &c_objValue1);

						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasImpactedItem", &t_relation2), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation2, &count3, &t_SecObj3), TD_LOG_ERROR_AND_THROW);
						for (b = 0; b < count3; b++)
						{
							TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(t_SecObj3[b], &t_item2), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(t_item2, &t_rev1), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_rev1, "object_string", &c_objValue1), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &c_objValue4), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(c_objValue1, c_objValue4) == 0)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj3[b], "td4ItemStatus", &c_objValue5), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(t_SecObj1[j], &b_count, &t_bvr), TD_LOG_ERROR_AND_THROW);
								if (b_count > 0)
								{

									for (y = 0; y < b_count; y++)
									{
										TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window, revruletag), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window, NULLTAG, t_SecObj1[j], t_bvr[y], &t_TopBomLine), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(t_TopBomLine, &BomChildCount, &t_Childs), TD_LOG_ERROR_AND_THROW);
										if (BomChildCount > 0)
										{
											for (l = 0; l < BomChildCount; l++)
											{
												TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "object_string", &c_objValue11), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(t_Childs[l], "bl_revision", &t_bom), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_object_type(t_bom, &tagObjType), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_name2(tagObjType, &bomType), TD_LOG_ERROR_AND_THROW);
												if (tc_strcmp(bomType, "TD4CommPartRevision") == 0 || tc_strcmp(bomType, "TD4DivPartRevision") == 0)
												{
													TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "td4ItemStatus", &c_objValue3), TD_LOG_ERROR_AND_THROW);

												if ((tc_strcmp(c_objValue5, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Prototype") == 0))
												{
													decision = EPM_go;
												}
												else if ((tc_strcmp(c_objValue5, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Pre-Production") == 0))
												{
													decision = EPM_go;
												}
												else if ((tc_strcmp(c_objValue5, "Prototype") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
												{
													decision = EPM_go;
												}
												else if ((tc_strcmp(c_objValue5, "Pre-Production") == 0) && (tc_strcmp(c_objValue3, "Pre-Production") == 0))
												{
													decision = EPM_go;
												}
												else if ((tc_strcmp(c_objValue5, "Pre-Production") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
												{
													decision = EPM_go;
												}
												else if ((tc_strcmp(c_objValue5, "Production") == 0) && (tc_strcmp(c_objValue3, "Production") == 0))
												{
													decision = EPM_go;
												}
												else
												{
													decision = EPM_nogo;
													TERADYNE_TRACE_CALL(EMH_store_error_s4(EMH_severity_error, TD_BOM_Status, c_objValue11, c_objValue3, c_objValue4, c_objValue5), TD_LOG_ERROR_AND_THROW);
													e++;
												}
											}
											else
											{
												decision = EPM_nogo;
												TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE, c_objValue11, c_objValue4), TD_LOG_ERROR_AND_THROW);
												e++;
											}
											Custom_free(c_objValue11);

											}
										}
										else
										{
											TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, ECN_OBJName, c_objValue4), TD_LOG_ERROR_AND_THROW);
											e++;
										}
										Custom_free(t_Childs);
									}
								}
								c++;
								Custom_free(t_bvr);
							}
						}
						if (c == 0)
						{
							decision = EPM_nogo;
							TERADYNE_TRACE_CALL(EMH_store_error_s1(EMH_severity_error, TD_NO_OLD_REVISION, c_objValue4), TD_LOG_ERROR_AND_THROW);
							e++;
						}
						Custom_free(t_SecObj3);
					}
				}
			}
			Custom_free(t_SecObj1);
		}

		if ((tc_strcmp(sec_obj_type, "TD4ReleaseECNRevision") == 0))
		{

			TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "object_string", &c_objValue10), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type("CMHasSolutionItem", &t_relation1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(attachments[i], t_relation1, &count2, &t_SecObj1), TD_LOG_ERROR_AND_THROW);
			for (j = 0; j < count2; j++)
			{
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(t_SecObj1[j], &t_ObjType), TD_LOG_ERROR_AND_THROW);
				if ((tc_strcmp(t_ObjType, "TD4CommPartRevision") == 0) || (tc_strcmp(t_ObjType, "TD4DivPartRevision") == 0))
				{
					//z = AOM_UIF_ask_value(t_SecObj1[j], "td4ItemStatus", &c_Pvalue1);

					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4ECNType", &c_Pvalue2), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(attachments[i], "td4FastTrack", &c_Pvalue3), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "object_string", &c_Pvalue5), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_SecObj1[j], "td4ItemStatus", &c_Pvalue7), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(c_Pvalue3, "False") == 0)
					{
						TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(t_SecObj1[j], &b_count, &t_bvr), TD_LOG_ERROR_AND_THROW);
						if (b_count > 0)
						{

							for (y = 0; y < b_count; y++)
							{
								TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&t_window), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = CFM_find("TER_LatestReleased", &revruletag), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_config_rule(t_window, revruletag), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(t_window, NULLTAG, t_SecObj1[j], t_bvr[y], &t_TopBomLine), TD_LOG_ERROR_AND_THROW);

								TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_all_child_lines(t_TopBomLine, &BomChildCount, &t_Childs), TD_LOG_ERROR_AND_THROW);
								if (BomChildCount > 0)
								{
									for (l = 0; l < BomChildCount; l++)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "object_string", &c_objValue9), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(t_Childs[l], "bl_revision", &t_bom), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_object_type(t_bom, &tagObjType), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_name2(tagObjType, &bomType), TD_LOG_ERROR_AND_THROW);
										if (tc_strcmp(bomType, "TD4CommPartRevision") == 0 || tc_strcmp(bomType, "TD4DivPartRevision") == 0)
										{
											TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(t_Childs[l], "td4ItemStatus", &c_objValue8), TD_LOG_ERROR_AND_THROW);
											if ((tc_strcmp(c_Pvalue2, "Prototype Release") == 0) && (tc_strcmp(c_objValue8, "Prototype") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_Pvalue2, "Prototype Release") == 0) && (tc_strcmp(c_objValue8, "Pre-Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_Pvalue2, "Prototype Release") == 0) && (tc_strcmp(c_objValue8, "Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_Pvalue2, "PreProduction Release") == 0) && (tc_strcmp(c_objValue8, "Pre-Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_Pvalue2, "PreProduction Release") == 0) && (tc_strcmp(c_objValue8, "Production") == 0))
											{
												decision = EPM_go;
											}
											else if ((tc_strcmp(c_Pvalue2, "Production Release") == 0) && (tc_strcmp(c_objValue8, "Production") == 0))
											{
												decision = EPM_go;
											}
											else
											{
												decision = EPM_nogo;
												TERADYNE_TRACE_CALL(EMH_store_error_s4(EMH_severity_error, TD_Diff_Status3, c_objValue10, c_Pvalue5, c_objValue9, c_objValue8), TD_LOG_ERROR_AND_THROW);
												e++;
											}
										}
										else
										{
											//error bom has no div/com part
											decision = EPM_nogo;
											TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_INVALID_CHILD_TYPE, c_objValue9, c_Pvalue5), TD_LOG_ERROR_AND_THROW);
											e++;
										}
										Custom_free(c_objValue9);
										Custom_free(bomType);


									}
								}
								else
								{
									TERADYNE_TRACE_CALL(EMH_store_error_s2(EMH_severity_error, TD_BOM_Child_Missing, c_objValue10, c_Pvalue5), TD_LOG_ERROR_AND_THROW);
									e++;
								}
								Custom_free(t_Childs);
							}
						}
					}
					else
					{

						decision = EPM_go;
					}
					Custom_free(c_Pvalue2);
					Custom_free(c_Pvalue3);
					Custom_free(c_Pvalue5);
					Custom_free(c_Pvalue7);
				}

			}
			Custom_free(t_SecObj1);

			Custom_free(c_objValue10);
		}
	}
	Custom_free(sec_obj_type);
	Custom_free(ECN_OBJName);
	
	if (e > 0)
	{
		decision = EPM_nogo;
	}
	Custom_free(attachments);
	return decision;

}