/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_InitiateWorkflow.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Custom Request Objects
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  19-Feb-2015                       Haripriya                          Initial Creation
#  06-Mar-2015						 Kameshwaran D						Added function "teradyne_update_forms_of_createormodify_request" to update Model Forms value
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_InitiateWorkflow
* Description		: Postaction to initiate workflow process for DTGModlModReqRevision,
*                     PartModReqRevision,TAGModlCreReqRevision,TAGModlModReqRevision, CommercialPartRequestRevision
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and initiate workflow while creating 
*                     DTGModlModReqRevision,PartModReqRevision,TAGModlCreReqRevision,
*                     TAGModlModReqRevision,CommercialPartRequestRevision
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_CommPartReqRevisionAWC(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int  iStatus				= ITK_ok,
		 iCreateReqFlag			= 0;

	tag_t tNewProcess           = NULLTAG,
		  tItemtag              = NULLTAG,
		  tRevTag				= NULL;

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tParentTag = NULLTAG;


	bool bMapModelUpdate		= false;
	char *pcProcessTemplateName = NULL,
		 *pcWorkflowName        = NULL,
		 *pcCBU = NULL,
		 *pcObjectType          = NULL;
	const char*	pcRevid			= NULL;
	
	char  *pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL,
		*pcURVendor = NULL,
		*pcManufacturer = NULL;

	tag_t turVendor = NULLTAG;

	int icount = 0, ivalueCount = 0;

	const char* __function__ = "TD4_postaction_on_save_CommPartReqRevisionAWC";

	TERADYNE_TRACE_ENTER();


	try
	{
		tRevTag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		bool bIsConceptPart				= false;

		if( bisNew )
		{

			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcObjectType),TD_LOG_ERROR_AND_THROW);
			if (!tc_strcmp(pcObjectType,TD_COMM_PART_REQ_REV))
			{
				
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tRevTag, TD_IS_CONCEPT_PART, &bIsConceptPart), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

				// Validating Owning Group as UR or MIR (Universal Robots)
				int valResult = 1;
				if ((hasEnding(string(pcGroupFullName), ".UR") == true) || (hasEnding(string(pcGroupFullName), ".MIR") == true))
				{
					valResult = 0;
					TC_write_syslog("\n pcGroupFullName Inside Comm Part Request : %s", pcGroupFullName);
						TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tRevTag, TD_UR_VENDOR_ATTR, &pcURVendor), TD_LOG_ERROR_AND_THROW);
						TC_write_syslog("\n pcURVendor Value: %s", pcURVendor);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_MANUFACTURE_1_ATTR, &pcManufacturer), TD_LOG_ERROR_AND_THROW);
						TC_write_syslog("\n pcManufacturer Value: %s", pcManufacturer);
				}

				if (valResult == 0)
				{
					if ((strcmp(pcURVendor, "") == 0) && (strcmp(pcManufacturer, "") == 0))
					{
						TC_write_syslog("\n INside Error Dialog pcURVendor : %s", pcURVendor);
						TC_write_syslog("\n pcManufacturer : %s", pcManufacturer);
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_COMM_PART_REQ_URVENDOR_TDMANUFACTURER_ERROR, "", ""), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_COMM_PART_REQ_URVENDOR_TDMANUFACTURER_ERROR;
						throw iStatus;
					}
				}
				
				
				/*int urGrp = 1;
				urGrp = ur_validateOwningGroup();*/
				if (valResult == 0)
				{
					TC_write_syslog("\n It is belongs to UR or MIR Part  : ");
				}
				else
				{
					if (bIsConceptPart)
					{
						AM__set_application_bypass(true);
						tag_t	tObjTypeTag = NULLTAG, tObjRevTypeTag = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_find_type(TD_COMM_PART, TD_COMM_PART, &tObjTypeTag), TD_LOG_ERROR_AND_THROW);
						tag_t tCommPartCreateInput = NULL;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_construct_create_input(tObjTypeTag, &tCommPartCreateInput), TD_LOG_ERROR_AND_THROW);

						tag_t tCommPartTag = NULL;
						TERADYNE_TRACE_CALL(iStatus = TCTYPE_create_object(tCommPartCreateInput, &tCommPartTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartTag,TD_OBJECT_NAME_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus=AOM_save_with_extensions(tCommPartTag),TD_LOG_ERROR_AND_THROW);

					tag_t	tCommPartRevTag = NULL;
					TERADYNE_TRACE_CALL(iStatus=ITEM_ask_latest_rev(tCommPartTag,&tCommPartRevTag),TD_LOG_ERROR_AND_THROW);

					string szCreRequestPart_Attr[]	= {TD_PROJECT_NAME_ATTR,TD_REQUESTORS_DIV};
						
					std::list<string> strCreReqPartAttrList( szCreRequestPart_Attr, szCreRequestPart_Attr + sizeof(szCreRequestPart_Attr) / sizeof(string) );

					std::map<string,string> strPropNameValueMap;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevTag,strCreReqPartAttrList,strPropNameValueMap),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_DESCR_ATTR, "Concept Part"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_PROJECT_NAME_ATTR, strPropNameValueMap.find(TD_PROJECT_NAME_ATTR)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_CONTRL_BUSS_UNIT, strPropNameValueMap.find(TD_REQUESTORS_DIV)->second), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag,TD_ITEM_STATUS_ATTR,TD_PROTO_TYPE_ATTR),TD_LOG_ERROR_AND_THROW);

					tag_t  tReqResultsRelTag = NULLTAG; 
			
					TERADYNE_TRACE_CALL(iStatus=GRM_find_relation_type(TD_REQ_RESULTS_IN_PART_REL,&tReqResultsRelTag),TD_LOG_ERROR_AND_THROW);

						if (tReqResultsRelTag != NULLTAG)
						{
							TC_write_syslog("Inside tReqResultsRelTag If Condition");

							tag_t tNewRelation = NULLTAG;

						//Attach to Comm Part Request (Results In)
						TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(tRevTag,tCommPartTag,tReqResultsRelTag,NULLTAG,&tNewRelation),TD_LOG_ERROR_AND_THROW);

						if(tNewRelation != NULLTAG)
						{
							TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tNewRelation),TD_LOG_ERROR_AND_THROW);
						}
					}


					TERADYNE_TRACE_CALL(iStatus = teradyne_create_discipleSpecificForms(tCommPartRevTag), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tCommPartRevTag, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tCommPartRevTag, TD_CONTRL_BUSS_UNIT, pcCBU), TD_LOG_ERROR_AND_THROW);




					TERADYNE_TRACE_CALL(iStatus=ITEM_save_rev(tCommPartRevTag),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus=ITEM_save_item(tCommPartTag),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_ESI_ITEM_CREATE_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				    TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tCommPartRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);

					// -----------------     Submit created comm part revision  to workflow ---------------

					//Getting Preference Value to get Workflow template name
				
					TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_T4O_ITEM_PUSH_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				
					 // Calling function to Initiate T4O_Item_Push Workflow on commercial part revision
				     TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tCommPartRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);

						AM__set_application_bypass(false);


					}
				}

			}
			
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcObjectType);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
