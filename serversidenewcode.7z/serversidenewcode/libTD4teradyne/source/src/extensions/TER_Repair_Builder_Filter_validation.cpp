
#include <extensions/teradyne_extensions.h>
#include<iostream>
#include<common/teradyne_common.h>


int TER_Repair_Builder_Filter_validation(const char* pcName, int iNumArgs, char** pcEntriesNames, char** pcEntriesValues, int* iNumFound, tag_t** tFound)
{
	int     iStatus = ITK_ok;
	int     entry_count = 0;
	int     iNumItemRevFound = 0;
	int m1 = 0,
		d1 = 0,
		y1 = 0,
		m2 = 0,
		d2 = 0,
		y2 = 0,
		hr = 0,
		min = 0,
		sec = 0;
	tag_t   tQuery = NULLTAG;
	tag_t*  tRecv = NULL;

	string strCurTimeStamp = "";
	date_t curDate;
	string strStartDate("");
	string strEndDate("");

	const char* __function__ = "TER_Repair_Builder_Filter_validation";
	TERADYNE_TRACE_ENTER();




	try
	{

		if (tc_strcmp(pcName, "__TER_Repair_Closed_Report") == 0)
		{
			TC_write_syslog("\n Inside TER_Repair_Closed_Report");
			string strClosure("");
			string strRepairLocation("");
			string strMaturity("");
			string strHLAPartNumber("");
			string strDescription("");
			string strCustomerName("");
			string strCustomerNo("");
			string strDisposition("");


			for (int inx = 0; inx < iNumArgs; inx++)
			{
				TC_write_syslog("\n *********** ");
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Order Closed Date From") == 0))
					strStartDate.append(pcEntriesValues[inx]);

				if ((tc_strcmp(pcEntriesNames[inx], "Repair Order Closed Date To") == 0))
					strEndDate.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Closure") == 0))
					strClosure.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Location") == 0))
					strRepairLocation.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Maturity") == 0))
					strMaturity.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "HLA Part Number") == 0))
					strHLAPartNumber.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Description") == 0))
					strDescription.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Customer Name") == 0))
					strCustomerName.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Customer No") == 0))
					strCustomerNo.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Disposition") == 0))
					strDisposition.append(pcEntriesValues[inx]);
			}
		}

		else if (tc_strcmp(pcName, "TER_REPAIR_ORDER_REVISIONS") == 0)
		{
			TC_write_syslog("\n Inside TER_REPAIR_ORDER_REVISIONS");
			string strClosure("");
			string strRepairLocation("");
			string strMaturity("");
			string strRepairOrderID("");



			for (int inx = 0; inx < iNumArgs; inx++)
			{
				TC_write_syslog("\n *********** ");
				if ((tc_strcmp(pcEntriesNames[inx], "Closure") == 0))
					strClosure.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Location") == 0))
					strRepairLocation.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Maturity") == 0))
					strMaturity.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Order Closed Date From") == 0))
					strStartDate.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Order Closed Date To") == 0))
					strEndDate.append(pcEntriesValues[inx]);
				if ((tc_strcmp(pcEntriesNames[inx], "Repair Order ID") == 0))
					strRepairOrderID.append(pcEntriesValues[inx]);

			}
		}

		if (strStartDate.empty() == true)
		{
			iStatus = TD_DATE_INVALID_ERROR;
			throw iStatus;


		}


		else

		{

			iStatus = DATE_string_to_date(strStartDate.c_str(), "%d-%B-%Y %H:%M", &m1, &d1, &y1, &hr, &min, &sec);

			if (strEndDate.empty() != true)
			{
				iStatus = DATE_string_to_date(strEndDate.c_str(), "%d-%B-%Y %H:%M", &m2, &d2, &y2, &hr, &min, &sec);

			}
			else
			{

				teradyne_current_timestamp("%d-%B-%Y %H:%M", strCurTimeStamp, curDate);
				iStatus = DATE_string_to_date(strCurTimeStamp.c_str(), "%d-%B-%Y %H:%M", &m2, &d2, &y2, &hr, &min, &sec);
			}


			Date dt1 = { d1, m1 , y1 };
			Date dt2 = { d2, m2 , y2 };


			int diff = getDifference(dt1, dt2);
			if (diff > 7)
			{
				iStatus = TD_DATE_DIFF_INVALID_ERROR;
				throw iStatus;
			}
			else
			{
				int   entry_count = 0;
				char  **entries = NULL;
				char  **values = NULL;
				int   iCn = 0;
				*iNumFound = 0;
				*tFound = NULLTAG;


				for (int i = 0; i < iNumArgs; i++)
				{
					
					if (tc_strcmp(pcEntriesNames[i], "") != 0)
					{

						entry_count++;
						if (entries == NULL)
						{

							entries = (char **)MEM_alloc(entry_count * sizeof(char *));
							entries[entry_count - 1] = MEM_string_copy(pcEntriesNames[i]);
							values = (char **)MEM_alloc(entry_count * sizeof(char *));
							values[entry_count - 1] = MEM_string_copy(pcEntriesValues[i]);
						}
						else
						{

							entries = (char **)MEM_realloc(entries, sizeof(char *) * entry_count);
							entries[entry_count - 1] = MEM_string_copy(pcEntriesNames[i]);
							values = (char **)MEM_realloc(values, sizeof(char *) * entry_count);
							values[entry_count - 1] = MEM_string_copy(pcEntriesValues[i]);
						}
					}
				}
				if (tc_strcmp(pcName, "__TER_Repair_Closed_Report") == 0)
					TERADYNE_TRACE_CALL(iStatus = QRY_find2("TER_Repair_Closed_Report", &tQuery), TD_LOG_ERROR_AND_THROW);
				else if (tc_strcmp(pcName, "TER_REPAIR_ORDER_REVISIONS") == 0)
					TERADYNE_TRACE_CALL(iStatus = QRY_find2("TER_REPAIR_ORDER_REVISIONS_QRY", &tQuery), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = QRY_execute(tQuery, entry_count, entries, values, &iNumItemRevFound, &tRecv), TD_LOG_ERROR_AND_THROW);

				*iNumFound = iNumItemRevFound;
				*tFound = (tag_t*)MEM_alloc(iNumItemRevFound * sizeof(tag_t));
				for (int j = 0; j < iNumItemRevFound; j++)
				{

					(*tFound)[j] = tRecv[j];

				}
				if (tRecv != NULLTAG) MEM_free(tRecv);

			}
			
		}


	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	//TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}





