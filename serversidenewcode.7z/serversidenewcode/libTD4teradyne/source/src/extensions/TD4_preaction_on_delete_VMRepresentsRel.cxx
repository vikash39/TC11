//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension TD4_preaction_on_delete_VMRepresentsRel
 *
 */
#include <extensions/TD4_preaction_on_delete_VMRepresentsRel.hxx>
#include <teradyne_register_user_exit.h>
#include <extensions/getTd4Country_of_OriginBase.hxx>
int TD4_preaction_on_delete_VMRepresentsRel( METHOD_message_t * msg, va_list args )
{
	const char* __function__ = "TD4_preaction_on_delete_VMRepresentsRel";
	TERADYNE_TRACE_ENTER();

	int				iStatus					= ITK_ok;

	tag_t 			tSelectedObject			= msg->object_tag,
					tPrimaryObject			= NULLTAG,
					tSecondaryObject		= NULLTAG;

	char			*pcPrimaryTypeName		= NULL,
					*pcSecondaryTypeName	= NULL;


	TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tSelectedObject, &tPrimaryObject), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tSelectedObject, &tSecondaryObject), TD_LOG_ERROR_AND_THROW);
	if ((tPrimaryObject != NULLTAG) && (tSecondaryObject != NULLTAG))
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject, &pcPrimaryTypeName), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject, &pcSecondaryTypeName), TD_LOG_ERROR_AND_THROW);
		if ((tc_strcmp(pcPrimaryTypeName, TD_COMM_PART_REV) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_DIV_PART_REV) == 0)
			&& tc_strcmp(pcSecondaryTypeName, TD_MFG_PART) == 0)
		{
			ITK__convert_tag_to_uid(tPrimaryObject, &td4PrimaryObjUID);
		}
	}
	TC_write_syslog("%s: Unhandled Exception" , td4PrimaryObjUID);
 return 0;

}