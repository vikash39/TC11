/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_save_CommPartReqRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for pre action on IMAN_save in Commercial Part Request Revision
#                                  request revision
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  09-June-2018                      Rodji                               Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_precondition_on_save_CommPartReqRevision
* Description		: Postaction to create forms		  
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: 
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_precondition_on_save_CommPartReqRevision(METHOD_message_t*  msg, va_list args)
{
  
	int iStatus					= ITK_ok;

	const char* __function__ = "TD4_precondition_on_save_CommPartReqRevision";
	TERADYNE_TRACE_ENTER();

    TERADYNE_TRACE_LEAVE(iStatus);
    return iStatus;
}

