
#include <extensions/teradyne_extensions.h>

bool hasLeadingTrailingEmptySpace(char* text) 
{
	bool result = false;
	
	string vendorPartId(text);

	if(vendorPartId.front() == ' ') 
	{
		result = true;
	}
	return result;
}

extern "C"
int TD4_postaction_on_save_MfgPart(METHOD_message_t *msg , va_list args) {

	//Declartion and Initialization of Local Variables
	int   iStatus               = ITK_ok;

	
	char *vendorPartId			= NULL,
		 *vendorPartIdName		= NULL;

	char* __function__ = "TD4_postaction_on_save_MfgPart";
	TERADYNE_TRACE_ENTER();

	tag_t   tTag		              = NULLTAG;

	try
	{
		//Getting values from iman_save action
		tTag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);

		TCTYPE_save_operation_context_t saveOperationContext;
		
		if (bisNew)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_ChangeHistoryForms(tTag), TD_LOG_ERROR_AND_THROW);
		}

		TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&saveOperationContext),TD_LOG_ERROR_AND_THROW);
		if(saveOperationContext == TCTYPE_save_on_create || saveOperationContext == TCTYPE_save_on_update)
		{
			char *specialChar=NULL;

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTag, TD_ITEM_ID_ATTR, &vendorPartId),TD_LOG_ERROR_AND_THROW);

			if(hasInvalidChar(vendorPartId, &specialChar))
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_name(tTag,TD_ITEM_ID_ATTR,&vendorPartIdName), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_INVALID_CHAR, vendorPartIdName,specialChar), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_INVALID_CHAR;
				throw iStatus;
			}

			if(hasLeadingTrailingEmptySpace(vendorPartId))
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_VALIDATE_TEXT_SPACES, vendorPartId), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_VALIDATE_TEXT_SPACES;
				throw iStatus;
			}
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(vendorPartId);
	Custom_free(vendorPartIdName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_create_ChangeHistoryForms(tag_t tRevTag)
{
	int   iStatus = ITK_ok;

	string szFormName[] = { "Change History Form" },
		szFormType[] = { TD_CHANGEHISTORY_FORM_TYPE };

	std::map<string, string> strFormTypeNameMap;

	char* __function__ = "teradyne_create_ChangeHistoryForms";
	TERADYNE_TRACE_ENTER();

	try
	{
		int iTypesize = sizeof(szFormName) / sizeof(string);
		for (int iCount = 0; iCount < iTypesize; iCount++)
		{
			strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
		}
		// Calling function to create Forms under DisciplineSpecific & OracleOrg DIVPARTREVISION
		TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, false), TD_LOG_ERROR_AND_THROW);

	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}