/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_create_Relation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for Precondition on Relation
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D.          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  03-Aug-2016                       Kameshwaran D.                     Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_precondition_on_create_Relation
 * Description      : This function will be executed whenever TD4ProjectRel
 *                    happens on ECN between ECN revision
 *                    and project form
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I) - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 1.Gets the Primary and Secondary object type.
 *					  2.If the Primary Object type is ECN revision
 *                    and Secondary Object type is Project form , then check for 
 *                    Active seq.
 *                    3.If project form not an active sequence throw error.
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_precondition_on_create_Relation(METHOD_message_t*  msg, va_list args) 
{
	int		iStatus					= ITK_ok,
			ifound					= 0;

	char	*pcPrimaryTypeName    = NULL,
			*pcSecondaryTypeName  = NULL;

	tag_t	tObject               = NULLTAG,
			tPrimaryObject        = NULLTAG,
			tSecondaryObject      = NULLTAG;

	const char* __function__ = "TD4_precondition_on_create_Relation";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);
		bool bisNew	  = va_arg(args, logical);

		//Getting Primary and Secondary Object for the Relation
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject,&tPrimaryObject),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject,&tSecondaryObject),TD_LOG_ERROR_AND_THROW);
		if ( (tPrimaryObject != NULLTAG) && ( tSecondaryObject != NULLTAG ) )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject,&pcPrimaryTypeName),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject,&pcSecondaryTypeName),TD_LOG_ERROR_AND_THROW);
			// if the Primary type is TD4StandardECNRevision or TD4ReleaseECNRevision
			if( ((tc_strcmp(pcPrimaryTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_REL_ECN_REV_TYPE) == 0)) && ((tc_strcmp(pcSecondaryTypeName, TD_PROJECT_FORM_TYPE) == 0))){
				bool bExists = false;
				char *pcProjForm = NULL;
				tag_t tActSeqObjTag = NULLTAG;

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObject,TD_OBJECT_NAME_ATTR,&pcProjForm),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_check_form_with_name_already_exists(tSecondaryObject,pcProjForm,bExists,&tActSeqObjTag),TD_LOG_ERROR_AND_THROW);

				if(tSecondaryObject != tActSeqObjTag){
					iStatus = TD_NON_ACTIVE_SEQ_ATTACH_ERROR;
					Custom_free(pcPrimaryTypeName);
					Custom_free(pcSecondaryTypeName);
					Custom_free(pcProjForm);
					throw iStatus;
				}
				Custom_free(pcProjForm);
			}
		}
	} 
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}