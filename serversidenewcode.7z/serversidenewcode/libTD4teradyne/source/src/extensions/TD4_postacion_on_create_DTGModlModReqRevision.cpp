/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postacion_on_create_DTGModlModReqRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on ITEM_create_rev in DTGModlModReqRevision
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  05-Nov-2014                       Haripriya                          Initial Creation
#  14-Nov-2014                       Haripriya                          Added form creation in ImanSpecification Relation
#  08-Jan-2015						 Kameshwaran 						Updated the Form Type																-
#  22-Jan-2015						 Kameshwaran						Renamed workflow's preference macro name to TD_TAGDTGMODELREQUEST_WF_PREF.
#  30-Jan-2015						 Haripriya                          Added condition to call postaction while creating DTGModlModReqRevision.
#  04-Feb-2015						 Kameshwaran                        Modified the postaction operation to ITEM_create_rev
#  19-Feb-2015						 Haripriya                          Moved the Workflow creation to Iman_Save Postaction
#  01-Apr-2015                       Haripriya                    	    MapForm Type is changed to TD_MAP_MODL_CRE_FORM_TYPE.
#  18-Jun-2015						 Haripriya                          Removed the Commented Codes.
#  $HISTORY$
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postacion_on_create_DTGModlModReqRevision
* Description		: Postaction to create forms	  
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and create forms 	  
*                     in ImanSpecification Relation while creating 
*                     DTGModlModReqRevision
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postacion_on_create_DTGModlModReqRevision(METHOD_message_t*  msg, va_list args)
{
	int iStatus					= ITK_ok;

	const char* __function__ = "TD4_postacion_on_create_DTGModlModReqRevision";

	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
