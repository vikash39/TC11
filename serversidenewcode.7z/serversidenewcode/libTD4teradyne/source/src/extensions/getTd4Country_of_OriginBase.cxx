//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension getTd4Country_of_OriginBase
 *
 */

#include <extensions/getTd4Country_of_OriginBase.hxx>

int getTd4Country_of_OriginBase(METHOD_message_t * msg, va_list args)
{
	int       		ifail 					= ITK_ok;
	int       		iStatus 				= ITK_ok;
	int 			iVendorPartsCount			= 0;
	tag_t 			tSelectedObject 			= msg->object_tag;
	tag_t  			tPropTag 				= va_arg(args, tag_t);
	char**			propValue 				= NULL;
	const char* 		cpAttname 				= msg->prop_name;
	propValue 		= va_arg(args, char**);
	tag_t 			tRelationType 				= NULLTAG;
	tag_t * 		tVendorParts 				= NULLTAG;
	int 			iFlag 					= 0;
	char*			sStatusName 				= "";
	tag_t**			tagArray 				= NULLTAG;
	char **			valueArray 				= NULL;
	tag_t 			tVMRepresentsRelObject 			= NULLTAG;
	vector <string> 	valueVector;
	vector <string>::iterator it;
	const char * __function__ = "getTd4Country_of_OriginBase";

	TERADYNE_TRACE_ENTER();

	try
	{

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tSelectedObject, tRelationType, &iVendorPartsCount, &tVendorParts), TD_LOG_ERROR_AND_THROW);

		if (iVendorPartsCount != 0)
		{
			for (int inx = 0; inx < iVendorPartsCount; inx++)
			{
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tSelectedObject, tVendorParts[inx], tRelationType, &tVMRepresentsRelObject), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(sStatusName, TD_REMOVED) != 0)
				{
					char* cooVendorPart = NULL;
					
					getCOOValueforVendoPart(tVendorParts[inx], &cooVendorPart, 0);

					if (cooVendorPart != NULL && (tc_strcmp(cooVendorPart, "") != 0))
					{
						TC_write_syslog("start if(cooVendorPart != NULL && cooVendorPart != "")");
						std::string s(cooVendorPart);

						valueVector.push_back(s);
						MEM_free(cooVendorPart);
						TC_write_syslog("end if(cooVendorPart != NULL && cooVendorPart != "")");
					}
				}
			}
			iFlag = 0;

			if (tc_strcmp(*propValue, TD_MULTI_USA) != 0)
			{
				TC_write_syslog("start if(propvalue != Multi USA.)");
				if (valueVector.size() > 0)
				{
					TC_write_syslog("start if(valueVector size > 0)");
					if (valueVector.size() == 1)
					{
						TC_write_syslog("start if(valueVector size = 1)");
						*propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(valueVector.at(0).c_str())) + 1));

						tc_strcpy(*propValue, valueVector.at(0).c_str());

						TC_write_syslog("end if(valueVector size = 1)");
					}
					else
					{
						TC_write_syslog("start if(valueVector size > 0 && != 1)");
						for (int i = 0; i < valueVector.size(); i++)
						{
							if (tc_strcmp(valueVector.at(i).c_str(), TD_MULTI_USA) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_VIRGIN_ISLANDS) == 0
								|| tc_strcmp(valueVector.at(i).c_str(), TD_GUAM) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_NORTHERN_MARIANA_ISLANDS) == 0
								|| tc_strcmp(valueVector.at(i).c_str(), TD_AMERICAN_SAMOA) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_PUERTO_RICO) == 0
								|| tc_strcmp(valueVector.at(i).c_str(), TD_US_MINOR_OUTLYING_ISLANDS) == 0)
							{
								iFlag = 1;
								break;
							}
							//TC_write_syslog("%s@@@@@@@@\n",valueVector.at(i).c_str());
							if (tc_strcmp(valueVector.at(i).c_str(), TD_USA) == 0)
							{
								iFlag = iFlag + 1;
							}
							else if (iFlag != 0)
							{
								iFlag = 1;
							}
						}
						if (iFlag == valueVector.size())
						{
							*propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_USA)) + 1));

							tc_strcpy(*propValue, TD_USA);
						}
						else if (iFlag > 0 && iFlag < valueVector.size())
						{
							*propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_USA)) + 1));

							tc_strcpy(*propValue, TD_MULTI_USA);
						}
						else
						{
							*propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_NON_USA)) + 1));

							tc_strcpy(*propValue, TD_MULTI_NON_USA);
						}
						TC_write_syslog("end if(valueVector size > 0 && != 1)");
					}
					TC_write_syslog("end if(valueVector size > 0)");
				}
				TC_write_syslog("end if(propvalue != Multi USA.)");
			}
			/**iffor (it = valueVector.begin(); it < valueVector.end(); it++)
			{
				TC_write_syslog("%s@@@@@@@@\n",*it);
				(tc_strcmp(valueVector.at(i).c_str(),"abc") == 0)
				{

				}
			}**/
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int getCOOValueforVendoPart(tag_t tVendorPart, char ** cooVendorPart, int isMFGPart) {

	int       		iStatus = ITK_ok;
	int				valueCount = 0;
	char ** 		td4CountryOfOriginVP = NULL;
	int 			iFlag = 0;
	int				iNonPendingCount = 0;
	int				iTemp = 0;
	const char * __function__ = "getTd4Country_of_OriginBase";

	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tVendorPart, TD_COUNTRY_OF_ORIGIN_LIST, &valueCount, &td4CountryOfOriginVP), TD_LOG_ERROR_AND_THROW);

		if (valueCount != 0 && valueCount != NULL) {
			for (int inx = 0; inx < valueCount; inx++)
			{
				if (strstr(td4CountryOfOriginVP[inx], "Pending") == NULL)
				{
					iNonPendingCount++;
					iTemp = inx;
				}
			}
			if (iNonPendingCount == 1)
			{
				char *token = tc_strtok(td4CountryOfOriginVP[iTemp], "|");

				*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(td4CountryOfOriginVP[iTemp])) + 1));

				tc_strcpy(*cooVendorPart, td4CountryOfOriginVP[iTemp]);
			}
			else if (valueCount == 1 && (isMFGPart == 1 || strstr(td4CountryOfOriginVP[0], "Pending") == NULL))
			{
				char *token = tc_strtok(td4CountryOfOriginVP[0], "|");

				*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(td4CountryOfOriginVP[0])) + 1));

				tc_strcpy(*cooVendorPart, td4CountryOfOriginVP[0]);
			}
			else if (valueCount > 1)
			{
				for (int iny = 0; iny < valueCount; iny++)
				{
					if (strstr(td4CountryOfOriginVP[iny], "Pending") == NULL)
					{
						char *token = tc_strtok(td4CountryOfOriginVP[iny], "|");

						if (tc_strcmp(td4CountryOfOriginVP[iny], TD_MULTI_USA) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_VIRGIN_ISLANDS) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_GUAM) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_NORTHERN_MARIANA_ISLANDS) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_AMERICAN_SAMOA) == 0 || tc_strcmp(td4CountryOfOriginVP[iny], TD_PUERTO_RICO) == 0
							|| tc_strcmp(td4CountryOfOriginVP[iny], TD_US_MINOR_OUTLYING_ISLANDS) == 0)
						{
							iFlag = 1;
							break;
						}
						else if (tc_strcmp(td4CountryOfOriginVP[iny], TD_USA) == 0)
						{
							iFlag = iFlag + 1;
						}
						else if (iFlag != 0)
						{
							iFlag = 1;
						}
					}
				}
				if (iFlag == valueCount)
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_USA);
				}
				else if (iFlag > 0 && iFlag < valueCount)
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_MULTI_USA);
				}
				else
				{
					*cooVendorPart = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_NON_USA)) + 1));

					tc_strcpy(*cooVendorPart, TD_MULTI_NON_USA);
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
