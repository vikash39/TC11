/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_InitiateWorkflow.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Custom Request Objects
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  19-Feb-2015                       Haripriya                          Initial Creation
#  06-Mar-2015						 Kameshwaran D						Added function "teradyne_update_forms_of_createormodify_request" to update Model Forms value
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_InitiateWorkflow
* Description		: Postaction to initiate workflow process for DTGModlModReqRevision,
*                     PartModReqRevision,TAGModlCreReqRevision,TAGModlModReqRevision, CommercialPartRequestRevision
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and initiate workflow while creating 
*                     DTGModlModReqRevision,PartModReqRevision,TAGModlCreReqRevision,
*                     TAGModlModReqRevision,CommercialPartRequestRevision
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_create_InitiateWorkflow(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int  iStatus = ITK_ok;

	tag_t tNewProcess           = NULLTAG,
		  tItemtag              = NULLTAG,
		  tRevTag				= NULL;

	char *pcProcessTemplateName = NULL,
		 *pcWorkflowName        = NULL,
		 *pcObjectType          = NULL,
		 *pcCBU					= NULL;

	const char*	pcRevid			= NULL;

	const char* __function__ = "TD4_postaction_on_create_InitiateWorkflow";

	TERADYNE_TRACE_ENTER();

	try
	{
		tRevTag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		bool bIsConceptPart				= false;

		if( bisNew )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcObjectType),TD_LOG_ERROR_AND_THROW);
			
			if (!tc_strcmp(pcObjectType, TD_DTG_MDL_MOD_REQ_REV))
			{
				string szFormName[] = { "CAD Model Form","CAE Model Form","Simulation Model Form","PADStack Model Form","MAP Model Form" },
					szFormType[] = { TD_CAD_MODL_MDF_FORM_TYPE,TD_CAE_MODL_MDF_FORM_TYPE,TD_SIMUL_MODL_MDF_FORM_TYPE,TD_PAD_STACK_MODL_MDF_FORM_TYPE,TD_MAP_MODL_CRE_FORM_TYPE };

				std::map<string, string> strFormTypeNameMap;

				int iTypesize = sizeof(szFormName) / sizeof(string);
				for (int iCount = 0; iCount < iTypesize; iCount++)
				{
					strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
				}

				// Calling function to create Forms under ImanSpecification Relation to DTGModlModReqRevision
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, true), TD_LOG_ERROR_AND_THROW);

				pcWorkflowName = TD_TAGDTGMODELREQUEST_WF_PREF;
			}
			else if (!tc_strcmp(pcObjectType, TD_TAG_MDL_CRE_REQ_REV))
			{
				string szFormName[] = { "CAD Model Form","CAE Model Form","Simulation Model Form","PADStack Model Form","MAP Model Form" },
					szFormType[] = { TD_CAD_MODL_CRE_FORM_TYPE,TD_CAE_MODL_CRE_FORM_TYPE,TD_SIMUL_MODL_CRE_FORM_TYPE,TD_PAD_STACK_MODL_CRE_FORM_TYPE,TD_MAP_MODL_FORM_TYPE };

				std::map<string, string> strFormTypeNameMap;

				int iTypesize = sizeof(szFormName) / sizeof(string);
				for (int iCount = 0; iCount < iTypesize; iCount++)
				{
					strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
				}
				// Calling function to create Forms under ImanSpecification Relation to TAGModlCreReqRevisoin
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, true), TD_LOG_ERROR_AND_THROW);

				pcWorkflowName = TD_TAGDTGMODELREQUEST_WF_PREF;
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_forms_of_createormodify_request(tRevTag, 1, false), TD_LOG_ERROR_AND_THROW);
			}
			else if (!tc_strcmp(pcObjectType, TD_TAG_MDL_MOD_REQ_REV))
			{
				string szFormName[] = { "CAD Model Form","CAE Model Form","Simulation Model Form","PADStack Model Form","MAP Model Form" },
					szFormType[] = { TD_CAD_MODL_MDF_FORM_TYPE,TD_CAE_MODL_MDF_FORM_TYPE,TD_SIMUL_MODL_MDF_FORM_TYPE,TD_PAD_STACK_MODL_MDF_FORM_TYPE,TD_MAP_MODL_FORM_TYPE };

				std::map<string, string> strFormTypeNameMap;

				int iTypesize = sizeof(szFormName) / sizeof(string);
				for (int iCount = 0; iCount < iTypesize; iCount++)
				{
					strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
				}
				// Calling function to create Forms under ImanSpecification Relation to TAGModlModReqRevisoin
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, true), TD_LOG_ERROR_AND_THROW);

				pcWorkflowName = TD_TAGDTGMODELREQUEST_WF_PREF;
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_forms_of_createormodify_request(tRevTag, 0, true), TD_LOG_ERROR_AND_THROW);
			}
			else if (!tc_strcmp(pcObjectType,TD_COMM_PART_REQ_REV))
			{
				
				TERADYNE_TRACE_CALL(iStatus = teradyne_validate_attributes_CommPartReqRevision(tRevTag), TD_LOG_ERROR_AND_THROW);

				string szFormName[] = { "CAD Model Form","CAE Model Form","Simulation Model Form","PADStack Model Form","MAP Model Form" },
					szFormType[] = { TD_CAD_MODL_CRE_FORM_TYPE,TD_CAE_MODL_CRE_FORM_TYPE,TD_SIMUL_MODL_CRE_FORM_TYPE,TD_PAD_STACK_MODL_CRE_FORM_TYPE,TD_MAP_MODL_CRE_FORM_TYPE };

				std::map<string, string> strFormTypeNameMap;
				
				int iTypesize = sizeof(szFormName) / sizeof(string);
				for (int iCount = 0; iCount < iTypesize; iCount++)
				{
					strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
				}
				// Calling function to create Forms under ImanSpecification Relation to CommPartRevision
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_form(tRevTag, strFormTypeNameMap, true), TD_LOG_ERROR_AND_THROW);

				
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_forms_of_createormodify_request(tRevTag,1,false),TD_LOG_ERROR_AND_THROW);

				// Added by ANandha Bharathi 

				// Validating Owning Group as UR
				iStatus = ur_validateOwningGroup();

				if (iStatus == 0)
					pcWorkflowName = UR_COMM_PART_REQUEST_WF_PREF; // UR Workflow Pref Name
				else
					pcWorkflowName = TD_COMMERCIALPARTREQUEST_WF_PREF; // TER Workflow Pref Name

			}
			else if (!tc_strcmp(pcObjectType,TD_OPS_TASK_REV))
			{
				pcWorkflowName = TD_OPSTASK_WF_PREF;
			}
			else if (!tc_strcmp(pcObjectType,TD_PART_MOD_REQ_REV))
			{

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tRevTag, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

				if(pcCBU != NULL )
				{
					TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tRevTag,TD_REQUESTORS_DIV, pcCBU),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tRevTag,TD_CONTRL_BUS_UNIT,pcCBU),TD_LOG_ERROR_AND_THROW);
				}

				pcWorkflowName = TD_PARTMODIFYREQUEST_WF_PREF;
			}	

			//Getting Preference Value to get Workflow template name
			TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(pcWorkflowName,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
			//Calling function to Initiate Workflow on Created PartModReqRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcCBU);
	Custom_free(pcObjectType);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name	    : teradyne_update_forms_of_createormodify_request
* Description		: Postaction to update the form values
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tRevTag - Object Tag
*                     iCreateReqFlag - 1 -> It is Create Request object
*								 	 - 0 -> It is Modify Request object
*					  bMapModelUpdate - True -> It contain Map form which needs to be updated
*									  - False-> No need to Update Map Form
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Get the "suggested name/Name change" attribute value from create dailogue
*					  and update it to respective Model Forms.
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_forms_of_createormodify_request(tag_t tRevTag,int iCreateReqFlag,bool bMapModelUpdate)
{
	int		iStatus					= ITK_ok;
	string	szCADModelName			= "", 
			szCAEModelName			= "",
			szPadstackModelName		= "",
			szSimulationModelName	= "",
			szMAPModelName			= "",
			szCreRequestPart_Attr[]	= {TD_CAD_MODEL_NAME_CRE_ATTR,TD_CAE_MODEL_NAME_CRE_ATTR,TD_PAD_MODEL_NAME_CRE_ATTR,TD_SIMULATION_MODEL_NAME_CRE_ATTR}, // This all On create Form attributes
			szRequestPart_Attr[]	= {TD_CAD_MODEL_NAME_ATTR,TD_CAE_MODEL_NAME_ATTR,TD_PAD_MODEL_NAME_ATTR,TD_SIMULATION_MODEL_NAME_ATTR,TD_MAP_MODEL_NAME_ATTR},// This all Attribute related to Model Forms
			szCreFormType[]			= {TD_CAD_MODL_CRE_FORM_TYPE,TD_CAE_MODL_CRE_FORM_TYPE,TD_PAD_STACK_MODL_CRE_FORM_TYPE,TD_SIMUL_MODL_CRE_FORM_TYPE,TD_MAP_MODL_FORM_TYPE},// Create Model form type
			szMdfFormType[]			= {TD_CAD_MODL_MDF_FORM_TYPE,TD_CAE_MODL_MDF_FORM_TYPE,TD_PAD_STACK_MODL_MDF_FORM_TYPE,TD_SIMUL_MODL_MDF_FORM_TYPE,TD_MAP_MODL_FORM_TYPE};// Modify Model form type

	std::map<string,string> strCreRequestPartPropNameValueMap;

	std::vector<string> strFormValuesVec;

	char* __function__ = "teradyne_update_forms_of_createormodify_request";

	TERADYNE_TRACE_ENTER();

	try 
	{
		if ( tRevTag !=NULLTAG )
		{
			std::list<string> strCreReqPartAttrList( szCreRequestPart_Attr, szCreRequestPart_Attr + sizeof(szCreRequestPart_Attr) / sizeof(string) );

			if(bMapModelUpdate)
			{
				strCreReqPartAttrList.push_back(TD_MAP_MODEL_NAME_CRE_ATTR); // Since the Object need to be updated with MAP model form value
			}
			
			//calling function to get Request Part property values
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevTag,strCreReqPartAttrList,strCreRequestPartPropNameValueMap),TD_LOG_ERROR_AND_THROW);
			if( strCreRequestPartPropNameValueMap.size() > 0 )
			{//Insert the Values to the vector in sequence
				szCADModelName.assign(strCreRequestPartPropNameValueMap.find(TD_CAD_MODEL_NAME_CRE_ATTR)->second);
				strFormValuesVec.push_back(szCADModelName);
				szCAEModelName.assign(strCreRequestPartPropNameValueMap.find(TD_CAE_MODEL_NAME_CRE_ATTR)->second);
				strFormValuesVec.push_back(szCAEModelName);
				szPadstackModelName.assign(strCreRequestPartPropNameValueMap.find(TD_PAD_MODEL_NAME_CRE_ATTR)->second);
				strFormValuesVec.push_back(szPadstackModelName);
				szSimulationModelName.assign(strCreRequestPartPropNameValueMap.find(TD_SIMULATION_MODEL_NAME_CRE_ATTR)->second);
				strFormValuesVec.push_back(szSimulationModelName);
				if(bMapModelUpdate)
				{
					szMAPModelName.assign(strCreRequestPartPropNameValueMap.find(TD_MAP_MODEL_NAME_CRE_ATTR)->second);
					strFormValuesVec.push_back(szMAPModelName);
				}
			}
			size_t vecSize = strFormValuesVec.size();
			for(int i=0; i<vecSize ; i++)
			{
				if ( strFormValuesVec.at(i).length() > 0 )
				{
					bool isPrimary = 0;
					tag_t tSecObjs = NULLTAG;

					if(iCreateReqFlag == 1 )
					{
						// Get Secondary object tag value
						TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevTag,TD_IMAN_SPEC_REL_NAME,szCreFormType[i],isPrimary,&tSecObjs),TD_LOG_ERROR_AND_THROW);
					}
					else
					{
						// Get Secondary object tag value
						TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevTag,TD_IMAN_SPEC_REL_NAME,szMdfFormType[i],isPrimary,&tSecObjs),TD_LOG_ERROR_AND_THROW);
					}

					if (tSecObjs != NULLTAG )
					{
						//Calling function to set the property value
						TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tSecObjs,szRequestPart_Attr[i],strFormValuesVec.at(i)), TD_LOG_ERROR_AND_THROW);
						
					}
				   
				}
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_validate_attributes_CommPartReqRevision
* Description		: Precondition to check td4ProjectName,td4Manufacturer1,2,3 and td4MfrPartNumber1,2,3
*                      and td4TPNForReqForm
* REQUIRED HEADERS	:
* INPUT PARAMS		: tag_t (I) - revtag
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1. Commercial Part Request Revision on create checks attribute value td4TPNForReqForm.
*                     2. If the value is true attributes td4ProjectName,td4Manufacturer1,2,3 and td4MfrPartNumber1,2,3
*						 will act as required fields.(Popup an error message in TeamCenter until filling the required values)
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_validate_attributes_CommPartReqRevision(tag_t tObject)
{
	int	iStatus			= ITK_ok,
		iMfgCount		= 0,
		iMfgPartCount	= 0,
		iPrjCount		= 0;

	bool bTPNValue = false;

	string strErrMsg = "";
	string strCommPartReq_Attr[] = { TD_PROJECT_NAME_ATTR,TD_MANUFACTURE_1_ATTR,TD_MANUFACTURE_2_ATTR,TD_MANUFACTURE_3_ATTR,TD_MANUFACTURE_PAER_1_ATTR,TD_MANUFACTURE_PAER_2_ATTR,TD_MANUFACTURE_PAER_3_ATTR };
	
	char *pcCBU = NULL;

	char* __function__ = "teradyne_validate_attributes_CommPartReqRevision";
	TERADYNE_TRACE_ENTER();

	try {
		if (tObject != NULLTAG)
		{
			
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tObject, TD_PROJECT_NAME_ATTR, &pcCBU), TD_LOG_ERROR_AND_THROW);

			if ( pcCBU !=NULL)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_REQUESTORS_DIV, pcCBU), TD_LOG_ERROR_AND_THROW);
			}

			std::map<string, string> strPropNameValueMap;

			//Validate the required attributes and to throw error message
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tObject, TD_TPN_REQ_FORM_ATTR, &bTPNValue), TD_LOG_ERROR_AND_THROW);
			if (bTPNValue) {

				list<string> strAttrList(strCommPartReq_Attr, strCommPartReq_Attr + sizeof(strCommPartReq_Attr) / sizeof(string));
				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tObject, strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
				if (strPropNameValueMap.size() > 0) {

					for (map<string, string>::iterator itr = strPropNameValueMap.begin(); itr != strPropNameValueMap.end(); ++itr) {

						if (itr->second.length() > 0 && itr->second.compare("") != 0) { //checking the properties having values

							if (iMfgCount == 0 && (itr->first.compare(TD_MANUFACTURE_1_ATTR) == 0 || itr->first.compare(TD_MANUFACTURE_2_ATTR) == 0 || itr->first.compare(TD_MANUFACTURE_3_ATTR) == 0)) {

								iMfgCount++;
							}
							else if (iMfgPartCount == 0 && (itr->first.compare(TD_MANUFACTURE_PAER_1_ATTR) == 0 || itr->first.compare(TD_MANUFACTURE_PAER_2_ATTR) == 0 || itr->first.compare(TD_MANUFACTURE_PAER_3_ATTR) == 0)) {

								iMfgPartCount++;
							}
							else if (iPrjCount == 0 && itr->first.compare(TD_PROJECT_NAME_ATTR) == 0) {

								iPrjCount++;
							}
						}
					}
					if (iPrjCount == 0 || iMfgCount == 0 || iMfgPartCount == 0) {

						if (iMfgCount == 0) {

							strErrMsg = "Manufacturer";
						}
						if (iMfgPartCount == 0) {

							if (strErrMsg.length() > 0) strErrMsg.append(TD_COMMA_CONSTANT);
							strErrMsg = strErrMsg.append("Manufacturer Part Number");
						}
						if (iPrjCount == 0) {

							if (strErrMsg.length() > 0) strErrMsg.append(TD_COMMA_CONSTANT);
							strErrMsg = strErrMsg.append("Project Name");
						}
					}
				}
				if (strErrMsg.length() > 0 && strErrMsg.compare("") != 0) {
					//throw the error on getting empty propery values
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_COMMPARTREQ_TPN_ERROR, strErrMsg.c_str()), TD_LOG_ERROR_AND_THROW);
					iStatus = TD_COMMPARTREQ_TPN_ERROR;
					throw iStatus;
				}
			}
		}
	}
	catch (...) {

		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/**/
int teradyne_sendmail_request_no_file(tag_t tObject, tag_t tCurRevTag)
{

	int   iStatus = ITK_ok;
	string	strCurTimeStamp = "",
		strMailFilePath = TD_TEMP_PATH,
		subject = "";

	date_t	currDate;

	char* __function__ = "teradyne_sendmail_request_no_file";
	TERADYNE_TRACE_ENTER();
	TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", strCurTimeStamp, currDate), TD_LOG_ERROR_AND_THROW);
	strMailFilePath.append("SUBSCRIPTION_NOTIFICATION").append(strCurTimeStamp).append(".htm");

	//builds the email subject
	subject.assign(teradyneBuildSubscriptionSubject(tCurRevTag, "Commodity Part Request Not Submitted"));
	//builds the email body
	string htmlBodyContent = teradyneBuildSubscriptionBodyContent(tCurRevTag, "Commodity Part Request Not Submitted");
	//creates the email body file
	TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW);

	//send to address list
	char *pcAddressList = NULL;
	TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_PCB_PCBA_ADDRESS_LIST_PREF, TC_preference_site, 0, &pcAddressList), TD_LOG_ERROR_AND_THROW);
	tag_t tDistributionList = NULLTAG;
	TERADYNE_TRACE_CALL(iStatus = MAIL_find_alias_list2(pcAddressList, &tDistributionList), TD_LOG_ERROR_AND_THROW);
	int iMemberCount = 0;
	char **pcMembers = NULL;
	TERADYNE_TRACE_CALL(iStatus = MAIL_ask_alias_list_members(tDistributionList, &iMemberCount, &pcMembers), TD_LOG_ERROR_AND_THROW);
	for (int iUserCount = 0; iUserCount < iMemberCount; iUserCount++)
	{
		tag_t tUserTag = NULLTAG;
		char *the_sender_email_addr = NULL;

		TERADYNE_TRACE_CALL(iStatus = SA_find_user2(pcMembers[iUserCount], &tUserTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tUserTag, &the_sender_email_addr), TD_LOG_ERROR_AND_THROW);

		if (tc_strlen(the_sender_email_addr) > 0 && the_sender_email_addr != NULL)
		{
			//sends the email
			TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject, strMailFilePath, the_sender_email_addr), TD_LOG_ERROR_AND_THROW);
		}
		Custom_free(the_sender_email_addr);
	}
	DeleteFileA(strMailFilePath.c_str());
	Custom_free(pcAddressList);
	Custom_free(pcMembers);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}