/*==================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_precondition_on_create_DesignDocRev_RefMaterialRel.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :          This file contains function for precondition to check whether Design Document Revision,
								  ITAR Document Property true or false. If property is true then while attaching file, It'll through the error msg.
#      Project         :           libTD4teradyne
#      Author          :           
#  =================================================================================================
#  Date                              Name                               Description of Change
#  21-Oct-2021                      Vikash B                              Initial Creation
#
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_precondition_on_create_DesignDocRev_RefMaterialRel
* Description		: To check DesignDocumentRevision property "ITAR Document" is contain boolen value true or false.
					  If property is true then while attaching file, It will through the error msg.
*
* REQUIRED HEADERS	:
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/

extern "C"
int TD4_precondition_on_create_DesignDocRev_RefMaterialRel(METHOD_message_t* msg, va_list args)
{
	int iStatus = ITK_ok;

	tag_t	tObject = NULLTAG;

	logical bItarDocument = false;

	const char* __function__ = "TD4_precondition_on_create_DesignDocRev_RefMaterialRel";
	TERADYNE_TRACE_ENTER();

	va_list largs;
	va_copy(largs, args);

	// Get the input arguments
	tObject = va_arg(largs, tag_t);

	va_end(largs);

	if (tObject != NULLTAG)
	{
		try
		{
			//Getting ITAR Document Property value
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tObject, "td4ItarDocument", &bItarDocument), TD_LOG_ERROR_AND_THROW);
			
			if (bItarDocument == true)
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_ATTACH_DESIGN_DOC_REV_ERROR), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_ATTACH_DESIGN_DOC_REV_ERROR;
				throw iStatus;
			}
		}
		catch (...)
		{
			if (iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception", __function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	}


	return iStatus;
}