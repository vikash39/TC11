/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_StandardECNRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_SAVE in Standard ECN revision
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================  
#  =================================================================================================                    
#  Date                              Name                           Description of Change
#  5-Mar-2015                       Kameshwaran D                     Initial Creation 
#  16-Sept-2019                     Marjorie D			              Modified TD4_postaction_on_save_StandardECNRevision that will initiate TER_ScrapReworkWF if Scrap or Rework Cost > 0
#  $HISTORY$                    
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_StandardECNRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_StandardECNRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					= ITK_ok,
		iSaveFlag				= 1;

	tag_t tRevtag               = NULLTAG,
		  tNewProcess           = NULLTAG;

	string szPrimaryProjectName		= "",
		   szImpactedProjectName	= "";

	map<string,string>	strECNRevisionPropNameValueMap;

	vector<string>	strProjectformVec;

	char *pcWrkFlowName			= TD_STAND_ECN_REL_WF_PREF;

	const char* __function__ = "TD4_postaction_on_save_StandardECNRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		if( !bisNew )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_attachorremove_project_form_with_ProjectRel(tRevtag,iSaveFlag),TD_LOG_ERROR_AND_THROW);
		}
		else
		{
			string  szFormName[] = { "Additional Reviewers Form" },
				szFormType[] = { TD_ADDITIONAL_REVIEWER_FORM_TYPE };

			map<string, string> strFormTypeNameMap;

			int iTypesize = sizeof(szFormName) / sizeof(string);
			for (int iCount = 0; iCount < iTypesize; iCount++)
			{
				strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
			}

			//Attach or remove the project form with relation TD4ProjectRel
			TERADYNE_TRACE_CALL(iStatus = teradyne_attachorremove_project_form_with_ProjectRel(tRevtag, 0), TD_LOG_ERROR_AND_THROW);

			//Create Additional Reviewer form and attach it with TD4AdditionalReviewersRel relation 
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_additional_reviewer_form(tRevtag, strFormTypeNameMap), TD_LOG_ERROR_AND_THROW);

			char *pcAdditonalReviewerURL = NULL;

			//Getting Preference Value to get Reviewr URL name
			TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_REVIEWERS_INSTRUCTION_URL_PREF, TC_preference_site, 0, &pcAdditonalReviewerURL), TD_LOG_ERROR_AND_THROW);

			//Set td4ReviewersInstructionUrl value with preference value.
			TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_REVIEWER_INSTRC_URL, pcAdditonalReviewerURL), TD_LOG_ERROR_AND_THROW);

			char *urWrkFlowName = UR_STAND_ECN_REL_WF_PREF;

			// Added by Anandha Bharathi
			iStatus = ur_validateOwningGroup();

			if (iStatus == 0)
			{
				//To initiate the workflow
				TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(urWrkFlowName, tRevtag), TD_LOG_ERROR_AND_THROW);
			}
			else
			{
				//To initiate the workflow
				TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName, tRevtag), TD_LOG_ERROR_AND_THROW);
				//Check if rework OR scrap cost is greater than $0
				double reworkCost = 0, scrapCost = 0;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevtag, TD_ECN_EST_RWK_COST, &reworkCost), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevtag, TD_ECN_EST_SCRAP_COST, &scrapCost), TD_LOG_ERROR_AND_THROW);
				if (reworkCost > 0 || scrapCost > 0)
				{
					//initiate TD_SCRAP_REWORK_WF_PREF
					TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(TD_SCRAP_REWORK_WF_PREF, tRevtag), TD_LOG_ERROR_AND_THROW);
				}
			}
			
						
			
		
	}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name	    : teradyne_initiate_workflow_based_on_argument
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: strWorkFlowName (string) - contains Workflow name which has to be triggered
*                     tRevTag (tag_t) - on which object workflow has to be intiated
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/

int teradyne_initiate_workflow_based_on_argument(char* strWorkFlowName,tag_t tRevTag)
{
	int iStatus = ITK_ok;

	tag_t tNewProcess = NULLTAG;

	char *pcProcessTemplateName = NULL;

	char* __function__ = "teradyne_initiate_workflow_based_on_argument";
	TERADYNE_TRACE_ENTER();

	if(tRevTag != NULLTAG)
	{
		try{
			//Getting Preference Value to get Workflow template name
			TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(strWorkFlowName,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
			//Calling function to Initiate Workflow on Created PartModReqRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_process((string)pcProcessTemplateName,"",EPM_target_attachment,tRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);
		}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
* Function Name	    : teradyne_attachorremove_project_form_with_ProjectRel
* Description		: Attach / Remove the Project form as per the call
*
* REQUIRED HEADERS	:
* INPUT PARAMS		: tRevtag            (I) - object tag
*                     flagOnSave		 (0) - This is case called when ECN revision is created
*										 (1) - This is case when ECN revision is edited and saved
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: Get the Project form values from td4PrimaryProject and td4ImpactedProjects
					  and attach/remove the Project forms which are associate to ECN Revision.
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_attachorremove_project_form_with_ProjectRel(tag_t tRevtag, int flagOnSave)
{
	int   iStatus = ITK_ok,
		iObjCount = 0,
		iImpactedProjCount = 0;

	tag_t 	tProjectRelTag = NULLTAG,
		tNewRelation = NULLTAG,
		tRelationTag = NULLTAG,
		*tFindObjTag = NULL,
		tActSeqObjTag = NULLTAG;

	string szECNRevision_Attr[] = { TD_PRIMARY_PROJECT },
		szPrimaryProjectName = "",
		szImpactedProjectName = "";



	map<string, string>	strECNRevisionPropNameValueMap;

	vector<string>	strProjectformVec;
	vector<tag_t>	projectFormMatchedVec;

	char* __function__ = "teradyne_attach_project_form_with_ProjectRel";

	char** ImpactedProjValues = NULL;
	TERADYNE_TRACE_ENTER();

	try {
		std::list<string> strECNRevisionAttrList(szECNRevision_Attr, szECNRevision_Attr + sizeof(szECNRevision_Attr) / sizeof(string));

		//calling function to get ECN Revision property values
		TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tRevtag, strECNRevisionAttrList, strECNRevisionPropNameValueMap), TD_LOG_ERROR_AND_THROW);
		//Find the TD4PrjectRel type
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PROJECT_REL_NAME, &tProjectRelTag), TD_LOG_ERROR_AND_THROW);
		if (strECNRevisionPropNameValueMap.size() > 0)
		{
			szPrimaryProjectName.assign(strECNRevisionPropNameValueMap.find(TD_PRIMARY_PROJECT)->second);
			strProjectformVec.push_back(szPrimaryProjectName);
		}
		//Get the td4ImpactedProjects value which is multi-type
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tRevtag, TD_OTHER_IMPACTED_PRJ, &iImpactedProjCount, &ImpactedProjValues), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iImpactedProjCount; i++)
		{
			strProjectformVec.push_back(ImpactedProjValues[i]);//Insert all Project form into same Vector
		}

		if (flagOnSave == 1)
		{
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PROJECT_REL_NAME, &tRelationTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevtag, tRelationTag, &iObjCount, &tFindObjTag), TD_LOG_ERROR_AND_THROW);
		}

		/* Loop to analyze on each project form whether to create TD4ProjectRel or not */
		for (int itr = 0; itr < strProjectformVec.size(); itr++)
		{
			tag_t *ListTag = NULLTAG;
			tag_t tobjectTag;
			char* objecttype;
			int count = 0;
			bool continueLoop = false;
			bool bExists = false;

			string strProjectForm = strProjectformVec.at(itr);
			TERADYNE_TRACE_CALL(iStatus = WSOM_find2(strProjectForm.c_str(), &count, &ListTag), TD_LOG_ERROR_AND_THROW);
			for (int pos = 0; pos < count; pos++)
			{
				tobjectTag = ListTag[pos];
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tobjectTag, &objecttype), TD_LOG_ERROR_AND_THROW);
				string strObjectType(objecttype);
				if (strObjectType.compare("TD4ProjectForm") == 0) {
					char *pcProjForm = (char *)MEM_alloc((int)(strProjectForm.length() + 1));
					strcpy(pcProjForm, strProjectForm.c_str());
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_form_with_name_already_exists(tobjectTag, pcProjForm, bExists, &tActSeqObjTag), TD_LOG_ERROR_AND_THROW);
					if (bExists) { tobjectTag = tActSeqObjTag; }
					Custom_free(pcProjForm);
					break;
				}
			}

			if (flagOnSave == 1)
			{
				for (int i = 0; i < iObjCount; i++)
				{
					if (tobjectTag == tFindObjTag[i]) {
						projectFormMatchedVec.push_back(tFindObjTag[i]);//populate the vector when both the tag matches
						continueLoop = true;
						break;//Project form matched which is already attached with TD4ProjectRel relationship we break loop here
					}
				}
			}

			MEM_free(ListTag);
			if (continueLoop) continue; // Since relation is already created for project form there is need to proceed with below lines

			TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevtag, tobjectTag, tProjectRelTag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tNewRelation), TD_LOG_ERROR_AND_THROW);
		}

		if (flagOnSave == 1)
		{
			tag_t tProjRel = NULLTAG;
			for (int i = 0; i < iObjCount; i++)
			{
				/* Here We find and remove the Project forms which does not exist in the values of attributes td4PrimaryProject and td4ImpactedProjects */
				std::vector<tag_t>::iterator it = projectFormMatchedVec.begin();
				it = find(projectFormMatchedVec.begin(), projectFormMatchedVec.end(), tFindObjTag[i]);
				if (it == projectFormMatchedVec.end())
				{
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tRevtag, tFindObjTag[i], tRelationTag, &tProjRel), TD_LOG_ERROR_AND_THROW);
					if (tProjRel != NULLTAG)
						GRM_delete_relation(tProjRel);// delete the relation with project form since it is removed from td4PrimaryProject/td4ImpactedProjects 
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	for (int i = 0; i < iImpactedProjCount; i++)	MEM_free(ImpactedProjValues[i]);

	MEM_free(ImpactedProjValues);
	MEM_free(tFindObjTag);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
* Function Name	    : teradyne_create_additional_reviewer_form
* Description		: Creates Custom form under given object
*					  in given Relation
*
* REQUIRED HEADERS	:
* INPUT PARAMS		: tRevtag            (I) - object tag
*                     strFormTypeNameMap (I) - Input has Form name and Type
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: Create the Addition Reviewer Form and attaches it with the
*					  revision in TD4AdditionalReviewersRel relation.
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_create_additional_reviewer_form(tag_t tRevTag, std::map<string, string> strFormTypeNameMap)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	tag_t tFormTag = NULLTAG,
		tAddReviewRelTag = NULLTAG,
		tNewRelation = NULLTAG;


	char* __function__ = "teradyne_create_Additional_Reviewer_form";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tRevTag != NULLTAG)
		{
			//Getting Additional reviewer relation tag
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ADDITIONAL_REVIEWER_REL_NAME, &tAddReviewRelTag), TD_LOG_ERROR_AND_THROW);

			for (std::map<string, string>::iterator it = strFormTypeNameMap.begin(); it != strFormTypeNameMap.end(); ++it)
			{
				//calling function to create form with the given type and name
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_object(it->first, it->second, &tFormTag), TD_LOG_ERROR_AND_THROW);
				if (tFormTag != NULLTAG)
				{
					//Attaching form to the Revision with TD4AdditionalReviewersRel in found relation tag
					TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tRevTag, tFormTag, tAddReviewRelTag, NULLTAG, &tNewRelation), TD_LOG_ERROR_AND_THROW);

					if (tNewRelation != NULLTAG)
						TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tNewRelation), TD_LOG_ERROR_AND_THROW);
					//TERADYNE_TRACE_CALL(iStatus = POM_load_instances_any_class(1, &tFormTag, POM_no_lock), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}