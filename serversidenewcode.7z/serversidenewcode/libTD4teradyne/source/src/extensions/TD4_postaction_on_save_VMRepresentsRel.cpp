#include <extensions/teradyne_extensions.h>
#include <workflow/teradyne_handlers.h>

extern "C"
int TD4_postaction_on_save_VMRepresentsRel(METHOD_message_t*  msg, va_list args)
{
	int iStatus					= ITK_ok,
		iVendorPartsCount		= 0,
		valueCount				= 0;

	char  *pcPrimaryTypeName    = NULL,
		  *pcSecondaryTypeName  = NULL,
		  *pcObjectType			= NULL,
		  *sStatusName			= "",
		  *propValue			= NULL,
		  *tTempValue			= NULL,
		  *sFinalValue			= NULL;
		 
	tag_t tObject               = NULLTAG,
	      tPrimaryObject        = NULLTAG,
		  tSecondaryObject		= NULLTAG,
		  tRelationType			= NULLTAG,
		  tVMRepresentsRelObject = NULLTAG;

	tag_t *tVendorParts			= NULLTAG,
		  *tVendorPartsCOO		= NULLTAG;

	char  **td4CountryOfOriginVPCOO = NULL;

	vector <string> valueVector;
	list <string> cooCodeList;
	list <string>::iterator it;

	const char* __function__ = "TD4_postaction_on_save_VMRepresentsRel";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);

		bool bisverdict = true;
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject, &tPrimaryObject), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject, &tSecondaryObject), TD_LOG_ERROR_AND_THROW);
		if ((tPrimaryObject != NULLTAG) && (tSecondaryObject != NULLTAG))
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject, &pcPrimaryTypeName), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject, &pcSecondaryTypeName), TD_LOG_ERROR_AND_THROW);
			if ((tc_strcmp(pcPrimaryTypeName, TD_COMM_PART_REV) == 0) || (tc_strcmp(pcPrimaryTypeName, TD_DIV_PART_REV) == 0)
				&& tc_strcmp(pcSecondaryTypeName, TD_MFG_PART) == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPrimaryObject, tRelationType, &iVendorPartsCount, &tVendorParts), TD_LOG_ERROR_AND_THROW);

				if (iVendorPartsCount != 0)
				{
					for (int inx = 0; inx < iVendorPartsCount; inx++)
					{
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObject, tVendorParts[inx], tRelationType, &tVMRepresentsRelObject), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

						if (tc_strcmp(sStatusName, TD_REMOVED) != 0)
						{
							char *cooVendorPart = NULL;

							teradyne_getCOOValueforVendoPart(tVendorParts[inx], &cooVendorPart, 0);

							if (cooVendorPart != NULL && (tc_strcmp(cooVendorPart, "") != 0))
							{
								std::string s(cooVendorPart);

								valueVector.push_back(s);
								MEM_free(cooVendorPart);
							}
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tVendorParts[inx], TD_COUNTRY_OF_ORIGIN_LIST, &valueCount, &td4CountryOfOriginVPCOO), TD_LOG_ERROR_AND_THROW);

							if (valueCount != 0 && valueCount != NULL)
							{
								for (int iny = 0; iny < valueCount; iny++)
								{
									if (strstr(td4CountryOfOriginVPCOO[iny], "Pending") == NULL)
									{
										char *token = tc_strtok(td4CountryOfOriginVPCOO[iny], "|");

										while (token != NULL)
										{
											tTempValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(token)) + 1));

											tc_strcpy(tTempValue, token);

											token = tc_strtok(NULL, "|");
										}
										std::string s(tTempValue);

										cooCodeList.push_back(s);
									}
								}
							}
						}
					}
					int iFlag = 0;

					if (valueVector.size() > 0)
					{
						if (valueVector.size() == 1)
						{
							propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(valueVector.at(0).c_str())) + 1));

							tc_strcpy(propValue, valueVector.at(0).c_str());
						}
						else
						{
							for (int i = 0; i < valueVector.size(); i++)
							{
								if (tc_strcmp(valueVector.at(i).c_str(), TD_MULTI_USA) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_VIRGIN_ISLANDS) == 0
									|| tc_strcmp(valueVector.at(i).c_str(), TD_GUAM) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_NORTHERN_MARIANA_ISLANDS) == 0
									|| tc_strcmp(valueVector.at(i).c_str(), TD_AMERICAN_SAMOA) == 0 || tc_strcmp(valueVector.at(i).c_str(), TD_PUERTO_RICO) == 0
									|| tc_strcmp(valueVector.at(i).c_str(), TD_US_MINOR_OUTLYING_ISLANDS) == 0)
								{
									iFlag = 1;
									break;
								}
								//TC_write_syslog("%s@@@@@@@@\n",valueVector.at(i).c_str());
								if (tc_strcmp(valueVector.at(i).c_str(), TD_USA) == 0)
								{
									iFlag = iFlag + 1;
								}
								else if (iFlag != 0)
								{
									iFlag = 1;
								}
							}
							if (iFlag == valueVector.size())
							{
								propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_USA)) + 1));

								tc_strcpy(propValue, TD_USA);
							}
							else if (iFlag > 0 && iFlag < valueVector.size())
							{
								propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_USA)) + 1));

								tc_strcpy(propValue, TD_MULTI_USA);
							}
							else
							{
								propValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(TD_MULTI_NON_USA)) + 1));

								tc_strcpy(propValue, TD_MULTI_NON_USA);
							}
						}
					}

					if (cooCodeList.size() > 0)
					{
						cooCodeList.sort();

						cooCodeList.unique();

						sFinalValue = (char*)MEM_alloc(sizeof(char) * (4 * (int)(cooCodeList.size()) + 1));

						for (it = cooCodeList.begin(); it != cooCodeList.end(); ++it)
						{

							if (tc_strcmp(sFinalValue, "") == 0)
							{
								tc_strcat(sFinalValue, it->c_str());
							}
							else
							{
								tc_strcat(sFinalValue, ",");

								tc_strcat(sFinalValue, it->c_str());
							}
						}
					}
					POM_AM__set_application_bypass(true);

					TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tPrimaryObject, &bisverdict), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimaryObject, true), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tPrimaryObject, "td4_Country_of_Origin_Code", sFinalValue), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tPrimaryObject, "td4_Country_of_Origin", propValue), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tPrimaryObject), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimaryObject, false), TD_LOG_ERROR_AND_THROW);
					}

					POM_AM__set_application_bypass(false);

					MEM_free(sFinalValue);
					MEM_free(tTempValue);
					MEM_free(propValue);
				}
			}
		}
		logical isCheckOut = false;
		POM_AM__set_application_bypass(true);
		//updating the change reason attribute with empty value
		TERADYNE_TRACE_CALL(iStatus = RES_is_checked_out(tPrimaryObject, &isCheckOut), TD_LOG_ERROR_AND_THROW);
		if (!isCheckOut)
		{
			TCTYPE_save_operation_context_t tsaveOpContext;
			TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&tsaveOpContext), TD_LOG_ERROR_AND_THROW);
			if (tsaveOpContext != TCTYPE_save_on_revise)
			{

			TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPrimaryObject, TD_CHNG_RESN_ATTR, "Modified Country of Origin as per Mfg Part change."), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = RES_checkout2(tPrimaryObject, " ", NULL, TD_TEMP_PATH, RES_EXCLUSIVE_RESERVE), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = RES_checkin(tPrimaryObject), TD_LOG_ERROR_AND_THROW);
			}
			if (bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimaryObject, true), TD_LOG_ERROR_AND_THROW);
			}
		}

		//edited for Updation of "Removed On" attribute
		char * pcPreferStat = NULL,
			 *pcUid = NULL;
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_PREFERRED_STATUS_ATTR, &pcPreferStat), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = POM_tag_to_uid(tObject, &pcUid), TD_LOG_ERROR_AND_THROW);
		string sKey = std::string(pcUid);
		if (tc_strcmp(pcPreferStat, TD_REMOVED) == 0)
		{
			string sPrevStat;
			string strCurTimeStamp = "";
			date_t curDate;
			if (tc_strlen(pcPreferStat) > 0)
			{
				sPrevStat = teradyne_get_vPreferedStat(sKey);
			}	
			if (tc_strcmp(pcPreferStat, sPrevStat.c_str())==0)
			{
				if (tc_strcmp(pcPreferStat, TD_REMOVED) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_current_time_utc(TD_DATE_DMY_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject, true), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_set_value_date(tObject,TD_REMOVED_DATE,curDate), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tObject), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject, false), TD_LOG_ERROR_AND_THROW);
				}
				
			}		
		}
		else
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject, true), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_set_value_date(tObject, TD_REMOVED_DATE, NULLDATE), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tObject), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject, false), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strlen(pcPreferStat) > 0)
		{
			teradyne_remove_vPreferedStat_ele(sKey);
		}
		Custom_free(pcPreferStat);
		Custom_free(pcUid);
		

		POM_AM__set_application_bypass(false);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		POM_AM__set_application_bypass(false);
	}

	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);
	Custom_free(pcObjectType);

	TERADYNE_TRACE_LEAVE(iStatus);

	POM_AM__set_application_bypass(false);

	return iStatus;
}