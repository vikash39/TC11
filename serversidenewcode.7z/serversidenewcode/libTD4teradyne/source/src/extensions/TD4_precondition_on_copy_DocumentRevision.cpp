/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_copy_DocumentRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Check the pre-conditon to apply revision rule on ITEM_copy_rev while revising DesingDoc, GenerealDoc and DivPart
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                             Name                               Description of Change
#  18-Jun-2015                      Vijayasekhar                       Initial Creation(Added function definitions TD4_precondition_on_copy_DocumentRevision and teradyne_check_and_apply_revision_rule)
#  26-Jun-2015                      Vijayasekhar                       Added function definitions teradyne_latest_rev_from_rev
#  30-Jun-2015                      Vijayasekhar                       Modified the function teradyne_check_and_apply_revision_rule definition to handle Revision skip letters
#  17-Jul-2015                      Manimaran                          Commented the code which prevents the user from skipping the revision id.
#  30-Sep-2015                      Manimaran                          Modified the code to check whether the Document Revision being revised is the Latest Revision.
#  20-Nov-2015                      Manimaran                          Modified the code to set the computed rev id as the latest revision rev id.
#  22-Dec-2015                      Manimaran                          Moved the function teradyne_latest_rev_from_rev to common.
#  17-Mar-2016                      Manimaran                          Modified the code to align BOM View revision IDs with div part rev IDs when skipping omitted revisions.
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
* Function Name	    : TD4_precondition_on_copy_DocumentRevision
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1. Check is it Change admin if yes then no need to procced return it
*					  2. If not Change admin then user has to follow the revision rule
* NOTES			    :
*------------------------------------------------------------------------------*/

int TD4_precondition_on_copy_DocumentRevision(METHOD_message_t *msg , va_list args)
{
	int		iStatus				= ITK_ok;
	char	*pcRevid			= NULL;
	tag_t    tPrevRevTag		= NULLTAG,
			 tLatestDocRev		    = NULLTAG;
	string szUsergroup			= "";

	const char* __function__ = "TD4_precondition_on_copy_DocumentRevision";
	TERADYNE_TRACE_ENTER();

	try {
			//Get the input arguments from item_copy_rev msg
			tPrevRevTag = va_arg(args, tag_t);
			pcRevid = va_arg(args, char*);

			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tPrevRevTag, &tLatestDocRev), TD_LOG_ERROR_AND_THROW);

			if (tPrevRevTag != tLatestDocRev) {
				TERADYNE_TRACE_CALL(iStatus=EMH_store_error(EMH_severity_error, TD_NOT_LATEST_REV_ERROR), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_NOT_LATEST_REV_ERROR;
				throw iStatus;
			}

			/*TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup),TD_LOG_ERROR_AND_THROW);
			if (!szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT)) { return iStatus; }
			else {
				//checks the revision rule 
				TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_apply_revision_rule(tPrevRevTag,pcRevid),TD_LOG_ERROR_AND_THROW);
			}*/
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name	    : teradyne_check_and_apply_revision_rule
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: tPrevRevTag (I) - Previous revision tag_t
*                     pcRevid (I) - Previous revision id char*
*					  iExcludedLovValues (I) - Count of excluded lov values int
*                     pcExcludedLovValues (I) - Array of excluded values char*
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1. Revision is created based on previous revision.
*					: 2. Check the Revision sequence without skipping the Alphabetical order. 
*					: 3. If it is in the order then will create the new revision otherwise it will throw appropriate error.
* NOTES			    :
*------------------------------------------------------------------------------*/

int teradyne_check_and_apply_revision_rule(tag_t tPrevRevTag,char *pcRevid, int iExcludedLovValues, char* pcExcludedLovValues)
{
	int	 iStatus				= ITK_ok;
	char *pcLastestRevId		= NULL;
	string	szRevid				= (pcRevid);
	tag_t tLatestRev			= NULLTAG;

	const char* __function__ = "teradyne_check_and_apply_revision_rule";
	TERADYNE_TRACE_ENTER();

	try
	{
		bool bAddCharacter = false;
		if(tPrevRevTag != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tPrevRevTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);
			if(tLatestRev != NULLTAG) {
			
				//Get the latest revisiong id item ID 
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_rev_id2(tLatestRev,&pcLastestRevId),TD_LOG_ERROR_AND_THROW);
			}
		}
		/* Logic to create next squence Revision Id based on previous id */
		string strLastestRevId(pcLastestRevId);
		size_t iRevLength = strLastestRevId.length();
		char *pcNewRevID = (char*) MEM_alloc(sizeof(char) * (int)(iRevLength + 1));
		if(pcNewRevID) {
		
			sprintf(pcNewRevID,"%s",strLastestRevId.c_str());
		} else {
		
			TC_write_syslog("Unable to Allocate Memory for Revision ID %s%s",pcLastestRevId,__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
			throw iStatus;
		}
		bool bIsZ = false;
		//New Rev ID is created pass it to ITK api to set Rev ID
		for ( int iPos = (int)(iRevLength-1) ; iPos >= 0 ; iPos --)
		{
			char pcSubPrevID = pcLastestRevId[iPos];
			if( pcSubPrevID != 'Z' ) {
					pcSubPrevID++;
					for(int iLov = 0; iLov < iExcludedLovValues; iLov++) {
					
						bIsZ = false;
						if(pcSubPrevID == pcExcludedLovValues[iLov]) {
						
							if(pcSubPrevID == 'Z') {
							
								bIsZ = true;
								if( iPos == 0 ) { bAddCharacter = true;}
								pcSubPrevID = 'A';
							} else {
							
								pcSubPrevID++;
								iLov = 0;
							}
						}
					}
					pcNewRevID[iPos] = pcSubPrevID;
					if(!bIsZ)
						break;
			} 
			else if(pcSubPrevID == 'Z'){
				if( iPos == 0 ) { bAddCharacter = true;}
				pcNewRevID[iPos] = 'A';
			}
		}
		string szNewRevID(pcNewRevID);
		//when revision crossed Z alphabet
		if(bAddCharacter)
		{
			szNewRevID = 'A' + szNewRevID;
		}

		TERADYNE_TRACE_CALL(iStatus = ITEM_set_rev_id(tLatestRev, szNewRevID.c_str()), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tLatestRev), TD_LOG_ERROR_AND_THROW);

		//Align BOM View revision IDs with div part rev IDs
		int iBomCountCheck     = 0;
		tag_t *tBomViewRevions = NULL;
		TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tLatestRev, &iBomCountCheck, &tBomViewRevions), TD_LOG_ERROR_AND_THROW);
		if(iBomCountCheck > 0)
		{
			for(int z = 0; z < iBomCountCheck; z++)
			{
				char *pcBomViewRev = NULL;
				char *pcItemId = NULL;

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tLatestRev, &pcItemId), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tBomViewRevions[z], TD_OBJECT_NAME_ATTR, &pcBomViewRev), TD_LOG_ERROR_AND_THROW);

				string szBomViewRev = string(pcBomViewRev);
				int ifnd = (int)szBomViewRev.find_last_of("-");
				string szBomViewRevName = string(pcItemId) + "/" + szNewRevID + string(szBomViewRev.substr(ifnd, szBomViewRev.length()));

				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tBomViewRevions[z], TD_OBJECT_NAME_ATTR, szBomViewRevName), TD_LOG_ERROR_AND_THROW);

				Custom_free(pcBomViewRev);
				Custom_free(pcItemId);
			}
		}
		Custom_free(tBomViewRevions);

	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("Unhandled exception occured %s",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcLastestRevId);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}
