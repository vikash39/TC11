/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_DivPartRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on ITEM_create_rev in Divisional Part revision
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  05-Nov-2014                       Haripriya                          Initial Creation
#  13-Jan-2015						 Kameshwaran D.						Removed Reliablity form from form name and form type array.
#  22-Jan-2015						 Kameshwaran D.						Renamed workflow's preference macro name to TD_T4O_ITEM_PUSH_WF_PREF.
#  30-Jan-2015						 Haripriya                          Added condition to call postaction while creating DivisionalPartRevision.
#  04-Feb-2015                       Haripriya                          Modified the postaction operation to ITEM_create_rev
#  16-Feb-2015                       Haripriya                          Modified teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory
#  18-Feb-2015                       Vijayasekhar                       Added boolean parameter for teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory
#  19-Feb-2015						 Haripriya                          Moved the Workflow creation to Iman_Save Postaction
#  04-Mar-2015                       Vijayasekhar                       Added changes to remove the reason attribute on part create and modify
#  05-Mar-2015                       Haripriya                          Modified the PartCategory not listed mail subject and body file content and StandardDescription error call.
#  11-Mar-2015						 Haripriya						    Modified teradyne_searchform_updateattributevalue and teradyne_validate_required_attribute.
#  13-Mar-2015						 Haripriya						    Checking  ItemId naming Pattern condition for other Than CMAdmin Roles
#  18-Mar-2015						 Haripriya						    Except DBA and CMAdmin Role others cannot Create Revision ID other Than A
#  30-Mar-2015						 Haripriya						    Added space after comma in standarddescription value
#  26-Mar-2015						 Selvi							    Added condition to avoid enter ItemID manually.
#  08-Jun-2015						 Haripriya							Replaced Item_find_item api with ITEM_find because of TC_MFK_DEFAULT_DOMAIN Preference
#  12-Jun-2015						 Haripriya							Added condition to avoid enter ItemID manually.
#  16-Jun-2015						 Haripriya							Added type check condition to avoid entering ItemID manually.
#  18-Jun-2015						 Haripriya                          Removed the Commented Codes.
#  23-Jun-2015					     Vijayasekhar                       Added current timestamp to the file path related to mail content
#  12-Aug-2015						 Haripriya                          Added type check condition to avoid entering ItemID manually..
#  31-Jan-2017						 Karl Reimann						Added td4PartType check for PCB or PCBA to send notification to address list.
#  22-May-2018						 Marjorie							Added create design document section (max of 3)
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_DivPartRevision
* Description		: Postaction to validate revisionid,partcategory,StandardDescription
*                     values,create forms.	      
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 1.Precondition to validate Revisionid,BasePart check,partcategory,
*                      and StandardDesc_Attr.
*                     2.Create forms and attach to DivPartRevision in DisciplineSpecific 
*                      Relation while creating DivPartRevision
*					 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"

int TD4_postaction_on_create_DivPartRevision(METHOD_message_t *msg , va_list args)
{
	int   iStatus                    = ITK_ok;

	char* __function__ = "TD4_postaction_on_create_DivPartRevision";
	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}




