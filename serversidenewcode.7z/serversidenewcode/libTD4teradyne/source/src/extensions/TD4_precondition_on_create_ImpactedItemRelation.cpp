/*==================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_precondition_on_create_ImpactedItemRelation.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains function for Precondition on create impacted Item Relation
#      Project         :           libTD4teradyne
#      Author          :           Vikash B.
#  =================================================================================================
#  Date                              Name                               Description of Change
#  02-July-2021                      Vikash B.                          Initial Creation
#  $HISTORY$
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_precondition_on_create_ImpactedItemRelation
 * Description      : This function will be check, td4ItemStatus property is inactive or not,
 *                    if it's inactive then through the error msg.
 *
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I) - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 1.Gets the Primary and Secondary object type.
 *					  2.If the Primary Object type is ECN revision
 *                    and Secondary Object type is DivpartRevision, then check for
 *                    td4ItemStatus property value inactive or not .
 *                    3.If property value is inactive then throw error.
 *
 * NOTES            :TD4_precondition_on_create_ImpactedItemRelation
 ******************************************************************************/
extern "C"
int TD4_precondition_on_create_ImpactedItemRelation(METHOD_message_t*  msg, va_list args)
{
	int	iStatus = ITK_ok,
		ifound = 0;

	char *pcPrimaryTypeName = NULL,
		*pcSecondaryTypeName = NULL,
		*pcTd4ItemStatus = NULL,
		*pcPrECNItemId = NULL,
		*pcPartItemId = NULL;

	tag_t tObject = NULLTAG,
		tPrimaryObject = NULLTAG,
		tSecondaryObject = NULLTAG;
	va_list largs;
	const char* __function__ = "TD4_precondition_on_create_ImpactedItemRelation";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		va_copy(largs, args);
		tPrimaryObject = va_arg(largs, tag_t);
		tSecondaryObject = va_arg(largs, tag_t);
		va_end(largs);

		if ((tPrimaryObject != NULLTAG) && (tSecondaryObject != NULLTAG))
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject, &pcPrimaryTypeName), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject, &pcSecondaryTypeName), TD_LOG_ERROR_AND_THROW);

			if ((tc_strcmp(pcSecondaryTypeName, TD_DIV_PART_REV) == 0)) {

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObject, TD_ITEM_INACTIVE_STATUS, &pcTd4ItemStatus), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tPrimaryObject, TD_ITEM_ID_ATTR, &pcPrECNItemId), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObject, TD_ITEM_ID_ATTR, &pcPartItemId), TD_LOG_ERROR_AND_THROW);

				if (pcTd4ItemStatus != NULL) {

					if (tc_strcmp(pcTd4ItemStatus, TD_INACTIVE_PRO) == 0) {

						EMH_store_error_s2(EMH_severity_error, TD_INACTIVE_DIV_PART_ATTACH_ERROR, pcPartItemId, pcPrECNItemId);
						iStatus = TD_INACTIVE_DIV_PART_ATTACH_ERROR;
						Custom_free(pcPrimaryTypeName);
						Custom_free(pcSecondaryTypeName);
						Custom_free(pcTd4ItemStatus);
						Custom_free(pcPrECNItemId);
						Custom_free(pcPartItemId);
						throw iStatus;
					}
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}