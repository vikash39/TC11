#include <extensions/teradyne_extensions.h>
extern "C"
int TD4_postaction_on_save_BVR(METHOD_message_t *msg , va_list args)
{
	int iStatus					    = ITK_ok;

	const char* __function__		= "TD4_postaction_on_save_BVR";

	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}