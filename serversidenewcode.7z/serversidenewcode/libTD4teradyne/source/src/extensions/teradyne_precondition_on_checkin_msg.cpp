/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                       
#      Filename        :           teradyne_precondition_on_checkin_msg.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for checkin pre condition action
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D.          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  13-Jan-2015                       Kameshwaran D.                     Initial Creation. Pre-condition on check-in action to check
#																		DSE form's change reason attribute value is filled or not.
#  06-Fed-2015                       Vijayasekhar	                    Added function call to validate the attributes for Commercial Part Request.
#  07-Oct-2015                       Deepachitra                        Added condition to check Rev Stamp Attribute value length
#  14-Oct-2015                       Manimaran                          Removed the condition which checks Rev Stamp Attribute value length
#  09-May-2018                       Marjorie                           Added condition to check Change Reason for TD4OPSTASK
#  11-May-2021						 Vikash B 							Modified the code to check Org value for NXT Div Part and throw error if it's not NXT
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : teradyne_precondition_on_checkin_msg
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED : To restrict Check-in if 'Change Reason' attribute is empty
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int teradyne_precondition_on_checkin_msg(METHOD_message_t*  msg, va_list args)
{
	int iStatus					= ITK_ok;

    char *pcChgReason			= NULL,
		 *pcTypeName			= NULL;

	tag_t tObject				= NULLTAG;

	const char* __function__ = "teradyne_precondition_on_checkin_msg";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);
		if(tObject != NULLTAG)
		{
		     TERADYNE_TRACE_CALL(iStatus = teradyne_validateObjectBeforeCheckIn(tObject),TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcTypeName);
	Custom_free(pcChgReason);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_validateObjectBeforeCheckIn(tag_t tObject)
{
	int iStatus					= ITK_ok;

    char *pcChgReason			= NULL,
		 *pcTypeName			= NULL;

	

	const char* __function__ = "teradyne_validateObjectBeforeCheckIn";
	TERADYNE_TRACE_ENTER();

	try
	{
		
		if(tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObject,&pcTypeName),TD_LOG_ERROR_AND_THROW);

			if(pcTypeName != NULL)
			{
				if(tc_strcmp(pcTypeName, TD_CHANGEADMIN_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_DFM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_RELIABILITY_FORM_TYPE) == 0 
					|| tc_strcmp(pcTypeName, TD_SBM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_SAFETY_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_TRADE_COMPL_FORM_TYPE) == 0
					|| tc_strcmp(pcTypeName, TD_OPS_TASK_REV) == 0 ||  tc_strcmp(pcTypeName, TD_COMM_PART_REV) == 0 ||tc_strcmp(pcTypeName, TD_DIV_PART_REV) == 0 
					|| tc_strcmp(pcTypeName, TD_MFG_PART) == 0)
					{
						//Get the Change Reason attribute value
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);

						//Throw warning message to user if Change Reason field is empty
						if(pcChgReason == NULL || tc_strlen(pcChgReason) == 0) {
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error,TD_CHECK_IN_MSG_ERROR),TD_LOG_ERROR_AND_THROW);
							iStatus = TD_CHECK_IN_MSG_ERROR;
							throw iStatus;
						}
					}

				if (tc_strcmp(pcTypeName, TD_VENDOR) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_VD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);

					//Throw warning message to user if Change Reason field is empty
					if (pcChgReason == NULL || tc_strlen(pcChgReason) == 0) {
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_CHECK_IN_MSG_ERROR), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_CHECK_IN_MSG_ERROR;
						throw iStatus;
					}
				}

				if( tc_strcmp(pcTypeName, TD_COMM_PART_REQ_REV) == 0) {



					//validates the attributes on checkin operation
					TERADYNE_TRACE_CALL(iStatus = teradyne_validate_attributes_CommPartReqRevision(tObject),TD_LOG_ERROR_AND_THROW);
				}
				if(tc_strcmp(pcTypeName, TD_ORACLE_ORG_FORM_TYPE) == 0 )
				{	
					char **orgValues = NULLTAG;	
					int count = 0;
					
					TERADYNE_TRACE_CALL(iStatus = AOM_lock(tObject),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tObject,true),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tObject, TD_ORG_FORM_ATTR, &count, &orgValues), TD_LOG_ERROR_AND_THROW);
					if( count > 0)
					{
						
						std::vector<std::string> orgVals;
						vector<string> duplicates;

						for(int i = 0; i < count; i++)
						{
							orgVals.push_back(orgValues[i]);
						}

						std::sort(orgVals.begin(), orgVals.end());
						for (int j = 1; j < orgVals.size(); j++)
						{
							if(orgVals[j-1] == orgVals[j])
								duplicates.push_back(orgVals[j]);
						}
						if(duplicates.size() > 0)
						{
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error,TD_DUPLICATE_ORGS_ERROR),TD_LOG_ERROR_AND_THROW);
							throw iStatus = TD_DUPLICATE_ORGS_ERROR;
						}
						else
						{	
							std::vector<char *> cStrings;
							cStrings.reserve(orgVals.size());
							tag_t tPrimaryObj = NULLTAG;
							tag_t tRevTag = NULLTAG;
							char * pcControllingBusUnit = NULL;
							logical isNXT = true;
							char * pcRevTypeName = NULL;
							TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tObject, TD_ORG_REL_NAME, "", 1, &tPrimaryObj), TD_LOG_ERROR_AND_THROW);
							if (tPrimaryObj != NULLTAG)
							{
								TC_write_syslog("\nPrimtag\n ");
								TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tPrimaryObj, &tRevTag), TD_LOG_ERROR_AND_THROW);
								if (tRevTag != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcRevTypeName),TD_LOG_ERROR_AND_THROW);
									if(tc_strcmp(pcRevTypeName, TD_DIV_PART_REV) == 0)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevTag, TD_CONTRL_BUSS_UNIT, &pcControllingBusUnit), TD_LOG_ERROR_AND_THROW);
										string controllingBusUnit(pcControllingBusUnit);

										if (controllingBusUnit.compare(TD_NXT) == 0)
										{
							for(int i=0; i< orgVals.size(); i++)
							{
												TC_write_syslog("\n ORG val: %s\n", orgVals[i].c_str());
												if (strcmp(orgVals[i].c_str(), "NXT") != 0)
												{
													TC_write_syslog("\ncontrollingBusUnit != NXT: %s\n", controllingBusUnit.c_str());
													
													isNXT = false;
													break;
												}
											}
											if (isNXT == false)
											{
												TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NOT_VALID_NXT_ORG), TD_LOG_ERROR_AND_THROW);
												throw iStatus = TD_NOT_VALID_NXT_ORG;
											}
											/*TC_write_syslog("\ncontrollingBusUnit: %s\n", controllingBusUnit.c_str());
											if (orgVals.size() > 1)
											{
												TC_write_syslog("\ncontrollingBusUnit > 1: %s\n", controllingBusUnit.c_str());
												TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NOT_VALID_NXT_ORG), TD_LOG_ERROR_AND_THROW);
												throw iStatus = TD_NOT_VALID_NXT_ORG;
											}
											else if(orgVals.size() == 1)
											{
												TC_write_syslog("\ncontrollingBusUnit = 1: %s\n", controllingBusUnit.c_str());
												if (strcmp(orgVals[0].c_str(), "NXT") != 0)
												{
													TC_write_syslog("\ncontrollingBusUnit != NXT: %s\n", controllingBusUnit.c_str());
													TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NOT_VALID_NXT_ORG), TD_LOG_ERROR_AND_THROW);
													throw iStatus = TD_NOT_VALID_NXT_ORG;
												}
											}*/
										}
									}
								}
							}
							for(int i=0; i< orgVals.size(); i++)
							{
								cStrings.push_back(const_cast<char*>(orgVals[i].c_str()));
							}
							TERADYNE_TRACE_CALL(iStatus = AOM_set_value_strings(tObject,TD_ORG_FORM_ATTR, count, &cStrings[0]), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tObject),TD_LOG_ERROR_AND_THROW);
							Custom_free(pcControllingBusUnit);
							Custom_free(pcRevTypeName);
						}

					}
					TERADYNE_TRACE_CALL(iStatus = AOM_unlock(tObject),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tObject,false),TD_LOG_ERROR_AND_THROW);
					Custom_free(orgValues);
				}
				//Material Impact Update form
				if( tc_strcmp(pcTypeName, TD_MATL_IMP_UPDATE_FORM_TYPE) == 0 )
				{
					double reworkCost = 0, scrapCost = 0;
					//Check if rework aOR scrap cost is greater than $0
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tObject,TD_ECN_EST_RWK_COST,&reworkCost),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tObject,TD_ECN_EST_SCRAP_COST,&scrapCost),TD_LOG_ERROR_AND_THROW);
					if( reworkCost > 0 || scrapCost > 0)
					{
						//initiate TD_SCRAP_REWORK_WF_PREF
						TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(TD_SCRAP_REWORK_WF_PREF,tObject) ,TD_LOG_ERROR_AND_THROW);
			}	
		}
	}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcTypeName);
	Custom_free(pcChgReason);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}






