/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                  Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_extensions.h          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Header file for custom extensions       
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  31-Oct-2014                       Haripriya                         Added declaration for function used in DivPart Post action 
#  11-Nov-2014                       Vijayasekhar                      teradyne_update_change_history_on_dse_form_edit function declaration added
#  14-Nov-2014						 Haripriya                         Modified declaration for teradyne_create_form
#  22-Jan-2015						 Kameshwaran D.					   Added a new argument to the function "teradyne_update_change_history_on_dse_form_edit".
#  28-Jan-2015                       Vijayasekhar                      Added declaration for TD4_precondition_on_create_CommPartReqRevision
#  06-Feb-2015						 Haripriya                         Modified declaration for teradyne_validate_required_attribute.
#  16-Feb-2015						 Haripriya                         Added declaration for TD4_precondition_on_create_DivPartMapForm,TD4_postaction_on_refresh_Vendor
#  18-Feb-2015						 Vijayasekhar					   Added declarations for teradyne_attach_commlvl1form_on_sbmform_edit,teradyne_find_and_delete_relation and teradyne_get_class_name
#																	   Modified declarations for teradyne_check_form_with_name_already_exists, TD4_precondition_on_create_Form
#  18-Feb-2015                       Vijayasekhar                      Added boolean parameter for teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory
#  19-Feb-2015						 Haripriya                         Added declaration for TD4_postaction_on_create_InitiateWorkflow and Removed TD4_postacion_on_create_PartModReqRevision
#  05-Mar-2015						 Haripriya                         Modified declaration for teradyne_validate_required_attribute.
#  05-Mar-2015						 Kameshwaran D					   Added declaration for TD4_postaction_on_create_StandardECNRevision , TD4_postaction_on_create_ReleaseECNRevision and functions related to it.
#  06-Mar-2015						 Kameshwaran D					   Added declaration for teradyne_update_forms_of_createormodify_request.
#  23-Mar-2015						 Kameshwaran D					   Added declaration for TD4_postaction_on_save_PCNRevision function
#  16-Apr-2015						 Kameshwaran D					   Added declaration for TD4_postaction_on_save_SuppPartTransRevision
#  17-Apr-2015						 Selvi         					   Removed declaration for teredyne_replace_string
#  22-Apr-2015						 Kameshwaran D					   Added declaration for teradyne_get_usergroup_as_string
#  04-Jun-2015                       Vijayasekhar                      Added declaration for TD4_postaction_on_create_Scp0PartToSubsCmplResultRel
#  12-Jun-2015						 Haripriya                         Added declaration for teradyne_search_nextid.
#  18-Jun-2015                       Vijayasekhar                      Added declaration for teradyne_check_and_apply_revision_rule and TD4_precondition_on_copy_DocumentRevision
#  26-Jun-2015                       Vijayasekhar                      Added declaration for teradyne_latest_rev_from_rev
#  30-Jun-2015						 Vijayasekhar                      Added extra parameters to function teradyne_check_and_apply_revision_rule declaration to handle Revision skip letters
#  12-Aug-2015						 Haripriya                         Modified declaration for teradyne_search_nextid.
#  11-Dec-2015                       Manimaran                         Added declaration for pre-condition, postaction and functions related to BOM Import functionality.
#  22-Dec-2015                       Manimaran                         Removed the function teradyne_latest_rev_from_rev declaration.
#  26-Dec-2015                       Manimaran                         Modified the function teradyne_get_divpart_details_from_datasetname argument.
#  16-Mar-2016                       Manimaran                         Added declaration for TD4_postaction_on_copy_DocumentRevision.
#  04-Aug-2016						 Kameshwaran					   Added declaration for TD4_precondition_on_create_Relation and add one more arugment to teradyne_check_form_with_name_already_exists function.
#  30-May-2018						 Marjorie						   Added declaration for TD4_precondition_on_create_DesignDocument
#  05-July-2021                      Vikash B                          Added declaration for TD4_precondition_on_create_ImpactedItemRelation
#  $HISTORY$                    
#  =================================================================================================*/  

#ifndef TERADYNE_EXTENSIONS_H
#define TERADYNE_EXTENSIONS_H

#include <common/teradyne_common.h>

// all functions should be without C++ mangling
#include <libtd4teradyne_exports.h>

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_VMRepresentsRel(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_Relation(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_ImpactedItemRelation(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_delete_VMRepresentsRel(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postacion_on_create_DTGModlModReqRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postacion_on_create_TAGModlModReqRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_CommPartReqRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_CommPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_CommPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_DivPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_DivPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_preaction_on_save_Form(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_DesignDocument(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postacion_on_create_TAGModlCreReqRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_copy_DivPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_copy_DivPartRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_copy_DocumentRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_DivPartMapForm(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_refresh_Vendor(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_BVR(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_InitiateWorkflow(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_CommPartReqRevisionAWC(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_PartModifyRequestRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_StandardECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_StandardECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_ReleaseECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_ReleaseECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_DeviateNoticeRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_ProtoBOMECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_ProtoPartECNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_SuppPartTransRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_PartModReqRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_PCNRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel(string szPrefName,bool &bisValidationSuccess);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_ComEnggTranRqRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_DocumentRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_Scp0PartToSubsCmplResultRel(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_copy_DocumentRevision(METHOD_message_t *msg , va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_create_CMHasSolutionItem(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_TERBOMCSV(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_save_TERBOMCSV(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_save_CommPartReqRevision(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_VMRepresentsRel(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_save_DisciplineSpecificEditForms(METHOD_message_t*  msg, va_list args);


extern "C" TD4TERADYNE_API int TD4_postaction_on_save_MfgPart(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_postaction_on_DivPartRev_PartCategory_Change(METHOD_message_t*  msg, va_list args);

extern "C" TD4TERADYNE_API int TD4_precondition_on_create_DesignDocRev_RefMaterialRel(METHOD_message_t* msg, va_list args);



int teradyne_check_grm_create_or_delete_vmrepresentsrel_tcvendorpartrel(string szPrefName,bool &bisValidationSuccess);

int teradyne_check_form_with_name_already_exists(tag_t tObject, char*pcFormName, bool &bisEsxists,tag_t *tActSeqObjTag);

int teradyne_validate_required_attribute(tag_t tRevTag,std::map<string,string> strPropNameValueMap,char *pcUsername,bool bisCreate);

int teradyne_searchform_updateattributevalue(string szDivPartCatergoryName,string szDivPartSubCatergoryName,tag_t tCurRevTag,bool bisExecuteCondition,bool bisNew);

int teradyne_create_form (tag_t tRevTag,std::map<string,string> strFormTypeNameMap,bool bisSpecification);

int teradyne_update_trade_compliance_form(tag_t tRevTag,std::map<string,string> strPropNameValueMap);

int teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory(char*partCategory,char*partSubCategory,tag_t *tDivpartTag, bool bCheck = false);

int teradyne_update_change_history_on_dse_form_edit(tag_t tObject,char* pcTypeName); 

int teradyne_update_change_history_on_part_edit(tag_t tObject,char* pcTypeName);

int teradyne_update_change_history_on_mfgpart_edit(tag_t tObject, char* pcTypeName);

int teradyne_update_commpart_desc(tag_t tObject);

int teradyne_validate_attributes_CommPartReqRevision(tag_t tObject);

int teradyne_precondition_on_create_DivPartRevision(tag_t tIPItemTag, tag_t tRevTag, bool bisNew);

int teradyne_attach_commlvl1form_on_sbmform_edit(tag_t tRevTag);

int teradyne_find_and_delete_relation(tag_t tComodityRelType, tag_t tPrimaryObj);

int teradyne_get_class_name(tag_t tObject, char** pcClassName);

int teradyne_update_forms_of_createormodify_request(tag_t tRevTag,int iCreateReqFlag,bool bMapModelUpdate);

int teradyne_create_additional_reviewer_form(tag_t tRevTag,std::map<string,string> strFormTypeNameMap);

int teradyne_attachorremove_project_form_with_ProjectRel(tag_t tRevtag, int flagOnSave);

int teradyne_initiate_workflow_based_on_argument(char* strWorkFlowName,tag_t tRevTag);

int teradyne_get_usergroup_as_string(string *szUsergroup);

int teradyne_search_nextid(char** nextId);

int teradyne_check_and_apply_revision_rule(tag_t tPrevRevTag,char *pcRevid, int iExcludedLovValues = 0, char* pcExcludedLovValues = NULL);

int teradyne_get_divpart_details_from_datasetname(char *pcDatasetName, tag_t *tDivPartsLatestRev, char **pcDivPartsID, char **pcDivPartsRevID);

int teradyne_search_dataset_based_on_divpartid_and_divpartrevid(char *pcDivPartIDs, char *pcDivPartRevIDs, int *iTotalRow, void ****pvQueryResult);

int teradyne_validateObjectBeforeCheckIn(tag_t tObject);

int teradyne_performActionAfterCheckIn(tag_t tObject);

int teradyne_create_discipleSpecificForms(tag_t tRevTag);

int teradyne_create_divpart_designDocs(tag_t tRevtag);

int teradyne_transform_change_history(char *pcChangeHistory, char **pcFormattedChangeHistory);

int replace_all_string(string& data, string toSearch, string replaceStr);
int teradyne_create_ChangeHistoryForms(tag_t tRevTag);
#include <libtd4teradyne_undef.h>

#endif
