/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                  Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_common.h          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Common header file         
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  31-Oct-2014                       Haripriya                          Added declaration for common function used in DivPart Post action
#  1-Nov-2014                        Vijayasekhar                       Added declarations for teradyne_current_timestamp
#  14-Nov-2014                       Vijayasekhar                       Added declarations for common function related to handlers
#  14-Nov-2014                       Haripriya							Added declarations for teradyne_create_object	
#  17-Nov-2014                       Vijayasekhar                       Added declaration for getting target objects of workflow process
#  28-Jan-2015                       Haripriya                          Added declaration for teradyne_send_os_mail,teradyne_os_mail_body,teradyne_ask_person_mailaddress
#  12-Feb-2015                       Vijayasekhar                       Added declaration for teradyne_ask_item_id_from_rev_tag
#  12-Feb-2015						 Selvi 								Added declaration for functions to set bypass application.
#  18-Feb-2015                       Vijayasekhar                       included the header CreateInput.h
#  12-Mar-2015						 Vijayasekhar						Modified the function declaration teradyne_get_attachments and added signoff header
#  16-Mar-2015						 Selvi 								Added declaration for functions of ECN Summary Report.
#   17-Mar-2015                       Haripriya                          Added declaration for teradyne_get_arrayproperty_value,teradyne_set_arrayproperty_value function.
#  18-Mar-2015						 Vijayasekhar						Added declarations teradyne_parse_input_date and teradyne_get_week_from_date.
#  20-Mar-2015						 Vijayasekhar						Added declarations teradyne_assign_task_to_users.
#  24-Mar-2015						 Vijayasekhar						Added declarations teradyne_list_all_revisions_from_revtag
#  30-Mar-2015						 Vijayasekhar						Modified the function declaration teradyne_current_timestamp
#  15-Apr-2015						 Haripriya						    Added declaration for functions to set bypass application after release status.
#  16-Apr-2015						 Vijayasekhar						Added header file #include <qry\crf.h> related to Teradyne-GenDeviationReport handler
#  17-Apr-2015						 Selvi						        Added declarations for teredyne_replace_string.
#  20-Apr-2015                       Haripriya                          Modified declaration for teradyne_get_arrayproperty_value.
#  21-Apr-2015						 Selvi						        Added declarations for teradyne_convert_xls2xlsx.
#  24-Apr-2015						 Selvi						        Added header file #include <tccore\workspaceobject.h>
#  07-May-2015                       Vijayasekhar						Added function declarations teradyne_delete_relation and added the header vms.h
#  07-May-2015                       Selvi                              Added Function teradyne_find_execute_qry and removed teradyne_find_latest_released_revision.
#  29-May-2015						 Kameshwaran D						Added Function teradyne_UpdateTerPartRevComplAtr
#  10-Jun-2015                       Haripriya                    	    Removed Function teradyne_UpdateTerPartRevComplAtr
#  30-Jun-2015						 Vijayasekhar                       Added header file <lov\lov.h> 
#  07-Jul-2015                       Haripriya                          Added teradyne_find_prev_revision function declaration.
#  12-Nov-2015                       Manimaran                          Added teradyne_convert_vector_to_array function declaration.
#  11-Dec-2015                       Manimaran                          Added header file #include <sa\am.h>
#  17-Dec-2015						 janani								Added teradyne_create_dataset function
#  22-Dec-2015                       Manimaran                          Added function teradyne_latest_rev_from_rev declaration.
#  23-Dec-2015                       Manimaran                          Added header file <tc\aliaslist.h>
#  19-Sep-2016                       Rodji                              Added set
#  4 -Dec-2020                       Anandha Bharathi R                 Added function that will validate owning Group as UR,if then update Item Status Property Value in Change Admin Form
#  $HISTORY$                    
#  =================================================================================================*/  

#ifndef TERADYNE_COMMON_H
#define TERADYNE_COMMON_H

#include <sys/timeb.h>
#include <time.h>
#include <tccore/method.h>
#include <iostream>
#include <climits>
#include <regex>
#include <functional> 
#include <cctype>
#include <locale>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pie/pie.h>
#include <property/prop.h>
#include <tc/preferences.h>
#include <tccore/custom.h>
#include <tcinit/tcinit.h>
#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <map>
#include <strstream>
#include <sstream>
#include <fstream>
#include <bom/bom.h>
#include <ae/ae.h>
#include <sa/tcfile.h>
#include <res/res_itk.h>
#include <sa/audit.h>
#include <sa/auditmgr.h>
#include <tchar.h>
#include <algorithm>
#include <itk/bmf.h>
#include <cfm/cfm.h>
#include <iterator>
#include <fclasses/tc_string.h>
#include <fclasses/tc_date.h>
#include <epm/epm.h>
#include <form/form.h>
#include <epm/epm_task_template_itk.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <sa/sa.h>
#include <pom/enq/enq.h>
#include <common/teradyne_trace.h>
#include <common/teradyne_constants.h>
#include <list>
#include <tc\folder.h>
#include <tc\tc_arguments.h>
#include <tc\iman_arguments.h>
#include <epm\signoff.h>
#include <property\nr.h>
#include <qry\crf.h>
#include <tccore\workspaceobject.h>
#include <vm\vms.h>
#include <lov\lov.h>
#include <sa\am.h>
#include <tc\aliaslist.h>
#include <property\legacy_counter.h>
#include <tccoreext\gde.h>
#include <Fnd0Participant/participant.h>
#include<curl\curl.h>


#include<stdlib.h>
#include<tc\tc.h>
#include<tccore\item.h>
#include<tccore\custom.h>
#include<tccore\grm.h>
#include<epm\epm.h>
#include<tccore\aom_prop.h>
#include<bom\bom.h>
#include<cfm\cfm.h>
#include<ae\dataset.h>
#include<ae\ae.h>
#include<tccore\tctype.h>
#include<tc\tc_startup.h>
#include<fclasses\tc_string.h>
#include <vector>
#include <string>
#include <iostream>
#include <map>

#pragma comment(lib, "rpcrt4.lib")
#include<rpc.h>
#include<iomanip>

using namespace std;

// Use to free mem
#define Custom_free(p) {\
    if ( p != NULL ) {\
        MEM_free(p); \
        p = NULL;\
    }\
}
// All function declarations without C++ mangling

//Trim string
#define TRIM_TEXT(sValue) {\
	size_t p = sValue.find_first_not_of(" \t"); \
	sValue.erase(0, p); \
	p = sValue.find_last_not_of(" \t");\
	if (string::npos != p)\
	sValue.erase(p+1);\
}

#ifdef __cplusplus
         extern "C"{
#endif

extern void AM__set_application_bypass(bool b);

extern void POM_AM__set_application_bypass(bool b);

int teradyne_ask_object_type(tag_t tObj_type,char** strTypeName);

int teradyne_ask_object_display_type(tag_t tObject,char** pcTypeName);

int teradyne_create_process(string strProcessTemplateName,string strDescription,int iAttachmentType,tag_t tAttachmentObject,tag_t *tNewProcess);

int teradyne_get_current_user_and_group(char** pcUsername, char** pcRoleName, char** pcGroupName, char** pcGroupFullName, tag_t* tUserTag, tag_t* tRoleTag, tag_t* tGroupTag);

int teradyne_setproperty_value(tag_t tRevtag,string szPropname,string pcPropvalue);

int teradyne_getproperty_values(tag_t tRevTag,std::list<string> strAttr,std::map<string,string> &strPropNameValueMap);

int teradyne_getprimaryorsecondary_relation_objecttag(tag_t tObjecttag,string szRelName,string szObjecttype,int iRelType,tag_t *ObjFoundTag);

int teradyne_create_object(string szTypeName,string szObjectName,tag_t *tCreObj); 

int teradyne_get_attachments(tag_t tTask, int iAttachType, int *iAttachCount, tag_t **ptAttaches);

int teradyne_get_root_task(tag_t tTask, tag_t *tRootTask);

int teradyne_current_timestamp(string strFormat, string &strTimeStamp, date_t &curDate);

int teradyne_ask_person_mailaddress(tag_t tSenderTag,char** pcSenderEmailAddr);

int teradyne_os_mail_body(string szMailBodyFilePath,string szMailContent);

int teradyne_send_os_mail(string szSubject,string szMailBodyFilePath,string szToMailAddress);

int teradyne_find_execute_qry(char *pcQueryName, std::map<string,string> strQryEntriesMap, int* count,tag_t** ptLatestRev);

int teradyne_ask_item_id_from_rev_tag(tag_t tObject,char** pcItemId);

void teradyne_get_handler_opts (IMAN_argument_list_t* givenArgList, char* pcGivenOptions, ...);

int teradyne_get_arrayproperty_value(tag_t tRevTag,string szpropname,std::vector<std::string> &VectorValues,string szpropertyname,bool bcheck);

int teradyne_set_arrayproperty_value(tag_t tRevtag,string szPropname,int iPropCnt,char** pcPropvalue);

int teradyne_get_week_from_date (string strInputDate, string &strGetWeek);

int teradyne_parse_input_date(string strInputDate, int* iYear, int* iMonth, int* iDay);

int teradyne_assign_task_to_users(tag_t tTask, tag_t tUser = NULLTAG, const char* pcRole = NULL, const char* pcGroup = NULL, const char* pcUser = NULL);

int teradyne_list_all_revisions_from_revtag(tag_t tRevOfItem, int* iRevs, tag_t** tRevs);

bool teradyne_is_workspace_object(tag_t tObjectTag);

int teradyne_create_and_attach_dataset (char  *cDatasetName, char  *cDatasetDesc, char  *cDatasetType, char  *cFormatName, char  *cDatasetRefName,         
                                        char  *cReferenceName, char  *cRelationTypeName, AE_reference_type_t ref_type, tag_t  tagRevTag, tag_t *tagNew_dataset);
void setgNULLPropertyExecution(bool setBool);

int teradyne_convert_xls2xlsx(string strxlsPath, string &strOutxlsxPath);

int teradyne_delete_relation(tag_t tPrimary, tag_t tSecondary, const char* strRelTypeName);

int teradyne_find_prev_revision(tag_t tObjTag,tag_t *tprevTag);

int teradyne_convert_vector_to_array( vector<string> VectorValues,char ***pctechreviewerarray);

int teradyne_create_dataset(char  *cDatasetName, char  *cDatasetDesc, char  *cDatasetType, char  *cFormatName, char  *cDatasetRefName,         
                                        char  *cReferenceName, AE_reference_type_t ref_type, tag_t *tagNew_dataset);

int teradyne_latest_rev_from_rev(tag_t tRev, tag_t* tLatestRev);

int teradyne_export_file_to_temp(tag_t tDataset, tag_t tNamedRef, string strRefName, string &strFilePath);

int teradyne_get_object_tag(const char* objectName,char* objectType,tag_t *objectTag);

int teradyne_get_cbu_from_project(tag_t tObjTag, const char* projAttr, char **pcCBU);

int teradyne_update_rejection_comments(tag_t task,string comment);

int teradyne_send_to_ERP(const char* eventType, tag_t objTagRev,bool skipT4OPush);

int teradyne_update_object_name(tag_t objTagRev);

std::string replaceLine( std::string line, const std::string& substr,const std::string& replace_with );

int teradyne_create_form(tag_t tRevTag, std::map<string, string> strFormTypeNameMap, bool bisSpecification);

int teradyne_getCOOValueforVendoPart(tag_t tVendorPart, char ** cooVendorPart, int isMFGPart);


int teradyne_AddToTagArray(tag_t tObject, int piNumTags, tag_t **pTagArray);

int teradyne_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);

int teradyne_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);

int teradyne_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag);


int TER_Repair_Builder_Filter_validation(const char* pcName, int iNumArgs, char** pcEntriesNames, char** pcEntriesValues, int* iNumFound, tag_t** tFound);
struct Date {
	int d, m, y;
};



const int monthDays[12] = { 31, 28, 31, 30, 31, 30,31, 31, 30, 31, 30, 31 };
int countLeapYears(Date d);

int getDifference(Date dt1, Date dt2);



#ifdef  __cplusplus
}
#endif

vector<string> teradyne_generate_tokens(std::string inputStr, std::string delimiterFormat);
string teredyne_replace_string(std::string &strDirPath, std::string toReplace, std::string replaceWith);

int teradyne_find_entry_exist(map<int,vector<string>> findMap, int Position,string matchVal,bool *found,int fndNoColmPos=0,bool FindNoCheck=false);
//map<string,int> teradyne_read_csv_header(string strFileName,bool *bFndNo,string *strHeader,string *err);
map<int,vector<string>> teradyne_correct_bom_find_no(map<int,vector<string>> *mapCsvFileData,int prtAssPos,int findno_pos,int qtypos,bool bZeroQnty,bool bFindNo);
bool  teradyne_check_same_findno_diff_component(map<int, vector<string>>crctCsvFileEntryMap, int checkFndNo, string PrtAssNo, int FndNoPos, int PrtAssPos, map<int, string> *mapFndCompnt);


std::vector<std::string> splitString(std::string theString, string delim, bool splitQuotes);

std::string &ltrim(std::string &s);
std::string &rtrim(std::string &s);
std::string &trim(std::string &s);
bool isDigitWSAllowed(std::string str);
bool isAlphaWSAllowed(std::string str);
bool isAlphaNumericWSAllowed(std::string str);
bool isAlphaNumericStrict(std::string str);
std::string incrementedAlpha(std::string str);
void getNextAlpha(string &buf, int pos, bool alphaNum);
std::string teradyneBuildNotificationSubject(EPM_action_message_t msg);
std::string teradyneBuildNotificationBodyContent(EPM_action_message_t msg);
std::string teradyneBuildSubscriptionSubject(tag_t tItemRevTag, string subscriptionName);
std::string teradyneBuildSubscriptionBodyContent(tag_t tItemRevTag, string subscriptionName);
std::string teradyneBuildEmailNotificationSubject(EPM_action_message_t msg, tag_t targetObjTag);
std::string teradyneBuildEmailNotificationSubjectRelease(EPM_action_message_t msg, tag_t targetObjTag);
std::string teradyneBuildEmailNotificationSubjectProtoBOM(EPM_action_message_t msg, tag_t targetObjTag);
int teradyneGenerateNextTestRevisionID(char *currRevID,char **newRevID);
bool hasInvalidChar(char* text, char **invalid);

int ur_validateOwningGroup();
int ur_CommPart_postAction(tag_t tRevtag);
int ur_DivPart_PostAction(tag_t tRevTag, string szDivPartCatergoryName, string szDivPartSubCatergoryName, bool bisNew);
int mir_getDivCommPartPostAction(tag_t tRevTag, string szDivPartCatergoryName, string szDivPartSubCatergoryName, bool bisNew);
int ur_divpart_CMAdminRole_PostAction(tag_t iRevTag);
int ur_CommPartCMAdminRole_postAction(tag_t tRevtag);
bool hasEnding(std::string const &fullString, std::string const &ending);

int teradyne_current_time_utc(string strFormat, string &strTimeStamp, date_t &curDate);

template <typename T>
string toString ( T Number )
{
	 ostringstream ss;
	 ss << Number;
	 return ss.str();
}


string teradyne_get_vPreferedStat(string);
void teradyne_set_vPreferedStat_with_uid(string sKey, string sValue);
void teradyne_remove_vPreferedStat_ele(string );

// Class Declarations
class Logger
{
private:
	bool isFileOpen;
	string strFilePath;
	string strFileName;
	ofstream outfile;
	bool bwasFileWritten;
public:
	enum LogLevel
	{
		INFO_LEVEL = 0,
		DEBUG_LEVEL = 1,
		ERROR_LEVEL = 2,
		WARN_LEVEL = 3
	};

	Logger();
	~Logger();

	void createLogFile(string strName, string strFileExt);

	void log(string data, Logger::LogLevel logL);

	void log(string data);

	void closeFile();

	string getFilePath();

	string getFileName();

	bool getisFileOpen();

	bool getWasFileWritten();

};

#endif
