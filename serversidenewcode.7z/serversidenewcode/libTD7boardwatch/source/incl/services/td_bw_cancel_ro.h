#pragma once
# ifndef TD_BW_CANCEL_RO
# define TD_BW_CANCEL_RO

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

	TERADYNE_SERVICE_EXPORT int td_bw_cancel_ro(std::string roUID);
	TERADYNE_SERVICE_EXPORT int td_set_config_objects_as_repaired(tag_t tRepairOrderRev);
	TERADYNE_SERVICE_EXPORT int set_config_objects_status(int tRepairOrderRev, string relationType);
#ifdef __cplusplus
}
#endif
#endif 