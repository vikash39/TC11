
# ifndef TERADYNE_SERVICES_H
# define TERADYNE_SERVICES_H

#include <common/teradyne_common.h>
#include <services/teradyne_services_exports.h>

#ifdef __cplusplus
extern "C" {
#endif

	TERADYNE_SERVICE_EXPORT int libTD7_teradyne_services_register_callbacks();

#ifdef __cplusplus
}
#endif

#endif //TERADYNE_SERVICES_H