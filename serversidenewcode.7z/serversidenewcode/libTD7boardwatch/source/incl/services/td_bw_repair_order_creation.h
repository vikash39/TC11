# ifndef TD_BW_REPAIR_ORDER_CREATION_H
# define TD_BW_REPAIR_ORDER_CREATION_H

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//Initiate Repair order creation
	TERADYNE_SERVICE_EXPORT int td_bw_repair_order_creation_execute(vector<string> vRoInput);

	/* 
	repairOrderInput["sCustomerID"] = roInput[0];
	repairOrderInput["sCustomerOrderNumber"] = roInput[1];
	repairOrderInput["sCustomerOrderStatus"] = roInput[2];
	repairOrderInput["sCustomerProgram"] = roInput[3];
	repairOrderInput["sCustomerSite"] = roInput[4];
	repairOrderInput["sESuspenseFlag"] = roInput[5];
	repairOrderInput["sMerlinOrderCreationDate"] = roInput[6];
	repairOrderInput["sOrderType"] = roInput[7];
	repairOrderInput["sPartDescription"] = roInput[8];
	repairOrderInput["sPartNumber"] = roInput[9];
	repairOrderInput["sPartRevStamp"] = roInput[10];
	repairOrderInput["sPartSerialNumber"] = roInput[11];
	repairOrderInput["sRepairLocation"] = roInput[12];
	repairOrderInput["sRepairOrderID"] = roInput[13];
	repairOrderInput["sSPRFlag"] = roInput[14];
	repairOrderInput["sServiceType"] = roInput[15];
	repairOrderInput["sSystemSerialNumber"] = roInput[16];

	*/



	//Read vector of values
	TERADYNE_SERVICE_EXPORT int validate_and_start_process(vector<string> vRoInput, int &strErroCode);
	
	//check customer availibility
	TERADYNE_SERVICE_EXPORT int get_customer_rev(string sCustomerId, tag_t& tCustomerRev);

	//search hla serial number
	//TERADYNE_SERVICE_EXPORT int query_item(string sItemId, string sType, int iCount, tag_t& tItemRev);
	
	//query for div part/rev
	//TERADYNE_SERVICE_EXPORT int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev);

	//create repair managed part
	TERADYNE_SERVICE_EXPORT int create_repair_managed_part(string sPartNumber, string sPartNumberRev, string sPartDesc, tag_t& tRepManagePartRev);

	//create hla serial number
	TERADYNE_SERVICE_EXPORT int create_attach_serial_number_ro_creation(string sSerialNumberId, string sObjectName, string sLLARevStamp,tag_t tPartRev, tag_t& tSerialNumRev);

	//create repair order
	TERADYNE_SERVICE_EXPORT int create_repair_order(string sRepairOrderNumber, tag_t tSerialNumberRev, vector<string> vtRoRevProps, tag_t& tRepairOrderRev);

	//create repair order
	TERADYNE_SERVICE_EXPORT int query_lla_serial_number_ro_creation(string sLLASerialNumberID, string sType, int iCount, tag_t& tQueriedSerialRev);

	//create repair order
	TERADYNE_SERVICE_EXPORT int get_serial_number_revision_based_on_revstamp_with_ro_creation(tag_t tLLASerial, string sLLARevStamp, tag_t& tLLASerialRev);

	//create repair order
	TERADYNE_SERVICE_EXPORT int get_hla_part_number(vector<string> vRoInput, tag_t &tQueriedDivPartRev);

	//create repair order
	TERADYNE_SERVICE_EXPORT int get_divisionla_part_with_revstamp_create_repairorder(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev);
	
	//create customer order
	TERADYNE_SERVICE_EXPORT int create_attach_customer_order(string sCustomerOrderNumber,tag_t tRepairOrderRev,tag_t tCustomerRev, tag_t& tCustomerOrderRev);

	//initiate workflow on repair order
	TERADYNE_SERVICE_EXPORT int initiate_workflow_on_repair_order(string sWorkflowName, tag_t tRepairOrderRev);

	//TERADYNE_SERVICE_EXPORT int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	TERADYNE_SERVICE_EXPORT int query_to_attach_template_excel(string datasetName, tag_t& tQueriedDataSet);

	TERADYNE_SERVICE_EXPORT int assign_repair_order_participants(tag_t tRepairOrderRev, char* sParticipantName, char* sGroupName, char* sRoleName);

	//TERADYNE_SERVICE_EXPORT int revise_object(tag_t tItem, tag_t& tItemReviseTag);

	TERADYNE_SERVICE_EXPORT int attach_commercial_part(tag_t tCommercialPart, tag_t tDivPartRev, tag_t tRepManagedPartRev);

	TERADYNE_SERVICE_EXPORT int validate_closure_value_of_existing_repair_orders(tag_t tSecondaryObj, bool &bValidClosureValue);

	TERADYNE_SERVICE_EXPORT int is_psn_attched_with_lla_ro_creation(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound);

	TERADYNE_SERVICE_EXPORT int assign_project_team(tag_t tRepairOrderRev, tag_t tHLAPartRev);

	TERADYNE_SERVICE_EXPORT int assign_project_team_members_into_signoff_ro_creation(tag_t tRepairOrderRev, tag_t tProjectTag);

	TERADYNE_SERVICE_EXPORT int create_checklist_form_ro_creation(tag_t tRepairOrderRev, string tFormType, string sObjName, string sFormName);

#ifdef __cplusplus
}
#endif

#endif 