# ifndef TD_BW_VALIDATE_REFERENCE_DESIGNATOR
# define TD_BW_VALIDATE_REFERENCE_DESIGNATOR

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

	
	TERADYNE_SERVICE_EXPORT void tostring_soa(char str[], int num);

	TERADYNE_SERVICE_EXPORT char* Charactervalues_soa(char *inputLine);

	TERADYNE_SERVICE_EXPORT char *NumericValues_soa(char *inputLine);

	TERADYNE_SERVICE_EXPORT int traverse_BOM_reference_designator(tag_t tBomLineRevisionTag, std::string componentPartNumber, std::string sUserRefDesignValue, std::string &validWarningMsg, vector<tag_t> &bomLineTags, bool &isInBomLine);

	TERADYNE_SERVICE_EXPORT int td7_validate_bom_line(tag_t tLLApartNumber, std::string componentPartNumber, std::string refDesignValue, tag_t tSerialNumRev, std::string  &refDesignWarningMsg);

	TERADYNE_SERVICE_EXPORT int compare_reference_designator(std::string ActualValue, std::string TargetValue, bool &isValid);
	TERADYNE_SERVICE_EXPORT int compare_ref_designator_strings(string dbRefDesignator, string userRefDesignator, bool &isValidaRefDesignator);
	
	//TERADYNE_SERVICE_EXPORT int teradyne_split(std::string str, char delimiter, std::vector<std::string> &vResult);
#ifdef __cplusplus
}
// validate reference designator
TERADYNE_SERVICE_EXPORT string validate_reference_designator(std::string referenceDesignator, std::string serialNumberUID, std::string componentPartNumber);
TERADYNE_SERVICE_EXPORT string split_reference_designator_validate_ref_design(std::string originalReferenceDesignator);
#endif

#endif