
#ifndef TERADYNE_SERVICES_EXPORTS_H
#define TERADYNE_SERVICES_EXPORTS_H


#if defined(SERVICES_EXPORTS)
# if defined(_WIN32)
#       define TERADYNE_SERVICE_EXPORT     __declspec(dllexport)
#   else
#       define TERADYNE_SERVICE_EXPORT
#   endif
#else
#  if defined(_WIN32)
#       define TERADYNE_SERVICE_EXPORT      __declspec(dllimport)
#   else
#       define TERADYNE_SERVICE_EXPORT
#   endif
#endif

#endif  //TERADYNE_SERVICES_EXPORTS_H


