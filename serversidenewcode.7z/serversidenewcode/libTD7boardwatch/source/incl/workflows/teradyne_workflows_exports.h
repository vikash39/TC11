
#ifndef TERADYNE_WORKFLOWS_EXPORTS_H
#define TERADYNE_WORKFLOWS_EXPORTS_H


#if defined(WORKFLOWS_EXPORTS)
# if defined(_WIN32)
#       define TERADYNE_WORKFLOW_EXPORT     __declspec(dllexport)
#   else
#       define TERADYNE_WORKFLOW_EXPORT
#   endif
#else
#  if defined(_WIN32)
#       define TERADYNE_WORKFLOW_EXPORT      __declspec(dllimport)
#   else
#       define TERADYNE_WORKFLOW_EXPORT
#   endif
#endif

#endif  //TERADYNE_WORKFLOWS_EXPORTS_H


