
#ifndef LOGGER_HXX
#define LOGGER_HXX
#include "teradyne_common_exports.h"
#include "teradyne_common.h"
#include "teradyne_trace_handling.h"
#include "TeradyneUtils.hxx"

#include <tc/LoggedInUser.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Timer.hxx>
#include <base_utils/OSEnvironment.hxx>
#include <fclasses/OSFile.hxx>
#include <fclasses/OSDirectory.hxx>


#include <iostream>
#include <string.h>
#include <vector>
#include <map>

#include <metaframework/BusinessObjectRef.hxx>
#include <base_utils\Timer.hxx>


using namespace std;
using namespace Teamcenter;
using namespace TERADYNE;

namespace TERADYNE {
	namespace COMMON 
	{
		class TERADYNECOMEXPCLASS Logger 
		{
		protected:
			tag_t	tDataset;
			string	sLogFileName;
			string	sLogFileFormat;
			string	sAbsLogFilePath;			
			ofstream	ofsTransLogFile;


			/**
			* \file  Logger.hxx
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			This function will validate input file path of logger file.
			* \verbatim
			\endverbatim
			* \param [in]        string input log File Path.
			* \param [in]        string File Format.		
			* \par Algorithm:
			* \verbatim  					
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			* \verbatim
			\endverbatim
			*/
			int validateLogFilePath(string sInputLogPath, string sFormat);				

			/**
			* \file  Logger.hxx
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			This function will create logger file.
			* \verbatim
			\endverbatim
			* \param [in]        string File Name.
			* \param [in]        string File Format.
			* \par Algorithm:
			* \verbatim  				
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			* \verbatim
			\endverbatim
			*/
			int createLogFile(string sFileNameWithoutExt, string sFileFormat);	

			/**
			* \file  Logger.hxx
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			This function will close logger file.
			* \verbatim
			\endverbatim			
			* \par Algorithm:
			* \verbatim 				
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			* \verbatim
			\endverbatim
			*/
			int closeLog();

		public:

			/**
			* \file  Logger.hxx
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			This function will return absolute file path of logger file.
			* \verbatim
			\endverbatim
			* \param [out]        string absolute log file path.
			* \par Algorithm:
			* \verbatim  
			1.Return the  absolute file path of logger file.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			* \verbatim
			\endverbatim
			*/
			int getLogAbsoluteFilePath(string &sAbsoluteFilePath);

			/**
			* \file  Logger.hxx
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			This function will validate input file path of logger file.
			* \verbatim
			\endverbatim
			* \param [out]        tag_t Dataset tag.			
			* \par Algorithm:
			* \verbatim  
			1.Returns tag of datast.		
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			* \verbatim
			\endverbatim
			*/
			int getLogDataset(tag_t &tinputDataset);


			//destructor
			~Logger();

		};
	}
}
#endif // LOGGER_HXX
