/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_import_repair_config.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int repair_config_uploader_workflow(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;

	/**int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t *tpReferencedObject = NULL;

	char *cpDatasetName = NULL;
	int namedreferencedCount = 0;
	char *cpNrPathname = NULL;
	fstream Readingfile;

	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_AND_THROW(EMH_clear_errors());

		TERADYNE_TRACE_AND_THROW(EPM_ask_root_task(msg.task, &tRootTask));

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_AND_THROW(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments));

		TERADYNE_TRACE_AND_THROW(AOM_ask_value_string(tpAttachments[0], "object_name", &cpDatasetName));

		//Loop through all the target attachments.
		for (int i = 0; i < iAttachmentCount; i++)
		{
			TERADYNE_TRACE_AND_THROW(AE_ask_dataset_named_refs(tpAttachments[i], &namedreferencedCount, &tpReferencedObject));

			for (int j = 0; j < namedreferencedCount; j++) {
				TERADYNE_TRACE_AND_THROW(IMF_ask_file_pathname2(tpReferencedObject[j], SS_WNT_MACHINE, &cpNrPathname));
				Readingfile.open(cpNrPathname, ios::in);
				if (Readingfile.is_open())
				{
					string inputline = "";
					while (getline(Readingfile, inputline))
					{
						vector<string> vSplittedValues;
						//TERADYNE_TRACE_AND_THROW(split_input_values(inputline, vSplittedValues));
						cout << "inputline" << inputline << endl;
						//TERADYNE_TRACE_AND_THROW(TeradyneUtils::teradyne_split(inputline, ',', vSplittedValues));
						TERADYNE_TRACE_AND_THROW(teradyne_split(inputline, ',', vSplittedValues));
						cout << "vSplittedValues.size()" << vSplittedValues.size() << endl;

						TERADYNE_TRACE_AND_THROW(read_record_import_repairconfigcsv(cpDatasetName, vSplittedValues));
					}
				}
			}
		}

		TERADYNE_TRACE_AND_THROW(EPM_trigger_action(tRootTask, EPM_complete_action, NULL));

	}
	catch (...)
	{

	}
	//Free Memory
	TERADYNE_MEM_FREE(tpAttachments);
	TERADYNE_MEM_FREE(tpReferencedObject);
	TERADYNE_MEM_FREE(cpDatasetName);
	TERADYNE_MEM_FREE(cpNrPathname);
	TERADYNE_MEM_FREE(tpAttachments);


	TERADYNE_TRACE_LEAVE();*/
	return iStatus;
}

int read_record_import_repairconfigcsv(string sRepairOrderNumber, vector<string> inputValues) {
	int iStatus = ITK_ok;
	/**bool bIsNull = false;
	tag_t tRepairOrder = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tHLAPart = NULLTAG;
	tag_t tHLAPartRev = NULLTAG;
	tag_t tPartNumber = NULLTAG;
	tag_t tPartNumberRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	//tag_t tRepManagedPart=NULLTAG;
	//tag_t tRepManagedPartRev=NULLTAG;

	string sLLASerialNumber = inputValues[0];
	string sLLAPartNumber = inputValues[1];
	string sLLAPartRevId = inputValues[2];
	string sRevStamp = inputValues[3];

	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_find_item(sRepairOrderNumber.c_str(), &tRepairOrder));

		if (tRepairOrder != NULLTAG) {
			TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tRepairOrder, &tRepairOrderRev));

			BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tRepairOrderRev);

			std::string sDivPart("");
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_PART_NUMBER, sDivPart, bIsNull));
			string sPartType = TD4_DIVISIONAL_PART;

			if (sDivPart.empty()) {
				TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_COMM_PART_NUMBER, sDivPart, bIsNull));
				sPartType = TD4_COMMERCIAL_PART;
			}

			std::string sRepManagedPart("");
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_REP_MANAGE_PART, sRepManagedPart, bIsNull));
			int iCount = 0;

			if (!sLLAPartNumber.empty()) {

				if (!sRepManagedPart.empty()) {
					sPartType = TD7_REPAIR_MANAGED_PART;

				}
				//TERADYNE_TRACE_AND_THROW(ITEM_find_item(sLLAPartNumber.c_str(), &tPartNumber));
				TERADYNE_TRACE_CALL(query_lla_serial_number_revs(sLLAPartNumber, sPartType, iCount, tPartNumber));

				if (tPartNumber != NULLTAG) {
					std::string sPartRevType("");

					// To set the part revision type for LLA Part
					if (tc_strcmp(sPartType.c_str(), TD4_DIVISIONAL_PART) == 0) {
						sPartRevType = DIVISIONAL_PART_REVISION;
					}
					if (tc_strcmp(sPartType.c_str(), TD4_COMMERCIAL_PART) == 0) {
						TERADYNE_TRACE_CALL(ITEM_find_revision(tPartNumber, sLLAPartRevId.c_str(), &tPartNumberRev));
					}
					if (tc_strcmp(sPartType.c_str(), TD7_REPAIR_MANAGED_PART) == 0) {
						sPartRevType = REP_MANAGED_PART_REVISION;
					}

					if (!sPartRevType.empty()) {
						TERADYNE_TRACE_CALL(query_div_and_rep_mang_part_revs(sLLAPartNumber, sLLAPartRevId, sPartRevType, iCount, tPartNumberRev));
					}

					if (tPartNumberRev == NULLTAG) {
						int iRepCount = 0;
						tag_t tRepairMenagePartRev = NULLTAG;

						TERADYNE_TRACE_CALL(query_item(sLLAPartNumber, REP_MANAGED_PART, iRepCount, tPartNumber));
						if (tPartNumber != NULLTAG) {
							TERADYNE_TRACE_CALL(query_div_and_rep_mang_part_revs(sLLAPartNumber, sLLAPartRevId, TERADYNE_THIRD_PART_REV, iRepCount, tRepairMenagePartRev));
							if (tRepairMenagePartRev != NULLTAG) {
								tPartNumberRev = tRepairMenagePartRev;
							}
							else {
								revise_object(tPartNumber, tRevisedObject);
								tPartNumberRev = tRevisedObject;
							}
						}
						else {
							TERADYNE_TRACE_CALL(teradyne_create_custom_object(TD7_REPAIR_MANAGED_PART, sLLAPartNumber, sLLAPartRevId, REP_MANAGED_PART, tPartNumber));
							if (tPartNumber != NULLTAG) {
								TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tPartNumber, &tPartNumberRev));
							}
						}
						// Update repair revision property for Repair Managed Part
						BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tPartNumberRev);
						AcquireLock lockOnRepairManagedPart(boRepairManagedPartRev);

						if (tc_strcmp(sLLAPartRevId.c_str(), "") != 0 && tc_strcmp(sLLAPartRevId.c_str(), NULL) != 0) {
							TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REPAIR_REVISION, sLLAPartRevId, false)));
						}
					}
				}
				else {
					//if (!sDivPart.empty()) {

					//	//	iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CUSTOMER_NOT_FOUND, vRoInput[0].c_str());
					//	//	iStatus = TERADYNE_CUSTOMER_NOT_FOUND;
					//	//	throw iStatus;

					//	iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_DIVPART_NOT_FOUND, sLLAPartNumber.c_str());
					//	iStatus = TERADYNE_DIVPART_NOT_FOUND;
					//	throw iStatus;
					//}
					//else if (!sRepManagedPart.empty()) {

					// Requirement change: If LLA Part Number is not exists, create "Repair Managed Part"
					TERADYNE_TRACE_CALL(query_lla_serial_number_revs(sLLAPartNumber, TD7_REPAIR_MANAGED_PART, iCount, tPartNumber));
					if (tPartNumber == NULLTAG) {
						TERADYNE_TRACE_CALL(teradyne_create_custom_object(TD7_REPAIR_MANAGED_PART, sLLAPartNumber, sLLAPartRevId, REP_MANAGED_PART, tPartNumber));
					}
					if (tPartNumber != NULLTAG) {
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tPartNumber, &tPartNumberRev));
					}

					//}
				}

				if (tPartNumberRev != NULLTAG) {
					tag_t tLLAPart = NULLTAG;
					tag_t tLLAPartRev = NULLTAG;

					int iLLACount = 0;

					// validate lla serial number is exist or not

					TERADYNE_TRACE_CALL(query_lla_serial_number_revs(sLLASerialNumber.c_str(), SERIALNUMBER, iLLACount, tLLAPart));

					if (tLLAPart == NULLTAG) {

						TERADYNE_TRACE_CALL(teradyne_create_custom_object(TD7_PART_SERIAL_NUM, sLLASerialNumber, "", LLA_SERIAL_NUMBER, tLLAPart));
						bool bObjectFound = FALSE;
						tag_t tRelation = NULLTAG;
						GRM_relation_t *tIsRelationAvailable = NULLTAG;
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tLLAPart, &tLLAPartRev));

						BusinessObjectRef< Teamcenter::BusinessObject > boLLAPartRev(tLLAPartRev);
						AcquireLock lockOnLLApartNum(tLLAPartRev);

						TERADYNE_TRACE_CALL((boLLAPartRev->setString(TD7_REV_STAMP, sRevStamp.c_str(), false)));
						TERADYNE_TRACE_CALL((boLLAPartRev->setString(TD7_SERIAL_NUMBER_STATUS, "In Progress", false)));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						//TC_write_syslog("********** Attaching  LLA Part Number into HLA Part Number***\n");
						TC_write_syslog("Checking if its attch with Div part");
						TERADYNE_TRACE_CALL(is_psn_attched_with_lla_import_repairconfigcsv(tLLAPartRev, TD7_PART_SERIAL_REL, tPartNumberRev, bObjectFound));

						if (!bObjectFound) {
							TC_write_syslog("Attaching to div part");
							TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tLLAPartRev, tPartNumberRev, TD7_PART_SERIAL_REL));
						}


						// is allow 'In Progress Serial Number
						TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRev, TD7_IS_ALLOW_INPROGRESS_SN, "false"));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						TC_write_syslog("********** Attaching  LLA Part Number into Repair Order***\n");
						TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tLLAPartRev, TD7_INCOMING_CONFIG_REL));
						TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tLLAPartRev, TD7_SOLUTION_CONFIG_REL));

						// is allow 'In Progress Serial Number
						TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRev, TD7_IS_ALLOW_INPROGRESS_SN, "true"));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						if (!sDivPart.empty()) {
							TERADYNE_TRACE_CALL(ITEM_find_item(sDivPart.c_str(), &tHLAPart));

							if (tHLAPart != NULLTAG) {
								TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tHLAPart, &tHLAPartRev));
							}

							TERADYNE_TRACE_CALL(td7_override_part_serial_relation_create_post(tLLAPartRev, tPartNumberRev, tHLAPartRev));
						}
					}

					else {
						bool bObjectFound = FALSE;
						tag_t tRelation = NULLTAG;
						GRM_relation_t *tIsRelationAvailable = NULLTAG;
						//TERADYNE_TRACE_AND_THROW(ITEM_ask_latest_rev(tLLAPart, &tLLAPartRev));

						TERADYNE_TRACE_CALL(revise_object(tLLAPart, tRevisedObject));
						tLLAPartRev = tRevisedObject;

						BusinessObjectRef< Teamcenter::BusinessObject > boLLAPartRev(tLLAPartRev);
						AcquireLock lockOnLLApartNum(tLLAPartRev);

						TERADYNE_TRACE_CALL((boLLAPartRev->setString(TD7_REV_STAMP, sRevStamp.c_str(), false)));
						// Update LLA SerialNumber Status property for Part Serial Number.
						TERADYNE_TRACE_CALL((boLLAPartRev->setString(TD7_SERIAL_NUMBER_STATUS, "In Progress", false)));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						//TC_write_syslog("********** Attaching  LLA Part Number into HLA Part Number***\n");
						TC_write_syslog("Checking if its attch with Div part");
						TERADYNE_TRACE_CALL(is_psn_attched_with_lla_import_repairconfigcsv(tLLAPartRev, TD7_PART_SERIAL_REL, tPartNumberRev, bObjectFound));

						if (!bObjectFound) {
							TC_write_syslog("Attaching to div part");
							TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tLLAPartRev, tPartNumberRev, TD7_PART_SERIAL_REL));
						}

						// is allow 'In Progress Serial Number
						TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRev, TD7_IS_ALLOW_INPROGRESS_SN, "false"));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						TC_write_syslog("********** Attaching  LLA Part Number into Repair Order***\n");
						TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tLLAPartRev, TD7_INCOMING_CONFIG_REL));

						// If LLA Serial Number status is 'Defective', should not allow to add "Solution Config".
						TERADYNE_TRACE_AND_THROW(teradyne_attach_with_relation(tRepairOrderRev, tLLAPartRev, TD7_SOLUTION_CONFIG_REL));

						// is allow 'In Progress Serial Number
						TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRev, TD7_IS_ALLOW_INPROGRESS_SN, "true"));
						TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev));

						if (!sDivPart.empty()) {
							TERADYNE_TRACE_CALL(ITEM_find_item(sDivPart.c_str(), &tHLAPart));

							if (tHLAPart != NULLTAG) {
								TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tHLAPart, &tHLAPartRev));
							}

							TERADYNE_TRACE_CALL(td7_override_part_serial_relation_create_post(tLLAPartRev, tPartNumberRev, tHLAPartRev));
						}
					}
				}
				else {
					iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_DIVPART_NOT_FOUND, sLLAPartNumber.c_str());
					iStatus = TERADYNE_DIVPART_NOT_FOUND;
					throw iStatus;
				}

			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();*/
	return iStatus;
}

// int revise_object(tag_t tItem, tag_t& tItemReviseTag) {
	// int iStatus = ITK_ok;
	// int numObjs = 0;
	// int *ifails = 0;
	// tag_t tItemRevTag = NULLTAG;
	// tag_t itemRevType = NULLTAG;
	// tag_t reviseDescTag = NULLTAG;
	// tag_t reviseInputTag = NULLTAG;
	// tag_t *deepCopyData = NULLTAG;
	// tag_t *targetCopyTags = NULLTAG;
	// try
	// {

		// TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tItem, &tItemRevTag));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_object_type(tItemRevTag, &itemRevType));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_revise_descriptor(itemRevType, &reviseDescTag));
		// TERADYNE_TRACE_CALL(TCTYPE_construct_operationinput(itemRevType, TCTYPE_OPERATIONINPUT_REVISE, &reviseInputTag));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_deepcopydata(tItemRevTag, TCTYPE_OPERATIONINPUT_REVISE,
			// &numObjs, &deepCopyData));
		// TERADYNE_TRACE_CALL(TCTYPE_revise_objects(1, &tItemRevTag, &reviseInputTag, &numObjs,
			// deepCopyData, &targetCopyTags, &ifails));
		// if (numObjs > 0) {
			// tItemReviseTag = targetCopyTags[0];
			// CHAR * itemId = NULL;
			// TERADYNE_TRACE_CALL(AOM_ask_value_string(tItemReviseTag, ITEM_ID, &itemId));

		// }
		// /**if (numObjs > 0) {

			// for (int i = 0; i < numObjs; i++) {
				// char * itemId = NULL;
				// char * itemRevId = NULL;
				// TERADYNE_TRACE_CALL(AOM_ask_value_string(targetCopyTags[i], ITEM_ID, &itemId));
				// TERADYNE_TRACE_CALL(AOM_ask_value_string(targetCopyTags[i], ITEM_REVISION_ID, &itemRevId));
				// if (tc_strcmp(itemId, NULL) != 0) {
					// tItemReviseTag = targetCopyTags[i];
				// }
			// }
		// }*/
	// }
	// catch (std::exception& err)
	// {
		// std::cout << "Error: " << err.what() << std::endl;
	// }
	// return iStatus;
// }

// int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev)
// {
	// int iStatus = ITK_ok;

	// TERADYNE_TRACE_ENTER();
	// try
	// {
		// tag_t tSavedQuery = NULLTAG;

		// if (!sLlaSerialNumber.empty()) {
			// iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			// if (tSavedQuery != NULLTAG)
			// {

				// char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				// const char * cpValues[] = { sLlaSerialNumber.c_str() , sType.c_str() };

				// int iFound = 0;
				// tag_t* tpResults = NULL;
				// TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults));

				// if (iFound > 0)
				// {
					// tQueriedSerialRev = tpResults[0];
				// }
				// TERADYNE_MEM_FREE(tpResults);
				// //MEM_FREE(cpEntries);
				// //MEM_FREE(cpValues);
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;

// }

// int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev)
// {
	// int iStatus = ITK_ok;

	// TERADYNE_TRACE_ENTER();
	// try
	// {
		// tag_t tSavedQuery = NULLTAG;

		// if (!sPartNumber.empty()) {
			// iStatus = QRY_find2(QUERY_ITEM_REVISION, &tSavedQuery);
			// if (tSavedQuery != NULLTAG)
			// {

				// char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_REVISION, QUERY_INPUT_TYPE };
				// const char * cpValues[] = { sPartNumber.c_str() , sPartNumberRev.c_str(), sType.c_str() };

				// int iFound = 0;
				// tag_t* tpResults = NULL;
				// TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 3, cpEntries, (char**)cpValues, &iFound, &tpResults));

				// if (iFound > 0)
				// {
					// tQueriedPartRev = tpResults[0];
				// }
				// TERADYNE_MEM_FREE(tpResults);
				// //MEM_FREE(cpEntries);
				// //MEM_FREE(cpValues);
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;

// }


// int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj) {

	// int iStatus = 0;
	// tag_t tCreateType = NULLTAG;
	// tag_t tCreateRevType = NULLTAG;
	// tag_t tItemCreateInput = NULLTAG;

	// TERADYNE_TRACE_ENTER();
	// try {
		// TERADYNE_TRACE_CALL(TCTYPE_find_type(sObjType.c_str(), NULL, &tCreateType));

		// if (iStatus == ITK_ok && tCreateType != NULLTAG)
		// {
			// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput));

			// if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			// {

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sItemdId.c_str()));
				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObject_name.c_str()));

				// if (sObjType.compare(TD7_REPAIR_MANAGED_PART) == 0) {

					// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART_REVISION, NULL, &tCreateRevType));

					// tag_t   tItemRevCreateInput = NULLTAG;
					// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput));

					// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, sItemRevId.c_str()));

					// TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput));
				// }
				// TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj));

				// if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				// {
					// TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj));
					// TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false));
				// }
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

// int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	// int iStatus = 0;
	// tag_t tNewRel = NULLTAG;
	// tag_t tRelation = NULLTAG;
	// TERADYNE_TRACE_ENTER();
	// try {
		// TERADYNE_TRACE_AND_THROW(GRM_find_relation_type(sAttachRel.c_str(), &tRelation));
		// if (tRelation != NULLTAG) {
			// TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel));
			// TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel));
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

// int td7_override_part_serial_relation_create_post(tag_t tLLApartNumber, tag_t tPrimaryObject, tag_t tSecondaryObject) {

	// int iStatus = ITK_ok;
	// tag_t* tBomViewRevisionTag = NULLTAG;
	// tag_t tWinTag = NULLTAG;
	// tag_t tTopLine = NULLTAG;
	// int iBomViewRevisionCount = 0;
	// bool bCompFound = false;
	// bool bIsNull = false;
	// TERADYNE_TRACE_ENTER();
	// try {
		// BusinessObjectRef< Teamcenter::BusinessObject > boPrimaryObject(tPrimaryObject);
		// std::string sPartNumber;
		// TERADYNE_TRACE_CALL(boPrimaryObject->getString(ITEM_ID, sPartNumber, bIsNull));

		// ITEM_rev_list_all_bom_view_revs(tSecondaryObject, &iBomViewRevisionCount, &tBomViewRevisionTag);

		// if (iBomViewRevisionCount > 0) {

			// TERADYNE_TRACE_CALL(BOM_create_window(&tWinTag));
			// TERADYNE_TRACE_CALL(BOM_set_window_top_line_bvr(tWinTag, tBomViewRevisionTag[0], &tTopLine));
			// TERADYNE_TRACE_CALL(traverse_BOM_import_repairconfigcsv(tTopLine, sPartNumber, bCompFound));

			// BusinessObjectRef< Teamcenter::BusinessObject > boLLApartNumber(tLLApartNumber);
			// AcquireLock lockOnLLApartNum(tLLApartNumber);
			// if (bCompFound) {
				// TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, YES, false)));
			// }
			// else {
				// TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, NO, false)));
			// }
			// TERADYNE_TRACE_CALL(BOM_close_window(tWinTag));

			// TERADYNE_TRACE_CALL(AOM_save(tLLApartNumber));
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

int traverse_BOM_import_repairconfigcsv(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound) {

	int iStatus = ITK_ok;
	/**bool bIsNull = false;
	tag_t* children_tag = NULLTAG;
	int childrens = 0;
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boBomLineRevisionTag(tBomLineRevisionTag);
		std::string sItemId;
		TERADYNE_TRACE_CALL(boBomLineRevisionTag->getString(BL_ITEM_ITEM_ID, sItemId, bIsNull));

		if (!bCompFound) {
			if (tc_strcmp(sItemId.c_str(), sPartNumber.c_str()) == 0) {
				bCompFound = true;
			}
			//BOM line ask child line
			TERADYNE_TRACE_CALL(BOM_line_ask_child_lines(tBomLineRevisionTag, &childrens, &children_tag));
			if (childrens > 0) { //If the item has childern

				for (int child = 0; child < childrens; child++) {

					TERADYNE_TRACE_CALL(traverse_BOM_import_repairconfigcsv(children_tag[child], sPartNumber, bCompFound)); // Run recursive function to get all bom lines.
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	TERADYNE_MEM_FREE(children_tag);*/
	return iStatus;
}

int is_psn_attched_with_lla_import_repairconfigcsv(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound) {

	int iStatus = ITK_ok;
	/**bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	TERADYNE_TRACE_ENTER();
	try {
		if (tSecondaryObj == NULLTAG || sRelation.empty() || tPrimaryObj == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(sRelation.c_str(), &tRelationType));

		int iSecondaryCnt = 0;

		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObj, tRelationType, &iSecondaryCnt, &tpSecondaryObjects));

		//if (tRelation != NULLTAG) {
		//	bObjectFound = TRUE;
		//}

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			if (tSecondaryObj == tpSecondaryObjects[i])
			{
				bObjectFound = TRUE;
			}
		}

	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	*/
	return iStatus;

}


// int teradyne_create_solution_config(string sItemdId, tag_t tRepairOrderRev, tag_t &tNewlyCreatedObj) {

	// int iStatus = 0;
	// tag_t tCreateType = NULLTAG;
	// tag_t tCreateRevType = NULLTAG;
	// tag_t tItemCreateInput = NULLTAG;
	// bool bIsNull = false;
	// std::string sRepairOrderNumber;

	// BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

	// TERADYNE_TRACE_CALL(boRepairOrderRev->getString(ITEM_ID, sRepairOrderNumber, bIsNull));

	// TERADYNE_TRACE_ENTER();
	// string sSolutionConfigId;
	// sSolutionConfigId = sSolutionConfigId.append(sItemdId);
	// sSolutionConfigId = sSolutionConfigId.append("_");
	// sSolutionConfigId = sSolutionConfigId.append(sRepairOrderNumber);

	// try {
		// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG, NULL, &tCreateType));

		// if (iStatus == ITK_ok && tCreateType != NULLTAG)
		// {
			// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput));

			// if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			// {

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSolutionConfigId.c_str()));
				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, "Solution Config"));

				// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG_REVISION, NULL, &tCreateRevType));

				// tag_t   tItemRevCreateInput = NULLTAG;
				// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput));

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"));

				// TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput));

				// TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj));

				// if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				// {
					// TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj));
					// TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false));
				// }
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }
