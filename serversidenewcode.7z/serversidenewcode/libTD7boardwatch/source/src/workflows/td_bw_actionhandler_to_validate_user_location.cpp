/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_validate_user_location.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  06-Feb-2020                      Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td7_validate_user_location_execute(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t * tpAttachments = NULL;
	char * cpUserName = NULL;
	char * cpUserId = NULL;
	char * cpRoleName = NULL;
	char * cCountry = NULL;


	const char * __function__ = "td7_validate_user_location_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);

		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tpAttachments[0]);

		std::string sRepairLocation("");
		tag_t pCurrentUser = NULLTAG;
	
		TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_BAT_REPAIR_LOCATION, sRepairLocation, bIsNull), TD_LOG_ERROR_AND_THROW);

		// To get the current logged in user.
		TERADYNE_TRACE_CALL(POM_get_user(&cpUserName, &pCurrentUser), TD_LOG_ERROR_AND_THROW);

		// To get the user id of the logged in user.
		TERADYNE_TRACE_CALL(SA_ask_user_identifier2(pCurrentUser, &cpUserId), TD_LOG_ERROR_AND_THROW);

		tag_t tRoleTag = NULLTAG;
		tag_t tPersonTag = NULLTAG;
		
		// Validate the user location and Repair Order's location
		TERADYNE_TRACE_CALL(SA_ask_user_person(pCurrentUser, &tPersonTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(SA_ask_person_attr2(tPersonTag, "PA5", &cCountry), TD_LOG_ERROR_AND_THROW); // PA5 --> is the real name for country property in Person object).

		if (tc_strcmp(cCountry, sRepairLocation.c_str()) != 0) {
			iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CURRENT_USER_IS_NOT_VALID, cpUserId);
			iStatus = TERADYNE_CURRENT_USER_IS_NOT_VALID;
			throw iStatus;
		}
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(tpAttachments);
	TERADYNE_MEM_FREE(cpUserName);
	TERADYNE_MEM_FREE(cpUserId);
	TERADYNE_MEM_FREE(cpRoleName);
	TERADYNE_MEM_FREE(cCountry);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}
