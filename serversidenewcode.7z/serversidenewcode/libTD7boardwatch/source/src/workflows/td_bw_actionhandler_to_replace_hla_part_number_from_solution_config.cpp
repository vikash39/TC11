/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_replace_hla_part_number_from_solution_config.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  31-Mar-2021                      Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td_bw_actionhandler_to_replace_hla_part_number_from_solution_config_execute(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t * tpAttachments = NULL;
	
	int iSolSecondaryCnt = 0;
	tag_t tSolRelationType = NULLTAG;
	tag_t* tpSolSecondaryObjects = NULLTAG;
	tag_t* tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	tag_t tLLASerialRev = NULLTAG;
	tag_t tLLAPartNumberRev = NULLTAG;
	tag_t tRepairOrder = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;

	int iHLASerialCnt = 0;
	tag_t* tpHLASerialRevs = NULLTAG;
	tag_t tHLASerialNumRelationType = NULLTAG;
	int iHLAPartCnt = 0;
	tag_t* tpHLAPartRevs = NULLTAG;
	tag_t tHLAPartNumRelationType = NULLTAG;

	const char * __function__ = "td_bw_actionhandler_to_replace_hla_part_number_from_solution_config_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);

		// get HLA Serial Number
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tHLASerialNumRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpAttachments[0], tHLASerialNumRelationType, &iHLASerialCnt, &tpHLASerialRevs), TD_LOG_ERROR_AND_THROW);
		if (iHLASerialCnt > 0) {
			for (int i = 0; i < iHLASerialCnt; i++) {
				tLLASerialRev = tpHLASerialRevs[i];
			}
		}


		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpAttachments[0], tSolRelationType, &iSolSecondaryCnt, &tpSolSecondaryObjects), TD_LOG_ERROR_AND_THROW);
		if (iSolSecondaryCnt > 0) {
			for (int k = 0; k < iSolSecondaryCnt; k++)
			{
				char* cpSolutionitemId = NULL;
				char* cpRevStamp = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], OBJECT_NAME, &cpSolutionitemId), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
				
				char* cpHLASNitemId = NULL;
				char* cpHLAPNitemId = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, OBJECT_NAME, &cpHLASNitemId), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(cpSolutionitemId, cpHLASNitemId) == 0)
				{

					// Remove this Relation Object from Repair Order and attach updated HLA Serial Number.
					TERADYNE_TRACE_CALL(teradyne_delete_relation(tpAttachments[0], tLLASerialRev, TD7_REPAIRS_SERIAL_NO_REL), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tpAttachments[0], tpSolSecondaryObjects[k], TD7_REPAIRS_SERIAL_NO_REL), TD_LOG_ERROR_AND_THROW);

					// Remove this Relation Object from Repair Order and attach Outgoing HLA Serial Number.
					TERADYNE_TRACE_CALL(teradyne_delete_relation(tpAttachments[0], tLLASerialRev, TD7_OUTGOING_SERIAL_REL), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tpAttachments[0], tpSolSecondaryObjects[k], TD7_OUTGOING_SERIAL_REL), TD_LOG_ERROR_AND_THROW);
	
					// Update Out going HLA Rev Stamp value.
					bool bisverdict = false;
					TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tpAttachments[0], &bisverdict), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpAttachments[0], true), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(AOM_set_value_string(tpAttachments[0], TD7_HLA_REVSTAMP_OUT, cpRevStamp), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_save_without_extensions(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpAttachments[0], false), TD_LOG_ERROR_AND_THROW);
					}
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(tpAttachments);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}