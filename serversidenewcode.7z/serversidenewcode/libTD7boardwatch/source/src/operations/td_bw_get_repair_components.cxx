/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_get_repair_components.cpp
#      Module          :           libTD7_teradyne_operations.dll
#      Project         :           libTD7_teradyne_operations
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <operations/td_bw_get_repair_components.h>


int td_bw_get_repair_components_execute(tag_t tRepairOrderRev, vector<tag_t> &vRepairComponents, vector<int> &vIsNull)
{
	int iStatus = ITK_ok;
	int iSolutionObjectCount = 0;
	int iRepairCompObjectCount = 0;
	tag_t tSolutionRelationTag = NULLTAG;
	tag_t tCompPartSerialRelationTag = NULLTAG;
	tag_t *tpSolutionsObjects = NULL;
	tag_t *tpRepairCompObjects = NULL;
	
	const char * __function__ = "td_bw_get_repair_components_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL( GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolutionRelationTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL( GRM_find_relation_type(TD7_REPAIRS_REL, &tCompPartSerialRelationTag), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL( GRM_list_secondary_objects_only(tRepairOrderRev, tSolutionRelationTag, &iSolutionObjectCount, &tpSolutionsObjects), TD_LOG_ERROR_AND_THROW);

		if (iSolutionObjectCount > 0) {
			for (int i=0; i < iSolutionObjectCount; i++) {
				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSolutionsObjects[i], tCompPartSerialRelationTag, &iRepairCompObjectCount, &tpRepairCompObjects), TD_LOG_ERROR_AND_THROW);
				
				for (int j=0; j < iRepairCompObjectCount; j++) {
					vRepairComponents.push_back(tpRepairCompObjects[j]);
					vIsNull.push_back(0);
				}
			}
		}
	}
	catch( ... )
	{
	}

	TERADYNE_MEM_FREE(tpSolutionsObjects);
	TERADYNE_MEM_FREE(tpRepairCompObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

