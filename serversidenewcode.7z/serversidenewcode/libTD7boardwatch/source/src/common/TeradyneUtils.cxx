/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_assigndynamicparticipant.cpp
#      Module          :           TeradyneUtils.dll
#      Project         :           libTD7_teradyne_common
#      Author          :           Sundarraj
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2015                       Sundarraj                    	        Initial Creation
#  =================================================================================================*/

#include <common/TeradyneUtils.hxx>
using namespace TERADYNE::COMMON;

// constructor
TeradyneUtils::TeradyneUtils()
{
}


int TeradyneUtils::teradyne_add_participant( tag_t tProjectRev, tag_t tGroupMember, char* cpParticipantType )
{
	int iStatus = ITK_ok;
	const char * __function__ = "teradyne_add_participant";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tParticipantType = NULLTAG;
		TERADYNE_TRACE_CALL( EPM_get_participanttype( cpParticipantType, &tParticipantType ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		tag_t tParticipant = NULLTAG;
		TERADYNE_TRACE_CALL(  EPM_create_participant( tGroupMember, tParticipantType, &tParticipant ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		TERADYNE_TRACE_CALL( ITEM_rev_add_participant( tProjectRev, tParticipant ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;
	}
	catch(...)
	{

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_remove_participant( tag_t tTargetObj, char* cpParticipantType )
{
	int iStatus = ITK_ok;
	tag_t* tParticipants = NULL;

	const char * __function__ = "teradyne_remove_participant";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tParticipantType = NULLTAG;
		TERADYNE_TRACE_CALL( iStatus = EPM_get_participanttype( cpParticipantType, &tParticipantType ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		int iParticipantCount = 0;
		TERADYNE_TRACE_CALL( iStatus = ITEM_rev_ask_participants( tTargetObj, tParticipantType, &iParticipantCount, &tParticipants ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		if( iParticipantCount > 0 )
		{
			for( int i=0; i<iParticipantCount; i++ )
			{
				// Chetan : Removing the Participant with current count(i) then the total size(iParticipantCount)
				TERADYNE_TRACE_CALL( iStatus = ITEM_rev_remove_participant( tTargetObj, tParticipants[i] ), TD_LOG_ERROR_AND_THROW);
				TERADYNE_LOG_ERROR_AND_THROW_STATUS;
			}
		}
	}
	catch(...)
	{

	}

	TERADYNE_MEM_FREE( tParticipants );
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

void TeradyneUtils::teradyne_get_handler_opts( IMAN_argument_list_t* givenArgList, char* pcGivenOptions,...)
{
	int           iArgCount = 0;
	char*         pcArgValue    = NULL;
	char*         pcOptions = pcGivenOptions;
	char*         pcEqualSign   = NULL;;
	char**        pcOptValue    = NULL;
	logical       bFound        = FALSE;
	va_list       functArgs;   

	const char * __function__ = "teradyne_get_handler_opts";
	TERADYNE_TRACE_ENTER();
	iArgCount = TC_number_of_arguments( givenArgList );
	va_start( functArgs, pcGivenOptions );

	while( pcOptions )
	{
		pcOptValue = va_arg( functArgs, char** );
		bFound = FALSE;
		IMAN_init_argument_list( givenArgList );

		for( int iCounter = 0; iCounter < iArgCount && !bFound; iCounter++ )
		{
			pcArgValue = TC_next_argument( givenArgList );

			if( !strncmp( pcArgValue, pcOptions, strlen( pcOptions ) ) )
			{
				bFound = TRUE;
				pcEqualSign = strchr( pcArgValue, '=' );

				if( pcEqualSign )
				{
					*pcOptValue = pcEqualSign + 1;
				}
				else
				{
					*pcOptValue = pcArgValue;
				}
			}//if (!strncmp(pcArgValue, pcOptions, strlen(pcOptions)))
		}//end of for (int iCounter = 0;;)

		if( !bFound )
		{
			*pcOptValue = NULL;
		}

		pcOptions = va_arg( functArgs, char* );
	}//end of while loop

	va_end( functArgs );
	TERADYNE_TRACE_LEAVE();
}  

int TeradyneUtils::teradyne_dataset_attach( char* cpDatasetType, char* cpRefName, char* cpFileName, char* cpFilePath, char*cpRelationName, tag_t tDocumentRevTag, tag_t *opDatasetTag )
{
	int    iStatus				=  0			;
	tag_t  dataset_tag			=  NULLTAG		;
	tag_t  tStructRelTag		=  NULLTAG		;
	tag_t* tpRelatedTags		=  {NULLTAG}	;
	int	   iObjectCount			=  0			;	
	char*  cpDatasetName		=  NULL			;
	char*  cpObjectType			=  NULL			;
	bool    bIsDatasetExist		=  false		;

	const char * __function__ = "teradyne_dataset_attach";
	TERADYNE_TRACE_ENTER();
	try
	{
		// file import as dataset
		tag_t dataset_type_tag = NULLTAG ;

		TERADYNE_TRACE_AND_THROW( AE_find_datasettype2( cpDatasetType, &dataset_type_tag ) );


		tag_t tool_tag = NULLTAG ;
		TERADYNE_TRACE_AND_THROW( AE_ask_datasettype_def_tool( dataset_type_tag, &tool_tag ));

		//Check if dataset exists with the document revision. 

		//Get the eform dataset tag if already created : starts
		TERADYNE_TRACE_AND_THROW( GRM_find_relation_type( cpRelationName , &tStructRelTag ) );

		TERADYNE_TRACE_AND_THROW( GRM_list_secondary_objects_only( tDocumentRevTag,tStructRelTag,&iObjectCount,&tpRelatedTags ) );


		for ( int index = 0; index < iObjectCount; index++ )
		{						
			TERADYNE_TRACE_AND_THROW(  AOM_ask_value_string(tpRelatedTags[index], OBJECT_TYPE, &cpObjectType) );


			if( cpObjectType != NULL && tc_strcmp( cpObjectType, cpDatasetType ) == 0 )
			{
				TERADYNE_TRACE_AND_THROW(  AOM_ask_value_string(tpRelatedTags[index], OBJECT_NAME, &cpDatasetName) );

				if(strcmp(cpDatasetName, cpFileName ) == 0)
				{
					dataset_tag = tpRelatedTags[index];
					bIsDatasetExist = true ;
				}

			}	
		}
		//Get the eform dataset tag if already created : ends

		if( dataset_tag == NULLTAG )
		{
			TERADYNE_TRACE_AND_THROW(  AE_create_dataset_with_id(	dataset_type_tag, // aDatasetType
				cpFileName, // aDatasetName
				NULL, // aDatasetDescription
				NULL, // aDatasetId
				NULL, // aDatasetRev
				&dataset_tag )); // aNewDataset			
		}
		else{
			//remove old one
			char *  	reference_name =NULL;
			AE_reference_type_t   	reference_type;
			tag_t  	referenced_object ;
			// Check if object is already locked
			logical		lWaslocked				= false;
			TERADYNE_TRACE_AND_THROW(  POM_modifiable	(dataset_tag,&lWaslocked) );			

			if (!lWaslocked)
			{
				// get lock on tech doc rev
				TERADYNE_TRACE_AND_THROW(  AOM_refresh( dataset_tag, true ) );

			}

			TERADYNE_TRACE_AND_THROW(  AE_find_dataset_named_ref2 ( dataset_tag,0,&reference_name,	&reference_type,&referenced_object));

			TERADYNE_TRACE_AND_THROW(   AE_remove_dataset_named_ref_by_tag2 ( dataset_tag,reference_name,referenced_object ) );

			TERADYNE_TRACE_AND_THROW(  AOM_save( dataset_tag ) ) ;

		}

		logical		lWaslocked				= false;
		TERADYNE_TRACE_AND_THROW(  POM_modifiable	(dataset_tag,&lWaslocked) );


		if (!lWaslocked)
		{
			// get lock on tech doc rev
			TERADYNE_TRACE_AND_THROW(  AOM_refresh( dataset_tag, true ) );

		}

		TERADYNE_TRACE_AND_THROW(  AE_import_named_ref(	dataset_tag, // datasetTag
			cpRefName, // referenceName
			cpFilePath, // osFullPathName
			NULL, // newFileName
			SS_BINARY ) ) ; // fileTypeFlag


		TERADYNE_TRACE_AND_THROW(  AOM_save( dataset_tag ) ) ;


		if (!lWaslocked)
		{
			// get lock on tech doc rev
			TERADYNE_TRACE_AND_THROW(  AOM_refresh( dataset_tag, false ) );

		}

		//Attach to doc rev starts
		if(!bIsDatasetExist)
		{
			if (!lWaslocked)
			{
				// get lock on tech doc rev
				TERADYNE_TRACE_AND_THROW(  AOM_refresh( dataset_tag, true ) );

			}

			tag_t	tDatasetRelationTypetag		= NULLTAG;
			tag_t	tDatasetRelationTag			= NULLTAG;

			TERADYNE_TRACE_AND_THROW(  GRM_find_relation_type( cpRelationName , &tDatasetRelationTypetag ) );


			TERADYNE_TRACE_AND_THROW(  GRM_create_relation( tDocumentRevTag,dataset_tag,tDatasetRelationTypetag,NULLTAG,&tDatasetRelationTag ) );


			//Save relation		
			TERADYNE_TRACE_AND_THROW(  GRM_save_relation( tDatasetRelationTag ) );


			TERADYNE_TRACE_AND_THROW(  AOM_save( dataset_tag ) ) ;
			TERADYNE_TRACE_AND_THROW(  AOM_refresh( dataset_tag, false ) ) ;

			*opDatasetTag = dataset_tag;

			logical		lWasDoclocked		= false;
			TERADYNE_TRACE_AND_THROW(  POM_modifiable	(tDocumentRevTag,&lWasDoclocked) );


			if (!lWasDoclocked)
			{
				// get lock on tech doc rev
				TERADYNE_TRACE_AND_THROW(  AOM_refresh( tDocumentRevTag, true ) );
			}

			TERADYNE_TRACE_AND_THROW(  AOM_save( tDocumentRevTag )) ;
			TERADYNE_TRACE_AND_THROW(  AOM_refresh( tDocumentRevTag, false)) ;
		}
		//Attach to doc rev ends
	}
	catch( ... )
	{
	}
	TERADYNE_MEM_FREE(tpRelatedTags);
	TERADYNE_MEM_FREE(cpObjectType);

	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}  

// int TeradyneUtils::teradyne_split( std::string str, char delimiter, std::vector<std::string> &vResult ) 
// {
	// int iStatus = ITK_ok;

	// std::stringstream ss( str ); // Turn the string into a stream.
	// std::string tok;

	// while( getline( ss, tok, delimiter ) )
	// {
		// vResult.push_back(tok);
	// }

	// return iStatus;
// }

int TeradyneUtils::teradyne_find_and_replace( string& source, string const& find, string const& replace )
{
	for(string::size_type inx = 0; (inx = source.find(find, inx)) != string::npos;)
	{
		source.replace(inx, find.length(), replace);
		inx += replace.length();
	}

	return 0;
}

//int TeradyneUtils::teradyne_form_delimited_string_from_vector( std::vector<std::string> vResult, char delimiter, std::stringstream &oss ) 
//{
//	int iStatus = ITK_ok;
//
//	//std::ostringstream oss;; // Turn the string into a stream.
//	std::string tok;
//
//	if (!vResult.empty())
//	{
//		// Convert all but the last element to avoid a trailing ","
//		std::copy(vResult.begin(), vResult.end()-1, std::ostream_iterator<string>(oss, ","));
//
//		// Now add the last element with no delimiter
//		oss << vResult.back();
//	}
//
//	return iStatus;
//}

int TeradyneUtils::teradyne_change_ownership( tag_t tInputObject,const char* cpUserName,const char* cpGroupName )
{
	int	iStatus	= ITK_ok;
	const char * __function__ = "teradyne_change_ownership";
	TERADYNE_TRACE_ENTER();
	try
	{
		//find the user and group tag
		tag_t tUser = NULLTAG;
		TERADYNE_TRACE_AND_THROW( SA_find_user2( cpUserName, &tUser) );

		tag_t tGroup = NULLTAG;
		TERADYNE_TRACE_AND_THROW(SA_find_group( cpGroupName, &tGroup) );

		AcquireLock lock( tInputObject );
		TERADYNE_TRACE_AND_THROW(AOM_set_ownership( tInputObject, tUser, tGroup ) );
		TERADYNE_TRACE_AND_THROW(AOM_save( tInputObject ) );
	}
	catch(...)
	{

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_get_current_date_time( date_t* dCurrDate )
{
	int iStatus = ITK_ok;
	const char * __function__ = "teradyne_get_current_date_time";
	TERADYNE_TRACE_ENTER();
	try
	{
		char* dCurrentDate = NULL;
		TERADYNE_TRACE_CALL( iStatus = ITK_ask_default_date_format	( &dCurrentDate ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		logical lIsValid = false;
		TERADYNE_TRACE_CALL( iStatus = DATE_string_to_date_t( dCurrentDate, &lIsValid, dCurrDate ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}	
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_compare_dates(date_t targetDate, date_t inputCompareDate, logical compareDateOnly)
{

	const char * __function__ = "teradyne_compare_dates";
	TERADYNE_TRACE_ENTER();
	size_t     timeDiff = 0;
	date_t  compareDate = NULLDATE;
	time_t  currentTime;
	struct  tm* current_tm = NULL;
	struct  tm compare_tm;
	struct  tm target_tm;

	if (DATE_IS_NULL(targetDate))
	{
		timeDiff = -1;
		return (int)timeDiff;
	}

	// If no compare date was input, use current local time.
	if (DATE_IS_NULL(inputCompareDate))
	{
		time(&currentTime);		
		compareDate.month = current_tm->tm_mon;
		compareDate.year = current_tm->tm_year + 1900;
		compareDate.day = current_tm->tm_mday;
		compareDate.hour = current_tm->tm_hour;
		compareDate.minute = current_tm->tm_min;
		compareDate.second = current_tm->tm_sec;
	}
	else
	{
		compareDate = inputCompareDate;
	}

	compare_tm.tm_mday = compareDate.day;
	compare_tm.tm_mon  = compareDate.month;
	compare_tm.tm_year = compareDate.year - 1900;
	compare_tm.tm_sec  = 0;
	compare_tm.tm_min  = 0;
	compare_tm.tm_hour = 0;
	compare_tm.tm_isdst= 1;
	if (!compareDateOnly)
	{
		compare_tm.tm_sec  = compareDate.second;
		compare_tm.tm_min  = compareDate.minute;
		compare_tm.tm_hour = compareDate.hour;
	}

	target_tm.tm_mday = targetDate.day;
	target_tm.tm_mon  = targetDate.month;
	target_tm.tm_year = targetDate.year - 1900;
	target_tm.tm_sec  = 0;
	target_tm.tm_min  = 0;
	target_tm.tm_hour = 0;
	target_tm.tm_isdst= 1;
	if (!compareDateOnly)
	{
		target_tm.tm_sec  = targetDate.second;
		target_tm.tm_min  = targetDate.minute;
		target_tm.tm_hour = targetDate.hour;
	}

	timeDiff = mktime(&target_tm) - mktime(&compare_tm);

	TERADYNE_TRACE_LEAVE();
	return (int)timeDiff;
}

int TeradyneUtils::teradyne_generate_fullpath(char* sDirName, char* sFileName, char* sCreationDate, char** sFullPath)
{
	int iStatus	=	ITK_ok	;

	const char * __function__ = "teradyne_generate_fullpath";
	TERADYNE_TRACE_ENTER();
	char* sTemp = NULL;

	TERADYNE_STRCPY(sTemp, sDirName);

	if (tc_strcmp(sFileName,NULL)!=0)
	{
		TERADYNE_STRCAT(sTemp, "\\");
		TERADYNE_STRCAT(sTemp, sFileName);
	}

	//Specially for report cases
	if (tc_strcmp(sCreationDate,NULL)!=0)
	{
		TERADYNE_STRCAT(sTemp, "_");
		TERADYNE_STRCAT(sTemp, sCreationDate);
		TERADYNE_STRCAT(sTemp, ".txt");
	}

	TERADYNE_STRCPY(*sFullPath, sTemp);
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_get_files_name_from_zip(const char* pcZipFileNm, const char * pcUnZipFolderNM,vector<string> &vFiles)

{	
	int	    iStatus  = ITK_ok	;
	size_t		iLoc				;

	const char * __function__ = "teradyne_get_files_name_from_zip";
	TERADYNE_TRACE_ENTER();
	try
	{
		const char* cpTcRootEnvVar;
		cpTcRootEnvVar = getenv( TC_ROOT_ENV_VAR );

		string strZipExePath = "\"";
		strZipExePath.append(cpTcRootEnvVar);
		strZipExePath.append("\\bin\\7za.exe e ");
		strZipExePath.append("\"");
		strZipExePath.append(pcZipFileNm);
		strZipExePath.append("\"");
		strZipExePath.append(" -o");
		strZipExePath.append("\"");
		strZipExePath.append(pcUnZipFolderNM);

		string strUnzCommand= "unzip ";
		strUnzCommand.append(pcZipFileNm);
		strUnzCommand.append(" -d "); 
		strUnzCommand.append(pcUnZipFolderNM);
		strUnzCommand.append(" "); 

		//Get only zip file name
		string strFileName = pcZipFileNm;
		iLoc = strFileName.find_last_of("/\\");
		strFileName =strFileName.substr (iLoc+1);
		iLoc= strFileName.find('.');
		strFileName =strFileName.substr(0,iLoc);

		strZipExePath.append("\\");
		strZipExePath.append(strFileName);
		strZipExePath.append("\"\"");

		TERADYNE_TRACE_CALL( iStatus = system(strZipExePath.c_str()), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		string strSlash="\\";
		string strDestFolderLoc = pcUnZipFolderNM +strSlash+ strFileName;

		const char* pcDestDir = strDestFolderLoc.c_str();
		FILE* pipe =  NULL;
		string strCommand = "\"dir /B /S \"" + string(pcDestDir) + "\"\"";
		char cBuffer[256];
		string strTempFilePath ;
		string  strFileNameWithExt	;
		if( NULL != (pipe = _popen(strCommand.c_str(),"rt")))
		{
			while (!feof(pipe))
			{
				if(fgets(cBuffer,256,pipe) != NULL)
				{
					strTempFilePath = cBuffer;
					strTempFilePath.erase(strTempFilePath.find_last_not_of("\n")+1);

					std::stringstream stream(strTempFilePath);
					while( getline(stream, strFileNameWithExt, '\\') )
					{
						//no processing required 
					}
					std::size_t dotFound = strFileNameWithExt.find_last_of(".");
					if (dotFound!=std::string::npos)
					{
						vFiles.push_back(string(cBuffer));
					}
				}
			}
			_pclose(pipe);
		}
		//Delete the temp zip file
		string strFileDeleteCmd= "\"del /f \"";
		strFileDeleteCmd.append(pcZipFileNm);
		strFileDeleteCmd.append("\"\"");
		//Delete zip file
		TERADYNE_TRACE_CALL( iStatus = system(strFileDeleteCmd.c_str()), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_create_dataset( const char* cpFilePath, tag_t* tDataset )
{
	int	    iStatus          = ITK_ok		;
	int		iCount			 = 0			;

	char*	cpRefName		 = NULL	; 	
	char**  cpPrefValues	 = NULL		;	

	std::string  strFileExt		 = ""		;
	std::string  strPrefFileExt	 = ""		;
	std::string  cpDatasetType	 = ""		;
	std::string  strFileName		 = ""		;
	std::string  strFileNameWithExt		 = ""		;

	const char * __function__ = "teradyne_create_dataset";
	TERADYNE_TRACE_ENTER();
	try
	{
		std::string strFilePath = cpFilePath;
		std::stringstream stream(cpFilePath);
		while( getline(stream, strFileNameWithExt, '\\') )
		{
			//no processing required 
		}

		//Get the filename and file extension. To get this, split the filename by last dot.
		strFileName = strFileNameWithExt.substr (0,strFileNameWithExt.find_last_of("."));
		strFileExt = strFileNameWithExt.substr (strFileNameWithExt.find_last_of(".")+1,strFileNameWithExt.size());

		//Convert the extension to lower case to avoid failure in comparison of extensions. For. eg. .pdf and .PDF are same.
		std::transform( strFileExt.begin(), strFileExt.end(), strFileExt.begin(), ::tolower );

		//Preference reading starts
		TERADYNE_TRACE_CALL( iStatus = PREF_ask_char_values( TERADYNE_FORMDATASET, &iCount, &cpPrefValues ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		for( int i=0; i<iCount; i++ )
		{
			std::stringstream stream( cpPrefValues[i] );
			getline( stream, strPrefFileExt, '|' ) ;
			if( strPrefFileExt.compare( strFileExt ) == 0 )
			{
				getline( stream, cpDatasetType, '|' );				
				break;
			}	
		}
		MEM_free (cpPrefValues);
		//Preference reading ends

		//Dataset creation starts
		// file import as dataset
		tag_t tDatasetTypeTag = NULLTAG ;
		TERADYNE_TRACE_CALL( iStatus = AE_find_datasettype2( cpDatasetType.c_str(), &tDatasetTypeTag ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		char** cpRefList = NULL;
		int    iRefCount = 0   ;
		TERADYNE_TRACE_CALL( iStatus = AE_ask_datasettype_refs ( tDatasetTypeTag, &iRefCount, &cpRefList ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		//Setting reference name for dataset creation e.g. setting "word" for docx type fo file
		cpRefName = cpRefList[0];
		MEM_free (cpRefList);

		TERADYNE_TRACE_CALL( iStatus = AE_create_dataset_with_id(	tDatasetTypeTag, // aDatasetType
			strFileName.c_str(), // aDatasetName
			NULL, // aDatasetDescription
			NULL, // aDatasetId
			NULL, // aDatasetRev
			tDataset ), TD_LOG_ERROR_AND_THROW); // aNewDataset
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		TERADYNE_TRACE_CALL( iStatus = AOM_lock( *tDataset), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		TERADYNE_TRACE_CALL( iStatus = AE_import_named_ref( *tDataset, // datasetTag
			cpRefName, // referenceName
			cpFilePath, // osFullPathName
			NULL, // newFileName
			SS_BINARY ), TD_LOG_ERROR_AND_THROW) ; // fileTypeFlag
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		TERADYNE_TRACE_CALL( iStatus = AOM_save( *tDataset ), TD_LOG_ERROR_AND_THROW) ;
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		TERADYNE_TRACE_CALL( iStatus = AOM_refresh( *tDataset, false ), TD_LOG_ERROR_AND_THROW) ;
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;
	}
	catch( ... )
	{
	}

	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::TERADYNE_current_get_time_stamp(char* format, char** timestamp)
{
	int iStatus = ITK_ok;
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	iStatus = DATE_date_to_string(currentTime, format, timestamp);

	return iStatus;
}

int TeradyneUtils::teradyne_grm_get_secondary_obj_of_type_with_relation ( tag_t tPrimaryObj, char*   pszRelationTypeName, char*   pszSecondaryObjType, tag_t** pptSecondaryObjects, tag_t** pptRelationObjects, int* piObjectCount )
{

	int     iStatus                           = ITK_ok;

	const char * __function__ = "teradyne_grm_get_secondary_obj_of_type_with_relation";
	TERADYNE_TRACE_ENTER();
	try
	{
		int     iCount                          = 0;
		int     iIterator                       = 0;
		int     iSecondaryCount                 = 0;
		tag_t   tRelationType                   = NULLTAG;
		char    *szObjectType[TCTYPE_name_size_c + 1] = {};
		GRM_relation_t *ptSecondaryObjects      = NULL;

		/* Initializing the Out Parameter to this function. */
		(*piObjectCount) = 0;
		(*pptSecondaryObjects) = NULL;
		(*pptRelationObjects) = NULL;

		/* verify input */
		if(tPrimaryObj == NULLTAG || TERADYNE_IS_STRING_EMPTY(pszSecondaryObjType))
		{
			return iStatus;
		}

		TERADYNE_TRACE_CALL( iStatus = GRM_find_relation_type(pszRelationTypeName, &tRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL( iStatus = GRM_list_secondary_objects(tPrimaryObj, tRelationType, &iSecondaryCount, &ptSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for(iIterator = 0; iIterator < iSecondaryCount && iStatus == ITK_ok; iIterator++)
		{
			tag_t   tObjectType = NULLTAG;
			logical lhasReadAccess    = false ;
			TERADYNE_TRACE_AND_THROW( AM_check_privilege( ptSecondaryObjects[iIterator].secondary, "READ",&lhasReadAccess ) );

			if (lhasReadAccess)
			{
				TERADYNE_TRACE_CALL( iStatus = TCTYPE_ask_object_type(ptSecondaryObjects[iIterator].secondary, &tObjectType), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL( iStatus = TCTYPE_ask_name2( tObjectType, szObjectType), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(szObjectType[0], pszSecondaryObjType) == 0)
				{
					iCount++;
					(*pptSecondaryObjects) = (tag_t*)MEM_realloc ( (*pptSecondaryObjects) , (sizeof(tag_t) * iCount) );
					(*pptSecondaryObjects)[iCount -1] = ptSecondaryObjects[iIterator].secondary;

					(*pptRelationObjects) = (tag_t*)MEM_realloc ( (*pptRelationObjects) , (sizeof(tag_t) * iCount) );
					(*pptRelationObjects)[iCount -1] = ptSecondaryObjects[iIterator].the_relation;
				}
			}
		}

		if(iCount == 0)
		{
			TC_write_syslog("No Secondary Object associated with the %s relation to the object.\n", pszRelationTypeName);
		}
		else
		{
			(*piObjectCount ) = iCount;
		}

	}
	catch( ... )
	{
	}	
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::dnvg_add_days_to_date( date_t dInpDate , int days, date_t* dOutDate )
{
	int iStatus = ITK_ok;

	struct tm date;
	date.tm_mday = dInpDate.day;
	date.tm_mon  = dInpDate.month;
	date.tm_year = dInpDate.year - 1900;
	date.tm_sec  = dInpDate.second;
	date.tm_min  = dInpDate.minute;
	date.tm_hour = dInpDate.hour;
	date.tm_isdst= 1;

	const time_t ONE_DAY = 24 * 60 * 60 ;

	// Seconds since start of epoch
	time_t date_seconds = mktime( &date ) + (days * ONE_DAY) ;

	// Update caller's date
	// Use localtime because mktime converts to UTC so may change date
	date = *localtime( &date_seconds ) ;

	char       buf[80];
	strftime( buf, sizeof(buf), "%d-%m-%Y %H:%M:%S", &date );

	iStatus = DATE_convert_formatted_string_to_date( buf, "%d-%m-%Y %H:%M:%S", false, false, dOutDate);

	return iStatus;
}

int TeradyneUtils::teradyne_grm_get_secondary_obj_of_type(tag_t tPrimaryObj, std::string sRelationTypeName, std::string sSecondaryObjType, std::vector<tag_t>& secondaryObjects)
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_grm_get_secondary_obj_of_type";
	TERADYNE_TRACE_ENTER();
	try
	{
		/* verify input */
		if(tPrimaryObj == NULLTAG || sSecondaryObjType.empty() || sRelationTypeName.empty() )
		{
			return iStatus;
		}

		tag_t tRelationType = NULLTAG;
		TERADYNE_TRACE_CALL( iStatus = GRM_find_relation_type(sRelationTypeName.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		int iSecondaryCount = 0;
		tag_t* ptSecondaryObjects = NULL;
		TERADYNE_TRACE_CALL( iStatus = GRM_list_secondary_objects_only( tPrimaryObj, tRelationType, &iSecondaryCount, &ptSecondaryObjects ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		for ( int i = 0; i < iSecondaryCount; i++ )
		{
			char* cpFolderType = NULL;
			TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_string( ptSecondaryObjects[i], OBJECT_TYPE, &cpFolderType ), TD_LOG_ERROR_AND_THROW);
			TERADYNE_LOG_ERROR_AND_THROW_STATUS;

			if( tc_strcmp( cpFolderType, sSecondaryObjType.c_str() ) == 0 )
			{
				secondaryObjects.push_back(ptSecondaryObjects[i]);
			}
		}

		TERADYNE_MEM_FREE(ptSecondaryObjects);
	}
	catch( ... )
	{
	}	
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::checkIsInstanceOf(tag_t& inputTag, const char* expectedType, bool& isTypeOf)
{
	int iStatus = 0;
	isTypeOf = false;

	const char * __function__ = "checkIsInstanceOf";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tPrimaryTypeTag = NULLTAG; 
		TERADYNE_TRACE_CALL( iStatus = POM_class_id_of_class( expectedType, &tPrimaryTypeTag), TD_LOG_ERROR_AND_THROW);
		tag_t tInputObjectType = NULLTAG;
		TERADYNE_TRACE_CALL( iStatus = POM_class_of_instance(inputTag, &tInputObjectType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL( iStatus = POM_is_descendant( tPrimaryTypeTag, tInputObjectType, &isTypeOf), TD_LOG_ERROR_AND_THROW);
	}
	catch( ... )
	{
	}	
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_create_release_status(tag_t tObject,char* sReleaseStatus)
{
	int iStatus	= ITK_ok;
	char* cpIdValue = NULL;

	const char * __function__ = "teradyne_create_release_status";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tReleaseStatus = NULLTAG;
		TERADYNE_TRACE_AND_THROW(RELSTAT_create_release_status( sReleaseStatus, &tReleaseStatus ) );

		TERADYNE_TRACE_AND_THROW(RELSTAT_add_release_status( tReleaseStatus, 1, &tObject, true ) );
	}
	catch(...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_find_default_admin_user( std::vector<tag_t>&vtUser, std::vector<tag_t>&vGroupmembers )
{

	int		iStatus	= 0	;
	int		iCount				= 0;
	char**	cpPrefValues		= NULL;
	tag_t *tpGroupMembers = NULLTAG;

	const char * __function__ = "teradyne_find_default_admin_user";
	TERADYNE_TRACE_ENTER();
	try
	{
		//Preference reading starts
		TERADYNE_TRACE_CALL( iStatus = PREF_ask_char_values( APS_DEFAULT_ADMIN_USERS, &iCount, &cpPrefValues ), TD_LOG_ERROR_AND_THROW);
		TERADYNE_LOG_ERROR_AND_THROW_STATUS;

		for( int index = 0; index < iCount; index++ ) 
		{
			if( !TERADYNE_IS_STRING_EMPTY( cpPrefValues[index] ) )
			{
				tag_t tUser = NULLTAG;
				TERADYNE_TRACE_CALL( iStatus = SA_find_user2(cpPrefValues[index], &tUser ), TD_LOG_ERROR_AND_THROW);
				TERADYNE_LOG_ERROR_AND_THROW_STATUS;

				if(tUser != NULLTAG)
				{				
					vtUser.push_back(tUser);

					tag_t tDefaultGroup = NULLTAG;
					TERADYNE_TRACE_CALL( iStatus = AOM_ask_value_tag(tUser,"default_group", &tDefaultGroup ), TD_LOG_ERROR_AND_THROW);
					TERADYNE_LOG_ERROR_AND_THROW_STATUS;

					int iGroupCount = NULL;
					TERADYNE_TRACE_CALL( iStatus = SA_find_groupmembers( tUser, tDefaultGroup, &iGroupCount, &tpGroupMembers), TD_LOG_ERROR_AND_THROW);
					TERADYNE_LOG_ERROR_AND_THROW_STATUS;

					if( iGroupCount > 0 )
					{
						vGroupmembers.push_back(tpGroupMembers[0]);
					}
				}
			}
		}
	}
	catch( ... )
	{
	}
	MEM_free(cpPrefValues) ;
	MEM_free(tpGroupMembers) ;

	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_copy_object( tag_t &tSourceObject, tag_t &tNewObject)
{
	int iStatus = ITK_ok;

	tag_t * tpDeepCpData = NULLTAG;

	const char * __function__ = "teradyne_copy_object";
	TERADYNE_TRACE_ENTER();
	try
	{ 

		tag_t tObjectType = NULLTAG;
		TERADYNE_TRACE_AND_THROW( TCTYPE_ask_object_type( tSourceObject, &tObjectType ) );

		tag_t tSaveAsInput = NULLTAG ;
		TERADYNE_TRACE_AND_THROW( TCTYPE_construct_saveasinput( tObjectType, &tSaveAsInput ) );

		int iNumObjAttached = 0;
		TERADYNE_TRACE_AND_THROW( TCTYPE_ask_deepcopydata(  tSourceObject, TCTYPE_OPERATIONINPUT_SAVEAS, &iNumObjAttached, &tpDeepCpData ) );

		TERADYNE_TRACE_AND_THROW( TCTYPE_saveas_object( tSourceObject, tSaveAsInput, iNumObjAttached, tpDeepCpData, &tNewObject ) );

		TERADYNE_TRACE_AND_THROW( AOM_refresh(tNewObject,false));

	}
	catch(...)
	{
	}

	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	TERADYNE_MEM_FREE( tpDeepCpData );
	return iStatus;
}

int TeradyneUtils::teradyne_create_relation( tag_t &tPrimary, tag_t &tSecondary ,std::string sRelationName)
{
	int iStatus = ITK_ok;

	const char * __function__ = "teradyne_create_relation";
	TERADYNE_TRACE_ENTER();
	try
	{ 
		tag_t tRelationType = NULLTAG;
		TERADYNE_TRACE_AND_THROW( GRM_find_relation_type( sRelationName.c_str(), &tRelationType ) );

		tag_t tRelation = NULLTAG;
		TERADYNE_TRACE_AND_THROW( GRM_create_relation( tPrimary, tSecondary, tRelationType, NULLTAG, &tRelation ) );

		TERADYNE_TRACE_AND_THROW( GRM_save_relation( tRelation ) );

	}

	catch(...)
	{
	}
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_grm_get_primary_obj_of_type(tag_t tSecondaryObj, std::string sRelationTypeName, std::string sPrimaryObjType, std::vector<tag_t>& secondaryObjects)
{
	int iStatus	= ITK_ok;
	tag_t * ptPrimaryObjects = NULLTAG;
	//char* cpObjType = NULL;

	const char * __function__ = "teradyne_grm_get_primary_obj_of_type";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(tSecondaryObj == NULLTAG || sPrimaryObjType.empty() || sRelationTypeName.empty() )
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG ;

		TERADYNE_TRACE_AND_THROW( iStatus = GRM_find_relation_type( sRelationTypeName.c_str() , &tRelationType ));

		int iPrimaryCnt = 0 ;


		GRM_list_primary_objects_only(tSecondaryObj,tRelationType,&iPrimaryCnt,&ptPrimaryObjects );

		for ( int i = 0; i < iPrimaryCnt; i++ )
		{
			bool isTypeOf = false;
			TERADYNE_TRACE_AND_THROW( checkIsInstanceOf( ptPrimaryObjects[i], sPrimaryObjType.c_str(), isTypeOf ) );

			if( isTypeOf )
			{
				secondaryObjects.push_back(ptPrimaryObjects[i]);
			}
		}
	}
	catch(...)
	{

	}
	TERADYNE_MEM_FREE(ptPrimaryObjects);
	//TERADYNE_MEM_FREE(cpObjType);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_delete_relation( tag_t tPrimary, tag_t tSecondary, char* cpRelationName )
{
	int iStatus = 0;

	const char * __function__ = "teradyne_delete_relation";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tRelationType = NULLTAG;
		TERADYNE_TRACE_AND_THROW( GRM_find_relation_type( cpRelationName, &tRelationType ));

		tag_t tRelation = NULLTAG;					
		TERADYNE_TRACE_AND_THROW( GRM_find_relation( tPrimary, tSecondary, tRelationType, &tRelation ) );

		if ( tRelation != NULLTAG )
			TERADYNE_TRACE_AND_THROW( GRM_delete_relation( tRelation ));
	}
	catch(...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_create_latest_rev(tag_t tTechDocRevision , tag_t &tNewRevision )
{
	int	    iStatus          = ITK_ok		;
	int	    iCount           = 0			;
	tag_t	tRelationType	 = NULLTAG		;
	tag_t	tRelation		 = NULLTAG		;
	tag_t * tpSecondaryObjects= NULLTAG		;
	tag_t * tpRelationObjects = NULLTAG		;

	const char * __function__ = "teradyne_create_latest_rev";
	TERADYNE_TRACE_ENTER();
	try
	{	
		//Release technical document revision
		TERADYNE_TRACE_AND_THROW(ITEM_copy_rev( tTechDocRevision , NULL, &tNewRevision ));

		TERADYNE_TRACE_AND_THROW(AOM_save( tNewRevision ) );
		TERADYNE_TRACE_AND_THROW(AOM_refresh( tNewRevision, false ) );

	}
	catch( ... )
	{
	}
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::teradyne_find_property_type(string sObjectType,string spropertyName,PROP_value_type_t &valueType)
{
	int		iStatus						=	ITK_ok;

	try{

		tag_t tObjectType= NULLTAG;
		TERADYNE_TRACE_AND_THROW(TCTYPE_find_type( sObjectType.c_str(), sObjectType.c_str(), &tObjectType ) );

		tag_t propDesc = NULLTAG;
		TERADYNE_TRACE_AND_THROW(TCTYPE_ask_property_by_name( tObjectType, spropertyName.c_str(), &propDesc ) );

		valueType = PROP_untyped;
		char *cpPropTypeName = NULL;
		TERADYNE_TRACE_AND_THROW( PROPDESC_ask_value_type( propDesc, &valueType, &cpPropTypeName ) );

	}
	catch( ... )
	{
	}

	return iStatus;
}

int TeradyneUtils::teradyne_find_property_max_length(string sObjectType,string spropertyName,int &iMaxEleCount)
{
	int		iStatus						=	ITK_ok;

	try{

		tag_t tObjectType= NULLTAG;
		TERADYNE_TRACE_AND_THROW(TCTYPE_find_type( sObjectType.c_str(), sObjectType.c_str(), &tObjectType ) );

		tag_t propDesc = NULLTAG;
		TERADYNE_TRACE_AND_THROW(TCTYPE_ask_property_by_name( tObjectType, spropertyName.c_str(), &propDesc ) );

		TERADYNE_TRACE_AND_THROW( PROPDESC_ask_max_num_elements( propDesc, &iMaxEleCount) );

	}
	catch( ... )
	{
	}
	return iStatus;
}

int TeradyneUtils::checkIfRelationExists( tag_t tPrimaryObject, tag_t tSecondaryObject, std::string sRelationName, logical &lExists )
{
	int iStatus = ITK_ok;

	const char * __function__ = "checkIfRelationExists";
	TERADYNE_TRACE_ENTER();
	try
	{
		if ( tPrimaryObject == NULLTAG || tSecondaryObject == NULLTAG || sRelationName.empty() )
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919204 );
		}

		tag_t tRelationType = NULLTAG;
		TERADYNE_TRACE_AND_THROW( TCTYPE_find_type( sRelationName.c_str(), sRelationName.c_str(), &tRelationType ) );

		tag_t tRelation = NULLTAG;
		TERADYNE_TRACE_AND_THROW( GRM_find_relation( tPrimaryObject, tSecondaryObject, tRelationType, &tRelation ) );

		lExists = false;
		if( tRelation != NULLTAG )
		{
			lExists = true;
		}
	}
	catch( int ex )
	{
		TC_write_syslog("Exception : %d ", ex);
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::getLatestRevision( tag_t tOldRevision, tag_t &tLatestRevision )
{
	int iStatus	= ITK_ok;

	const char * __function__ = "getLatestRevision";
	TERADYNE_TRACE_ENTER();
	try
	{
		if ( tOldRevision == NULLTAG )
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919204 );
		}

		tag_t tItem = NULLTAG;
		TERADYNE_TRACE_AND_THROW( ITEM_ask_item_of_rev( tOldRevision, &tItem ) );

		tag_t tLatestGroupRev = NULLTAG;
		TERADYNE_TRACE_AND_THROW( ITEM_ask_latest_rev( tItem, &tLatestRevision ) );
	}
	catch( int ex )
	{
		TC_write_syslog("Exception : %d ", ex);
	}
	TERADYNE_TRACE_LEAVE_RVAL( "%d", iStatus );
	return iStatus;
}

int TeradyneUtils::getPrimaryObjectOfType( tag_t tSecondaryObj, std::string sRelationTypeName, std::string sPrimaryObjType, std::vector<tag_t> &vPrimaryObject )
{
	int iStatus	= ITK_ok;
	tag_t *tpPrimaryObj = NULL;

	const char * __function__ = "getPrimaryObjectOfType";
	TERADYNE_TRACE_ENTER();
	try
	{
		if( tSecondaryObj == NULLTAG || sPrimaryObjType.empty() || sRelationTypeName.empty() )
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919204 );
		}

		tag_t tRelationType = NULLTAG ;
		TERADYNE_TRACE_AND_THROW( GRM_find_relation_type( sRelationTypeName.c_str() , &tRelationType ));

		int iPrimaryCnt = 0 ;
		TERADYNE_TRACE_AND_THROW( GRM_list_primary_objects_only( tSecondaryObj, tRelationType, &iPrimaryCnt, &tpPrimaryObj ) );

		vPrimaryObject.reserve( iPrimaryCnt );
		for ( int i = 0; i < iPrimaryCnt; i++ )
		{
			vPrimaryObject.push_back( tpPrimaryObj[i] );
		}
	}
	catch( int ex )
	{
		TC_write_syslog("Exception : %d ", ex);
	}
	TERADYNE_MEM_FREE( tpPrimaryObj );
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::reviseInputObject( tag_t tItemRevision, tag_t &tNewItemRevision )
{
	int iStatus = ITK_ok;

	const char * __function__ = "reviseInputObject";
	TERADYNE_TRACE_ENTER();
	try
	{	
		if( tItemRevision == NULLTAG )
		{
			TERADYNE_TRACE_AND_THROW( ERROR_919204 );
		}

		tag_t tItem = NULLTAG;
		TERADYNE_TRACE_AND_THROW( ITEM_ask_item_of_rev( tItemRevision, &tItem ));

		logical lhasWriteAccessOnItem = false ;
		TERADYNE_TRACE_AND_THROW( AM_check_privilege( tItem, "WRITE", &lhasWriteAccessOnItem ) );

		if( lhasWriteAccessOnItem )
		{
			TERADYNE_TRACE_AND_THROW( ITEM_copy_rev( tItemRevision , NULL, &tNewItemRevision ) );
			TERADYNE_TRACE_AND_THROW( AOM_save_with_extensions( tNewItemRevision ) );
			TERADYNE_TRACE_AND_THROW( AOM_refresh( tNewItemRevision, false) );
		}
	}
	catch( int ex )
	{
		TC_write_syslog("Exception : %d ", ex);
	}
	TERADYNE_TRACE_LEAVE_RVAL("%d", iStatus);
	return iStatus;
}

string TeradyneUtils::trim( std::string &strInputString )
{
	std::string strTrimmedString;
	size_t iStart = strInputString.find_first_not_of(' ');
	if( string::npos == iStart )
	{
		return strInputString;
	}
	size_t iEnd = strInputString.find_last_not_of(' ');
	return strInputString.substr( iStart, ( iEnd - iStart + 1 ) );
}

int TeradyneUtils::createObject(S_TeradyneUtils_CreateObjectInfo_t &structCreateObjectInfo)
{
	int iStatus = ITK_ok;
	try
	{		
		CreateInput* vtCreateInput = static_cast<Teamcenter::CreateInput*>(Teamcenter::BusinessObjectRegistry::instance().createInputObject(structCreateObjectInfo.sObjectTypeName, OPERATIONINPUT_CREATE));
		for (auto& iterator: structCreateObjectInfo.mPropertiesToSet) 
		{
			TERADYNE_TRACE_AND_THROW( vtCreateInput->setString(iterator.first, iterator.second, false ) );
		}
		Teamcenter::BusinessObject *boNewObject = dynamic_cast<Teamcenter::BusinessObject *>(Teamcenter::BusinessObjectRegistry::instance().createBusinessObject(vtCreateInput));
		TERADYNE_TRACE_AND_THROW( AOM_save_with_extensions( boNewObject->getTag() ) );
		TERADYNE_TRACE_AND_THROW( AOM_refresh( boNewObject->getTag(), false) );
		//Return the tag of newly created object in the inputed structure
		structCreateObjectInfo.tCreatedObject = boNewObject->getTag();
	}
	catch(...)
	{

	}
	return iStatus;
}

inline const char * const BoolToString(bool b)
{
	return b ? "true" : "false";
}

int TeradyneUtils::teradyne_create_URL_from_tag ( tag_t tTargetObject, string &sObjectURL )
{
	int iStatus = ITK_ok;
	const char * __function__ = "teradyne_create_URL_from_tag";
	TERADYNE_TRACE_ENTER();
	try
	{
		//Find the puid of Target Object
		char* cpTargetObjUid= NULL;
		ITK__convert_tag_to_uid( tTargetObject, &cpTargetObjUid );

		//Find the preference value
		char* cpURLprefValue = NULL;
		TERADYNE_TRACE_AND_THROW ( PREF_ask_char_value ( ACTIVEWORKSPACE_URL , 0 , &cpURLprefValue ) ) ;

		if ( cpURLprefValue != NULL )			 
		{
			//Create URLs for Target Object
			sObjectURL = cpURLprefValue + string("#/com.siemens.splm.clientfx.tcui.xrt.showObject?uid=") + cpTargetObjUid;
		}

	}
	catch( ... )
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int TeradyneUtils::teradyne_abort_workflow(tag_t tTargetObject , char*  strComment )
{
	int    iStatus	=  ITK_ok			;
	const char * __function__ = "teradyne_abort_workflow";
	TERADYNE_TRACE_ENTER();
	try
	{
		std::vector<tag_t> vTasks;
		std::vector<int> vtaskCnt;
		BusinessObjectRef<Teamcenter::BusinessObject> BODocRev( tTargetObject );
		TERADYNE_TRACE_AND_THROW( BODocRev->getTagArray( PROCESS_STAGE_LIST, vTasks, vtaskCnt) );

		if( vtaskCnt.size() > 0 )
		{
			TERADYNE_TRACE_AND_THROW( EPM_trigger_action(  vTasks[vtaskCnt.size()-1], EPM_abort_action, strComment) );
		}
	}
	catch( ... )
	{
	}

	TERADYNE_TRACE_LEAVE();
	TERADYNE_TRACE_LEAVE_RVAL(  "%d", iStatus );
	return iStatus;
}
