/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_assigndynamicparticipant.cpp
#      Module          :           libTD7_teradyne_common.dll
#      Project         :           libTD7_teradyne_common
#      Author          :           Sundarraj
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2015                       Sundarraj                    	        Initial Creation
#  =================================================================================================*/

#include <common/teradyne_common.h>
#include <common/teradyne_trace_handling.h>
#include<workflows/teradyne_workflows.h>

int libTD7_teradyne_common_register_callbacks()
{
	int iStatus				= ITK_ok;

	try
	{
		TC_write_syslog("Successfully registered the dll libTD7_teradyne_common. Build on %s %s \n", __DATE__, __TIME__);
	}
	catch( ... )
	{
	}
	return iStatus;	
}

int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	int iStatus = 0;
	tag_t tNewRel = NULLTAG;
	tag_t tRelation = NULLTAG;
	const char * __function__ = "teradyne_attach_with_relation";
	TERADYNE_TRACE_ENTER();
	try {
		TERADYNE_TRACE_AND_THROW(GRM_find_relation_type(sAttachRel.c_str(), &tRelation));
		if (tRelation != NULLTAG) {
			TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int revise_object(tag_t tItem, tag_t& tItemReviseTag) {
	int iStatus = ITK_ok;
	int numObjs = 0;
	int *ifails = 0;
	tag_t tItemRevTag = NULLTAG;
	tag_t itemRevType = NULLTAG;
	tag_t reviseDescTag = NULLTAG;
	tag_t reviseInputTag = NULLTAG;
	tag_t *deepCopyData = NULLTAG;
	tag_t *targetCopyTags = NULLTAG;
	try
	{
		
		TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tItem, &tItemRevTag), TD_LOG_ERROR_AND_THROW);
		
		TERADYNE_TRACE_CALL(TCTYPE_ask_object_type(tItemRevTag, &itemRevType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_ask_revise_descriptor(itemRevType, &reviseDescTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_construct_operationinput(itemRevType, TCTYPE_OPERATIONINPUT_REVISE, &reviseInputTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_ask_deepcopydata(tItemRevTag, TCTYPE_OPERATIONINPUT_REVISE,
			&numObjs, &deepCopyData), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_revise_objects(1, &tItemRevTag, &reviseInputTag, &numObjs,
			deepCopyData, &targetCopyTags, &ifails), TD_LOG_ERROR_AND_THROW);
		
		if (numObjs > 0) {
			tItemReviseTag = targetCopyTags[0];
			CHAR * itemId = NULL;
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tItemReviseTag, ITEM_ID, &itemId), TD_LOG_ERROR_AND_THROW);

		}
	}
	catch (std::exception& err)
	{
		std::cout << "Error: " << err.what() << std::endl;
	}
	return iStatus;
}

int remove_secondary_objects(tag_t tPrimaryObject, string sRelationType) {
	int iStatus = ITK_ok;
	int numSecondaryObjs = 0;
	tag_t tRelationType = NULLTAG;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t reviseDescTag = NULLTAG;
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(sRelationType.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObject, tRelationType, &numSecondaryObjs, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (numSecondaryObjs > 0) {
			// TO Do ==> Discussion needed to get repair order.
			for (int i = 0; i < numSecondaryObjs; i++) {
				// Remove this Relation Object from Repair Order.
				tag_t tRelationTag = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_find_relation(tPrimaryObject, tSecondaryObjects[i], tRelationType, &tRelationTag), TD_LOG_ERROR_AND_THROW);
				if (tRelationTag != NULLTAG) {
					TERADYNE_TRACE_CALL(GRM_delete_relation(tRelationTag), TD_LOG_ERROR_AND_THROW);
					//TERADYNE_TRACE_CALL(AOM_refresh(tPrimaryObject, false), TD_LOG_ERROR_AND_THROW);
					//TERADYNE_TRACE_CALL(AOM_save(tPrimaryObject), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (std::exception& err)
	{
		std::cout << "Error: " << err.what() << std::endl;
	}
	return iStatus;
}

int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev)
{
	int iStatus = ITK_ok;

	const char * __function__ = "query_div_and_rep_mang_part_revs";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sPartNumber.empty()) {
			iStatus = QRY_find2(QUERY_ITEM_REVISION, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_REVISION, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sPartNumber.c_str() , sPartNumberRev.c_str(), sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 3, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

				if (iFound > 0)
				{
					tQueriedPartRev = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
				//MEM_FREE(cpEntries);
				//MEM_FREE(cpValues);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int query_item(string sItemId, string sType, int iCount, tag_t& tItemRev)
{
	int iStatus = ITK_ok;

	const char * __function__ = "query_item";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sItemId.empty()) {
			iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sItemId.c_str() , sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_AND_THROW(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults));

				if (iFound > 0)
				{
					tItemRev = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int teradyne_split(std::string str, char delimiter, std::vector<std::string> &vResult)
{
	int iStatus = ITK_ok;

	std::stringstream ss(str); // Turn the std::string into a stream.
	std::string tok;

	while (getline(ss, tok, delimiter))
	{
		vResult.push_back(tok);
	}

	return iStatus;
}

int set_as_older_versions_for_checklists(tag_t tPrimaryObj, string sRelation, string tFormType) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	bool bisverdict = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	const char * __function__ = "set_as_older_versions_for_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (sRelation.empty() || tPrimaryObj == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(sRelation.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObj, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), tFormType.c_str()) == 0) {
				//set the env info so that the date modified attribute will not be updated
				iStatus = POM_set_env_info(POM_bypass_attr_update, false, 0, 0, NULLTAG, "");
				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tpSecondaryObjects[i], &bisverdict), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], true), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(AOM_set_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, FALSE), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save_without_extensions(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], false), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{

	}
	TERADYNE_MEM_FREE(tpSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int create_checklist_form(tag_t tRepairOrderRev, string tFormType, string sobjName, string sFormName) {
	int iStatus = 0;
	tag_t tFormTypeTag = NULLTAG;
	tag_t tCreateInputTag = NULLTAG;
	tag_t tForm = NULLTAG;

	const char * __function__ = "create_checklist_form";
	TERADYNE_TRACE_ENTER();
	try {

		// Set boolean value to find, older versions of checklists.
		TERADYNE_TRACE_CALL(set_as_older_versions_for_checklists(tRepairOrderRev, IMAN_SPECIFICATION, tFormType), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(TCTYPE_find_type(tFormType.c_str(), tFormType.c_str(), &tFormTypeTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tFormTypeTag, &tCreateInputTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_set_value_string(tCreateInputTag, OBJECT_NAME, sobjName.c_str()), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(TCTYPE_create_object(tCreateInputTag, &tForm), TD_LOG_ERROR_AND_THROW);
		if (tForm != NULLTAG) {
			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tForm), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tForm, false), TD_LOG_ERROR_AND_THROW);
			BusinessObjectRef< Teamcenter::BusinessObject > boForm(tForm);
			AcquireLock lockOnLLApartNum(boForm);

			if (tc_strcmp(sFormName.c_str(), "") != 0 && tc_strcmp(sFormName.c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boForm->setString(TD7_FORM_NAME, sFormName, false)), TD_LOG_ERROR_AND_THROW);
			}
			// set as latest version
			TERADYNE_TRACE_CALL(AOM_set_value_logical(tForm, TD7_IS_LATEST_VERSION, TRUE), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_save(tForm), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(teradyne_dataset_attach_with_relation(tRepairOrderRev, tForm, IMAN_SPECIFICATION), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (exception exp) {}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int teradyne_dataset_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	int iStatus = 0;
	tag_t tNewRel = NULLTAG;
	tag_t tRelation = NULLTAG;

	const char * __function__ = "teradyne_dataset_attach_with_relation";
	TERADYNE_TRACE_ENTER();

	try {
		ITK_set_bypass(true);
		TERADYNE_TRACE_AND_THROW(GRM_find_relation_type(sAttachRel.c_str(), &tRelation));
		if (tRelation != NULLTAG) {
			TERADYNE_TRACE_AND_THROW(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel));
			TERADYNE_TRACE_AND_THROW(GRM_save_relation(tNewRel));
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	ITK_set_bypass(false);
	return iStatus;
}

int teradyne_create_solution_config(string sItemdId, tag_t tRepairOrderRev, tag_t &tNewlyCreatedObj) {

	int iStatus = 0;
	tag_t tCreateType = NULLTAG;
	tag_t tCreateRevType = NULLTAG;
	tag_t tItemCreateInput = NULLTAG;
	bool bIsNull = false;
	std::string sRepairOrderNumber;

	BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

	TERADYNE_TRACE_CALL(boRepairOrderRev->getString(ITEM_ID, sRepairOrderNumber, bIsNull), TD_LOG_ERROR_AND_THROW);

	const char * __function__ = "teradyne_create_solution_config";
	TERADYNE_TRACE_ENTER();
	string sSolutionConfigId;
	sSolutionConfigId = sSolutionConfigId.append(sItemdId);
	sSolutionConfigId = sSolutionConfigId.append("_");
	sSolutionConfigId = sSolutionConfigId.append(sRepairOrderNumber);

	try {
		TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG, NULL, &tCreateType), TD_LOG_ERROR_AND_THROW);

		if (iStatus == ITK_ok && tCreateType != NULLTAG)
		{
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			{

				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSolutionConfigId.c_str()), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, "Solution Config"), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG_REVISION, NULL, &tCreateRevType), TD_LOG_ERROR_AND_THROW);

				tag_t   tItemRevCreateInput = NULLTAG;
				TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj), TD_LOG_ERROR_AND_THROW);

				if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				{
					TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int td7_override_part_serial_relation_create_post(tag_t tLLApartNumber, tag_t tPrimaryObject, tag_t tSecondaryObject) {

	int iStatus = ITK_ok;
	tag_t* tBomViewRevisionTag = NULLTAG;
	tag_t tWinTag = NULLTAG;
	tag_t tTopLine = NULLTAG;
	int iBomViewRevisionCount = 0;
	bool bCompFound = false;
	bool bIsNull = false;

	const char * __function__ = "td7_override_part_serial_relation_create_post";
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boPrimaryObject(tPrimaryObject);
		std::string sPartNumber;
		TERADYNE_TRACE_CALL(boPrimaryObject->getString(ITEM_ID, sPartNumber, bIsNull), TD_LOG_ERROR_AND_THROW);

		ITEM_rev_list_all_bom_view_revs(tSecondaryObject, &iBomViewRevisionCount, &tBomViewRevisionTag);

		if (iBomViewRevisionCount > 0) {

			TERADYNE_TRACE_CALL(BOM_create_window(&tWinTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(BOM_set_window_top_line_bvr(tWinTag, tBomViewRevisionTag[0], &tTopLine), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(traverse_BOM_import_repairconfigcsv(tTopLine, sPartNumber, bCompFound), TD_LOG_ERROR_AND_THROW);

			BusinessObjectRef< Teamcenter::BusinessObject > boLLApartNumber(tLLApartNumber);
			AcquireLock lockOnLLApartNum(tLLApartNumber);
			if (bCompFound) {
				TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, YES, false)), TD_LOG_ERROR_AND_THROW);
			}
			else {
				TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, NO, false)), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(BOM_close_window(tWinTag), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_save(tLLApartNumber), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj) {

	int iStatus = 0;
	tag_t tCreateType = NULLTAG;
	tag_t tCreateRevType = NULLTAG;
	tag_t tItemCreateInput = NULLTAG;

	const char * __function__ = "teradyne_create_custom_object";
	TERADYNE_TRACE_ENTER();
	try {
		TERADYNE_TRACE_CALL(TCTYPE_find_type(sObjType.c_str(), NULL, &tCreateType), TD_LOG_ERROR_AND_THROW);

		if (iStatus == ITK_ok && tCreateType != NULLTAG)
		{
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			{

				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sItemdId.c_str()), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObject_name.c_str()), TD_LOG_ERROR_AND_THROW);

				if (sObjType.compare(TD7_REPAIR_MANAGED_PART) == 0) {

					TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART_REVISION, NULL, &tCreateRevType), TD_LOG_ERROR_AND_THROW);

					tag_t   tItemRevCreateInput = NULLTAG;
					TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, sItemRevId.c_str()), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj), TD_LOG_ERROR_AND_THROW);

				if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				{
					TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev)
{
	int iStatus = ITK_ok;

	const char * __function__ = "query_lla_serial_number_revs";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sLlaSerialNumber.empty()) {
			iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sLlaSerialNumber.c_str() , sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

				if (iFound > 0)
				{
					tQueriedSerialRev = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
				//MEM_FREE(cpEntries);
				//MEM_FREE(cpValues);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

/***************************************************************************************
*   Function Name       : ltrim
*   Description         : This function trims the left leading whitespaces
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &ltrim(std::string &s) {
	s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
	return s;
}

/***************************************************************************************
*   Function Name       : rtrim
*   Description         : This function trims the right trailing whitespaces
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &rtrim(std::string &s) {
	s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
	return s;
}

/***************************************************************************************
*   Function Name       : trim
*   Description         : This function trims the leading and trailing whitespaces
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string &trim(std::string &s) {
	return ltrim(rtrim(s));
}

/***************************************************************************************
*   Function Name       : isDigitWSAllowed
*   Description         : This function checks if a string is numeric
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isDigitWSAllowed(std::string str)
{
	if (str == "" || str.length() <= 0)
		return false;

	for (int n = 0; n < str.length(); n++)
	{
		if (std::isspace(str[n]))
			continue;
		if (!std::isdigit(str[n]))
			return false;
	}

	return true;
}

/***************************************************************************************
*   Function Name       : isAlphaWSAllowed
*   Description         : This function checks if a string is alpha
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaWSAllowed(std::string str)
{
	if (str == "" || str.length() <= 0)
		return false;

	for (int n = 0; n < str.length(); n++)
	{
		if (std::isspace(str[n]))
			continue;
		if (!std::isalpha(str[n]))
			return false;
	}

	return true;
}


/***************************************************************************************
*   Function Name       : isAlphaNumericWSAllowed
*   Description         : This function checks if a string is alphanumeric
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaNumericWSAllowed(std::string str)
{
	if (str == "" || str.length() <= 0)
		return false;

	std::regex e("^(?:\\w|\\s)*$");

	if (std::regex_match(str.begin(), str.end(), e))
		return true;

	return false;
}

/***************************************************************************************
*   Function Name       : isAlphaNumericStrict
*   Description         : This function checks if a string is strictly alphanumeric only
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
bool isAlphaNumericStrict(std::string str) {
	if (isAlphaWSAllowed(str) || isDigitWSAllowed(str))
		return false;
	if (!isAlphaNumericWSAllowed(str))
		return false;
	return true;
}

/***************************************************************************************
*   Function Name       : incrementedAlpha
*   Description         : This function increments a string by one
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        : string buf
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::string incrementedAlpha(std::string text)
{
	// We will not process empty string
	auto len = text.length();
	if (len == 0)
		return text;

	// Determine whether the last char is numeric. We need to find out the
	// the numeric char as whole value to increment
	auto charLen = text.length() - 1;
	int numPos = -1;
	bool numFound = false;
	for (int i = charLen; i >= 0; i--) {
		if (std::isdigit(text.at(i))) {
			numFound = true;
			continue;
		}
		else {
			numPos = i;
			break;
		}
	}

	if (numPos == -1 && numFound)
	{  // Case1: All Numerics
		int incr = stoi(text);
		incr++;
		return toString(incr);
	}
	else if (numPos != -1 && numFound)
	{ // Case2: Partial Numeric
		string strCons = text.substr(0, numPos + 1);
		string strIncr = text.substr(numPos + 1, text.length());
		int incr = stoi(strIncr);
		incr++;
		return strCons + toString(incr);
	}
	else
	{
		// Determine where does the first alpha-numeric starts.
		bool alphaNum = false;
		int alphaNumPos = -1;
		for (int cn = 0; cn < text.size(); cn++)
		{
			alphaNumPos++;
			if (std::isdigit(text.at(cn)) || std::isalpha(text.at(cn)))
			{
				alphaNum = true;
				break;
			}
		}

		// Now we go calculate the next successor char of the given text.
		string buf = text;
		if (!alphaNum || alphaNumPos == 0 || alphaNumPos == len) {
			// do the entire input text
			getNextAlpha(buf, buf.length() - 1, alphaNum);
		}
		else {
			// Strip the input text for non alpha numeric prefix. We do not need to process these prefix but to save and
			// re-attach it later after the result.
			string prefix = text.substr(0, alphaNumPos);
			buf = text.substr(alphaNumPos);
			getNextAlpha(buf, buf.length() - 1, alphaNum);
			buf.insert(0, prefix);
		}

		return buf;
	}

}

/***************************************************************************************
*   Function Name       : getNextAlpha
*   Description         : This function will get the next aplha/numeric sequence
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*
*
*   RETURN VALUE        :
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
void getNextAlpha(string &buf, int pos, bool alphaNum)
{
	// We are asked to carry over next value for the left most char
	if (pos == -1) {
		char c = buf.at(0);
		string rep = "";
		if (std::isdigit(c))
			rep = "1";
		else if (std::islower(c))
			rep = "a";
		else if (std::isupper(c))
			rep = "A";
		else
			rep = ++c;
		buf.insert(0, rep);
		return;
	}

	char c = buf.at(pos);
	if (std::isdigit(c)) {
		if (c == '9') {
			buf.replace(pos, pos + 1, "0");
			getNextAlpha(buf, pos - 1, alphaNum);
		}
		else {
			std::string s(1, ++c);
			buf.replace(pos, pos + 1, s);
		}
	}
	else if (std::islower(c)) {
		if (c == 'z') {
			buf.replace(pos, pos + 1, "a");
			getNextAlpha(buf, pos - 1, alphaNum);
		}
		else {
			std::string s(1, ++c);
			buf.replace(pos, pos + 1, s);
		}
	}
	else if (std::isupper(c)) {
		if (c == 'Z') {
			buf.replace(pos, pos + 1, "A");
			getNextAlpha(buf, pos - 1, alphaNum);
		}
		else {
			std::string s(1, ++c);
			buf.replace(pos, pos + 1, s);
		}
	}
	else {
		// If input text has any alpha num at all then we are to calc next these characters only and ignore the
		// we will do this by recursively call into next char in buf.
		if (alphaNum) {
			getNextAlpha(buf, pos - 1, alphaNum);
		}
		else {
			// However if the entire input text is non alpha numeric, then we will calc successor by simply
			// increment to the next char in range (including non-printable char!)
			if (c == CHAR_MAX) {
				std::string s(1, CHAR_MIN);
				buf.replace(pos, pos + 1, s);
				getNextAlpha(buf, pos - 1, alphaNum);
			}
			else {
				std::string s(1, ++c);
				buf.replace(pos, pos + 1, s);
			}
		}
	}
}

/***************************************************************************************
*   Function Name       : splitString
*   Description         : This function splits the given string by a given delimiter.
*   REQUIRED HEADERS    :
*
*   INPUT/OUTPUT PARAMS : string theString
*                         char delim
*
*   RETURN VALUE        : vector of elements
*
*   GLOBALS USED        :None
*   FUNCTIONS CALLED    :
*
*   ALGORITHM           :
*
*********************************************************************************************/
std::vector<std::string> splitString(std::string theString, string delim, bool splitQuotes)
{
	std::vector<std::string> elems;
	std::string quotedDelim = "\"" + delim;
	std::string replaceStr = "#~#";
	std::string searchStr = "";
	char quotes = '"';

	if (splitQuotes)
	{
		if (theString != "" && theString.length() > 0)
		{
			size_t it = 0;
			while (it != string::npos && it < theString.length())
			{
				if (it == 0)
				{
					if (quotes == theString[0])
					{
						it = theString.find(quotedDelim);
						searchStr = quotedDelim;
					}
					else
					{
						it = theString.find(delim);
						searchStr = delim;
					}
				}
				else
				{
					if (theString[it] == quotes)
					{
						theString.replace(it, 1, "");
						it = theString.find(quotedDelim, it);
						searchStr = quotedDelim;
					}
					else
					{
						it = theString.find(delim, it);
						searchStr = delim;
					}
				}

				if (it != string::npos)
				{
					theString.replace(it, searchStr.length(), replaceStr);
					it += replaceStr.length();
				}
			}

			if (theString[0] == quotes)
			{
				theString.replace(0, 1, "");
			}
			size_t strLen = theString.length() - 1;
			if (theString[strLen] == quotes)
			{
				theString.replace(strLen, 1, "");
			}
		}

		delim = "#~#";
	}

	auto start = 0U;
	auto end = theString.find(delim);
	while (end != std::string::npos)
	{
		elems.push_back(theString.substr(start, end - start));
		start = end + delim.length();
		end = theString.find(delim, start);
	}
	elems.push_back(theString.substr(start, end));
	return elems;
}

string removeSpecialCharactors(string inputString) {
	string line;
	string temp = "";

	for (int i = 0; i < inputString.size(); ++i) {
		if ((inputString[i] >= 'a' && inputString[i] <= 'z') || (inputString[i] >= 'A' && inputString[i] <= 'Z') || (inputString[i] >= '0' && inputString[i] <= '9')) {
			temp = temp + inputString[i];
		}
	}
	line = temp;
	return line;
}

/*******************************************************************************
 * Function Name			: teradyne_current_timestamp
 * Description				: this function will return current time stamp in the
 *                            format YYYY-MM-DD HH:MM:SS(EX:2014-11-10 15:09:24)
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : strFormat (I)   - Format for the time stamp
 *							: strTimeStamp (O) - Output time stamp
 *							: curDate(O)	-	Current date date_t
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_current_timestamp(string strFormat, string &strTimeStamp, date_t &curDate)
{
	int iStatus = ITK_ok;
	char *strDate = NULL;

	const char * __function__ = "teradyne_current_timestamp";
	TERADYNE_TRACE_ENTER();

	try
	{
		struct timeb timebuffer;
		ftime(&timebuffer);

		time_t tt = timebuffer.time;
		struct tm *ptm = localtime(&tt);
		//date_t curDate ;
		curDate.year = ptm->tm_year + 1900;
		curDate.month = ptm->tm_mon;
		curDate.day = ptm->tm_mday;
		curDate.hour = ptm->tm_hour;
		curDate.minute = ptm->tm_min;
		curDate.second = ptm->tm_sec;
		if (strFormat.length() > 0) {

			TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(curDate, strFormat.c_str(), &strDate), TD_LOG_ERROR_AND_THROW);
			strTimeStamp = strDate;
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			//iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	TERADYNE_MEM_FREE(strDate);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}









