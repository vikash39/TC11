/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow.cpp
#      Module          :           libTD7_teradyne_extensions.dll
#      Project         :           libTD7_teradyne_extensions
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

int td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute(va_list localArgs)
{
	int iStatus = ITK_ok;
	tag_t tTargetObject = NULLTAG;
	tag_t tObjectType = NULLTAG;
	char **cpObjectType = NULL;
	bool bIsNull = false;
	bool isSameHLASNAndPN = false;
	char *cpDatasetName = NULL;
	int namedreferencedCount = 0;
	char *cpNrPathname = NULL;
	fstream Readingfile;
	tag_t *tpReferencedObject = NULL;
	int strErroCode = 0;
	string strItemId = "";
	int config_lines_from_csv = 0;
	int config_obj_from_ro = 0;

	tag_t tObject = NULLTAG;
	tag_t tPrimaryObj = NULLTAG;
	tag_t tSecondayObj = NULLTAG;
	tag_t tRelationType = NULLTAG;
	const char * __function__ = "Boardwatch_PostAction_on_RepairConfigCSV";
	TERADYNE_TRACE_ENTER();
	try
	{
		/**va_list vArgs;
		va_copy(vArgs, localArgs);

		tTargetObject = va_arg(vArgs, tag_t);
		va_end(vArgs);*/

		//Get the input arguments
		//tTargetObject = va_arg(localArgs, tag_t);
		//bool bisNew = va_arg(localArgs, logical);

		tPrimaryObj = va_arg(localArgs, tag_t);
		tSecondayObj = va_arg(localArgs, tag_t);
		tRelationType = va_arg(localArgs, tag_t);

		if (tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG) {

			BusinessObjectRef<Teamcenter::BusinessObject> boPrimaryObj(tSecondayObj);

			std::string sSecondaryObjectType("");
			TERADYNE_TRACE_CALL(boPrimaryObj->getString(OBJECT_TYPE, sSecondaryObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (sSecondaryObjectType.compare(TD7_REPAIR_CONFIG_CSV) == 0)
			{
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondayObj, "object_name", &cpDatasetName), TD_LOG_ERROR_AND_THROW);
				logical lRoFound = FALSE;
				TERADYNE_TRACE_CALL(validate_repair_order_availability(tPrimaryObj, cpDatasetName, lRoFound), TD_LOG_ERROR_AND_THROW);
				if (lRoFound)
				{

					TERADYNE_TRACE_CALL(AE_ask_dataset_named_refs(tSecondayObj, &namedreferencedCount, &tpReferencedObject), TD_LOG_ERROR_AND_THROW);

					for (int j = 0; j < namedreferencedCount; j++) {
						TERADYNE_TRACE_CALL(IMF_ask_file_pathname2(tpReferencedObject[j], SS_WNT_MACHINE, &cpNrPathname), TD_LOG_ERROR_AND_THROW);
						Readingfile.open(cpNrPathname, ios::in);
						if (Readingfile.is_open())
						{
							string inputline = "";
							while (getline(Readingfile, inputline))
							{
								config_lines_from_csv++;
								vector<string> vSplittedValues;
								TERADYNE_TRACE_CALL(teradyne_split(inputline, ',', vSplittedValues), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(read_record_postaction_on_repairconfigcsv(cpDatasetName, vSplittedValues, strErroCode, strItemId), TD_LOG_ERROR_AND_THROW);

								if (strErroCode != 0) {
									EMH_clear_errors();
									iStatus = EMH_store_error_s1(EMH_severity_error, strErroCode, strItemId.c_str());
									iStatus = strErroCode;
									throw iStatus;
								}
								else {
									config_obj_from_ro++;
								}
							}
							TERADYNE_TRACE_CALL(is_same_hla_sn_and_hla_pn_to_set_rev_Stamp(cpDatasetName, isSameHLASNAndPN), TD_LOG_ERROR_AND_THROW);

							if (config_lines_from_csv != config_obj_from_ro) {
								iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_NOT_ALL_CONFIG_OBJ_CREATED, cpDatasetName);
								iStatus = TERADYNE_NOT_ALL_CONFIG_OBJ_CREATED;
								throw iStatus;
							}
						}
						else {
							iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CONFIG_CSV_FILE_NOT_GETTING_LOAD, "");
							iStatus = TERADYNE_CONFIG_CSV_FILE_NOT_GETTING_LOAD;
							throw iStatus;
						}

					}
				}
				else {
					iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_ORDER_CSV_FAILED, cpDatasetName);
					iStatus = TERADYNE_REPAIR_ORDER_CSV_FAILED;
					throw iStatus;
				}
			}
		}

	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(cpObjectType);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}


int validate_repair_order_availability(tag_t tRepairOrderRev, char* cpDatasetName, logical &lRoFound)
{
	int iStatus = ITK_ok;
	bool bIsNull = false;
	int iNumItems = 0;
	int iCount = 0;
	tag_t *tpPrimaryObjects = NULL;
	
	tag_t tRepairOrder = NULLTAG;
	const char * __function__ = "validate_repair_order_availability";
	TERADYNE_TRACE_ENTER();
	try {
		char* roId = NULL;
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, ITEM_ID, &roId), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(roId, cpDatasetName) == 0) {
			lRoFound = TRUE;
		}

		/**BusinessObjectRef< Teamcenter::BusinessObject > boTargetObject(tRepairOrderRev);
		std::string sObjectName;
		TERADYNE_TRACE_CALL(boTargetObject->getString(OBJECT_NAME, sObjectName, bIsNull), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(query_repair_order(sObjectName.c_str(), TD7_REPAIR_ORDER, iCount, tRepairOrder), TD_LOG_ERROR_AND_THROW);

		if (tRepairOrder != NULLTAG) {
			
					lRoFound = TRUE;
		}*/
	}
	catch (...)
	{

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}


int query_repair_order(string sROID, string sType, int iCount, tag_t& tRepairOrder)
{
	int iStatus = ITK_ok;
	const char * __function__ = "query_lla_serial_number_revs_repair_config_csv";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sROID.empty()) {
			iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sROID.c_str(), sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

				if (iFound > 0)
				{
					tRepairOrder = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);

			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int read_record_postaction_on_repairconfigcsv(string sRepairOrderNumber, vector<string> inputValues, int &strErroCode, string &strItemId) {
	int iStatus = ITK_ok;
	bool bIsNull = false;
	bool isSameHLASNAndPN = false;
	tag_t tRepairOrder = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tHLAPart = NULLTAG;
	tag_t tHLAPartRev = NULLTAG;
	tag_t tPartNumber = NULLTAG;
	tag_t tPartNumberRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	tag_t tQueriedDivPartRev = NULLTAG;
	string sLLASerialNumber;
	string sLLAPartNumber;
	string sLLARevStamp;

	//input line validation
	if (inputValues.size() == 3) {
		sLLASerialNumber = inputValues[0];
		sLLAPartNumber = inputValues[1];
		sLLARevStamp = inputValues[2];
	}
	else {
		strItemId = "";
		strErroCode = TERADYNE_INPUT_LINE_OF_CSV_NOT_VALID;
		return 0;
	}

	//string strErroMessage = NULL;

	logical bValidClosureValue = false;
	const char * __function__ = "read_record_postaction_on_repairconfigcsv";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_find_item(sRepairOrderNumber.c_str(), &tRepairOrder), TD_LOG_ERROR_AND_THROW);

		if (tRepairOrder != NULLTAG) {
			TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tRepairOrder, &tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

			BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tRepairOrderRev);

			std::string sDivPart("");
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_PART_NUMBER, sDivPart, bIsNull), TD_LOG_ERROR_AND_THROW);
			string sPartType = TD4_DIVISIONAL_PART;
			if (sDivPart.empty()) {
				TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_COMM_PART_NUMBER, sDivPart, bIsNull), TD_LOG_ERROR_AND_THROW);
				sPartType = TD4_COMMERCIAL_PART;
			}
			if (sDivPart.empty()) {
				TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_REP_MANAGE_PART, sDivPart, bIsNull), TD_LOG_ERROR_AND_THROW);
				sPartType = TD7_REPAIR_MANAGED_PART;
			}

			if (!sLLAPartNumber.empty()) {

				TERADYNE_TRACE_CALL(get_hla_part_number_repairconfigcsv(sLLAPartNumber, sLLARevStamp, sPartType, sDivPart, tQueriedDivPartRev), TD_LOG_ERROR_AND_THROW);
				tPartNumberRev = tQueriedDivPartRev;

				if (tPartNumberRev != NULLTAG) {
					tag_t tLLASerial = NULLTAG;
					tag_t tLLASerialRev = NULLTAG;

					int iLLACount = 0;
					TERADYNE_TRACE_CALL(query_lla_serial_number_revs_repair_config_csv(sLLASerialNumber.c_str(), SERIALNUMBER, iLLACount, tLLASerial), TD_LOG_ERROR_AND_THROW);

					if (tLLASerial == NULLTAG) {
						TERADYNE_TRACE_CALL(is_new_lla_config(sLLASerialNumber, sLLASerialNumber, sLLARevStamp, sDivPart, tRepairOrderRev, tPartNumberRev), TD_LOG_ERROR_AND_THROW);
					}

					else {
						bool bObjectFound = FALSE;

						tag_t tRelation = NULLTAG;

						TERADYNE_TRACE_CALL(get_serial_number_revision_based_on_revstamp(tLLASerial, sLLARevStamp, tLLASerialRev), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(is_psn_attched_with_lla_repairconfigcsv(tLLASerialRev, TD7_PART_SERIAL_REL, tPartNumberRev, bObjectFound), TD_LOG_ERROR_AND_THROW);

						if (bObjectFound) {
							bool isExistingConfigObjects = false;
							TERADYNE_TRACE_CALL(validate_previous_configs_in_same_ro(tRepairOrderRev, tLLASerialRev, tPartNumberRev, isExistingConfigObjects), TD_LOG_ERROR_AND_THROW);
							if (!isExistingConfigObjects) {
								TERADYNE_TRACE_CALL(is_same_hla_sn_and_hla_pn(tRepairOrderRev, tLLASerialRev, sLLARevStamp, tPartNumberRev, isSameHLASNAndPN), TD_LOG_ERROR_AND_THROW);
								if (!isSameHLASNAndPN) {

									char* cSerialNumberStatus = NULL;
									TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, TD7_SERIAL_NUMBER_STATUS, &cSerialNumberStatus), TD_LOG_ERROR_AND_THROW);
									if (tc_strcmp(cSerialNumberStatus, "In Progress") != 0) {
										TERADYNE_TRACE_CALL(attach_all_lla_into_config_objects(tLLASerialRev, sLLARevStamp, isSameHLASNAndPN, tPartNumberRev, tRepairOrderRev, sDivPart), TD_LOG_ERROR_AND_THROW);
									}
									else {
										char* cpRoId = NULL;
										char* cpSerialId = NULL;
										char* cpSerialRev = NULL;
										TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, OBJECT_NAME, &cpSerialId), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, ITEM_REVISION_ID, &cpSerialRev), TD_LOG_ERROR_AND_THROW);
										tag_t tRelationType = NULLTAG;
										tag_t* tpPrimaryObjects = NULLTAG;
										tag_t tReapriRev = NULLTAG;
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIR_SERIAL_NO_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);
										int iPrimaryCnt = 0;

										TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tLLASerialRev, tRelationType, &iPrimaryCnt, &tpPrimaryObjects), TD_LOG_ERROR_AND_THROW);
										if (iPrimaryCnt > 0) {
											tReapriRev = tpPrimaryObjects[0];
										}

										if (tReapriRev == NULLTAG) {
											tag_t tSolRelationType = NULLTAG;
											tag_t* tpSOlPrimaryObjects = NULLTAG;
											TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolRelationType), TD_LOG_ERROR_AND_THROW);
											int iSolPrimaryCnt = 0;

											TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tLLASerialRev, tSolRelationType, &iSolPrimaryCnt, &tpSOlPrimaryObjects), TD_LOG_ERROR_AND_THROW);
											if (iSolPrimaryCnt > 0) {
												tReapriRev = tpSOlPrimaryObjects[0];
											}
										}
										if (tReapriRev == NULLTAG) {
											tag_t tInRelationType = NULLTAG;
											tag_t* tpInPrimaryObjects = NULLTAG;
											TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tInRelationType), TD_LOG_ERROR_AND_THROW);
											int iInPrimaryCnt = 0;

											TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tLLASerialRev, tInRelationType, &iInPrimaryCnt, &tpInPrimaryObjects), TD_LOG_ERROR_AND_THROW);
											if (iInPrimaryCnt > 0) {
												tReapriRev = tpInPrimaryObjects[0];
											}
										}
										
										if (tReapriRev != NULLTAG) {
											char* cpRoId = NULL;
											char* cpSerialId = NULL;
											TERADYNE_TRACE_CALL(AOM_ask_value_string(tReapriRev, ITEM_ID, &cpRoId), TD_LOG_ERROR_AND_THROW);
											TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, OBJECT_NAME, &cpSerialId), TD_LOG_ERROR_AND_THROW);
											strItemId = strItemId.append(cpSerialId);
											strItemId = strItemId.append(" -- ");
											strItemId = strItemId.append(cpRoId);
										} else{
											strItemId = "";
										}
										strErroCode = TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR;
										return 0;
									}
								}
								else {
									TERADYNE_TRACE_CALL(attach_all_lla_into_config_objects(tLLASerialRev, sLLARevStamp, isSameHLASNAndPN, tPartNumberRev, tRepairOrderRev, sDivPart), TD_LOG_ERROR_AND_THROW);
								}
							}
							else {
								char* cSerialNumber = NULL;
								char* cPartNumber = NULL;
								TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, OBJECT_NAME, &cSerialNumber), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_ask_value_string(tPartNumberRev, ITEM_ID, &cPartNumber), TD_LOG_ERROR_AND_THROW);
								//string sErrorValue = "";
								strItemId = strItemId.append(cSerialNumber);
								strItemId = strItemId.append(" - ");
								strItemId = strItemId.append(cPartNumber);

								strErroCode = TERADYNE_DUPLICATE_CONFIG_LINE;
								return 0;
							}
						}
						else {

							bool isValidateToRemoveExistingPartNumber = false;
							TERADYNE_TRACE_CALL(validation_to_remove_part_number_if_revstamp_mismtach(tRepairOrderRev, tPartNumberRev, sLLASerialNumber, sLLAPartNumber, sLLARevStamp, isValidateToRemoveExistingPartNumber), TD_LOG_ERROR_AND_THROW);

							if (isValidateToRemoveExistingPartNumber) {
								TERADYNE_TRACE_CALL(attach_all_lla_into_config_objects(tLLASerialRev, sLLARevStamp, isSameHLASNAndPN, tPartNumberRev, tRepairOrderRev, sDivPart), TD_LOG_ERROR_AND_THROW);
							}
							else {

								std::string sSerialNumber = "";
								std::string sPartNumber = "";
								int iLastChars = 5;
								tag_t tSerialNumRev = NULLTAG;
								sSerialNumber = sSerialNumber.append(sLLASerialNumber);
								//requirement changes
								sPartNumber = removeSpecialCharactors(sLLAPartNumber);
								//sPartNumber = sPartNumber.substr(0, 5);
								if (iLastChars < sPartNumber.length()) {
									sPartNumber = sPartNumber.substr(sPartNumber.length() - iLastChars);
								}
								sSerialNumber = sSerialNumber.append(sPartNumber);
								TERADYNE_TRACE_CALL(is_new_lla_config(sLLASerialNumber, sSerialNumber, sLLARevStamp, sDivPart, tRepairOrderRev, tPartNumberRev), TD_LOG_ERROR_AND_THROW);
							}
						}
						/**}
						else {
							strErroCode = TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR;
							return 0;
						}*/
					}
				}
				else {
				    strItemId = sDivPart;
					strErroCode = TERADYNE_PART_NUMBER_DOES_NOT_EXIST;
					return 0;
				}
			}

		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int query_lla_serial_number_revs_repair_config_csv(string sLLASerialNumberID, string sType, int iCount, tag_t& tLLASerial)
{
	int iStatus = ITK_ok;
	const char * __function__ = "query_lla_serial_number_revs_repair_config_csv";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sLLASerialNumberID.empty()) {
			iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_NAME, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sLLASerialNumberID.c_str(), sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

				if (iFound > 0)
				{
					tLLASerial = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
				//MEM_FREE(cpEntries);
				//MEM_FREE(cpValues);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int is_new_lla_config(string sLLASerialNumberID, string sLLASerialNumber, string sLLARevStamp, string sDivPart, tag_t tRepairOrderRev, tag_t tPartNumberRev) {
	int iStatus = ITK_ok;
	int iLLACount = 0;
	tag_t tLLASerial = NULLTAG;
	tag_t tLLASerialRev = NULLTAG;

	const char * __function__ = "is_new_lla_config";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(query_lla_serial_number_revs_repair_config_csv(sLLASerialNumber.c_str(), SERIALNUMBER, iLLACount, tLLASerial), TD_LOG_ERROR_AND_THROW);
		if (tLLASerial == NULLTAG) {
			TERADYNE_TRACE_CALL(teradyne_create_custom_object(TD7_PART_SERIAL_NUM, sLLASerialNumberID, "A", sLLASerialNumber, tLLASerial), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tLLASerial, &tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (tLLASerialRev != NULLTAG) {
			TERADYNE_TRACE_CALL(attach_all_lla_into_config_objects(tLLASerialRev, sLLARevStamp, false, tPartNumberRev, tRepairOrderRev, sDivPart), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int attach_all_lla_into_config_objects(tag_t tLLASerialRev, string sLLARevStamp, bool isSameHLASNAndPN, tag_t tPartNumberRev, tag_t tRepairOrderRev, string sDivPart) {
	int iStatus = ITK_ok;
	tag_t tHLAPart = NULLTAG;
	tag_t tHLAPartRev = NULLTAG;
	int iReleaseStatusCount = 0;
	tag_t* tReleaseStatusList = NULLTAG;
	tag_t tReleaseStatus = NULLTAG;
	tag_t tSerialNum = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	bool bisverdict = false;
	const char * __function__ = "attach_all_lla_into_config_objects";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(AOM_ask_value_tags(tLLASerialRev, RELEASE_STATUS_LIST, &iReleaseStatusCount, &tReleaseStatusList), TD_LOG_ERROR_AND_THROW);
		// Add Released status (Locked) for Incoming Objects
		if (iReleaseStatusCount > 0) {
			TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tLLASerialRev, &tSerialNum), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(revise_object(tSerialNum, tRevisedObject), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(remove_secondary_objects(tRevisedObject, TD7_REPAIRS_REL), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(remove_secondary_objects(tRevisedObject, TD7_PART_SERIAL_REL), TD_LOG_ERROR_AND_THROW);

			tLLASerialRev = tRevisedObject;
			TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tLLASerialRev, tPartNumberRev, TD7_PART_SERIAL_REL), TD_LOG_ERROR_AND_THROW);
		}

		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tLLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_SERIAL_NUMBER_STATUS, "In Progress"), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_REV_STAMP, sLLARevStamp.c_str()), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);


		if (!isSameHLASNAndPN) {
			TC_write_syslog("Attaching to div part");
			TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tLLASerialRev, tPartNumberRev, TD7_PART_SERIAL_REL), TD_LOG_ERROR_AND_THROW);
		}


		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tLLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_IS_ALLOW_INPROGRESS_SN, "false"), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save_without_extensions(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);


		TC_write_syslog("********** Attaching  LLA Part Number into Repair Order***\n");
		TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tLLASerialRev, TD7_INCOMING_CONFIG_REL), TD_LOG_ERROR_AND_THROW);

		// is allow 'In Progress Serial Number
		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tLLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_IS_ALLOW_INPROGRESS_SN, "true"), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save_without_extensions(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);
		TERADYNE_TRACE_CALL(AOM_ask_value_tags(tLLASerialRev, RELEASE_STATUS_LIST, &iReleaseStatusCount, &tReleaseStatusList), TD_LOG_ERROR_AND_THROW);

		// Add Released status (Locked) for Incoming Objects
		if (iReleaseStatusCount == 0) {
			TERADYNE_TRACE_CALL(RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleaseStatus), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(RELSTAT_add_release_status(tReleaseStatus, 1, &tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
			//TERADYNE_TRACE_CALL(AOM_save_without_extensions(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		}

		TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tLLASerialRev, &tSerialNum), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(revise_object(tSerialNum, tRevisedObject), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(remove_secondary_objects(tRevisedObject, TD7_REPAIRS_REL), TD_LOG_ERROR_AND_THROW);
		//TERADYNE_TRACE_CALL(AOM_save_without_extensions(tRevisedObject), TD_LOG_ERROR_AND_THROW);
		tLLASerialRev = tRevisedObject;

		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tLLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_IS_ALLOW_INPROGRESS_SN, "false"), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save_without_extensions(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);

		TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tLLASerialRev, TD7_SOLUTION_CONFIG_REL), TD_LOG_ERROR_AND_THROW);

		POM_AM__set_application_bypass(true);
		TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tLLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, true), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_set_value_string(tLLASerialRev, TD7_IS_ALLOW_INPROGRESS_SN, "true"), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save_without_extensions(tLLASerialRev), TD_LOG_ERROR_AND_THROW);
		if (!bisverdict)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tLLASerialRev, false), TD_LOG_ERROR_AND_THROW);
		}
		POM_AM__set_application_bypass(false);


		if (!sDivPart.empty()) {
			TERADYNE_TRACE_CALL(ITEM_find_item(sDivPart.c_str(), &tHLAPart), TD_LOG_ERROR_AND_THROW);

			if (tHLAPart != NULLTAG) {
				TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tHLAPart, &tHLAPartRev), TD_LOG_ERROR_AND_THROW);
			}

			TERADYNE_TRACE_CALL(td7_override_part_serial_relation_create_post(tLLASerialRev, tPartNumberRev, tHLAPartRev), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_closure_value_of_existing_repair_orders_repair_config_csv(tag_t tSecondaryObj, bool &bValidClosureValue) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpPrimaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	char* cpItemId = NULL;
	bool isValidSN = false;
	const char * __function__ = "validate_closure_value_of_existing_repair_orders_repair_config_csv";
	TERADYNE_TRACE_ENTER();
	try {

		if (tSecondaryObj == NULLTAG)
		{
			return iStatus;
		}
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondaryObj, ITEM_ID, &cpItemId), TD_LOG_ERROR_AND_THROW);
		tag_t tRelationType = NULLTAG;
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIR_SERIAL_NO_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);
		int iPrimaryCnt = 0;

		TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tSecondaryObj, tRelationType, &iPrimaryCnt, &tpPrimaryObjects), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < iPrimaryCnt; i++)
		{
			logical bIsNull = false;
			TERADYNE_TRACE_ENTER();
			char* sClosureValue = NULL;
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tpPrimaryObjects[i], TD7_BAT_CLOSURE, &sClosureValue), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sClosureValue, "Open") == 0)
			{
				//Display the error message if Customer not found.
				iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR, cpItemId);
				iStatus = TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR;
				throw iStatus;
			}
		}

		bValidClosureValue = TRUE;

	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_serial_number_revision_based_on_revstamp(tag_t tLLASerial, string sLLARevStamp, tag_t& tLLASerialRev) {
	int iStatus = ITK_ok;
	char* cpSerialNumberType = NULL;
	char* cpRevStamp = NULL;
	int iSerialNumRevisionsCount = 0;
	tag_t* tSerialNumberRevisions = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	const char * __function__ = "get_serial_number_revision_based_on_revstamp";
	TERADYNE_TRACE_ENTER();
	try {

		//TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart));
		if (tLLASerial != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerial, OBJECT_TYPE, &cpSerialNumberType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpSerialNumberType, TD7_PART_SERIAL_NUM) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tLLASerial, &iSerialNumRevisionsCount, &tSerialNumberRevisions), TD_LOG_ERROR_AND_THROW);
				if (iSerialNumRevisionsCount > 0) {
					for (int i = 0; i < iSerialNumRevisionsCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRevisions[i], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sLLARevStamp.c_str(), cpRevStamp) == 0) {
							tSerialNumRev = tSerialNumberRevisions[i];
							break;
						}
					}
					// if there is no Rev Stamp matches, get the latest revision
					if (tSerialNumRev == NULLTAG) {
						tag_t tRevisedObject = NULLTAG;
						//TERADYNE_TRACE_CALL(revise_object(tLLASerial, tRevisedObject));
						//TERADYNE_TRACE_CALL(remove_secondary_objects(tRevisedObject, TD7_REPAIRS_REL));
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tLLASerial, &tRevisedObject), TD_LOG_ERROR_AND_THROW);
						tSerialNumRev = tRevisedObject;
					}
					tLLASerialRev = tSerialNumRev;
				}
			}
		}

	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_serial_number_status_of_all_the_sn_revisions(tag_t tLLASerial, string sLLARevStamp, bool& isSerialNumValid) {
	int iStatus = ITK_ok;
	/**char* cpSerialNumberType = NULL;
	char* cpSnStauts = NULL;
	int iSerialNumRevisionsCount = 0;
	tag_t* tSerialNumberRevisions = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	TERADYNE_TRACE_ENTER();
	try {

		//TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart));
		if (tLLASerial != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerial, OBJECT_TYPE, &cpSerialNumberType));
			if (tc_strcmp(cpSerialNumberType, TD7_PART_SERIAL_NUM) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tLLASerial, &iSerialNumRevisionsCount, &tSerialNumberRevisions));
				if (iSerialNumRevisionsCount > 0) {
					for (int i = 0; i < iSerialNumRevisionsCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRevisions[i], TD7_SERIAL_NUMBER_STATUS, &cpSnStauts));
						if (tc_strcmp(cpSnStauts, "In Progress") == 0) {
							isSerialNumValid = true;
							return 0;

						}
					}

				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();*/
	return iStatus;
}

int get_hla_part_number_repairconfigcsv(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, string sDivPart, tag_t& tQueriedDivPartRev) {

	int iStatus = ITK_ok;
	int iDivCount = 0;
	int iCommercialPartRevCount = 0;
	int iRepairManagedPartRevCount = 0;
	tag_t tDivPart = NULLTAG;
	tag_t tCustomerRev = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tCustomerOrderRev = NULLTAG;
	tag_t tSerialNum = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tDivPartRev = NULLTAG;
	tag_t tQueriedRepManagePart = NULLTAG;
	tag_t tQueriedRepManagePartRev = NULLTAG;
	tag_t tRepairMenagePartRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	tag_t tRepairOrder = NULLTAG;

	tag_t tCommercialPart = NULLTAG;
	tag_t tCommercilaPartRev = NULLTAG;
	tag_t tRepairManagedPartRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t* tCommercilaPartRevs = NULLTAG;
	tag_t* tRepairManagedPartRevs = NULLTAG;
	char* cpCommercialType = NULL;
	char* cpCommercialRevType = NULL;

	// get the div part repair group
	int iProjectCount = 0;
	tag_t* tProjectList = NULLTAG;
	bool bisverdict = false;
	const char * __function__ = "get_hla_part_number_repairconfigcsv";
	TERADYNE_TRACE_ENTER();
	try {
		if (tc_strcmp(sLLAPartType.c_str(), TD4_DIVISIONAL_PART) == 0) {
			TERADYNE_TRACE_CALL(get_divisionla_part_with_revstamp(sLLAPartNumber, sLLARevStamp, tDivPartRev), TD_LOG_ERROR_AND_THROW);
		}
		// Validate Commercial Part.
		if (tc_strcmp(sLLAPartType.c_str(), TD4_COMMERCIAL_PART) == 0) {
			TERADYNE_TRACE_CALL(ITEM_find_item(sLLAPartNumber.c_str(), &tCommercialPart), TD_LOG_ERROR_AND_THROW);

			if (tCommercialPart != NULLTAG) {
					TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tCommercialPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
					tDivPartRev = tLatestRevTag;
			}
		}


		if (tDivPartRev == NULLTAG) {

			int iRepCount = 0;

			TERADYNE_TRACE_CALL(query_item(sLLAPartNumber, REP_MANAGED_PART, iRepCount, tQueriedRepManagePart), TD_LOG_ERROR_AND_THROW);
			if (tQueriedRepManagePart != NULLTAG) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tQueriedRepManagePart, &iRepairManagedPartRevCount, &tRepairManagedPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iRepairManagedPartRevCount > 0) {
					char* cpRevStamp = NULL;
					for (int i = 0; i < iRepairManagedPartRevCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairManagedPartRevs[i], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sLLARevStamp.c_str(), cpRevStamp) == 0) {
							tRepairManagedPartRev = tRepairManagedPartRevs[i];
						}

					}
					if (tRepairManagedPartRev == NULLTAG) {
						TERADYNE_TRACE_CALL(revise_object(tQueriedRepManagePart, tRevisedObject), TD_LOG_ERROR_AND_THROW);
						//TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tQueriedRepManagePart, &tRevisedObject));


						POM_AM__set_application_bypass(true);
						TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRevisedObject, &bisverdict), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict) {
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRevisedObject, true), TD_LOG_ERROR_AND_THROW);
						}

						TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tRevisedObject, TD7_REV_STAMP, sLLARevStamp.c_str()), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tRevisedObject), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRevisedObject, false), TD_LOG_ERROR_AND_THROW);
						}
						POM_AM__set_application_bypass(false);

						tRepairManagedPartRev = tRevisedObject;
					}
					tDivPartRev = tRepairManagedPartRev;

				}
			}
		}

		if (tDivPartRev == NULLTAG) {
			tag_t tRepManagePartRev = NULLTAG;
			TERADYNE_TRACE_CALL(create_repair_managed_part_repairconfigcsv(sLLAPartNumber, sLLARevStamp, sDivPart, tRepManagePartRev), TD_LOG_ERROR_AND_THROW);

			if (tRepManagePartRev != NULLTAG) {
				tDivPartRev = tRepManagePartRev;
			}
		}
		tQueriedDivPartRev = tDivPartRev;
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(cpCommercialType);
	TERADYNE_MEM_FREE(cpCommercialRevType);
	TERADYNE_MEM_FREE(tProjectList);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_divisionla_part_with_revstamp(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev) {
	int iStatus = ITK_ok;
	int iDivisionalPartRevCount = 0;
	char* cpDivisionalPartType = NULL;
	char* cpRevStamp = NULL;
	tag_t tDivisionalPart = NULLTAG;
	tag_t* tDivisionalPartRevs = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t tDivPartRevTag = NULLTAG;
	const char * __function__ = "get_divisionla_part_with_revstamp";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart), TD_LOG_ERROR_AND_THROW);
		if (tDivisionalPart != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPart, OBJECT_TYPE, &cpDivisionalPartType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpDivisionalPartType, TD4_DIVISIONAL_PART) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tDivisionalPart, &iDivisionalPartRevCount, &tDivisionalPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iDivisionalPartRevCount > 0) {
					for (int i = 0; i < iDivisionalPartRevCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPartRevs[i], TD4_TERADYNE_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sPartRevStamp.c_str(), cpRevStamp) == 0) {
							tDivPartRevTag = tDivisionalPartRevs[i];
						}
					}
					// if there is no Rev Stamp matches, get the latest revision
					if (tDivPartRevTag == NULLTAG) {
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tDivisionalPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
						tDivPartRevTag = tLatestRevTag;
					}
					tQueriedPartRev = tDivPartRevTag;
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//int query_item(string sItemId, string sType, int iCount, tag_t& tItemRev)
//{
	//int iStatus = ITK_ok;

	// TERADYNE_TRACE_ENTER();
	// try
	// {
		// tag_t tSavedQuery = NULLTAG;

		// if (!sItemId.empty()) {
			// iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			// if (tSavedQuery != NULLTAG)
			// {

				// char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				// const char * cpValues[] = { sItemId.c_str() , sType.c_str() };

				// int iFound = 0;
				// tag_t* tpResults = NULL;
				// TERADYNE_TRACE_AND_THROW(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults));

				// if (iFound > 0)
				// {
					// tItemRev = tpResults[0];
				// }
				// TERADYNE_MEM_FREE(tpResults);
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;

//}

//create hla serial number
int create_attach_serial_number_repairconfigcsv(string sSerialNumberId, string sObjectName, tag_t tPartRev, tag_t& tSerialNumRev)
{
	int iStatus = ITK_ok;

	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;
	const char * __function__ = "create_attach_serial_number_repairconfigcsv";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sSerialNumberId.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM, TD7_PART_SERIAL_NUM, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSerialNumberId.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObjectName.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM_REVISION, TD7_PART_SERIAL_NUM_REVISION, &tItemRevTypeTag), TD_LOG_ERROR_AND_THROW);
			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

			//TERADYNE_TRACE_AND_THROW(iStatus = AOM_refresh(tNewItem, false));

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tSerialNumRev), TD_LOG_ERROR_AND_THROW);

			//if (tSerialNumRev != NULLTAG && tPartRev != NULLTAG) {
				//tag_t tRelationType = NULLTAG;
				//TERADYNE_TRACE_AND_THROW(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationType));

				//tag_t tRelation = NULLTAG;
				//TERADYNE_TRACE_AND_THROW(GRM_create_relation(tSerialNumRev, tPartRev, tRelationType, NULLTAG, &tRelation));

				//TERADYNE_TRACE_AND_THROW(GRM_save_relation(tRelation));

			//}

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

// int revise_object(tag_t tItem, tag_t& tItemReviseTag) {
	// int iStatus = ITK_ok;
	// int numObjs = 0;
	// int *ifails = 0;
	// tag_t tItemRevTag = NULLTAG;
	// tag_t itemRevType = NULLTAG;
	// tag_t reviseDescTag = NULLTAG;
	// tag_t reviseInputTag = NULLTAG;
	// tag_t *deepCopyData = NULLTAG;
	// tag_t *targetCopyTags = NULLTAG;
	// try
	// {

		// TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tItem, &tItemRevTag));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_object_type(tItemRevTag, &itemRevType));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_revise_descriptor(itemRevType, &reviseDescTag));
		// TERADYNE_TRACE_CALL(TCTYPE_construct_operationinput(itemRevType, TCTYPE_OPERATIONINPUT_REVISE, &reviseInputTag));
		// TERADYNE_TRACE_CALL(TCTYPE_ask_deepcopydata(tItemRevTag, TCTYPE_OPERATIONINPUT_REVISE,
			// &numObjs, &deepCopyData));
		// TERADYNE_TRACE_CALL(TCTYPE_revise_objects(1, &tItemRevTag, &reviseInputTag, &numObjs,
			// deepCopyData, &targetCopyTags, &ifails));
		// if (numObjs > 0) {
			// tItemReviseTag = targetCopyTags[0];
			// CHAR * itemId = NULL;
			// TERADYNE_TRACE_CALL(AOM_ask_value_string(tItemReviseTag, ITEM_ID, &itemId));

		// }
		// /**if (numObjs > 0) {

			// for (int i = 0; i < numObjs; i++) {
				// char * itemId = NULL;
				// char * itemRevId = NULL;
				// TERADYNE_TRACE_CALL(AOM_ask_value_string(targetCopyTags[i], ITEM_ID, &itemId));
				// TERADYNE_TRACE_CALL(AOM_ask_value_string(targetCopyTags[i], ITEM_REVISION_ID, &itemRevId));
				// if (tc_strcmp(itemId, NULL) != 0) {
					// tItemReviseTag = targetCopyTags[i];
				// }
			// }
		// }*/
	// }
	// catch (std::exception& err)
	// {
		// std::cout << "Error: " << err.what() << std::endl;
	// }
	// return iStatus;
// }

// int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev)
// {
	// int iStatus = ITK_ok;

	// TERADYNE_TRACE_ENTER();
	// try
	// {
		// tag_t tSavedQuery = NULLTAG;

		// if (!sLlaSerialNumber.empty()) {
			// iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			// if (tSavedQuery != NULLTAG)
			// {

				// char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_TYPE };
				// const char * cpValues[] = { sLlaSerialNumber.c_str() , sType.c_str() };

				// int iFound = 0;
				// tag_t* tpResults = NULL;
				// TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults));

				// if (iFound > 0)
				// {
					// tQueriedSerialRev = tpResults[0];
				// }
				// TERADYNE_MEM_FREE(tpResults);
				// //MEM_FREE(cpEntries);
				// //MEM_FREE(cpValues);
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;

// }

/**int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev)
{
	int iStatus = ITK_ok;

	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sPartNumber.empty()) {
			iStatus = QRY_find2(QUERY_ITEM_REVISION, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_ITEM_ID, QUERY_INPUT_REVISION, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sPartNumber.c_str() , sPartNumberRev.c_str(), sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 3, cpEntries, (char**)cpValues, &iFound, &tpResults));

				if (iFound > 0)
				{
					tQueriedPartRev = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
				//MEM_FREE(cpEntries);
				//MEM_FREE(cpValues);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}*/


// int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj) {

	// int iStatus = 0;
	// tag_t tCreateType = NULLTAG;
	// tag_t tCreateRevType = NULLTAG;
	// tag_t tItemCreateInput = NULLTAG;

	// TERADYNE_TRACE_ENTER();
	// try {
		// TERADYNE_TRACE_CALL(TCTYPE_find_type(sObjType.c_str(), NULL, &tCreateType));

		// if (iStatus == ITK_ok && tCreateType != NULLTAG)
		// {
			// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput));

			// if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			// {

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sItemdId.c_str()));
				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObject_name.c_str()));

				// if (sObjType.compare(TD7_REPAIR_MANAGED_PART) == 0) {

					// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART_REVISION, NULL, &tCreateRevType));

					// tag_t   tItemRevCreateInput = NULLTAG;
					// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput));

					// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, sItemRevId.c_str()));

					// TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput));
				// }
				// TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj));

				// if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				// {
					// TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj));
					// TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false));
				// }
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

// int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	// int iStatus = 0;
	// tag_t tNewRel = NULLTAG;
	// tag_t tRelation = NULLTAG;
	// TERADYNE_TRACE_ENTER();
	// try {
		// TERADYNE_TRACE_AND_THROW(GRM_find_relation_type(sAttachRel.c_str(), &tRelation));
		// if (tRelation != NULLTAG) {
			// TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel));
			// TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel));
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

// int td7_override_part_serial_relation_create_post(tag_t tLLApartNumber, tag_t tPrimaryObject, tag_t tSecondaryObject) {

	// int iStatus = ITK_ok;
	// tag_t* tBomViewRevisionTag = NULLTAG;
	// tag_t tWinTag = NULLTAG;
	// tag_t tTopLine = NULLTAG;
	// int iBomViewRevisionCount = 0;
	// bool bCompFound = false;
	// bool bIsNull = false;
	// TERADYNE_TRACE_ENTER();
	// try {
		// BusinessObjectRef< Teamcenter::BusinessObject > boPrimaryObject(tPrimaryObject);
		// std::string sPartNumber;
		// TERADYNE_TRACE_CALL(boPrimaryObject->getString(ITEM_ID, sPartNumber, bIsNull));

		// ITEM_rev_list_all_bom_view_revs(tSecondaryObject, &iBomViewRevisionCount, &tBomViewRevisionTag);

		// if (iBomViewRevisionCount > 0) {

			// TERADYNE_TRACE_CALL(BOM_create_window(&tWinTag));
			// TERADYNE_TRACE_CALL(BOM_set_window_top_line_bvr(tWinTag, tBomViewRevisionTag[0], &tTopLine));
			// TERADYNE_TRACE_CALL(traverse_BOM_import_repairconfigcsv(tTopLine, sPartNumber, bCompFound));

			// BusinessObjectRef< Teamcenter::BusinessObject > boLLApartNumber(tLLApartNumber);
			// AcquireLock lockOnLLApartNum(tLLApartNumber);
			// if (bCompFound) {
				// TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, YES, false)));
			// }
			// else {
				// TERADYNE_TRACE_CALL((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, NO, false)));
			// }
			// TERADYNE_TRACE_CALL(BOM_close_window(tWinTag));

			// TERADYNE_TRACE_CALL(AOM_save(tLLApartNumber));
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

/**int traverse_BOM(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t* children_tag = NULLTAG;
	int childrens = 0;
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boBomLineRevisionTag(tBomLineRevisionTag);
		std::string sItemId;
		TERADYNE_TRACE_CALL(boBomLineRevisionTag->getString(BL_ITEM_ITEM_ID, sItemId, bIsNull));

		if (!bCompFound) {
			if (tc_strcmp(sItemId.c_str(), sPartNumber.c_str()) == 0) {
				bCompFound = true;
			}
			//BOM line ask child line
			TERADYNE_TRACE_CALL(BOM_line_ask_child_lines(tBomLineRevisionTag, &childrens, &children_tag));
			if (childrens > 0) { //If the item has childern

				for (int child = 0; child < childrens; child++) {

					TERADYNE_TRACE_CALL(traverse_BOM(children_tag[child], sPartNumber, bCompFound)); // Run recursive function to get all bom lines.
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	TERADYNE_MEM_FREE(children_tag);
	return iStatus;
}*/

int is_psn_attched_with_lla_repairconfigcsv(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	char* cpSerialNumberID = NULL;
	char* cpPartNumberID = NULL;
	const char * __function__ = "is_psn_attched_with_lla_repairconfigcsv";
	TERADYNE_TRACE_ENTER();
	try {
		if (tSecondaryObj == NULLTAG || sRelation.empty() || tPrimaryObj == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(sRelation.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;

		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObj, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iSecondaryCnt > 0) {

			for (int i = 0; i < iSecondaryCnt; i++)
			{
				//get part num id
				char* cpPartNumberID = NULL;
				char* cpConfigPartID = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondaryObj, ITEM_ID, &cpPartNumberID), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryObjects[i], ITEM_ID, &cpConfigPartID), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(cpPartNumberID, cpConfigPartID) == 0)
				{
					bObjectFound = TRUE;
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();

	return iStatus;

}

int is_same_hla_sn_and_hla_pn(tag_t tRepairOrderRev, tag_t tLLASerialRev, string sLLARevStamp, tag_t tLLAPartNumberRev, bool &isSameHLASNAndPN) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t * tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "is_same_hla_sn_and_hla_pn";
	TERADYNE_TRACE_ENTER();
	try {

		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIR_SERIAL_NO_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;

		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iSecondaryCnt > 0) {
			for (int i = 0; i < iSecondaryCnt; i++)
			{
				if (tLLASerialRev == tpSecondaryObjects[i])
				{
					tag_t tPartRelationType = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);

					int iSecondaryPartCnt = 0;

					//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i], tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects), TD_LOG_ERROR_AND_THROW);

					if (iSecondaryPartCnt > 0) {
						for (int i = 0; i < iSecondaryPartCnt; i++)
						{
							if (tLLAPartNumberRev == tpSecondaryPartObjects[i])
							{

								POM_AM__set_application_bypass(true);
								bool bisverdict = false;
								//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
								TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
								if (!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
								}
								TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_HLA_REVSTAMP_IN, sLLARevStamp.c_str()), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_save_without_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
								if (!bisverdict)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
								}
								POM_AM__set_application_bypass(false);
								isSameHLASNAndPN = TRUE;
							}
						}
					}
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();

	return iStatus;

}

int validate_previous_configs_in_same_ro(tag_t tRepairOrderRev, tag_t tLLASerialRev, tag_t tLLAPartNumberRev, bool &isExistingConfigObjects) {
	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t * tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	const char * __function__ = "validate_previous_configs_in_same_ro";
	TERADYNE_TRACE_ENTER();
	try {

		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;

		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		//get serial num id
		char* cpSerialNumberID = NULL;
		char* cpConfigSerialID = NULL;
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, ITEM_ID, &cpSerialNumberID), TD_LOG_ERROR_AND_THROW);


		if (iSecondaryCnt > 0) {
			for (int i = 0; i < iSecondaryCnt; i++)
			{
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryObjects[i], ITEM_ID, &cpConfigSerialID), TD_LOG_ERROR_AND_THROW);
				//	if (tLLASerialRev == tpSecondaryObjects[i])
				if (tc_strcmp(cpSerialNumberID, cpConfigSerialID) == 0)
				{
					tag_t tPartRelationType = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);

					int iSecondaryPartCnt = 0;

					//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i], tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects), TD_LOG_ERROR_AND_THROW);

					//get part num id
					char* cpPartNumberID = NULL;
					char* cpConfigPartID = NULL;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLAPartNumberRev, ITEM_ID, &cpPartNumberID), TD_LOG_ERROR_AND_THROW);

					if (iSecondaryPartCnt > 0) {
						for (int i = 0; i < iSecondaryPartCnt; i++)
						{
							TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryPartObjects[i], ITEM_ID, &cpConfigPartID), TD_LOG_ERROR_AND_THROW);
							//if (tLLAPartNumberRev == tpSecondaryPartObjects[i])
							if (tc_strcmp(cpPartNumberID, cpConfigPartID) == 0)
							{
								isExistingConfigObjects = TRUE;
							}

						}
					}
				}
			}
		}



	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();

	return iStatus;
}

int is_same_hla_sn_and_hla_pn_to_set_rev_Stamp(string sRepairOrderNumber, bool &isSameHLASNAndPN) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	int iSolSecondaryCnt = 0;
	tag_t tSolRelationType = NULLTAG;
	tag_t* tpSolSecondaryObjects = NULLTAG;
	tag_t* tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	tag_t tLLASerialRev = NULLTAG;
	tag_t tLLAPartNumberRev = NULLTAG;
	tag_t tRepairOrder = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;

	int iHLASerialCnt = 0;
	tag_t* tpHLASerialRevs = NULLTAG;
	tag_t tHLASerialNumRelationType = NULLTAG;
	int iHLAPartCnt = 0;
	tag_t* tpHLAPartRevs = NULLTAG;
	tag_t tHLAPartNumRelationType = NULLTAG;
	const char * __function__ = "is_same_hla_sn_and_hla_pn_to_set_rev_Stamp";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(ITEM_find_item(sRepairOrderNumber.c_str(), &tRepairOrder), TD_LOG_ERROR_AND_THROW);

		if (tRepairOrder != NULLTAG) {
			TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tRepairOrder, &tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

			// get HLA Serial Number
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tHLASerialNumRelationType), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tHLASerialNumRelationType, &iHLASerialCnt, &tpHLASerialRevs), TD_LOG_ERROR_AND_THROW);
			if (iHLASerialCnt > 0) {
				for (int i = 0; i < iHLASerialCnt; i++) {
					tLLASerialRev = tpHLASerialRevs[i];
					// get HLA Part Number
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tHLAPartNumRelationType), TD_LOG_ERROR_AND_THROW);
					if (tHLAPartNumRelationType != NULLTAG) {
						TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpHLASerialRevs[i], tHLAPartNumRelationType, &iHLAPartCnt, &tpHLAPartRevs), TD_LOG_ERROR_AND_THROW);
					}
					if (iHLAPartCnt > 0) {
						for (int j = 0; j < iHLAPartCnt; j++) {
							tLLAPartNumberRev = tpHLAPartRevs[j];
						}
					}
				}
			}


			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tSolRelationType), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tSolRelationType, &iSolSecondaryCnt, &tpSolSecondaryObjects), TD_LOG_ERROR_AND_THROW);
			if (iSolSecondaryCnt > 0) {
				for (int k = 0; k < iSolSecondaryCnt; k++)
				{
					char* cpSolutionitemId = NULL;
					char* cpRevStamp = NULL;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], ITEM_ID, &cpSolutionitemId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
					char* cpHLASNitemId = NULL;
					char* cpHLAPNitemId = NULL;
					AOM_ask_value_string(tLLASerialRev, ITEM_ID, &cpHLASNitemId);
					AOM_ask_value_string(tLLAPartNumberRev, ITEM_ID, &cpHLAPNitemId);

					//if (tLLASerialRev == tpSolSecondaryObjects[k])
					if (tc_strcmp(cpSolutionitemId, cpHLASNitemId) == 0)
					{
						tag_t tPartRelationType = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);
						int iSecondaryPartCnt = 0;
						//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
						TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSolSecondaryObjects[k], tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects), TD_LOG_ERROR_AND_THROW);

						if (iSecondaryPartCnt > 0) {

							for (int i = 0; i < iSecondaryPartCnt; i++)
							{
								char* cpSolutionPNitemId = NULL;
								AOM_ask_value_string(tpSecondaryPartObjects[i], ITEM_ID, &cpSolutionPNitemId);
								//if (tLLAPartNumberRev == tpSecondaryPartObjects[i])
								if (tc_strcmp(cpSolutionPNitemId, cpHLAPNitemId) == 0)
								{

									POM_AM__set_application_bypass(true);
									bool bisverdict = false;
									//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
									TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
									if (!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
									}
									TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_HLA_REVSTAMP_IN, cpRevStamp), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(AOM_save_without_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
									if (!bisverdict)
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
									}
									POM_AM__set_application_bypass(false);

									isSameHLASNAndPN = TRUE;
								}
							}
						}
					}
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validation_to_remove_part_number_if_revstamp_mismtach(tag_t tRepairOrderRev, tag_t tLLAPartNumRev, string sLLASerialNumber, string sLLAPartNumber, string sLLARevStamp, bool &isValidateToRemoveExistingPartNumber) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	int iSolSecondaryCnt = 0;
	tag_t tSolRelationType = NULLTAG;
	tag_t* tpSolSecondaryObjects = NULLTAG;
	tag_t* tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	tag_t tHLASerialRev = NULLTAG;
	tag_t tHLAPartNumberRev = NULLTAG;

	int iHLASerialCnt = 0;
	tag_t* tpHLASerialRevs = NULLTAG;
	tag_t tHLASerialNumRelationType = NULLTAG;
	int iHLAPartCnt = 0;
	tag_t* tpHLAPartRevs = NULLTAG;
	tag_t tHLAPartNumRelationType = NULLTAG;
	const char * __function__ = "validation_to_remove_part_number_if_revstamp_mismtach";
	TERADYNE_TRACE_ENTER();
	try {

		if (tRepairOrderRev != NULLTAG) {

			// get HLA Serial Number
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tHLASerialNumRelationType), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tHLASerialNumRelationType, &iHLASerialCnt, &tpHLASerialRevs), TD_LOG_ERROR_AND_THROW);
			if (iHLASerialCnt > 0) {
				for (int i = 0; i < iHLASerialCnt; i++) {
					tHLASerialRev = tpHLASerialRevs[i];
					// get HLA Part Number
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tHLAPartNumRelationType), TD_LOG_ERROR_AND_THROW);
					if (tHLAPartNumRelationType != NULLTAG) {
						TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpHLASerialRevs[i], tHLAPartNumRelationType, &iHLAPartCnt, &tpHLAPartRevs), TD_LOG_ERROR_AND_THROW);
					}
					if (iHLAPartCnt > 0) {
						for (int j = 0; j < iHLAPartCnt; j++) {
							tHLAPartNumberRev = tpHLAPartRevs[j];
						}
					}
				}
			}

			char* cpHLASNitemId = NULL;
			char* cpHLAPNitemId = NULL;
			char* cpHLASNRevStamp = NULL;
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tHLASerialRev, OBJECT_NAME, &cpHLASNitemId), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tHLAPartNumberRev, ITEM_ID, &cpHLAPNitemId), TD_LOG_ERROR_AND_THROW);

			if ((tc_strcmp(sLLASerialNumber.c_str(), cpHLASNitemId) == 0) && (tc_strcmp(sLLAPartNumber.c_str(), cpHLAPNitemId) == 0) && (tc_strcmp(sLLARevStamp.c_str(), cpHLASNRevStamp) != 0)) {

				// Remove this Relation from HLA Serial Number and HLA Part Number.
				tag_t tRelationTag = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tHLAPartNumRelationType), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(GRM_find_relation(tHLASerialRev, tHLAPartNumberRev, tHLAPartNumRelationType, &tRelationTag), TD_LOG_ERROR_AND_THROW);
				if (tRelationTag != NULLTAG) {
					TERADYNE_TRACE_CALL(GRM_delete_relation(tRelationTag), TD_LOG_ERROR_AND_THROW);
					AOM_refresh(tHLASerialRev, false);
				}

				TC_write_syslog("Attaching to LLA div part");
				TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tHLASerialRev, tLLAPartNumRev, TD7_PART_SERIAL_REL), TD_LOG_ERROR_AND_THROW);

				POM_AM__set_application_bypass(true);
				bool bisverdict = false;
				//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tHLASerialRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tHLASerialRev, true), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(AOM_set_value_string(tHLASerialRev, TD7_REV_STAMP, sLLARevStamp.c_str()), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save_without_extensions(tHLASerialRev), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tHLASerialRev, false), TD_LOG_ERROR_AND_THROW);
				}
				POM_AM__set_application_bypass(false);



				isValidateToRemoveExistingPartNumber = TRUE;
			}



		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//int teradyne_create_solution_config(string sItemdId, tag_t tRepairOrderRev, tag_t &tNewlyCreatedObj) {
//}
	// int iStatus = 0;
	// tag_t tCreateType = NULLTAG;
	// tag_t tCreateRevType = NULLTAG;
	// tag_t tItemCreateInput = NULLTAG;
	// bool bIsNull = false;
	// std::string sRepairOrderNumber;

	// BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

	// TERADYNE_TRACE_CALL(boRepairOrderRev->getString(ITEM_ID, sRepairOrderNumber, bIsNull));

	// TERADYNE_TRACE_ENTER();
	// string sSolutionConfigId;
	// sSolutionConfigId = sSolutionConfigId.append(sItemdId);
	// sSolutionConfigId = sSolutionConfigId.append("_");
	// sSolutionConfigId = sSolutionConfigId.append(sRepairOrderNumber);

	// try {
		// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG, NULL, &tCreateType));

		// if (iStatus == ITK_ok && tCreateType != NULLTAG)
		// {
			// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateType, &tItemCreateInput));

			// if (iStatus == ITK_ok && tItemCreateInput != NULLTAG)
			// {

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSolutionConfigId.c_str()));
				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, "Solution Config"));

				// TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_SOLUTION_CONFIG_REVISION, NULL, &tCreateRevType));

				// tag_t   tItemRevCreateInput = NULLTAG;
				// TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tCreateRevType, &tItemRevCreateInput));

				// TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"));

				// TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput));

				// TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewlyCreatedObj));

				// if (iStatus == ITK_ok && tNewlyCreatedObj != NULLTAG)
				// {
					// TERADYNE_TRACE_CALL(AOM_save_without_extensions(tNewlyCreatedObj));
					// TERADYNE_TRACE_CALL(AOM_refresh(tNewlyCreatedObj, false));
				// }
			// }
		// }
	// }
	// catch (...)
	// {

	// }

	// TERADYNE_TRACE_LEAVE();
	// return iStatus;
// }

	//create repair managed part
int create_repair_managed_part_repairconfigcsv(string sLLAPartNumber, string sPartNumberRev, string sHLAPartNumber, tag_t& tRepManagePartRev)
{
	int iStatus = ITK_ok;
	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;
	bool	isNull = false;
	bool bisverdict = false;
	const char * __function__ = "create_repair_managed_part_repairconfigcsv";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sLLAPartNumber.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART, TD7_REPAIR_MANAGED_PART, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sLLAPartNumber.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, "Repair Managed Part"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART_REVISION, TD7_REPAIR_MANAGED_PART_REVISION, &tItemRevTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);


			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tRepManagePartRev), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepManagePartRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepManagePartRev, true), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tRepManagePartRev, TD7_REV_STAMP, sPartNumberRev.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_save(tRepManagePartRev), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepManagePartRev, false), TD_LOG_ERROR_AND_THROW);
			}

			// Assign repair managed part into repair group.
			int iDivCount = 0;
			tag_t tDivPart = NULLTAG;
			TERADYNE_TRACE_CALL(query_item(sHLAPartNumber, DIVISIONAL_PART, iDivCount, tDivPart), TD_LOG_ERROR_AND_THROW);
			if (iDivCount == 0) {
				TERADYNE_TRACE_CALL(query_item(sHLAPartNumber, COMMERCIAL_PART, iDivCount, tDivPart), TD_LOG_ERROR_AND_THROW);
			}

			// get the div part repair group
			int iProjectCount = 0;
			tag_t* tProjectList = NULLTAG;

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tDivPart, TD7_PROJECT_LIST, &iProjectCount, &tProjectList), TD_LOG_ERROR_AND_THROW);
			if (iProjectCount > 0) {
				for (int i = 0; i < iProjectCount; i++) {
					// assign existing repair group into created repair managed part
					TERADYNE_TRACE_CALL(iStatus = PROJ_assign_objects(1, &tProjectList[i], 1, &tNewItem), TD_LOG_ERROR_AND_THROW);
				}
			}
			else {
				// assign UNKNOWN repair group into created repair managed part
				tag_t tUnknownProjectTag = NULLTAG;
				TERADYNE_TRACE_CALL(PROJ_find("UNKNOWN_01", &tUnknownProjectTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = PROJ_assign_objects(1, &tUnknownProjectTag, 1, &tNewItem), TD_LOG_ERROR_AND_THROW);
			}

			TERADYNE_TRACE_CALL(AOM_save(tNewItem), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}