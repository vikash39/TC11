/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_pre_condition_on_iman_save_to_set_serial_number_status.cpp
#      Module          :           libTD7_teradyne_extensions.dll
#      Project         :           libTD7_teradyne_extensions
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

int td_bw_pre_condition_on_iman_save_to_set_serial_number_status_execute(va_list localArgs)
{
	int iStatus = ITK_ok;
	tag_t tObject = NULLTAG;
	tag_t tPrimaryObj = NULLTAG;
	tag_t tSecondayObj = NULLTAG;
	tag_t tRelationType = NULLTAG;
	logical bIsNull = false;
	string sCurrentStep;
	bool bisverdict = false;

	const char * __function__ = "td_bw_pre_condition_on_iman_save_to_set_serial_number_status_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		
		//Get the input arguments
		tObject = va_arg(localArgs, tag_t);
		bool bisNew = va_arg(localArgs, logical);

		//Getting Primary and Secondary Object for the Relation
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject, &tPrimaryObj), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject, &tSecondayObj), TD_LOG_ERROR_AND_THROW);

		if (tPrimaryObj != NULLTAG && tSecondayObj != NULLTAG) {

			BusinessObjectRef<Teamcenter::BusinessObject> boSecondaryObj(tSecondayObj);
			std::string sIsAllowInProgressSerialNumber("");
			TERADYNE_TRACE_CALL(boSecondaryObj->getString(TD7_IS_ALLOW_INPROGRESS_SN, sIsAllowInProgressSerialNumber, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sIsAllowInProgressSerialNumber.c_str(), "true") == 0 || tc_strcmp(sIsAllowInProgressSerialNumber.c_str(), "") == 0) {

				std::string sSerialNumberStatus("");
				std::string sItemId("");
				TERADYNE_TRACE_CALL(boSecondaryObj->getString(TD7_SERIAL_NUMBER_STATUS, sSerialNumberStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(boSecondaryObj->getString(ITEM_ID, sItemId, bIsNull), TD_LOG_ERROR_AND_THROW);

				if ((tc_strcmp(sSerialNumberStatus.c_str(), "New") == 0) || (tc_strcmp(sSerialNumberStatus.c_str(), "Repaired") == 0) || (tc_strcmp(sSerialNumberStatus.c_str(), "Swapped") == 0)) {

					POM_AM__set_application_bypass(true);
					TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tSecondayObj, &bisverdict), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSecondayObj, true), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(AOM_set_value_string(tSecondayObj, TD7_SERIAL_NUMBER_STATUS, "In Progress"), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(AOM_save_without_extensions(tSecondayObj), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSecondayObj, false), TD_LOG_ERROR_AND_THROW);
					}
					POM_AM__set_application_bypass(false);

				}
				else if (tc_strcmp(sSerialNumberStatus.c_str(), "") == 0) {
					POM_AM__set_application_bypass(true);
					TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tSecondayObj, &bisverdict), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSecondayObj, true), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(AOM_set_value_string(tSecondayObj, TD7_SERIAL_NUMBER_STATUS, "In Progress"), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(AOM_save_without_extensions(tSecondayObj), TD_LOG_ERROR_AND_THROW);
					if (!bisverdict)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSecondayObj, false), TD_LOG_ERROR_AND_THROW);
					}
					POM_AM__set_application_bypass(false);
				}
				else {
					iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_SERIAL_NUMBER_IS_NOT_VALID, sItemId.c_str());
					iStatus = TERADYNE_SERIAL_NUMBER_IS_NOT_VALID;
					throw iStatus;
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}