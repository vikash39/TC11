/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_post_action_on_repairs_rel_to_validate_ref_desig.cpp
#      Module          :           libTD7_teradyne_extensions.dll
#      Project         :           libTD7_teradyne_extensions
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

int td_bw_post_action_on_repairs_rel_to_validate_ref_desig_execute(tag_t tPrimary, tag_t tSecondary)
{
	int iStatus = ITK_ok;
	//tag_t tRepairCompRev = NULLTAG;
	//tag_t tHLAPart = NULLTAG;
	//tag_t *tHLAPartRev = NULLTAG;
	//tag_t tLLAPart = NULLTAG;
	//tag_t tLLAPartRev = NULLTAG;
	//logical bIsNull = false;
	//bool lRoFound = FALSE;
	//string sCurrentStep;
	//std::string sDivPart("");
	//std::string sDivPartRevision("");
	//
	//TERADYNE_TRACE_ENTER();
	//try
	//{
	//	if (tPrimary != NULLTAG) {

	//		tag_t tRelationType = NULLTAG;

	//		TERADYNE_TRACE_AND_THROW(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tRelationType));

	//		int iRepairOrderCnt = 0;
	//		tag_t * tpRepairOrderObjects = NULLTAG;
	//		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
	//		TERADYNE_TRACE_AND_THROW(GRM_list_primary_objects_only(tPrimary,
	//			tRelationType, &iRepairOrderCnt, &tpRepairOrderObjects));

	//		if (iRepairOrderCnt > 0) {
	//			for (int i = 0; i < iRepairOrderCnt; i++) {
	//				BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tpRepairOrderObjects[i]);

	//				// check for Divisional Part
	//				TERADYNE_TRACE_AND_THROW(tRepairOrderRevBORef->getString(TD7_PART_NUMBER, sDivPart, bIsNull));
	//				TERADYNE_TRACE_AND_THROW(tRepairOrderRevBORef->getString(TD7_PART_REVISION, sDivPartRevision, bIsNull));

	//				if (tc_strcmp(sDivPart.c_str(), "") == 0) {
	//					// check for Repair Managed Part
	//					TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_REP_MANAGE_PART, sDivPart, bIsNull));
	//					TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_REP_MANAGE_PART_REVISION, sDivPartRevision, bIsNull));
	//				}

	//				if (tc_strcmp(sDivPart.c_str(), "") == 0) {
	//					// check for Commercial Part
	//					TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_COMM_PART_NUMBER, sDivPart, bIsNull));
	//					TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_COMM_PART_REVISION, sDivPartRevision, bIsNull));
	//				}
	//				
	//			}
	//		}

	//		if (tSecondary != NULLTAG) {

	//			BusinessObjectRef<Teamcenter::BusinessObject> boRepairCompObj(tSecondary);

	//			std::string sCompPartNumber("");
	//			std::string sRefDesignator("");
	//			TERADYNE_TRACE_AND_THROW(boRepairCompObj->getString(TD7_COMP_PART_NUMBER, sCompPartNumber, bIsNull));
	//			TERADYNE_TRACE_AND_THROW(boRepairCompObj->getString(TD7_REFERENCE_DESIGNATOR, sRefDesignator, bIsNull));

	//			if (!sCompPartNumber.empty() && !sDivPart.empty()) {
	//				TERADYNE_TRACE_AND_THROW(ITEM_find_item(sCompPartNumber.c_str(), &tLLAPart));
	//				TERADYNE_TRACE_AND_THROW(ITEM_find_item(sDivPart.c_str(), &tHLAPart));
	//				ITEM_find_revision(tHLAPart, sDivPartRevision.c_str(), tHLAPartRev);
	//				
	//				if (tHLAPart != NULLTAG) {
	//					TERADYNE_TRACE_AND_THROW(ITEM_ask_latest_rev(tLLAPart, &tLLAPartRev));
	//				}

	//				TERADYNE_TRACE_AND_THROW(td7_set_bom_and_initiate_to_iterate_bom(tSecondary, tLLAPartRev, tHLAPartRev[0], lRoFound));
	//			}
	//		}
	//	}
	//}
	//catch (exception) {}
	//TERADYNE_TRACE_LEAVE();
	return iStatus;
}

/**int td7_set_bom_and_initiate_to_iterate_bom(tag_t tRepairComp, tag_t tPrimaryObject, tag_t tSecondaryObject, logical &lRoFound) {

	int iStatus = ITK_ok;
	tag_t* tBomViewRevisionTag = NULLTAG;
	tag_t tWinTag = NULLTAG;
	tag_t tTopLine = NULLTAG;
	int iBomViewRevisionCount = 0;
	bool bCompFound = false;
	bool bIsNull = false;
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boPrimaryObject(tPrimaryObject);
		std::string sPartNumber;
		TERADYNE_TRACE_AND_THROW(boPrimaryObject->getString(ITEM_ID, sPartNumber, bIsNull));

		ITEM_rev_list_all_bom_view_revs(tSecondaryObject, &iBomViewRevisionCount, &tBomViewRevisionTag);

		if (iBomViewRevisionCount > 0) {

			TERADYNE_TRACE_AND_THROW(BOM_create_window(&tWinTag));
			TERADYNE_TRACE_AND_THROW(BOM_set_window_top_line_bvr(tWinTag, tBomViewRevisionTag[0], &tTopLine));
			TERADYNE_TRACE_AND_THROW(traverse_BOM(tTopLine, sPartNumber, bCompFound));

			BusinessObjectRef< Teamcenter::BusinessObject > boLLApartNumber(tRepairComp);
			AcquireLock lockOnLLApartNum(tRepairComp);
			if (bCompFound) {
				TERADYNE_TRACE_AND_THROW((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, YES, false)));
			}
			else {
				TERADYNE_TRACE_AND_THROW((boLLApartNumber->setString(TD7_PRESENT_IN_BOM, NO, false)));
			}
			TERADYNE_TRACE_AND_THROW(BOM_close_window(tWinTag));

			TERADYNE_TRACE_AND_THROW(AOM_save(tRepairComp));
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}
*/
/**int traverse_BOM(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t* children_tag = NULLTAG;
	int childrens = 0;
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boBomLineRevisionTag(tBomLineRevisionTag);
		std::string sItemId;
		TERADYNE_TRACE_AND_THROW(boBomLineRevisionTag->getString(BL_ITEM_ITEM_ID, sItemId, bIsNull));

		if (!bCompFound) {
			if (tc_strcmp(sItemId.c_str(), sPartNumber.c_str()) == 0) {
				bCompFound = true;
			}
			//BOM line ask child line
			TERADYNE_TRACE_AND_THROW(BOM_line_ask_child_lines(tBomLineRevisionTag, &childrens, &children_tag));
			if (childrens > 0) { //If the item has childern

				for (int child = 0; child < childrens; child++) {

					TERADYNE_TRACE_AND_THROW(traverse_BOM(children_tag[child], sPartNumber, bCompFound)); // Run recursive function to get all bom lines.
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	TERADYNE_MEM_FREE(children_tag);
	return iStatus;
}*/