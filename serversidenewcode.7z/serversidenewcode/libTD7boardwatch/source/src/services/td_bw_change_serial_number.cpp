/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_change_serial_number.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  19-Jun-2020                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_change_serial_number.h>

int change_serial_number(std::string sNewSerialNumber, std::string sNewSerialNumberName, std::string repairOrderUID) {

	tag_t tRepairOrderRev = NULLTAG;
	tag_t tSerialNumberRev = NULLTAG;
	tag_t *tpLLAPartNumberRev = NULLTAG;
	tag_t tPartSerialRel = NULLTAG;
	bool bIsNull = false;
	GRM_relation_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	int iStatus = ITK_ok;
	int	iLLAPartNumberCount = 0;
	std::string refDesignWarningMsg;
	char* serialNumberStatus = NULL;
	tag_t tPartRev = NULL;

	const char * __function__ = "change_serial_number";
	TERADYNE_TRACE_ENTER();
	try
	{
		

			ITK__convert_uid_to_tag(repairOrderUID.c_str(), &tRepairOrderRev);

			if (tRepairOrderRev == NULLTAG)
			{
				return iStatus;
			}
			tag_t tRelationType = NULLTAG;

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

			int iSecondaryCnt = 0;
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

			for (int i = 0; i < iSecondaryCnt; i++)
			{
				// to set status for new serial number
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryObjects[i].secondary, TD7_SERIAL_NUMBER_STATUS, &serialNumberStatus), TD_LOG_ERROR_AND_THROW);

				// to get HLA Part Number to attach to new serial number
				tag_t tPartRelationType = NULLTAG;
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);
				int iPartCount = 0;
				tag_t* tHLAPart = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i].secondary, tPartRelationType, &iPartCount, &tHLAPart), TD_LOG_ERROR_AND_THROW);
				tPartRev = tHLAPart[0];

				bool bisverdict = false;
				//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tpSecondaryObjects[i].secondary, &bisverdict), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(AOM_load(tpSecondaryObjects[i].secondary), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i].secondary, true), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(AOM_set_value_string(tpSecondaryObjects[i].secondary, TD7_SERIAL_NUMBER_STATUS, "Retired"), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save_without_extensions(tpSecondaryObjects[i].secondary), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(AOM_unload(tpSecondaryObjects[i].secondary), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i].secondary, false), TD_LOG_ERROR_AND_THROW);
				}

				//TERADYNE_TRACE_CALL(AOM_set_value_string(tpSecondaryObjects[i].secondary, TD7_SERIAL_NUMBER_STATUS, "Retired"));
				
				// cut part serial number from repair order to add new serial number.
				TERADYNE_TRACE_CALL(GRM_delete_relation(tpSecondaryObjects[i].the_relation), TD_LOG_ERROR_AND_THROW);
			}

			// create a new serial number
			TERADYNE_TRACE_CALL(create_new_serial_number(sNewSerialNumber, sNewSerialNumber, tPartRev, tSerialNumberRev), TD_LOG_ERROR_AND_THROW);
			

			bool bisverdict = false;
			//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
			TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tSerialNumberRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(AOM_load(tSerialNumberRev), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSerialNumberRev, true), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(AOM_set_value_string(tSerialNumberRev, TD7_SERIAL_NUMBER_STATUS, serialNumberStatus), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save_without_extensions(tSerialNumberRev), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(AOM_unload(tSerialNumberRev), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tSerialNumberRev, false), TD_LOG_ERROR_AND_THROW);
			}

			
			// attach new serial number into repair order
			if (tRepairOrderRev != NULLTAG && tSerialNumberRev != NULLTAG) {
				TERADYNE_TRACE_CALL(attach_with_relation(tRepairOrderRev, tSerialNumberRev, TD7_REPAIR_SERIAL_NO_REL), TD_LOG_ERROR_AND_THROW);
			}
		
	}
		catch (...)
		{
		}
		ITK_set_bypass(false);
		TERADYNE_MEM_FREE(tpLLAPartNumberRev);
		TERADYNE_TRACE_LEAVE();
		return  iStatus;
	}

//create hla serial number
int create_new_serial_number(string sSerialNumberId, string sObjectName, tag_t tPartRev, tag_t& tSerialNumRev)
{
	int iStatus = ITK_ok;

	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;

	const char * __function__ = "create_new_serial_number";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sSerialNumberId.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM, TD7_PART_SERIAL_NUM, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSerialNumberId.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObjectName.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM_REVISION, TD7_PART_SERIAL_NUM_REVISION, &tItemRevTypeTag), TD_LOG_ERROR_AND_THROW);
			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tSerialNumRev), TD_LOG_ERROR_AND_THROW);

			if (tSerialNumRev != NULLTAG && tPartRev != NULLTAG) {
				tag_t tRelationType = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

				tag_t tRelation = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_create_relation(tSerialNumRev, tPartRev, tRelationType, NULLTAG, &tRelation), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(GRM_save_relation(tRelation), TD_LOG_ERROR_AND_THROW);

			}

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	int iStatus = 0;
	tag_t tNewRel = NULLTAG;
	tag_t tRelation = NULLTAG;

	const char * __function__ = "attach_with_relation";
	TERADYNE_TRACE_ENTER();
	try {
		TERADYNE_TRACE_CALL(GRM_find_relation_type(sAttachRel.c_str(), &tRelation), TD_LOG_ERROR_AND_THROW);
		if (tRelation != NULLTAG) {
			TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}