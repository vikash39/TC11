﻿/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_repair_group_creation.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  05-Apr-2020                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_validate_reference_designator.h>

string validate_reference_designator(std::string referenceDesignator, std::string serialNumberUID, std::string componentPartNumber) {

	tag_t tSerialNumberRev = NULLTAG;
	tag_t *tpLLAPartNumberRev = NULLTAG;
	tag_t tPartSerialRel = NULLTAG;
	int iStatus = ITK_ok;
	int	iLLAPartNumberCount = 0;
	std::string refDesignWarningMsg;
	const char * __function__ = "validate_reference_designator";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (true) {
			//ITK_set_bypass(true);
			ITK__convert_uid_to_tag(serialNumberUID.c_str(), &tSerialNumberRev);
			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartSerialRel), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tSerialNumberRev, tPartSerialRel, &iLLAPartNumberCount, &tpLLAPartNumberRev), TD_LOG_ERROR_AND_THROW);
			for (int i = 0; i < iLLAPartNumberCount; i++) {
				TERADYNE_TRACE_CALL(td7_validate_bom_line(tpLLAPartNumberRev[i], componentPartNumber, referenceDesignator, tSerialNumberRev, refDesignWarningMsg), TD_LOG_ERROR_AND_THROW);
				return  refDesignWarningMsg;
			}
		}
	}
	catch (...)
	{
	}
	//ITK_set_bypass(false);
	TERADYNE_MEM_FREE(tpLLAPartNumberRev);
	TERADYNE_TRACE_LEAVE();
	return  refDesignWarningMsg;
}

int td7_validate_bom_line(tag_t tLLApartNumber, std::string componentPartNumber, std::string refDesignValue, tag_t tSerialNumRev, std::string &refDesignWarningMsg) {

	int iStatus = ITK_ok;
	tag_t* tBomViewRevisionTag = NULLTAG;
	tag_t tWinTag = NULLTAG;
	tag_t tTopLine = NULLTAG;
	int iBomViewRevisionCount = 0;
	bool bCompFound = false;
	bool bIsNull = false;
	std::string validWarningMsg;
	std::vector<tag_t> bomLineTags;
	bool isInBomLine = FALSE;
	bool isValid = FALSE;
	std::string warningMsg;

	const char * __function__ = "td7_validate_bom_line";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(ITEM_rev_list_all_bom_view_revs(tLLApartNumber, &iBomViewRevisionCount, &tBomViewRevisionTag), TD_LOG_ERROR_AND_THROW);


		if (iBomViewRevisionCount > 0) {

			TERADYNE_TRACE_CALL(BOM_create_window(&tWinTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(BOM_set_window_top_line_bvr(tWinTag, tBomViewRevisionTag[0], &tTopLine), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(traverse_BOM_reference_designator(tTopLine, componentPartNumber, refDesignValue, validWarningMsg, bomLineTags, isInBomLine), TD_LOG_ERROR_AND_THROW);

			refDesignWarningMsg = validWarningMsg;

			TERADYNE_TRACE_CALL(BOM_close_window(tWinTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tSerialNumRev), TD_LOG_ERROR_AND_THROW);
		}
		// store the warning message
		//refDesignWarningMsg = warningMsg;
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(tBomViewRevisionTag);
	//TERADYNE_MEM_FREE(validWarningMsg);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int traverse_BOM_reference_designator(tag_t tBomLineRevisionTag, std::string componentPartNumber, std::string sUserRefDesignValue, std::string &validWarningMsg, vector<tag_t> &bomLineTags, bool &isInBomLine) {

	int iStatus = ITK_ok;
	bool bIsNull = FALSE;
	tag_t* children_tag = NULLTAG;
	int childrens = 0;
	bool isValidated = FALSE;
	bool isValid = FALSE;

	const char * __function__ = "traverse_BOM_reference_designator";
	TERADYNE_TRACE_ENTER();
	try {
		BusinessObjectRef< Teamcenter::BusinessObject > boBomLineRevisionTag(tBomLineRevisionTag);
		std::string sItemId;
		TERADYNE_TRACE_CALL(boBomLineRevisionTag->getString(BL_ITEM_ITEM_ID, sItemId, bIsNull), TD_LOG_ERROR_AND_THROW);

		// terminate this recursion
		if (isValidated) {
			return 0;
		}

		if (!isValidated)
		{
			if (tc_strcmp(sItemId.c_str(), componentPartNumber.c_str()) == 0) {
				isInBomLine = TRUE;
				char* sDBRefDesValue;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tBomLineRevisionTag, BL_REFERENCE_DESIGNATOR, &sDBRefDesValue), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(sDBRefDesValue, "") != 0) {

					string fromDBSplitedRefDesignator = "";
					string userSplitedRefDesignator = "";
					fromDBSplitedRefDesignator = split_reference_designator_validate_ref_design(sDBRefDesValue);
					userSplitedRefDesignator = split_reference_designator_validate_ref_design(sUserRefDesignValue);
					compare_ref_designator_strings(fromDBSplitedRefDesignator, userSplitedRefDesignator, isValid);

					if (isValid) {
						validWarningMsg = "Yes";
						isValidated = TRUE;
						return 0;
					}

				}

			}
			else {
				//bomLineTags.push_back(tBomLineRevisionTag);
			}
			//BOM line ask child line
			TERADYNE_TRACE_CALL(BOM_line_ask_child_lines(tBomLineRevisionTag, &childrens, &children_tag), TD_LOG_ERROR_AND_THROW);
			if (childrens > 0) { //If the item has childern
				for (int child = 0; child < childrens; child++) {
					TERADYNE_TRACE_CALL(traverse_BOM_reference_designator(children_tag[child], componentPartNumber, sUserRefDesignValue, validWarningMsg, bomLineTags, isInBomLine), TD_LOG_ERROR_AND_THROW); // Run recursive function to get all bom lines.
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(children_tag);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int compare_ref_designator_strings(string dbRefDesignator, string userRefDesignator, bool &isValidaRefDesignator) {
	int iStatus = 0;
	vector<std::string> vDBSplittedValues;
	vector<std::string> vUserSplittedValues;
	std::vector<int>::iterator it;
	bool isValid = false;
	TERADYNE_TRACE_AND_THROW(teradyne_split(dbRefDesignator, ',', vDBSplittedValues));
	TERADYNE_TRACE_AND_THROW(teradyne_split(userRefDesignator, ',', vUserSplittedValues));


	for (int i = 0; i < vUserSplittedValues.size(); i++) {
		if (std::find(vDBSplittedValues.begin(), vDBSplittedValues.end(), vUserSplittedValues[i]) != vDBSplittedValues.end())
		{
			// Element in vector.
			isValid = true;
		}
		else {
			isValid = false;
			isValidaRefDesignator = isValid;
			return 0;
		}

	}
	isValidaRefDesignator = isValid;
	return iStatus;
}


void tostring_soa(char str[], int num)
{
	int i, rem, len = 0, n;

	n = num;
	while (n != 0)
	{
		len++;
		n /= 10;
	}
	for (i = 0; i < len; i++)
	{
		rem = num % 10;
		num = num / 10;
		str[len - (i + 1)] = rem + '0';
	}
	str[len] = '\0';
}

char* Charactervalues_soa(char *inputLine) {
	int i, j;
	char *line = (char *)malloc(sizeof(inputLine));
	strcpy(line, inputLine);
	for (i = 0; line[i] != '\0'; ++i)
	{
		while (!((line[i] >= 'a' && line[i] <= 'z') || (line[i] >= 'A' && line[i] <= 'Z') || line[i] == '\0'))
		{
			for (j = i; line[j] != '\0'; ++j)
			{
				line[j] = line[j + 1];
			}
			line[j] = '\0';
		}
	}
	return line;
}

char *NumericValues_soa(char *inputLine) {
	int i, j;
	char *line = (char *)malloc(sizeof(inputLine));
	strcpy(line, inputLine);
	for (i = 0; line[i] != '\0'; ++i)
	{
		while (((line[i] >= 'a' && line[i] <= 'z') || (line[i] >= 'A' && line[i] <= 'Z') || line[i] == '\0'))
		{
			for (j = i; line[j] != '\0'; ++j)
			{
				line[j] = line[j + 1];
			}
			line[j] = '\0';
		}
	}
	return line;
}

std::string toUpperCase(std::string charactor)
{
	int x = 32;
	for (int i = 0; charactor[i] != '\0'; i++)
		charactor[i] = charactor[i] & ~x;

	return charactor;
}

string split_reference_designator_validate_ref_design(std::string originalReferenceDesignator) {
	int iStatus = ITK_ok;
	int ifail = 0,
		iCount = 0,
		isplitTwo = 0;
	char  *ActualValue = NULL,
		*charNewvalue = NULL,
		**cValue = NULL,
		*charVal = NULL,
		** csplitValue = NULL;
	std::string splitedValues = "";

	const char * __function__ = "split_reference_designator_validate_ref_design";
	TERADYNE_TRACE_ENTER();
	try {
		iStatus = EPM__parse_string(originalReferenceDesignator.c_str(), ",", &iCount, &cValue);
		for (int i = 0; i < iCount; i++) {
			if (strstr(cValue[i], "-") != NULL) {
				iStatus = EPM__parse_string(cValue[i], "-", &isplitTwo, &csplitValue);
				string numericValue1 = "";
				string numericValue2 = "";
				char* charValue = "";
				char str[20];
				charValue = Charactervalues_soa(csplitValue[0]);
				numericValue1 = NumericValues_soa(csplitValue[0]);
				numericValue2 = NumericValues_soa(csplitValue[1]);
				int num1 = atoi(numericValue1.c_str());
				int num2 = atoi(numericValue2.c_str());
				for (int i = num1; i <= num2; i++) {
					// sprintf(str, "%s", i);
					//itoa(i, str, 10);
					_itoa(i, str, 10);
					char *charVal = (char *)malloc(sizeof(charValue));
					strcpy(charVal, charValue);

					string merge = strcat(charVal, str);
					string output = strcat(charVal, ",");
					cout << output;
					splitedValues.append(output);


				}
			}
			if (strstr(cValue[i], ":") != NULL) {
				iStatus = EPM__parse_string(cValue[i], ":", &isplitTwo, &csplitValue);
				string numericValue1 = "";
				string numericValue2 = "";
				char* charValue = "";
				char str[20];
				charValue = Charactervalues_soa(csplitValue[0]);
				numericValue1 = NumericValues_soa(csplitValue[0]);
				numericValue2 = NumericValues_soa(csplitValue[1]);
				int num1 = atoi(numericValue1.c_str());
				int num2 = atoi(numericValue2.c_str());
				for (int i = num1; i <= num2; i++) {
					// sprintf(str, "%s", i);
					//itoa(i, str, 10);
					_itoa(i, str, 10);
					char *charVal = (char *)malloc(sizeof(charValue));
					strcpy(charVal, charValue);

					string merge = strcat(charVal, str);
					string output = strcat(charVal, ",");
					cout << output;
					splitedValues.append(output);


				}
			}
			if (i != iCount - 1) {
				if ((strstr(cValue[i], "-") != NULL) || (strstr(cValue[i], ":") != NULL)) {

				}
				else {
					string output = strcat(cValue[i], ",");
					cout << output;
					splitedValues.append(output);
				}


				//cout<<cValue[i];
			}
			else {
				if ((strstr(cValue[i], "-") != NULL) || (strstr(cValue[i], ":") != NULL)) {

				}
				else {
					string output = strcat(cValue[i], ",");
					cout << output;
					splitedValues.append(output);
				}


			}

		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	splitedValues.pop_back();
	return splitedValues;
}

int compare_reference_designator(std::string ActualValue, std::string userRefDesValue, bool &isValid) {
	int iStatus = ITK_ok;
	// TO DO
	return iStatus;
}