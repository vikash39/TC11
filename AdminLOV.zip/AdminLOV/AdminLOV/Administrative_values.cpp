#include<tc/tc.h>
#include<tc/emh.h>
#include<bom/bom.h>
#include<time.h>
#include<tccore/item.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<fclasses/tc_string.h>
#include<tc/preferences.h>
#include<sa/sa.h>
#include<epm/epm_task_template_itk.h>
#include<tccore/grm.h>
#include<res/res_itk.h>
#include<epm/epm_toolkit_tc_utils.h>
#include<tccore/workspaceobject.h>
#include<sa/tcfile.h>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <set>
#include <stdlib.h>


using namespace std;

#define ADMINISTRATIVE_LOV_TYPE	"Fnd0AdminLOVValue"
#define OBJECT_NAME			 "object_name"
#define OBJECT_DESC			 "object_desc"
#define OBJECT_VALUE		 "fnd0lov_value"
#define OBJECT_VALUEDESC	 "fnd0lov_description"
#define OBJECT_VALUECATEGORY "fnd0lov_category"
void initialize(char **cUserName, char **cPassWord, char **cUsergroup, char **cInputFile);

int ITK_user_main(int argc, char* argv[])
{

	int iCnt =  0,
        iLine = 1,
		iFail=ITK_ok;

	char *cUserName = NULL,
	     *cPassWord = NULL,
	     *cUsergroup = NULL,
	     *cInputFile = NULL,
	     **cValues = NULL;
		
   tag_t tAdministrativeTag = NULLTAG,
	     tItemType  = NULLTAG,
         tItem = NULLTAG;



	string  sline  = "";

	fstream   finput_file;
	          


	string  cSeparator		    = ",";
	

	try {
		//initialize(&cUserName, &cPassWord, &cUsergroup, &cInputFile);
	cUserName = ITK_ask_cli_argument("-u=");

    cPassWord = ITK_ask_cli_argument("-p=");

    cUsergroup = ITK_ask_cli_argument("-g=");

    cInputFile =ITK_ask_cli_argument("-i=");

    if( ITK_init_module(cUserName,cPassWord,cUsergroup) != ITK_ok)

    {

        printf("\n Login failed \n");

        TC_write_syslog("\n Login failed \n");

        exit(1);

    }

		cout<<"Login success";
		ITK_set_bypass(true); 
		//Opening the input file
		finput_file.open(cInputFile);
		//getchar();
		//Remove if File already Exists
		std::remove(cInputFile);
		

		if (!(finput_file.is_open()))
		{
			cout <<"\n\n Failed to open Input file \n\n";
			exit(1);
		}
		
				cout<<"\n Input File Opened \n"; 

				//Reading the input file
				while(getline(finput_file,sline))
				{
					//ftext_file<<" ******************* Administrative Values "<<iLine<<" *********************************"<<endl;
					//Separating List of value Name
					ITKCALL(EPM__parse_string(sline.c_str(),",",&iCnt,&cValues));	
						
						if(cValues[0] != NULL)
						{
							ITKCALL(TCTYPE_ask_type( ADMINISTRATIVE_LOV_TYPE, &tItemType ));
							ITKCALL(TCTYPE_construct_create_input( tItemType, &tAdministrativeTag));
							ITKCALL(AOM_set_value_string(tAdministrativeTag,OBJECT_NAME,cValues[0]));
							ITKCALL(AOM_set_value_string(tAdministrativeTag,OBJECT_DESC,cValues[1]));
							ITKCALL(AOM_set_value_string(tAdministrativeTag,OBJECT_VALUE,cValues[2]));
							ITKCALL(AOM_set_value_string(tAdministrativeTag,OBJECT_VALUEDESC,cValues[3]));
							ITKCALL(AOM_set_value_string(tAdministrativeTag,OBJECT_VALUECATEGORY,cValues[4]));
							ITKCALL(TCTYPE_create_object(tAdministrativeTag, &tItem ));
							ITKCALL(AOM_save_without_extensions( tItem ));
							ITKCALL(AOM_refresh(tItem,FALSE));
							cout<<iLine<<" . "<<cValues[0]<< " Created "<<endl;
						}
						else{
                          cout <<"\n Name field is mandatory to fill \n";
						}

	                    if(cValues != NULL) MEM_free(cValues);	
						iLine++;

					}
    
	finput_file.close();
	}
	
	catch(...) {

		cout << "\n ##### In catch block for Administrative list of values \n";

	}
	
	

	
	
	
	ITK_set_bypass(false);
	ITK_exit_module(true);
	return ITK_ok;
}


