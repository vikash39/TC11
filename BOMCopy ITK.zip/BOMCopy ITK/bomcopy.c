#include<item.h>

int ITK_user_main(int argc, char* argv[])
{
	int result,count;

	tag_t item_tag = NULLTAG;
	tag_t rev_tag = NULLTAG;

	if((result = ITK_auto_login())==ITK_ok)
	{
		result = ITEM_find_item("000114",&item_tag);
		printf("\n Find Item Result :%d",result);

		result = ITEM_ask_latest_rev(item_tag,&rev_tag);
		printf("\n Latest Rev REsult :%d",result);

	}
	return result;
}


/****************************************************************************
 *  Function Name		:SIM_BOM_Copy_structure
 *  Description		    :This is the main module of server exit.
 *	FUNCTIONS CALLED	:SIM_BOM_Copy_structure
 *
 ******************************************************************************/
int SIM_BOM_Copy_structure(void* retvalue)
{
	/* Declaration */
    int iStatus = ITK_ok,g = 0;

	char	*psMasterItemID	= NULL,
			*psDomainName	= NULL,
			*psRevID		= NULL,
			*sRevConfigRule = NULL,
			sTempErrorString[5000] = "-",
			sEnv[1024+1]     =  "",
			*sReUseObjectTag = NULL,
			*sCloneItemIDMaster = NULL;

	tag_t	tMasterItem		= NULLTAG,
			tMasterItemRev	= NULLTAG,
			tMasterRevTag  = NULLTAG;
	
	logical lTopAssemblyVerdict;

	printf("\n\nEntering SIM_BOM_Copy_structure..");


    try
    {
		/* Reading user service argument */

		iStatus = USERARG_get_string_argument(&psMasterItemID) ;

		iStatus = USERARG_get_string_argument(&psRevID) ) ;

		iStatus = USERARG_get_string_argument(&psDomainName) ;

		iStatus = USERARG_get_string_argument(&sRevConfigRule) ;
		
		printf("\n\n   IN : %s/%s-%s",psMasterItemID,psRevID,psDomainName);

		/* Calling function for the processing parent assembly */
        iErrorThrowConst = 0;
		iFlagTraverse = 0;
		iProjAssignFlag = 0;
		iErrStrIndex = -1;
		iProjListIndex = 0;iProjUnassignedListReady = 0;iMmItemUnassignedListReady = 0;iUnprivilegeListReady = 0;

		 tc_strcpy(sTempErrorString,"");
	     tc_strcpy(sMmItemUnassignedList,"");
		 tc_strcpy(sProjUnassignedList,"");
		 tc_strcpy(sMemberUnprivilegedList,"");
		 sGlobRevConfigRule = NULL;

		 printf("\n sGlobRevConfigRule(after nullifying) = %s",sGlobRevConfigRule);
		 //opening file

		sGlobRevConfigRule = sRevConfigRule;
		printf("\n sGlobRevConfigRule(after copying) = %s",sGlobRevConfigRule);
		
		if(sGlobRevConfigRule == sRevConfigRule)
		{   
			printf("\n rev rule got is correct***************process starting");
		}
		
		
 
         
         MRV_TRACE_CALL( iStatus = ITEM_find_rev(psMasterItemID,psRevID,&tMasterRevTag));
         //
         sUnavailablePartItemId =  (char**)MEM_alloc(sizeof(char*)*1024);
		 sCloneItemIDMaster = (char *) MEM_alloc(256);
         //sTempErrorString = (char*)MEM_alloc(sizeof(char)*5000);
		 mapStructureObjects.clear();
		//

		 if(!tc_strcmp(psDomainName,MMCFD))
			sprintf (sCloneItemIDMaster, "%s-%s-%c", psMasterItemID, psRevID,'F');
		 else
			sprintf (sCloneItemIDMaster, "%s-%s-%c", psMasterItemID, psRevID,*psDomainName);

		 printf("\n sCloneItemIDMaster ------- %s\n",sCloneItemIDMaster);

		 MRV_TRACE_CALL( iStatus = ITEM_find_item(sCloneItemIDMaster,&tMasterItem));

		printf(" \n  tMasterItem = %d",tMasterItem);

        if(tMasterItem != NULLTAG)
		{
		 iStatus = AM_check_privilege(tMasterItem,"READ",&lTopAssemblyVerdict);
		 printf(" \n  lTopAssemblyVerdict = %d",lTopAssemblyVerdict);

		    if ( lTopAssemblyVerdict == 0)
			{
				printf("\n       Structure for \"%s\" Already Exist",psDomainName);
				iStatus = MM_STRUCT_ALREADY_EXISTS;
				MRV_TRACE_CALL( iStatus =  EMH_store_initial_error_s1( EMH_severity_error,iStatus,psMasterItemID));
				return MM_STRUCT_ALREADY_EXISTS;
			}
		}

			iStatus  = traverse_master_structure(psMasterItemID,psRevID,psDomainName);
         printf("\nflag_traverse = %d",iFlagTraverse);
		 if(iFlagTraverse != 0)
		 {   
             /*sTempErrorString = (char*)MEM_alloc(1024);*/
			 for(g = 0;g <= iErrStrIndex;g++)
			 {   
				 printf("\n concatenating");
                 tc_strcat(sTempErrorString,"\r\n");
				 //printf("\n in loop sTempErrorString = %s",sTempErrorString);
				 tc_strcat(sTempErrorString,sUnavailablePartItemId[g]);
			     
			 }
             
            printf("\n sTempErrorString = %s",sTempErrorString);

		    EMH_store_initial_error_s1( EMH_severity_error,MMSIMPARTNOTAVAILABLEEROR,sTempErrorString);
			printf("\n MMSIMPARTNOTAVAILABLEEROR is %d",MMSIMPARTNOTAVAILABLEEROR);
            for(g = 0;g <= iErrStrIndex;g++)
			{
				tc_strcpy(sUnavailablePartItemId[g],"");
			}
			tc_strcpy(sTempErrorString,"");
			MEM_free(sUnavailablePartItemId);
			sUnavailablePartItemId = NULL;
			return MMSIMPARTNOTAVAILABLEEROR;
		 }
		 //privilege check for simassembly
         if(iUnprivilegeListReady == 1)
		 {
              EMH_store_initial_error_s1( EMH_severity_error,MM_USER_PRIVILEGE_OF_PROJ_ERROR,sMemberUnprivilegedList);
		      return MM_USER_PRIVILEGE_OF_PROJ_ERROR;
		 }




         //project assigning check
         if(iProjUnassignedListReady == 1)
		 {
            EMH_store_initial_error_s1( EMH_severity_error,MM_PROJ_ASSIGN_ERROR,sProjUnassignedList);
		    return MM_PROJ_ASSIGN_ERROR;
		 }
		 //
		iStatus = MRV_process_master_structure(psMasterItemID, psRevID, psDomainName);


		if ( !iStatus )
		{
			//MRV_TRACE_CALL( iStatus = MRV_traverse_map_structure() );

			/* Calling function for processing cloned items */

			MRV_TRACE_CALL( iStatus = MRV_process_clone_structure(psMasterItemID, psRevID, psDomainName) );
			printf("\n\n   IN : %s/%s-%s",psMasterItemID,psRevID,psDomainName);

			MRV_TRACE_CALL( iStatus = ITEM_find_item ( psMasterItemID, &tMasterItem ));
			printf("\n\n   IN1 :%d",tMasterItem);

			MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tMasterItem, psRevID, &tMasterItemRev ));
			printf("\n\n   IN2 :%d",tMasterItemRev);

			* (tag_t *)retvalue = tMasterItemRev;
		}
		else
		{
			/* Function block if already exist */

			MRV_TRACE_CALL( iStatus = ITEM_find_item ( psMasterItemID, &tMasterItem ));

			cout << "\n   Already Exist";			
			iStatus = MM_STRUCT_ALREADY_EXISTS;
			MRV_TRACE_CALL( iStatus =  EMH_store_initial_error_s1( EMH_severity_error,iStatus,psMasterItemID));
			printf("\n MM_STRUCT_ALREADY_EXISTS is %d",MM_STRUCT_ALREADY_EXISTS);
			return MM_STRUCT_ALREADY_EXISTS;

			* (tag_t *)retvalue = tMasterItem;
			
		}

    }
    catch (...)
    {

    }

	/* Memory Cleanup */
    
	mapStructureObjects.clear();
	printf("\n map cleared");

    return iStatus;
}


/****************************************************************************
 *  Function Name		:MRV_create_structure_component
 *  Description			:This function used to create the process items.
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
 
int MRV_create_structure_component(char *sChildItemID, char *sChildItemRevID, char *sDomainValue, tag_t tSourceItemRevision)
{
	int		iStatus					= ITK_ok,
			iCreateRel				= 0,
			iBvCount                = 0,
			iSFCode                 = 0;

    //FILE *time_stamp_file = NULL;

	char	*sCloneItemID			= NULL,
			*sObjectName			= NULL,
			sRevId[64]              = ""  ,
			*sSourceObjRev			= NULL,
			*sCloneObjRev			= NULL,
			sCloneItemRevId[64]		= ""  ;

	tag_t	tCloneItem				= NULLTAG,
		    tCloneItem_rev          = NULLTAG,
			tCloneItemRev			= NULLTAG,
			sInputItem			    = NULLTAG,
			*tBvInputList			= NULLTAG,
			tFilterInputItem       = NULLTAG;

	logical active;
    printf("\n Entering create structure component");
	MRV_TRACE_CALL( iStatus = AOM_ask_value_string( tSourceItemRevision, "object_name", &sObjectName ));

	
	/* Preparing Cloning item id */

	sCloneItemID = (char *) MEM_alloc((int)(tc_strlen(sChildItemID) + tc_strlen(sChildItemRevID) + tc_strlen(sDomainValue)) + 4);
    //
    MRV_TRACE_CALL( iStatus = ITEM_find_rev(sChildItemID,sChildItemRevID,&sInputItem));

    MRV_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(sInputItem,&tFilterInputItem));
	iSFCode = filter_check_for_leaf(tFilterInputItem);
	   if(iSFCode == 1)
	   {
             char *sSourceObjRev	= NULL,
				*sCloneObjRev	= NULL;

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSourceItemRevision, &sSourceObjRev ));

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tCloneItemRev, &sCloneObjRev ));

		mapStructureObjects.insert(make_pair(std::string(sSourceObjRev),std::string("SKIP")));
		return ITK_ok;
	   }

	
	MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs(sInputItem,&iBvCount,&tBvInputList));
	
	if(iBvCount == 0)
	{  
		
		if(!tc_strcmp(sDomainValue,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%s%c", sChildItemID, sChildItemRevID,"AN",'F');
		else
			sprintf (sCloneItemID, "%s-%s-%s%c", sChildItemID, sChildItemRevID,"HW",*sDomainValue);

	   MRV_TRACE_CALL( iStatus = ITEM_find_item ( sCloneItemID, &tCloneItem ));
	   printf("\n tCloneItem is %d",tCloneItem);

	}
    //
	else
	{   
		if(!tc_strcmp(sDomainValue,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%c", sChildItemID, sChildItemRevID,'F');
		else
			sprintf (sCloneItemID, "%s-%s-%c", sChildItemID, sChildItemRevID,*sDomainValue);
	    
	}
	MRV_TRACE_CALL( iStatus = ITEM_find_item ( sCloneItemID, &tCloneItem ));
    //MRV_TRACE_CALL( iStatus = ITEM_ask_latest_rev ( tCloneItem, &tCloneItem_rev ));
	
	printf("\n tCloneItem is %d",tCloneItem);
    

	/* Function block to create new item */
    
	if ( tCloneItem == NULLTAG && iBvCount > 0)
	{
		printf("\n        Cloning new item %s/%s --> %s/%s", sChildItemID, sChildItemRevID, sCloneItemID, sChildItemRevID);
        
		MRV_TRACE_CALL( iStatus = ITEM_create_item ( sCloneItemID, sObjectName, MRV_SIMASSEMBLY_TYPE, NULL, &tCloneItem, &tCloneItemRev ));
		printf("\n tCloneItem is %d",tCloneItem);
		printf("\n tCloneItemRev is %d",tCloneItemRev);
		ITEM_ask_rev_id(tCloneItemRev,sCloneItemRevId);
		
		iCreateRel++;
	}

	/* Function block to create new item revision */
	else
	{
		//MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tCloneItem, sChildItemRevID, &tCloneItemRev ));

		/*if ( tCloneItemRev == NULLTAG )
		{*/
		if (tCloneItemRev != NULLTAG) {
		
			int		iDeepCopiedObjects		= 0;

			tag_t	tCloneLatestRev			= NULLTAG,
					*tDeepCopiedObjects		= NULL;
            
			MRV_TRACE_CALL( iStatus = ITEM_ask_latest_rev ( tCloneItem, &tCloneItemRev ));

            MRV_TRACE_CALL( iStatus = ITEM_ask_rev_id(tCloneItemRev,sRevId));    
           
			printf("\n tCloneLatestRev is %d",tCloneItemRev);

			printf("\n        Cloning existing item rev %s/%s --> %s/%s", sChildItemID, sChildItemRevID, sCloneItemID, sRevId);

			proj_assign(tSourceItemRevision, tCloneItemRev);

			
		}
			/*MRV_TRACE_CALL( iStatus = ITEM_copy_rev ( tCloneLatestRev, sChildItemRevID, &tCloneItemRev ));

			printf("\n tCloneItemRev is %d",tCloneItemRev);
			MRV_TRACE_CALL( iStatus = ITEM_perform_deepcopy ( tCloneItemRev, ITEM_revise_operation, tCloneLatestRev, &iDeepCopiedObjects, &tDeepCopiedObjects));*/

			/*iCreateRel++;*/
		/*}	*/	
	}

	/* Functional block to make clone item as re-usable component */

	if (tCloneItemRev != NULLTAG) 
	{
		    char *sSourceObjRev	= NULL,
				*sCloneObjRev	= NULL;

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSourceItemRevision, &sSourceObjRev ));
        printf("\n sSourceObjRev = %s",sSourceObjRev);
		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tCloneItemRev, &sCloneObjRev ));
        printf("\n sCloneObjRev = %s",sCloneObjRev);
		mapStructureObjects.insert(make_pair(std::string(sSourceObjRev),std::string(sCloneObjRev)));
        
		if(iCreateRel)
		{
			MRV_TRACE_CALL( iStatus = MRV_attach_reusable_component(tCloneItemRev, tSourceItemRevision, sDomainValue) );
			proj_assign(tSourceItemRevision, tCloneItemRev);
		}
	
	}

	MRV_free_memory (sCloneItemID);

	
	return ITK_ok;
}
