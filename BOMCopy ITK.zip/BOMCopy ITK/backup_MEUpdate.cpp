#include "IMAN_header.hpp"


int ITK_user_main(int argc,char * argv[])
{
	char	*sUserName = NULL,	*sPassword = NULL,	*sGroupName = NULL,
			*sInputFileName = NULL,	*sObjectType = NULL,	*sObjectName = NULL,
			*sPropValue = NULL;
	double topQuantity ;
	char sfilename[100];
	char	sUnitTime[32];
	double dCalcTime;
	int	iErrorCode,	iNumberFound,	iNumberOfRef,
		ichildCount;
	
	tag_t groupTag = NULL,	itemRevTag = NULL,	windowTag = NULL,
		itemIDTag = NULL,	topBomLineTag = NULL,	bomLineTag = NULL,
		revRuleTag = NULL,	validBvrTag = NULL;

	tag_t* listofWSOtags = {NULLTAG},	*listOfRef = {NULLTAG},	*bomChildrenTags = { NULLTAG };

	time_t t = time(NULL);
	FL_sort_criteria_t fl_sort_criteria = FL_fsc_no_order;

	strftime(sfilename, sizeof(sfilename), LOGNAME_FORMAT, std::localtime(&t));
	logfile.open (sfilename);
	
	logfile << "Utility started the Processing" << endl;
	logfile << "Read the input arguments... " << argc << endl;
	logfile << "Total input argument is : " << argc << endl;

	if ( argc < 5 || ITK_ask_cli_argument("-help") || ITK_ask_cli_argument("-h") )
		Help();
	
	ReadArguments(&sUserName, &sPassword, &sGroupName,&sInputFileName);
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	if (ITK_init_module(sUserName,sPassword,sGroupName) == ITK_ok )
	{
		logfile << "\n\n**************************************************************************************\n";
		logfile <<  "\n*                           Login to TC.......                               *   ";
		logfile << "\n**************************************************************************************\n" ;
		
		ifstream infile(sInputFileName);
		string line;
		int iLineCounter = 1;
		string sItemID;
		string sRevID;
		logfile << "Reading input file : " << sInputFileName << endl;
		while (getline(infile, line))
		{
			size_t pos = line.find(INPUTFILEDELIMETER);
			if( pos != string::npos )
			{
				sItemID = line.substr(0,pos);
				sRevID = line.substr(pos+1,line.length());
				logfile << "Processing Line : " << iLineCounter << endl;
				logfile << "\tItemiD : " << sItemID <<"\tRevisionID : "<< sRevID << endl;
			}
			else
			{
				logfile << "ERROR : Wrong input format in Line " << iLineCounter << endl;
				continue;
			}
			RootItem = sItemID;
			logfile << "\tProcessing ItemID : " << sItemID << endl;

			ERROR_REPORT(ITEM_find_rev(sItemID.c_str(),sRevID.c_str(),&itemRevTag));
			
			if(itemRevTag == NULLTAG )
			{
				logfile << "\tERROR : Item " << sItemID << " is not present in the teamcenter" << endl;
				continue;
			}
			
			ERROR_REPORT(CFM_find(BOP_REVRULE, &revRuleTag));
			getValidBVR( itemRevTag, NULL, &validBvrTag ); // Checking bom view type
			ERROR_REPORT(BOM_create_window(&windowTag));
			ERROR_REPORT(BOM_set_window_config_rule( windowTag, revRuleTag));
			ERROR_REPORT(BOM_set_window_top_line(windowTag,NULLTAG,itemRevTag,validBvrTag,&topBomLineTag));
			ERROR_REPORT(BOM_line_ask_all_child_lines(topBomLineTag,&ichildCount,&bomChildrenTags));
			
			//cout << ichildCount << endl;
			for( int child = 0; child < ichildCount ; child++ )
			{
				ERROR_REPORT(AOM_ask_value_double(topBomLineTag,"bl_quantity",&topQuantity));

				if( topQuantity == 0)
				{
					topQuantity = 1;
				}

				ProcessBOMchild(bomChildrenTags[child],topQuantity);
				postRootMap.clear();
			}

			ERROR_REPORT(BOM_close_window(windowTag));
		}
		
		vector<pair<tag_t,map<string,double>>> sevector;
		vector<pair<tag_t,map<string,double>>>::iterator vectorIter;
		map<string,double> attributeMap;
		map<string,double>::iterator attributeMapIter;
		double acdoublequantity = 0;
		double stationacdoublequantity = 0;
		double rootAcdoublequantity = 0;
		tag_t rootItemTag = NULL,	InnerOperationsTag = NULL,	InnerOperationsRevTag = NULL;
		tag_t rootRevTag = NULL,	innerTopLineTag = NULL,	newBomviewTag = NULL,
			AssemblyOperationTag = NULL,	AssemblyOperationRevTag	= NULL,	AssemblyTopLineTag = NULL,
			SupplierOperationTag = NULL,	SupplierOperationRevTag = NULL,	SupplierTopLineTag = NULL,
			TopWaItemTag = NULL,	TopWaItemRevTag = NULL,	TopWaTopLineTag = NULL,
			StationItemTag = NULL,	StationRevTag = NULL, StationTopLineTag = NULL,
			OperationTopLineTag = NULL,	viewTag = NULL,	bomWindowTag = NULL,
			topbomlineTag = NULL, bomviewTag = NULL,	bvrTag = NULL,
			newBomlineTag = NULL, relationTag = NULL;
		
		rootDataMapIter = rootDataMap.begin();
		int counter = 0;

		ERROR_REPORT(GRM_find_relation_type("IMAN_master_form",&relationTag));
		PS_find_view_type("view",&viewTag);
		
		for( rootDataMapIter ; rootDataMapIter != rootDataMap.end() ; rootDataMapIter++)
		{
			cout << "Main key" << rootDataMapIter->first << endl;
			string Itemid = "BOP_" + rootDataMapIter->first;
			
			ERROR_REPORT(ITEM_create_item(NULL,Itemid.c_str(),"Product",NULL,&rootItemTag,&rootRevTag));
			ERROR_REPORT(AOM_save(rootItemTag));
			CreateBVR( viewTag, rootItemTag,rootRevTag );

			ERROR_REPORT(ITEM_create_item(NULL,"InnerOperations","Product",NULL,&InnerOperationsTag,&InnerOperationsRevTag));
			ERROR_REPORT(AOM_save(InnerOperationsTag));
			CreateBVR( viewTag, InnerOperationsTag,InnerOperationsRevTag );

			ERROR_REPORT(ITEM_create_item(NULL,"Assembly operations","Product",NULL,&AssemblyOperationTag,&AssemblyOperationRevTag));
			ERROR_REPORT(AOM_save(AssemblyOperationTag));

			ERROR_REPORT(ITEM_create_item(NULL,"Supplier operations","Product",NULL,&SupplierOperationTag,&SupplierOperationRevTag));
			ERROR_REPORT(AOM_save(SupplierOperationTag));

			// Create Window 
			ERROR_REPORT(BOM_create_window(&bomWindowTag));
			ERROR_REPORT(BOM_set_window_top_line(bomWindowTag,rootItemTag,rootRevTag,newBomviewTag,&topbomlineTag));
			
			ERROR_REPORT(BOM_line_add(topbomlineTag,InnerOperationsTag,InnerOperationsRevTag,newBomviewTag,&innerTopLineTag));
			ERROR_REPORT(BOM_line_add(topbomlineTag,AssemblyOperationTag,AssemblyOperationRevTag,newBomviewTag,&AssemblyTopLineTag));
			ERROR_REPORT(BOM_line_add(topbomlineTag,SupplierOperationTag,SupplierOperationRevTag,newBomviewTag,&SupplierTopLineTag));

			postRootMap = rootDataMapIter->second;
			postRootMapIter = postRootMap.begin();
			rootAcdoublequantity = 0;

			for( postRootMapIter ; postRootMapIter != postRootMap.end() ; postRootMapIter++)
			{
				cout << "\t sub key "<< postRootMapIter->first << endl;
				ERROR_REPORT(ITEM_create_item(NULL,postRootMapIter->first.c_str(),"Product",NULL,&TopWaItemTag,&TopWaItemRevTag));
				ERROR_REPORT(AOM_save(TopWaItemTag));
				CreateBVR( viewTag, TopWaItemTag,TopWaItemRevTag );				
				
				ERROR_REPORT(BOM_line_add(innerTopLineTag,TopWaItemTag,TopWaItemRevTag,newBomviewTag,&TopWaTopLineTag));

				operationMap = postRootMapIter->second;
				operationMapiter = operationMap.begin();
				stationacdoublequantity = 0;
				for( operationMapiter ; operationMapiter != operationMap.end() ; ++operationMapiter)
				{
					acdoublequantity = 0;
					sevector = operationMapiter->second;
					cout << "\t\tStation " << operationMapiter->first << endl;
					ERROR_REPORT(ITEM_create_item(NULL,operationMapiter->first.c_str(),"Product",NULL,&StationItemTag,&StationRevTag));
					ERROR_REPORT(AOM_save(StationItemTag));
					CreateBVR( viewTag, StationItemTag,StationRevTag );

					ERROR_REPORT(BOM_line_add(TopWaTopLineTag,StationItemTag,StationRevTag,newBomviewTag,&StationTopLineTag));

					for( vectorIter = sevector.begin(); vectorIter != sevector.end() ; ++vectorIter)
					{
						ERROR_REPORT(BOM_line_add(StationTopLineTag,(*vectorIter).first,NULL,newBomviewTag,&OperationTopLineTag));
						attributeMap = (*vectorIter).second;
						attributeMapIter = attributeMap.begin();
						for( attributeMapIter ; attributeMapIter != attributeMap.end(); attributeMapIter++)
						{
							//cout << attributeMapIter->first << ":" << attributeMapIter->second << endl;
							acdoublequantity += attributeMapIter->second;
							cout <<"\t\t\t\t" << attributeMapIter->second << endl;
						}
					}
					cout <<"\t\t" << acdoublequantity << endl;
					stationacdoublequantity += acdoublequantity;
					SetFormAttribute( StationRevTag ,acdoublequantity, relationTag);
				}
				cout << "\t" << stationacdoublequantity << endl;
				rootAcdoublequantity += stationacdoublequantity;
				SetFormAttribute( TopWaItemRevTag ,stationacdoublequantity, relationTag);
			}
			cout << rootAcdoublequantity << endl;
			SetFormAttribute( rootRevTag ,rootAcdoublequantity, relationTag);
			ERROR_REPORT(BOM_save_window(bomWindowTag));
			ERROR_REPORT(BOM_close_window(bomWindowTag));
		}

		if( sObjectType != NULL && tc_strlen(sObjectType) > 0 )	MEM_free(sObjectType);
		if( sObjectName != NULL && tc_strlen(sObjectName) > 0 )	MEM_free(sObjectName);
		if( sPropValue != NULL && tc_strlen(sPropValue) > 0 )	MEM_free(sPropValue);
	}

	logfile.close();
	return ITK_ok;
}

void Help()
{
	logfile << "\n------------------------------------------------------------\n" ;
	logfile << "Usage:\n\n";
	logfile << "MEActivity_update_attr.exe \t-u=<valid Teamcenter User Name>\n\n" ;
	logfile << "\t\t\t\t-p=<valid Password of the User>\n\n" ;
	logfile << "\t\t\t\t-g=<valid Group of the User>\n\n" ;
	logfile << "\t\t\t\t[-InGroup]=<Valid Input group name for MEactivity>\n\n" ;
	logfile << "\t\t\t\t[-help]\n\n" ;
	logfile << "-u\t\t-  User name\n\n" ;
	logfile << "-p\t\t-  Password\n\n" ;
	logfile << "-g\t\t-  Group\n\n" ;
	logfile << "-inputfile\t\t-  input file path\n\n" ;
	logfile << "-help\t\t-  Displays this help\n\n" ;
	logfile << "------------------------------------------------------------\n" ;
	exit(1);
}

void ReadArguments(char **sUserName,char **sPassword,char **sGroupName,char **sInputFileName)
{
	*sUserName = ITK_ask_cli_argument( "-u=" );
	if(*sUserName==NULL)	{	logfile << "\nArgument -Username Missing";	Help(); }

	*sPassword = ITK_ask_cli_argument( "-p=" );
	if(*sPassword==NULL)	{	logfile << "\nArgument -Password Missing";	Help(); }

	*sGroupName = ITK_ask_cli_argument( "-g=" );
	if(*sGroupName==NULL)	{	logfile << "\nArgument -Group Missing";	Help(); }

	*sInputFileName = ITK_ask_cli_argument( "-inputfile=" );
	if(*sInputFileName==NULL)	{	logfile << "\nArgument -InGroup Missing";	Help(); }
}

int getValidBVR ( tag_t revTag, char *plant, tag_t *bvrTag )
{
	int		bvrCnt=0, bvr=0;//result=0,	
	 
	char	*bvType=NULL;	//bvrType[129]={'\0'};

	tag_t	*bvrTags={NULLTAG},
			bvTag=NULLTAG,		bvTypeTag=NULLTAG;

	*bvrTag = NULLTAG;

	ERROR_REPORT(ITEM_rev_list_all_bom_view_revs( revTag, &bvrCnt, &bvrTags ));
	for( bvr=0; bvr<bvrCnt; bvr++ )
	{
		//ERROR_CALL(WSOM_ask_object_type( bvrTags[bvr], bvrType ));
		ERROR_REPORT(PS_ask_bom_view_of_bvr( bvrTags[bvr], &bvTag));
		ERROR_REPORT(PS_ask_bom_view_type( bvTag, &bvTypeTag));
		ERROR_REPORT(PS_ask_view_type_name( bvTypeTag, &bvType));

		//if( tc_strcasecmp(bvrType, "view BOMView Revision")==0 )
		//if( tc_strcasecmp(bvType, "view")==0 )
		if( ( plant==NULL &&  tc_strcasecmp(bvType, "view")==0 ) || (plant!=NULL && strstr(bvType, plant)!=NULL) )
		{
			*bvrTag=bvrTags[bvr];
			break;
		}
	}
	if( bvType!=NULL && strlen(bvType)>0 )	MEM_free(bvType);
	if( bvrCnt>0 )	MEM_free( bvrTags );

	return 0;
}

int ProcessBOMchild(tag_t childTag, int topQuantity)
 {
	int ichildCount,operation_count;
	 double partQuantity = 1 ;
	char * quantity = NULL;
	//tag_t itemIDTag = NULL;
	char *itemID = NULL;
	tag_t itemIDtag = NULL,	revTag = NULL;
	tag_t * bomChildrenTags = { NULLTAG },	*operations = { NULLTAG };
	
	ERROR_REPORT(BOM_line_ask_all_child_lines(childTag,&ichildCount,&bomChildrenTags));
	//cout << "child "  << ichildCount << endl;
	//cout << "ProcessBOMchild : " <<  topQuantity << endl;
	ERROR_REPORT(AOM_ask_value_string(childTag,"bl_item_item_id",&itemID));
	ERROR_REPORT(AOM_UIF_ask_value(childTag,"bl_quantity",&quantity));
	
	if(strlen(quantity)>0)
		partQuantity = atof(quantity);
	else
		partQuantity = partQuantity * 1;

	topQuantity = topQuantity * partQuantity;

	
	//if( quantity == 0)
//	{
	//	quantity = 1;
	//}
		
//	topQuantity = topQuantity * quantity;
		

	ERROR_REPORT(ITEM_find_item(itemID,&itemIDtag));
	ERROR_REPORT(ITEM_ask_latest_rev(itemIDtag,&revTag));
	ERROR_REPORT(AOM_ask_value_tags(revTag,"ar3AC_Operations",&operation_count,&operations));

	for( int iOperation = 0 ; iOperation < operation_count ; iOperation++ )
	{
		//cout << "itemid "  << itemID << endl;
		ERROR_REPORT(AOM_ask_value_string(operations[iOperation],"item_id",&itemID));

		//cout << "itemid "  << itemID << endl;
		GetStationDetails(itemID , topQuantity);
	}

	ERROR_REPORT(BOM_line_ask_all_child_lines(childTag,&ichildCount,&bomChildrenTags));

	//cout << "children" << ichildCount << endl;
	for( int child = 0; child < ichildCount ; child++)
	{
		ProcessBOMchild(bomChildrenTags[child],topQuantity);
	}
	
		
	return ITK_ok;

 }

void GetStationDetails(char * itemID, int topQuantity)
 {
	 tag_t itemIDtag = NULL,	revTag = NULL,	validBvrTag=NULL,
		 windowTag = NULL,	topBomLineTag = NULL;

	 tag_t * bomChildrenTags  = { NULLTAG };
	 int ichildCount = 0;
	 
	 char *sObjectType = NULL,	*sItemID = NULL,	*sar3AC_TOP = NULL;

	// cout <<  "itemID \t" << itemID  << "\t topQuantity \t" << topQuantity << endl;

	 ERROR_REPORT(ITEM_find_item(itemID,&itemIDtag));
	 string operationItem = itemID ;
	 tag_t operationItemTag = itemIDtag;
	 ERROR_REPORT(ITEM_ask_latest_rev(itemIDtag,&revTag));
	  tag_t operationRevTag = revTag;

	 getValidBVR( revTag, NULL, &validBvrTag );
	 ERROR_REPORT(BOM_create_window(&windowTag));
	 ERROR_REPORT(BOM_set_window_top_line(windowTag,NULLTAG,revTag,validBvrTag,&topBomLineTag));
	 ERROR_REPORT(BOM_line_ask_all_child_lines(topBomLineTag,&ichildCount,&bomChildrenTags));
	 
	 vector<pair<tag_t,map<string,double>>> tempVector;
	 vector<pair<tag_t,map<string,double>>> operationVector;
	 map<string,double> attributeMap;
	 map<string,vector<pair<tag_t,map<string,double>>>> tempMap;
	 map<string,vector<pair<tag_t,map<string,double>>>>::iterator tempMapIter;
	 map<string,map<string,vector<pair<tag_t,map<string,double>>>>> temppostRootMap;

	// cout << "GetStationDetails : " << topQuantity << endl;
	for( int child = 0; child < ichildCount ; child++ )
	{
		ERROR_REPORT(AOM_UIF_ask_value( bomChildrenTags[child], "bl_item_object_type", &sObjectType));
		
		if(	tc_strcmp( sObjectType , "CADItem") == ITK_ok )
		{
			ERROR_REPORT(AOM_UIF_ask_value( bomChildrenTags[child], "bl_item_item_id", &sItemID));		
			ERROR_REPORT(ITEM_find_item(sItemID,&itemIDtag));
			ERROR_REPORT(ITEM_ask_latest_rev(itemIDtag,&revTag));
			ERROR_REPORT(AOM_UIF_ask_value(revTag, "object_desc", &sar3AC_TOP));	

			if(tc_strlen( sar3AC_TOP ) >0)
			{
				rootDataMapIter = rootDataMap.find(RootItem);

				if( rootDataMapIter != rootDataMap.end() )
				{
					temppostRootMap = rootDataMap[RootItem];
					postRootMapIter = temppostRootMap.find(sar3AC_TOP);
					
					if( postRootMapIter != temppostRootMap.end() )
					{
						tempMap = temppostRootMap[sar3AC_TOP];
						tempMapIter = tempMap.find(sItemID);
						if( tempMapIter != tempMap.end() )
						{
							tempVector = tempMap[sItemID];
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							tempVector.push_back(make_pair(operationItemTag,attributeMap));
							tempMap[sItemID] = tempVector;
							temppostRootMap[sar3AC_TOP] =  tempMap; 
						}
						else
						{
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							tempMap[sItemID] = operationVector;
							temppostRootMap[sar3AC_TOP] = tempMap;
						}
						 rootDataMap[RootItem] = temppostRootMap;
					}
					else
					{
						operationMapiter = operationMap.find(sItemID);
						if( operationMapiter != operationMap.end() )
						{
							operationVector = operationMap[sItemID];
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							operationMap[sItemID] = operationVector;
						} 
						else
						{
							operationMap.clear();
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							operationMap[sItemID] = operationVector;
						}
						temppostRootMap[sar3AC_TOP] = operationMap;
						rootDataMap[RootItem] = temppostRootMap;
					}
				}
				else
				{
					postRootMapIter = postRootMap.find(sar3AC_TOP);
					
					if( postRootMapIter != postRootMap.end() )
					{
						tempMap = postRootMap[sar3AC_TOP];
						tempMapIter = tempMap.find(sItemID);
						if( tempMapIter != tempMap.end() )
						{
							tempVector = tempMap[sItemID];
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							tempVector.push_back(make_pair(operationItemTag,attributeMap));
							tempMap[sItemID] = tempVector;
							postRootMap[sar3AC_TOP] =  tempMap;
						}
						else
						{
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							tempMap[sItemID] = operationVector;
							postRootMap[sar3AC_TOP] = tempMap;
						}
						 rootDataMap[RootItem] = postRootMap;
					}
					else
					{
						operationMapiter = operationMap.find(sItemID);
						if( operationMapiter != operationMap.end() )
						{
							operationVector = operationMap[sItemID];
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							operationMap[sItemID] = operationVector;
						} 
						else
						{
							operationMap.clear();
							attributeMap.clear();
							UpdateAttribute(operationRevTag,attributeMap,topQuantity);
							operationVector.push_back(make_pair(operationItemTag,attributeMap));
							operationMap[sItemID] = operationVector;
						}
						postRootMap[sar3AC_TOP] = operationMap;
						rootDataMap[RootItem] = postRootMap;
					}
				}
			}
			break;
		}
	}

	ERROR_REPORT(BOM_close_window(windowTag));

	if( sObjectType != NULL && tc_strlen(sObjectType) > 0 )	MEM_free(sObjectType);
	if( sItemID != NULL && tc_strlen(sItemID) > 0 )	MEM_free(sItemID);
	if( sar3AC_TOP != NULL && tc_strlen(sar3AC_TOP) > 0 )	MEM_free(sar3AC_TOP);
 }

void UpdateAttribute(tag_t objectTag,map<string,double> &AttributeMap,int topQuantity)
 {
	 int formCnt1;
	 double partQuantity = 0;
	 char * dQuantity = NULL ;

	 tag_t	relationTag=NULLTAG,
			*formTags1={NULLTAG} ;

	  map<string,double>::iterator AttributeMapIter;

	 ERROR_REPORT(GRM_find_relation_type("IMAN_master_form",&relationTag));
	 ERROR_REPORT(GRM_list_secondary_objects_only( objectTag, relationTag, &formCnt1, &formTags1));

	 ERROR_REPORT(AOM_UIF_ask_value(formTags1[0] , "AC_Base_BOM_Quantity" , &dQuantity));
	 
	 if(strlen(dQuantity)>0)
	 {
		partQuantity = atof(dQuantity);
		topQuantity = topQuantity * partQuantity;
		AttributeMap["AC_Base_BOM_Quantity"] = topQuantity;
		//	cout << "form count :" << topQuantity << endl;
	 }
 }

 void SetFormAttribute(tag_t objectTag, double AC_bom_quantity, tag_t relationTag)
 {
	int formCnt1;
	tag_t	*formTags1={NULLTAG} ;
	ERROR_REPORT(GRM_list_secondary_objects_only( objectTag, relationTag, &formCnt1, &formTags1));

	ERROR_REPORT(AOM_set_value_double(formTags1[0],"AC_Base_BOM_Quantity",AC_bom_quantity));
	ERROR_REPORT( AOM_save(formTags1[0]));
	ERROR_REPORT(AOM_refresh(formTags1[0],true));
	//Set_Attribute_Value(formTags1[0],"AC_Base_BOM_Quantity",AC_bom_quantity);
	ERROR_REPORT(AOM_set_value_double(formTags1[0],"AC_Base_BOM_Quantity",AC_bom_quantity));
	ERROR_REPORT(AOM_save(formTags1[0]));
	ERROR_REPORT(AOM_refresh(formTags1[0],false));
 }

void Set_Attribute_Value(tag_t formTag,char *Attribute,double value)
{
//	char	String_value[32];

//		sprintf(String_value,  "%0.2f", value);	

//	ERROR_REPORT( AOM_set_value_string (formTag,Attribute,String_value));
	ERROR_REPORT(AOM_set_value_double(formTag,Attribute,value));
	//return ITK_ok;
}

 void CreateBVR(tag_t viewTag, tag_t rootItemTag,tag_t rootRevTag)
 {
	tag_t bomviewTag = NULL,	bvrTag = NULL;

	ERROR_REPORT(PS_create_bom_view(viewTag,NULL,NULL,rootItemTag,&bomviewTag));
	AOM_save(bomviewTag);
	AOM_save(rootItemTag);
	PS_create_bvr(bomviewTag,NULL,NULL,FALSE,rootRevTag,&bvrTag);
	AOM_save(bvrTag);
	AOM_save(rootRevTag);
 }