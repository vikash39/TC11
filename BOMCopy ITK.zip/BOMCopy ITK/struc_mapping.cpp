/*------------------------------------------------------------------------------------------------

 * Filename		    :   MRV_structure_mapping.cxx
 * Description      :
 * Module  		    :   MRV_structure_mapping.exe
 * Since		    :   release1
 * ENVIRONMENT		:   C, ITK
 * Note				:
 * FUNCTION LIST	:
 * History
 *------------------------------------------------------------------------------------------------
 * Date         	Name				Description of Change
 * 27-11-2010		Padma Kumar			Initial creation
 * -----------------------------------------------------------------------------------------------

 *************************************************************************************************/
#include "tc_common.h"
#include <ict/ict_userservice.h>
#include <server_exits/user_server_exits.h>
#include <tccore/custom.h>
#include "mm_strings.h"
#include <tccore/project.h>
#include <ss/ss_const.h>


using namespace std;
//#define printf TC_write_syslog

typedef std::map<std::string, std::string> mapCAEStruct;
mapCAEStruct mapStructureObjects;

char **sUnavailablePartItemId			= NULL,
      sMmItemUnassignedList[1024+1]		= "",
	  sMemberUnprivilegedList[1024+1]	= "",
	  sProjUnassignedList[1024+1]		= "",
	  *sGlobRevConfigRule				= NULL;
int proj_assign(tag_t tRevTag, tag_t tTargetRevTag);

int iErrorThrowConst			=  0,
    iFlagTraverse				= 0,
	iProjAssignFlag				= 0,
	iErrStrIndex				= -1,
	iProjListIndex				= 0,
	iProjUnassignedListReady	= 0,
	iMmItemUnassignedListReady  = 0,	
	iUnprivilegeListReady		= 0;

//FILE *time_stamp_file = NULL;

/****************************************************************************
 *  Function Name		:mrv_structure_mapping
 *  Description		    :This is the main module of server exit.
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS :
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		:None
 *	FUNCTIONS CALLED	:MRV_structure_mapping
 *
 ******************************************************************************/
int mrv_structure_mapping(void* retvalue)
{
	/* Declaration */
    int iStatus = ITK_ok,g = 0;

	char	*psMasterItemID	= NULL,
			*psDomainName	= NULL,
			*psRevID		= NULL,
			*sRevConfigRule = NULL,
			sTempErrorString[5000] = "-",
			sEnv[1024+1]     =  "",
			*sReUseObjectTag = NULL,
			*sCloneItemIDMaster = NULL;

	tag_t	tMasterItem		= NULLTAG,
			tMasterItemRev	= NULLTAG,
			tMasterRevTag  = NULLTAG;
	
	logical lTopAssemblyVerdict;

	printf("\n\nEntering mrv_structure_mapping..");


    try
    {
		/* Reading user service argument */

		MRV_TRACE_CALL ( iStatus = USERARG_get_string_argument(&psMasterItemID) ) ;

		MRV_TRACE_CALL ( iStatus = USERARG_get_string_argument(&psRevID) ) ;

		MRV_TRACE_CALL ( iStatus = USERARG_get_string_argument(&psDomainName) ) ;

		MRV_TRACE_CALL ( iStatus = USERARG_get_string_argument(&sRevConfigRule) ) ;
		
		printf("\n\n   IN : %s/%s-%s",psMasterItemID,psRevID,psDomainName);

		/* Calling function for the processing parent assembly */
        iErrorThrowConst = 0;
		iFlagTraverse = 0;
		iProjAssignFlag = 0;
		iErrStrIndex = -1;
		iProjListIndex = 0;iProjUnassignedListReady = 0;iMmItemUnassignedListReady = 0;iUnprivilegeListReady = 0;

		 tc_strcpy(sTempErrorString,"");
	     tc_strcpy(sMmItemUnassignedList,"");
		 tc_strcpy(sProjUnassignedList,"");
		 tc_strcpy(sMemberUnprivilegedList,"");
		 sGlobRevConfigRule = NULL;

		 printf("\n sGlobRevConfigRule(after nullifying) = %s",sGlobRevConfigRule);
		 //opening file

		sGlobRevConfigRule = sRevConfigRule;
		printf("\n sGlobRevConfigRule(after copying) = %s",sGlobRevConfigRule);
		
		if(sGlobRevConfigRule == sRevConfigRule)
		{   
			printf("\n rev rule got is correct***************process starting");
		}
		
		
         /*sEnv = getenv ("TC_DATA");*/

		 /*printf("\n time_stamp_file_path = %s ",time_stamp_file_path);
		 tc_strcpy(time_stamp_file_path,"C:\\TEMP\\CAE\\sim_assembly.txt");
         fopen_s(&time_stamp_file,time_stamp_file_path,"w");*/
         
         MRV_TRACE_CALL( iStatus = ITEM_find_rev(psMasterItemID,psRevID,&tMasterRevTag));
         //
         sUnavailablePartItemId =  (char**)MEM_alloc(sizeof(char*)*1024);
		 sCloneItemIDMaster = (char *) MEM_alloc(256);
         //sTempErrorString = (char*)MEM_alloc(sizeof(char)*5000);
		 mapStructureObjects.clear();
		//

		 if(!tc_strcmp(psDomainName,MMCFD))
			sprintf (sCloneItemIDMaster, "%s-%s-%c", psMasterItemID, psRevID,'F');
		 else
			sprintf (sCloneItemIDMaster, "%s-%s-%c", psMasterItemID, psRevID,*psDomainName);

		 printf("\n sCloneItemIDMaster ------- %s\n",sCloneItemIDMaster);

		 MRV_TRACE_CALL( iStatus = ITEM_find_item(sCloneItemIDMaster,&tMasterItem));

		printf(" \n  tMasterItem = %d",tMasterItem);

        if(tMasterItem != NULLTAG)
		{
		 iStatus = AM_check_privilege(tMasterItem,"READ",&lTopAssemblyVerdict);
		 printf(" \n  lTopAssemblyVerdict = %d",lTopAssemblyVerdict);

		    if ( lTopAssemblyVerdict == 0)
			{
				printf("\n       Structure for \"%s\" Already Exist",psDomainName);
				iStatus = MM_STRUCT_ALREADY_EXISTS;
				MRV_TRACE_CALL( iStatus =  EMH_store_initial_error_s1( EMH_severity_error,iStatus,psMasterItemID));
				return MM_STRUCT_ALREADY_EXISTS;
			}
		}

			iStatus  = traverse_master_structure(psMasterItemID,psRevID,psDomainName);
         printf("\nflag_traverse = %d",iFlagTraverse);
		 if(iFlagTraverse != 0)
		 {   
             /*sTempErrorString = (char*)MEM_alloc(1024);*/
			 for(g = 0;g <= iErrStrIndex;g++)
			 {   
				 printf("\n concatenating");
                 tc_strcat(sTempErrorString,"\r\n");
				 //printf("\n in loop sTempErrorString = %s",sTempErrorString);
				 tc_strcat(sTempErrorString,sUnavailablePartItemId[g]);
			     
			 }
             
            printf("\n sTempErrorString = %s",sTempErrorString);

		    EMH_store_initial_error_s1( EMH_severity_error,MMSIMPARTNOTAVAILABLEEROR,sTempErrorString);
			printf("\n MMSIMPARTNOTAVAILABLEEROR is %d",MMSIMPARTNOTAVAILABLEEROR);
            for(g = 0;g <= iErrStrIndex;g++)
			{
				tc_strcpy(sUnavailablePartItemId[g],"");
			}
			tc_strcpy(sTempErrorString,"");
			MEM_free(sUnavailablePartItemId);
			sUnavailablePartItemId = NULL;
			return MMSIMPARTNOTAVAILABLEEROR;
		 }
		 //privilege check for simassembly
         if(iUnprivilegeListReady == 1)
		 {
              EMH_store_initial_error_s1( EMH_severity_error,MM_USER_PRIVILEGE_OF_PROJ_ERROR,sMemberUnprivilegedList);
		      return MM_USER_PRIVILEGE_OF_PROJ_ERROR;
		 }




         //project assigning check
         if(iProjUnassignedListReady == 1)
		 {
            EMH_store_initial_error_s1( EMH_severity_error,MM_PROJ_ASSIGN_ERROR,sProjUnassignedList);
		    return MM_PROJ_ASSIGN_ERROR;
		 }
		 //
		iStatus = MRV_process_master_structure(psMasterItemID, psRevID, psDomainName);


		

		
        /*if(iStatus == MMSIMPARTNOTAVAILABLEEROR)
		{
			EMH_store_initial_error_s1( EMH_severity_error,MMSIMPARTNOTAVAILABLEEROR,sUnavailablePartItemId);
			printf("\n MMREVNOTCONFIGUREDERROR is %d",MMSIMPARTNOTAVAILABLEEROR);
			return MMSIMPARTNOTAVAILABLEEROR;
		}*/
		/* iStatus = 1, if it already exist */

		if ( !iStatus )
		{
			//MRV_TRACE_CALL( iStatus = MRV_traverse_map_structure() );

			/* Calling function for processing cloned items */

			MRV_TRACE_CALL( iStatus = MRV_process_clone_structure(psMasterItemID, psRevID, psDomainName) );
			printf("\n\n   IN : %s/%s-%s",psMasterItemID,psRevID,psDomainName);

			MRV_TRACE_CALL( iStatus = ITEM_find_item ( psMasterItemID, &tMasterItem ));
			printf("\n\n   IN1 :%d",tMasterItem);

			MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tMasterItem, psRevID, &tMasterItemRev ));
			printf("\n\n   IN2 :%d",tMasterItemRev);

			* (tag_t *)retvalue = tMasterItemRev;
		}
		else
		{
			/* Function block if already exist */

			MRV_TRACE_CALL( iStatus = ITEM_find_item ( psMasterItemID, &tMasterItem ));

			cout << "\n   Already Exist";			
			iStatus = MM_STRUCT_ALREADY_EXISTS;
			MRV_TRACE_CALL( iStatus =  EMH_store_initial_error_s1( EMH_severity_error,iStatus,psMasterItemID));
			printf("\n MM_STRUCT_ALREADY_EXISTS is %d",MM_STRUCT_ALREADY_EXISTS);
			return MM_STRUCT_ALREADY_EXISTS;

			* (tag_t *)retvalue = tMasterItem;
			
		}

    }
    catch (...)
    {

    }

	/* Memory Cleanup */
    
	/*if(iProjAssignFlag == 1 || iMmItemUnassignedListReady == 1)
	{
            iStatus = MM_PROJECT_ASSIGNING_ERRORS;
		    MRV_TRACE_CALL( iStatus =  EMH_store_initial_error_s2( EMH_severity_error,iStatus,sMmItemUnassignedList,proj_assigning_errors));
			printf("\n MM_PROJECT_ASSIGNING_ERRORS is %d",MM_PROJECT_ASSIGNING_ERRORS);
			mapStructureObjects.clear();
			return MM_PROJECT_ASSIGNING_ERRORS;
	}*/
    /*printf("\n closing file");
    fclose(time_stamp_file);
     printf("\n  file closed");*/
	mapStructureObjects.clear();
	printf("\n map cleared");

    return iStatus;
}

/****************************************************************************
 *  Function Name		:MRV_traverse_map_structure
 *  Description			:This function used to print all the processed items
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_traverse_map_structure()
{
	/* Local Declaration */

	int		icnt	= 1,
			iStatus			= ITK_ok;

	tag_t	tSourceObjectRev	= NULLTAG,
			tDestObjectRev		= NULLTAG;

	char	*sItemID1		= NULL,
			*sItemRevID1	= NULL,
			*sItemID2		= NULL,
			*sItemRevID2	= NULL;

	mapCAEStruct::iterator mapCAEStructIterator;

	/* Print all the processed items */

	for ( mapCAEStructIterator = mapStructureObjects.begin(); mapCAEStructIterator != mapStructureObjects.end(); ++mapCAEStructIterator )
	{
		MRV_TRACE_CALL( iStatus = AOM_string_to_tag ( mapCAEStructIterator->first.c_str(), &tSourceObjectRev ));

		MRV_TRACE_CALL( iStatus = AOM_refresh(tSourceObjectRev,false));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tSourceObjectRev,"item_id",&sItemID1));
		printf("\n sItemID1 is %s",sItemID1);

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tSourceObjectRev,"item_revision_id",&sItemRevID1));
		printf("\n sItemRevID1 is %s",sItemRevID1);

		MRV_TRACE_CALL( iStatus = AOM_string_to_tag ( mapCAEStructIterator->second.c_str(), &tDestObjectRev ));

		MRV_TRACE_CALL( iStatus = AOM_refresh(tDestObjectRev,false));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tDestObjectRev,"item_id",&sItemID2));
		printf("\n sItemID2 is %s",sItemID2);

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tDestObjectRev,"item_revision_id",&sItemRevID2));
		printf("\n sItemRevID2 is %s",sItemRevID2);

		cout<< "\n\n mapCAEStructIterator " << icnt <<" : " << mapCAEStructIterator->first << " (" << sItemID1 <<"/" << sItemRevID1 << ") "<<mapCAEStructIterator->second<< " (" << sItemID2 <<"/" << sItemRevID2 << ") ";

		icnt++;
	}
	
	return ITK_ok;
}
/****************************************************************************
 *  Function Name		:MRV_process_master_structure
 *  Description			:This function used to process parent assembly
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_process_master_structure(char *sMasterItemID, char *sMasterItemRevID, char *sDomainValue)
{
	/* Local Declaration */

	int		iStatus				= ITK_ok,
			iBvrCount			= 0,
			iFirstLevelChild	= 0,
			iConfigValue          = 0;

	tag_t	tMasterItemRev			= NULLTAG,
			tMasterItem				= NULLTAG,
			*ptBvrItem				= NULL,
			tBomWindow				= NULLTAG,
			tTopLine				= NULLTAG,
			*ptFirstLevelChildern	= NULL,
			tRule                    = NULLTAG;

	char	*sChildItemID			= NULL,
			*sChildItemRevID		= NULL,
			*sReUseObjectTag		= NULL,
			*sAttributeName         = NULL;

	tag_t	tChildItemRev			= NULLTAG;

	int		isFilter				= 1;

	printf("\nProcessing : %s/%s..\n", sMasterItemID, sMasterItemRevID);

	MRV_TRACE_CALL( iStatus = ITEM_find_item ( sMasterItemID, &tMasterItem ));
	printf("\n tMasterItem is %d",tMasterItem);


	MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tMasterItem, sMasterItemRevID, &tMasterItemRev ));
	printf("\n tMasterItemRev is %d",tMasterItemRev);

	/* Calling function to find the re-usable component */

	MRV_TRACE_CALL( iStatus = MRV_check_existing_part(tMasterItemRev, sDomainValue, &sReUseObjectTag) );

	printf("\n sReUseObjectTag  = %s",sReUseObjectTag);
	printf("\n iErrorThrowConst = %d",iErrorThrowConst);
	if ( tc_strlen(sReUseObjectTag) > 0 && iErrorThrowConst == 1)
	{
		printf("\n       Structure for \"%s\" Already Exist",sDomainValue);

		return 1;
	}

	/* Calling function to find the filter component */
	MRV_TRACE_CALL( iStatus = MRV_check_filter_part(tMasterItemRev, &isFilter) );

	if (!isFilter)
	{
		return 1;
	}

	/* Processing parent assembly */
	MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs ( tMasterItemRev, &iBvrCount, &ptBvrItem ));
	printf("\n iBvrCount is %d",iBvrCount);
	if(iBvrCount == 0)
	{
	iStatus = MM_NO_BVRCOUNT;
	MRV_TRACE_CALL( iStatus =  EMH_store_initial_error( EMH_severity_error,iStatus));   
	printf("\n MM_NO_BVRCOUNT is %d",MM_NO_BVRCOUNT);
	return MM_NO_BVRCOUNT;
	}

	MRV_TRACE_CALL( iStatus = BOM_create_window(&tBomWindow));
    
	MRV_TRACE_CALL( iStatus = CFM_find(sGlobRevConfigRule,&tRule));  
	
	MRV_TRACE_CALL( iStatus = BOM_set_window_config_rule(tBomWindow,tRule));
	
	MRV_TRACE_CALL( iStatus = BOM_set_window_top_line(tBomWindow,NULLTAG,tMasterItemRev,ptBvrItem[0],&tTopLine));

	MRV_TRACE_CALL( iStatus = BOM_line_ask_all_child_lines(tTopLine, &iFirstLevelChild,&ptFirstLevelChildern ));
	printf("\n iFirstLevelChild is %d",iFirstLevelChild);
		
	for(int iChildInx = 0 ;iChildInx<iFirstLevelChild ;iChildInx++)
	{
		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],"bl_item_item_id",&sChildItemID));
		printf("\n sChildItemID is %s",sChildItemID);

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],"bl_rev_item_revision_id",&sChildItemRevID));
		printf("\n sChildItemRevID is %s",sChildItemRevID);

		MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(ptFirstLevelChildern[iChildInx],"bl_revision",&tChildItemRev));
		printf("\n tChildItemRev is %d",tChildItemRev);		

		printf("\n\n    Child Level %d : %s/%s", iChildInx+1, sChildItemID, sChildItemRevID);

         MRV_TRACE_CALL( iStatus = BOM_line_look_up_attribute("bl_rev_item_revision_id",&iConfigValue));

         MRV_TRACE_CALL( iStatus = BOM_line_ask_attribute_string(ptFirstLevelChildern[iChildInx],iConfigValue,&sAttributeName));
         
		 printf("\n sAttributeName = %s",sAttributeName);

		 if(tc_strcmp(sAttributeName,"") == 0)
		 {
            return MMREVNOTCONFIGUREDERROR;
 		 }


		/* Calling function for processing child */

		MRV_TRACE_CALL( iStatus = MRV_process_child_structure(sChildItemID, sChildItemRevID, sDomainValue, ptFirstLevelChildern[iChildInx]));
		if(iStatus == MMREVNOTCONFIGUREDERROR)
		{
          return MMREVNOTCONFIGUREDERROR;
 		}
	
	}

	/* Calling function for creating parent clone assembly */

	MRV_TRACE_CALL( iStatus = MRV_create_structure_component(sMasterItemID, sMasterItemRevID, sDomainValue, tMasterItemRev) );
	if(iStatus == MMSIMPARTNOTAVAILABLEEROR)
	{
		return MMSIMPARTNOTAVAILABLEEROR;
	}

	/* Memory Cleanup */
	MRV_free_memory (ptFirstLevelChildern);

	MRV_free_memory (ptBvrItem);

	MRV_TRACE_CALL( iStatus = BOM_close_window(tBomWindow));
	
	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_create_structure_component
 *  Description			:This function used to create the process items.
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_create_structure_component(char *sChildItemID, char *sChildItemRevID, char *sDomainValue, tag_t tSourceItemRevision)
{
	int		iStatus					= ITK_ok,
			iCreateRel				= 0,
			iBvCount                = 0,
			iSFCode                 = 0;

    //FILE *time_stamp_file = NULL;

	char	*sCloneItemID			= NULL,
			*sObjectName			= NULL,
			sRevId[64]              = ""  ,
			*sSourceObjRev			= NULL,
			*sCloneObjRev			= NULL,
			sCloneItemRevId[64]		= ""  ;

	tag_t	tCloneItem				= NULLTAG,
		    tCloneItem_rev          = NULLTAG,
			tCloneItemRev			= NULLTAG,
			sInputItem			    = NULLTAG,
			*tBvInputList			= NULLTAG,
			tFilterInputItem       = NULLTAG;

	logical active;
    printf("\n Entering create structure component");
	MRV_TRACE_CALL( iStatus = AOM_ask_value_string( tSourceItemRevision, "object_name", &sObjectName ));

	
	/* Preparing Cloning item id */

	sCloneItemID = (char *) MEM_alloc((int)(tc_strlen(sChildItemID) + tc_strlen(sChildItemRevID) + tc_strlen(sDomainValue)) + 4);
    //
    MRV_TRACE_CALL( iStatus = ITEM_find_rev(sChildItemID,sChildItemRevID,&sInputItem));

    MRV_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(sInputItem,&tFilterInputItem));
	iSFCode = filter_check_for_leaf(tFilterInputItem);
	   if(iSFCode == 1)
	   {
             char *sSourceObjRev	= NULL,
				*sCloneObjRev	= NULL;

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSourceItemRevision, &sSourceObjRev ));

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tCloneItemRev, &sCloneObjRev ));

		mapStructureObjects.insert(make_pair(std::string(sSourceObjRev),std::string("SKIP")));
		return ITK_ok;
	   }

	
	MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs(sInputItem,&iBvCount,&tBvInputList));
	
	if(iBvCount == 0)
	{  
		
		if(!tc_strcmp(sDomainValue,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%s%c", sChildItemID, sChildItemRevID,"AN",'F');
		else
			sprintf (sCloneItemID, "%s-%s-%s%c", sChildItemID, sChildItemRevID,"HW",*sDomainValue);

	   MRV_TRACE_CALL( iStatus = ITEM_find_item ( sCloneItemID, &tCloneItem ));
	   printf("\n tCloneItem is %d",tCloneItem);

	}
    //
	else
	{   
		if(!tc_strcmp(sDomainValue,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%c", sChildItemID, sChildItemRevID,'F');
		else
			sprintf (sCloneItemID, "%s-%s-%c", sChildItemID, sChildItemRevID,*sDomainValue);
	    
	}
	MRV_TRACE_CALL( iStatus = ITEM_find_item ( sCloneItemID, &tCloneItem ));
    //MRV_TRACE_CALL( iStatus = ITEM_ask_latest_rev ( tCloneItem, &tCloneItem_rev ));
	
	printf("\n tCloneItem is %d",tCloneItem);
    

	/* Function block to create new item */
    
	if ( tCloneItem == NULLTAG && iBvCount > 0)
	{
		printf("\n        Cloning new item %s/%s --> %s/%s", sChildItemID, sChildItemRevID, sCloneItemID, sChildItemRevID);
        
		MRV_TRACE_CALL( iStatus = ITEM_create_item ( sCloneItemID, sObjectName, MRV_SIMASSEMBLY_TYPE, NULL, &tCloneItem, &tCloneItemRev ));
		printf("\n tCloneItem is %d",tCloneItem);
		printf("\n tCloneItemRev is %d",tCloneItemRev);
		ITEM_ask_rev_id(tCloneItemRev,sCloneItemRevId);

		proj_assign(tSourceItemRevision, tCloneItemRev);
  
		/*MRV_TRACE_CALL( iStatus =  AOM_ask_value_string (tSourceItemRevision,"project_ids",&sProjectIdValue));
        printf("\n project_id_value = %s",project_id_value);*/
		//if(tc_strcmp(project_id_value,"") == 0 || tc_strcmp(project_id_value," ") == 0)
		//{   
		//	printf("\n mm_item not assigned");
  //          sprintf(sTempString,"\nMM_Item not assigned to any projects %s/%s\n",sChildItemID,sChildItemRevID);
		//	tc_strcat(sMmItemUnassignedList,sTempString);
		//	iMmItemUnassignedListReady = 1;
		//}
		//else
		//{			printf("\ninside assigning");
		//	       /* proj_id = tc_strtok(project_id_value,",");
		//            printf("\n proj_id = %s",proj_id);
		//			fprintf(time_stamp_file,"%s/%s/%s\n",sCloneItemID,sCloneItemRevId,file_proj_id);
		//					while(proj_id!= NULL)
		//					{
		//					   tc_strcat(file_proj_id,proj_id);
		//					   								
		//						proj_id = tc_strtok(NULL,",");
		//						printf("\n proj_id = %s at end of while",proj_id);
		//					}*/
		//                    printf("\n time_stamp_file_path = %s ",time_stamp_file_path);
		//                    tc_strcpy(time_stamp_file_path,"C:\\TEMP\\CAE\\sim_assembly.txt");
		//					printf("\n file opening");
		//					printf("\n file_count = %d",file_count);
		//					if(file_count == 1)
		//					{
		//						fopen_s(&time_stamp_file,time_stamp_file_path,"a");
		//					}
		//					else
		//					{
		//						fopen_s(&time_stamp_file,time_stamp_file_path,"w");
		//						file_count  = 1 ;
		//					}
		//					printf("\n file_count = %d",file_count);
		//					
		//					
		//					fprintf(time_stamp_file,"%s,%s,%s\n",sCloneItemID,sCloneItemRevId,project_id_value);
		//					printf("\n file closing");
		//			        fclose(time_stamp_file);
		//					printf("\n file closed");
		//}
		iCreateRel++;
	}

	/* Function block to create new item revision */
	else
	{
		//MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tCloneItem, sChildItemRevID, &tCloneItemRev ));

		/*if ( tCloneItemRev == NULLTAG )
		{*/
		if (tCloneItemRev != NULLTAG) {
		
			int		iDeepCopiedObjects		= 0;

			tag_t	tCloneLatestRev			= NULLTAG,
					*tDeepCopiedObjects		= NULL;
            
			MRV_TRACE_CALL( iStatus = ITEM_ask_latest_rev ( tCloneItem, &tCloneItemRev ));

            MRV_TRACE_CALL( iStatus = ITEM_ask_rev_id(tCloneItemRev,sRevId));    
           
			printf("\n tCloneLatestRev is %d",tCloneItemRev);

			printf("\n        Cloning existing item rev %s/%s --> %s/%s", sChildItemID, sChildItemRevID, sCloneItemID, sRevId);

			proj_assign(tSourceItemRevision, tCloneItemRev);

			
		}
			/*MRV_TRACE_CALL( iStatus = ITEM_copy_rev ( tCloneLatestRev, sChildItemRevID, &tCloneItemRev ));

			printf("\n tCloneItemRev is %d",tCloneItemRev);
			MRV_TRACE_CALL( iStatus = ITEM_perform_deepcopy ( tCloneItemRev, ITEM_revise_operation, tCloneLatestRev, &iDeepCopiedObjects, &tDeepCopiedObjects));*/

			/*iCreateRel++;*/
		/*}	*/	
	}

	/* Functional block to make clone item as re-usable component */

	if (tCloneItemRev != NULLTAG) 
	{
		    char *sSourceObjRev	= NULL,
				*sCloneObjRev	= NULL;

		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSourceItemRevision, &sSourceObjRev ));
        printf("\n sSourceObjRev = %s",sSourceObjRev);
		MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tCloneItemRev, &sCloneObjRev ));
        printf("\n sCloneObjRev = %s",sCloneObjRev);
		mapStructureObjects.insert(make_pair(std::string(sSourceObjRev),std::string(sCloneObjRev)));
        
		if(iCreateRel)
		{
			MRV_TRACE_CALL( iStatus = MRV_attach_reusable_component(tCloneItemRev, tSourceItemRevision, sDomainValue) );
			proj_assign(tSourceItemRevision, tCloneItemRev);
		}
	
	}

	MRV_free_memory (sCloneItemID);

	
	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_attach_reusable_component
 *  Description			:This function used to attach reusable component
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_attach_reusable_component(tag_t tCloneItemRev, tag_t tSourceItemRevision,char *sDomain)
{
	int		iStatus					= ITK_ok,
			iSecondaryObjects		= 0;

	tag_t	tStorageClass			= NULLTAG,
			*ptSecondaryObjects		= NULL,
			tReuseCompRel			= NULLTAG,
			tReuseCompRel1			= NULLTAG,
			tNewReuseRelationtarg   = NULLTAG,
			tNewReuseRelationsource = NULLTAG,
			tNewRelationtarg        = NULLTAG,
			tNewRelationsource      = NULLTAG;

	char	*sClassType				= NULL,
			sObjectType[WSO_object_type_size_c]	= "";

	printf("\n going into MRV_attach_reusable_component");
    
    MRV_TRACE_CALL( iStatus = GRM_find_relation_type(MRV_MMITEM_TO_SIMASSEMBLY_REL_TARGET,&tReuseCompRel));

    MRV_TRACE_CALL( iStatus = GRM_find_relation_type(MRV_MMITEM_TO_SIMASSEMBLY_REL_SOURCE,&tReuseCompRel1));

    MRV_TRACE_CALL( iStatus = GRM_find_relation ( tCloneItemRev, tSourceItemRevision, tReuseCompRel, &tNewReuseRelationtarg) );
    
    MRV_TRACE_CALL( iStatus = GRM_find_relation ( tCloneItemRev, tSourceItemRevision, tReuseCompRel1, &tNewReuseRelationsource) );
    
	if(tNewReuseRelationtarg == NULLTAG)
	{
	MRV_TRACE_CALL( iStatus = GRM_create_relation ( tCloneItemRev, tSourceItemRevision, tReuseCompRel, NULLTAG, &tNewRelationtarg) );

	MRV_TRACE_CALL( iStatus = AOM_save(tNewRelationtarg) );

	MRV_TRACE_CALL( iStatus = AOM_refresh(tCloneItemRev,false) );
	}
	if(tNewReuseRelationsource == NULLTAG)
	{
	 MRV_TRACE_CALL( iStatus = GRM_create_relation ( tCloneItemRev, tSourceItemRevision, tReuseCompRel1, NULLTAG, &tNewRelationsource) );

	MRV_TRACE_CALL( iStatus = AOM_save(tNewRelationsource) );

	MRV_TRACE_CALL( iStatus = AOM_refresh(tCloneItemRev,false) );
	}

	MRV_TRACE_CALL( iStatus = GRM_list_secondary_objects_only ( tCloneItemRev, NULLTAG, &iSecondaryObjects, &ptSecondaryObjects ));

	for (int iZNX = 0; iZNX < iSecondaryObjects; iZNX++)
	{
		iStatus = POM_class_of_instance(ptSecondaryObjects[iZNX], &tStorageClass);

		iStatus = POM_name_of_class(tStorageClass, &sClassType);

		if ( tc_strcasecmp(sClassType,"Form") == 0 )
		{
			MRV_TRACE_CALL( iStatus = WSOM_ask_object_type(ptSecondaryObjects[iZNX], sObjectType));

			if ( ( tc_strcasecmp(sObjectType,MRV_SIMASSEMBLY_REV_MASTER) == 0 ) /*|| */
				/*( tc_strcasecmp(sObjectType,MRV_SIMPART_REV_MASTER) == 0 )*/ )
			{
				printf("\n             Updating domain value");

				MRV_TRACE_CALL( iStatus = AOM_refresh(ptSecondaryObjects[iZNX], true));
                       
				MRV_TRACE_CALL( iStatus = AOM_set_value_string(ptSecondaryObjects[iZNX], MRV_DOMAIN_ATTRIBUTE, sDomain));

				MRV_TRACE_CALL( iStatus = AOM_save(ptSecondaryObjects[iZNX]));

				MRV_TRACE_CALL( iStatus = AOM_refresh(ptSecondaryObjects[iZNX], false));
			}
		}
	}
    
	MRV_free_memory (ptSecondaryObjects);
	printf("\n exiting MRV_attach_reusable_component");	
	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_check_filter_part
 *  Description			:This function used to apply the filter rule
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_check_filter_part(tag_t tSoureObjectRevision, int *isFilter)
{
	int		iStatus					= ITK_ok,
			iSecondaryObjects		= 0;

	tag_t	tStorageClass			= NULLTAG,
			*ptSecondaryObjects		= NULL,
			tItemMasterRel			= NULLTAG,
			tSourceItem             = NULLTAG,
			tClassTag				= NULLTAG;

	char	*sClassType				= NULL,
			sObjectType[WSO_object_type_size_c]	= "",
			*sPFCodeAttrValue		= NULL,
			sConfigFileLine[81]		= "",
			*sTempPFCodeValue		= NULL,
			*sClassName   = NULL;

	FILE	*fpConfigFile			= NULL;

	*isFilter = 1;

	printf("\n        Entering filter check function : ");

    MRV_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(tSoureObjectRevision,&tSourceItem));

	MRV_TRACE_CALL( iStatus = GRM_find_relation_type("IMAN_master_form",&tItemMasterRel));

	MRV_TRACE_CALL( iStatus = GRM_list_secondary_objects_only ( tSourceItem, tItemMasterRel, &iSecondaryObjects, &ptSecondaryObjects ));

	for (int iZNX = 0; iZNX < iSecondaryObjects; iZNX++)
	{
		iStatus = POM_class_of_instance(ptSecondaryObjects[iZNX], &tStorageClass);

		iStatus = POM_name_of_class(tStorageClass, &sClassType);

		if ( tc_strcasecmp(sClassType,"Form") == 0 )
		{
			MRV_TRACE_CALL( iStatus = WSOM_ask_object_type(ptSecondaryObjects[iZNX], sObjectType));
			printf(" \n sObjectType .... %s",sObjectType);
            MRV_TRACE_CALL( iStatus = POM_class_of_instance(ptSecondaryObjects[iZNX],&tClassTag));
			printf(" \n tClassTag .... %d",tClassTag);
			MRV_TRACE_CALL( iStatus = POM_name_of_class(tClassTag,&sClassName)); 
			printf(" \n sClassName .... %s",sClassName);


		if (  tc_strstr(sObjectType,"MM_Item") != NULL || tc_strstr(sObjectType,"MM_DSPart_I") != NULL || tc_strstr(sObjectType,"MM_DSPart") != NULL || tc_strstr(sObjectType,"MM_Item_I") != NULL || tc_strstr(sObjectType,"MM_ControlPart") != NULL || tc_strstr(sObjectType,"MM_DesignContext") != NULL || tc_strstr(sObjectType,"MM_MasterSection") != NULL || tc_strstr(sObjectType,"MM_PMI") != NULL || tc_strstr(sObjectType,"MM_StandardPart") != NULL || tc_strstr(sObjectType,"MM_Supplier") != NULL || tc_strstr(sObjectType,"MM_Supplier_I") != NULL || tc_strstr(sObjectType,"MM_Temp") != NULL || tc_strstr(sObjectType,"MM_Temp_I") != NULL || tc_strstr(sObjectType,"MM_Vehicle") != NULL )
		{
				MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptSecondaryObjects[iZNX], MRV_FILTER_ATTRIBUTE, &sPFCodeAttrValue));

				printf("\n sPFCodeAttrValue = %s",sPFCodeAttrValue);

				if ( ( tc_strlen(sPFCodeAttrValue) > 0 ) )
				{
					char	*psConfigFilePath	= NULL,
							*psConfigFile		= NULL;

					psConfigFilePath = getenv ("TC_DATA");

					if (psConfigFilePath!=NULL) 
					{
						psConfigFile = (char *) MEM_alloc(sizeof(char) * ((int)tc_strlen(psConfigFilePath) + (int)tc_strlen(MRV_FILTER_CONFIG_FILE_NAME) + 10) );

						sprintf(psConfigFile,"%s\\%s",psConfigFilePath,MRV_FILTER_CONFIG_FILE_NAME);
					}
					else
					{
						psConfigFile = (char *) MEM_alloc(sizeof(char) * ((int)tc_strlen(MRV_FILTER_PATH) + (int)tc_strlen(MRV_FILTER_CONFIG_FILE_NAME) + 10) );

						sprintf(psConfigFile,"%s\\%s",MRV_FILTER_PATH,MRV_FILTER_CONFIG_FILE_NAME);
					}

					fpConfigFile = fopen(psConfigFile, "r");

					if (fpConfigFile != NULL)
					{
						while( fgets( sConfigFileLine, 80, fpConfigFile) != NULL)
						{
							sTempPFCodeValue = tc_strtok(sConfigFileLine,"\n");

							if ( tc_strcasecmp(sTempPFCodeValue,sPFCodeAttrValue) == 0 )
							{
								char	*sSoureObjectRevisionTag	= NULL;

								printf("\n            Filter item found (\"%s\")",sPFCodeAttrValue);

								MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSoureObjectRevision, &sSoureObjectRevisionTag ));

								mapStructureObjects.insert(make_pair(std::string(sSoureObjectRevisionTag),std::string("SKIP")));

								*isFilter = 0;

								break;
							}
						}

						fclose(fpConfigFile);
					}
					else
					{
						printf("\n   *** ERROR: Unable to find out filter config file\n");
					}
				}								
			}
		}		
	}

	MRV_free_memory (ptSecondaryObjects);
		
	printf("\n        Exiting filter check function : ");

	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_check_existing_part
 *  Description			:This function used to check the existing items
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_check_existing_part(tag_t tSoureObjectRevision, char *sDomain, char **sReUseObjectTag)
{
	int		iStatus					= ITK_ok,
			iReferences				= 0,
			*iRefLevel				= 0,
			iSecondaryObjects		= 0,
			iBvCount                = 0,
			iSfCodeFlag				= 0;

	tag_t	*ptReferences			= NULL,
			tStorageClass			= NULLTAG,
			*ptSecondaryObjects		= NULL,
			tSourceItem             = NULLTAG,
			*tBvInputList			= NULL,
			tCloneRevTag            = NULLTAG,
			tCloneItem              = NULLTAG;

	char	**psRefRelations		= NULL,
			*sClassType				= NULL,
			sObjectType[WSO_object_type_size_c]	= "",
			*sDomainAttrValue		= NULL,
			sSourceItemId[256]      = "",
            *sCloneItemID           = NULL,
			sSourceRevId[ITEM_id_size_c+1] = "",
	        *sRevTagBomLine	        = NULL;

	*sReUseObjectTag = NULL;

	sCloneItemID = (char *) MEM_alloc(256);

	iErrorThrowConst++;

	printf("\n        Entering existing part check function : ");

	/*MRV_TRACE_CALL( iStatus = GRM_list_primary_objects_only(tSoureObjectRevision,NULLTAG, &iReferences, &ptReferences));*/
   
    MRV_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(tSoureObjectRevision,&tSourceItem));
	printf("\n tSourceItem = %d",tSourceItem);
    
	MRV_TRACE_CALL( iStatus = ITEM_ask_id  (tSourceItem,sSourceItemId) );
	printf("\n sSourceItemId = %s",sSourceItemId);

    MRV_TRACE_CALL( iStatus = ITEM_ask_rev_id  (tSoureObjectRevision,sSourceRevId)); 
    printf("\n sSourceRevId = %s",sSourceRevId);



    /*MRV_TRACE_CALL( iStatus = ITEM_find_item(sChildItemID,&sInputItem));*/
	
	MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs(tSoureObjectRevision,&iBvCount,&tBvInputList));
	printf("\n iBvCount = %d",iBvCount);
	if(iBvCount == 0)
	{  
       iSfCodeFlag = filter_check_for_leaf(tSourceItem);
	   
	   if(!tc_strcmp(sDomain,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%s%c", sSourceItemId, sSourceRevId,"AN",'F');
		else
			sprintf (sCloneItemID, "%s-%s-%s%c", sSourceItemId, sSourceRevId,"HW",*sDomain);
       
	   
	   printf("\n sCloneItemID = %s",sCloneItemID);
	}
    
	else
	{
		printf("\n inside else");
		printf("\n domain = %s",sDomain);

		if(!tc_strcmp(sDomain,MMCFD))
			sprintf (sCloneItemID, "%s-%s-%c", sSourceItemId, sSourceRevId,'F');
		else
			sprintf (sCloneItemID, "%s-%s-%c", sSourceItemId, sSourceRevId,*sDomain);

		printf("\n sCloneItemID = %s",sCloneItemID);
	}
	
	 iStatus = ITEM_find_item ( sCloneItemID, &tCloneItem );

	if(tCloneItem == NULLTAG)
	{
		printf("\n proceeding to create the clone item");
        if(iSfCodeFlag == 1)
	    {    
			printf("\n going to making map");
			MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSoureObjectRevision, &sRevTagBomLine ));
             mapStructureObjects.insert(make_pair(std::string(sRevTagBomLine),std::string("SKIP")));
		} 

         return ITK_ok;

	}
	else
	{

	iStatus = ITEM_ask_latest_rev(tCloneItem,&tCloneRevTag);
	
	/*for(int iCount=0;iCount<iReferences;iCount++)
	{*/
		/*MRV_TRACE_CALL( iStatus = POM_class_of_instance(ptReferences[iCount],&tStorageClass));

		MRV_TRACE_CALL( iStatus = POM_name_of_class(tStorageClass,&sClassType));*/

		/*if((tc_strstr(psRefRelations[iCount],MRV_MMITEM_TO_SIMASSEMBLY_REL))!=NULL)
		{*/
			/*if(tc_strcasecmp("ItemRevision",sClassType)==0)
			{*/
				/*MRV_TRACE_CALL( iStatus = WSOM_ask_object_type(ptReferences[iCount],sObjectType));

				if( ( tc_strcasecmp(MRV_SIMASSEMBLY_REV_TYPE,sObjectType ) ==0 ) || 
					( tc_strcasecmp(MRV_SIMPART_REV_TYPE,sObjectType) == 0 ) )*/
	          /* {*/
					/*MRV_TRACE_CALL( iStatus = GRM_list_secondary_objects_only ( ptReferences[iCount], NULLTAG, &iSecondaryObjects, &ptSecondaryObjects ));*/

					//for (int iZNX = 0; iZNX < iSecondaryObjects; iZNX++)
					//{
					//	iStatus = POM_class_of_instance(ptSecondaryObjects[iZNX], &tStorageClass);

					//	iStatus = POM_name_of_class(tStorageClass, &sClassType);

					//	if ( tc_strcasecmp(sClassType,"Form") == 0 )
					//	{
					//		MRV_TRACE_CALL( iStatus = WSOM_ask_object_type(ptSecondaryObjects[iZNX], sObjectType));

					//		if ( ( tc_strcasecmp(sObjectType,MRV_SIMASSEMBLY_REV_MASTER) == 0 ) || 
					//			( tc_strcasecmp(sObjectType,MRV_SIMPART_REV_MASTER) == 0 ) )
					//		{
					//			MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptSecondaryObjects[iZNX], MRV_DOMAIN_ATTRIBUTE, &sDomainAttrValue));

					//			if ( ( tc_strcasecmp(sDomainAttrValue,sDomain) == 0 ) )
					//			{
									

									MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tCloneRevTag, sReUseObjectTag ));

									MRV_TRACE_CALL( iStatus = AOM_tag_to_string ( tSoureObjectRevision, &sRevTagBomLine ));
                                    if(iSfCodeFlag == 1)
	                                 {
											 mapStructureObjects.insert(make_pair(std::string(sRevTagBomLine),std::string("SKIP")));
		                             } 


									
									else
									{

									mapStructureObjects.insert(make_pair(std::string(sRevTagBomLine),std::string(*sReUseObjectTag)));
									}

									printf("\n sReUseObjectTag = %s",*sReUseObjectTag);

	//								MRV_free_memory (ptSecondaryObjects);

	//								MRV_free_memory (psRefRelations);

	//								MRV_free_memory (iRefLevel);

	//								MRV_free_memory (ptReferences);

						}		
	//				/*			}								
	//						}
	//					}		
	//				}*/
	//			/*}*/
	//		/*}*/
	//	//}
	////}

	//MRV_free_memory (ptSecondaryObjects);

	//MRV_free_memory (psRefRelations);

	//MRV_free_memory (iRefLevel);

	//MRV_free_memory (ptReferences);
		
	printf("\n        Exiting existing part check function : ");

	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_process_child_structure
 *  Description			:This function used to process all child assemblies
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_process_child_structure(char *sChildItemID, char *sChildItemRevID, char *sDomainValue, tag_t tChildBomLine)
{
	int		iStatus					= ITK_ok,
			iChildBOMLineRevisions	= 0,
			iSFilter				= 1,
			iConfigValue              = 0;

	char	*sChildLineItemRevID	= NULL,
			*sChildLineItemID		= NULL,
			*sReUseObjectTag		= NULL,
			*sAttributeName         = NULL;

	tag_t	*ptChildBOMLineRevisions	= NULL,
			tRevTagBomLine				= NULLTAG;

	MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(tChildBomLine,"bl_revision",&tRevTagBomLine));

	/*********************************************************************	
		Block for Filter Check 		
	*********************************************************************/

	MRV_TRACE_CALL( iStatus = MRV_check_filter_part(tRevTagBomLine, &iSFilter) );

	if (!iSFilter)
	{
		return ITK_ok;
	}
	
	/*********************************************************************	
		Block for Re-Useable Check 		
	*********************************************************************/

	MRV_TRACE_CALL( iStatus = MRV_check_existing_part(tRevTagBomLine, sDomainValue, &sReUseObjectTag) );

	if ( tc_strlen(sReUseObjectTag) > 0 )
	{
		char	*sChildItemID1			= NULL,
				*sChildItemRevID1		= NULL;

		tag_t	tReUseObjectTag			= NULLTAG;

		MRV_TRACE_CALL( iStatus = AOM_string_to_tag ( sReUseObjectTag, &tReUseObjectTag ));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tReUseObjectTag,"item_id",&sChildItemID1));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tReUseObjectTag,"item_revision_id",&sChildItemRevID1));

		printf("\n           Re-Usable component %s/%s",sChildItemID1, sChildItemRevID1);

	}
	else
	{   
    	MRV_TRACE_CALL( iStatus = MRV_create_structure_component(sChildItemID, sChildItemRevID, sDomainValue, tRevTagBomLine) );
		/*if(iStatus  == MMREVNOTCONFIGUREDERROR)
		{
			printf("\n process aborting as one of the revision is unconfigured"); 
		    return MMREVNOTCONFIGUREDERROR;
		}*/
		/*********************************************************************	
			Block for processing child component		
		*********************************************************************/

		MRV_TRACE_CALL( iStatus = BOM_line_ask_all_child_lines(tChildBomLine, &iChildBOMLineRevisions,&ptChildBOMLineRevisions ));

		for(int iChildRevInx = 0 ;iChildRevInx<iChildBOMLineRevisions ;iChildRevInx++)
		{
			MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],"bl_item_item_id",&sChildLineItemID));

			MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],"bl_rev_item_revision_id",&sChildLineItemRevID));

			printf("\n\n    Child Level %d : %s/%s", iChildRevInx+1, sChildLineItemID, sChildLineItemRevID);
            
			MRV_TRACE_CALL( iStatus = BOM_line_look_up_attribute("bl_rev_item_revision_id",&iConfigValue));

            MRV_TRACE_CALL( iStatus = BOM_line_ask_attribute_string(ptChildBOMLineRevisions[iChildRevInx],iConfigValue,&sAttributeName));
         
		    printf("\n sAttributeName = %s",sAttributeName);

			 if(tc_strcmp(sAttributeName,"") == 0)
			 {
				return MMREVNOTCONFIGUREDERROR;
 			 }
            
             



			MRV_TRACE_CALL( iStatus = MRV_process_child_structure(sChildLineItemID, sChildLineItemRevID, sDomainValue, ptChildBOMLineRevisions[iChildRevInx]));

		}		

		MRV_free_memory (ptChildBOMLineRevisions);
	}

	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_process_clone_structure
 *  Description			:This function will create the clone structure 
 *						 for parent assembly
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_process_clone_structure(char *sMasterItemID, char *sMasterItemRevID, char *sDomainValue)
{
	int		iStatus				= ITK_ok,
			iBvrCount			= 0,
			iFirstLevelChild	= 0;

	tag_t	tMasterItemRev			= NULLTAG,
			tMasterItem				= NULLTAG,
			*ptBvrItem				= NULL,
			tBomWindow				= NULLTAG,
			tTopLine				= NULLTAG,
			*ptFirstLevelChildern	= NULL,
			tRuleTag                = NULLTAG;

	char	*sChildItemID			= NULL,
			*sChildItemRevID		= NULL,
			*sAbsMatrixValue		= NULL,
			*sFindNo				= NULL,
			*sRelMatrixValue        = NULL;

	tag_t	tChildItemRev			= NULLTAG;
	printf("\n checking .... %s",sAbsMatrixValue);

	printf("\n\nCloning Structure: %s/%s..\n", sMasterItemID, sMasterItemRevID);

	MRV_TRACE_CALL( iStatus = ITEM_find_item ( sMasterItemID, &tMasterItem ));

	MRV_TRACE_CALL( iStatus = ITEM_find_revision ( tMasterItem, sMasterItemRevID, &tMasterItemRev ));

	MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs ( tMasterItemRev, &iBvrCount, &ptBvrItem ));

	MRV_TRACE_CALL( iStatus = BOM_create_window(&tBomWindow));

	MRV_TRACE_CALL( iStatus = CFM_find(sGlobRevConfigRule,&tRuleTag)); 
	printf("\n tRuleTag = %d",tRuleTag);
	
    MRV_TRACE_CALL( iStatus = BOM_set_window_config_rule(tBomWindow,tRuleTag));
	
	MRV_TRACE_CALL( iStatus = BOM_set_window_top_line(tBomWindow,NULLTAG,tMasterItemRev,ptBvrItem[0],&tTopLine));

	MRV_TRACE_CALL( iStatus = BOM_line_ask_all_child_lines(tTopLine, &iFirstLevelChild,&ptFirstLevelChildern ));
		
	for(int iChildInx = 0 ;iChildInx<iFirstLevelChild ;iChildInx++)
	{
		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],"bl_item_item_id",&sChildItemID));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],"bl_rev_item_revision_id",&sChildItemRevID));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(ptFirstLevelChildern[iChildInx],"bl_revision",&tChildItemRev));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],MRV_BOM_FIND_NO,&sFindNo));

		printf("\n\n    Child Level %d : %s/%s", iChildInx+1, sChildItemID, sChildItemRevID);

		MRV_TRACE_CALL( iStatus = MRV_process_clone_child_structure(sDomainValue, ptFirstLevelChildern[iChildInx]));
		//MRV_TRACE_CALL( iStatus = MRV_process_clone_structure(sChildItemID, sChildItemRevID,sDomainValue));

        MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],MRV_TRANSFROM_MATRIX_ATTRIBUTE,&sAbsMatrixValue));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptFirstLevelChildern[iChildInx],MRV_TRANSFROM_RELMATRIX_ATTRIBUTE,&sRelMatrixValue));
		printf("\n checking .... %s",sAbsMatrixValue);

		
			MRV_TRACE_CALL( iStatus = MRV_create_bom_structure(tTopLine,ptFirstLevelChildern[iChildInx],sAbsMatrixValue,sRelMatrixValue,sFindNo));
		
		sRelMatrixValue = NULL;
		sAbsMatrixValue = NULL;
	}

	MRV_TRACE_CALL( iStatus = BOM_close_window(tBomWindow));
	
	MRV_free_memory (ptFirstLevelChildern);

	MRV_free_memory (ptBvrItem);
	
	return ITK_ok;
}
/****************************************************************************
 *  Function Name		:MRV_process_clone_child_structure
 *  Description			:This function will create the clone structure 
 *						 for child assembly
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_process_clone_child_structure(char *sDomainValue, tag_t tChildBomLine)
{
	int		iStatus					= ITK_ok,
			iChildBOMLineRevisions	= 0;

	char	*sChildLineItemRevID	= NULL,
			*sChildLineItemID		= NULL,
			*sAbsMatrixValue		= NULL,
			*sRelMatrixValue        = NULL,
			*sFindNo				= NULL;

	tag_t	*ptChildBOMLineRevisions	= NULL,
			tRevTagBomLine				= NULLTAG;

	MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(tChildBomLine,"bl_revision",&tRevTagBomLine));

	/*********************************************************************	
		Block for processing child component		
	*********************************************************************/
	printf("\n Before calling function .... %s",sAbsMatrixValue);
	MRV_TRACE_CALL( iStatus = BOM_line_ask_all_child_lines(tChildBomLine, &iChildBOMLineRevisions,&ptChildBOMLineRevisions ));

	for(int iChildRevInx = 0 ;iChildRevInx<iChildBOMLineRevisions ;iChildRevInx++)
	{
		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],"bl_item_item_id",&sChildLineItemID));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],"bl_rev_item_revision_id",&sChildLineItemRevID));

		printf("\n checking .... %s",sAbsMatrixValue);

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],MRV_BOM_FIND_NO,&sFindNo));

		printf("\n\n    Child Level %d : %s/%s", iChildRevInx+1, sChildLineItemID, sChildLineItemRevID);

		MRV_TRACE_CALL( iStatus = MRV_process_clone_child_structure(sDomainValue, ptChildBOMLineRevisions[iChildRevInx]));

        MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],MRV_TRANSFROM_MATRIX_ATTRIBUTE,&sAbsMatrixValue));

		MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptChildBOMLineRevisions[iChildRevInx],MRV_TRANSFROM_RELMATRIX_ATTRIBUTE,&sRelMatrixValue));

		
			MRV_TRACE_CALL( iStatus = MRV_create_bom_structure(tChildBomLine,ptChildBOMLineRevisions[iChildRevInx],sAbsMatrixValue,sRelMatrixValue,sFindNo));
		
        sAbsMatrixValue = NULL;
		sRelMatrixValue = NULL;
	}

	MRV_free_memory (ptChildBOMLineRevisions);

	return ITK_ok;
}

/****************************************************************************
 *  Function Name		:MRV_create_bom_structure
 *  Description			:This function will create the relation between
 *						 cloned parent and child component
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int MRV_create_bom_structure(tag_t topLine,tag_t BOMLine, char *sAbsMatrixValue,char *sRelMatrixValue ,char *sFindNo)
{
	 int		iStatus				= ITK_ok,
		        iBvrCount			= 0     ;

	 /* Declaration */
	tag_t	tAddedLine1			= NULLTAG,
			tBLParentObject		= NULLTAG,
			tBLChildObject		= NULLTAG,
			tParentCloneObject	= NULLTAG,
			tChildCloneObject	= NULLTAG,
			tBomWindow			= NULLTAG,
			tBomTopLine			= NULLTAG,
			*ptBvrItem			= NULLTAG,
			tRuleTag			= NULLTAG,
			tBOMViewType		= NULLTAG,
		    tBOMView			= NULLTAG,
			tParentCloneObjectItem	= NULLTAG,
			tBOMViewRevision		= NULLTAG;


	 char	*sBLParentObject		= NULL,
			*sBLChildObject			= NULL,
			sParentObjectName[256]  = "",
			*sAbsMatrixValue1       = NULL,
    	 	*sTempItemID			= NULL,
			*sTempItemRevID			= NULL,
			*sParentType			= NULL;
    
	

	 printf("\n       Entering function MRV_create_bom_structure");

	 MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(topLine,"bl_revision",&tBLParentObject));

	 printf("\n tBLParentObject = %d",tBLParentObject);

	 WSOM_ask_object_type(tBLParentObject,sParentObjectName);
	 printf("\n sParentObjectName = %s",sParentObjectName);

	 MRV_TRACE_CALL( iStatus = AOM_tag_to_string(tBLParentObject,&sBLParentObject));

	 mapCAEStruct::iterator mapCAEStructIteratorP = mapStructureObjects.find(sBLParentObject);

	 if ( mapCAEStructIteratorP != mapStructureObjects.end() )
	 {
		 if ( tc_strcasecmp(mapCAEStructIteratorP->second.c_str(),"SKIP") != 0 )
		 {
			MRV_TRACE_CALL( iStatus = AOM_string_to_tag(mapCAEStructIteratorP->second.c_str(),&tParentCloneObject));
            printf("\n inside if statement mapCAEStructIteratorP = %s, \ntParentCloneObject = %d",mapCAEStructIteratorP->second.c_str(),tParentCloneObject);
		    printf("\n tParentCloneObject = %d",tParentCloneObject);
		 }
	 }
     
	 if (tParentCloneObject != NULLTAG)
	 {
		 MRV_TRACE_CALL( iStatus = AOM_ask_value_tag(BOMLine,"bl_revision",&tBLChildObject));

		 MRV_TRACE_CALL( iStatus = AOM_tag_to_string(tBLChildObject,&sBLChildObject));

		 mapCAEStruct::iterator mapCAEStructIteratorC = mapStructureObjects.find(sBLChildObject);

		 if ( mapCAEStructIteratorC != mapStructureObjects.end() )
		 {
			 if ( tc_strcasecmp(mapCAEStructIteratorC->second.c_str(),"SKIP") != 0 )
			 {
				MRV_TRACE_CALL( iStatus = AOM_string_to_tag(mapCAEStructIteratorC->second.c_str(),&tChildCloneObject));
			 }
		 }
		 if (tChildCloneObject != NULLTAG){
			 MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tChildCloneObject,"item_id",&sTempItemID));
			 printf("\nPrinting PMI Chech ID:%s",sTempItemID);
			 if(tc_strstr(sTempItemID,"PMI")){
				tChildCloneObject = NULLTAG;
			 }
		 }

         printf("\n after two if statement ");
		 if (tChildCloneObject != NULLTAG)
		 {
			         tBomWindow	= NULLTAG,
					tBomTopLine	= NULLTAG,
					ptBvrItem	= NULLTAG;

			        iBvrCount	= 0;
					
			        sTempItemID	= NULL,
					sTempItemRevID	= NULL;


             printf("\n tParentCloneObject = %d",tParentCloneObject);

			 MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tParentCloneObject,"object_type",&sParentType));
			  printf("\n sParentType = %s",sParentType);
			 
			 MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tParentCloneObject,"item_id",&sTempItemID));

			 MRV_TRACE_CALL( iStatus = AOM_ask_value_string(tParentCloneObject,"item_revision_id",&sTempItemRevID));

			 printf("\n after findin item_rev_id    sTempItemID = %s   sTempItemRevID = %s  ",sTempItemID,sTempItemRevID);

			 printf("\n           Creating structure %s/%s",sTempItemID,sTempItemRevID);

			 MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs ( tParentCloneObject, &iBvrCount, &ptBvrItem ));

			 if (iBvrCount <= 0)
			 {
				       tBOMViewType	= NULLTAG,
						tBOMView		= NULLTAG,
						tParentCloneObjectItem	= NULLTAG,
						tBOMViewRevision		= NULLTAG;

				 MRV_TRACE_CALL( iStatus = PS_find_view_type ( MRV_BOM_VIEW_TYPE, &tBOMViewType ) );

				 MRV_TRACE_CALL( iStatus = ITEM_ask_item_of_rev(tParentCloneObject, &tParentCloneObjectItem) );

				 MRV_TRACE_CALL( iStatus = PS_create_bom_view ( tBOMViewType, NULL, NULL, tParentCloneObjectItem, &tBOMView) );

				 MRV_TRACE_CALL( iStatus = AOM_save(tBOMView));

				 MRV_TRACE_CALL( iStatus = AOM_save(tParentCloneObjectItem));

				 MRV_TRACE_CALL( iStatus = PS_create_bvr ( tBOMView, NULL, NULL, FALSE, tParentCloneObject, &tBOMViewRevision ) );

				 MRV_TRACE_CALL( iStatus = AOM_save(tBOMViewRevision));

				 MRV_TRACE_CALL( iStatus = AOM_save(tParentCloneObject));

			 }

			 MRV_TRACE_CALL( iStatus = BOM_create_window(&tBomWindow));

			 /*MRV_TRACE_CALL( iStatus = CFM_find(sGlobRevConfigRule,&tRuleTag)); 
	         printf("\n tRuleTag = %d",tRuleTag);
	  
     	     MRV_TRACE_CALL( iStatus = BOM_set_window_config_rule(tBomWindow,tRuleTag));*/
	
			 MRV_TRACE_CALL( iStatus = BOM_set_window_top_line(tBomWindow,NULLTAG,tParentCloneObject,NULLTAG,&tBomTopLine));

			 MRV_TRACE_CALL( iStatus = BOM_line_add(tBomTopLine,NULLTAG,tChildCloneObject,null_tag,&tAddedLine1));

			 MRV_TRACE_CALL( iStatus = BOM_save_window(tBomWindow));//check

			 MRV_TRACE_CALL( iStatus = BOM_refresh_window(tBomWindow));//check

			 MRV_TRACE_CALL( iStatus = AOM_set_value_string(tAddedLine1,MRV_BOM_FIND_NO,sFindNo));

			 printf("\n             Setting Absolute Matrix value : %s",sAbsMatrixValue);

			 //MRV_TRACE_CALL( iStatus = AOM_set_value_string(tAddedLine1,MRV_TRANSFROM_MATRIX_ATTRIBUTE,sAbsMatrixValue));
			 if(tc_strcmp(sRelMatrixValue,"") == 0)
			 {
             printf("\n doing only it is  null");
             MRV_TRACE_CALL( iStatus = AOM_set_value_string(tAddedLine1,MRV_TRANSFROM_RELMATRIX_ATTRIBUTE,""));
			 }
			 else
			 {    MRV_TRACE_CALL( iStatus = AOM_set_value_string(tAddedLine1,MRV_TRANSFROM_RELMATRIX_ATTRIBUTE,sRelMatrixValue));
				 printf("\n here for relative matrix not null");
			 }

			 MRV_TRACE_CALL( iStatus = BOM_save_window(tBomWindow));

			 MRV_TRACE_CALL( iStatus = BOM_close_window(tBomWindow));

			 MRV_free_memory (ptBvrItem);
		}
	 }

	 printf("\n       Entering function MRV_create_bom_structure");

	 return ITK_ok;
 }
/****************************************************************************
 *  Function Name		:traverse_master_structure
 *  Description			:This function will traverse the MM_Item structure and checks for
						 read access, availability of corresponding SIMPart
 *						 
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int traverse_master_structure(char *temp_master_id,char *temp_rev_id,char *domain_name )
{
      tag_t tItemTag			= NULLTAG,
		    tRevTag				= NULLTAG,
			*tBvList			= NULL,
			tWindow				= NULLTAG,
			tTopLine			= NULLTAG,
			*tChilds			= NULL,
			tChildItem			= NULLTAG,
			tFindItem			= NULLTAG,
			tMasterRel			= NULLTAG,
			*ptSecondaryObjects = NULL,
			tSimAssembly		= NULLTAG,
			tSimAssemblyRev		= NULLTAG,
			tFindItemRev		= NULLTAG,
			tChildItemMain		= NULLTAG,
			tRule				= NULLTAG;

	  int	iBvrCount			= 0,
			iChildCount			= 0,
			iStatus				= 0, 
			i					= 0,
			iSecondaryObjects	= 0,
			iSfCodeFlag			= 0,
			iPmiChk				= 0;

	  char	*sBlItemId			= NULL,
		    *sBlItemRevId		= NULL,
			*sFindItemId		= NULL,
			sObjectType[256]	= "",
			*sSimAssemblyId		= NULL;

	  char	*psConfigFilePath	= NULL,
			*psConfigFile		= NULL,
			sConfigFileLine[81] = "",
			*sTempPFCodeValue	= NULL,
			*sPFCodeAttrValue   = NULL;

	  FILE	*fpConfigFile		= NULL;

	  logical lVerdict					,
			  lSIMPartVerdict			,
		      lVerdict1					;

	  sFindItemId = (char *) MEM_alloc(256);
      sSimAssemblyId = (char *) MEM_alloc(256);
	  printf("\n Entering the travcre");
    //item tag is revision tag hav tochange it.
     MRV_TRACE_CALL( iStatus = ITEM_find_rev( temp_master_id, temp_rev_id,&tItemTag ));
     printf("\n tItemTag = %d",tItemTag);
    
	 if(!tc_strcmp(domain_name,MMCFD))
			sprintf (sSimAssemblyId, "%s-%s-%c", temp_master_id, temp_rev_id,'F');
	 else
			sprintf (sSimAssemblyId, "%s-%s-%c", temp_master_id, temp_rev_id,*domain_name);

	 printf("\n sSimAssemblyId = %s",sSimAssemblyId);
     //proj_assign_check(tItemTag);//for mm_item
	 ITEM_find_item(sSimAssemblyId,&tSimAssembly);
	 printf("\n tSimAssembly = %d",tSimAssembly);
     if(tSimAssembly != NULLTAG)
	 {   
		 ITEM_ask_latest_rev(tSimAssembly,&tSimAssemblyRev);
		 printf("\n tSimAssemblyRev = %d",tSimAssemblyRev);
		 ITEM_rev_list_bom_view_revs( tSimAssemblyRev, &iBvrCount, &tBvList );
		 iStatus = AM_check_privilege(tSimAssembly,"READ",&lVerdict);
		 printf(" \n  lVerdict = %d",lVerdict);
		 if(iBvrCount)
		 {
		 iStatus = AM_check_privilege(tBvList[0],"READ",&lVerdict1);
		 printf(" \n  lVerdict1 = %d",lVerdict1);
		 }
         
         if(lVerdict == 0 || lVerdict1 == 0)
		 {   
             tc_strcat(sMemberUnprivilegedList,"\r\n");
			 tc_strcat(sMemberUnprivilegedList,sSimAssemblyId);
			 printf("\n User has no READ privilege");
			 iUnprivilegeListReady = 1;
			 
		 }
		 else
		 {   
			 printf("\n User has READ privilege");
		 }
		 //proj_assign_check(tSimAssemblyRev);
	 }

	 MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs(tItemTag, &iBvrCount, &tBvList ));
	 printf("\n iBvrCount = %d",iBvrCount);
     
	 if(iBvrCount>0)
	 {
		 MRV_TRACE_CALL( iStatus = BOM_create_window(&tWindow));
		
		 MRV_TRACE_CALL( iStatus = CFM_find(sGlobRevConfigRule,&tRule)); 
	     printf("\n tRule = %d",tRule);
	  
     	 MRV_TRACE_CALL( iStatus = BOM_set_window_config_rule(tWindow,tRule));
         		
		 MRV_TRACE_CALL( iStatus = BOM_set_window_top_line(tWindow,NULLTAG,tItemTag,tBvList[0],&tTopLine));

		 MRV_TRACE_CALL( iStatus = BOM_line_ask_child_lines(tTopLine, &iChildCount,&tChilds ));
		   printf("\n iChildCount = %d",iChildCount);
		 for(i = 0;i<iChildCount;i++)
		 {
              iStatus = AOM_ask_value_string(tChilds[i],"bl_item_item_id",&sBlItemId);
			  iStatus = AOM_ask_value_string(tChilds[i],"bl_rev_item_revision_id",&sBlItemRevId);
			  
			  iStatus =ITEM_find_rev(sBlItemId,sBlItemRevId,&tChildItem);	
			  ITEM_ask_item_of_rev(tChildItem,&tChildItemMain);
			  
              MRV_TRACE_CALL( iStatus = ITEM_rev_list_bom_view_revs( tChildItem, &iBvrCount, &tBvList ));

			  if(iBvrCount>0)
			  {  
			     printf("\n recursion");
                 traverse_master_structure(sBlItemId,sBlItemRevId,domain_name);
			  }

			  else
			  {
              ///////
				iSfCodeFlag = filter_check_for_leaf(tChildItemMain);	
				printf("\n iSfCodeFlag = %d",iSfCodeFlag);
				if(iSfCodeFlag  ==  1)
				{  
					continue;
				}
              //////
	          printf("\n checking as leaf part");

			  if(!tc_strcmp(domain_name,MMCFD))
				   sprintf (sFindItemId, "%s-%s-%s%c", sBlItemId, sBlItemRevId,"AN",'F');
			  else
				   sprintf (sFindItemId, "%s-%s-%s%c", sBlItemId, sBlItemRevId,"HW",*domain_name);


			  ITEM_find_item(sFindItemId,&tFindItem);
			  if(tc_strstr(sFindItemId,"PMI")){
				//tFindItem = NULLTAG;
				//iSfCodeFlag = 0;
				  iPmiChk =1;
			 }
              
			  if(iPmiChk == 0){
					if(tFindItem == NULLTAG && iSfCodeFlag != 1) 
			  {   
				  printf("\n simpart missing");
				  iErrStrIndex++;
                  sUnavailablePartItemId[iErrStrIndex] = (char*)MEM_alloc(sizeof(char)*200);
				  sprintf(sUnavailablePartItemId[iErrStrIndex],"%s/%s",sBlItemId,sBlItemRevId);
				  printf("\nunavail_part_item_id[%d] = %s",iErrStrIndex,sUnavailablePartItemId[iErrStrIndex]);
				  iFlagTraverse = MMSIMPARTNOTAVAILABLEEROR;
			  }
			  else
			  {   printf("\n it has to come here");

						iStatus = AM_check_privilege(tFindItem,"READ",&lSIMPartVerdict);
						printf(" \n  lSIMPartVerdict = %d",lSIMPartVerdict);
						 if(lSIMPartVerdict == 0 )
						 {   
							 tc_strcat(sMemberUnprivilegedList,"\r\n");
							 tc_strcat(sMemberUnprivilegedList,sFindItemId);
							 printf("\n User has no READ privilege for this SIMPart");
							 iUnprivilegeListReady = 1;
						 }
						 else
						 {   
							 printf("\n User has READ privilege");
						 }
                 /* ITEM_ask_latest_rev(tFindItem,&tFindItemRev);
				  proj_assign_check(tFindItemRev);*/
			  }
			  }
              
			  
  
			  }
		 }
         
	 }
	 return iFlagTraverse;
}
/****************************************************************************
 *  Function Name		:filter_check_for_leaf
 *  Description			:This function will check for filter parts.
 *						 
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int filter_check_for_leaf(tag_t tChildItem)
{         
       char	*psConfigFilePath	= NULL,
			*psConfigFile		= NULL,
			sConfigFileLine[81] = "",
			*sTempPFCodeValue	= NULL,
			*sPFCodeAttrValue   = NULL;
	   
      tag_t tItemTag			= NULLTAG,
		    tRevTag				= NULLTAG,
			*tBvList			= NULL,
			tWindow				= NULLTAG,
			tTopLine			= NULLTAG,
			*tChilds			= NULL,
			tFindItem			= NULLTAG,
			tMasterRel			= NULLTAG,
			*ptSecondaryObjects = NULL,
			tClassTag           = NULLTAG;

	  int iBvrCount				= 0,
		  iChildCount			= 0,
		  iStatus				= 0, 
		  i						= 0,	
		  iSecondaryObjects		= 0,
		  iSfCodeFlag			= 0;

	  char *sBlItemId			= NULL,
		    *sBlItemRevId		= NULL,
			*sFindItemId		= NULL,
			sObjectType[256]	= "",
			*sClassName			= NULL;

	  
	  FILE	*fpConfigFile			= NULL;


				printf(" \n Inside filter_check_for_leaf................");

                MRV_TRACE_CALL( iStatus = GRM_find_relation_type("IMAN_master_form",&tMasterRel));
				printf(" \n tMasterRel .... %d",tMasterRel);

				MRV_TRACE_CALL( iStatus = GRM_list_secondary_objects_only ( tChildItem, tMasterRel, &iSecondaryObjects, &ptSecondaryObjects ));

				printf(" \n iSecondaryObjects .... %d",iSecondaryObjects);

				for (int iZNX = 0; iZNX < iSecondaryObjects; iZNX++)
				{
					
						MRV_TRACE_CALL( iStatus = WSOM_ask_object_type(ptSecondaryObjects[iZNX], sObjectType));
						printf(" \n sObjectType .... %s",sObjectType);
						MRV_TRACE_CALL( iStatus = POM_class_of_instance(ptSecondaryObjects[iZNX],&tClassTag));
						printf(" \n tClassTag .... %d",tClassTag);
						MRV_TRACE_CALL( iStatus = POM_name_of_class(tClassTag,&sClassName)); 
						printf(" \n sClassName .... %s",sClassName);


						if (  tc_strstr(sObjectType,"MM_Item") != NULL || tc_strstr(sObjectType,"MM_Item_I") != NULL || tc_strstr(sObjectType,"MM_ControlPart") != NULL || tc_strstr(sObjectType,"MM_DesignContext") != NULL || tc_strstr(sObjectType,"MM_MasterSection") != NULL || tc_strstr(sObjectType,"MM_PMI") != NULL || tc_strstr(sObjectType,"MM_StandardPart") != NULL || tc_strstr(sObjectType,"MM_Supplier") != NULL || tc_strstr(sObjectType,"MM_Supplier_I") != NULL || tc_strstr(sObjectType,"MM_Temp") != NULL || tc_strstr(sObjectType,"MM_Temp_I") != NULL || tc_strstr(sObjectType,"MM_Vehicle") != NULL )
						{   
							MRV_TRACE_CALL( iStatus = AOM_ask_value_string(ptSecondaryObjects[iZNX], MRV_FILTER_ATTRIBUTE, &sPFCodeAttrValue));

							printf("\n sPFCodeAttrValue = %s",sPFCodeAttrValue);

							if ( ( tc_strlen(sPFCodeAttrValue) > 0 ) )
							{
								psConfigFilePath	= NULL,
								psConfigFile		= NULL;

								psConfigFilePath = getenv ("TC_DATA");

								if (psConfigFilePath!=NULL) 
								{
									psConfigFile = (char *) MEM_alloc(sizeof(char) * ((int)tc_strlen(psConfigFilePath) + (int)tc_strlen(MRV_FILTER_CONFIG_FILE_NAME) + 10) );

									sprintf(psConfigFile,"%s\\%s",psConfigFilePath,MRV_FILTER_CONFIG_FILE_NAME);
								}

								fpConfigFile = fopen(psConfigFile, "r");

								if (fpConfigFile != NULL)
								 {   printf("\nfile found");
									while( fgets( sConfigFileLine, 80, fpConfigFile) != NULL)
									{
										sTempPFCodeValue = tc_strtok(sConfigFileLine,"\n");

										if ( tc_strcasecmp(sTempPFCodeValue,sPFCodeAttrValue) == 0 )
										{
											printf("\n            Filter item found (\"%s\")",sPFCodeAttrValue);
											iSfCodeFlag  =  1;
											break;
										}
									}
			                        
									fclose(fpConfigFile);
									printf("\nskipping for this item");
									break;
								}
								else
								{
									printf("\n   *** ERROR: Unable to find out filter config file\n");
								}
							}								
						}
				   		
				}
				return iSfCodeFlag;

}
/****************************************************************************
 *  Function Name		:proj_assign_check
 *  Description			:This function will check whether the MM_Item is assigned to 
						 any projects are not.
 *						 
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int proj_assign_check(tag_t tRevTag)
{
		char *sProjectIdValue   = NULL,
		     sRevId[256]        = "",
			 sItemId[256]       = "",
			 sTempString[256]   = "",
			 person_name[256]   = "";

		tag_t sItemOfRev        = NULLTAG;
			  
		int   iStatus           = 0;
        
		MRV_TRACE_CALL( iStatus =  ITEM_ask_rev_id (tRevTag,sRevId));
        MRV_TRACE_CALL( iStatus =  ITEM_ask_item_of_rev(tRevTag,&sItemOfRev));
		MRV_TRACE_CALL( iStatus =  ITEM_ask_id (sItemOfRev,sItemId));
	    MRV_TRACE_CALL( iStatus =  AOM_ask_value_string(tRevTag,"project_ids",&sProjectIdValue));
		printf("\n sProjectIdValue=%s",sProjectIdValue);
        /*MRV_TRACE_CALL( iStatus =  AOM_ask_value_string(mm_rev_tag,"project_ids",&project_id_mm));*/
		

		if(tc_strcmp(sProjectIdValue,"") == 0 || tc_strcmp(sProjectIdValue," ") == 0)
		{
			printf("\nIF");
           sprintf(sTempString,"\r\n%s/%s",sItemId,sRevId);
		   tc_strcat(sProjUnassignedList,sTempString);
		   iProjUnassignedListReady = 1;
		}
		else
		{
			printf("\nELSE");
		}
        


  

return ITK_ok;

}


/****************************************************************************
 *  Function Name		:proj_assign
 *  Description			:This function will assign MM_Item is project to 
						 cloned Items.
 *						 
 *	REQUIRED HEADERS	:MRV_structure_mapping.h
 *  INPUT/OUTPUT PARAMS	:
 *
 *	RETURN VALUE		:ITK_ok for success
 *						 iStatus value in case of failures
 *	GLOBALS USED		: None
 *	FUNCTIONS CALLED	:
 *
 ******************************************************************************/
int proj_assign(tag_t tRevTag, tag_t tTargetRevTag)
{
		char *sProjectIdValue   = NULL,
		     sRevId[256]        = "",
			 sItemId[256]       = "",
			 sTempString[256]   = "",
			 person_name[256]   = "",
			 *sTempProjID		= NULL,
			 *sCpyProjID		= NULL;

		tag_t sItemOfRev        = NULLTAG,
			  sItemOfRevTar		= NULLTAG,
			  tProjectTag		= NULLTAG;
			  
		int   iStatus           = 0;

		logical	  is_user_privileged_member	= false;
		logical	  is_project_active	        = false;
        
		MRV_TRACE_CALL( iStatus =  ITEM_ask_rev_id (tRevTag,sRevId));
        MRV_TRACE_CALL( iStatus =  ITEM_ask_item_of_rev(tRevTag,&sItemOfRev));
		MRV_TRACE_CALL( iStatus =  ITEM_ask_item_of_rev(tTargetRevTag,&sItemOfRevTar));
		MRV_TRACE_CALL( iStatus =  ITEM_ask_id (sItemOfRev,sItemId));
	    MRV_TRACE_CALL( iStatus =  AOM_ask_value_string(tRevTag,"project_ids",&sProjectIdValue));
		printf("\n sProjectIdValue=%s",sProjectIdValue);
        /*MRV_TRACE_CALL( iStatus =  AOM_ask_value_string(mm_rev_tag,"project_ids",&project_id_mm));*/
		

		if(tc_strcmp(sProjectIdValue,"") != 0 || tc_strcmp(sProjectIdValue," ") != 0)
		{
			/*printf("\nIF");
           sprintf(sTempString,"\r\n%s/%s",sItemId,sRevId);
		   tc_strcat(sProjUnassignedList,sTempString);
		   iProjUnassignedListReady = 1;*/
			if( tc_strstr(sProjectIdValue,",") != NULL )
			{
				sTempProjID = tc_strtok(sProjectIdValue,",");
				while(sTempProjID != NULL)
				{
					MRV_TRACE_CALL(iStatus = PROJ_find(sTempProjID,&tProjectTag));
					printf("\n proj tag is %d",tProjectTag);
					if(tProjectTag != NULLTAG)
					{		
						MRV_TRACE_CALL( iStatus = AOM_refresh(sItemOfRevTar, true));
						MRV_TRACE_CALL(iStatus = PROJ_assign_objects(1,&tProjectTag,1,&sItemOfRevTar));
						MRV_TRACE_CALL( iStatus = AOM_refresh(sItemOfRevTar, false));					
					}

					sTempProjID = tc_strtok(NULL,",");
				}
			}
			else
			{
				MRV_TRACE_CALL(iStatus = PROJ_find(sProjectIdValue,&tProjectTag));
				printf("\n proj tag is %d",tProjectTag);
				if(tProjectTag != NULLTAG)
				{	
					MRV_TRACE_CALL( iStatus = AOM_refresh(sItemOfRevTar, true));
					MRV_TRACE_CALL(iStatus = PROJ_assign_objects(1,&tProjectTag,1,&sItemOfRevTar));
					MRV_TRACE_CALL( iStatus = AOM_refresh(sItemOfRevTar, false));
					printf("\n Project assingned for proposal");	

				}
			}
		}
		else
		{
			printf("\nELSE");
		}    

return ITK_ok;

}



