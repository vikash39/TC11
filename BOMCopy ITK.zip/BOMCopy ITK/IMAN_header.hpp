#include <iostream>
#include <fstream>
#include <ctime>
#include <user_exits\epm_toolkit_utils.h>
#include <tccore\aom.h>
#include <tccore\aom_prop.h>
#include<tcinit\tcinit.h>
#include <tccore\workspaceobject.h>
#include <tc\emh.h>
#include <tc\folder.h>
#include <sa\group.h>
#include <tccore/grm.h>

using namespace std;

#define LOGNAME_FORMAT "log_%Y%m%d_%H%M%S.txt"
#define ERROR_REPORT(x)	{\
							int result;\
							char *err_string;\
							if( (result = (x)) != ITK_ok)\
							{\
								EMH_ask_error_text (result, &err_string);\
								logfile << "\n\t[ERROR : " << result << "]" << err_string << endl;\
								logfile << "\tFunction : " << #x << "FILE:"  << __FILE__ << "LINE:" <<  __LINE__ << endl;\
								MEM_free (err_string);\
							}\
						}

ofstream logfile;

void Help();
void ReadArguments(char **sUserName,char **sPassword,char **sGroupName,char **sInputGroupName);
void RemoveFromAllFolder(tag_t object);