#include "IMAN_header.hpp"

/*!
*	"Utility for Activity Migration"
*	ITK utility (cpp) to copy the value from One attribute to another. This will do the following process
*	
*	1.  Search for all Objects (Activities) with class name: MEActivity and with the given Group Name (i/p from Command Line Argument).
*   Use WSOM_search api to get all objects
*
*	2. Iterate the output Activities:
*		A) If the object_type of the Activity is ARConvActivity then convert the Type of Activity to ARActivity
*		B)  Get the Form attached under the Activity using FL_ask_references api.
*		C) Get attributes form the FORM and set it in the Activity objet itself          
*            AC_Operation_Position to ar3AC_Position
*            AC_Activity_Type to ar3 AC_Activity_Type
*            AC_ID to ar3AC_Activity_ID
*            AC_Labour to ar3AC_Labour
*		D) Get calc time form Activity and Set it in unit time attribute in the Activity itself
*            calc_time to time_system_unit_time
*		E)  Delete Form from the Activity.
*
*/

int ITK_user_main(int argc,char * argv[])
{
	char	*sUserName = NULL,	*sPassword = NULL,	*sGroupName = NULL,
			*sInputGroupName = NULL,	*sObjectType = NULL,	*sObjectName = NULL,
			*sPropValue = NULL;
	
	char sfilename[100];
	char	sUnitTime[32];
	double dCalcTime;
	int	iErrorCode,	iNumberFound,	iNumberOfRef;
	tag_t groupTag = NULL;

	tag_t* listofWSOtags = {NULLTAG},	*listOfRef = {NULLTAG};

	time_t t = time(NULL);
	FL_sort_criteria_t fl_sort_criteria = FL_fsc_no_order;

	strftime(sfilename, sizeof(sfilename), LOGNAME_FORMAT, std::localtime(&t));
	logfile.open (sfilename);
	
	logfile << "Utility started the Processing" << endl;
	logfile << "Read the input arguments... " << argc << endl;
	logfile << "Total input argument is : " << argc << endl;

	if ( argc < 5 || ITK_ask_cli_argument("-help") || ITK_ask_cli_argument("-h") )
		Help();
	
	ReadArguments(&sUserName, &sPassword, &sGroupName,&sInputGroupName);
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	if (ITK_init_module(sUserName,sPassword,sGroupName) == ITK_ok )
	{
		logfile << "\n\n**************************************************************************************\n";
		logfile <<  "\n*                           Login to TC.......                               *   ";
		logfile << "\n**************************************************************************************\n" ;

		ERROR_REPORT(SA_find_group(sInputGroupName,&groupTag));

		if( groupTag == NULLTAG )
		{
			logfile << "\n Group is invalid : " << sInputGroupName << " \n Please specify any group in Teamcenter\n" ;
		}

        WSO_search_criteria_t criteria;
		WSOM_clear_search_criteria(&criteria);
        strcpy(criteria.pom_class_name,"MEActivity");
		criteria.group = groupTag;
		try
		{
			ERROR_REPORT(WSOM_search(criteria, &iNumberFound,&listofWSOtags));
		}
		catch(...)
		{
			logfile << "\n Exception \n" ;
			return ITK_ok;
		}

		logfile << "\n Number of MEActivity : " << iNumberFound << endl;

		for(int iActivity = 0; iActivity < iNumberFound ; ++iActivity)
		{
			ERROR_REPORT(AOM_ask_value_string(listofWSOtags[iActivity],"object_name",&sObjectName));
			ERROR_REPORT(AOM_ask_value_string(listofWSOtags[iActivity],"object_type",&sObjectType));
			logfile << "\n Processing MEActivity : " << iActivity << "\n\t" << "Object Name : " << sObjectName ;
			logfile << "\n\tObject Type : " << sObjectType << endl;

			if (  sObjectType != NULL && tc_strlen(sObjectType) > 0 &&   tc_strcmp( sObjectType, "ARConvActivity") == ITK_ok ) 
			{
				POM_load_instances_any_class(1,&listofWSOtags[iActivity],POM_modify_lock);
				AOM_refresh(listofWSOtags[iActivity],true);
				ERROR_REPORT(WSOM_set_object_type(listofWSOtags[iActivity],"ARActivity"));
				AOM_save(listofWSOtags[iActivity]);
				AOM_refresh(listofWSOtags[iActivity],false);
			}

			if( sObjectType != NULL && tc_strlen(sObjectType) > 0 && ( tc_strcmp( sObjectType, "ARConvActivity") == ITK_ok || 
				tc_strcmp( sObjectType, "ARActivity") == ITK_ok ))
			{
				ERROR_REPORT(FL_ask_references(listofWSOtags[iActivity],fl_sort_criteria,&iNumberOfRef,&listOfRef));
				logfile << "\t Number of reference : " << iNumberOfRef << endl ;
				ERROR_REPORT(AOM_refresh(listofWSOtags[iActivity],true));

				for(int iRef = 0; iRef < iNumberOfRef ; ++iRef)
				{
					ERROR_REPORT(AOM_ask_value_string(listOfRef[iRef],"object_type",&sObjectType));
					if(sObjectType != NULL && tc_strlen( sObjectType ) > 0 && ( tc_strcmp( sObjectType, "ARConvActivityForm") == ITK_ok || 
						tc_strcmp( sObjectType, "ARActivityForm") == ITK_ok))
					{
						logfile << "\t Reference found : " << sObjectType << endl;

						ERROR_REPORT(AOM_ask_value_string(listOfRef[iRef],"AC_Operation_Position",&sPropValue));
						ERROR_REPORT(AOM_set_value_string(listofWSOtags[iActivity],"ar3AC_Position",sPropValue));
						logfile << "\t AC_Operation_Position -> ar3AC_Position : " << sPropValue << endl;

						ERROR_REPORT(AOM_ask_value_string(listOfRef[iRef],"AC_Activity_Type",&sPropValue));
						ERROR_REPORT(AOM_set_value_string(listofWSOtags[iActivity],"ar3AC_Activity_Type",sPropValue));
						logfile << "\t AC_Activity_Type -> ar3AC_Activity_Type : " << sPropValue << endl;

						ERROR_REPORT(AOM_ask_value_string(listOfRef[iRef],"AC_ID",&sPropValue));
						ERROR_REPORT(AOM_set_value_string(listofWSOtags[iActivity],"ar3AC_Activity_ID",sPropValue));
						logfile << "\t AC_ID -> ar3AC_Activity_ID : " << sPropValue << endl;

						ERROR_REPORT(AOM_ask_value_string(listOfRef[iRef],"AC_Labour",&sPropValue));
						ERROR_REPORT(AOM_set_value_string(listofWSOtags[iActivity],"ar3AC_Labour",sPropValue));
						logfile << "\t AC_Labour -> ar3AC_Labour : " << sPropValue << endl;

						ERROR_REPORT(AOM_lock_for_delete(listOfRef[iRef]));
						RemoveFromAllFolder(listOfRef[iRef]);
						ERROR_REPORT(AOM_delete(listOfRef[iRef]));
					}
				} // End of Reference

				ERROR_REPORT(AOM_ask_value_double(listofWSOtags[iActivity],"calc_time",&dCalcTime));
				
				if(dCalcTime >0)
				{
					ERROR_REPORT(AOM_set_value_double(listofWSOtags[iActivity],"time_system_unit_time",dCalcTime));
				}
				else 
					dCalcTime = 0;

				logfile << "\t calc_time -> time_system_unit_time : " << dCalcTime << endl;

				ERROR_REPORT(AOM_save(listofWSOtags[iActivity]));
				ERROR_REPORT(AOM_refresh(listofWSOtags[iActivity],false));
			}
		} // End of Activity

        MEM_free(listofWSOtags); 
		if( sObjectType != NULL && tc_strlen(sObjectType) > 0 )	MEM_free(sObjectType);
		if( sObjectName != NULL && tc_strlen(sObjectName) > 0 )	MEM_free(sObjectName);
		if( sPropValue != NULL && tc_strlen(sPropValue) > 0 )	MEM_free(sPropValue);
	}

	logfile.close();
	return ITK_ok;
}

void Help()
{
	logfile << "\n------------------------------------------------------------\n" ;
	logfile << "Usage:\n\n";
	logfile << "MEActivity_update_attr.exe \t-u=<valid Teamcenter User Name>\n\n" ;
	logfile << "\t\t\t\t-p=<valid Password of the User>\n\n" ;
	logfile << "\t\t\t\t-g=<valid Group of the User>\n\n" ;
	logfile << "\t\t\t\t[-InGroup]=<Valid Input group name for MEactivity>\n\n" ;
	logfile << "\t\t\t\t[-help]\n\n" ;
	logfile << "-u\t\t-  User name\n\n" ;
	logfile << "-p\t\t-  Password\n\n" ;
	logfile << "-g\t\t-  Group\n\n" ;
	logfile << "-InGroup\t\t-  input Group\n\n" ;
	logfile << "-help\t\t-  Displays this help\n\n" ;
	logfile << "------------------------------------------------------------\n" ;
	exit(1);
}

void ReadArguments(char **sUserName,char **sPassword,char **sGroupName,char **sInputGroupName)
{
	*sUserName = ITK_ask_cli_argument( "-u=" );
	if(*sUserName==NULL)	{	logfile << "\nArgument -Username Missing";	Help(); }

	*sPassword = ITK_ask_cli_argument( "-p=" );
	if(*sPassword==NULL)	{	logfile << "\nArgument -Password Missing";	Help(); }

	*sGroupName = ITK_ask_cli_argument( "-g=" );
	if(*sGroupName==NULL)	{	logfile << "\nArgument -Group Missing";	Help(); }

	*sInputGroupName = ITK_ask_cli_argument( "-InGroup=" );
	if(*sInputGroupName==NULL)	{	logfile << "\nArgument -InGroup Missing";	Help(); }
}

void RemoveFromAllFolder(tag_t object)
{
    int	iInstances,	*instance_levels,	*instance_where_found,
        n_classes,	*class_levels,	*class_where_found;
   
	tag_t	folder_type,	newstuff_type,	*ref_instances,
        *ref_classes,	type = NULLTAG;

    ERROR_REPORT(POM_referencers_of_instance(object, 1, POM_in_ds_and_db,
        &iInstances, &ref_instances, &instance_levels,
        &instance_where_found, &n_classes, &ref_classes, &class_levels,
        &class_where_found));

    if (iInstances > 0)
    {
        for (int iRef = 0; iRef < iInstances; iRef++)
        {
			char* sTypeName = NULL;
            TCTYPE_ask_object_type(ref_instances[iRef], &type);
			TCTYPE_ask_name2(type, &sTypeName);
            if (tc_strcasecmp(sTypeName, "Folder") == 0 || tc_strcasecmp(sTypeName, "Newstuff Folder"))
            {
                ERROR_REPORT(AOM_refresh(ref_instances[iRef], TRUE));
                ERROR_REPORT(FL_remove(ref_instances[iRef], object));
                ERROR_REPORT(AOM_save(ref_instances[iRef]));
                ERROR_REPORT(AOM_refresh(ref_instances[iRef], FALSE));
            }
        }
        
		MEM_free(ref_instances);
        MEM_free(instance_levels);
        MEM_free(instance_where_found);
    }

    if (n_classes > 0)
    {
        MEM_free(ref_classes);
        MEM_free(class_levels);
        MEM_free(class_where_found);
    }
}